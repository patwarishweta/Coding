package com.cwan.privatefund.transaction.model;

import java.time.LocalDate;
import java.util.NavigableMap;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NavSchedules {

  private Long accountId;
  private Long securityId;
  private NavigableMap<LocalDate, Double> navSchedule;
  private NavigableMap<LocalDate, Double> gaapNavSchedule;
  private NavigableMap<LocalDate, Double> statNavSchedule;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class NavSchedule {

  private LocalDate scheduleDate;
  private Double amount;
}
