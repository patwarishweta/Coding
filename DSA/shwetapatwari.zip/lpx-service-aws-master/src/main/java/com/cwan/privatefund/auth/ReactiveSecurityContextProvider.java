package com.cwan.privatefund.auth;

import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/** Class for providing SecurityContext using ReactiveSecurityContextHolder. */
@Service
public class ReactiveSecurityContextProvider implements ISecurityContextProvider {

  /**
   * Provides the SecurityContext using ReactiveSecurityContextHolder.
   *
   * @return the current SecurityContext wrapped in a Mono.
   */
  @Override
  public Mono<SecurityContext> provideContext() {
    return ReactiveSecurityContextHolder.getContext();
  }
}
