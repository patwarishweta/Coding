package com.cwan.privatefund.leadership.service;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.leader.Context;
import org.springframework.stereotype.Service;

/** LpxLeadershipManager provides services related to leadership context management. */
@Service
public class LpxLeadershipManager {

  @Value("${leadershipManager.isLeader:false}")
  private Boolean isLeader;

  private final AtomicReference<Context> lpxLeadershipContext = new AtomicReference<>();

  public Context getLpxLeadershipContext() {
    Optional.ofNullable(isLeader)
        .filter(Boolean.TRUE::equals)
        .ifPresent(val -> lpxLeadershipContext.set(() -> true));
    return lpxLeadershipContext.get();
  }

  public void setLpxLeadershipContext(Context context) {
    lpxLeadershipContext.set(context);
  }
}
