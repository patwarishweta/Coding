package com.cwan.privatefund.fxrate.source;

import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountSpotSourceHistory {
  private List<SpotSourceConfig> defaultSortedHistory;
  private Map<Integer, List<SpotSourceConfig>> sortedHistoriesByBasisId;
}
