package com.cwan.privatefund.cpd.ws.client;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.client.WsClientStatus;
import com.cwan.privatefund.cpd.ws.model.CpdField;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import java.net.UnknownHostException;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Slf4j
@Service
public class CpdWSClient {

  private static final String DATA_TAG_PATH = "data/tag/get";
  private static final String FIELD_PATH = "field/by/client/";
  private static final String FIELD_ID_PARAM = "fid";
  public static final String CLIENT_ID_PARAM = "cid";
  public static final String ACCOUNT_ID_PARAM = "aid";
  private final WebClient cpdWebClient;
  private final AuthTokenCore authTokenCore;

  /**
   * Constructor for the CpdWSClient service.
   *
   * @param cpdWebClient The web client for CPDWS.
   * @param authTokenCore The auth token core for CPDWS authentication.
   */
  public CpdWSClient(WebClient cpdWebClient, AuthTokenCore authTokenCore) {
    this.cpdWebClient = cpdWebClient;
    this.authTokenCore = authTokenCore;
  }

  /**
   * Fetches tag entries based on field IDs, client ID, and account ID.
   *
   * @param fids The set of field IDs.
   * @param clientId The client's ID.
   * @param accountId The account's ID.
   * @return A Flux stream containing the corresponding tag entries.
   */
  public Flux<TagEntry> getTagEntries(Set<Integer> fids, Long clientId, Long accountId) {
    log.debug(
        "Fetching tag entries with fids: {}, clientId: {}, accountId: {}",
        fids,
        clientId,
        accountId);
    return cpdWebClient
        .get()
        .uri(
            uriBuilder -> {
              uriBuilder.path(DATA_TAG_PATH);
              fids.forEach(fid -> uriBuilder.queryParam(FIELD_ID_PARAM, fid));
              uriBuilder.queryParam(CLIENT_ID_PARAM, clientId);
              if (accountId != null) {
                uriBuilder.queryParam(ACCOUNT_ID_PARAM, accountId);
              }
              return uriBuilder.build();
            })
        .headers(httpHeaders -> httpHeaders.setBearerAuth(authTokenCore.createApplicationToken()))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res -> {
              log.error("4xx error for getTagEntries with fids: {}", fids);
              return WsClientStatus.onStatusError(
                  res, "CpdWSClient getTagEntries 4xxClientError for fids: " + fids);
            })
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res -> {
              log.error("5xx error for getTagEntries with fids: {}", fids);
              return WsClientStatus.onStatusError(
                  res, "CpdWSClient getTagEntries is5xxServerError for fids: " + fids);
            })
        .bodyToFlux(TagEntry.class)
        .onErrorResume(
            e -> {
              handleWebClientError(
                  "fids: " + fids + ", clientId: " + clientId + ", accountId: " + accountId, e);
              return Flux.empty();
            });
  }

  private void handleWebClientError(String requestInfo, Throwable e) {
    if (e instanceof UnknownHostException) {
      log.error(
          "Failed to get response cpdWsClient {} due to UnknownHostException for Request: {}",
          "getTagEntries",
          requestInfo,
          e);
    } else {
      log.error(
          "Failed to get response cpdWsClient {} for Request: {} Exception: ",
          "getTagEntries",
          requestInfo,
          e);
    }
  }

  /**
   * Fetches cpd fields based on client ID.
   *
   * @param clientId The client's ID.
   * @return A Flux stream containing the corresponding field entries.
   */
  public Flux<CpdField> getCpdFields(Long clientId) {
    log.debug("Fetching cpd fields with clientId: {}", clientId);
    return cpdWebClient
        .get()
        .uri(
            uriBuilder -> {
              uriBuilder.path(FIELD_PATH + clientId);
              uriBuilder.queryParam("criteria", "CLIENT_FIELDS");
              return uriBuilder.build();
            })
        .headers(httpHeaders -> httpHeaders.setBearerAuth(authTokenCore.createApplicationToken()))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res -> {
              log.error("4xx error for getCpdFields with clientId: {}", clientId);
              return WsClientStatus.onStatusError(
                  res, "CpdWSClient getCpdFields 4xxClientError for clientId: " + clientId);
            })
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res -> {
              log.error("5xx error for getCpdFields with clientId: {}", clientId);
              return WsClientStatus.onStatusError(
                  res, "CpdWSClient getCpdFields is5xxServerError for clientId: " + clientId);
            })
        .bodyToFlux(CpdField.class)
        .onErrorResume(
            e -> {
              handleWebClientError("clientId: " + clientId, e);
              return Flux.empty();
            });
  }
}
