package com.cwan.privatefund.auth.service;

import java.util.Set;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AuthenticationServiceConfig {

  @Bean(value = "authServices")
  Set<AuthenticationService> authServices(
      SessionAuthenticationService sessionAuthenticationService,
      JwtAuthenticationService jwtAuthenticationService) {
    return Set.of(sessionAuthenticationService, jwtAuthenticationService);
  }
}
