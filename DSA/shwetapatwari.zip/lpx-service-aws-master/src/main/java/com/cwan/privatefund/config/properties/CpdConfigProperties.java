package com.cwan.privatefund.config.properties;

import java.util.Map;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "cpd")
public class CpdConfigProperties {

  private WebService webService;
  private Cache cache;
  private FieldIds fieldIds;

  @Data
  public static final class WebService {

    private String baseUrl;
    private Integer maxMemorySize;
  }

  @Data
  public static final class Cache {

    private Integer maxSize;
    private Integer timeoutInHours;
  }

  @Data
  public static final class FieldIds {

    private Map<String, Integer> reviewers;
    private Map<String, Integer> abaRoutingNumbers;
  }
}
