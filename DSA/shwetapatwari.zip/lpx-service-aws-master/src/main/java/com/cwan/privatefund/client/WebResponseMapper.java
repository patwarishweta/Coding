package com.cwan.privatefund.client;

import java.net.UnknownHostException;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import reactor.core.publisher.Mono;

@Slf4j
public abstract class WebResponseMapper<T extends RuntimeException> {

  protected abstract T getException(String msg);

  public <U> Mono<U> mapToType(
      WebClient.ResponseSpec responseSpec, ParameterizedTypeReference<U> typeReference) {
    withOnStatus(responseSpec);
    return responseSpec.bodyToMono(typeReference).onErrorResume(getFallback());
  }

  public <U> Mono<U> mapToClass(WebClient.ResponseSpec responseSpec, Class<U> clasz) {
    withOnStatus(responseSpec);
    return responseSpec.bodyToMono(clasz).onErrorResume(getFallback());
  }

  private void withOnStatus(ResponseSpec responseSpec) {
    responseSpec
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response -> Mono.error(getException("is4xxClientError Exception " + response)))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response -> Mono.error(getException("is5xxServerError Exception " + response)));
  }

  private <T> Function<? super Throwable, ? extends Mono<? extends T>> getFallback() {
    return e -> {
      if (e instanceof UnknownHostException) {
        log.error("Failed to get response, desired service not present :: UnknownHostException");
      } else {
        log.error("Failed to receive response due to {}", e.getMessage());
      }
      throw getException("Exception occured during request: " + e);
    };
  }
}
