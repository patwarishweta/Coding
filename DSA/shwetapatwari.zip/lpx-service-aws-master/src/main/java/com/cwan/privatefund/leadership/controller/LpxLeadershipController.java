package com.cwan.privatefund.leadership.controller;

import com.cwan.privatefund.leadership.service.LpxLeadershipManager;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.leader.event.OnGrantedEvent;
import org.springframework.integration.leader.event.OnRevokedEvent;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/** LpxLeadershipController provides REST endpoints related to leadership management. */
@RestController
@Slf4j
@RequestMapping(value = "/leader")
public class LpxLeadershipController {

  public static final String UNKNOWN_HOST = "UNKNOWN_HOST";
  private final String hostName;
  private final LpxLeadershipManager lpxLeadershipManager;

  @Value("${spring.cloud.kubernetes.leader.role}")
  private String role;

  /**
   * Constructs an instance of LpxLeadershipController.
   *
   * @param lpxLeadershipManager The leadership manager.
   */
  public LpxLeadershipController(LpxLeadershipManager lpxLeadershipManager) {
    this.lpxLeadershipManager = lpxLeadershipManager;
    var resolvedHostName = UNKNOWN_HOST;
    try {
      resolvedHostName = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      log.warn("Unable to retrieve the host name. Using default value '{}'.", UNKNOWN_HOST, e);
    }
    this.hostName = resolvedHostName;
  }

  /**
   * Retrieves the leadership status for the current host.
   *
   * @return the leadership status.
   */
  @GetMapping
  public Mono<ResponseEntity<String>> getLeadershipStatus() {
    var optionalLeadershipContext =
        Optional.ofNullable(lpxLeadershipManager.getLpxLeadershipContext());
    var response =
        optionalLeadershipContext
            .map(
                ctx -> {
                  log.info(
                      "Checked leadership status for host '{}': Is the leader for role '{}'.",
                      hostName,
                      role);
                  return ResponseEntity.ok()
                      .body(String.format("Host '%s' is the leader for '%s'.", hostName, role));
                })
            .orElseGet(
                () -> {
                  log.warn(
                      "Checked leadership status for host '{}': Not the leader for role '{}'.",
                      hostName,
                      role);
                  return ResponseEntity.ok()
                      .body(String.format("Host '%s' is not the leader for '%s'.", hostName, role));
                });
    return Mono.just(response);
  }

  /**
   * Relinquishes the leadership for the current host.
   *
   * @return the relinquish leadership response.
   */
  @PutMapping
  public Mono<ResponseEntity<String>> relinquishLeadership() {
    var optionalLeadershipContext =
        Optional.ofNullable(lpxLeadershipManager.getLpxLeadershipContext());
    var response =
        optionalLeadershipContext
            .map(
                ctx -> {
                  ctx.yield();
                  log.info("Leadership for host '{}' has been relinquished.", hostName);
                  return ResponseEntity.ok(
                      String.format("Leadership for '%s' has been relinquished.", hostName));
                })
            .orElseGet(
                () -> {
                  log.warn(
                      "Attempt to relinquish leadership when the host '{}' is not a leader.",
                      hostName);
                  return ResponseEntity.badRequest()
                      .body(
                          String.format(
                              "Host '%s' is not a leader. Can't relinquish leadership.", hostName));
                });
    return Mono.just(response);
  }

  /**
   * Handles the event when leadership is granted.
   *
   * @param event The leadership granted event.
   */
  @EventListener
  public synchronized void handleLeadershipGranted(OnGrantedEvent event) {
    log.info("Leadership granted for role '{}' on host '{}'.", event.getRole(), hostName);
    lpxLeadershipManager.setLpxLeadershipContext(event.getContext());
  }

  /**
   * Handles the event when leadership is revoked.
   *
   * @param event The leadership revoked event.
   */
  @EventListener
  public synchronized void handleLeadershipRevoked(OnRevokedEvent event) {
    log.info("Leadership for role '{}' has been revoked on host '{}'.", event.getRole(), hostName);
    lpxLeadershipManager.setLpxLeadershipContext(null);
  }
}
