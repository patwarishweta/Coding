package com.cwan.privatefund.calculated.model;

import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.pbor.trans.Constants.TransactionBasisAffects;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
@EqualsAndHashCode
public class BalanceSchedule {

  private final Map<BalanceTypeKey, NavigableMap<LocalDate, Double>> scheduleByType;

  public BalanceSchedule() {
    this.scheduleByType = new HashMap<>();
  }

  /**
   * Adds a single new balance (final value) anywhere in the balance schedule. Does NOT affect later
   * entries.
   *
   * @param balanceType
   * @param date
   * @param amount
   */
  public void addNewBalance(
      BalanceType balanceType, LocalDate date, Double amount, String basisAffect) {
    scheduleByType
        .computeIfAbsent(new BalanceTypeKey(balanceType, basisAffect), val -> new TreeMap<>())
        .put(date, amount);
  }

  /**
   * Adds a collection of activities (deltas) anywhere in the balance schedule and updates all later
   * entries to reflect the new activities.
   *
   * @param balanceAffects
   */
  public void addNewActivities(List<BalanceAffect> balanceAffects, String basisAffect) {
    balanceAffects.sort(Comparator.comparing(BalanceAffect::getDate));
    balanceAffects.forEach(ba -> addNewActivity(ba, basisAffect));
  }

  /**
   * Adds a single activity (delta) anywhere in the balance schedule and updates all later entries
   * to reflect the new activity.
   *
   * @param balanceAffect
   */
  public void addNewActivity(BalanceAffect balanceAffect, String basisAffect) {
    NavigableMap<LocalDate, Double> schedule =
        scheduleByType.computeIfAbsent(
            new BalanceTypeKey(balanceAffect.getBalanceType(), basisAffect),
            key -> new TreeMap<>());
    // Ensure an entry for the balance affect date exists
    schedule.computeIfAbsent(
        balanceAffect.getDate(),
        key -> {
          Map.Entry<LocalDate, Double> lastGoodBalance = schedule.floorEntry(key);
          double newBalance = 0.0;
          if (lastGoodBalance != null) {
            newBalance = lastGoodBalance.getValue();
          }
          return newBalance;
        });

    if (balanceAffect.getAmount() != 0.0) {
      // Get all entries that are affected by inserting activities into the middle of the balance
      // schedule
      NavigableMap<LocalDate, Double> affectedEntries =
          schedule.tailMap(balanceAffect.getDate(), true);
      Map<LocalDate, Double> updatedSchedule =
          new HashMap<>((int) (affectedEntries.size() / 0.75) + 1);
      affectedEntries
          .entrySet()
          .forEach(
              entry ->
                  updatedSchedule.put(
                      entry.getKey(), entry.getValue() + balanceAffect.getAmount()));
      schedule.putAll(updatedSchedule);
    }
  }

  public double getBasisSpecificValue(BalanceType balanceType, String basis, LocalDate date) {
    var dateToValue =
        scheduleByType.get(
            new BalanceTypeKey(balanceType, basis == null ? TransactionBasisAffects.ALL : basis));
    if (dateToValue == null) {
      return 0.0;
    }
    var value = dateToValue.floorEntry(date).getValue();
    return value == null ? 0.0 : value;
  }

  public double getValue(BalanceType balanceType, LocalDate date) {
    return getBasisSpecificValue(balanceType, TransactionBasisAffects.ALL, date);
  }

  public BalanceSchedule createReducedSchedule(Set<BalanceType> balancesTypeToKeep) {
    BalanceSchedule reducedSchedule = new BalanceSchedule();
    scheduleByType.forEach(
        (balanceTypeKey, schedule) -> {
          BalanceType balanceType = balanceTypeKey.getBalanceType();
          if (balancesTypeToKeep.contains(balanceType)) {
            schedule.forEach(
                (key, value) ->
                    reducedSchedule.addNewBalance(
                        balanceType, key, value, balanceTypeKey.getBasisAffect()));
          }
        });
    return reducedSchedule;
  }

  public BalanceSchedule merge(BalanceSchedule other) {
    this.scheduleByType.putAll(other.scheduleByType);
    return this;
  }
}
