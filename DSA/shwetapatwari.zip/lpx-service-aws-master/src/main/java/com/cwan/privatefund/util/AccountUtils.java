package com.cwan.privatefund.util;

import com.cwan.lpx.domain.Account;
import com.cwan.privatefund.account.ClientAccounts;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public final class AccountUtils {

  /** Gathers clientId and ultimateParentId from each BusinessAccount in the provided map. */
  public static Set<Long> gatherClientIds(Map<Long, BusinessAccount> businessAccountMap) {
    return businessAccountMap.values().parallelStream()
        .filter(Objects::nonNull)
        .flatMap(ba -> gatherClientIdsFromBusinessAccount(ba).stream())
        .collect(Collectors.toSet());
  }

  /** Extracts clientId and ultimateParentId from a single BusinessAccount, if present. */
  public static List<Long> gatherClientIdsFromBusinessAccount(BusinessAccount businessAccount) {
    List<Long> ids = new ArrayList<>();
    Optional.ofNullable(businessAccount.getClientId()).ifPresent(ids::add);
    Optional.ofNullable(businessAccount.getUltimateParentId()).ifPresent(ids::add);
    return ids;
  }

  /**
   * Groups accounts by their clientId and creates ClientAccounts objects containing: - The clientId
   * as the key - The client details from the first account in each group - The list of all accounts
   * belonging to that client Filters out accounts with null clientId or client information.
   */
  public static List<ClientAccounts> groupByClientId(List<Account> accounts) {
    Map<Long, List<Account>> accountsByClientId =
        accounts.stream()
            .filter(account -> account.getClientId() != null)
            .filter(account -> account.getClient() != null)
            .collect(Collectors.groupingBy(Account::getClientId));
    return accountsByClientId.entrySet().stream()
        .map(
            entry ->
                new ClientAccounts(
                    entry.getKey(), entry.getValue().get(0).getClient(), entry.getValue()))
        .toList();
  }

  private AccountUtils() {
    // Adding a private constructor to hide the implicit public one.
  }
}
