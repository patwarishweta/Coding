package com.cwan.privatefund.capital.call.controller;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.privatefund.capital.call.model.ComprehensiveAuditDetail;
import com.cwan.privatefund.capital.call.service.LpxCapitalCallService;
import com.cwan.privatefund.util.ExceptionUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.util.Collections;
import java.util.NoSuchElementException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Controller class for capital call operations. This class exposes HTTP endpoints for fetching
 * capital calls, updating capital call status, and retrieving capital call audit logs.
 */
@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping(value = "v1/capital-call")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "Bad Request"),
      @ApiResponse(responseCode = "401", description = "Unauthorized"),
      @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
public class CapitalCallController {

  private final LpxCapitalCallService lpxCapitalCallService;

  /**
   * Retrieves capital calls associated with a specific user.
   *
   * @param ultimateParentClientId the optional Ultimate Parent Client ID
   * @return a Flux stream of CapitalCallDocument objects
   */
  @GetMapping
  @Operation(summary = "Retrieve capital calls for a specific user")
  @ApiResponse(responseCode = "200", description = "Retrieved capital calls successfully")
  public Flux<CapitalCallDocument> getCapitalCallsByAccounts(
      @RequestParam(required = false) Integer ultimateParentClientId) {
    log.info(
        "Initiating request to fetch capital calls for user with optional ultimateParentClientId: {}",
        ultimateParentClientId);
    return lpxCapitalCallService
        .fetchAllCapitalCallsByAccounts(ultimateParentClientId)
        .doOnError(
            error ->
                log.error(
                    "Error while fetching capital calls: {}",
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Retrieves capital calls associated with a specific user based on a date range.
   *
   * @param filterType the type of date filter to apply.
   * @param startDate the beginning of the date range.
   * @param endDate the end of the date range.
   * @param ultimateParentClientId the optional Ultimate Parent Client ID
   * @return a Flux stream of CapitalCallDocument objects
   */
  @GetMapping("/by-date-range")
  @Operation(summary = "Retrieve capital calls for a specific user based on the date range")
  @ApiResponse(responseCode = "200", description = "Retrieved capital calls successfully")
  public Flux<CapitalCallDocument> getCapitalCallsByDateRange(
      @RequestParam @Parameter(description = "Date Filter Type")
          CapitalCallDateFilterType filterType,
      @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
      @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam(required = false) Integer ultimateParentClientId) {
    log.info("Fetching capital calls from {} to {} with filter {}", startDate, endDate, filterType);
    return lpxCapitalCallService
        .fetchCapitalCallsWithinDateRange(filterType, startDate, endDate, ultimateParentClientId)
        .doOnError(
            error ->
                log.error(
                    "Error while fetching capital calls between {} and {}. Error: {}",
                    startDate,
                    endDate,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Retrieves detailed audit information for a specific date range.
   *
   * @param filterType the type of date filter to apply.
   * @param startDate the beginning of the date range.
   * @param endDate the end of the date range.
   * @param ultimateParentClientId the optional Ultimate Parent Client ID
   * @return a Flux stream of ComprehensiveAuditDetail objects
   */
  @GetMapping("/comprehensive-audit")
  @Operation(summary = "Retrieve comprehensive audit details for a specific date range")
  @ApiResponse(responseCode = "200", description = "Retrieved audit details successfully")
  public Flux<ComprehensiveAuditDetail> getComprehensiveAuditDetails(
      @RequestParam @Parameter(description = "Date Filter Type")
          CapitalCallDateFilterType filterType,
      @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
      @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam(required = false) Integer ultimateParentClientId) {
    log.info(
        "Fetching comprehensive audit details from {} to {} with filter {}",
        startDate,
        endDate,
        filterType);
    return lpxCapitalCallService
        .fetchDetailedAuditForCapitalCalls(filterType, startDate, endDate, ultimateParentClientId)
        .doOnError(
            error ->
                log.error(
                    "Error while fetching comprehensive audit details between {} and {}. Error: {}",
                    startDate,
                    endDate,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Retrieves payment initiation details for a given document ID, returned in XML format.
   *
   * @param documentId Document ID for which to fetch payment initiation details
   * @return Mono of ResponseEntity with XML-formatted payment initiation details. Returns 200 OK on
   *     success, 400 Bad Request on invalid parameters, or 500 Internal Server Error on failure
   */
  @GetMapping(value = "/payment-initiation", produces = MediaType.APPLICATION_XML_VALUE)
  @Operation(summary = "Retrieve payment initiation details")
  @ApiResponse(
      responseCode = "200",
      description = "Retrieved payment initiation details successfully")
  public Mono<ResponseEntity<String>> getPaymentInitiation(
      @RequestParam @Parameter(description = "Document ID") Long documentId) {
    log.info("Fetching payment initiation details for document ID: {}", documentId);
    return lpxCapitalCallService
        .processPaymentInitiation(documentId)
        .map(ResponseEntity::ok)
        .doOnError(
            error ->
                log.error(
                    "Error while fetching payment initiation details for document ID {}. Error: {}",
                    documentId,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Endpoint to update the status of a capital call.
   *
   * @param documentId the ID of the capital call document to update
   * @param currentStatus the current status of the capital call
   * @param action the action to perform on the capital call
   * @param comment a comment to be added to the capital call
   * @return a Mono with the updated capital call
   */
  @PostMapping
  @Operation(summary = "Update the status of a capital call")
  @ApiResponse(responseCode = "200", description = "Updated capital call status successfully")
  public Mono<CapitalCallDocument> updateCapitalCallStatus(
      @RequestParam @Parameter(description = "Document ID") Long documentId,
      @RequestParam @Parameter(description = "Current status of the capital call")
          CapitalCallStatus currentStatus,
      @RequestParam @Parameter(description = "Action to be performed on the capital call")
          CapitalCallAction action,
      @RequestParam @Parameter(description = "Comment to be added on capital call")
          String comment) {
    log.info("Updating status for document with id: {}", documentId);
    return lpxCapitalCallService
        .updateCapitalCallStatus(documentId, currentStatus, action, comment)
        .doOnError(
            error ->
                log.error(
                    "Error occurred while updating capital call status for document id: {}. Error is: {}",
                    documentId,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Endpoint to retrieve the capital call audit for a specific document.
   *
   * @param documentId the ID of the document to retrieve the audit log for
   * @return a Mono with the audit log for the capital call of the document
   */
  @GetMapping("/audit/{documentId}")
  @Operation(summary = "Retrieve the capital call audit log for a specific document")
  @ApiResponse(responseCode = "200", description = "Retrieved capital call audit log successfully")
  public Mono<CapitalCallAuditLog> getCapitalCallAuditByDocument(
      @PathVariable @Parameter(description = "Document ID") Long documentId) {
    log.info("Fetching capital call audit log for document with id: {}", documentId);
    return lpxCapitalCallService
        .getCapitalCallAuditByDocument(documentId)
        .switchIfEmpty(Mono.error(new NoSuchElementException("Document Not Found")))
        .doOnError(
            error ->
                log.error(
                    "Error occurred while fetching capital call audit log for document id: {}. Error is: {}",
                    documentId,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Endpoint to retrieve the capital calls for a specific status.
   *
   * @param status the status of the capital calls to retrieve
   * @return a Flux stream with the capital calls of the given status
   */
  @GetMapping("/status/{status}")
  @Operation(
      tags = {"DevOnly"},
      summary = "[DEV ONLY] Retrieve capital calls for a specific status")
  @ApiResponse(responseCode = "200", description = "Retrieved capital calls successfully")
  public Flux<CapitalCallDocument> getCapitalCallsByStatus(
      @PathVariable @Parameter(description = "Capital call status") CapitalCallStatus status) {
    log.info("Fetching capital calls for status: {}", status);
    return lpxCapitalCallService
        .getCapitalCallsByStatuses(Collections.singleton(status))
        .doOnError(
            error ->
                log.error(
                    "Error occurred while fetching capital calls for status: {}. Error is: {}",
                    status,
                    ExceptionUtils.getStackTraceAsString(error)));
  }
}
