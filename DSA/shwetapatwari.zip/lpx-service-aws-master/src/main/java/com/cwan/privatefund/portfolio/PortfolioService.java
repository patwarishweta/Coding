package com.cwan.privatefund.portfolio;

import static java.util.stream.Collectors.toList;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Performance;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.performance.api.Performances;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.auth.accesscontrolfiltering.AccessControlFilteringService;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.portfolio.model.AggregatePortfolioData;
import com.cwan.privatefund.portfolio.model.CalculationTask;
import com.cwan.privatefund.portfolio.model.PortfolioData;
import com.cwan.privatefund.portfolio.model.PortfolioData.Ranges;
import com.cwan.privatefund.portfolio.model.PortfolioSummaryResponse;
import com.cwan.privatefund.portfolio.model.SecurityAccountPair;
import com.cwan.privatefund.publisher.MessagePublisher;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.google.common.collect.Lists;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.jetbrains.annotations.VisibleForTesting;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.ParallelFlux;
import reactor.core.scheduler.Schedulers;

@Service
@Slf4j
public class PortfolioService {

  private final Documents documents;
  private final Performances performances;
  private final PortfolioBalanceTransformer portfolioBalanceTransformer;
  private final AccountService accountService;
  private final SecurityService securityService;
  private final PortfolioWsClient portfolioWsClient;
  private final MessagePublisher<CalculationTask> performanceMessagePublisher;
  private final LpxTransactionService lpxTransactionService;
  private final SecurityContextService securityContextService;
  private final SecurityContextUserService securityContextUserService;
  private final LpxFundMasterService lpxFundMasterService;
  private final PortfolioWsApacheClient portfolioWsApacheClient;
  private final AccessControlFilteringService accessControlFilteringService;
  private static final double MAXIMUM_IRR = 5.0;

  public PortfolioService(
      Documents documents,
      Performances performances,
      PortfolioBalanceTransformer portfolioBalanceTransformer,
      AccountService accountService,
      SecurityService securityService,
      PortfolioWsClient portfolioWsClient,
      MessagePublisher<CalculationTask> performanceMessagePublisher,
      LpxTransactionService lpxTransactionService,
      SecurityContextService securityContextService,
      SecurityContextUserService securityContextUserService,
      LpxFundMasterService lpxFundMasterService,
      PortfolioWsApacheClient portfolioWsApacheClient,
      AccessControlFilteringService accessControlFilteringService) {
    this.documents = documents;
    this.performances = performances;
    this.portfolioBalanceTransformer = portfolioBalanceTransformer;
    this.accountService = accountService;
    this.securityService = securityService;
    this.portfolioWsClient = portfolioWsClient;
    this.performanceMessagePublisher = performanceMessagePublisher;
    this.lpxTransactionService = lpxTransactionService;
    this.securityContextService = securityContextService;
    this.securityContextUserService = securityContextUserService;
    this.lpxFundMasterService = lpxFundMasterService;
    this.portfolioWsApacheClient = portfolioWsApacheClient;
    this.accessControlFilteringService = accessControlFilteringService;
  }

  public Mono<List<Long>> checkUserAccess(Set<Long> accountIds) {
    return securityContextUserService
        .validateAndGetUserId()
        .flatMap(
            userId ->
                accessControlFilteringService.checkAccountsAccessForUserid(userId, accountIds));
  }

  public Mono<PortfolioSummaryResponse> getPortfolioBalances(
      Set<Long> accountIds, LocalDate calculationDate) {
    return Flux.fromIterable(accountIds)
        .flatMap(accountService::expandAccountIdMap)
        .map(Map::entrySet)
        .flatMapIterable(Function.identity())
        .flatMap(
            expandedAccountMapEntry ->
                checkUserAccess(Set.copyOf(expandedAccountMapEntry.getValue()))
                    .map(longs -> Map.entry(expandedAccountMapEntry.getKey(), longs))
                    .onErrorResume(e -> Mono.just(expandedAccountMapEntry)))
        .flatMap(
            expandedAccountMapEntry -> {
              if (expandedAccountMapEntry.getValue().isEmpty()) {
                return raiseAccessDenied(accountIds);
              }
              if (expandedAccountMapEntry.getValue().size() > 1) {
                return partitionAndProcessAccounts(
                    expandedAccountMapEntry.getKey(),
                    Set.copyOf(expandedAccountMapEntry.getValue()),
                    calculationDate);
              }
              return partitionAndProcessAccounts(
                  null, Set.copyOf(expandedAccountMapEntry.getValue()), calculationDate);
            })
        .map(PortfolioService::irrValidityCheck)
        .reduce((portfolioSummaryResponse, portfolioSummaryResponse2) -> portfolioSummaryResponse);
  }

  // IRR cannot be above MAXIMUM_IRR, if it is, than we shouldn't report it to the
  // client as that
  // means
  // there is not ample data for it to be calculated.
  protected static PortfolioSummaryResponse irrValidityCheck(
      PortfolioSummaryResponse portfolioSummary) {
    List<PortfolioBalance> data = portfolioSummary.getData();
    for (PortfolioBalance balance : data) {
      Performance performance = balance.getPerformance();
      if ((performance != null)
          && (performance.getNetXirr() != null)
          && (performance.getNetXirr() > MAXIMUM_IRR)) {
        performance.setNetXirr(null);
      }
    }
    return portfolioSummary;
  }

  public Mono<PortfolioSummaryResponse> partitionAndProcessAccounts(
      Long aggAccountId, Set<Long> accountIds, LocalDate calculationDate) {
    log.info("partitionAndProcessAccounts accountIds: {}", accountIds);
    return Flux.just(accountIds)
        .flatMapIterable(accountIdsSet -> Lists.partition(List.copyOf(accountIdsSet), 200))
        .collectList()
        .flatMapIterable(Function.identity())
        .publishOn(Schedulers.parallel())
        .flatMap(
            accountIdsList -> enrichPortfolioBalances(Set.copyOf(accountIdsList), calculationDate),
            2)
        .collectList()
        .flatMap(
            portfolioBalanceList -> {
              if (aggAccountId != null) {
                PortfolioBalance aggPortfolioBalanceRequest =
                    PortfolioBalance.builder()
                        .account(Account.builder().id(aggAccountId).build())
                        .security(Security.builder().securityId(-2L).build())
                        .build();
                return fetchAggregatePortfolioBalance(aggPortfolioBalanceRequest, calculationDate)
                    .map(
                        aggPortfolioBalance -> {
                          if (aggPortfolioBalance.getAccount() == null) {
                            log.info(
                                "Completed portfolio processing without aggregate data, Performance not found :{}-{} TotalEntries-{}",
                                aggAccountId,
                                calculationDate,
                                portfolioBalanceList.size());
                            return PortfolioSummaryResponse.builder()
                                .data(portfolioBalanceList)
                                .build();
                          } else {
                            log.info(
                                "Completed portfolio processing with aggregate data:{}-{}",
                                aggAccountId,
                                calculationDate);
                            return PortfolioSummaryResponse.builder()
                                .data(portfolioBalanceList)
                                .agg(
                                    AggregatePortfolioData.builder()
                                        .irr(aggPortfolioBalance.getPerformance().getNetXirr())
                                        .pme(aggPortfolioBalance.getPerformance().getPme())
                                        .rvpi(aggPortfolioBalance.getPerformance().getRvpi())
                                        .dpi(aggPortfolioBalance.getPerformance().getDpi())
                                        .tvpi(aggPortfolioBalance.getPerformance().getTvpi())
                                        .build())
                                .build();
                          }
                        });
              }
              Set<Long> uniqueSecurityIds =
                  portfolioBalanceList.stream()
                      .map(portfolioBalance -> portfolioBalance.getSecurity().getSecurityId())
                      .collect(Collectors.toSet());
              if (uniqueSecurityIds.size() > 1) {
                PortfolioBalance aggPortfolioBalanceRequest =
                    PortfolioBalance.builder()
                        .account(Account.builder().id(accountIds.iterator().next()).build())
                        .security(Security.builder().securityId(-3L).build())
                        .build();
                return fetchAggregatePortfolioBalance(aggPortfolioBalanceRequest, calculationDate)
                    .map(
                        aggPortfolioBalance -> {
                          if (aggPortfolioBalance.getAccount() == null) {
                            log.info(
                                "Completed portfolio processing without aggregate data, Performance not found :{} TotalEntries-{}",
                                calculationDate,
                                portfolioBalanceList.size());
                            return PortfolioSummaryResponse.builder()
                                .data(portfolioBalanceList)
                                .build();
                          } else {
                            log.info(
                                "Completed portfolio processing with aggregate data:{}",
                                calculationDate);
                            return PortfolioSummaryResponse.builder()
                                .data(portfolioBalanceList)
                                .agg(
                                    AggregatePortfolioData.builder()
                                        .irr(aggPortfolioBalance.getPerformance().getNetXirr())
                                        .pme(aggPortfolioBalance.getPerformance().getPme())
                                        .rvpi(aggPortfolioBalance.getPerformance().getRvpi())
                                        .dpi(aggPortfolioBalance.getPerformance().getDpi())
                                        .tvpi(aggPortfolioBalance.getPerformance().getTvpi())
                                        .build())
                                .build();
                          }
                        });
              } else {
                log.info(
                    "Completed portfolio processing without aggregate data:{} TotalEntries-{}",
                    calculationDate,
                    portfolioBalanceList.size());
                return Mono.just(
                    PortfolioSummaryResponse.builder().data(portfolioBalanceList).build());
              }
            });
  }

  private Mono<PortfolioBalance> fetchAggregatePortfolioBalance(
      PortfolioBalance aggPortfolioBalanceRequest, LocalDate calculationDate) {
    return hydratePerformance(aggPortfolioBalanceRequest, calculationDate)
        .defaultIfEmpty(PortfolioBalance.builder().build());
  }

  public ParallelFlux<PortfolioBalance> enrichPortfolioBalances(
      Set<Long> accountIds, LocalDate calculationDate) {
    log.info(
        "Enrich Portfolio Balances with Document and Performance Data for accountIds: {}",
        accountIds);
    return this.fetchAccountSecurityPairsWithCacheCheck(accountIds, calculationDate, true)
        .map(portfolioBalanceTransformer)
        .log("PortfolioBalance transformer successful")
        .collectMultimap(
            portfolioBalance -> portfolioBalance.getAccount().getId(), Function.identity())
        .flatMapIterable(Map::entrySet)
        .flatMap(this::setDocumentsDates, 1024)
        .publishOn(Schedulers.boundedElastic())
        .log("Stamped dates")
        .parallel()
        .runOn(Schedulers.parallel())
        .flatMap(
            portfolioBalance ->
                hydratePerformance(portfolioBalance, calculationDate)
                    .flatMap(this::hydrateFundMaster));
  }

  public Mono<SecurityAccountPair> createSecurityAccountPair(PortfolioData portfolioData) {
    var accountMono = accountService.getAccountData(portfolioData.getAccountId());
    var securityMono =
        securityService.getSecurity(
            null, portfolioData.getAccountId(), portfolioData.getSecurityId());
    return Mono.zip(accountMono, securityMono)
        .map(
            objects ->
                SecurityAccountPair.builder()
                    .account(objects.getT1())
                    .security(objects.getT2())
                    .build());
  }

  private Mono<PortfolioBalance> hydratePerformance(
      PortfolioBalance portfolioBalance, LocalDate calculationDate) {
    log.info(
        "Performance {} {}",
        portfolioBalance.getAccount().getId(),
        portfolioBalance.getSecurity().getSecurityId());
    return performances
        .getPerformanceByAccountIdSecurityIdFreqAndCalculationDateOrderByModifiedOnDesc(
            portfolioBalance.getAccount().getId(),
            portfolioBalance.getSecurity().getSecurityId(),
            "ITD",
            calculationDate.atStartOfDay())
        .filter(Objects::nonNull)
        .log()
        .map(
            performance -> {
              portfolioBalance.setPerformance(performance);
              return portfolioBalance;
            });
  }

  private Mono<PortfolioBalance> hydrateFundMaster(PortfolioBalance portfolioBalance) {
    log.info(
        "Hydrate fundmaster for PortFolio accId {} secId {} performanceId {}",
        portfolioBalance.getAccount().getId(),
        portfolioBalance.getSecurity().getSecurityId(),
        portfolioBalance.getPerformance().getId());
    FundMasterEntity fundMasterEntity =
        lpxFundMasterService
            .getFundMasterEntitiesWithOverridesBySecurities(
                portfolioBalance.getAccount().getClientId(),
                null,
                Set.of(portfolioBalance.getSecurity().getSecurityId()))
            .get(portfolioBalance.getSecurity().getSecurityId());
    if (fundMasterEntity != null) {
      portfolioBalance.setFundMaster(fundMasterEntity);
    }
    return Mono.just(portfolioBalance);
  }

  private Flux<PortfolioBalance> setDocumentsDates(
      Map.Entry<Long, Collection<PortfolioBalance>> portfolioBalancesByAccountId) {
    log.info(
        "Set Document Dates for accountId: {} and securityIds size: {}",
        portfolioBalancesByAccountId.getKey(),
        portfolioBalancesByAccountId.getValue().size());
    return documents
        .getDocumentsByAccountId(Set.of(portfolioBalancesByAccountId.getKey()))
        .filter(document -> document.getDocumentDate() != null)
        .collectMultimap(Document::getType, Function.identity())
        .map(
            docMap ->
                docMap.entrySet().stream()
                    .collect(
                        Collectors.toMap(
                            Map.Entry::getKey,
                            entry ->
                                entry.getValue().stream()
                                    .sorted(
                                        Comparator.comparing(Document::getDocumentDate).reversed())
                                    .toList())))
        .map(
            docMap -> {
              var callNoticeDoc = docMap.get("Capital Call Notice");
              var distributionNoticeDoc = docMap.get("Capital Distribution Notice");
              var capitalAccountDoc = docMap.get("Capital Account Statement");
              Map<Long, List<Document>> capCallNoticeBySecId =
                  getLatestDocumentListBySecurityId(callNoticeDoc);
              Map<Long, List<Document>> capDistNoticeBySecId =
                  getLatestDocumentListBySecurityId(distributionNoticeDoc);
              Map<Long, List<Document>> accStmtNoticeBySecId =
                  getLatestDocumentListBySecurityId(capitalAccountDoc);
              log.info(
                  "capCallNoticeBySecId:{} \ncapDistNoticeBySecId:{} \naccStmtNoticeBySecId:{}",
                  capCallNoticeBySecId,
                  capDistNoticeBySecId,
                  accStmtNoticeBySecId);
              return Flux.fromIterable(portfolioBalancesByAccountId.getValue())
                  .flatMap(
                      portfolioBalance -> {
                        portfolioBalance.setCallNoticeDate(
                            (capCallNoticeBySecId.containsKey(
                                        portfolioBalance.getSecurity().getSecurityId())
                                    && !capCallNoticeBySecId
                                        .get(portfolioBalance.getSecurity().getSecurityId())
                                        .isEmpty())
                                ? capCallNoticeBySecId
                                    .get(portfolioBalance.getSecurity().getSecurityId())
                                    .get(0)
                                    .getDocumentDate()
                                : null);
                        portfolioBalance.setDistributionNoticeDate(
                            (capDistNoticeBySecId.containsKey(
                                        portfolioBalance.getSecurity().getSecurityId())
                                    && !capDistNoticeBySecId
                                        .get(portfolioBalance.getSecurity().getSecurityId())
                                        .isEmpty())
                                ? capDistNoticeBySecId
                                    .get(portfolioBalance.getSecurity().getSecurityId())
                                    .get(0)
                                    .getDocumentDate()
                                : null);
                        portfolioBalance.setAccountStatementDate(
                            (accStmtNoticeBySecId.containsKey(
                                        portfolioBalance.getSecurity().getSecurityId())
                                    && !accStmtNoticeBySecId
                                        .get(portfolioBalance.getSecurity().getSecurityId())
                                        .isEmpty())
                                ? accStmtNoticeBySecId
                                    .get(portfolioBalance.getSecurity().getSecurityId())
                                    .get(0)
                                    .getDocumentDate()
                                : null);
                        return Mono.just(portfolioBalance);
                      });
            })
        .flatMapMany(Function.identity());
  }

  private static Map<Long, List<Document>> getLatestDocumentListBySecurityId(
      List<Document> notice) {
    if (notice == null) {
      return Map.of();
    }
    return notice.stream()
        .collect(
            Collectors.groupingBy(
                document -> document.getSecurity().getSecurityId(),
                Collectors.mapping(
                    Function.identity(),
                    Collectors.collectingAndThen(
                        toList(),
                        e ->
                            e.stream()
                                .sorted(Comparator.comparing(Document::getDocumentDate).reversed())
                                .collect(toList())))));
  }

  public void submitAmortCalculationTask(Long accountId, Long securityId) {
    val calculationTask =
        CalculationTask.builder()
            .accountId(accountId)
            .securityId(securityId)
            .asOfDate(LocalDate.now())
            .frequency(List.of("MTD"))
            .calculationTypes(List.of("AMORT"))
            .build();
    performanceMessagePublisher.publishMessage(
        calculationTask,
        Map.of(
            "messageGroupId",
            accountId.toString(),
            "generateActivity",
            "false",
            "messageDeduplicationId",
            String.valueOf(System.nanoTime())),
        true);
  }

  public void refreshPerformance(
      List<Long> accountIds, LocalDate calculationDate, String frequency) {
    Flux.fromIterable(accountIds)
        .subscribe(
            accountId -> {
              val calculationTask =
                  CalculationTask.builder()
                      .accountId(accountId)
                      .asOfDate(calculationDate)
                      .frequency(List.of(frequency))
                      .calculationTypes(List.of("XIRR", "MULTIPLE", "PME"))
                      .build();
              performanceMessagePublisher.publishMessage(
                  calculationTask,
                  Map.of(
                      "messageGroupId",
                      accountId.toString(),
                      "generateActivity",
                      "false",
                      "messageDeduplicationId",
                      String.valueOf(System.nanoTime())),
                  true);
            });
  }

  public void reloadPerformanceTillCurrentDate() {
    lpxTransactionService
        .getAllAccountsAndMinimumSettleDateTransactionModifiedToday()
        .filter(entry -> !(entry.getValue().getSettleDate().isAfter(LocalDate.now())))
        .delayElements(Duration.ofSeconds(2))
        .map(
            entry -> {
              String[] accountSecurity = entry.getKey().split(":");
              LocalDate minModifiedSettleDate = entry.getValue().getSettleDate();
              log.info(
                  "reloadPerformanceTillCurrentDate {} -> {}:{}",
                  LocalDate.now(),
                  Arrays.toString(accountSecurity),
                  minModifiedSettleDate);
              return CalculationTask.builder()
                  .accountId(Long.valueOf(accountSecurity[0].trim()))
                  .securityId(Long.valueOf(accountSecurity[1].trim()))
                  .asOfDate(minModifiedSettleDate)
                  .frequency(List.of("ITD"))
                  .calculationTypes(List.of("XIRR", "MULTIPLE", "PME"))
                  .recalculatePerformanceTillCurrentDate(Boolean.TRUE)
                  .build();
            })
        .subscribe(
            calculationTask -> {
              performanceMessagePublisher.publishMessage(
                  calculationTask,
                  Map.of(
                      "messageGroupId",
                      calculationTask.getAccountId().toString(),
                      "generateActivity",
                      "false",
                      "messageDeduplicationId",
                      String.valueOf(System.nanoTime())),
                  true);
            },
            error ->
                log.error(
                    "Error occurred during reloadPerformanceTillCurrentDateScheduler ", error));
  }

  public Flux<Performance> getPerformancesForDates(
      Long accountId, String freq, Collection<LocalDateTime> calculationDates) {
    return this.fetchAccountSecurityPairsWithCacheCheck(
            List.of(accountId),
            calculationDates.stream()
                .max(Comparator.naturalOrder())
                .orElse(LocalDateTime.now())
                .toLocalDate(),
            false)
        .flatMap(
            securityAccountPair ->
                performances.getPerformanceByAccountIdSecurityIdFreqAndCalculationDateIn(
                    securityAccountPair.getAccount().getId(),
                    securityAccountPair.getSecurity().getSecurityId(),
                    freq,
                    calculationDates));
  }

  public Flux<Performance> getEarliestActivePerformancesForAccount(Long accountId, String freq) {
    return this.fetchAccountSecurityPairsWithCacheCheck(List.of(accountId), LocalDate.now(), false)
        .flatMap(
            securityAccountPair ->
                performances.getEarliestActivePerformanceByAccountIdSecurityIdAndFreq(
                    securityAccountPair.getAccount().getId(),
                    securityAccountPair.getSecurity().getSecurityId(),
                    freq));
  }

  private Flux<SecurityAccountPair> fetchAccountSecurityPairsWithCacheCheck(
      Collection<Long> accountIds, LocalDate calculationDate, boolean filterClosedLots) {
    return portfolioWsClient
        .getPortfolioDataWithCacheCheck(accountIds)
        .flatMapIterable(Function.identity())
        .filter(
            portfolioData -> filterOutClosedLots(calculationDate, filterClosedLots, portfolioData))
        .filter(portfolioData -> portfolioData.getSecurityId() != null)
        .flatMap(this::createSecurityAccountPair, 1024)
        .publishOn(Schedulers.parallel());
  }

  @VisibleForTesting
  protected static boolean filterOutClosedLots(
      LocalDate calculationDate, boolean filterClosedLots, PortfolioData portfolioData) {
    if (!filterClosedLots) {
      return true;
    }
    for (Ranges ranges : portfolioData.getRanges()) {
      LocalDateRange range =
          LocalDateRanges.create(
              ranges.getAtLeast(),
              ranges.getLessThan() == null ? LocalDate.MAX : ranges.getLessThan());
      if (range.contains(calculationDate)) {
        return true;
      }
    }
    return false;
  }

  private Mono<Map<Long, Collection<Long>>> getAllSecurityIdsByAccountId(Long accountId) {
    return accountService
        .expandAccountId(accountId)
        .collectList()
        .flatMap(
            expandedAccountIds ->
                portfolioWsClient
                    .getPortfolioDataWithCacheCheck(expandedAccountIds)
                    .flatMapIterable(Function.identity())
                    .filter(portfolioData -> portfolioData.getSecurityId() != null)
                    .collectMultimap(PortfolioData::getAccountId, PortfolioData::getSecurityId));
  }

  public Mono<Map<Long, Collection<Security>>> fetchAllSecuritiesByAccountId(Long accountId) {
    return getAllSecurityIdsByAccountId(accountId)
        .flatMap(
            originalMap ->
                Flux.fromIterable(originalMap.entrySet())
                    .flatMap(
                        entry ->
                            Flux.fromIterable(entry.getValue())
                                .collectList()
                                .flatMap(
                                    securityIds ->
                                        securityService
                                            .getSecurities(
                                                null,
                                                entry.getKey(),
                                                entry.getValue().stream().toList())
                                            .map(
                                                securities ->
                                                    Map.entry(entry.getKey(), securities))))
                    .collectMap(Map.Entry::getKey, Map.Entry::getValue));
  }

  private static Mono<PortfolioSummaryResponse> raiseAccessDenied(Set<Long> accountIds) {
    var errorMsg =
        String.format(
            "Access denied for user on account IDs %s due to insufficient permissions or account access.",
            accountIds);
    log.warn(errorMsg);
    return Mono.error(new ResponseStatusException(HttpStatus.FORBIDDEN, errorMsg));
  }
}
