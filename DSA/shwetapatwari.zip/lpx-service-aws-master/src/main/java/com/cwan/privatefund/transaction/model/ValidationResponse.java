package com.cwan.privatefund.transaction.model;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidationResponse {
  private List<String> response;
}
