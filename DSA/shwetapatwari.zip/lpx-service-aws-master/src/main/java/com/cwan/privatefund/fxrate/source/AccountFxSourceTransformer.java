package com.cwan.privatefund.fxrate.source;

import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class AccountFxSourceTransformer
    implements Function<AccountFxSourceEntity, AccountFxSource> {
  @Override
  public AccountFxSource apply(AccountFxSourceEntity accountFxSourceEntity) {
    return AccountFxSource.builder()
        .accountId(accountFxSourceEntity.getAccountId())
        .basisId(accountFxSourceEntity.getBasisId())
        .date(accountFxSourceEntity.getDate())
        .fxRateSourceId(accountFxSourceEntity.getFxRateSourceId())
        .rankId(accountFxSourceEntity.getRankId())
        .modifiedOn(accountFxSourceEntity.getModifiedOn())
        .build();
  }
}
