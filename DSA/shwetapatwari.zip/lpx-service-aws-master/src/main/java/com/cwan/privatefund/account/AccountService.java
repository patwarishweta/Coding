package com.cwan.privatefund.account;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.basis.ws.BasisWSCache;
import com.cwan.privatefund.basis.ws.model.Basis;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.util.AccountUtils;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.SortedMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
@RequiredArgsConstructor
@Service
public class AccountService {

  private final BusinessWSCache businessWSCache;
  private final AccountTransformer accountTransformer;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final BasisWSCache basisWSCache;

  public Mono<Map<Long, Boolean>> checkUserAccessToAccounts(Integer userId, Set<Long> accountIds) {
    return businessWSCache.getUserAccountAccess(userId, accountIds);
  }

  public Mono<Account> enrichClientInfoOnAccount(Account accountObj, Long ultimateParentClientId) {
    return Mono.zip(
        businessWSCache
            .getClientData(accountObj.getClientId())
            .map(Optional::of)
            .defaultIfEmpty(Optional.empty()),
        businessWSCache
            .getClientData(ultimateParentClientId)
            .map(Optional::of)
            .defaultIfEmpty(Optional.empty()),
        (t1, t2) ->
            accountObj.toBuilder()
                .client(t1.orElse(null))
                .ultimateParentClient(t2.orElse(null))
                .build());
  }

  /**
   * Expands an account ID to retrieve all associated account IDs. This method handles both
   * aggregate and simple account types: - For aggregate accounts: Returns all simple account IDs
   * that belong to the aggregate - For simple accounts: Returns a Flux containing only the input
   * account ID
   *
   * @param accountId The account ID to expand. Can be either an aggregate or simple account ID.
   * @return A Flux of account IDs. For aggregate accounts, contains all constituent simple account
   *     IDs. For simple accounts, contains only the input account ID.
   */
  public Flux<Long> expandAccountId(Long accountId) {
    return businessWSCache.getExpandedAccountIds(accountId).flux().flatMap(Flux::fromIterable);
  }

  /**
   * Retrieves a Mono containing a Map that associates the given account ID with its expanded list
   * of constituent account IDs (if it's an aggregate) or just itself (if it's a simple account).
   *
   * @param accountId The account ID to expand.
   * @return A Mono of Map, where the key is the original account ID and the value is the list of
   *     expanded account IDs.
   */
  public Mono<Map<Long, List<Long>>> expandAccountIdMap(Long accountId) {
    return businessWSCache
        .getExpandedAccountIds(accountId)
        .map(expandedAccounts -> Map.of(accountId, expandedAccounts));
  }

  /**
   * Expands a collection of account IDs to retrieve all associated account IDs from the cache. This
   * method merges the expanded results (e.g., constituent IDs for aggregate accounts) back into the
   * original set of IDs. If the input collection is null or empty, an empty Mono is returned.
   * Similarly, if there are no non-null entries in the input, an empty Mono is returned.
   *
   * @param accountIds A collection of account IDs to expand.
   * @return A Mono emitting a Set of expanded account IDs, including both original and newly added
   *     IDs.
   */
  public Mono<Set<Long>> expandAccountIds(Collection<Long> accountIds) {
    if (CollectionUtils.isEmpty(accountIds)) {
      return Mono.empty();
    }
    Set<Long> cleanAccountIds =
        accountIds.stream().filter(Objects::nonNull).collect(Collectors.toCollection(HashSet::new));
    if (CollectionUtils.isEmpty(cleanAccountIds)) {
      return Mono.empty();
    }
    return businessWSCache
        .getExpandedAccountByIdsFromCache(cleanAccountIds)
        .map(
            expandedAccountsMap -> {
              expandedAccountsMap.values().stream()
                  .flatMap(Collection::stream)
                  .filter(Objects::nonNull)
                  .forEach(cleanAccountIds::add);
              return cleanAccountIds;
            })
        .defaultIfEmpty(cleanAccountIds);
  }

  public Mono<Account> getAccountData(Long accountId) {
    return businessWSCache
        .getAccountData(accountId)
        .flatMap(
            businessAccount ->
                Mono.just(accountTransformer.apply(businessAccount))
                    .map(
                        account ->
                            enrichClientInfoOnAccount(
                                account, businessAccount.getUltimateParentId())))
        .flatMap(Function.identity());
  }

  public Mono<List<Account>> getAccountsData(Collection<Long> accountIds) {
    return businessWSCache
        .getAccountsData(accountIds)
        .flatMap(
            businessAccounts -> {
              Set<Long> clientIds =
                  businessAccounts.parallelStream()
                      .map(BusinessAccount::getClientId)
                      .filter(Objects::nonNull)
                      .collect(Collectors.toSet());
              Set<Long> ultimateParentIds =
                  businessAccounts.parallelStream()
                      .map(BusinessAccount::getUltimateParentId)
                      .filter(Objects::nonNull)
                      .collect(Collectors.toSet());
              return Mono.zip(
                  businessWSCache.getClientDataFromCache(List.copyOf(clientIds)),
                  businessWSCache.getClientDataFromCache(List.copyOf(ultimateParentIds)),
                  (clientidsClientDataMap, ultimateParentIdsClientDataMap) ->
                      businessAccounts.stream()
                          .map(
                              businessAccount -> {
                                var account = accountTransformer.apply(businessAccount);
                                return account.toBuilder()
                                    .client(
                                        businessAccount.getClientId() != null
                                            ? clientidsClientDataMap.getOrDefault(
                                                businessAccount.getClientId(), null)
                                            : null)
                                    .ultimateParentClient(
                                        businessAccount.getUltimateParentId() != null
                                            ? ultimateParentIdsClientDataMap.getOrDefault(
                                                businessAccount.getUltimateParentId(), null)
                                            : null)
                                    .build();
                              })
                          .toList());
            })
        .flatMapIterable(Function.identity())
        .map(this::mergeConfigurationIntoAccount)
        .flatMap(Function.identity())
        .collectList();
  }

  public Mono<Account> getAccountWithClientData(Long accountId) {
    return businessWSCache
        .getAccountData(accountId)
        .flatMap(
            businessAccount ->
                Mono.just(accountTransformer.apply(businessAccount))
                    .map(
                        account ->
                            enrichClientInfoOnAccount(
                                account, businessAccount.getUltimateParentId())))
        .flatMap(Function.identity());
  }

  public Flux<Account> getClientAccounts(Long clientId, Integer userId) {
    return businessWSCache
        .getClientAccountIds(clientId)
        .map(Set::copyOf)
        .flatMap(accountIds -> checkUserAccessToAccounts(userId, accountIds))
        .map(Map::entrySet)
        .map(
            entries ->
                entries.stream()
                    .filter(Map.Entry::getValue)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toSet()))
        .flatMap(businessWSCache::getAccountsData)
        .flatMapIterable(Function.identity())
        .map(accountTransformer)
        .map(this::mergeConfigurationIntoAccount)
        .flatMap(Function.identity());
  }

  public Flux<ClientAccounts> getClientAccountsData(Integer userId) {
    return retrieveUserAccounts(userId)
        .collectList()
        .flatMapMany(accounts -> Flux.fromIterable(AccountUtils.groupByClientId(accounts)));
  }

  public Map<Long, SortedMap<Integer, Long>> getClientHierarchyForClients(Set<Long> clientIds) {
    return businessWSCache
        .ultimateParentCacheByClientId(clientIds)
        .subscribeOn(Schedulers.boundedElastic())
        .toFuture()
        .join();
  }

  public Flux<Basis> getEnabledBases(Long accountId, Integer userId) {
    return checkUserAccessToAccounts(userId, Set.of(accountId))
        .filter(map -> Boolean.TRUE.equals(map.get(accountId)))
        .map(Map::keySet)
        .flatMapIterable(Function.identity())
        .flatMapIterable(basisWSCache::getEnabledBases);
  }

  /**
   * Retrieves a Mono of Map where each key is an ultimate parent ID and each value is a set of the
   * user’s account IDs associated with that parent.
   *
   * @param userId The user ID to fetch the map for.
   * @return A Mono of Map<Integer, Set<Long>> mapping parent IDs to account IDs.
   */
  public Mono<Map<Integer, Set<Long>>> retrieveAccountMapByUltimateParent(Integer userId) {
    return retrieveFilteredUserAccounts(userId)
        .collectMultimap(account -> account.getUltimateParentClient().getParentId(), Account::getId)
        .map(
            multimap ->
                multimap.entrySet().stream()
                    .collect(
                        Collectors.toMap(Map.Entry::getKey, e -> new HashSet<>(e.getValue()))));
  }

  /**
   * Groups and returns user accounts by their ultimate parent client, as a Flux of
   * UltimateParentsAccountMap objects.
   *
   * @param userId The user ID whose accounts are grouped by ultimate parent.
   * @return A Flux of UltimateParentsAccountMap objects, each containing a parent ID and the list
   *     of associated accounts.
   */
  public Flux<UltimateParentsAccountMap> retrieveAccountsGroupedByUltimateParent(Integer userId) {
    return retrieveFilteredUserAccounts(userId)
        .groupBy(account -> account.getUltimateParentClient().getParentId())
        .flatMap(
            group ->
                group
                    .collectList()
                    .map(
                        accounts ->
                            UltimateParentsAccountMap.builder()
                                .ultimateParentId(group.key())
                                .accounts(accounts)
                                .build()));
  }

  /**
   * Retrieves a Flux of UltimateParents objects for the given user ID by filtering and mapping the
   * user's accessible account configurations.
   *
   * @param userId The user ID to fetch ultimate parents for.
   * @return A Flux of UltimateParents objects.
   */
  public Flux<UltimateParents> retrieveUltimateParents(Integer userId) {
    return retrieveUserAccessibleAccountIds(userId)
        .flatMap(
            accountIds ->
                accountConfigServiceCache
                    .getAllAccountConfigs()
                    .map(
                        accountConfigs ->
                            accountConfigs.stream()
                                .filter(ac -> accountIds.contains(ac.getAccount().getId()))
                                .map(
                                    ac ->
                                        UltimateParents.builder()
                                            .ultimateParentId(ac.getUltimateParentId())
                                            .ultimateParentName(ac.getUltimateParentName())
                                            .build())
                                .collect(Collectors.toSet())))
        .flatMapMany(Flux::fromIterable);
  }

  /**
   * Retrieves all account IDs that the specified user has access to by checking: 1. All existing
   * account configurations 2. Which of those accounts the user is authorized to access
   *
   * @param userId The user ID whose accessible accounts are to be retrieved.
   * @return A Mono containing a Set of account IDs the user has access to.
   */
  public Mono<Set<Long>> retrieveUserAccessibleAccountIds(Integer userId) {
    return accountConfigServiceCache
        .getAllAccountConfigs()
        .map(
            accountConfigs ->
                accountConfigs.parallelStream()
                    .map(AccountConfig::getAccount)
                    .map(Account::getId)
                    .collect(Collectors.toSet()))
        .flatMap(accountIds -> businessWSCache.getUserAccountAccess(userId, accountIds))
        .map(
            entries ->
                entries.entrySet().stream()
                    .filter(Map.Entry::getValue)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toSet()));
  }

  /**
   * Retrieves the account IDs that the specified user has access to, in batches of the given size.
   *
   * @param userId The user ID whose accessible account IDs will be retrieved.
   * @param batchSize The size of each batch.
   * @return A Flux of Sets, each set containing up to batchSize account IDs.
   */
  public Flux<Set<Long>> retrieveUserAccessibleAccountIdsInBatches(
      Integer userId, Integer batchSize) {
    return retrieveUserAccessibleAccountIds(userId)
        .flatMapMany(Flux::fromIterable)
        .buffer(batchSize)
        .map(HashSet::new);
  }

  /**
   * Retrieves and enriches Account entities for a given user ID. The process involves: 1. Fetching
   * account IDs for the user 2. Retrieving business account data and enriching with client
   * information 3. Merging configuration data into each account
   *
   * @param userId The ID of the user whose accounts should be retrieved
   * @return A Flux of enriched Account entities
   */
  public Flux<Account> retrieveUserAccounts(Integer userId) {
    log.info("retrieveUserAccounts userId = {}", userId);
    if (userId == null) {
      return Flux.empty();
    }
    return retrieveUserAccessibleAccountIds(userId).flatMapMany(this::fetchAndEnrichAccounts);
  }

  /**
   * Converts a map of (accountId -> BusinessAccount) into a map of (accountId -> Account) by
   * attaching client & ultimate parent data.
   */
  private Mono<Map<Long, Account>> attachClientAndParentData(
      Map<Long, BusinessAccount> businessAccountMap) {
    var clientIds = AccountUtils.gatherClientIds(businessAccountMap);
    return businessWSCache
        .getClientDataFromCache(List.copyOf(clientIds))
        .map(
            clientDataMap ->
                convertBusinessAccountsToAccountMap(businessAccountMap, clientDataMap));
  }

  /**
   * Converts a map of (accountId -> BusinessAccount) into a map of (accountId -> Account),
   * attaching any available client or ultimate-parent data from the provided clientDataMap.
   */
  private Map<Long, Account> convertBusinessAccountsToAccountMap(
      Map<Long, BusinessAccount> businessAccountMap, Map<Long, Client> clientDataMap) {
    return businessAccountMap.entrySet().parallelStream()
        .map(entry -> createAccountWithClientData(entry.getValue(), clientDataMap))
        .collect(HashMap::new, (map, acc) -> map.put(acc.getId(), acc), HashMap::putAll);
  }

  /**
   * Creates a single Account from a BusinessAccount, enriching it with client and ultimate-parent
   * data if present.
   */
  private Account createAccountWithClientData(
      BusinessAccount businessAccount, Map<Long, Client> clientDataMap) {
    var account = accountTransformer.apply(businessAccount);
    Optional.ofNullable(businessAccount.getClientId())
        .ifPresent(clientId -> account.setClient(clientDataMap.get(clientId)));
    Optional.ofNullable(businessAccount.getUltimateParentId())
        .ifPresent(parentId -> account.setUltimateParentClient(clientDataMap.get(parentId)));
    return account;
  }

  /**
   * Orchestrates retrieving BusinessAccount data for the given account IDs, converting them into
   * Account objects, then merging config data to produce a Flux<Account>.
   */
  private Flux<Account> fetchAndEnrichAccounts(Set<Long> accountIds) {
    return businessWSCache
        .getAccountsDataFromCache(accountIds)
        .publishOn(Schedulers.parallel())
        .flatMap(this::attachClientAndParentData)
        .flatMapMany(this::mergeConfigIntoAccounts);
  }

  /**
   * Converts a map of (accountId -> Account) into a Flux<Account>, retrieving and merging each
   * account's configuration data from the accountConfigServiceCache.
   */
  private Flux<Account> mergeConfigIntoAccounts(Map<Long, Account> accountMap) {
    return Flux.fromIterable(accountMap.entrySet())
        .flatMap(entry -> mergeConfigurationIntoAccount(entry.getValue()));
  }

  /**
   * Merges configuration data (e.g., subscription start date, attributes) into the provided Account
   * object.
   */
  private Mono<Account> mergeConfigurationIntoAccount(Account account) {
    return accountConfigServiceCache
        .getByAccountId(account.getId())
        .map(
            config ->
                account.toBuilder()
                    .subscriptionStartDate(config.getSubscriptionStartDate())
                    .attributes(
                        Optional.ofNullable(config.getAttributes()).orElse(Collections.emptyMap()))
                    .build());
  }

  /** Retrieves only those user accounts which have a valid ultimate parent client. */
  private Flux<Account> retrieveFilteredUserAccounts(Integer userId) {
    return retrieveUserAccounts(userId)
        .filter(
            account ->
                Objects.nonNull(account.getUltimateParentClient())
                    && Objects.nonNull(account.getUltimateParentClient().getParentId()));
  }
}
