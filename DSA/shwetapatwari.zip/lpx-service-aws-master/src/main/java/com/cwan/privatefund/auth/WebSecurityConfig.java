package com.cwan.privatefund.auth;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity.CsrfSpec;
import org.springframework.security.config.web.server.ServerHttpSecurity.FormLoginSpec;
import org.springframework.security.web.server.SecurityWebFilterChain;
import reactor.core.publisher.Mono;

@Configuration
@EnableWebFluxSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig {

  @Bean
  public SecurityWebFilterChain securityWebFilterChain(
      ServerHttpSecurity http, SecurityContextRepository securityContextRepository) {
    http.csrf(CsrfSpec::disable) // Disable CSRF
        .formLogin(FormLoginSpec::disable) // Disable form login
        .authorizeExchange(
            authorize ->
                authorize
                    // no authorization needed
                    .pathMatchers(
                        "/webjars/swagger-ui/*",
                        "/api-docs/swagger-config",
                        "/api-docs",
                        "/actuator/health",
                        "/status")
                    .permitAll()
                    // general application-level authorization
                    .pathMatchers("/v1/**", "/tabular/**", "/leader")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE)
                    // capital call level authorization
                    .pathMatchers(
                        HttpMethod.GET,
                        "/*/capitalCallManagement/**",
                        "/*/capital-call",
                        "/*/capital-call/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_READ)
                    .pathMatchers(
                        HttpMethod.POST,
                        "/*/capitalCallManagement/**",
                        "/*/capital-call",
                        "/*/capital-call/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_WRITE)
                    .pathMatchers(
                        HttpMethod.DELETE,
                        "/*/capitalCallManagement/**",
                        "/*/capital-call",
                        "/*/capital-call/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_WRITE)
                    // document level authorization
                    .pathMatchers(HttpMethod.GET, "/*/documents/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_VIEW_ACCESS)
                    .pathMatchers(HttpMethod.POST, "/*/documents/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_EDIT_ACCESS)
                    .pathMatchers(HttpMethod.PUT, "/*/documents/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_EDIT_ACCESS)
                    .pathMatchers(HttpMethod.DELETE, "/*/documents/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_EDIT_ACCESS)
                    // document manager level authorization
                    .pathMatchers(HttpMethod.GET, "/*/document-manager/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_MANAGER_VIEW)
                    .pathMatchers(HttpMethod.POST, "/*/document-manager/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_MANAGER_EDIT)
                    // k1 level authorization
                    .pathMatchers(HttpMethod.GET, "/*/k1s/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_K1_READ)
                    .pathMatchers(HttpMethod.POST, "/*/k1s/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_K1_WRITE)
                    // watchlist level authorization
                    .pathMatchers(HttpMethod.GET, "/*/watchlist/**")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_WATCHLIST_READ)
                    .pathMatchers(HttpMethod.POST, "/*/watchlist")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_WATCHLIST_WRITE)
                    .pathMatchers(HttpMethod.PUT, "/*/watchlist")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_WATCHLIST_WRITE)
                    .pathMatchers(HttpMethod.DELETE, "/*/watchlist")
                    .hasAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_WATCHLIST_WRITE)
                    .anyExchange()
                    .authenticated())
        .exceptionHandling(
            exceptions ->
                exceptions
                    .authenticationEntryPoint(
                        (swe, e) ->
                            Mono.fromRunnable(
                                () -> swe.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED)))
                    .accessDeniedHandler(
                        (swe, e) ->
                            Mono.fromRunnable(
                                () -> swe.getResponse().setStatusCode(HttpStatus.FORBIDDEN))))
        .securityContextRepository(securityContextRepository);

    return http.build();
  }

  @Bean
  public OpenAPI customizeOpenAPI() {
    final var securitySchemeName = "bearerAuth";
    return new OpenAPI()
        .addSecurityItem(new SecurityRequirement().addList(securitySchemeName))
        .components(
            new Components()
                .addSecuritySchemes(
                    securitySchemeName,
                    new SecurityScheme()
                        .name(securitySchemeName)
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")));
  }
}
