package com.cwan.privatefund.portfolio.model;

import java.util.Collection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class PortfolioRequestData {

  private String ranges;
  private Collection<Long> accountIds;
}
