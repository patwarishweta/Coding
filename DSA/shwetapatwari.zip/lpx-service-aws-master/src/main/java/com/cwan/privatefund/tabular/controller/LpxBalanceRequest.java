package com.cwan.privatefund.tabular.controller;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

public class LpxBalanceRequest implements Serializable {

  private Set<Long> accountIds;
  private Set<Integer> fieldIds;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate beginDate;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate date;

  public LpxBalanceRequest() {}

  public LpxBalanceRequest(Set<Long> accountIds, Set<Integer> fieldIds, LocalDate asOfDate) {
    this(accountIds, fieldIds, null, asOfDate);
  }

  public LpxBalanceRequest(
      Set<Long> accountIds, Set<Integer> fieldIds, LocalDate beginDate, LocalDate asOfDate) {
    this.accountIds = accountIds;
    this.fieldIds = fieldIds;
    this.beginDate = beginDate;
    this.date = asOfDate;
  }

  public Set<Long> getAccountIds() {
    return accountIds;
  }

  public Set<Integer> getFieldIds() {
    return fieldIds;
  }

  public LocalDate getDate() {
    return date;
  }

  public LocalDate getBeginDate() {
    return beginDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LpxBalanceRequest that = (LpxBalanceRequest) o;
    return Objects.equals(accountIds, that.accountIds)
        && Objects.equals(fieldIds, that.fieldIds)
        && Objects.equals(beginDate, that.beginDate)
        && Objects.equals(date, that.date);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountIds, fieldIds, date, beginDate);
  }
}
