package com.cwan.privatefund.portfolio;

import static com.cwan.privatefund.constant.Constants.BATCH_SIZE;
import static com.cwan.privatefund.constant.RedisConstants.PORTFOLIO_ACCOUNT_SECURITY_CACHE;

import com.ca.json2.utils.JsonUtils2;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.client.WsClientStatus;
import com.cwan.privatefund.portfolio.model.PortfolioData;
import com.cwan.privatefund.portfolio.model.PortfolioRequestData;
import com.google.common.collect.Lists;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class PortfolioWsClient {

  private final WebClient webClient;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final RedisTemplate redisTemplate;

  public PortfolioWsClient(
      @Qualifier("portfolioWebServiceClient") WebClient webClient,
      AccountConfigServiceCache accountConfigServiceCache,
      RedisTemplate redisTemplate) {
    this.webClient = webClient;
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.redisTemplate = redisTemplate;
  }

  public Mono<Set<PortfolioData>> getPortfolioData(Set<Long> accountIds) {
    return Flux.fromIterable(accountIds)
        .flatMap(
            accountId ->
                accountConfigServiceCache
                    .getByAccountId(accountId)
                    .flatMapMany(
                        accountConfig ->
                            Flux.just(
                                PortfolioRequestData.builder()
                                    .ranges(
                                        String.format(
                                            "[{\"atLeast\":\"%s\",\"atMost\":\"%s\"}]",
                                            accountConfig.getSubscriptionStartDate(),
                                            accountConfig.getSubscriptionEndDate()))
                                    .accountIds(List.of(accountId))
                                    .build())))
        .collectList()
        .filter(
            portfolioRequestData -> portfolioRequestData != null && !portfolioRequestData.isEmpty())
        .doOnNext(
            portfolioRequest ->
                log.info("PortFolio Request: {}", JsonUtils2.objToJson(portfolioRequest)))
        .flatMap(
            portfolioRequest ->
                webClient
                    .post()
                    .uri("/specialized/openRanges/v1")
                    .bodyValue(portfolioRequest)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .onStatus(
                        HttpStatusCode::is4xxClientError,
                        res ->
                            WsClientStatus.onStatusError(
                                res,
                                "PortfolioWsClient getPortfolioData 4xxClientError accountId: "
                                    + accountIds))
                    .onStatus(
                        HttpStatusCode::is5xxServerError,
                        res ->
                            WsClientStatus.onStatusError(
                                res,
                                "PortfolioWsClient getPortfolioData is5xxServerError accountId: : "
                                    + accountIds))
                    .bodyToMono(new ParameterizedTypeReference<Set<PortfolioData>>() {})
                    .onErrorResume(
                        e -> {
                          if (e instanceof UnknownHostException) {
                            log.error(
                                "Failed to get response from portfolio-ws, desired service not present: {}",
                                e);
                          } else {
                            log.error(
                                "Exception occurred PortfolioWsClient getting security Data retrieval {}",
                                accountIds,
                                e);
                          }
                          return Mono.empty();
                        }));
  }

  public Mono<Set<PortfolioData>> getPortfolioDataWithCacheCheck(Collection<Long> accountIds) {
    AtomicBoolean missingAccountsFlag = new AtomicBoolean(false);
    Map<Long, List<PortfolioData>> expandedAccountsMap =
        accountIds.stream()
            .collect(
                Collectors.toMap(
                    Function.identity(),
                    accId -> {
                      List<PortfolioData> portfolioData =
                          (List<PortfolioData>)
                              redisTemplate
                                  .opsForHash()
                                  .get(PORTFOLIO_ACCOUNT_SECURITY_CACHE, accId);
                      if (portfolioData == null || portfolioData.isEmpty()) {
                        missingAccountsFlag.set(true);
                        return new ArrayList<>();
                      }
                      return portfolioData;
                    },
                    (x, y) -> y));

    if (Boolean.FALSE.equals(missingAccountsFlag.get())) {
      log.info("getPortfolioDataWithCacheCheck: All accounts found in cache");
      return Mono.just(
          expandedAccountsMap.entrySet().stream()
              .map(Map.Entry::getValue)
              .flatMap(Collection::stream)
              .collect(Collectors.toSet()));
    }

    List<Long> missingAccountIds =
        expandedAccountsMap.entrySet().stream()
            .filter(longListEntry -> longListEntry.getValue().isEmpty())
            .map(Map.Entry::getKey)
            .toList();

    log.info(
        "Few accounts missing in cache going to hit BusinessWs Client  {}",
        missingAccountIds.size());

    return Mono.just(missingAccountIds)
        .map(accIds -> Lists.partition(accIds, BATCH_SIZE))
        .flatMapIterable(Function.identity())
        .flatMap(accIdBatch -> getPortfolioData(Set.copyOf(accIdBatch)))
        .flatMapIterable(Function.identity())
        .map(
            portfolioData -> {
              List<PortfolioData> cachedPortfolioData =
                  expandedAccountsMap.getOrDefault(portfolioData.getAccountId(), new ArrayList<>());
              cachedPortfolioData.add(portfolioData);
              expandedAccountsMap.put(portfolioData.getAccountId(), cachedPortfolioData);
              return portfolioData;
            })
        .collectList()
        .map(
            x -> {
              missingAccountIds.stream()
                  .forEach(
                      missAccid -> {
                        if (expandedAccountsMap.containsKey(missAccid)) {
                          redisTemplate
                              .opsForHash()
                              .put(
                                  PORTFOLIO_ACCOUNT_SECURITY_CACHE,
                                  missAccid,
                                  expandedAccountsMap.get(missAccid));
                        }
                      });
              return expandedAccountsMap.values().stream()
                  .flatMap(Collection::stream)
                  .collect(Collectors.toSet());
            });
  }
}
