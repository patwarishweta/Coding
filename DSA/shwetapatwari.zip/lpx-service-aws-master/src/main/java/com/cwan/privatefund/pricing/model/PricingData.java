package com.cwan.privatefund.pricing.model;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class PricingData implements Serializable {

  @Serial private static final long serialVersionUID = -6636335471366854442L;

  private String sourceId;
  private Double price;
}
