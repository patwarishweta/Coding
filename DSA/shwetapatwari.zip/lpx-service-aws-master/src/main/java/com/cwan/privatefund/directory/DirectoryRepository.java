package com.cwan.privatefund.directory;

import com.cwan.privatefund.directory.model.DirectoryEntity;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DirectoryRepository extends JpaRepository<DirectoryEntity, Long> {

  Collection<DirectoryEntity> findAllByAccountId(Long accountId);

  Collection<DirectoryEntity> findAllByParentDirectoryId(Long parentDirectoryId);
}
