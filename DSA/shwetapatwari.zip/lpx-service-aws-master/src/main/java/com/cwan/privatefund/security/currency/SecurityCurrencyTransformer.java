package com.cwan.privatefund.security.currency;

import com.cwan.privatefund.security.model.SecurityCurrency;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class SecurityCurrencyTransformer
    implements Function<SecurityCurrencyEntity, SecurityCurrency> {
  @Override
  public SecurityCurrency apply(SecurityCurrencyEntity securityCurrencyInfo) {
    return SecurityCurrency.builder()
        .securityId(securityCurrencyInfo.getSecurityId())
        .currencyId(securityCurrencyInfo.getCurrencyId())
        .modifiedOn(securityCurrencyInfo.getModifiedOn())
        .build();
  }
}
