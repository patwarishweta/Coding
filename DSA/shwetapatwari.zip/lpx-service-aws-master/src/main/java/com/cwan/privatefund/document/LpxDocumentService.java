package com.cwan.privatefund.document;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Client;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.balance.LpxBalanceEntityService;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.constant.Constants;
import com.cwan.privatefund.document.DocumentAuditService.DocumentDbInfo;
import com.cwan.privatefund.document.model.DocumentAudit;
import com.cwan.privatefund.document.model.DocumentAuditValidationEntity;
import com.cwan.privatefund.document.signed.url.SignedUrlAuditService;
import com.cwan.privatefund.issuestore.IssueStoreClient;
import com.cwan.privatefund.issuestore.model.Issue;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.google.common.collect.Lists;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
public class LpxDocumentService {

  private final HttpClient signedUrlClient;
  private final AccountService accountService;
  private final Documents documents;
  private final SecurityService securityService;
  private final LpxDocumentServiceClient lpxDocumentServiceClient;
  private final LpxTransactionService lpxTransactionService;
  private final LpxBalanceEntityService lpxBalanceEntityService;
  private final IssueStoreClient issueStoreClient;
  private final BusinessWSClient businessWSClient;
  private final DocumentAuditService documentAuditService;
  private final SignedUrlAuditService signedUrlAuditService;
  private final SecurityContextUserService securityContextUserService;

  public LpxDocumentService(
      AccountService accountService,
      Documents documents,
      SecurityService securityService,
      LpxDocumentServiceClient lpxDocumentServiceClient,
      @Qualifier("signedUrlClient") HttpClient signedUrlClient,
      LpxTransactionService lpxTransactionService,
      LpxBalanceEntityService lpxBalanceEntityService,
      IssueStoreClient issueStoreClient,
      BusinessWSClient businessWSClient,
      DocumentAuditService documentAuditService,
      SignedUrlAuditService signedUrlAuditService,
      SecurityContextUserService securityContextUserService) {
    this.accountService = accountService;
    this.documents = documents;
    this.securityService = securityService;
    this.lpxDocumentServiceClient = lpxDocumentServiceClient;
    this.signedUrlClient = signedUrlClient;
    this.lpxTransactionService = lpxTransactionService;
    this.lpxBalanceEntityService = lpxBalanceEntityService;
    this.issueStoreClient = issueStoreClient;
    this.businessWSClient = businessWSClient;
    this.documentAuditService = documentAuditService;
    this.signedUrlAuditService = signedUrlAuditService;
    this.securityContextUserService = securityContextUserService;
  }

  public Flux<Document> addDocuments(Set<Document> documentsToAdd) {
    return Flux.fromIterable(documentsToAdd).flatMap(lpxDocumentServiceClient::saveDocument);
  }

  public Mono<Document> deleteDocumentByDocId(Long docId) {
    var isBalancesFound =
        lpxBalanceEntityService
            .getBalancesByDocumentIds(Set.of(docId))
            .hasElements()
            .onErrorReturn(Boolean.FALSE);
    Mono<Boolean> isTransactionsFound;
    try {
      isTransactionsFound =
          lpxTransactionService
              .getTransactionsByDocumentId(docId)
              .collectList()
              .flatMap(
                  transactions ->
                      transactions.isEmpty() ? Mono.just(Boolean.FALSE) : Mono.just(Boolean.TRUE));
    } catch (Exception ex) {
      return Mono.error(new RuntimeException(ex.getMessage() + " for docId:" + docId));
    }
    return isBalancesFound
        .switchIfEmpty(isTransactionsFound)
        .flatMap(
            balFound -> {
              if (Boolean.TRUE.equals(balFound)) {
                return Mono.error(
                    new RuntimeException(
                        MessageFormat.format(
                            "This Document:{0} was received from upstream or "
                                + "automatically added. hence cannot be deleted",
                            docId)));
              }
              return isTransactionsFound;
            })
        .flatMap(
            txnFound -> {
              if (Boolean.TRUE.equals(txnFound)) {
                return Mono.error(
                    new RuntimeException(
                        MessageFormat.format(
                            "This document:{0} has transactions associated with it either "
                                + "delete the transaction or change the document reference for associated transactions",
                            docId)));
              }
              return getDocumentById(docId)
                  .map(document -> document.toBuilder().isDisabled(true).build())
                  .flatMapMany(document -> updateDocumentInfo(Set.of(document)))
                  .next();
            });
  }

  public Mono<Void> deleteMissingDocumentAlertsByClientId(Long clientId) {
    return lpxDocumentServiceClient.deleteMissingDocumentAlerts(clientId);
  }

  public Mono<Void> deleteMissingDocumentExpectationsBySecurityIdAndDocumentType(
      Long securityId, String documentType) {
    return lpxDocumentServiceClient.deleteMissingDocumentExpectation(securityId, documentType);
  }

  public Flux<Document> fetchActiveDocumentsInDateRange(
      Collection<Long> accountIds,
      Collection<Long> securityIds,
      LocalDate beginDate,
      LocalDate endDate) {
    String accountsDesc = CollectionUtils.isNotEmpty(accountIds) ? accountIds.toString() : "none";
    String securitiesDesc =
        CollectionUtils.isNotEmpty(securityIds) ? securityIds.toString() : "none";
    log.info(
        "Starting document fetch and hydration process | Date Range: {} to {} | Accounts: {} | Securities: {}",
        beginDate,
        endDate,
        accountsDesc,
        securitiesDesc);
    return documents
        .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            accountIds, securityIds, beginDate, endDate, Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .flatMapMany(Flux::fromIterable)
        .doOnComplete(
            () ->
                log.info(
                    "Successfully completed document processing | Date Range: {} to {} | Accounts: {} | Securities: {}",
                    beginDate,
                    endDate,
                    accountsDesc,
                    securitiesDesc));
  }

  public Flux<DocumentAudit> getAllDocumentsByAccountAndDateRange(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return Flux.fromIterable(accountIds)
        .subscribeOn(Schedulers.boundedElastic())
        .flatMap(accountService::expandAccountId)
        .collect(Collectors.toSet())
        .map(accIds -> Lists.partition(List.copyOf(accIds), 1000))
        .flatMapIterable(Function.identity())
        .flatMap(
            expandedAccountIds ->
                getAllDocumentsByAccountAndDateRangeForAudit(
                    Set.copyOf(expandedAccountIds), beginDate, endDate))
        .flatMap(
            document -> {
              log.info("Before getting Document issue {}", document);
              Flux<Issue> issueFlux =
                  document.getDocumentEntity() != null
                      ? issueStoreClient.getIssuesByTag(
                          String.valueOf(document.getDocumentEntity().getId()))
                      : null;
              if (issueFlux == null) {
                return Flux.empty();
              }
              log.info("After Issue {}", issueFlux);
              return issueFlux
                  .flatMap(
                      issue -> {
                        log.info("Checking user Id for the Issue {}", issue);
                        Integer userId = issue.getStatus().getUserId();
                        log.info("fetching user name if id exists for issue {}", issue);
                        Mono<User> userDetailsMono =
                            businessWSClient
                                .fetchUserDetails(userId)
                                .onErrorResume(e -> Mono.empty());
                        return userDetailsMono
                            .map(
                                userDetails ->
                                    DocumentAudit.builder()
                                        // when issue exist with user ID
                                        .documentId(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getId())
                                                .orElse(0L))
                                        .documentName(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getFileName())
                                                .orElse(""))
                                        .documentType(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getType())
                                                .orElse(""))
                                        .accountId(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getAccountId())
                                                .orElse(0L))
                                        .securityId(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getSecurityId())
                                                .orElse(0L))
                                        .client(
                                            Optional.ofNullable(document.getDocument().getAccount())
                                                .map(Account::getClient)
                                                .map(Client::getName)
                                                .orElse(""))
                                        .investor(
                                            Optional.ofNullable(document.getDocument().getAccount())
                                                .map(Account::getClient)
                                                .map(Client::getName)
                                                .orElse(""))
                                        .canoeId(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getCanoeId())
                                                .orElse(""))
                                        .knowledgeDate(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getReceivedDate())
                                                .map(Object::toString)
                                                .orElse(""))
                                        .cashMovementDate(
                                            Optional.ofNullable(
                                                    document.getDocumentEntity().getCashMvmtDate())
                                                .map(Object::toString)
                                                .orElse(""))
                                        .issue(issue)
                                        .actionBy(userDetails.getFullname())
                                        .validated(
                                            Optional.ofNullable(document.getDocumentEntity())
                                                .map(DocumentEntity::getChecked)
                                                .orElse(false))
                                        .validatedBy(
                                            Optional.ofNullable(
                                                    document.getDocumentAuditValidationEntity())
                                                .map(DocumentAuditValidationEntity::getModifiedBy)
                                                .orElse(""))
                                        .validatedOn(
                                            Optional.ofNullable(
                                                    document.getDocumentAuditValidationEntity())
                                                .map(DocumentAuditValidationEntity::getModifiedOn)
                                                .orElse(null))
                                        .build())
                            .defaultIfEmpty(
                                DocumentAudit.builder()
                                    // when userId is -1 and issue exists
                                    .documentId(
                                        Optional.ofNullable(document.getDocumentEntity().getId())
                                            .orElse(0L))
                                    .documentName(
                                        Optional.ofNullable(
                                                document.getDocumentEntity().getFileName())
                                            .orElse(""))
                                    .documentType(
                                        Optional.ofNullable(document.getDocumentEntity().getType())
                                            .orElse(""))
                                    .accountId(
                                        Optional.ofNullable(
                                                document.getDocumentEntity().getAccountId())
                                            .orElse(0L))
                                    .securityId(
                                        Optional.ofNullable(
                                                document.getDocumentEntity().getSecurityId())
                                            .orElse(0L))
                                    .client(
                                        Optional.ofNullable(document.getDocument().getAccount())
                                            .map(Account::getClient)
                                            .map(Client::getName)
                                            .orElse(""))
                                    .investor(
                                        Optional.ofNullable(document.getDocument().getAccount())
                                            .map(Account::getClient)
                                            .map(Client::getName)
                                            .orElse(""))
                                    .canoeId(
                                        Optional.ofNullable(
                                                document.getDocumentEntity().getCanoeId())
                                            .orElse(""))
                                    .knowledgeDate(
                                        Optional.ofNullable(
                                                document.getDocumentEntity().getReceivedDate())
                                            .map(Object::toString)
                                            .orElse(""))
                                    .cashMovementDate(
                                        Optional.ofNullable(
                                                document.getDocumentEntity().getCashMvmtDate())
                                            .map(Object::toString)
                                            .orElse(""))
                                    .issue(issue)
                                    .validated(
                                        Optional.ofNullable(document.getDocumentEntity())
                                            .map(DocumentEntity::getChecked)
                                            .orElse(false))
                                    .validatedBy(
                                        Optional.ofNullable(
                                                document.getDocumentAuditValidationEntity())
                                            .map(DocumentAuditValidationEntity::getModifiedBy)
                                            .orElse(""))
                                    .validatedOn(
                                        Optional.ofNullable(
                                                document.getDocumentAuditValidationEntity())
                                            .map(DocumentAuditValidationEntity::getModifiedOn)
                                            .orElse(null))
                                    .build());
                      })
                  .switchIfEmpty(Flux.empty());
            });
  }

  public Flux<DocumentInfo> getAllDocumentsByAccountAndDateRangeForAudit(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    Flux<Document> documentFlux =
        getDocumentsByAccountsAndCashMvmtDateBetween(accountIds, beginDate, endDate);
    return getDocumentInfos(documentFlux);
  }

  public Flux<Document> getAuthorizedDocumentsInDateRange(
      Collection<Long> accountIds,
      Collection<Long> securityIds,
      LocalDate beginDate,
      LocalDate endDate) {
    return accountService
        .expandAccountIds(accountIds)
        .doOnNext(expandedIds -> log.info("Total expanded accounts: {}", expandedIds.size()))
        .flatMap(
            expandedIds ->
                securityContextUserService
                    .validateAndGetUserId()
                    .flatMap(accountService::retrieveUserAccessibleAccountIds)
                    .map(
                        allAuthorizedAccounts -> {
                          Set<Long> filtered =
                              expandedIds.stream()
                                  .filter(allAuthorizedAccounts::contains)
                                  .collect(Collectors.toSet());
                          log.info("Filtered accounts: {}", filtered.size());
                          return filtered;
                        }))
        .flatMapMany(
            filteredIds ->
                fetchActiveDocumentsInDateRange(filteredIds, securityIds, beginDate, endDate));
  }

  public Flux<Document> getAuthorizedDocumentsInDateRange(LocalDate beginDate, LocalDate endDate) {
    return securityContextUserService
        .validateAndGetUserId()
        .flatMap(accountService::retrieveUserAccessibleAccountIds)
        .doOnNext(
            authorizedAccounts ->
                log.info("Total authorized accounts: {}", authorizedAccounts.size()))
        .flatMapMany(
            authorizedAccounts ->
                fetchActiveDocumentsInDateRange(
                    authorizedAccounts, Collections.emptyList(), beginDate, endDate));
  }

  public Mono<Document> getDocumentById(Long id) {
    return documents.getDocumentById(id);
  }

  public Flux<DocumentInfo> getDocumentInfos(Flux<Document> documentFlux) {
    return documentAuditService.getDocumentsWithAuditInfo(documentFlux);
  }

  public Flux<Document> getDocumentsByAccountsAndCashMvmtDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return documents
        .getDocumentsByAccountsAndCashMvmtDateBetween(accountIds, beginDate, endDate)
        .filter(
            doc ->
                (doc.getSource() == null)
                    || !Constants.GEN_AI_DOCUMENTS_SOURCE.equals(doc.getSource()))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .map(
            docList -> {
              populateAssigneeDetails(docList);
              return docList;
            })
        .flatMapIterable(Function.identity());
  }

  public Flux<Document> getDocumentsByAccountsAndCashMvmtDateBetweenAndType(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate, String type) {
    if (StringUtils.isBlank(type)) {
      return getDocumentsByAccountsAndCashMvmtDateBetween(accountIds, beginDate, endDate);
    }
    List<String> types = Arrays.asList(type.split(","));
    return documents
        .getDocumentsByAccountsAndCashMvmtDateBetweenAndTypes(accountIds, beginDate, endDate, types)
        .filter(
            doc ->
                (doc.getSource() == null)
                    || !Constants.GEN_AI_DOCUMENTS_SOURCE.equals(doc.getSource()))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .publishOn(Schedulers.boundedElastic())
        .map(
            docList -> {
              populateAssigneeDetails(docList);
              return docList;
            })
        .flatMapIterable(Function.identity());
  }

  public Flux<Document> getDocumentsByAccountsAndDocumentDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return documents
        .getDocumentsByAccountsAndDocumentDateBetween(accountIds, beginDate, endDate)
        .filter(
            doc ->
                (doc.getSource() == null)
                    || !Constants.GEN_AI_DOCUMENTS_SOURCE.equals(doc.getSource()))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .flatMapIterable(Function.identity());
  }

  public Flux<Document> getDocumentsByAccountsAndPeriodEndDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return documents
        .getDocumentsByAccountsAndPeriodEndDateBetween(accountIds, beginDate, endDate)
        .filter(
            doc ->
                (doc.getSource() == null)
                    || !Constants.GEN_AI_DOCUMENTS_SOURCE.equals(doc.getSource()))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .flatMapIterable(Function.identity());
  }

  public Flux<Document> getDocumentsByAccountsAndReceivedDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return documents
        .getDocumentsByAccountsAndReceivedDateBetween(accountIds, beginDate, endDate)
        .filter(
            doc ->
                (doc.getSource() == null)
                    || !Constants.GEN_AI_DOCUMENTS_SOURCE.equals(doc.getSource()))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .publishOn(Schedulers.boundedElastic())
        .map(
            docList -> {
              populateAssigneeDetails(docList);
              return docList;
            })
        .flatMapIterable(Function.identity());
  }

  public Flux<Document> getDocumentsByAccountsAndReceivedDateBetweenAndType(
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      String type,
      boolean includeDemoAccounts) {
    if (StringUtils.isBlank(type)) {
      return getDocumentsByAccountsAndReceivedDateBetween(accountIds, beginDate, endDate)
          .filter(doc -> includeDemoAccounts || !doc.getAccount().getDemo());
    }
    List<String> types = Arrays.asList(type.split(","));
    return documents
        .getDocumentsByAccountsAndReceivedDateBetweenAndTypes(accountIds, beginDate, endDate, types)
        .filter(doc -> includeDemoAccounts || !doc.getAccount().getDemo())
        .filter(
            doc ->
                (doc.getSource() == null)
                    || !Constants.GEN_AI_DOCUMENTS_SOURCE.equals(doc.getSource()))
        .collectList()
        .flatMap(this::hydrateAccountAndSecurityDataOnDocuments)
        .map(
            docList -> {
              populateAssigneeDetails(docList);
              return docList;
            })
        .flatMapIterable(Function.identity());
  }

  public Flux<MissingDocuments> getMissingDocuments(Long accountId) {
    return lpxDocumentServiceClient.getMissingDocuments(accountId);
  }

  public Flux<MissingDocumentAlertConfig> getMissingDocumentsAlerts() {
    return lpxDocumentServiceClient.getAllMissingDocumentAlerts();
  }

  public Flux<MissingDocumentExpectationsConfig> getMissingDocumentsExpectations() {
    return lpxDocumentServiceClient.getMissingDocumentExpectations();
  }

  public Flux<DocumentDbInfo> getRecentlyValidatedDocuments(
      LocalDate beginDate, LocalDate endDate, Set<Long> accountIds) {
    return documentAuditService.getRecentlyValidatedDocuments(beginDate, endDate, accountIds);
  }

  public Mono<String> getSignedUrlByDocId(Long documentId) {
    var auditMono = signedUrlAuditService.performAudit(documentId);
    return lpxDocumentServiceClient
        .getSignedUrl(documentId)
        .doOnError(e -> log.error("Failed to retrieve signed URL", e))
        .flatMap(url -> auditMono.then(Mono.just(url)));
  }

  public byte[] getZipFileFromDocumentIds(Set<Long> documentIds) throws IOException {
    try (var baos = new ByteArrayOutputStream();
        var zos = new ZipOutputStream(baos)) {
      Set<String> usedFileNames = new HashSet<>();
      for (Long documentId : documentIds) {
        byte[] data =
            lpxDocumentServiceClient
                .getSignedUrl(documentId)
                .flatMap(this::resolveSignedUrl)
                .toFuture()
                .join();
        var document = documents.getDocumentById(documentId).toFuture().join();
        String baseFileName =
            DocumentUtils.appendTimestampBeforeExtension(
                document.getFileName(), document.getCreatedOn(), 75);
        String uniqueFileName = ensureUniqueFileName(baseFileName, usedFileNames);
        var zipEntry = new ZipEntry(uniqueFileName);
        zos.putNextEntry(zipEntry);
        zos.write(data);
        zos.closeEntry();
      }
      zos.finish();
      return baos.toByteArray();
    }
  }

  /**
   * Ensures a filename is unique by adding " (n)" before the extension if it has already been used.
   * Example: "example.pdf" -> "example (1).pdf"
   *
   * @param fileName the original filename
   * @param usedFileNames a set tracking previously used filenames
   * @return a guaranteed-unique filename
   */
  private static String ensureUniqueFileName(String fileName, Set<String> usedFileNames) {
    if (usedFileNames.add(fileName)) {
      return fileName;
    }
    int dotIndex = fileName.lastIndexOf('.');
    String nameWithoutExt = (dotIndex == -1) ? fileName : fileName.substring(0, dotIndex);
    String extension = (dotIndex == -1) ? "" : fileName.substring(dotIndex);
    int counter = 1;
    String candidate;
    do {
      candidate = nameWithoutExt + " (" + counter++ + ")" + extension;
    } while (!usedFileNames.add(candidate));
    return candidate;
  }

  public Mono<List<Document>> hydrateAccountAndSecurityDataOnDocuments(
      Collection<Document> documentCollection) {
    if (CollectionUtils.isEmpty(documentCollection)) {
      log.info("No documents to hydrate");
      return Mono.empty();
    }
    Set<Long> accountIdsSet =
        DocumentUtils.extractIds(documentCollection, Document::getAccount, Account::getId);
    Set<Long> securityIdsSet =
        DocumentUtils.extractIds(
            documentCollection, Document::getSecurity, Security::getSecurityId);
    if (CollectionUtils.isEmpty(accountIdsSet) && CollectionUtils.isEmpty(securityIdsSet)) {
      log.info("No account or security IDs found for hydration, returning original documents");
      return Mono.just(new ArrayList<>(documentCollection));
    }
    log.info(
        "Fetching data for hydration | Account IDs: {} | Security IDs: {}",
        accountIdsSet,
        securityIdsSet);
    Mono<List<Account>> accountsMono =
        CollectionUtils.isEmpty(accountIdsSet)
            ? Mono.empty()
            : accountService.getAccountsData(accountIdsSet);
    Mono<List<Security>> securitiesMono =
        CollectionUtils.isEmpty(securityIdsSet)
            ? Mono.empty()
            : securityService.getSecurities(null, null, List.copyOf(securityIdsSet));
    return Mono.zip(
        accountsMono,
        securitiesMono,
        (accounts, securities) -> {
          Map<Long, Account> accountMap =
              DocumentUtils.createEntityMap(accounts, Account::getId, (x, y) -> x);
          Map<Long, Security> securityMap =
              DocumentUtils.createEntityMap(securities, Security::getSecurityId, (x, y) -> x);
          List<Document> hydratedDocs =
              documentCollection.stream()
                  .filter(Objects::nonNull)
                  .map(doc -> DocumentUtils.hydrateDocument(doc, accountMap, securityMap))
                  .toList();
          log.info(
              "Successfully hydrated {} documents with account IDs: {} and security IDs: {}",
              hydratedDocs.size(),
              accountIdsSet,
              securityIdsSet);
          return hydratedDocs;
        });
  }

  public Flux<MissingDocumentAlertConfig> saveMissingDocumentAlerts(
      MissingDocumentAlertConfig config) {
    return lpxDocumentServiceClient.saveMissingDocumentAlerts(List.of(config));
  }

  public Flux<MissingDocumentExpectationsConfig> saveMissingDocumentExpectationsConfigs(
      MissingDocumentExpectationsConfig config) {
    return lpxDocumentServiceClient.saveMissingDocumentExpectationsConfigs(List.of(config));
  }

  public Flux<Document> updateDocumentInfo(Set<Document> documentsToUpdate) {
    /*
     * PUTs to this endpoint do not impact a document's account or security
     * information, therefore we should not 500 if we are unable to hydrate that
     * data
     */
    var documentFlux = documents.updateDocumentInfo(documentsToUpdate);
    try {
      documentFlux.subscribe(documentAuditService::saveDocumentAuditInfo);
      return hydrateSecurityAndAccountData(documentFlux);
    } catch (Exception e) {
      return documentFlux;
    }
  }

  public Flux<String> uploadFile(Flux<FilePart> file) {
    return file.flatMap(lpxDocumentServiceClient::uploadFile);
  }

  private Mono<Document> addAccountDataToDocument(Document document) {
    return accountService
        .getAccountWithClientData(document.getAccount().getId())
        .map(account -> document.toBuilder().account(account).build());
  }

  private Mono<Document> addSecurityDataToDocument(Document document) {
    if ((document.getSecurity() == null) || (document.getSecurity().getSecurityId() == null)) {
      return Mono.just(document);
    }
    var securityData =
        securityService.getSecurity(
            document.getAccount().getClientId(),
            document.getAccount().getId(),
            document.getSecurity().getSecurityId());
    if (securityData == null) {
      return Mono.just(document);
    }
    return securityData.map(security -> document.toBuilder().security(security).build());
  }

  private Flux<Document> hydrateSecurityAndAccountData(Flux<Document> documentFlux) {
    return documentFlux
        .flatMap(this::addAccountDataToDocument)
        .flatMap(this::addSecurityDataToDocument);
  }

  private void populateAssigneeDetails(List<Document> documentList) {
    Map<String, UserDetails> assigneeCache = new HashMap<>();
    log.info("populateAssigneeDetails for documents {}", documentList.size());
    List<String> canoeIds =
        documentList.parallelStream()
            .filter(
                document ->
                    (document.getCanoeId() != null)
                        && (document.getAssigneeId() == null)
                        && (document.getCreatedOn() != null))
            .filter(document -> document.getCreatedOn().isAfter(LocalDateTime.now().minusMonths(6)))
            .map(Document::getCanoeId)
            .toList();
    log.info("populateAssigneeDetails for only canoeIds size {}", canoeIds.size());
    Mono<Map<String, String>> assigneeMapByCanoeId =
        Mono.just(canoeIds)
            .flatMapIterable(canoe -> Lists.partition(canoe, 100))
            .collectList()
            .flatMapIterable(Function.identity())
            .concatMap(
                canoeId ->
                    Mono.fromCallable(
                            () ->
                                lpxDocumentServiceClient.getDocumentDataByCanoeId(
                                    Set.copyOf(canoeId)))
                        .delayElement(Duration.ofSeconds(5)))
            .flatMap(Function.identity())
            .flatMapIterable(Function.identity())
            .filter(canoeDataMap -> canoeDataMap.containsKey("assignee"))
            .collectMultimap(
                canoeDataMap -> (String) canoeDataMap.get("assignee"),
                canoeDataMap -> (String) canoeDataMap.get("id"))
            .filter(canoeIdListByUserId -> !canoeIdListByUserId.isEmpty())
            .flatMapMany(
                canoeIdListByUserId -> {
                  List<String> userIds = new ArrayList<>(canoeIdListByUserId.keySet());
                  userIds.removeAll(assigneeCache.keySet());
                  if (userIds.isEmpty()) {
                    return Flux.empty();
                  }
                  return lpxDocumentServiceClient
                      .fetchUserDetails(Set.copyOf(userIds))
                      .doOnNext(
                          userDetails -> assigneeCache.put(userDetails.getUserId(), userDetails))
                      .map(
                          userDetails ->
                              canoeIdListByUserId.entrySet().stream()
                                  .flatMap(
                                      e ->
                                          e.getValue().stream()
                                              .map(
                                                  v ->
                                                      new AbstractMap.SimpleImmutableEntry<>(
                                                          e.getKey(), v)))
                                  .collect(
                                      Collectors.toMap(
                                          Map.Entry::getValue, Map.Entry::getKey, (x, y) -> x)));
                })
            .collect(HashMap::new, Map::putAll);
    assigneeMapByCanoeId
        .map(
            canoeIdMap -> {
              log.info(
                  "Canoe Map To AssigneeId {} \n assigneeCache:{} {}",
                  canoeIdMap,
                  assigneeCache,
                  documentList);
              return documentList.stream()
                  .filter(
                      document ->
                          (document.getCanoeId() != null) && (document.getAssigneeId() == null))
                  .filter(
                      document ->
                          canoeIdMap.containsKey(document.getCanoeId())
                              && assigneeCache.containsKey(canoeIdMap.get(document.getCanoeId())))
                  .map(
                      document -> {
                        UserDetails userDetails =
                            assigneeCache.get(canoeIdMap.get(document.getCanoeId()));
                        return document.toBuilder()
                            .assigneeId(userDetails.getUserId())
                            .assigneeName(
                                userDetails.getFirstName() + " " + userDetails.getLastName())
                            .assigneeEmail(userDetails.getEmail())
                            .build();
                      })
                  .toList();
            })
        .map(enrichedDocumentList -> documents.updateDocumentInfo(Set.copyOf(enrichedDocumentList)))
        .flatMapMany(Function.identity())
        .collectList()
        .subscribe(
            x -> {},
            e -> log.error("Exception during populateAssigneeDetails :: {}", e.getMessage()));
  }

  private Mono<byte[]> resolveSignedUrl(String signedUrl) {
    var httpGet = new HttpGet(signedUrl);
    HttpResponse response;
    try {
      response = signedUrlClient.execute(httpGet);
      var baos = new ByteArrayOutputStream();
      response.getEntity().writeTo(baos);
      var bytes = baos.toByteArray();
      return Mono.just(bytes);
    } catch (IOException e) {
      throw new RuntimeException("Exception occurred while calling signed URL", e);
    }
  }
}
