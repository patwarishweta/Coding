package com.cwan.privatefund.accelex;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;

public record DocumentMetaData(
    String identifierType,
    String identifierValues,
    String documentType,
    String canoeId,
    String documentName,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate documentDate)
    implements Serializable {}
