package com.cwan.privatefund.portfolio;

import com.ca.json2.utils.JsonUtils2;
import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.PostRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.cache.Cache;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PortfolioWsApacheClient {

  private final WsHttpClient wsHttpClient;
  private final Resource securityHoldingsResource;
  private final Resource lotBySecurityResource;
  private final Cache<Long, List<PortfolioLot>> accountToPortfolioLotsCache;

  public PortfolioWsApacheClient(
      WsHttpClient wsHttpClient,
      ServerConfiguration serverConfiguration,
      Cache<Long, List<PortfolioLot>> accountToPortfolioLotsCache) {
    this.wsHttpClient = wsHttpClient;
    this.securityHoldingsResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("specialized/holdingAccounts/v1/securities")
            .withAcceptType(MimeType.JSON)
            .toResource();
    this.lotBySecurityResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("lots/v2/accounts/{accountId}/securities")
            .withAcceptType(MimeType.JSON)
            .toResource();
    this.accountToPortfolioLotsCache = accountToPortfolioLotsCache;
  }

  public Set<Long> getAccountIdsBySecurityId(Long securityId, LocalDate date) {
    log.info(
        "PortfolioWsApacheClient getAccountIdsBySecurityId securityId: {}, date: {}",
        securityId,
        date);
    GetRequest request =
        securityHoldingsResource
            .doGET(wsHttpClient)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .addQueryParam("securityId", securityId)
            .addQueryParam("asOfDate", date.format(DateTimeFormatter.ISO_DATE))
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error("PortfolioWsApacheClient getAccountIdsBySecurityId error: {}", e.getMessage());
      return Set.of(); // not resolving holding accounts should not be a fatal error
    }
  }

  public List<PortfolioLot> getPortfolioLots(Long accountId, Set<Long> securityIds) {
    try {
      return accountToPortfolioLotsCache.get(
          accountId, () -> fetchPortfolioLots(accountId, securityIds));
    } catch (Exception e) {
      log.error("Error while fetching portfolio lot for accountId " + accountId, e);
      throw new RuntimeException(e);
    }
  }

  private List<PortfolioLot> fetchPortfolioLots(Long accountId, Set<Long> securityIds) {
    log.info(
        "PortfolioWsApacheClient getPortfolioLot accountId: {}, securityIds: {}",
        accountId,
        securityIds);
    PostRequest request =
        lotBySecurityResource
            .doPOST(wsHttpClient)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withPathParam("accountId", accountId)
            .addFormParams("securityIds", securityIds)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (Exception e) {
      log.error("PortfolioWsApacheClient getAccountIdsBySecurityId error: {}", e.getMessage());
      throw new RuntimeException(
          "Error while fetching portfolio lot for accountId " + accountId, e);
    }
  }

  public record LotUnitChange(
      @JsonFormat(pattern = "yyyy-MM-dd") LocalDate entryDate,
      @JsonFormat(pattern = "yyyy-MM-dd") LocalDate settlePostDate,
      long origTranId,
      int units) {}

  public record PortfolioLot(long accountId, long securityId, List<LotUnitChange> lotUnitChanges) {}

  // SECURITY_ID -> List<GlobalDateRange>  start of holding lot to end of holding
  public Map<Long, List<LocalDateRange>> getLotEffectiveRangeMap(
      Long accountId, Set<Long> securityIds) {
    Map<Long, List<LocalDateRange>> retVal = new HashMap<>();

    List<PortfolioLot> portfolioLots = getPortfolioLots(accountId, securityIds);
    for (PortfolioLot portfolioLot : portfolioLots) {
      List<LotUnitChange> lotUnitChanges = portfolioLot.lotUnitChanges();
      LocalDate lotBeginDate = lotUnitChanges.get(0).entryDate();
      LocalDate lotEndDate = LocalDate.MAX;
      // if the units are 0 we set end date, otherwise we assume the lot is still open
      Integer endingUnits =
          lotUnitChanges.stream().map(LotUnitChange::units).reduce(0, Integer::sum);
      if (endingUnits <= 0) {
        lotEndDate = lotUnitChanges.get(lotUnitChanges.size() - 1).settlePostDate();
      }

      LocalDateRange effectiveRange = LocalDateRanges.create(lotBeginDate, lotEndDate);

      retVal.computeIfAbsent(portfolioLot.securityId(), k -> new ArrayList<>()).add(effectiveRange);
    }
    return retVal;
  }
}
