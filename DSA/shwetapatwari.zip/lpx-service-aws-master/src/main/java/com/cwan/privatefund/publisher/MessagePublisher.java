package com.cwan.privatefund.publisher;

import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.hydrate.TransactionDataHydrationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.model.MessageAttributeValue;
import software.amazon.awssdk.services.sns.model.PublishRequest;

@Slf4j
public class MessagePublisher<T> {

  private final String topicArn;
  private final SnsClient snsClient;
  private final ObjectMapper objectMapper;

  private final TransactionDataHydrationService transactionDataHydrationService;

  public MessagePublisher(
      String topicArn,
      SnsClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    this.topicArn = topicArn;
    this.snsClient = snsClient;
    this.objectMapper = objectMapper;
    this.transactionDataHydrationService = transactionDataHydrationService;
  }

  public void publishMessageCollection(Collection<Transaction> messages) {
    Map<Long, List<Transaction>> transactionsPerAccountId =
        messages.stream() // Map all transactions to the account id on them
            .collect(Collectors.groupingBy(transaction -> transaction.getAccount().getId()));

    transactionsPerAccountId
        .values()
        .forEach(
            this::publishMessageAsCollection); // for each account id, publish the collection of
    // transactions mapped to them.
  }

  public void publishMessageAsCollection(List<Transaction> msgData) {
    Map<Boolean, List<Transaction>> checkAccountHydration =
        msgData.stream()
            .collect(
                Collectors.partitioningBy(
                    transaction ->
                        (!StringUtils.isEmpty(transaction.getAccount().getFunctionalCurrencyCode())
                            && transaction.getAccount().getCurrencyFxRateSourceId() != null
                            && transaction.getAccount().getFunctionalCurrencyId() != null)));

    List<Transaction> hydratedData = new ArrayList<>(checkAccountHydration.get(Boolean.TRUE));
    Mono<List<Transaction>> hydratedAccountData =
        transactionDataHydrationService
            .hydrateAccountData(checkAccountHydration.get(Boolean.FALSE))
            .doOnNext(transactions -> hydratedData.addAll(transactions))
            .thenReturn(hydratedData);
    hydratedAccountData.subscribe(
        transactions -> {
          try {
            String message = objectMapper.writeValueAsString(transactions);
            PublishRequest request =
                PublishRequest.builder()
                    .message(message)
                    .topicArn(topicArn)
                    .messageGroupId(transactions.get(0).getAccount().getId().toString())
                    .build();
            send(request);
            log.info("Sending Message : {}. to the topic: {}", message, topicArn);
          } catch (Exception ex) {
            log.error(
                "Error while processing collection of payload :{} exception : {}",
                transactions.toString(),
                ex);
          }
        });
  }

  public void publishMessage(T msgData, Map<String, String> attributes, boolean isFifo) {
    try {
      var message = objectMapper.writeValueAsString(msgData);
      log.info("Sending Message : {}. to the topic: {}", message, topicArn);
      Map<String, MessageAttributeValue> msgAttributeMap = new HashMap<>();
      msgAttributeMap.put(
          "event",
          MessageAttributeValue.builder().dataType("String").stringValue("publishEvent").build());
      var generateActivityValue = attributes.get("generateActivity");
      if (msgData instanceof Balance) {
        msgAttributeMap.put(
            "generateActivity",
            MessageAttributeValue.builder()
                .dataType("String")
                .stringValue(generateActivityValue)
                .build());
      }
      PublishRequest request;
      if (isFifo) {
        request =
            PublishRequest.builder()
                .message(message)
                .messageGroupId(attributes.get("messageGroupId"))
                .messageDeduplicationId(attributes.get("messageDeduplicationId"))
                .topicArn(topicArn)
                .messageAttributes(msgAttributeMap)
                .build();
      } else {
        request =
            PublishRequest.builder()
                .message(message)
                .topicArn(topicArn)
                .messageAttributes(msgAttributeMap)
                .build();
      }
      log.info("Publish request = " + request);
      send(request);
    } catch (Exception ex) {
      log.error("Error while processing payload :{} exception : {}", msgData.toString(), ex);
    }
  }

  private void send(PublishRequest request) {
    log.info("Publishing to the topic [{}], message [{}]", topicArn, request.message());
    try {
      snsClient.publish(request);
    } catch (Exception ex) {
      log.error("Error while processing payload:{} exception:{}", request, ex);
      throw new RuntimeException(ex);
    }
  }
}
