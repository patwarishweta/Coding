package com.cwan.privatefund.tabular.service;

import static com.cwan.privatefund.constant.Constants.LPX_CLARITY;
import static com.cwan.privatefund.constant.Constants.LPX_PRISM;
import static com.cwan.privatefund.constant.Constants.OFFSET_TRANSACTION_TYPE;
import static com.cwan.privatefund.tabular.dataset.DataSetUtils.getUltimateParentClientId;

import com.ca.relalg.Column;
import com.ca.relalg.data.DataSet;
import com.cwan.lpx.client.tabular.LPField;
import com.cwan.lpx.client.tabular.LPTransactionField;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.accelex.AccelexField;
import com.cwan.privatefund.accelex.AccelexService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.document.DocumentAuditService;
import com.cwan.privatefund.document.DocumentInfo;
import com.cwan.privatefund.document.LpxDocumentService;
import com.cwan.privatefund.tabular.TabularDataSupplier;
import com.cwan.privatefund.tabular.TransactionRowConverter;
import com.cwan.privatefund.tabular.dataset.DataSetUtils;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.cwan.privatefund.util.DateUtils;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class TabularTransactionService {

  private final LpxTransactionService lpxTransactionService;
  private final AccelexService accelexService;
  private final BusinessWSClient businessWsClient;
  private final LpxDocumentService lpxDocumentService;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private static final int MAX_SUPPORTED_PRISM_TRANSACTION_FIELD_ID = 29;

  public TabularTransactionService(
      LpxTransactionService lpxTransactionService,
      AccelexService accelexService,
      BusinessWSClient businessWsClient,
      LpxDocumentService lpxDocumentService,
      AccountConfigServiceCache accountConfigServiceCache) {
    this.lpxTransactionService = lpxTransactionService;
    this.accelexService = accelexService;
    this.businessWsClient = businessWsClient;
    this.lpxDocumentService = lpxDocumentService;
    this.accountConfigServiceCache = accountConfigServiceCache;
  }

  private Flux<TransactionInfo> getTransactionInfoFlux(Flux<Transaction> transactionFlux) {
    // Fetch DocumentInfo based on Transaction documents
    Flux<DocumentInfo> allDocumentsByAccountAndDateRange =
        lpxDocumentService
            .getDocumentInfos(
                transactionFlux.map(Transaction::getDocument).filter(c -> c.getId() != null))
            .cache();

    Flux<TransactionInfo> noDocumentTransactionInfos =
        transactionFlux
            .filter(tran -> tran.getDocument().getId() == null)
            .map(tran -> new TransactionInfo(tran, null));

    // Map transactions to TransactionInfo by matching DocumentInfo
    Flux<TransactionInfo> hasDocumentTransactionInfos =
        transactionFlux
            .filter(tran -> tran.getDocument().getId() != null)
            .flatMap(
                transaction ->
                    allDocumentsByAccountAndDateRange
                        .filter(x -> !Objects.isNull(x))
                        .filter(tran -> tran.getDocument() != null)
                        .filter(
                            doc ->
                                Objects.equals(
                                    doc.getDocument().getId(), transaction.getDocument().getId()))
                        .collectList()
                        .flatMap(
                            matchingDocs -> {
                              if (!matchingDocs.isEmpty()) {
                                // If there are matching documents, create a TransactionInfo object
                                return Mono.just(
                                    new TransactionInfo(
                                        transaction,
                                        matchingDocs.get(
                                            0))); // You can change how you choose the DocumentInfo
                                // if needed
                              } else {
                                // If no matching documents, return an empty Mono
                                return Mono.just(new TransactionInfo(transaction, null));
                              }
                            }))
            .distinct()
            .collectList()
            .flatMapMany(Flux::fromIterable);

    return Flux.concat(noDocumentTransactionInfos, hasDocumentTransactionInfos);
  }

  public Mono<TabularDataSupplier> getTabularTransactionDataReactive(
      Set<Integer> fieldIds,
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      boolean queryByEntryDate,
      boolean queryByValidationDate,
      boolean offset) {
    List<Integer> header =
        fieldIds.stream().sorted(Comparator.comparingInt(a -> a)).collect(Collectors.toList());
    LocalDateTime asOf = LocalDateTime.now(ZoneId.of("UTC"));
    String excludedTranType = offset ? "" : OFFSET_TRANSACTION_TYPE;

    Flux<TransactionInfo> transactionInfoFlux;
    if (queryByValidationDate) {
      transactionInfoFlux =
          lpxDocumentService
              .getRecentlyValidatedDocuments(beginDate, endDate, accountIds)
              .filter(documentDbInfo -> documentDbInfo.auditEntity() != null)
              .filter(
                  documentDbInfo ->
                      documentDbInfo.documentEntity().getChecked() != null
                          && documentDbInfo.documentEntity().getChecked())
              .collectList() // Collect all documents into a List
              .flatMapMany(
                  documentDbInfos -> {
                    // Extract document IDs
                    Set<Long> documentIds =
                        documentDbInfos.stream()
                            .map(documentDbInfo -> documentDbInfo.documentEntity().getId())
                            .collect(Collectors.toSet());

                    // Fetch all transactions for the collected document IDs at once
                    return lpxTransactionService
                        .getTransactionsByDocumentIds(documentIds)
                        .filter(t -> t.getVersion() != null)
                        .collectList() // Collect transactions into a List
                        .flatMapMany(
                            transactions -> {
                              var latestVersionOfEachTransaction =
                                  transactions.stream()
                                      .collect(
                                          Collectors.toMap(
                                              Transaction::getId,
                                              Function.identity(),
                                              (t1, t2) ->
                                                  t1.getVersion() > t2.getVersion() ? t1 : t2));
                              // Create a map for easy lookup of transactions by document ID
                              Multimap<Long, Transaction> transactionMap =
                                  latestVersionOfEachTransaction.values().stream()
                                      .filter(transaction -> transaction.getDocument() != null)
                                      .collect(
                                          Multimaps.toMultimap(
                                              t -> t.getDocument().getId(),
                                              Function.identity(),
                                              HashMultimap::create));

                              // Now map back to create TransactionInfo for each DocumentInfo
                              return Flux.fromIterable(
                                  documentDbInfos.stream()
                                      .flatMap(
                                          documentDbInfo -> {
                                            Collection<Transaction> transactionsForDoc =
                                                transactionMap.get(
                                                    documentDbInfo.documentEntity().getId());
                                            if (transactionsForDoc.isEmpty()) {
                                              return Stream.empty();
                                            }
                                            return getTransactionInfos(
                                                transactionsForDoc, documentDbInfo)
                                                .stream();
                                          })
                                      .filter(Objects::nonNull)
                                      .toList());
                            });
                  })
              .collectMultimap(
                  transactionInfo -> transactionInfo.transaction.getId(),
                  transactionInfo -> transactionInfo)
              .flatMapMany(
                  transactionIdToAllDocAuditEntries ->
                      Flux.fromIterable(
                          transactionIdToAllDocAuditEntries // Since we're essentially joining on
                              // doc audit we're gonna have extra
                              // entries and we only need the latest
                              // one for each transaction which this
                              // logic attempts to do.
                              .values()
                              .stream()
                              .map(
                                  transactionInfos ->
                                      transactionInfos.stream()
                                          .filter(
                                              f ->
                                                  f.documentInfo()
                                                              .getDocumentAuditValidationEntity()
                                                          != null
                                                      && f.documentInfo()
                                                              .getDocumentAuditValidationEntity()
                                                              .getModifiedOn()
                                                          != null)
                                          .max(
                                              Comparator.comparing(
                                                  g ->
                                                      g.documentInfo()
                                                          .getDocumentAuditValidationEntity()
                                                          .getModifiedOn()))
                                          .orElse(null))
                              .filter(
                                  Objects
                                      ::nonNull) // shouldnt realistically be null here but adding
                              // this just in case.
                              .collect(Collectors.toSet())));

    } else {
      Flux<Transaction> transactionFlux =
          lpxTransactionService
              .getTransactions(
                  accountIds, beginDate, endDate, asOf, excludedTranType, queryByEntryDate, false)
              .cache();

      transactionInfoFlux = getTransactionInfoFlux(transactionFlux);
    }
    return transactionInfoFlux
        .map(transaction -> getRow(transaction, header))
        .collectList()
        .map(data -> TabularDataSupplier.createTransactionDataSupplier(header, data));
  }

  private static List<TransactionInfo> getTransactionInfos(
      Collection<Transaction> transactions, DocumentAuditService.DocumentDbInfo documentDbInfo) {
    List<TransactionInfo> transactionInfos = new ArrayList<>();
    for (Transaction tran : transactions) {
      transactionInfos.add(
          new TransactionInfo(
              tran,
              new DocumentInfo(
                  documentDbInfo.documentEntity(),
                  documentDbInfo.auditEntity(),
                  tran.getDocument())));
    }
    return transactionInfos;
  }

  public DataSet<Column> getAccelexMappedTransactionData(
      LocalDate knowledgeStartDateGreaterThan,
      LocalDate knowledgeStartDateLessThan,
      LocalDateTime knowledgeEndDateGreaterThan,
      Set<Long> accountIds,
      boolean initialLoad)
      throws ExecutionException, InterruptedException {
    accountIds = accountConfigServiceCache.getAllAccountsWithAttribute(accountIds, LPX_CLARITY);

    List<Integer> sortedHeaders =
        Arrays.stream(LPTransactionField.values())
            .map(LPTransactionField::getId)
            .sorted(Comparator.comparingInt(a -> a))
            .toList();
    var activePaborTransactionDataSet =
        getAllTransactionsBetweenDatesAsDataSet(
            knowledgeStartDateGreaterThan,
            knowledgeStartDateLessThan,
            knowledgeEndDateGreaterThan,
            sortedHeaders,
            accountIds); // when accountIds is null, it will return all transactions
    var activeAccelexDataSet =
        accelexService
            .convertTransactionColumnsToAccelexMappingDataSet(activePaborTransactionDataSet)
            .query()
            .extend(row -> "", AccelexField.ACTION) // no action in the case it's an add or update
            .go();
    var inactiveAccelexDataSet = new DataSet<>();

    if (!initialLoad) { // no need to recreate inactive transactions for initial load
      var inactivePaborTransactionDataSet =
          getInactivatedTransactionsBetweenDates(
              knowledgeStartDateGreaterThan, knowledgeStartDateLessThan, accountIds);

      inactiveAccelexDataSet =
          accelexService
              .convertTransactionColumnsToAccelexMappingDataSet(inactivePaborTransactionDataSet)
              .query()
              .extend(row -> "delete", AccelexField.ACTION) // delete if it's been inactivated
              .go();
      activeAccelexDataSet = activeAccelexDataSet.query().unionAll(inactiveAccelexDataSet).go();
    }

    return activeAccelexDataSet;
  }

  public DataSet<Column> getAllPrismTransactionsBetweenDates(
      LocalDate knowledgeStartDateGreaterThan,
      LocalDate knowledgeStartDateLessThan,
      LocalDateTime knowledgeEndDateGreaterThan,
      Set<Long> accountIds)
      throws ExecutionException, InterruptedException {
    List<Integer> sortedHeaders =
        Arrays.stream(LPTransactionField.values())
            .map(LPTransactionField::getId)
            .filter(
                fieldId ->
                    fieldId
                        < MAX_SUPPORTED_PRISM_TRANSACTION_FIELD_ID) // prism can't support new field
            // adds to their schema, so this
            // limits to what currently
            // schema supports
            .sorted(Comparator.comparingInt(a -> a))
            .toList();

    Set<Long> allPrismEnabledSimpleAccounts =
        accountConfigServiceCache.getAllAccountsWithAttribute(accountIds, LPX_PRISM);
    return getAllTransactionsBetweenDatesAsDataSet(
        knowledgeStartDateGreaterThan,
        knowledgeStartDateLessThan,
        knowledgeEndDateGreaterThan,
        sortedHeaders,
        allPrismEnabledSimpleAccounts);
  }

  private DataSet<Column> getAllTransactionsBetweenDatesAsDataSet(
      LocalDate knowledgeStartDateGreaterThan,
      LocalDate knowledgeStartDateLessThan,
      LocalDateTime knowledgeEndDateGreaterThan,
      List<Integer> requestedFields,
      Set<Long> accountIds)
      throws ExecutionException, InterruptedException {

    var transactionFlux =
        lpxTransactionService
            .getTransactions(
                accountIds,
                knowledgeStartDateGreaterThan,
                knowledgeStartDateLessThan,
                knowledgeEndDateGreaterThan,
                OFFSET_TRANSACTION_TYPE,
                false,
                true,
                false)
            .filter(getTransactionPredicate(accountIds));

    Flux<TransactionInfo> transactionInfoFlux = getTransactionInfoFlux(transactionFlux);

    var columnDataSet = convertToDataSet(requestedFields, transactionInfoFlux);
    Set<Long> uniqueAccountIds =
        DataSetUtils.distinctValuesForIntColumn(columnDataSet, LPTransactionField.ACCOUNT_ID)
            .stream()
            .map(Long::valueOf)
            .collect(Collectors.toSet());
    var ultimateParentMapFromAccounts =
        businessWsClient.getUltimateParentMapFromAccounts(uniqueAccountIds).toFuture().get();
    return columnDataSet
        .query()
        .extend(
            row ->
                getUltimateParentClientId(
                    ultimateParentMapFromAccounts, row.getInt(LPTransactionField.ACCOUNT_ID)),
            () -> "ultimateParentClientId")
        .go();
  }

  private static Predicate<Transaction> getTransactionPredicate(Set<Long> accountIds) {
    return transaction ->
        (accountIds == null) || accountIds.contains(transaction.getAccount().getId());
  }

  public DataSet<Column> getInactivatedTransactionsBetweenDates(
      LocalDate knowledgeStartDateGreaterThan,
      LocalDate knowledgeStartDateLessThan,
      Set<Long> accountIds) {
    var transactionFlux =
        lpxTransactionService
            .getTransactionsWithKnowledgeEndDateGreaterThanAndKnowledgeEndDateLessThanAndTypeNotIn(
                knowledgeStartDateGreaterThan.atStartOfDay(),
                DateUtils.atEndOfDay(knowledgeStartDateLessThan),
                Set.of(OFFSET_TRANSACTION_TYPE))
            .filter(getTransactionPredicate(accountIds));

    List<Integer> sortedHeaders =
        Arrays.stream(LPTransactionField.values())
            .map(LPTransactionField::getId)
            .sorted(Comparator.comparingInt(a -> a))
            .collect(Collectors.toList());
    Flux<TransactionInfo> transactionInfoFlux = getTransactionInfoFlux(transactionFlux);
    return convertToDataSet(sortedHeaders, transactionInfoFlux);
  }

  private Iterable<Object> getRow(TransactionInfo transaction, List<Integer> headerFieldIds) {
    var transactionRow = TransactionRowConverter.convertToTransactionRow(transaction);
    return headerFieldIds.stream()
        .map(fieldId -> LPTransactionField.fromId(fieldId).apply(transactionRow))
        .collect(Collectors.toList());
  }

  private List<Object> getRowAsList(TransactionInfo transaction, List<Integer> headerFieldIds) {
    var transactionRow = TransactionRowConverter.convertToTransactionRow(transaction);
    return headerFieldIds.stream()
        .map(fieldId -> LPTransactionField.fromId(fieldId).apply(transactionRow))
        .collect(Collectors.toList());
  }

  private DataSet<Column> convertToDataSet(
      List<Integer> header, Flux<TransactionInfo> transactionFlux) {
    var data =
        transactionFlux
            .map(transaction -> getRowAsList(transaction, header))
            .collectList()
            .share()
            .toFuture()
            .join();
    List<LPField> lpTransactionFields =
        header.stream().map(LPTransactionField::fromId).collect(Collectors.toList());
    return DataSetUtils.convertToDataSet(Objects.requireNonNull(data), lpTransactionFields);
  }

  public record TransactionInfo(Transaction transaction, DocumentInfo documentInfo) {}
}
