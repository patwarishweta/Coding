package com.cwan.privatefund.fxrate;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
// Represents the average fx rate data for a base/account currency
public class AverageFxRateMap {
  // Local/security currencyId -> security's reportingFrequency -> date -> average fx rate
  private Map<Long, Map<ReportingFrequency, Map<LocalDate, Double>>> map;

  public static AverageFxRateMap build(Collection<FXRate> fxRates) {
    return new AverageFxRateMap(
        fxRates.stream()
            .collect(
                Collectors.groupingBy(
                    FXRate::getLocalCurrencyId,
                    Collectors.groupingBy(
                        FXRate::getReportingFrequency,
                        Collectors.toMap(FXRate::getDate, FXRate::getAverageFxRate)))));
  }

  public Map<LocalDate, Double> getRatesForLocalCurrency(
      Long localCurrencyId, ReportingFrequency reportingFrequency) {
    return map.getOrDefault(localCurrencyId, Collections.emptyMap())
        .getOrDefault(reportingFrequency, Collections.emptyMap());
  }

  public Set<Long> getLocalCurrencyIds() {
    return map.keySet();
  }
}
