package com.cwan.privatefund.tabular;

import com.cwan.lpx.client.tabular.TransactionRow;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.tabular.service.TabularTransactionService.TransactionInfo;

public class TransactionRowConverter {

  private TransactionRowConverter() {}

  public static TransactionRow convertToTransactionRow(TransactionInfo transactionInfo) {
    Transaction transaction = transactionInfo.transaction();
    return new TransactionRow(
        transaction.getId(),
        transaction.getAccount().getId().intValue(),
        transaction.getSecurity().getSecurityId().intValue(),
        transaction.getDocument().getId(),
        transaction.getSource(),
        transaction.getTradeDate(),
        transaction.getEntryDate(),
        transaction.getSettleDate(),
        transaction.getKnowledgeStartDate(),
        transaction.getKnowledgeEndDate(),
        transaction.getType(),
        transaction.getSubType(),
        transaction.getCurrency(),
        transaction.getUnit(), // to-do can't update lpx-client version, will be removed once
        // changes are tested, Will not affect anything
        transaction.getPrice(),
        transaction.getFxRate(),
        transaction.getFxCurrency(),
        transaction.getGrossAmount(),
        transaction.getNetAmount(),
        transaction.getCashImpact(),
        transaction.getNavImpact(),
        transaction.getUnfundedCommitmentImpact(),
        transaction.getRecallableImpact(),
        transaction.getInvestmentCompany(),
        transaction.getModifiedOn() != null ? transaction.getModifiedOn().toLocalDate() : null,
        transaction.getFundedCommitmentImpact(),
        transaction.getTotalCommitmentImpact(),
        transaction.getAdditionalNotes(),
        transactionInfo.documentInfo() != null
            && transactionInfo
                .documentInfo()
                .isValidated(), // having no document is considered validated
        transactionInfo.documentInfo() != null
            ? transactionInfo.documentInfo().validationDate() != null
                ? transactionInfo.documentInfo().validationDate().toLocalDate()
                : null
            : null);
  }
}
