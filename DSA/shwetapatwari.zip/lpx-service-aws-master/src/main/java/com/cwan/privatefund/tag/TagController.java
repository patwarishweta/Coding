package com.cwan.privatefund.tag;

import com.cwan.lpx.domain.Tag;
import com.cwan.privatefund.tag.model.DocumentTagsRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/tags")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class TagController {

  private final LpxTagService lpxTagService;

  TagController(LpxTagService lpxTagService) {
    this.lpxTagService = lpxTagService;
  }

  @PutMapping(value = "/document")
  @Operation(summary = "update the tags for the provided documentId to match the passed-in list")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Tag.class))
            })
      })
  public Flux<Tag> updateTagsForDocument(
      @Parameter(description = "update tags for document request") @RequestBody
          DocumentTagsRequest request) {
    return lpxTagService.updateTagsForDocumentId(request.getDocumentId(), request.getTags());
  }
}
