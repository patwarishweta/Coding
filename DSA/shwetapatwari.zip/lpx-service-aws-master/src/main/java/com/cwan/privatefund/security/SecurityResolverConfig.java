package com.cwan.privatefund.security;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class SecurityResolverConfig {

  @Value("${securityResolver.base.server}")
  private String securityResolverServer;

  @Bean(value = "securityResolverWebClient")
  SecurityResolverClient securityResolverWebClient() {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(
            securityResolverServer, 443, "security-resolver-ws", Resource.Scheme.HTTPS);
    return new SecurityResolverClient(WsHttpClientBuilder.getSharedDefault(), serverConfiguration);
  }
}
