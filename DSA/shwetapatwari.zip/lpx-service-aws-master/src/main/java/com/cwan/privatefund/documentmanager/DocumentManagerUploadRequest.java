package com.cwan.privatefund.documentmanager;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.http.codec.multipart.FilePart;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class DocumentManagerUploadRequest {

  private FilePart file;
  private DocumentManagerData documentManagerData;
}
