package com.cwan.privatefund.portfolio.model;

import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CalculationTask {

  private Long accountId;
  private Long securityId;
  private LocalDate asOfDate;
  private List<String> frequency;
  private List<String> calculationTypes;
  private Boolean recalculatePerformanceTillCurrentDate;
}
