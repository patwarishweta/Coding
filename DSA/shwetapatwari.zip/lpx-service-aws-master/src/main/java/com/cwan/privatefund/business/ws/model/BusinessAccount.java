package com.cwan.privatefund.business.ws.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BusinessAccount implements Serializable {

  @Serial private static final long serialVersionUID = -5296774598134863114L;
  private Long id;
  private String name;
  private Boolean multiCurrency;
  private Boolean aggregate;
  private Boolean displayed;
  private Long functionalCurrencyId;
  private String functionalCurrencyCode;
  private Long currencyFxRateSourceId;
  private Long clientId;
  private String sourceAccount;
  private String sourceAccountName;
  private Boolean stat;
  private Boolean simpleWeight;
  private Integer numRatingsRequired;
  private Boolean active;
  private Boolean demo;
  private Boolean naic;
  private Boolean tax;
  private Boolean premiumUseWalForEffectiveMaturity;
  private Boolean discountUseWalForEffectiveMaturity;
  private Boolean tradingReconciled;
  private List<Long> simpleAccountIds;
  private Long ultimateParentId;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  private LocalDate stableDate;

  private Boolean reconciled;
  private Boolean mmfundInterestAccrued;
}
