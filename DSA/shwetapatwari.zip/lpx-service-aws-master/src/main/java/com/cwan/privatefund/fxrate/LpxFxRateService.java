package com.cwan.privatefund.fxrate;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import com.cwan.pbor.fxrate.api.FXRates;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import com.cwan.privatefund.fxrate.source.AccountFxSourceService;
import com.cwan.privatefund.fxrate.source.FxSourceSchedule;
import com.cwan.privatefund.security.currency.SecurityCurrencyService;
import com.cwan.privatefund.security.model.SecurityCurrency;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
public class LpxFxRateService {
  private final FXRates fxRates;
  private final LpxFundMasterService lpxFundMasterService;
  private final SecurityCurrencyService securityCurrencyService;
  private final Transactions transactions;
  private final BusinessWSCache businessWSCache;
  private final AverageFxRateCalculator averageFxRateCalculator;
  private final FxServiceApacheClient fxServiceApacheClient;
  private final AccountFxSourceService accountFxSourceService;

  public LpxFxRateService(
      FXRates fxRates,
      LpxFundMasterService lpxFundMasterService,
      SecurityCurrencyService securityCurrencyService,
      Transactions transactions,
      BusinessWSCache businessWSCache,
      AverageFxRateCalculator averageFxRateCalculator,
      FxServiceApacheClient fxServiceApacheClient,
      AccountFxSourceService accountFxSourceService) {
    this.fxRates = fxRates;
    this.lpxFundMasterService = lpxFundMasterService;
    this.securityCurrencyService = securityCurrencyService;
    this.transactions = transactions;
    this.businessWSCache = businessWSCache;
    this.averageFxRateCalculator = averageFxRateCalculator;
    this.fxServiceApacheClient = fxServiceApacheClient;
    this.accountFxSourceService = accountFxSourceService;
  }

  public AverageFxRateMap getAverageFxRates(Long baseCurrencyId, Long sourceId) {
    Set<FXRate> fxRateSet =
        fxRates.getFxRatesForBaseCurrencyAndSourceId(baseCurrencyId, Set.of(sourceId));
    return AverageFxRateMap.build(fxRateSet);
  }

  // Retrieves average FX rate if it exists in the database, otherwise calculates it
  public Mono<Double> getAverageFxRate(
      Long accountId, Long securityId, Long localCurrencyId, LocalDate date) {
    return businessWSCache
        .getAccountData(accountId)
        .flatMap(
            accountDetail -> {
              ReportingFrequency reportingFrequency =
                  lpxFundMasterService.getReportingFrequency(securityId);

              NavigableMap<LocalDate, List<Long>> sourceSchedule =
                  accountFxSourceService
                      .getFxSourceSchedule(accountId)
                      .getScheduleForBasis(AccountFxSource.NOT_BASIS_SPECIFIC_ID);
              if (sourceSchedule.floorEntry(date) == null) {
                Set<AccountFxSource> accountFxSources =
                    fxServiceApacheClient.getAccountFxSources(accountId);
                accountFxSourceService.updateFxSources(accountFxSources);

                sourceSchedule =
                    FxSourceSchedule.build(accountFxSources)
                        .getScheduleForBasis(AccountFxSource.NOT_BASIS_SPECIFIC_ID);
                if (sourceSchedule.floorEntry(date) == null) {
                  return Mono.empty();
                }
              }
              List<Long> orderedSourceIds = sourceSchedule.floorEntry(date).getValue();
              return Mono.justOrEmpty(
                  getOrCalculateAverageFxRate(
                      orderedSourceIds,
                      accountDetail.getFunctionalCurrencyId(),
                      localCurrencyId,
                      reportingFrequency,
                      date));
            });
  }

  private Double getOrCalculateAverageFxRate(
      List<Long> orderedSourceIds,
      Long baseCurrencyId,
      Long localCurrencyId,
      ReportingFrequency reportingFrequency,
      LocalDate date) {
    for (Long sourceId : orderedSourceIds) {
      Double storedRate =
          getAverageFxRates(baseCurrencyId, sourceId)
              .getRatesForLocalCurrency(localCurrencyId, reportingFrequency)
              .get(date);
      if (storedRate != null) {
        return storedRate;
      }
      FXRate fxRate =
          averageFxRateCalculator.calculateAverageFxRate(
              sourceId, baseCurrencyId, localCurrencyId, reportingFrequency, date);
      if (fxRate != null) {
        fxRates.addFXRates(Set.of(fxRate));
        return fxRate.getAverageFxRate();
      }
    }
    return null;
  }

  // Returns map of basisId -> securityId -> date -> average fx rate
  public Map<Integer, Map<Long, Map<LocalDate, Double>>> getSecurityAverageFxRatesByBasis(
      Long baseCurrencyId, Long accountId) {
    FxSourceSchedule fxSourceSchedule = accountFxSourceService.getFxSourceSchedule(accountId);

    if (fxSourceSchedule.getBasisIds().isEmpty()) {
      return Map.of();
    }

    // Only return data for securities that are associated with the account
    Set<Long> securityIds =
        transactions.getTransactionsByAccountIdsNonReactive(Set.of(accountId)).stream()
            .map(tran -> tran.getSecurity().getSecurityId())
            .collect(Collectors.toSet());

    if (securityIds.isEmpty()) {
      return Map.of();
    }

    Map<Integer, Map<Long, Map<LocalDate, Double>>> averageFxRateMapByBasis = new HashMap<>();

    for (Integer basisId : fxSourceSchedule.getBasisIds()) {
      NavigableMap<LocalDate, List<Long>> sourceScheduleForBasis =
          fxSourceSchedule.getScheduleForBasis(basisId);
      Set<Long> sourceIds =
          sourceScheduleForBasis.values().stream()
              .flatMap(List::stream)
              .collect(Collectors.toSet());

      Set<FXRate> fxRateSet =
          fxRates.getFxRatesForBaseCurrencyAndSourceId(baseCurrencyId, sourceIds);
      Set<FXRate> fxRatesToUse = getHighestRankedFxRates(fxRateSet, sourceScheduleForBasis);
      if (fxRatesToUse.isEmpty()) {
        continue;
      }

      Map<Long, Map<LocalDate, Double>> securityAverageFxRates =
          getSecurityAverageFxRates(AverageFxRateMap.build(fxRatesToUse), securityIds);
      averageFxRateMapByBasis.put(basisId, securityAverageFxRates);
    }
    return averageFxRateMapByBasis;
  }

  // Given a set of FX rates, reduce the set down to a maximum of one FXRate object per
  // Date/LocalCurrencyId/ReportingFrequency combination.
  // Only return FX rates that have a sourceId that matches the sourceSchedule.
  // When a Date/LocalCurrencyId/ReportingFrequency combination has more than one applicable FX
  // rate, choose the one that was calculated using the highest ranking sourceId
  private Set<FXRate> getHighestRankedFxRates(
      Set<FXRate> fxRateSet, NavigableMap<LocalDate, List<Long>> sourceSchedule) {
    Map<FxRateGroupKey, Map<Long, FXRate>> ratesByKeyAndSource =
        fxRateSet.stream()
            .collect(
                Collectors.groupingBy(
                    FxRateGroupKey::new,
                    Collectors.toMap(FXRate::getFxRateSourceId, Function.identity())));

    Set<FXRate> highestRankedFxRates = new HashSet<>();
    for (FxRateGroupKey key : ratesByKeyAndSource.keySet()) {
      Entry<LocalDate, List<Long>> sourceEntry = sourceSchedule.floorEntry(key.getDate());
      if (sourceEntry == null) {
        continue;
      }
      Map<Long, FXRate> rateBySource = ratesByKeyAndSource.get(key);
      for (Long sourceId : sourceEntry.getValue()) {
        FXRate fxRate = rateBySource.get(sourceId);
        if (fxRate != null) {
          highestRankedFxRates.add(fxRate);
          break;
        }
      }
    }
    return highestRankedFxRates;
  }

  private Map<Long, Map<LocalDate, Double>> getSecurityAverageFxRates(
      AverageFxRateMap averageFxRateMap, Set<Long> allowedSecurityIds) {
    if (allowedSecurityIds.isEmpty()) {
      return Map.of();
    }

    // Get map of securities that have currency data and are allowed
    Map<Long, Long> securityToCurrency =
        securityCurrencyService
            .findAllByCurrencyIdIn(averageFxRateMap.getLocalCurrencyIds())
            .stream()
            .filter(
                securityCurrency -> allowedSecurityIds.contains(securityCurrency.getSecurityId()))
            .collect(
                Collectors.toMap(SecurityCurrency::getSecurityId, SecurityCurrency::getCurrencyId));

    Map<Long, ReportingFrequency> securityToFrequency =
        lpxFundMasterService.getReportingFrequencies(securityToCurrency.keySet());

    // Convert averageFxRates map to use securityId in place of localCurrencyId and
    // reportingFrequency
    Map<Long, Map<LocalDate, Double>> mapToReturn = new HashMap<>();
    for (Entry<Long, Long> entry : securityToCurrency.entrySet()) {
      Long securityId = entry.getKey();
      Long localCurrencyId = entry.getValue();

      Map<LocalDate, Double> securityRates =
          averageFxRateMap.getRatesForLocalCurrency(
              localCurrencyId, securityToFrequency.get(securityId));

      // inverts value of map so the rate returned to AWS can be multiplied by the local value of
      // the field
      Map<LocalDate, Double> securityRateMultiplierMap =
          securityRates.entrySet().stream()
              .collect(
                  Collectors.toMap(
                      Entry::getKey, e -> e.getValue() == 0.0 ? 0.0 : 1 / e.getValue()));

      if (!securityRates.isEmpty()) {
        mapToReturn.put(securityId, securityRateMultiplierMap);
      }
    }
    return mapToReturn;
  }
}
