package com.cwan.privatefund.portfolio.model;

import com.cwan.privatefund.portfolio.PortfolioBalance;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PortfolioSummaryResponse {

  private List<PortfolioBalance> data;
  private AggregatePortfolioData agg;
}
