package com.cwan.privatefund.salesforce.config;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class SaleForceUtils {

  private static final String BEARER = "Bearer ";
  public static final String AUTHORIZATION = "Authorization";

  private SaleForceUtils() {
    // Private Constructor has been created to prevent build issues on Sonar.
  }

  public static HttpHeaders createHttpHeaders(MediaType mediaType, String authToken) {
    var httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(mediaType);
    if (authToken != null) {
      httpHeaders.set(AUTHORIZATION, BEARER + authToken);
    }
    return httpHeaders;
  }

  public static <T, R> ResponseEntity<R> makeRequest(
      RestTemplate restTemplate,
      String url,
      HttpMethod method,
      HttpEntity<T> entity,
      Class<R> responseType) {
    return restTemplate.exchange(url, method, entity, responseType);
  }
}
