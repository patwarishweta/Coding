package com.cwan.privatefund.serializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;

/** Deserializer to normalize and trim JSON string values. */
public class NormalizedStringDeserializer extends JsonDeserializer<String> {

  /**
   * Returns the normalized string or {@code null} if empty after trimming.
   *
   * @param jsonParser the JSON parser
   * @param ctx the deserialization context
   * @return normalized string or null
   * @throws IOException if deserialization error occurs
   */
  @Override
  public String deserialize(JsonParser jsonParser, DeserializationContext ctx) throws IOException {
    return StringUtils.normalizeSpace(StringUtils.trimToNull(jsonParser.getValueAsString()));
  }
}
