package com.cwan.privatefund.clientSpecificData;

import com.cwan.lpx.domain.ClientSpecificData;
import com.cwan.pbor.clientspecific.FundService;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class LpxClientSpecificDataService {
  private final FundService fundService;

  public LpxClientSpecificDataService(FundService fundService) {
    this.fundService = fundService;
  }

  public List<ClientSpecificData> saveClientSpecificData(
      Set<ClientSpecificData> clientSpecificData) {
    return fundService.upsertClientSpecificData(clientSpecificData);
  }
}
