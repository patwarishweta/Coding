package com.cwan.privatefund.documentmanager;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.concurrent.ExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/document-manager")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class LpxDocumentManagerController {

  private final LpxDocumentManagerService lpxDocumentManagerService;

  LpxDocumentManagerController(LpxDocumentManagerService lpxDocumentManagerService) {
    this.lpxDocumentManagerService = lpxDocumentManagerService;
  }

  @GetMapping(value = "/account/{accountId}/tag/{tag}")
  @Operation(summary = "get all active documents by account id and tag")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Flux<DocumentManagerData> getActiveDocumentsByAccountIdAndTag(
      @PathVariable("accountId") Long accountId, @PathVariable("tag") String tag) {
    return lpxDocumentManagerService.getActiveDocumentsByAccountIdAndTag(accountId, tag);
  }

  @GetMapping(value = "/account/{accountId}/name/{name}")
  @Operation(summary = "get all active documents by account id and file name")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Flux<DocumentManagerData> getActiveDocumentsByAccountIdAndFileName(
      @PathVariable("accountId") Long accountId, @PathVariable("name") String name) {
    return lpxDocumentManagerService.getActiveDocumentsByAccountIdAndFileName(accountId, name);
  }

  @GetMapping(value = "/directory/{directoryId}")
  @Deprecated
  @Operation(summary = "get all active documents by directory id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Flux<DocumentManagerData> getActiveDocumentsByDirectoryId(
      @PathVariable("directoryId") Long directoryId) {
    return lpxDocumentManagerService.getActiveDocumentsByDirectoryId(directoryId);
  }

  @GetMapping(value = "/account/{accountId}/disabled")
  @Operation(summary = "get all disabled documents under an account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Flux<DocumentManagerData> getDisabledDocumentsForAccount(
      @PathVariable("accountId") Long accountId) throws ExecutionException, InterruptedException {
    return lpxDocumentManagerService.getDisabledDocumentsForAccount(accountId);
  }

  @GetMapping(value = "/account/{accountId}/active")
  @Operation(summary = "get all active documents under an account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Flux<DocumentManagerData> getActiveDocumentsForAccount(
      @PathVariable("accountId") Long accountId) throws ExecutionException, InterruptedException {
    return lpxDocumentManagerService.getActiveDocumentsForAccount(accountId);
  }

  @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Upload file and metadata for document")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Created document successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Mono<DocumentManagerData> saveDocument(
      @ModelAttribute DocumentManagerUploadRequest request) {
    return lpxDocumentManagerService.saveNewDocument(
        request.getFile(), request.getDocumentManagerData());
  }

  @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Upload file and metadata for document")
  @ApiResponses(
      value = {@ApiResponse(responseCode = "201", description = "Created document successfully")})
  public Mono<ResponseEntity<DocumentUploadResponse>> uploadDocument(
      @ModelAttribute DocumentUploadRequest request) {
    if (request != null && (request.getFiles() == null || request.getFiles().isEmpty())) {
      return Mono.error(
          new ResponseStatusException(HttpStatus.BAD_REQUEST, "files cannot be null or empty"));
    }
    return lpxDocumentManagerService.uploadDocument(request);
  }

  @GetMapping(value = "/account/{accountId}/no-directory")
  @Deprecated
  @Operation(
      summary =
          "get all active documents that are not under a directory and are under the given accountId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentManagerData.class))
            })
      })
  public Flux<DocumentManagerData> getActiveDocumentsWithoutDirectoryByAccount(
      @PathVariable("accountId") Long accountId) {
    return lpxDocumentManagerService.getActiveDocumentsWithoutDirectoryByAccount(accountId);
  }
}
