package com.cwan.privatefund.config;

import com.ca.notification.client.NotificationClient;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.resource.Resource.Scheme;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Configuration class for setting up notification-related beans. */
@Configuration
public class NotificationConfig {

  @Value("${notification.email.host}")
  private String host;

  @Value("${notification.email.port}")
  private Integer port;

  @Value("${notification.email.scheme}")
  private String scheme;

  @Value("${notification.email.basePath}")
  private String basePath;

  /**
   * Creates and returns a ServerConfiguration object for notifications.
   *
   * @return ServerConfiguration for notifications.
   */
  @Bean(value = "notificationServerConfiguration")
  public ServerConfiguration notificationServerConfiguration() {
    Scheme resolvedScheme;
    try {
      resolvedScheme = Scheme.valueOf(scheme);
    } catch (IllegalArgumentException e) {
      resolvedScheme = Scheme.HTTPS;
    }
    return new ServerConfiguration(host, port, basePath, resolvedScheme);
  }

  /**
   * Creates and returns a NotificationClient object for notifications.
   *
   * @param notificationServerConfiguration The server configuration to use.
   * @return NotificationClient for notifications.
   */
  @Bean
  public NotificationClient notificationClient(
      ServerConfiguration notificationServerConfiguration) {
    return new NotificationClient(notificationServerConfiguration);
  }
}
