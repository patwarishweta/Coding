package com.cwan.privatefund.basis.ws;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.resource.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BasisWSConfig {

  public static final String ACCOUNT_ID_TO_BASES = "account_id_to_bases";
  public static final String BASIS_ID_TO_BASES = "basis_id_to_bases";

  @Value("${basis.ws.base.server}")
  private String basisWsBaseServer;

  @Bean(value = "basisWsServerConfiguration")
  public ServerConfiguration basisWsServerConfiguration() {
    return new ServerConfiguration(basisWsBaseServer, 443, "basis-ws", Resource.Scheme.HTTPS);
  }
}
