package com.cwan.privatefund.financialstatement;

import com.cwan.lpx.domain.FinancialStatement;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.fs.api.FinancialReports;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import com.google.common.annotations.VisibleForTesting;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class FinancialStatementService {
  private final FinancialReports financialReports;
  private final SecurityService securityService;
  private final Documents documents;
  private final AccountService accountService;

  public FinancialStatementService(
      FinancialReports financialReports,
      AccountService accountService,
      SecurityService securityService,
      Documents documents) {
    this.financialReports = financialReports;
    this.accountService = accountService;
    this.securityService = securityService;
    this.documents = documents;
  }

  public Flux<FinancialStatement> getFinancialStatementsByIds(Set<Long> reportIds) {
    return hydrateSADData(financialReports.getReportsByIds(reportIds));
  }

  public Flux<FinancialStatement> getFinancialStatementsByDocumentId(Long id) {
    return hydrateSADData(financialReports.getAllFinancialStatementsByDocumentId(id));
  }

  @VisibleForTesting
  protected Flux<FinancialStatement> hydrateSADData(
      Flux<FinancialStatement> financialStatementFlux) {
    return financialStatementFlux
        .flatMap(this::addAccountDataToFinancialStatement)
        .flatMap((this::addSecurityDataToFinancialStatement))
        .flatMap(this::addDocumentDataToFinancialStatement);
  }

  @VisibleForTesting
  protected Mono<FinancialStatement> addSecurityDataToFinancialStatement(
      FinancialStatement financialStatement) {
    return securityService
        .getSecurity(
            financialStatement.getAccount().getClientId(),
            financialStatement.getAccount().getId(),
            financialStatement.getSecurity().getSecurityId())
        .map(security -> financialStatement.toBuilder().security(security).build());
  }

  @VisibleForTesting
  protected Mono<FinancialStatement> addAccountDataToFinancialStatement(
      FinancialStatement financialStatement) {
    return accountService
        .getAccountData(financialStatement.getAccount().getId())
        .map(account -> financialStatement.toBuilder().account(account).build());
  }

  @VisibleForTesting
  protected Mono<FinancialStatement> addDocumentDataToFinancialStatement(
      FinancialStatement financialStatement) {
    if (null != financialStatement.getDocument()
        && null != financialStatement.getDocument().getId()) {
      return documents
          .getDocumentById(financialStatement.getDocument().getId())
          .map(document -> financialStatement.toBuilder().document(document).build());
    }
    return Mono.just(financialStatement);
  }
}
