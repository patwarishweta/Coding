package com.cwan.privatefund.security.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityResponse implements Serializable {

  @Serial private static final long serialVersionUID = -6236645373685206131L;

  @JsonProperty("SecurityMaster")
  private SecurityMasterData securityMasterData;

  @JsonProperty("FundMaster")
  private FundMasterData fundMasterData;

  @JsonProperty("SecurityTypeData")
  private SecurityTypeData securityTypeData;

  @JsonProperty("derived")
  private Derived derived;

  @JsonProperty("securityId")
  private Long securityId;
}
