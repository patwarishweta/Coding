package com.cwan.privatefund.document;

import com.cwan.lpx.domain.Document;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.privatefund.document.model.DocumentAuditValidationEntity;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocumentInfo {

  private DocumentEntity documentEntity;
  private DocumentAuditValidationEntity documentAuditValidationEntity;
  private Document document;

  public boolean isValidated() {
    if (documentEntity == null) {
      return false;
    }
    return Optional.ofNullable(documentEntity.getChecked()).orElse(false);
  }

  public LocalDateTime validationDate() {
    if (documentAuditValidationEntity == null
        || documentAuditValidationEntity.getModifiedOn() == null
        || !isValidated()) {
      return null;
    }
    return documentAuditValidationEntity.getModifiedOn();
  }
}
