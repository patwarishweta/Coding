package com.cwan.privatefund.capital.call.helper;

import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import reactor.core.publisher.Mono;

@Slf4j
public final class LpxCapitalCallManagementHelper {

  public static Mono<Void> checkUserAccessToAccount(
      Set<Long> userAccounts, Long accountId, long userId) {
    if (!userAccounts.contains(accountId)) {
      log.error(
          "User {} does not have access to the specified account with ID: {}", userId, accountId);
      return Mono.error(
          new AccessDeniedException(
              "Access denied. You do not have permission to access this account."));
    }
    return Mono.empty();
  }

  private LpxCapitalCallManagementHelper() {
    // Adding a private constructor to hide the implicit public one.
  }
}
