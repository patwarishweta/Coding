package com.cwan.privatefund.security;

import static com.cwan.privatefund.constant.RedisConstants.SECURITY;

import com.cwan.privatefund.security.model.SecurityRequest;
import com.cwan.privatefund.security.model.SecurityResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class SecurityCache {

  private final SecurityClient securityClient;

  private final RedisTemplate<String, Object> redisTemplate;

  public SecurityCache(SecurityClient securityClient, RedisTemplate<String, Object> redisTemplate) {
    this.securityClient = securityClient;
    this.redisTemplate = redisTemplate;
  }

  public Mono<SecurityResponse> getSecurityById(SecurityRequest req, Long securityId) {
    var securityResponses = (SecurityResponse) redisTemplate.opsForHash().get(SECURITY, securityId);
    if (securityResponses != null) {
      log.info("Found in security cache");
      return Mono.just(securityResponses);
    }
    log.info("Not found in security cache. Send request to security client");
    return securityClient
        .getSecurityInformation(req)
        .filter(responses -> !responses.isEmpty())
        .<SecurityResponse>handle(
            (responses, sink) -> {
              if (responses.size() > 1) {
                sink.error(
                    new SecurityException(
                        "There is more than one security response for securityId= " + securityId));
                return;
              }
              sink.next(responses.get(0));
            })
        .doOnNext(response -> redisTemplate.opsForHash().put(SECURITY, securityId, response));
  }

  private Mono<List<SecurityResponse>> updateSecurityCache(SecurityRequest securityRequest) {
    return securityClient
        .getSecurityInformation(securityRequest)
        .filter(responses -> !responses.isEmpty())
        .map(
            responses -> {
              var securityMap =
                  responses.stream()
                      .collect(
                          Collectors.toMap(
                              SecurityResponse::getSecurityId, Function.identity(), (x, y) -> y));
              redisTemplate.opsForHash().putAll(SECURITY, securityMap);
              return responses;
            })
        .defaultIfEmpty(List.of());
  }

  public Mono<List<SecurityResponse>> getSecurities(SecurityRequest securityRequest) {
    log.info("getSecurities cache {}", securityRequest);
    if (securityRequest == null) {
      return Mono.empty();
    }

    var securityIds = securityRequest.getSecurityIds();

    if ((securityIds == null || securityIds.isEmpty())
        && (securityRequest.getAccountId() != null || securityRequest.getClientId() != null)) {
      log.info("No securityIds found in request {}", securityRequest);
      return updateSecurityCache(securityRequest)
          .onErrorResume(
              throwable -> {
                log.error(
                    "Exception when no securityIds sent {}", throwable.getMessage(), throwable);
                return Mono.empty();
              });
    }

    AtomicBoolean missingSecurityFlag = new AtomicBoolean(false);
    Map<Long, SecurityResponse> securityResponseMap =
        securityIds.parallelStream()
            .collect(
                HashMap::new,
                (map, secId) -> {
                  SecurityResponse securityResponse =
                      (SecurityResponse) redisTemplate.opsForHash().get(SECURITY, secId);
                  if (securityResponse == null) {
                    missingSecurityFlag.set(true);
                  }
                  map.put(secId, securityResponse);
                },
                HashMap::putAll);

    if (Boolean.FALSE.equals(missingSecurityFlag.get())) {
      return Mono.just(List.copyOf(securityResponseMap.values()));
    }

    List<Long> missingSecurityIds = new ArrayList<>();
    securityResponseMap
        .entrySet()
        .removeIf(
            e -> {
              if (e.getValue() == null) {
                missingSecurityIds.add(e.getKey());
                return true;
              }
              return false;
            });

    log.info("getSecurities :: Few security missing in cache {}", missingSecurityIds);

    SecurityRequest missingSecurityReq =
        SecurityRequest.builder()
            .accountId(securityRequest.getAccountId())
            .securityIds(missingSecurityIds)
            .clientId(securityRequest.getClientId())
            .fieldsBySource(securityRequest.getFieldsBySource())
            .build();

    return updateSecurityCache(missingSecurityReq)
        .doOnNext(
            res ->
                log.info("{} Total Missing Securities Loaded {}", missingSecurityReq, res.size()))
        .map(
            secResponses -> {
              Map<Long, SecurityResponse> missingResponse =
                  secResponses.stream()
                      .collect(
                          Collectors.toMap(
                              SecurityResponse::getSecurityId, Function.identity(), (x, y) -> y));
              securityResponseMap.putAll(missingResponse);
              return List.copyOf(securityResponseMap.values());
            });
  }

  public Mono<SecurityResponse> getSecurity(SecurityRequest req, Long securityId) {
    return securityClient
        .getSecurityInformation(req)
        .filter(responses -> !responses.isEmpty())
        .<SecurityResponse>handle(
            (responses, sink) -> {
              if (responses.size() > 1) {
                sink.error(
                    new SecurityException(
                        "There is more than one security response for securityId= " + securityId));
                return;
              }
              sink.next(responses.get(0));
            })
        .doOnNext(response -> redisTemplate.opsForHash().put(SECURITY, securityId, response));
  }
}
