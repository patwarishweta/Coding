package com.cwan.privatefund.business.ws.model;

import java.util.Set;

public record UserAccounts(Integer userId, Set<Long> accountIds) {}
