package com.cwan.privatefund.tag;

import com.cwan.pbor.tag.TagEntity;
import com.cwan.pbor.tag.TagRepository;
import java.util.Collection;
import org.springframework.stereotype.Repository;

@Repository
public interface LpxTagRepository extends TagRepository {

  Collection<TagEntity> findAllByTagContainingIgnoreCase(String tag);
}
