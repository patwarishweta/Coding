package com.cwan.privatefund.calculated;

import static com.cwan.lpx.client.tabular.BalanceType.CUM_CONTRIBUTION;
import static com.cwan.lpx.client.tabular.BalanceType.CUM_DISTRIBUTION;
import static com.cwan.lpx.client.tabular.BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION;
import static com.cwan.lpx.client.tabular.BalanceType.WATCHLIST_ENDING_NAV;
import static com.cwan.lpx.client.tabular.BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT;
import static com.cwan.lpx.domain.ConfigAttributes.TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE;
import static com.cwan.privatefund.constant.Constants.ECONOMIC_NAV_SUB_TYPE;
import static com.cwan.privatefund.constant.Constants.EXCLUDE_HISTORIC_TRANSACTIONS_FOR_CONTRIBUTION;
import static com.cwan.privatefund.constant.Constants.WATCHLIST_NAV_SUB_TYPE;

import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.trans.Constants.TransactionBasisAffects;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.calculated.model.BalanceSchedule;
import com.cwan.privatefund.calculated.model.BalanceScheduleKey;
import com.cwan.privatefund.calculated.model.BalanceTypeKey;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient;
import com.cwan.privatefund.pricing.PricingOverrideService;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.cwan.privatefund.transaction.model.NavSchedules;
import com.cwan.privatefund.util.DateUtils;
import com.cwan.privatefund.watchlist.WatchlistService;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class CalculatedBalanceService {

  protected static final LocalDate MIN_DATE = LocalDate.of(1753, 1, 1);
  protected static final BalanceTypeKey ALL_NAV_SCHEDULE =
      new BalanceTypeKey(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, TransactionBasisAffects.ALL);
  protected static final BalanceTypeKey WATCHLIST_NAV_SCHEDULE =
      new BalanceTypeKey(WATCHLIST_ENDING_NAV, TransactionBasisAffects.ALL);
  protected static final BalanceTypeKey WATCHLIST_WITH_ADJUSTMENTS_NAV_SCHEDULE =
      new BalanceTypeKey(WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, TransactionBasisAffects.ALL);
  protected static final BalanceTypeKey GAAP_NAV_SCHEDULE =
      new BalanceTypeKey(WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, TransactionBasisAffects.GAAP);
  protected static final BalanceTypeKey STAT_NAV_SCHEDULE =
      new BalanceTypeKey(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, TransactionBasisAffects.STAT);
  private final BalanceScheduleService balanceScheduleService;
  private final LpxTransactionService lpxTransactionService;
  private final PricingOverrideService pricingOverrideService;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final AccountService accountService;
  private final WatchlistService watchlistService;
  private final PortfolioWsApacheClient portfolioService;

  public CalculatedBalanceService(
      BalanceScheduleService balanceScheduleService,
      LpxTransactionService lpxTransactionService,
      PricingOverrideService pricingOverrideService,
      AccountConfigServiceCache accountConfigServiceCache,
      AccountService accountService,
      WatchlistService watchlistService,
      PortfolioWsApacheClient portfolioService) {
    this.balanceScheduleService = balanceScheduleService;
    this.lpxTransactionService = lpxTransactionService;
    this.pricingOverrideService = pricingOverrideService;
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.accountService = accountService;
    this.watchlistService = watchlistService;
    this.portfolioService = portfolioService;
  }

  public Flux<CalculatedBalance> calculateBalances(
      long accountId, LocalDate settleEndDate, LocalDate knowledgeAsOf, boolean forAccounting) {
    Set<BalanceType> balanceTypes =
        Set.of(
            BalanceType.FUNDED_COMMITMENT,
            BalanceType.REPORTED_RECALLABLE_DISTRIBUTION,
            BalanceType.REPORTED_TOTAL_COMMITMENT,
            BalanceType.REPORTED_ENDING_NAV,
            BalanceType.WATCHLIST_ENDING_NAV,
            BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT,
            BalanceType.CUM_CONTRIBUTION,
            BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION,
            BalanceType.CUM_DISTRIBUTION);
    return accountService
        .expandAccountId(accountId)
        .onErrorResume(Mono::error)
        .collectList()
        .flatMapMany(
            accountIds -> {
              log.info(
                  "getting calculated balances for accountId: {}, asOfDate: {}, knowledgeDate: {}",
                  accountId,
                  settleEndDate,
                  knowledgeAsOf);
              return calculate(
                  accountId,
                  accountIds,
                  MIN_DATE,
                  settleEndDate,
                  knowledgeAsOf,
                  balanceTypes,
                  forAccounting);
            })
        .flatMap(
            balanceSchedules ->
                getCalculatedBalances(
                    balanceSchedules, settleEndDate == null ? LocalDate.now() : settleEndDate));
  }

  public Flux<NavSchedules> getNavSchedule(
      Long accountId,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeDate,
      boolean forAccounting) {
    Set<BalanceType> balanceTypes =
        Set.of(
            BalanceType.REPORTED_ENDING_NAV,
            BalanceType.WATCHLIST_ENDING_NAV,
            BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT);
    return accountService
        .expandAccountId(accountId)
        .onErrorResume(Mono::error)
        .collectList()
        .flatMapMany(
            accIds ->
                calculate(
                    accountId,
                    accIds,
                    beginDate,
                    endDate,
                    knowledgeDate,
                    balanceTypes,
                    forAccounting))
        .flatMap(
            transactionBalanceScheduleMap ->
                Flux.fromIterable(transactionBalanceScheduleMap.entrySet()))
        .map(
            entry -> {
              NavigableMap<LocalDate, Double> navSchedule;
              if (hasWatchlistBalance(
                  entry.getValue().getScheduleByType().get(WATCHLIST_NAV_SCHEDULE))) {
                navSchedule =
                    entry
                        .getValue()
                        .getScheduleByType()
                        .get(WATCHLIST_WITH_ADJUSTMENTS_NAV_SCHEDULE);
              } else {
                navSchedule = entry.getValue().getScheduleByType().get(ALL_NAV_SCHEDULE);
              }
              return NavSchedules.builder()
                  .accountId(entry.getKey().getAccount().getId())
                  .securityId(entry.getKey().getSecurity().getSecurityId())
                  .navSchedule(navSchedule)
                  .gaapNavSchedule(
                      entry
                          .getValue()
                          .getScheduleByType()
                          .get(GAAP_NAV_SCHEDULE)) // should be watchlist_gaap now
                  .statNavSchedule(
                      entry
                          .getValue()
                          .getScheduleByType()
                          .get(STAT_NAV_SCHEDULE)) // should be watchlist_stat now
                  .build();
            });
  }

  // Returns an updated version of the passed-in accountIdToTransactions map.
  // The updated map will contain transactions with settleDate=knowledgeStartDate for accounts that
  // have this feature enabled.
  private Mono<Map<Long, List<Transaction>>> accountForNavKnowledgeDate(
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeAsOf,
      Flux<AccountConfig> accountConfigs,
      Map<Long, List<Transaction>> accountIdToTransactions) {

    Mono<Map<Long, LocalDate>> accountIdToFeatureDate =
        getAccountIdToTreatKnowledgeDateAsSettle(accountConfigs);

    Mono<Map<Long, List<Transaction>>> accountIdToNavTransactions =
        accountIdToFeatureDate.flatMap(
            featureDateMap ->
                getAccountIdToNavTransactions(featureDateMap, beginDate, endDate, knowledgeAsOf));

    return accountIdToNavTransactions.flatMap(
        navTranMap -> {
          List<Long> navTranIds =
              navTranMap.values().stream().flatMap(List::stream).map(Transaction::getId).toList();

          return Mono.just(accountIdToTransactions)
              .flatMap(
                  nonNavTranMap -> {
                    // Filter duplicate transactions out of existing map - we want to use
                    // the NAV versions
                    Map<Long, List<Transaction>> filteredNonNavTranMap =
                        nonNavTranMap.values().stream()
                            .flatMap(List::stream)
                            .filter(t -> !navTranIds.contains(t.getId()))
                            .collect(Collectors.groupingBy(t -> t.getAccount().getId()));

                    // Merge the passed-in map (with NAV transactions filtered out) with the
                    // NAV transaction map
                    return Mono.just(mergeMaps(filteredNonNavTranMap, navTranMap));
                  });
        });
  }

  private Mono<Map<Long, LocalDate>> getAccountIdToTreatKnowledgeDateAsSettle(
      Flux<AccountConfig> accountConfigs) {
    return accountConfigs
        .collectMap(config -> config.getAccount().getId(), this::getTreatKnowledgeDateAsSettleDate)
        .flatMapMany(map -> Flux.fromIterable(map.entrySet()))
        // Filter out accounts that are not using the feature
        .filter(entry -> entry.getValue() != null)
        .collectMap(Map.Entry::getKey, Map.Entry::getValue);
  }

  private Mono<Map<Long, List<Transaction>>> getAccountIdToNavTransactions(
      Map<Long, LocalDate> accountIdToTreatKnowledgeDateAsSettle,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeAsOf) {

    List<Long> accountIds = accountIdToTreatKnowledgeDateAsSettle.keySet().stream().toList();

    return lpxTransactionService
        .getNavTransactions(accountIds, beginDate, endDate, knowledgeAsOf)
        .onErrorResume(Mono::error)
        .filter(Transaction::getIsCurrent)
        .filter(
            t ->
                !t.getKnowledgeStartDate()
                    .toLocalDate()
                    .isBefore(accountIdToTreatKnowledgeDateAsSettle.get(t.getAccount().getId())))
        .groupBy(tran -> tran.getAccount().getId())
        .flatMap(
            groupedFlux ->
                groupedFlux.collectList().map(list -> Map.entry(groupedFlux.key(), list)))
        .collectMap(Entry::getKey, Entry::getValue);
  }

  private Map<Long, List<Transaction>> mergeMaps(
      Map<Long, List<Transaction>> map1, Map<Long, List<Transaction>> map2) {
    map2.forEach(
        (key, value) ->
            map1.merge(
                key,
                value,
                (list1, list2) -> {
                  list1.addAll(list2);
                  return list1;
                }));
    return map1;
  }

  private LocalDate getTreatKnowledgeDateAsSettleDate(AccountConfig accountConfig) {
    Map<String, String> attributeMap = accountConfig.getAttributes();
    attributeMap = attributeMap == null ? Collections.emptyMap() : attributeMap;
    String featureDateString = attributeMap.get(TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE.toString());
    return featureDateString != null && !featureDateString.isEmpty()
        ? LocalDate.parse(featureDateString, DateTimeFormatter.ISO_DATE)
        : null;
  }

  private Flux<Map<BalanceScheduleKey, BalanceSchedule>> calculate(
      Long parentAccountId,
      List<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeAsOf,
      Set<BalanceType> balanceTypes,
      boolean forAccounting) {
    LocalDate finalEndDate = endDate == null ? LocalDate.now() : endDate;
    log.info(
        "Calculating balance for parentAccountId: {}, accountIds: {}, asOfDate: {}, and knowledgeDate: {}",
        parentAccountId,
        accountIds,
        endDate,
        knowledgeAsOf);

    Flux<AccountConfig> accountConfigs =
        accountConfigServiceCache
            .getAccountConfigs(accountIds, LocalDate.now())
            .onErrorResume(Mono::error)
            .flatMapMany(Flux::fromIterable);

    Mono<Map<Long, List<Transaction>>> accountIdToTransactions =
        accountConfigs
            .collectList()
            .flatMap(
                configs -> {
                  Map<Long, LocalDate> accountIdToSubscriptionStartDate =
                      configs.stream()
                          .collect(
                              Collectors.toMap(
                                  config -> config.getAccount().getId(),
                                  AccountConfig::getSubscriptionStartDate));
                  log.info(
                      "Retrieving transactions under {} accounts for calculating balances, for parentAccountId: {}, beginDate: {}, endDate: {}",
                      accountIdToSubscriptionStartDate.size(),
                      parentAccountId,
                      beginDate,
                      finalEndDate);

                  return lpxTransactionService.getTransactionsForCalculatingBalances(
                      parentAccountId,
                      List.copyOf(accountIdToSubscriptionStartDate.keySet()),
                      beginDate,
                      finalEndDate,
                      DateUtils.atEndOfDay(knowledgeAsOf != null ? knowledgeAsOf : LocalDate.now()),
                      forAccounting);
                })
            .map(
                txnsList ->
                    txnsList.stream()
                        .collect(
                            Collectors.groupingByConcurrent(
                                tran -> tran.getAccount().getId(),
                                Collectors.mapping(
                                    transaction -> transaction, Collectors.toList()))))
            .flatMap(
                accTxnMap -> {
                  if (forAccounting) {
                    return accountForNavKnowledgeDate(
                        beginDate, finalEndDate, knowledgeAsOf, accountConfigs, accTxnMap);
                  }
                  return Mono.just(accTxnMap);
                });

    return accountIdToTransactions.flatMapMany(
        map -> {
          List<Long> securities =
              map.values().stream()
                  .flatMap(List::stream)
                  .filter(t -> WATCHLIST_NAV_SUB_TYPE.equals(t.getSubType()))
                  .map(transaction -> transaction.getSecurity().getSecurityId())
                  .distinct()
                  .collect(Collectors.toList());

          return accountConfigs.map(
              accountConfig -> {
                Long accountId = accountConfig.getAccount().getId();
                List<Transaction> allTxns =
                    map.getOrDefault(accountId, Collections.emptyList()).stream()
                        .filter(
                            // Economic NAV should not be part of the accounting data returned
                            // by
                            // this API
                            // Note that if this is for accounting, we do this filtering logic
                            // to
                            // prepare
                            // it for the accounting-etl
                            // else if this is not for accounting, then it is used to display
                            // in
                            // LMC, so
                            // economic NVAs still need to be excluded from those balances.
                            // Essentially:
                            // -- /v1/calculated/balance/nav-schedule and
                            // /v1/calculated/balance/account
                            // include economic NAVs
                            // -- /v1/calculated/balance/nav-schedule/accounting and
                            // /v1/calculated/balance/account/accounting do not
                            t -> !(forAccounting && ECONOMIC_NAV_SUB_TYPE.equals(t.getSubType())))
                        .toList();

                Map<Long, Set<WatchlistEntity>> activeWatchListsMap =
                    watchlistService.getActiveWatchlistSecuritiesByAccount(
                        map.keySet().stream().toList(), securities, finalEndDate);

                List<Transaction> openingTransactions =
                    lpxTransactionService.getOpeningTransactions(allTxns);

                log.info(
                    "Starting balance calculation for parentAccountId: {}, accountId: {}, beginDate: {}, endDate: {}",
                    parentAccountId,
                    accountId,
                    beginDate,
                    finalEndDate);

                Map<BalanceScheduleKey, BalanceSchedule> allBalanceSchedules =
                    getBalances(
                        accountConfig.getAccount().getId(),
                        accountConfig.getSubscriptionStartDate(),
                        allTxns,
                        openingTransactions,
                        activeWatchListsMap,
                        beginDate,
                        finalEndDate,
                        Boolean.parseBoolean(
                            accountConfig
                                .getAttributes()
                                .get(EXCLUDE_HISTORIC_TRANSACTIONS_FOR_CONTRIBUTION)));
                Map<BalanceScheduleKey, BalanceSchedule> filteredSchedules =
                    allBalanceSchedules.entrySet().stream()
                        .collect(
                            Collectors.toMap(
                                Map.Entry::getKey,
                                e -> e.getValue().createReducedSchedule(balanceTypes)));

                log.info(
                    "Completed balance calculation for parentAccountId: {}, accountId: {}, beginDate: {}, endDate: {}",
                    parentAccountId,
                    accountId,
                    beginDate,
                    finalEndDate);
                return filteredSchedules;
              });
        });
  }

  /**
   * Uses transactions from a single account to fetch the override transactions and combine them
   * with all normal transactions to create a balance schedule grouped by accountId and securityId.
   *
   * @param subscriptionStartDate
   * @param transactionList
   * @param openingTransactions A list of transactions that all pertain to the single {@code
   *     accountId}
   * @param startDate
   * @param endDate
   * @return A map of BalanceScheduleKey to BalanceSchedule, where BalanceSchedule contains all
   *     BalanceTypes
   */
  private Map<BalanceScheduleKey, BalanceSchedule> getBalances(
      long accountId,
      LocalDate subscriptionStartDate,
      List<Transaction> transactionList,
      List<Transaction> openingTransactions,
      Map<Long, Set<WatchlistEntity>> watchlistPeriods,
      LocalDate startDate,
      LocalDate endDate,
      boolean excludeHistoricContributionTransactions) {
    List<Transaction> pricingOverrideTransactions =
        pricingOverrideService.getPricingOverrideTransactions(
            subscriptionStartDate, openingTransactions);
    log.info("Override Transactions {}", pricingOverrideTransactions);

    return balanceScheduleService.createBalanceMap(
        accountId,
        transactionList,
        pricingOverrideTransactions,
        openingTransactions,
        watchlistPeriods,
        startDate,
        endDate,
        subscriptionStartDate,
        excludeHistoricContributionTransactions);
  }

  private Flux<CalculatedBalance> getCalculatedBalances(
      Map<BalanceScheduleKey, BalanceSchedule> balanceSchedulesByTran, LocalDate endDate) {
    return Flux.fromStream(
        balanceSchedulesByTran.entrySet().stream()
            .map(
                entry -> {
                  BalanceScheduleKey balanceScheduleKey = entry.getKey();
                  var balanceSchedule = entry.getValue();
                  var totalCommitment =
                      balanceSchedule.getValue(BalanceType.REPORTED_TOTAL_COMMITMENT, endDate);
                  var funded = balanceSchedule.getValue(BalanceType.FUNDED_COMMITMENT, endDate);
                  // TODO PATH-2552 Fix the absolute value handling
                  var totalContributions =
                      // general adjustment values shouldn't take the abs value
                      Math.abs(balanceSchedule.getValue(CUM_CONTRIBUTION, endDate))
                          + balanceSchedule.getValue(GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, endDate);
                  var totalDistributions =
                      Math.abs(balanceSchedule.getValue(CUM_DISTRIBUTION, endDate));
                  return CalculatedBalance.builder()
                      .source(balanceScheduleKey.getSource())
                      .security(balanceScheduleKey.getSecurity())
                      .account(balanceScheduleKey.getAccount())
                      .currency(balanceScheduleKey.getSecurity().getCurrency().getCode())
                      .watchlistNavImpact(
                          balanceSchedule.getValue(WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, endDate))
                      .navImpact(balanceSchedule.getValue(BalanceType.REPORTED_ENDING_NAV, endDate))
                      .gaapNavImpact(
                          balanceSchedule.getBasisSpecificValue(
                              BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT,
                              TransactionBasisAffects.GAAP,
                              endDate))
                      .statNavImpact(
                          balanceSchedule.getBasisSpecificValue(
                              BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT,
                              TransactionBasisAffects.STAT,
                              endDate))
                      .fundedCommitmentImpact(funded)
                      .unfundedCommitmentImpact(totalCommitment - funded)
                      .recallableImpact(
                          balanceSchedule.getValue(
                              BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, endDate))
                      .totalCommitment(totalCommitment)
                      .totalContributions(totalContributions)
                      .totalDistributions(totalDistributions)
                      .build();
                }));
  }

  private boolean hasWatchlistBalance(NavigableMap<LocalDate, Double> watchlistNavSchedule) {
    return watchlistNavSchedule.entrySet().stream().anyMatch(entry -> entry.getValue() != 0.0);
  }
  //
  //  protected Set<BalanceScheduleKey> openBalances(Set<BalanceScheduleKey> balanceScheduleKeys,
  // LocalDate endDate) {
  //    Set<BalanceScheduleKey> openBalances = new HashSet<>();
  //    Map<Long, List<BalanceScheduleKey>> accountToBalanceRow =
  //        balanceScheduleKeys.stream().collect(groupingBy(BalanceScheduleKey::getAccountId));
  //    for (Entry<Long, List<BalanceScheduleKey>> entry : accountToBalanceRow.entrySet()) {
  //      List<BalanceScheduleKey> balanceRowsForAccount = entry.getValue();
  //      Map<Long, List<LocalDateRange>> lotEffectiveRangeMap =
  //          portfolioService.getLotEffectiveRangeMap(
  //              entry.getKey(),
  //              balanceRowsForAccount.stream()
  //                  .map(BalanceScheduleKey::getSecurityId)
  //                  .collect(Collectors.toSet()));
  //      for (BalanceScheduleKey balanceScheduleKey : balanceRowsForAccount) {
  //        List<LocalDateRange> lotEffectiveRanges =
  //            lotEffectiveRangeMap.get(balanceScheduleKey.getSecurityId());
  //        if (lotEffectiveRanges == null) {
  //          openBalances.add(balanceScheduleKey); //return if there is no core lot created
  //          break;
  //        }
  //        for (LocalDateRange lotEffectiveRange : lotEffectiveRanges) {
  //          if (lotEffectiveRange.getSecond().isAfter(endDate)) {
  //            openBalances.add(balanceScheduleKey);
  //            break;
  //          }
  //        }
  //      }
  //    }
  //    return openBalances;
  //  }
}
