package com.cwan.privatefund.document;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import io.netty.channel.ChannelOption;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

@Configuration
public class LpxDocumentServiceConfig {

  @Value("${lpx.document.service.base.url}")
  private String lpxDocumentServiceBaseUrl;

  @Value("${lpx.document.service.base.server}")
  private String lpxDocumentServiceBaseServer;

  @Bean(value = "documentServiceClient")
  WebClient lpxDocumentServiceClient() {
    var httpClient = HttpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 100000);
    final int size = 16 * 1024 * 1024;
    final ExchangeStrategies strategies =
        ExchangeStrategies.builder()
            .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(size))
            .build();

    return WebClient.builder()
        .exchangeStrategies(strategies)
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .baseUrl(lpxDocumentServiceBaseUrl)
        .build();
  }

  @Bean(value = "lpxDocumentServiceApacheClient")
  LpxDocumentServiceApacheClient documentServiceApacheClient() {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(
            lpxDocumentServiceBaseServer, 443, "lpx-document-service", Resource.Scheme.HTTPS);
    return new LpxDocumentServiceApacheClient(
        WsHttpClientBuilder.getSharedDefault(), serverConfiguration);
  }
}
