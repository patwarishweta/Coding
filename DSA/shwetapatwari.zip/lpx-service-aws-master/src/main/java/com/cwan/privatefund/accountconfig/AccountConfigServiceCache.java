package com.cwan.privatefund.accountconfig;

import static com.cwan.privatefund.constant.RedisConstants.ACCOUNT;

import com.cwan.lpx.domain.AccountConfig;
import com.google.common.collect.Lists;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class AccountConfigServiceCache {

  private final RedisTemplate<String, Object> redisTemplate;
  private static final int BATCH_SIZE = 50;

  public AccountConfigServiceCache(RedisTemplate<String, Object> redisTemplate) {
    this.redisTemplate = redisTemplate;
  }

  public Mono<AccountConfig> getByAccountId(long accountId) {
    return getAccountConfig(accountId)
        .onErrorResume(
            e -> {
              log.error("Error getByAccountId during getAccountConfig method {}", accountId, e);
              return Mono.empty();
            });
  }

  public Mono<AccountConfig> getAccountConfig(Long accountId) {
    List<AccountConfig> accountConfig =
        (List<AccountConfig>) redisTemplate.opsForHash().get(ACCOUNT, accountId);
    if ((accountConfig != null) && !accountConfig.isEmpty()) {
      return Mono.justOrEmpty(accountConfig.get(0));
    }
    return Mono.error(new Throwable("LP Account id is not found " + accountId));
  }

  public Mono<List<AccountConfig>> getAccountConfigs(
      Collection<Long> accountIds, LocalDate knowledgeDate) {
    List<List<Long>> batches = Lists.partition(accountIds.stream().toList(), BATCH_SIZE);
    return Flux.fromIterable(batches)
        .flatMap(batch -> getAccountConfigsForBatch(batch, knowledgeDate))
        .flatMapIterable(Function.identity())
        .collectList();
  }

  private Mono<List<AccountConfig>> getAccountConfigsForBatch(
      List<Long> accountIds, LocalDate knowledgeDate) {
    List<AccountConfig> accountConfigList = new ArrayList<>();
    for (Long accountId : accountIds) {
      List<AccountConfig> accountConfigFromCache;
      try {
        accountConfigFromCache =
            (List<AccountConfig>) redisTemplate.opsForHash().get(ACCOUNT, accountId);
      } catch (Exception e) {
        log.error("Account not found in cache: {}", e.getMessage());
        throw new AccountConfigServiceException(e);
      }
      if ((accountConfigFromCache != null) && !accountConfigFromCache.isEmpty()) {
        AccountConfig accountConfig = accountConfigFromCache.get(0);
        if (!knowledgeDate.isBefore(accountConfig.getSubscriptionStartDate())
            && ((accountConfig.getSubscriptionEndDate() == null)
                || knowledgeDate.isBefore(accountConfig.getSubscriptionEndDate()))) {
          accountConfigList.add(accountConfig);
        }
      }
    }
    return Mono.just(accountConfigList);
  }

  public Mono<List<AccountConfig>> getAllAccountConfigs() {
    log.info(
        "Total accounts found in redis cache: {}",
        redisTemplate.opsForHash().values(ACCOUNT).size());
    return Flux.fromIterable(redisTemplate.opsForHash().values(ACCOUNT))
        .ofType((Class<List<AccountConfig>>) (Class<?>) List.class)
        .flatMap(Flux::fromIterable)
        .collectList();
  }

  public Set<Long> getAllAccountsWithAttribute(Set<Long> accountIds, String booleanConfigName) {
    return getAllAccountConfigsWithAttribute(accountIds, booleanConfigName).stream()
        .map(c -> c.getAccount().getId())
        .collect(Collectors.toSet());
  }

  public Set<AccountConfig> getAllAccountConfigsWithAttribute(
      Set<Long> accountIds, String booleanConfigName) {
    if (StringUtils.isBlank(booleanConfigName)) {
      return Collections.emptySet();
    }
    boolean loadAllAccounts = CollectionUtils.isEmpty(accountIds);
    return getAllAccountConfigs()
        .map(
            configs -> {
              if (CollectionUtils.isEmpty(configs)) {
                return new HashSet<AccountConfig>();
              }
              return configs.stream()
                  .filter(Objects::nonNull)
                  .filter(
                      config ->
                          Objects.nonNull(config.getAccount())
                              && Objects.nonNull(config.getAttributes()))
                  .filter(
                      config ->
                          loadAllAccounts
                              || (Objects.nonNull(config.getAccount().getId())
                                  && accountIds.contains(config.getAccount().getId())))
                  .filter(
                      config -> {
                        Map<String, String> attributes = config.getAttributes();
                        String value = attributes.get(booleanConfigName);
                        return StringUtils.isNotBlank(value) && Boolean.parseBoolean(value);
                      })
                  .filter(Objects::nonNull)
                  .collect(Collectors.toSet());
            })
        .defaultIfEmpty(Collections.emptySet())
        .onErrorReturn(Collections.emptySet())
        .toFuture()
        .join();
  }
}
