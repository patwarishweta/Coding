package com.cwan.privatefund.status;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/status")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class StatusController {

  public StatusController() {}

  @GetMapping
  @Operation(summary = "Get status")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Map.class))
            })
      })
  public Map<String, Object> getStatus(
      @RequestParam(name = "readinessOnly", defaultValue = "false") boolean readinessOnly) {
    Map<String, Object> statusMap = new HashMap<>();

    if (readinessOnly) {
      statusMap.put("status", "READY");
    } else {
      statusMap.put("status", "UP");
    }
    statusMap.put("message", "Service is operational");

    return statusMap;
  }
}
