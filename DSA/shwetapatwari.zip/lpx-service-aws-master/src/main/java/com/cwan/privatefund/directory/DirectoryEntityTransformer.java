package com.cwan.privatefund.directory;

import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class DirectoryEntityTransformer implements Function<Directory, DirectoryEntity> {

  @Override
  public DirectoryEntity apply(Directory directory) {
    return DirectoryEntity.builder()
        .id(directory.getId())
        .accountId(directory.getAccountId())
        .name(directory.getName())
        .parentDirectoryId(directory.getParentDirectoryId())
        .isDisabled(directory.getIsDisabled())
        .build();
  }
}
