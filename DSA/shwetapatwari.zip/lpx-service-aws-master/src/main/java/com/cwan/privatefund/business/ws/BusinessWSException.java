package com.cwan.privatefund.business.ws;

import java.io.Serial;

public class BusinessWSException extends RuntimeException {

  @Serial private static final long serialVersionUID = 5940623984073156695L;

  public BusinessWSException(String msg) {
    super(msg);
  }
}
