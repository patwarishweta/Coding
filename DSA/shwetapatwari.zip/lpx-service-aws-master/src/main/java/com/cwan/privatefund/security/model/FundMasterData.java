package com.cwan.privatefund.security.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Builder;

@Builder(toBuilder = true)
public record FundMasterData(
    @JsonProperty("name") String name, @JsonProperty("gpName") String gpName)
    implements Serializable {}
