package com.cwan.privatefund.auth.service;

import static com.cwan.privatefund.util.AuthenticationUtils.getAuthenticationToken;

import com.ca.authtoken.core.AuthTokenCore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class JwtAuthenticationService implements AuthenticationService {

  private final AuthTokenCore authTokenCore;
  private final AuthorityService authorityService;

  private static final String USER_ID = "userId";

  public JwtAuthenticationService(AuthTokenCore authTokenCore, AuthorityService authorityService) {
    this.authTokenCore = authTokenCore;
    this.authorityService = authorityService;
  }

  @Override
  public Mono<Authentication> getAuthentication(ServerWebExchange swe) {
    var authHeader = swe.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
    if (authHeader == null) {
      return Mono.empty();
    }
    var token = authHeader.replace("Bearer ", "");
    var valid = authTokenCore.isValidToken(token);
    var principal = valid ? authTokenCore.decodeToken(token).get(USER_ID) : token;
    return Mono.just(
        getAuthenticationToken(principal, token, valid, authorityService.getAuthorities(swe)));
  }
}
