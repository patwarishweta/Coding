package com.cwan.privatefund.fxrate;

import static com.cwan.privatefund.util.DateUtils.getPreviousWeekday;
import static com.cwan.privatefund.util.DateUtils.getStartDateFromFrequency;
import static com.cwan.privatefund.util.DateUtils.isOnWeekend;
import static java.math.RoundingMode.HALF_UP;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.NavigableMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AverageFxRateCalculator {

  private static final int DEFAULT_RATE_DECIMAL_PLACES = 6;
  private final FxServiceApacheClient fxServiceClient;

  public AverageFxRateCalculator(FxServiceApacheClient fxServiceClient) {
    this.fxServiceClient = fxServiceClient;
  }

  public FXRate calculateAverageFxRate(
      Long fxRateSourceId,
      Long baseCurrencyId,
      Long localCurrencyId,
      ReportingFrequency reportingFrequency,
      LocalDate endDate) {
    try {
      LocalDate startDate = getStartDateFromFrequency(endDate, reportingFrequency);
      /* We need to have a Fx rate to use for the start date. Theoretically, we should be getting
      fx rates daily, but to play it safe, we will request data starting from the previous day,
      or previous Friday if the start date is on a weekend.
       */
      LocalDate dayBeforeStart =
          isOnWeekend(startDate) ? getPreviousWeekday(startDate) : startDate.minusDays(1);
      // fx rate map for the base currency
      var baseCurrencyMap =
          fxServiceClient.getFxRateMap(dayBeforeStart, endDate, fxRateSourceId, baseCurrencyId);
      // fx rate map for the local currency
      var localCurrencyMap =
          fxServiceClient.getFxRateMap(dayBeforeStart, endDate, fxRateSourceId, localCurrencyId);

      List<String> mapErrors = validateRateMaps(startDate, baseCurrencyMap, localCurrencyMap);
      if (!mapErrors.isEmpty()) {
        log.error(
            "Invalid FX rate maps for date={}, baseCurrency={}, localCurrency={}, reportingFrequency={}, sourceId={}: {}",
            endDate,
            baseCurrencyId,
            localCurrencyId,
            reportingFrequency,
            fxRateSourceId,
            mapErrors);
        return null;
      }

      Double averageFxRate = getAverageRate(startDate, endDate, baseCurrencyMap, localCurrencyMap);
      if (averageFxRate == null) {
        log.error(
            "Average FX Rate Value for date={}, baseCurrency={}, localCurrency={}, reportingFrequency={}, sourceId={} is null",
            endDate,
            baseCurrencyId,
            localCurrencyId,
            reportingFrequency,
            fxRateSourceId);
        return null;
      }
      log.info(
          "Computed Average FX Rate Value for date={}, baseCurrency={}, localCurrency={}, reportingFrequency={}, sourceId={}: {}",
          endDate,
          baseCurrencyId,
          localCurrencyId,
          reportingFrequency,
          fxRateSourceId,
          averageFxRate);

      Double baseValue = baseCurrencyMap.floorEntry(endDate).getValue();
      Double localValue = localCurrencyMap.floorEntry(endDate).getValue();
      int maxDecimalPlaces = Integer.max(getDecimalPlaces(baseValue), getDecimalPlaces(localValue));
      Double fxRate =
          BigDecimal.valueOf(baseValue / localValue)
              .setScale(maxDecimalPlaces, HALF_UP)
              .doubleValue();

      return FXRate.builder()
          .baseCurrencyId(baseCurrencyId)
          .localCurrencyId(localCurrencyId)
          .reportingFrequency(reportingFrequency)
          .date(endDate)
          .fxRateSourceId(fxRateSourceId)
          .averageFxRate(averageFxRate)
          .fxRate(fxRate)
          .createdBy("lpx-service")
          .isCreatedByInternalUser(true)
          .createdOn(LocalDateTime.now(ZoneOffset.UTC))
          .modifiedBy("lpx-service")
          .isModifiedByInternalUser(true)
          .modifiedOn(LocalDateTime.now(ZoneOffset.UTC))
          .build();
    } catch (Exception e) {
      log.error(
          "Error while calculating average FX rate for date={}, baseCurrency={}, localCurrency={}, reportingFrequency={}, sourceId={}: ",
          endDate,
          baseCurrencyId,
          localCurrencyId,
          reportingFrequency,
          fxRateSourceId,
          e);
      return null;
    }
  }

  /**
   * Averages the fx rates in the base (account) currency rates map with the local (security)
   * currency rates map over a period defined by startDate and endDate. It will only include rates
   * whose date can be found in one of the map's key sets. If one of the maps includes a date that
   * the other does not, it will use the rate of the date most recent to it. We only generate fx
   * rates that are as precise as the data we use to generate them. i.e. if base and local rate only
   * go to 3 decimal places, then the average rate will go to 3 decimal places. Returns null if no
   * rates are averaged.
   *
   * @param startDate
   * @param endDate
   * @param baseCurrencyRates
   * @param localCurrencyRates
   * @return
   */
  private Double getAverageRate(
      LocalDate startDate,
      LocalDate endDate,
      NavigableMap<LocalDate, Double> baseCurrencyRates,
      NavigableMap<LocalDate, Double> localCurrencyRates) {
    Double sumRateRatios = 0.0;
    int count = 0;
    LocalDate current = LocalDate.from(startDate);
    while (!current.isAfter(endDate)) {
      if (baseCurrencyRates.containsKey(current) || localCurrencyRates.containsKey(current)) {
        sumRateRatios +=
            baseCurrencyRates.floorEntry(current).getValue()
                / localCurrencyRates.floorEntry(current).getValue();
        count++;
      }
      current = current.plusDays(1);
    }

    if (sumRateRatios == 0.0 || count == 0) {
      return null;
    }

    return BigDecimal.valueOf(sumRateRatios / count)
        .setScale(DEFAULT_RATE_DECIMAL_PLACES, HALF_UP)
        .doubleValue();
  }

  private List<String> validateRateMaps(
      LocalDate startDate,
      NavigableMap<LocalDate, Double> baseRates,
      NavigableMap<LocalDate, Double> localRates) {
    List<String> errors = new ArrayList<>();
    if (baseRates.isEmpty()) {
      errors.add("Base Currency Map is empty");
    }

    if (localRates.isEmpty()) {
      errors.add("Local Currency Map is empty");
    }

    if (errors.isEmpty()) {
      if (baseRates.firstKey().isAfter(startDate)) {
        errors.add(
            String.format(
                "Base Currency Map first key is after start date. key: %s, start date: %s",
                baseRates.firstKey().toString(), startDate));
      }
      if (localRates.firstKey().isAfter(startDate)) {
        errors.add(
            String.format(
                "Local Currency Map first key is after start date. key: %s, start date: %s",
                localRates.firstKey().toString(), startDate));
      }
    }

    return errors;
  }

  private int getDecimalPlaces(Double number) {
    String[] split = number.toString().split("\\.");
    if (split.length != 2) {
      return 0;
    }
    return split[1].length();
  }
}
