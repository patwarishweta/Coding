package com.cwan.privatefund.auth;

import com.cwan.privatefund.auth.ws.AuthWSService;
import com.cwan.privatefund.auth.ws.SAMLResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/auth")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class AuthController {

  private final AuthWSService authWSService;

  AuthController(AuthWSService authWSService) {
    this.authWSService = authWSService;
  }

  @GetMapping("partnerSSO")
  @Operation(summary = "Initiate PartnerSSO")
  public Mono<SAMLResponse> initiatePartnerSSO(
      @Parameter(description = "partnerCode") String partnerCode,
      @RequestHeader("Authorization") String authorization) {
    return authWSService.initiatePartnerSSO(partnerCode, authorization);
  }
}
