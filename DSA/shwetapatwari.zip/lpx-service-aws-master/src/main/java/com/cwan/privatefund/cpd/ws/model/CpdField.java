package com.cwan.privatefund.cpd.ws.model;

import com.ca.relalg.BasicEnum;
import com.ca.tabular.WebService;
import com.ca.tabular.field.DataType;
import com.ca.tabular.field.FieldLink;
import java.io.Serial;
import java.io.Serializable;
import java.util.Set;
import lombok.Builder;

@Builder(toBuilder = true)
public record CpdField(
    Integer id,
    Long clientId,
    WebService webService,
    FieldLink fieldLink,
    String tagType,
    String name,
    DataType dataType,
    String definition,
    boolean active,
    Set<String> properties,
    String summaryFunctionType,
    BasicEnum[] enumMembers,
    boolean creditRating,
    boolean isComplexWeight,
    boolean staticField)
    implements Serializable {

  @Serial private static final long serialVersionUID = -8815871511323585576L;
}
