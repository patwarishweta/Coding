package com.cwan.privatefund.business.ws;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.business.ws.model.UserAccounts;
import com.cwan.privatefund.client.ClientRequest;
import com.cwan.privatefund.client.WebResponseMapper;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Configuration
@Slf4j
public class BusinessWSConfig {

  @Value("${business.ws.base.url}")
  private String businessWSBaseUrl;

  @Value("${business.ws.base.server}")
  private String businessWSBaseServer;

  @Value("${business.cache.maxsize}")
  private Integer maxCacheSize;

  @Value("${business.cache.timeout.hours}")
  private Integer cacheDurationHrs;

  @Value("${business.ws.memory.maxsize}")
  private Integer maxInMemorySize;

  @Bean(value = "businessWebClient")
  WebClient businessWebClient(ReactorClientHttpConnector reactorClientHttpConnector) {
    return WebClient.builder()
        .baseUrl(businessWSBaseUrl)
        .filter(
            (request, next) ->
                next.exchange(request).retryWhen(Retry.backoff(3, Duration.ofSeconds(5))))
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(maxInMemorySize))
                .build())
        .filter(ClientRequest.logRequest(BusinessWSClient.class.getName() + ".START_TIME"))
        .clientConnector(reactorClientHttpConnector)
        .build();
  }

  @Bean(value = "businessWsApacheClient")
  BusinessWSApacheClient businessWSApacheClient(AuthTokenCore authTokenCore) {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(businessWSBaseServer, 443, "business", Resource.Scheme.HTTPS);
    return new BusinessWSApacheClient(
        WsHttpClientBuilder.getSharedDefault(), serverConfiguration, authTokenCore);
  }

  @Bean(value = "accountIdCache")
  Cache<Long, BusinessAccount> accountIdCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "expandedAccountsCache")
  Cache<Long, List<Long>> expandedAccountsCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "userDetailsCache")
  Cache<Integer, Mono<User>> userDetailsCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "userAccountAccessCache")
  Cache<UserAccounts, Map<Long, Boolean>> userAccountAccessCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "clientCache")
  Cache<Long, Client> clientDataCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "clientUltimateParentCache")
  Cache<Long, SortedMap<Integer, Long>> clientUltimateParentCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "businessResponseMapper")
  WebResponseMapper<BusinessWSException> businessResponseMapper() {
    return new WebResponseMapper<>() {
      @Override
      protected BusinessWSException getException(String msg) {
        return new BusinessWSException(msg);
      }
    };
  }

  @Bean(value = "clientIdtoAccountIdsCache")
  Cache<Long, List<Long>> clientIdtoAccountIdsCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }
}
