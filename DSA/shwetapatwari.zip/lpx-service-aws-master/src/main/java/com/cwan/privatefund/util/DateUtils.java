package com.cwan.privatefund.util;

import com.ca.util.date.GlobalDate;
import com.ca.util.time.UTCTimestamp;
import com.cwan.lpx.domain.ReportingFrequency;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public final class DateUtils {

  private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
      DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

  private static final List<DayOfWeek> WEEKEND = List.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);

  private static final Map<ReportingFrequency, Function<LocalDate, LocalDate>>
      FREQUENCY_TO_DATE_FUNC =
          Map.of(
              ReportingFrequency.MONTHLY,
              DateUtils::getStartOfMonth,
              ReportingFrequency.QUARTERLY,
              DateUtils::getStartOfQuarter,
              ReportingFrequency.YEARLY,
              DateUtils::getStartOfYear);

  private DateUtils() {}

  public static LocalDateTime atEndOfDay(LocalDate localDate) {
    return localDate.atTime(23, 59, 59);
  }

  public static String convertDateTimeFormat(UTCTimestamp timestamp) {
    if (timestamp == null) {
      return "";
    }
    return DATE_FORMATTER.format(timestamp.asDate());
  }

  public static String convertDateFormat(GlobalDate globalDate) {
    if (globalDate == null) {
      return "";
    }
    return DATE_FORMATTER.format(globalDate.getDate());
  }

  public static String convertDateTimeFormat(LocalDateTime localDateTime) {
    if (localDateTime == null) {
      return "";
    }
    return DATE_TIME_FORMATTER.format(localDateTime);
  }

  public static boolean isOnWeekend(LocalDate date) {
    return WEEKEND.contains(date.getDayOfWeek());
  }

  public static LocalDate getPreviousWeekday(LocalDate date) {
    int daysToSubtract =
        switch (date.getDayOfWeek().getValue()) {
          case 6 -> 1; // Saturday
          case 7 -> 2; // Sunday
          default -> 0;
        };
    return daysToSubtract > 0 ? date.minusDays(daysToSubtract) : date;
  }

  public static LocalDate getStartDateFromFrequency(
      LocalDate asOfDate, ReportingFrequency frequency) {
    return FREQUENCY_TO_DATE_FUNC.getOrDefault(frequency, Function.identity()).apply(asOfDate);
  }

  public static LocalDate getStartOfMonth(LocalDate asOfDate) {
    return LocalDate.of(asOfDate.getYear(), asOfDate.getMonthValue(), 1);
  }

  public static LocalDate getStartOfQuarter(LocalDate asOfDate) {
    return LocalDate.of(
        asOfDate.getYear(), getQuarterStartMonthNumber(asOfDate.getMonthValue()), 1);
  }

  public static LocalDate getStartOfYear(LocalDate asOfDate) {
    return LocalDate.of(asOfDate.getYear(), 1, 1);
  }

  private static int getQuarterStartMonthNumber(int monthNumber) {
    int quarterNumber = ((monthNumber - 1) / 3) + 1;
    return (3 * quarterNumber) - 2;
  }
}
