package com.cwan.privatefund.fxrate.source;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Builder(toBuilder = true)
@RequiredArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class AccountFxSource implements Serializable {
  // Value that is used for basisId if the FX sourceId is not basis-specific
  public static final int NOT_BASIS_SPECIFIC_ID = -1;

  private Long accountId;
  private LocalDate date;
  private Integer basisId;
  private Integer rankId;
  private Long fxRateSourceId;
  private LocalDateTime modifiedOn;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountFxSource fxSource = (AccountFxSource) o;
    return Objects.equals(accountId, fxSource.accountId)
        && Objects.equals(date, fxSource.date)
        && Objects.equals(basisId, fxSource.basisId)
        && Objects.equals(rankId, fxSource.rankId)
        && Objects.equals(fxRateSourceId, fxSource.fxRateSourceId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountId, date, basisId, rankId, fxRateSourceId);
  }
}
