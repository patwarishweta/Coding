package com.cwan.privatefund.logger;

import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.ServerWebExchangeDecorator;

public class LPxServiceHttpLogDecorator extends ServerWebExchangeDecorator {

  private final RequestBodyContentWrapper requestBodyContentWrapper;
  private final ResponseBodyContentWrapper responseBodyContentWrapper;

  public LPxServiceHttpLogDecorator(ServerWebExchange exchange) {
    super(exchange);
    this.requestBodyContentWrapper = new RequestBodyContentWrapper(exchange.getRequest());
    this.responseBodyContentWrapper = new ResponseBodyContentWrapper(exchange.getResponse());
  }

  @Override
  public RequestBodyContentWrapper getRequest() {
    return requestBodyContentWrapper;
  }

  @Override
  public ResponseBodyContentWrapper getResponse() {
    return responseBodyContentWrapper;
  }
}
