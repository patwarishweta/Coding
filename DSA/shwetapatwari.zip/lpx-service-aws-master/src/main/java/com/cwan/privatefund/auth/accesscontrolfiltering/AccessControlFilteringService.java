package com.cwan.privatefund.auth.accesscontrolfiltering;

import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/** This service class provides methods to check resource access for user. */
@Service
@Slf4j
@RequiredArgsConstructor
public class AccessControlFilteringService {

  private final AccountService accountService;
  private final BusinessWSCache businessWebCache;

  public Mono<Boolean> checkResourceAccessByAccount(User user, Long resourceAccountId) {
    return accountService
        .retrieveUserAccessibleAccountIds(user.getId())
        .flatMap(accountIds -> Mono.just(accountIds.contains(resourceAccountId)));
  }

  public Mono<List<Long>> checkAccountsAccessForUserid(Integer userId, Set<Long> accountIds) {
    return businessWebCache
        .getUserAccountAccess(userId, accountIds)
        .map(
            longBooleanMap ->
                longBooleanMap.entrySet().stream()
                    .filter(entry -> Boolean.TRUE.equals(entry.getValue()))
                    .map(Entry::getKey)
                    .toList())
        .map(Function.identity());
  }
}
