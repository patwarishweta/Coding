package com.cwan.privatefund.logger;

import java.nio.charset.StandardCharsets;
import org.reactivestreams.Publisher;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class ResponseBodyContentWrapper extends ServerHttpResponseDecorator {

  private final StringBuilder responseBody = new StringBuilder();

  public ResponseBodyContentWrapper(ServerHttpResponse delegate) {
    super(delegate);
  }

  @Override
  public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
    Flux<DataBuffer> buffer = Flux.from(body);
    return super.writeWith(buffer.doOnNext(this::capture));
  }

  private void capture(DataBuffer buffer) {
    this.responseBody.append(StandardCharsets.UTF_8.decode(buffer.asByteBuffer()));
  }

  public String getResponseBody() {
    return this.responseBody.toString();
  }
}
