package com.cwan.privatefund.auth.ws;

import com.cwan.privatefund.auth.AuthenticationException;
import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.cwan.privatefund.client.WebResponseMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class AuthWSClient {

  private final WebClient authWebClient;
  private final WebResponseMapper<AuthenticationException> responseMapper;

  public AuthWSClient(
      WebClient authWebClient, WebResponseMapper<AuthenticationException> authResponseMapper) {
    this.authWebClient = authWebClient;
    this.responseMapper = authResponseMapper;
  }

  public Mono<Boolean> isSessionValid(SessionValidRequest request) {
    var responseSpec =
        authWebClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path("v3/session/valid")
                        .queryParam("userId", request.getUserId())
                        .queryParam("privateLabelId", request.getPrivateLabelId())
                        .queryParam("sessionId", request.getSessionId())
                        .queryParam("application", request.getApplication())
                        .build())
            .accept(MediaType.APPLICATION_JSON)
            .retrieve();
    return responseMapper.mapToClass(responseSpec, Boolean.class);
  }

  public Mono<SAMLResponse> initiatePartnerSSO(String partnerCode, String authorization) {
    return responseMapper.mapToClass(
        authWebClient
            .get()
            .uri(uriBuilder -> uriBuilder.path("/v3/saml/assertion/" + partnerCode).build())
            .header("Authorization", authorization)
            .accept(MediaType.APPLICATION_JSON)
            .retrieve()
            .onRawStatus(
                status -> status == 404,
                res ->
                    Mono.error(
                        new AuthenticationException(
                            "PartnerSSO for " + partnerCode + " not found")))
            .onStatus(
                HttpStatusCode::is5xxServerError,
                res -> Mono.error(new AuthenticationException("Authentication Service failure"))),
        SAMLResponse.class);
  }
}
