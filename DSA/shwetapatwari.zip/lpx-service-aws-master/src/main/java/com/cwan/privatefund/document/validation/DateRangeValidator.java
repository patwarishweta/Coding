package com.cwan.privatefund.document.validation;

import com.cwan.privatefund.document.dto.DocumentFilterCriteria;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class DateRangeValidator
    implements ConstraintValidator<ValidDateRange, DocumentFilterCriteria> {

  @Override
  public boolean isValid(DocumentFilterCriteria request, ConstraintValidatorContext context) {
    if (Objects.isNull(request.beginDate()) || Objects.isNull(request.endDate())) {
      return true;
    }
    boolean isValid = !request.endDate().isBefore(request.beginDate());
    if (!isValid) {
      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate(
              StringUtils.join(
                  "End date ",
                  request.endDate(),
                  " cannot be before begin date ",
                  request.beginDate()))
          .addConstraintViolation();
    }
    return isValid;
  }
}
