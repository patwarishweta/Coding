package com.cwan.privatefund.util;

import java.util.Collection;
import java.util.Collections;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

public final class AuthenticationUtils {

  private AuthenticationUtils() {}

  public static Authentication getAuthenticationToken(
      Object principal, Object credentials, boolean isValid) {
    return isValid
        ? new UsernamePasswordAuthenticationToken(principal, credentials, Collections.emptyList())
        : new UsernamePasswordAuthenticationToken(credentials, principal);
  }

  public static Authentication getAuthenticationToken(
      Object principal,
      Object credentials,
      boolean isValid,
      Collection<GrantedAuthority> authorities) {
    return isValid
        ? new UsernamePasswordAuthenticationToken(principal, credentials, authorities)
        : new UsernamePasswordAuthenticationToken(credentials, principal);
  }
}
