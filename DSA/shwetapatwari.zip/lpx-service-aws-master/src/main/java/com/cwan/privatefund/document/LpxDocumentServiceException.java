package com.cwan.privatefund.document;

import java.io.Serial;

public class LpxDocumentServiceException extends RuntimeException {

  @Serial private static final long serialVersionUID = -6552050022338158750L;

  public LpxDocumentServiceException(String msg) {
    super(msg);
  }
}
