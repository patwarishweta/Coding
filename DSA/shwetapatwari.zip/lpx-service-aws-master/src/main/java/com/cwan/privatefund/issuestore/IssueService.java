package com.cwan.privatefund.issuestore;

import static com.cwan.privatefund.constant.Constants.IssueTypes.MISSING_DOCUMENT;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.MutableLocalDateRange;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.issuestore.model.Issue;
import com.cwan.privatefund.issuestore.model.IssueStatusName;
import java.time.LocalDate;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class IssueService {

  private final IssueStoreClient issueStoreClient;
  private final AccountService accountService;

  IssueService(IssueStoreClient issueStoreClient, AccountService accountService) {
    this.issueStoreClient = issueStoreClient;
    this.accountService = accountService;
  }

  public Flux<Issue> getDocumentErrors(Long documentId) {
    return issueStoreClient
        .getIssuesByTag(documentId.toString())
        .filter(issue -> IssueStatusName.FOUND.equals(issue.getStatus().getStatusName()));
  }

  public Flux<Issue> getMissingDocumentsByUserId(
      Integer userId, LocalDate beginDate, LocalDate endDate) {
    LocalDateRange range = new MutableLocalDateRange(beginDate, endDate);
    return accountService
        .retrieveUserAccessibleAccountIds(userId)
        .flatMapMany(
            accountIds ->
                issueStoreClient
                    .getIssuesByTypeName(MISSING_DOCUMENT)
                    .filter(issue -> accountIds.contains(Long.parseLong(issue.getMetaData())))
                    .filter(
                        issue ->
                            range.contains(issue.getCreatedDateTime().toLocalDate())
                                && IssueStatusName.FOUND.equals(
                                    issue.getStatus().getStatusName())));
  }

  public Flux<Issue> updateIssues(Set<Issue> issues) {
    return Flux.fromIterable(issues).flatMap(issueStoreClient::updateIssue);
  }
}
