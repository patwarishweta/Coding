package com.cwan.privatefund.calculated;

import static com.cwan.privatefund.constant.Constants.CALCULATED_SOURCE;
import static com.cwan.privatefund.constant.Constants.OPEN_TRAN_TYPES;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.MutableLocalDateRange;
import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.trans.Constants.TransactionBasisAffects;
import com.cwan.privatefund.calculated.model.BalanceAffect;
import com.cwan.privatefund.calculated.model.BalanceSchedule;
import com.cwan.privatefund.calculated.model.BalanceScheduleKey;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BalanceScheduleService {

  private final BalanceAffectService balanceAffectService;

  public static final Predicate<Transaction> STAT_TRANSACTIONS =
      x ->
          TransactionBasisAffects.STAT.equals(x.getBasisAffect())
              || TransactionBasisAffects.ALL.equals(x.getBasisAffect())
              || x.getBasisAffect() == null; // this represents an edge case as we backfill
  // "ALL"

  public static final Predicate<Transaction> GAAP_TRANSACTIONS =
      x ->
          TransactionBasisAffects.GAAP.equals(x.getBasisAffect())
              || TransactionBasisAffects.ALL.equals(x.getBasisAffect())
              || x.getBasisAffect() == null; // this represents an edge case as we backfill
  // "ALL"

  private static final Map<String, Predicate<Transaction>> BASIS_PREDICATE_MAP =
      Map.of(
          TransactionBasisAffects.ALL,
              x -> Objects.equals(x.getBasisAffect(), TransactionBasisAffects.ALL),
          TransactionBasisAffects.GAAP, GAAP_TRANSACTIONS,
          TransactionBasisAffects.STAT, STAT_TRANSACTIONS);

  private static final double TOLERANCE = 0.01;

  public BalanceScheduleService(BalanceAffectService balanceAffectService) {
    this.balanceAffectService = balanceAffectService;
  }

  /**
   * Any transaction with a settleDate between the startDate and endDate, which is also after the
   * max(configureDate, openingTransaction.entryDate) will be considered for the balanceSchedule.
   *
   * @param accountId Account id to which all transactions pertain
   * @param allTransactions Should be all transactions between the startDate and endDate for a
   *     single account (should include historic transactions and opening transactions)
   * @param overrideTransactions Should be all override transactions between the startDate and
   *     endDate for a single account
   * @param openingTransactions Should be all transactions between the startDate and endDate for a
   *     single account (should include historic transactions)
   * @param startDate The begin point of our search periods for transactions
   * @param endDate The end point of our search periods for transactions
   * @param configureDate The date the account is configured to begin tracking in lpx-service (aka.
   *     subscriptionStartDate)
   * @return SecurityId to balanceSchedule. The BalanceSchedule is showing balances as of a certain
   *     date for a given balance field (BalanceType).
   */
  public Map<BalanceScheduleKey, BalanceSchedule> createBalanceMap(
      long accountId,
      List<Transaction> allTransactions,
      List<Transaction> overrideTransactions,
      List<Transaction> openingTransactions,
      Map<Long, Set<WatchlistEntity>> watchlistPeriods,
      LocalDate startDate,
      LocalDate endDate,
      LocalDate configureDate,
      boolean excludeHistoricContributionTransactions) {
    Map<BalanceScheduleKey, BalanceSchedule> result = new HashMap<>();
    for (String basis : BASIS_PREDICATE_MAP.keySet()) {
      List<Transaction> basisTransactions =
          allTransactions.stream().filter(BASIS_PREDICATE_MAP.get(basis)).toList();
      // Get the earliest opening transaction per accountId/securityId and build a date range per,
      // which is then used to filter out transactions
      Map<Long, Transaction> firstOpeningTran =
          openingTransactions.stream()
              .collect(
                  Collectors.toMap(
                      t -> t.getSecurity().getSecurityId(),
                      Function.identity(),
                      BinaryOperator.minBy(Comparator.comparing(Transaction::getEntryDate))));

      LocalDateRange accountDefaultFilterRange = new MutableLocalDateRange(configureDate, endDate);
      // We only consider transactions where NON-opening transactions are on or after the first
      // opening transaction AND
      //   on-after the subscription start date
      Map<Long, LocalDateRange> securityTransactionRange =
          firstOpeningTran.entrySet().stream()
              .collect(
                  Collectors.toMap(
                      Map.Entry::getKey,
                      e -> {
                        // TODO PATH-2550 Remove use of entryDate and replace with settleDate
                        if (e.getValue().getEntryDate().isBefore(configureDate)) {
                          return accountDefaultFilterRange;
                        } else {
                          return new MutableLocalDateRange(e.getValue().getEntryDate(), endDate);
                        }
                      }));

      Map<Long, List<Transaction>> overrideTransactionsBySecurityId =
          overrideTransactions.stream().collect(groupingBy(e -> e.getSecurity().getSecurityId()));

      // TODO PATH-2551 Fix inconsisent filtering on subscriptionStartDate
      Map<Long, List<Transaction>> transactionsBySecurityId =
          basisTransactions.stream().collect(groupingBy(e -> e.getSecurity().getSecurityId()));

      for (Map.Entry<Long, List<Transaction>> entry : transactionsBySecurityId.entrySet()) {
        List<Transaction> transactions = entry.getValue();
        if (isPositionClosed(transactions, endDate)) {
          continue;
        }
        Set<String> sources =
            transactions.stream()
                .map(Transaction::getSource)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        Optional<Transaction> randomTransaction =
            transactions.stream()
                .sorted(Comparator.comparing(Transaction::getSettleDate))
                .findFirst();
        Account account = null;
        Security security = null;
        String source = null;
        // Get balance key data
        if (randomTransaction.isPresent()) {
          account = randomTransaction.get().getAccount();
          security = randomTransaction.get().getSecurity();
          // Matching behavior as seen in UI
          source = sources.size() != 1 ? CALCULATED_SOURCE : randomTransaction.get().getSource();

          // Defensive programming against bad data
          if (security.getCurrency() == null) {
            security.setCurrency(
                Currency.builder().code(randomTransaction.get().getCurrency()).build());
          }
        }

        BalanceSchedule basisBalanceSchedule =
            createBalanceSchedule(
                securityTransactionRange.getOrDefault(entry.getKey(), accountDefaultFilterRange),
                startDate,
                transactions,
                overrideTransactionsBySecurityId.getOrDefault(
                    entry.getKey(), Collections.emptyList()),
                watchlistPeriods,
                basis,
                excludeHistoricContributionTransactions);

        // check to see if we need to create a new balance schedule or merge to an existing one
        BalanceScheduleKey balanceScheduleKey =
            new BalanceScheduleKey(accountId, entry.getKey(), account, security, source);
        BalanceSchedule balanceSchedule = result.get(balanceScheduleKey);
        if (balanceSchedule != null) {
          balanceSchedule.merge(
              basisBalanceSchedule); // this will update by reference the value already in the map.
        } else {
          result.put(balanceScheduleKey, basisBalanceSchedule);
        }
      }
    }
    return result;
  }

  /**
   * All transactions are assumed to be from the same account for the same security and should
   * already be filtered down by desired date range. Special subscriptionStartDate logic will be
   * applied internally by <code>BalanceAffectService</code>.
   *
   * @param filterRange Range for this specific security to which apply filters against transactions
   * @param startDate Initial date we want to balance schedule to start. An entry is guaranteed in
   *     the balance schedule for this date.
   * @param allTransactions All current historic and non_historic transactions (includes opening
   *     transactions)
   * @param overrideTransactions
   * @return
   */
  public BalanceSchedule createBalanceSchedule(
      LocalDateRange filterRange,
      LocalDate startDate,
      List<Transaction> allTransactions,
      List<Transaction> overrideTransactions,
      Map<Long, Set<WatchlistEntity>> watchlistPeriods,
      String basis,
      boolean excludeHistoricContributionTransactions) {
    Map<LocalDate, List<BalanceAffect>> overrideBalances = new HashMap<>();
    List<BalanceType> overrideTypes =
        List.of(
            BalanceType.REPORTED_ENDING_NAV,
            BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT,
            BalanceType.WATCHLIST_ENDING_NAV);
    for (Transaction transaction : overrideTransactions) {
      List<BalanceAffect> overrideAffects =
          balanceAffectService
              .getBalanceAffects(
                  BalanceAffectService.ALL_INCLUSIVE_FILTER_RANGE,
                  transaction,
                  watchlistPeriods,
                  excludeHistoricContributionTransactions)
              .stream()
              .filter(e -> overrideTypes.contains(e.getBalanceType()))
              .toList();
      // We only expect one price per security per day, so it is ok to override the value in the map
      overrideBalances
          .computeIfAbsent(transaction.getSettleDate(), key -> new ArrayList<>())
          .addAll(overrideAffects);
    }

    BalanceSchedule balanceSchedule = new BalanceSchedule();
    NavigableMap<LocalDate, List<Transaction>> transactionsByDate =
        allTransactions.stream()
            .collect(groupingBy(Transaction::getSettleDate, TreeMap::new, Collectors.toList()));
    // Adding in entries for all applicable dates
    overrideBalances
        .keySet()
        .forEach(key -> transactionsByDate.putIfAbsent(key, Collections.emptyList()));

    // We should always have rows in the balance schedule for the start date
    if (!transactionsByDate.containsKey(startDate)) {
      balanceSchedule.addNewActivities(
          balanceAffectService.getZeroedBalanceAffects(startDate, watchlistPeriods), basis);
    }

    for (Map.Entry<LocalDate, List<Transaction>> entry : transactionsByDate.entrySet()) {
      // Get and apply overrides of specific types
      List<BalanceAffect> overrideAffects = overrideBalances.get(entry.getKey());
      if (overrideAffects != null) {
        // TODO PATH-2574 Should add flat balances for day
        balanceSchedule.addNewActivities(overrideAffects, basis);
      }

      for (Transaction transaction : entry.getValue()) {
        List<BalanceAffect> toApply =
            balanceAffectService.getBalanceAffects(
                filterRange,
                transaction,
                watchlistPeriods,
                excludeHistoricContributionTransactions);
        if (overrideAffects != null) {
          // When overrides exist, remove normal affects of the override types for this day
          toApply =
              toApply.stream()
                  // TODO PATH-2574 Overrides should remove ANY other balance affects for the given
                  // overrideTypes
                  .filter(
                      e ->
                          !isOpeningTranOnPriceOverrideDay(transaction, entry.getKey())
                              || !overrideTypes.contains(e.getBalanceType()))
                  .collect(toList());
        }
        // Add activities for this day
        balanceSchedule.addNewActivities(toApply, basis);
      }
    }
    return balanceSchedule;
  }

  private boolean isOpeningTranOnPriceOverrideDay(Transaction transaction, LocalDate date) {
    return OPEN_TRAN_TYPES.contains(transaction.getType())
        && transaction.getSettleDate().equals(date);
  }

  protected boolean isPositionClosed(Collection<Transaction> transactions, LocalDate date) {
    NavigableMap<LocalDate, List<Transaction>> transactionsByDate =
        transactions.stream()
            .collect(
                groupingBy(
                    Transaction::getSettleDate,
                    TreeMap::new,
                    mapping(Function.identity(), toList())));
    Map.Entry<LocalDate, List<Transaction>> entry = transactionsByDate.floorEntry(date);
    if (entry == null) {
      return false;
    }
    // Only show the position as being exited the day after the last transaction.
    if (date.equals(entry.getKey())) {
      return false;
    }
    List<Transaction> lastTransactions = entry.getValue();
    boolean isSold =
        lastTransactions.stream().anyMatch(transaction -> "SELL".equals(transaction.getType()));
    // Always exit the position if it is sold.
    if (isSold) {
      return true;
    }
    List<Transaction> transfers =
        lastTransactions.stream()
            .filter(transaction -> "TRNO".equals(transaction.getType()))
            .toList();
    if (transfers.isEmpty()) {
      return false;
    }
    double availableNAV =
        transactionsByDate.headMap(date, true).values().stream()
            .flatMap(List::stream)
            .filter(tran -> !"TRNO".equals(tran.getType())) // Ignore transfers
            .filter(tran -> Objects.nonNull(tran.getNavImpact()))
            .mapToDouble(Transaction::getNavImpact)
            .sum();
    double transferedNAV =
        transfers.stream()
            .filter(tran -> Objects.nonNull(tran.getNavImpact()))
            .mapToDouble(Transaction::getNavImpact)
            .sum();
    if (availableNAV == 0.0 || transferedNAV == 0.0) {
      return false;
    }
    return availableNAV + transferedNAV < TOLERANCE;
  }
}
