package com.cwan.privatefund.portfolio;

import java.io.Serial;

public class PortfolioWsException extends RuntimeException {

  @Serial private static final long serialVersionUID = -750083207586304018L;

  public PortfolioWsException(String message) {
    super(message);
  }
}
