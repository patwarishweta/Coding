package com.cwan.privatefund.calculated.model;

import com.cwan.lpx.client.tabular.BalanceType;
import java.time.LocalDate;
import lombok.Data;

@Data
public class BalanceAffect {

  private final BalanceType balanceType;
  private final LocalDate date;
  private final double amount;

  public BalanceAffect(BalanceType balanceType, LocalDate date, Double amount) {
    this.balanceType = balanceType;
    this.date = date;
    this.amount = amount == null ? 0.0 : amount;
  }
}
