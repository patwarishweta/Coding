package com.cwan.privatefund.document;

import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.misc.document.entity.MiscDocumentEntity;
import com.cwan.privatefund.client.WsClientStatus;
import com.cwan.privatefund.document.model.DocumentTypeData;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.http.codec.multipart.Part;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class LpxDocumentServiceClient {

  private final WebClient webClient;

  public LpxDocumentServiceClient(@Qualifier("documentServiceClient") WebClient webClient) {
    this.webClient = webClient;
  }

  public Mono<String> uploadFile(Part file) {
    log.info("Uploading file from document service for fileName: {}]", file.name());
    var builder = new MultipartBodyBuilder();
    builder.part("file", file);
    return webClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("v1/document/files").build())
        .contentType(MediaType.MULTIPART_FORM_DATA)
        .body(BodyInserters.fromMultipartData(builder.build()))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "DocumentServiceClient uploadFile 4xxClientError filename(): " + file.name()))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "DocumentServiceClient uploadFile is5xxServerError filename(): : "
                        + file.name()))
        .bodyToMono(String.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error(
                    "Failed DocumentServiceClient uploadFile {} response due to {}",
                    file.name(),
                    e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during document upload: " + e);
            });
  }

  public Mono<String> getSignedUrl(Long documentId) {
    log.info("Fetching signed url from document service for documentId: {}", documentId);
    return webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("v1/document/signedUrl/" + documentId).build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is4xxClientError Exception " + response)))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is5xxServerError Exception " + response)))
        .bodyToMono(String.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during document signed url retrieval: " + e);
            });
  }

  public Flux<Document> saveDocument(Document document) {
    return webClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("/v1/document").build())
        .bodyValue(document)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("4xx Client Error: " + response.statusCode())))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("5xx Server Error: " + response.statusCode())))
        .bodyToFlux(Document.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during save document: " + e);
            });
  }

  public Mono<List<Map<String, Object>>> getDocumentDataByCanoeId(Set<String> canoeIds) {
    return webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("v1/document/data")
                    .queryParam("canoeId", String.join(",", canoeIds))
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res, "Document Service Client 4xxClientError canoeIds: " + canoeIds))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res, "Document Service Client is5xxServerError canoeIds : : " + canoeIds))
        .bodyToMono(new ParameterizedTypeReference<List<Map<String, Object>>>() {})
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response DocumentServiceClient getDocumentDataByCanoeId, desired service not present :: UnknownHostException ",
                    e);
              } else {
                log.error(
                    "Failed to get response DocumentServiceClient getDocumentDataByCanoeId for canoeId: {} Exception: ",
                    canoeIds,
                    e);
              }
              return Mono.empty();
            });
  }

  public Flux<UserDetails> fetchUserDetails(Set<String> userIds) {
    return webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("v1/document/users")
                    .queryParam("userIds", String.join(",", userIds))
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "DocumentServiceClient fetchUserDetails 4xxClientError userIds: " + userIds))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "DocumentServiceClient fetchUserDetails is5xxServerError userIds : : "
                        + userIds))
        .bodyToFlux(UserDetails.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response DocumentServiceClient fetchUserDetails, desired service not present :: UnknownHostException ",
                    e);
              } else {
                log.error(
                    "Failed to get response DocumentServiceClient fetchUserDetails for userId: {} Exception: ",
                    userIds,
                    e);
              }
              return Flux.empty();
            });
  }

  public Flux<MissingDocuments> getMissingDocuments(Long accountId) {
    log.info("Fetching document status for accountIds: {}", accountId);
    return webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/v1/document/missing/state")
                    .queryParam("accountIds", accountId)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is4xxClientError Exception " + response)))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is5xxServerError Exception " + response)))
        .bodyToFlux(MissingDocuments.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during document status retrieval: " + e);
            });
  }

  public Flux<MissingDocumentAlertConfig> getAllMissingDocumentAlerts() {
    log.info("Fetching All document alert configs");
    return webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("/v1/document/missing/alert/config/all").build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is4xxClientError Exception " + response)))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is5xxServerError Exception " + response)))
        .bodyToFlux(MissingDocumentAlertConfig.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during document alert config retrieval: " + e);
            });
  }

  public Flux<MissingDocumentExpectationsConfig> getMissingDocumentExpectations() {
    log.info("Fetching All document expectation configs");
    return webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("/v1/document/missing/expectation/config/all").build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is4xxClientError Exception " + response)))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("is5xxServerError Exception " + response)))
        .bodyToFlux(MissingDocumentExpectationsConfig.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during document expectations config retrieval: " + e);
            });
  }

  public Mono<Void> deleteMissingDocumentAlerts(Long clientId) {
    log.info("Deleting document alert configs for clientId: {}", clientId);
    return webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder.path("/v1/document/missing/alert/config/delete/" + clientId).build())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .flatMap(response -> handleResponseForDeleteApi(response))
        .onErrorResume(e -> handleErrorForDeleteApi(e, "delete document alert config"))
        .then();
  }

  public Mono<Void> deleteMissingDocumentExpectation(Long securityId, String documentType) {
    log.info(
        "Deleting document expectation configs for securityId: {} and DocumentType: {}",
        securityId,
        documentType);
    return webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/v1/document/missing/expectation/config/delete")
                    .queryParam("securityId", securityId)
                    .queryParam("documentType", documentType)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .flatMap(response -> handleResponseForDeleteApi(response))
        .onErrorResume(e -> handleErrorForDeleteApi(e, "delete document expectation config"))
        .then();
  }

  private Mono<Void> handleResponseForDeleteApi(ClientResponse response) {
    HttpStatusCode statusCode = response.statusCode();
    if (statusCode.is4xxClientError() || statusCode.is5xxServerError()) {
      return Mono.error(new LpxDocumentServiceException("Exception: " + response));
    } else if (statusCode == HttpStatus.NO_CONTENT) {
      return Mono.empty();
    } else {
      return Mono.error(new LpxDocumentServiceException("Unexpected status: " + response));
    }
  }

  private Mono<Void> handleErrorForDeleteApi(Throwable e, String messageFor) {
    if (e instanceof UnknownHostException) {
      log.error("Failed to get response, desired service not present: {}", e);
    } else {
      log.error("Failed to receive response due to {}", e);
    }
    return Mono.error(
        new LpxDocumentServiceException("Exception occurred for " + messageFor + ": " + e));
  }

  public Flux<MissingDocumentAlertConfig> saveMissingDocumentAlerts(
      List<MissingDocumentAlertConfig> configs) {
    return webClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("/v1/document/missing/alert/config/add").build())
        .bodyValue(configs)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("4xx Client Error: " + response.statusCode())))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("5xx Server Error: " + response.statusCode())))
        .bodyToFlux(MissingDocumentAlertConfig.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during save missing document alert config: " + e);
            });
  }

  public Flux<MissingDocumentExpectationsConfig> saveMissingDocumentExpectationsConfigs(
      List<MissingDocumentExpectationsConfig> configs) {
    return webClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("/v1/document/missing/expectation/config/add").build())
        .bodyValue(configs)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("4xx Client Error: " + response.statusCode())))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("5xx Server Error: " + response.statusCode())))
        .bodyToFlux(MissingDocumentExpectationsConfig.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during save missing document expectation config: " + e);
            });
  }

  public Mono<Map<String, DocumentTypeData>> getAllDocumentTypeData() {
    return webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("/v1/document/documentTypes").build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("4xx Client Error: " + response.statusCode())))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("5xx Server Error: " + response.statusCode())))
        .bodyToFlux(DocumentTypeData.class)
        .collectList()
        .map(
            documentTypeDataList -> {
              return documentTypeDataList.stream()
                  .collect(
                      Collectors.toMap(DocumentTypeData::getDocumentType, Function.identity()));
            })
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred while fetching all document types data: " + e);
            });
  }

  public Mono<MiscDocumentEntity> saveMiscDocument(MiscDocumentEntity miscDocument) {
    return webClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("/v1/document/misc").build())
        .bodyValue(miscDocument)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("4xx Client Error: " + response.statusCode())))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new LpxDocumentServiceException("5xx Server Error: " + response.statusCode())))
        .bodyToMono(MiscDocumentEntity.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error("Failed to get response, desired service not present: {}", e);
              } else {
                log.error("Failed to receive response due to {}", e);
              }
              throw new LpxDocumentServiceException(
                  "Exception occurred during save misc document : " + e);
            });
  }
}
