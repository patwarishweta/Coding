package com.cwan.privatefund.tabular;

import com.cwan.lpx.client.tabular.BalanceRow;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.trans.TransactionService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class TransactionAmountCalculator {

  private final TransactionService transactions;
  protected static final String RCAP = "RCAP";
  protected static final String CAPD = "CAPD";
  protected static final String INC = "INC";
  protected static final String DVD = "DVD";

  TransactionAmountCalculator(final TransactionService transactions) {
    this.transactions = transactions;
  }

  public void addTransactionSumsToBalanceRows(Collection<BalanceRow> balanceRows) {
    balanceRows.forEach(c -> c.setSumOfDistTransactions(BigDecimal.ZERO));
    balanceRows.forEach(c -> c.setSumOfIncDivTransactions(BigDecimal.ZERO));
    if (balanceRows.isEmpty()) {
      return;
    }
    Set<Long> accountIds =
        balanceRows.stream().map(BalanceRow::getAccountId).collect(Collectors.toSet());
    var transactionList =
        transactions.getTransactionsByAccountIds(accountIds).collectList().share().block();
    if (transactionList == null) {
      return;
    }
    for (BalanceRow balanceRow : balanceRows) {
      Set<Transaction> transactionsForRow =
          transactionList.stream()
              .filter(
                  t ->
                      (t.getAccount().getId() == balanceRow.getAccountId())
                          && (t.getSecurity().getSecurityId() == balanceRow.getSecurityId()))
              .collect(Collectors.toSet());
      var distributionSum =
          BigDecimal.valueOf(
                  transactionsForRow.stream()
                      .filter(t -> RCAP.equals(t.getType()) || CAPD.equals(t.getType()))
                      .mapToDouble(Transaction::getNetAmount)
                      .sum())
              .setScale(2, RoundingMode.HALF_UP);
      var incDivSum =
          BigDecimal.valueOf(
                  transactionsForRow.stream()
                      .filter(t -> INC.equals(t.getType()) || DVD.equals(t.getType()))
                      .mapToDouble(Transaction::getNetAmount)
                      .sum())
              .setScale(2, RoundingMode.HALF_UP);
      balanceRow.setSumOfDistTransactions(distributionSum);
      balanceRow.setSumOfIncDivTransactions(incDivSum);
    }
  }
}
