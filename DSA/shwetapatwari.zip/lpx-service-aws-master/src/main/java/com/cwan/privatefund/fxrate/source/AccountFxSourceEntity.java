package com.cwan.privatefund.fxrate.source;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@IdClass(AccountFxSourceKey.class)
@Table(name = "account_fx_sources", catalog = "pabor")
public class AccountFxSourceEntity implements Serializable {

  @Id private Long accountId;
  @Id private LocalDate date;
  @Id private Integer basisId;
  @Id private Integer rankId;
  private Long fxRateSourceId;
  private LocalDateTime modifiedOn;

  public AccountFxSourceKey toKey() {
    return new AccountFxSourceKey(accountId, date, basisId, rankId);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountFxSourceEntity that = (AccountFxSourceEntity) o;
    return Objects.equals(accountId, that.accountId)
        && Objects.equals(date, that.date)
        && Objects.equals(basisId, that.basisId)
        && Objects.equals(rankId, that.rankId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountId, date, basisId, rankId);
  }
}
