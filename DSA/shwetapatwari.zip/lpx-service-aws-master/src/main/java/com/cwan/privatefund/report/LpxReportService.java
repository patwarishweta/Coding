package com.cwan.privatefund.report;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.missing.document.api.impl.MissingDocumentsServiceImpl;
import com.cwan.pbor.reporting.LpxReportEntity;
import com.cwan.pbor.reporting.LpxReportingService;
import com.cwan.pbor.reporting.models.BalanceDiscrepancyEntry;
import com.cwan.pbor.reporting.models.BalanceMismatchReportEntry;
import com.cwan.pbor.reporting.models.CalculatedReportedBalancesReportEntry;
import com.cwan.pbor.reporting.models.DuplicateTransactionReportEntry;
import com.cwan.pbor.reporting.models.FoPurchaseReportEntry;
import com.cwan.pbor.reporting.models.FoSaleReportEntry;
import com.cwan.pbor.reporting.models.GaapBalanceSheetByLotEntry;
import com.cwan.pbor.reporting.models.GaapStatBalanceEntry;
import com.cwan.pbor.reporting.models.LpxVsFrontOfficeTransactionEntry;
import com.cwan.pbor.reporting.models.StatBalanceSheetByLotEntry;
import com.cwan.privatefund.account.AccountService;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class LpxReportService {

  private final LpxReportingService lpxReportingService;
  private final MissingDocumentsServiceImpl missingDocumentsService;
  private final AccountService accountService;
  private final ObjectMapper objectMapper;

  public LpxReportService(
      LpxReportingService lpxReportingService,
      MissingDocumentsServiceImpl missingDocumentsService,
      AccountService accountService,
      ObjectMapper objectMapper) {
    this.lpxReportingService = lpxReportingService;
    this.missingDocumentsService = missingDocumentsService;
    this.accountService = accountService;
    this.objectMapper = objectMapper;
  }

  public List<CommitmentManagerEntry> getCommitmentManagerReport(
      Long accountId, LocalDate beginDate, LocalDate endDate) {
    LocalDateRange range = LocalDateRanges.create(beginDate, endDate);
    List<Long> accountIds =
        accountService.expandAccountId(accountId).collectList().toFuture().join();
    List<CommitmentManagerEntry> entries = new ArrayList<>();
    for (Long simpleAccount : accountIds) {
      Optional<Pair<LocalDateTime, List<LpxVsFrontOfficeTransactionEntry>>>
          lpxVsFrontOfficeTransactionEntries =
              Optional.ofNullable(lpxReportingService.getMostRecentFOMismatchReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<CalculatedReportedBalancesReportEntry>>>
          calculatedReportedBalancesReportEntries =
              Optional.ofNullable(
                  lpxReportingService.getMostRecentCalculatedBalanceReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<DuplicateTransactionReportEntry>>>
          duplicateTransactionReportEntries =
              Optional.ofNullable(
                  lpxReportingService.getMostRecentDuplicateTransactionReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<BalanceDiscrepancyEntry>>>
          gaapBalanceDiscrepancyReportEntries =
              Optional.ofNullable(
                  lpxReportingService.getMostRecentGaapBalanceDiscrepancyReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<BalanceDiscrepancyEntry>>>
          statBalanceDiscrepancyReportEntries =
              Optional.ofNullable(
                  lpxReportingService.getMostRecentStatBalanceDiscrepancyReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<BalanceMismatchReportEntry>>> balanceMismatchReportEntries =
          Optional.ofNullable(
              lpxReportingService.getMostRecentBalanceMismatchReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<FoPurchaseReportEntry>>> foPurchaseReportEntries =
          Optional.ofNullable(lpxReportingService.getMostRecentFoPurchaseReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<FoSaleReportEntry>>> foSaleReportEntries =
          Optional.ofNullable(lpxReportingService.getMostRecentFoSaleReport(simpleAccount));
      Optional<Pair<LocalDateTime, List<GaapBalanceSheetByLotEntry>>> gaapBalanceSheetByLotEntries =
          Optional.ofNullable(
              lpxReportingService.getMostRecentGaapBalanceSheetByLot(simpleAccount));
      Optional<Pair<LocalDateTime, List<StatBalanceSheetByLotEntry>>> statBalanceSheetByLotEntries =
          Optional.ofNullable(
              lpxReportingService.getMostRecentStatBalanceSheetByLot(simpleAccount));
      Optional<Pair<LocalDateTime, List<GaapStatBalanceEntry>>> gaapStatBalanceEntries =
          Optional.ofNullable(lpxReportingService.getMostRecentGaapStatBalanceEntry(simpleAccount));
      ConsolidatedLmcVsFoReportEntries consolidatedLmcVsFoReportEntries =
          new ConsolidatedLmcVsFoReportEntries(
              gaapBalanceDiscrepancyReportEntries.map(Pair::getRight).orElse(null),
              statBalanceDiscrepancyReportEntries.map(Pair::getRight).orElse(null),
              balanceMismatchReportEntries.map(Pair::getRight).orElse(null),
              foPurchaseReportEntries.map(Pair::getRight).orElse(null),
              foSaleReportEntries.map(Pair::getRight).orElse(null),
              gaapBalanceSheetByLotEntries.map(Pair::getRight).orElse(null),
              statBalanceSheetByLotEntries.map(Pair::getRight).orElse(null),
              gaapStatBalanceEntries.map(Pair::getRight).orElse(null));
      List<MissingDocuments> missingDocuments =
          missingDocumentsService
              .getAllMissingDocumentsUsingAccountIdIn(List.of(simpleAccount))
              .stream()
              .filter(doc -> doc.getDocumentMissingCategory() != MissingDocumentStatus.RECEIVED)
              .filter(doc -> range.contains(doc.getDocDate()))
              .toList();
      HashSet<LocalDateTime> dates = new HashSet<>();
      calculatedReportedBalancesReportEntries.map(Pair::getLeft).ifPresent(dates::add);
      duplicateTransactionReportEntries.map(Pair::getLeft).ifPresent(dates::add);
      List<DuplicateTransactionReportEntry> duplicateTransactionReportEntriesList = null;
      if (duplicateTransactionReportEntries.isPresent()) {
        Pair<LocalDateTime, List<DuplicateTransactionReportEntry>> localDateTimeListPair =
            duplicateTransactionReportEntries.get();
        List<DuplicateTransactionReportEntry> right = localDateTimeListPair.getRight();
        duplicateTransactionReportEntriesList =
            right.stream().filter(c -> range.contains(c.getSettleDate())).toList();
      }
      LocalDateTime leastModifiedOn = dates.stream().min(LocalDateTime::compareTo).orElse(null);
      entries.add(
          new CommitmentManagerEntry(
              lpxVsFrontOfficeTransactionEntries.map(Pair::getRight).orElse(null),
              calculatedReportedBalancesReportEntries.map(Pair::getRight).orElse(null),
              duplicateTransactionReportEntriesList,
              consolidatedLmcVsFoReportEntries,
              simpleAccount,
              leastModifiedOn,
              missingDocuments));
    }
    return entries;
  }

  public List<DuplicateTransactionReportEntry> getMostRecentDuplicateTransactionReport(
      Long accountId) {
    return lpxReportingService.getMostRecentDuplicateTransactionReport(accountId).getRight();
  }

  public List<LpxVsFrontOfficeTransactionEntry> getMostRecentFrontOfficeAccountingReport(
      Long accountId) {
    return lpxReportingService.getMostRecentFOMismatchReport(accountId).getRight();
  }

  public List<CalculatedReportedBalancesReportEntry> getMostRecentCoreAccountingReport(
      Long accountId) {
    return lpxReportingService.getMostRecentCalculatedBalanceReport(accountId).getRight();
  }

  public List<LpxReportEntity> save(CoreTransactionEntryRequest accountingEntryRequest)
      throws JsonProcessingException {
    return lpxReportingService.saveReportEntities(
        List.of(
            new LpxReportEntity(
                accountingEntryRequest.id,
                accountingEntryRequest.accountId,
                LpxReportingService.CORE_TRANSACTION_COMPARISON,
                objectMapper.writeValueAsString(
                    accountingEntryRequest.lpxVsFrontOfficeTransactionEntry),
                LocalDateTime.now())));
  }

  public List<LpxReportEntity> save(CoreAccountingEntryRequest coreAccountingEntryRequest)
      throws JsonProcessingException {
    return lpxReportingService.saveReportEntities(
        List.of(
            new LpxReportEntity(
                coreAccountingEntryRequest.id,
                coreAccountingEntryRequest.accountId,
                LpxReportingService.DUPLICATE_TRANSACTIONS,
                objectMapper.writeValueAsString(
                    coreAccountingEntryRequest.calculatedReportedBalancesReportEntries),
                LocalDateTime.now())));
  }

  public List<LpxReportEntity> save(
      DuplicateTransactionEntryRequest duplicateTransactionEntryRequest)
      throws JsonProcessingException {
    return lpxReportingService.saveReportEntities(
        List.of(
            new LpxReportEntity(
                duplicateTransactionEntryRequest.id,
                duplicateTransactionEntryRequest.accountId,
                LpxReportingService.DUPLICATE_TRANSACTIONS,
                objectMapper.writeValueAsString(
                    duplicateTransactionEntryRequest.duplicateTransactionReportEntry),
                LocalDateTime.now())));
  }

  public record CoreAccountingEntryRequest(
      List<CalculatedReportedBalancesReportEntry> calculatedReportedBalancesReportEntries,
      Long accountId,
      Long id) {}

  public record CoreTransactionEntryRequest(
      List<LpxVsFrontOfficeTransactionEntry> lpxVsFrontOfficeTransactionEntry,
      Long accountId,
      Long id) {}

  public record DuplicateTransactionEntryRequest(
      List<DuplicateTransactionReportEntry> duplicateTransactionReportEntry,
      Long accountId,
      Long id) {}

  public record ConsolidatedLmcVsFoReportEntries(
      List<BalanceDiscrepancyEntry> gaapDiscrepancyEntries,
      List<BalanceDiscrepancyEntry> statDiscrepancyEntries,
      List<BalanceMismatchReportEntry> balanceMismatchReportEntries,
      List<FoPurchaseReportEntry> foPurchaseReportEntries,
      List<FoSaleReportEntry> foSaleReportEntries,
      List<GaapBalanceSheetByLotEntry> gaapBalanceSheetByLotEntries,
      List<StatBalanceSheetByLotEntry> statBalanceSheetByLotEntries,
      List<GaapStatBalanceEntry> gaapStatBalanceEntries) {}

  public record CommitmentManagerEntry(
      List<LpxVsFrontOfficeTransactionEntry> lpxVsFrontOfficeTransactionEntries,
      List<CalculatedReportedBalancesReportEntry> calculatedReportedBalancesReportEntries,
      List<DuplicateTransactionReportEntry> duplicateTransactionReportEntries,
      ConsolidatedLmcVsFoReportEntries consolidatedLmcVsFoReportEntries,
      Long accountId,
      @JsonFormat(pattern = "yyyy-MM-dd") LocalDateTime oldestModifiedOnDate,
      List<MissingDocuments> missingDocuments) {}
}
