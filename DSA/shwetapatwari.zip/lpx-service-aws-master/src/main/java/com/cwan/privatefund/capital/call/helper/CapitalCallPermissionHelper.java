package com.cwan.privatefund.capital.call.helper;

import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants.EMAIL_SPLIT_PATTERN;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants.FINAL;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants.INITIAL;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants.WIRE_TRANSFER;

import com.cwan.lpx.domain.CapitalCallPermissions;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Provides utility functions for determining permissions related to Capital Calls. Primary use
 * cases include verifying user permissions for specific actions and extracting key information from
 * capital call data.
 */
@Slf4j
public final class CapitalCallPermissionHelper {

  /**
   * Returns the default CapitalCallPermissions for a given user email.
   *
   * @param userEmail The email of the user for which permissions are being fetched.
   * @return CapitalCallPermissions The default permissions for the given user email.
   */
  public static CapitalCallPermissions getDefaultPermissionsForUser(String userEmail) {
    if (isSystemUser(userEmail)) {
      return CapitalCallPermissions.builder()
          .approveActionAllowed(true)
          .rejectActionAllowed(true)
          .build();
    }
    return CapitalCallPermissions.builder()
        .approveActionAllowed(false)
        .rejectActionAllowed(false)
        .build();
  }

  /**
   * Determines the tag key associated with a given capital call status.
   *
   * @param status The capital call status.
   * @return The associated tag key.
   */
  private static String getTagKeyByStatus(CapitalCallStatus status) {
    return switch (status) {
      case WIRE_CHECK, WIRE_CHECK_REJECTED, BLACKLISTED -> WIRE_TRANSFER;
      case INITIAL_REVIEW -> INITIAL;
      case FINAL_REVIEW, COMPLETED -> FINAL;
      default -> null;
    };
  }

  /**
   * Determines if an action is allowed based on the status, tag entries, and user email.
   *
   * @param status The capital call status.
   * @param tagEntries Map of tag keys and their associated entries.
   * @param userEmail The email of the user for which the permission check is done.
   * @return True if the action is allowed, false otherwise.
   */
  public static boolean derivePermissionForAction(
      CapitalCallStatus status, Map<String, TagEntry> tagEntries, String userEmail) {
    if (isSystemUser(userEmail)) {
      log.debug(
          "Permission check bypassed as the user '{}' is identified as a system user.", userEmail);
      return true;
    }
    var tagKey = getTagKeyByStatus(status);
    if (Objects.isNull(tagKey)) {
      log.warn("Could not derive a tag key for status: {}", status);
      return false;
    }
    return Optional.ofNullable(tagEntries.get(tagKey))
        .map(TagEntry::cpdValue)
        .map(
            value -> {
              var cleanedValue = StringUtils.deleteWhitespace(value);
              log.debug("Processed tag entry value: {}", cleanedValue);
              return cleanedValue;
            })
        .map(
            value ->
                EMAIL_SPLIT_PATTERN
                    .splitAsStream(value)
                    .filter(StringUtils::isNotBlank)
                    .map(StringUtils::lowerCase)
                    .collect(Collectors.toSet()))
        .map(emailSet -> emailSet.contains(StringUtils.lowerCase(userEmail)))
        .orElse(false);
  }

  private static boolean isSystemUser(String userEmail) {
    return StringUtils.equalsIgnoreCase(
        SystemUserConstants.EMAIL, StringUtils.deleteWhitespace(userEmail));
  }

  private CapitalCallPermissionHelper() {
    // Adding a private constructor to hide the implicit public one.
  }
}
