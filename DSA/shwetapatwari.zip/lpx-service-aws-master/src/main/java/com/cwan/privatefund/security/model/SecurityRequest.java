package com.cwan.privatefund.security.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityRequest {
  private Long accountId;
  private Long clientId;
  private List<Long> securityIds;
  private String date;
  private List<FieldsBySource> fieldsBySource;
  private String asOfDatetime;

  public static class SecurityRequestBuilder {}
}
