package com.cwan.privatefund.constant;

public final class RedisConstants {

  public static final String ACCOUNT = "Account";

  public static final String SECURITY = "Security";

  public static final String BUSINESS_ACCOUNT_DATA_CACHE = "business:account_data";

  public static final String BUSINESS_USER_DETAILS_CACHE = "business:user_details";

  public static final String BUSINESS_CLIENT_DATA_CACHE = "business:client_data";

  public static final String BUSINESS_EXPANDED_ACCOUNTS_CACHE = "business:expanded_account";

  public static final String BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE =
      "business:user_accounts_access";

  public static final String BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE = "business:client_account";

  public static final String BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID =
      "business:client_ultimate_parent_by_acc_id";

  public static final String BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_CLIENT_ID =
      "business:client_ultimate_parent_by_client_id";

  public static final String PORTFOLIO_ACCOUNT_SECURITY_CACHE = "portfolio:account_security_cache";

  public static final String DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE =
      "document_service:document_types_cache";

  private RedisConstants() {}
}
