package com.cwan.privatefund.transaction.model;

import com.cwan.lpx.domain.Transaction;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class TransactionRequest {

  private Set<Transaction> transactions;
}
