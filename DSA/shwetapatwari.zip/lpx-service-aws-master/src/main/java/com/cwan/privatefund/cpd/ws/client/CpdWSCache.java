package com.cwan.privatefund.cpd.ws.client;

import com.ca.util.date.GlobalDates;
import com.cwan.privatefund.config.properties.CpdConfigProperties;
import com.cwan.privatefund.cpd.ws.model.CpdField;
import com.cwan.privatefund.cpd.ws.model.CpdFieldAndData;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import com.google.common.cache.Cache;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** This service manages caching related to CPD Web Services (WS). */
@Slf4j
@Service
public class CpdWSCache {

  private final CpdWSClient cpdWSClient;
  private final CpdConfigProperties cpdConfigProperties;
  private final Cache<Long, ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>>
      tagEntriesCache;
  private final Map<Integer, String> fieldNameById;

  /**
   * Initializes the cache manager with necessary dependencies.
   *
   * @param cpdWSClient The client to interface with the CPD Web Service.
   * @param tagEntriesCache The cache to store tag entries.
   * @param cpdConfigProperties Configuration properties for CPD.
   */
  public CpdWSCache(
      CpdWSClient cpdWSClient,
      Cache<Long, ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>>
          tagEntriesCache,
      CpdConfigProperties cpdConfigProperties) {
    this.cpdWSClient = Objects.requireNonNull(cpdWSClient, "Web client cannot be null");
    this.cpdConfigProperties =
        Objects.requireNonNull(cpdConfigProperties, "CPD config properties cannot be null");
    this.tagEntriesCache = Objects.requireNonNull(tagEntriesCache, "Cache cannot be null");
    this.fieldNameById = Collections.unmodifiableMap(buildFieldNameMap());
  }

  /**
   * Retrieves cached or fetched tag entries for a client and account ID.
   *
   * @param clientId The client's ID.
   * @param accountId The account's ID.
   * @param fieldIds The set of field IDs.
   * @return Tag entries as a Mono.
   */
  public Mono<ConcurrentHashMap<String, TagEntry>> getTagEntriesForClient(
      Long clientId, Long accountId, Set<Integer> fieldIds) {
    log.debug(
        "Attempting to retrieve cached tag entries for clientId: {}, accountId: {}",
        clientId,
        accountId);
    return validateClientId(clientId)
        .then(
            Mono.defer(
                () ->
                    Optional.ofNullable(tagEntriesCache.getIfPresent(clientId))
                        .orElseGet(
                            () -> {
                              var newClientMap =
                                  new ConcurrentHashMap<
                                      Long, Mono<ConcurrentHashMap<String, TagEntry>>>();
                              tagEntriesCache.put(clientId, newClientMap);
                              return newClientMap;
                            })
                        .computeIfAbsent(
                            accountId,
                            key ->
                                fetchTagEntriesFromServiceAndCache(clientId, accountId, fieldIds)
                                    .cache())))
        .doOnError(
            e ->
                log.error(
                    "Error occurred while retrieving or fetching tag entries for clientId: {}, accountId: {}",
                    clientId,
                    accountId,
                    e))
        .onErrorResume(
            e -> {
              log.warn(
                  "Failed to obtain cached or fetched tag entries for clientId: {}. Passing on the error for further handling.",
                  clientId);
              return Mono.error(e);
            });
  }

  /**
   * Removes cached entries for the specified client ID.
   *
   * @param clientId Client ID whose cache is to be cleared.
   * @return A signal indicating completion.
   */
  public Mono<Void> clearCacheForClient(Long clientId) {
    return validateClientId(clientId)
        .doOnNext(
            id -> {
              log.info("Clearing the cache for client ID: {}", id);
              tagEntriesCache.invalidate(id);
            })
        .then();
  }

  /**
   * Removes all entries from the cache.
   *
   * @return A signal indicating completion.
   */
  public Mono<Void> clearCache() {
    return Mono.fromRunnable(
        () -> {
          log.info("Clearing the tag entries cache.");
          tagEntriesCache.invalidateAll();
        });
  }

  /**
   * Retrieves reviewers based on client and account ID.
   *
   * @param clientId The client's ID.
   * @param accountId The account's ID.
   * @return Tag entries representing reviewers as a Mono.
   */
  public Mono<ConcurrentHashMap<String, TagEntry>> getReviewers(Long clientId, Long accountId) {
    return getTagEntriesForClient(
        clientId,
        accountId,
        new HashSet<>(
            Objects.requireNonNull(
                    cpdConfigProperties.getFieldIds().getReviewers(),
                    "Reviewers configuration is missing.")
                .values()));
  }

  /**
   * Fetches and caches tag entries from a remote service for specified client and account ID.
   *
   * @param clientId The client's ID.
   * @param accountId The account's ID.
   * @param fieldIds The set of field IDs.
   * @return Cached tag entries as a Mono.
   */
  Mono<ConcurrentHashMap<String, TagEntry>> fetchTagEntriesFromServiceAndCache(
      Long clientId, Long accountId, Set<Integer> fieldIds) {
    log.debug(
        "No cache found for clientId: {}, accountId: {}. Fetching tag entries from remote service.",
        clientId,
        accountId);
    return cpdWSClient
        .getTagEntries(fieldIds, clientId, accountId)
        .filter(
            tagEntry ->
                Objects.equals(clientId, tagEntry.clientId())
                    && Objects.equals(accountId, tagEntry.accountId()))
        .collectList()
        .map(
            tagEntries -> {
              var resultMap = new ConcurrentHashMap<String, TagEntry>();
              tagEntries.forEach(tagEntry -> addTagEntryToCache(resultMap, tagEntry));
              log.info(
                  "Successfully cached tag entries for clientId: {}, accountId: {} after fetching from the service.",
                  clientId,
                  accountId);
              return resultMap;
            });
  }

  /**
   * Adds a tag entry to the cache.
   *
   * @param map The map representing the cache.
   * @param tagEntry The tag entry to add.
   */
  void addTagEntryToCache(Map<String, TagEntry> map, TagEntry tagEntry) {
    Optional.ofNullable(fieldNameById.get(tagEntry.fieldId()))
        .ifPresentOrElse(
            fieldName -> map.put(fieldName, tagEntry),
            () ->
                log.error(
                    "Could not associate field name with field ID: {}. Excluding this entry from cache.",
                    tagEntry.fieldId()));
  }

  /**
   * Validates the provided client ID.
   *
   * @param clientId The ID of the client to be validated.
   * @return A Mono signaling completion if the client ID is valid or an error Mono with a common
   *     exception if not.
   */
  private Mono<Long> validateClientId(Long clientId) {
    if (Objects.isNull(clientId) || (clientId <= 0)) {
      log.error("Invalid client ID: {}", clientId);
      return Mono.error(new IllegalArgumentException("Invalid client ID provided"));
    }
    return Mono.just(clientId);
  }

  /**
   * Builds a mapping from field IDs to field names using configuration properties.
   *
   * @return A map of field IDs to field names.
   */
  private Map<Integer, String> buildFieldNameMap() {
    return new ConcurrentHashMap<>(
        cpdConfigProperties.getFieldIds().getReviewers().entrySet().stream()
            .collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey)));
  }

  /**
   * Retrieves cpd fields, filters enabled in LMC fields, and fetches data from tag entries for a
   * client.
   *
   * @param clientId The client's ID.
   * @return list of cpd fields with their corresponding data.
   */
  public Mono<List<CpdFieldAndData>> getCpdFieldAndDataForClient(Long clientId) {
    log.debug("Attempting to retrieve cached field entries for clientId: {}", clientId);
    Flux<CpdField> receivedCpdFields =
        cpdWSClient
            .getCpdFields(clientId)
            .filter(entry -> entry.properties().contains("ENABLED_IN_LMC"));
    return receivedCpdFields
        .collectList()
        .filter(Objects::nonNull)
        .flatMap(
            cpdFieldList ->
                cpdWSClient
                    .getTagEntries(
                        cpdFieldList.stream().map(CpdField::id).collect(Collectors.toSet()),
                        clientId,
                        null)
                    .collectList()
                    .filter(Objects::nonNull)
                    .flatMap(
                        tagEntriesList -> {
                          Map<Integer, List<TagEntry>> tagEntries =
                              tagEntriesList.stream()
                                  .filter(
                                      entry ->
                                          entry.reportDate() == null
                                              || GlobalDates.createToday().getDayNumber()
                                                  >= entry.reportDate())
                                  .filter(
                                      entry ->
                                          entry.endDate() == null
                                              || GlobalDates.createToday().getDayNumber()
                                                  <= entry.endDate())
                                  .collect(Collectors.groupingBy(TagEntry::fieldId));
                          return Mono.just(
                              cpdFieldList.stream()
                                  .map(
                                      cpdField -> {
                                        if (tagEntries.get(cpdField.id()) == null) {
                                          return new CpdFieldAndData(cpdField, Map.of());
                                        }
                                        Map<Integer, String> dataMap =
                                            tagEntries.get(cpdField.id()).stream()
                                                .collect(
                                                    Collectors.toMap(
                                                        TagEntry::tagId, TagEntry::cpdValue));
                                        CpdFieldAndData cpdFieldAndData =
                                            new CpdFieldAndData(cpdField, dataMap);
                                        return cpdFieldAndData;
                                      })
                                  .collect(Collectors.toList()));
                        }));
  }
}
