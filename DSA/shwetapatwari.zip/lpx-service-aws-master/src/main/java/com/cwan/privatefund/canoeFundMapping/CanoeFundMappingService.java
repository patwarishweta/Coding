package com.cwan.privatefund.canoeFundMapping;

import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingAccountResponse;
import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingClientResponse;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CanoeFundMappingService {

  private final CanoeFundMappingRepository canoeFundMappingRepository;

  @Autowired
  public CanoeFundMappingService(CanoeFundMappingRepository canoeFundMappingRepository) {
    this.canoeFundMappingRepository = canoeFundMappingRepository;
  }

  public Set<CanoeFundMappingClientResponse> getClientDetails() {
    log.info("getting all unique client details");
    return canoeFundMappingRepository.findAllClientNames();
  }

  public List<CanoeFundMappingAccountResponse> getAccountDetails(long clientId) {
    log.info("getting account details for clientId {}", clientId);
    return canoeFundMappingRepository.findAccountByClientId(clientId);
  }
}
