package com.cwan.privatefund.pricing;

import java.io.Serial;

public class PricingException extends RuntimeException {

  @Serial private static final long serialVersionUID = 8333742121269395246L;

  public PricingException(String msg) {
    super(msg);
  }
}
