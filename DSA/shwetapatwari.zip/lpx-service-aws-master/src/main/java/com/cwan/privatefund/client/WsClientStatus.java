package com.cwan.privatefund.client;

import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

public interface WsClientStatus {

  Logger LOGGER = LoggerFactory.getLogger(WsClientStatus.class);

  static Mono<Exception> onStatusError(ClientResponse res, String errorReason) {
    res.bodyToMono(String.class)
        .doOnNext(errorMessage -> LOGGER.error("{} Error Response :{} ", errorReason, errorMessage))
        .thenEmpty(Mono.empty())
        .subscribe();
    return Mono.error(
        new Exception(
            errorReason
                + " responseStatusCode: "
                + res.statusCode()
                + " "
                + (HttpStatus.resolve(res.statusCode().value()) != null
                    ? Objects.requireNonNull(HttpStatus.resolve(res.statusCode().value()))
                        .getReasonPhrase()
                    : "Unknown Status")));
  }
}
