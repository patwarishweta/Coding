package com.cwan.privatefund.business.ws;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.client.WebResponseMapper;
import com.cwan.privatefund.client.WsClientStatus;
import java.net.UnknownHostException;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.Exceptions;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class BusinessWSClient {

  public static final String USER_INFO_PATH = "user";
  private static final String ACCOUNT_INFO_PATH = "account/accounts";
  private final WebClient businessWebClient;
  private final WebResponseMapper<BusinessWSException> responseMapper;
  private final AuthTokenCore authTokenCore;

  public BusinessWSClient(
      WebClient businessWebClient,
      WebResponseMapper<BusinessWSException> businessResponseMapper,
      AuthTokenCore authTokenCore) {
    this.businessWebClient = businessWebClient;
    this.responseMapper = businessResponseMapper;
    this.authTokenCore = authTokenCore;
  }

  public Mono<List<BusinessAccount>> getAccountInformation(Long accountId) {
    return businessWebClient
        .get()
        .uri(uriBuilder -> uriBuilder.path(ACCOUNT_INFO_PATH).queryParam("aid", accountId).build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getAccountInformation 4xxClientError accountId: "
                        + accountId))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getAccountInformation is5xxServerError accountId: : "
                        + accountId))
        .bodyToMono(new ParameterizedTypeReference<List<BusinessAccount>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  MessageFormat.format(
                      "Exception businessWsClient getAccountInformation {0} Exception: {1}",
                      e.getLocalizedMessage(), e));
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response businessWsClient getAccountInformation, desired service not present :: UnknownHostException ",
                    e);
              } else {
                log.error(
                    "Failed to get response businessWsClient getAccountInformation for accountId: {} Exception: ",
                    accountId,
                    e);
              }
              return Mono.error(e);
            });
  }

  /**
   * Fetches the user details from the business web service client given a user ID.
   *
   * @param userId The ID of the user for which details are required.
   * @return A Mono wrapping User details fetched from business web service client.
   */
  public Mono<User> fetchUserDetails(Integer userId) {
    return businessWebClient
        .get()
        .uri(uriBuilder -> uriBuilder.path(USER_INFO_PATH).queryParam("userId", userId).build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "Error during getUserDetails from BusinessWSClient: Client error (4xx) encountered for userId: "
                        + userId))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "Error during getUserDetails from BusinessWSClient: Server error (5xx) encountered for userId: "
                        + userId))
        .bodyToMono(User.class)
        .onErrorResume(
            e -> {
              String errorMessage;
              if (e instanceof UnknownHostException) {
                errorMessage =
                    "Failed to get response from businessWsClient for getUserDetails. Service may be unavailable. UnknownHostException: ";
              } else {
                errorMessage =
                    String.format(
                        "Failed to get response from businessWsClient for getUserDetails request for userId: %d. Exception: ",
                        userId);
              }
              log.error(errorMessage, e);
              return Mono.error(e);
            });
  }

  public Mono<List<BusinessAccount>> getAccountsInformation(Collection<Long> accountIds) {
    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
    for (var accountId : accountIds) {
      formData.add("aid", accountId.toString());
    }
    return businessWebClient
        .post()
        .uri(uriBuilder -> uriBuilder.path(ACCOUNT_INFO_PATH).build())
        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
        .body(BodyInserters.fromFormData(formData))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getAccountsInformation 4xxClientError accountId: "
                        + accountIds))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getAccountsInformation is5xxServerError accountId: : "
                        + accountIds))
        .bodyToMono(new ParameterizedTypeReference<List<BusinessAccount>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  MessageFormat.format(
                      "Exception businessWsClient getAccountsInformation {0} Exception: {1}",
                      e.getLocalizedMessage(), e));
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response businessWsClient getAccountsInformation, desired service not present :: UnknownHostException :: ",
                    e);
              } else {
                log.error(
                    "Failed to get response businessWsClient getAccountsInformation for accountId size: {} Exception: ",
                    accountIds,
                    e);
              }
              return Mono.error(e);
            });
  }

  public Mono<List<Long>> getExpandedAccountIds(Long accountId) {
    return businessWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder.path("account/subaccounts").queryParam("aid", accountId).build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient aggregatedAccounts 4xxClientError accountId: " + accountId))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient aggregatedAccounts is5xxServerError accountId: : "
                        + accountId))
        .bodyToMono(new ParameterizedTypeReference<List<Long>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  MessageFormat.format(
                      "Exception businessWsClient aggregatedAccounts {0} Exception: {1}",
                      e.getLocalizedMessage(), e));
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response businessWsClient aggregatedAccounts, desired service not present :: UnknownHostException :: ",
                    e);
              } else if (Exceptions.isRetryExhausted(e)) {
                log.error(
                    "Failed to get response businessWsClient aggregatedAccounts after multiple retries for account {} :: RetryExhaustedException :: ",
                    accountId,
                    e);
              } else {
                log.error(
                    "Failed to get response businessWsClient aggregatedAccounts for Request: {} Exception: ",
                    accountId,
                    e);
              }
              return Mono.error(e);
            });
  }

  public Mono<Map<Long, Boolean>> getUserAccountAccess(
      Integer userId, Collection<Long> accountIds) {
    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
    formData.add("userId", userId.toString());
    for (var accountId : accountIds) {
      formData.add("aids", accountId.toString());
    }
    return businessWebClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("account/getUserAccessForAccounts").build())
        .body(BodyInserters.fromFormData(formData))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res, "BusinessWSClient getUserAccountAccess 4xxClientError userId: " + userId))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getUserAccountAccess is5xxServerError userId: : " + userId))
        .bodyToMono(new ParameterizedTypeReference<Map<Long, Boolean>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  MessageFormat.format(
                      "Exception businessWsClient getUserAccountAccess {0} Exception: {1}",
                      e.getLocalizedMessage(), e));
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response getUserAccountAccess, desired service not present :: UnknownHostException :: ",
                    e);
              } else {
                log.error(
                    "Failed to get response getUserAccountAccess for userId: {} Exception: ",
                    userId,
                    e);
              }
              return Mono.error(e);
            });
  }

  public Mono<Map<Long, SortedMap<Integer, Long>>> getUltimateParentMapFromAccounts(
      Set<Long> accountIds) {
    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
    for (var accountId : accountIds) {
      formData.add("aid", accountId.toString());
    }
    var responseSpec =
        businessWebClient
            .post()
            .uri(uriBuilder -> uriBuilder.path("client/tree/accounts").build())
            .headers(
                httpHeaders -> httpHeaders.setBearerAuth(authTokenCore.createApplicationToken()))
            .body(BodyInserters.fromFormData(formData))
            .accept(MediaType.APPLICATION_JSON)
            .retrieve();
    return responseMapper.mapToType(responseSpec, new ParameterizedTypeReference<>() {});
  }

  public Mono<Map<Long, SortedMap<Integer, Long>>> getUltimateParentMapFromClients(
      Set<Long> clientIds) {
    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
    for (var clientId : clientIds) {
      formData.add("cid", clientId.toString());
    }
    var responseSpec =
        businessWebClient
            .post()
            .uri(uriBuilder -> uriBuilder.path("client/tree/clients").build())
            .headers(
                httpHeaders -> httpHeaders.setBearerAuth(authTokenCore.createApplicationToken()))
            .body(BodyInserters.fromFormData(formData))
            .accept(MediaType.APPLICATION_JSON)
            .retrieve();
    return responseMapper.mapToType(responseSpec, new ParameterizedTypeReference<>() {});
  }

  public Mono<Map<Long, Client>> getClientInfo(Collection<Long> clientIds) {
    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
    for (var clientId : clientIds) {
      formData.add("cid", clientId.toString());
    }
    return businessWebClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("client/clients").build())
        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
        .body(BodyInserters.fromFormData(formData))
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res, "BusinessWSClient getClientInfo 4xxClientError clientIds: " + clientIds))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getClientInfo is5xxServerError clientIds: : " + clientIds))
        .bodyToMono(new ParameterizedTypeReference<Map<Long, Client>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  MessageFormat.format(
                      "Exception businessWsClient getClientInfo {0} Exception: {1}",
                      e.getLocalizedMessage(), e));
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response BusinessWSClient getClientInfo, desired service not present :: UnknownHostException :: ",
                    e);
              } else {
                log.error(
                    "Failed to get response BusinessWSClient getClientInfo for clientIds size: {} Exception: ",
                    clientIds.size(),
                    e);
              }
              return Mono.error(e);
            });
  }

  public Mono<List<Long>> getClientAccountIds(Long clientId) {
    return businessWebClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("client/accountIds").queryParam("cid", clientId).build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getClientAccountIds 4xxClientError clientId: " + clientId))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "BusinessWSClient getClientAccountIds is5xxServerError clientId: : "
                        + clientId))
        .bodyToMono(new ParameterizedTypeReference<List<Long>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  MessageFormat.format(
                      "Exception businessWsClient getClientAccountIds {0} Exception: {1}",
                      e.getLocalizedMessage(), e));
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response businessWsClient getClientAccountIds, desired service not present :: UnknownHostException :: ",
                    e);
              } else {
                log.error(
                    "Failed to get response businessWsClient getClientAccountIds for clientId: {} Exception: ",
                    clientId,
                    e);
              }
              return Mono.error(e);
            });
  }
}
