package com.cwan.privatefund.documentmanager.exception;

import com.cwan.privatefund.documentmanager.DocumentUploadFileDetails;
import java.util.List;
import lombok.Getter;

@Getter
public class DocumentUploadFailedException extends Exception {

  private final List<DocumentUploadFileDetails> uploadFileDetailsList;

  public DocumentUploadFailedException(List<DocumentUploadFileDetails> uploadFileDetailsList) {
    this.uploadFileDetailsList = uploadFileDetailsList;
  }
}
