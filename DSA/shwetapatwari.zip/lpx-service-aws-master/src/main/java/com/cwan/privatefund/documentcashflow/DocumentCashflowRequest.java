package com.cwan.privatefund.documentcashflow;

import com.cwan.lpx.domain.DocumentCashFlow;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class DocumentCashflowRequest {

  private Set<DocumentCashFlow> documentCashFlows;
}
