package com.cwan.privatefund.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Objects;
import org.apache.commons.lang3.StringUtils;

/** Utility class for exception-related operations. */
public final class ExceptionUtils {

  /** Private constructor to prevent instantiation. */
  private ExceptionUtils() {}

  /**
   * Converts the stack trace of a given {@code Throwable} into a string.
   *
   * @param throwable the exception or error to convert.
   * @return the stack trace as a string. If {@code throwable} is null, returns an empty string.
   */
  public static String getStackTraceAsString(Throwable throwable) {
    if (Objects.isNull(throwable)) {
      return "";
    }
    var stringWriter = new StringWriter();
    throwable.printStackTrace(new PrintWriter(stringWriter));
    return StringUtils.trim(stringWriter.toString());
  }
}
