package com.cwan.privatefund.accelex;

import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_DISPOSITION_HEADER;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_ENCODING_HEADER;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_TYPE_CSV;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_TYPE_HEADER;

import com.ca.json2.utils.JsonUtils2;
import com.ca.relalg.Column;
import com.ca.relalg.data.DataSet;
import com.cwan.pbor.fundmaster.PortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.privatefund.accelex.AccelexService.LpData;
import com.cwan.privatefund.accelex.AccelexService.ReferenceFileType;
import com.cwan.privatefund.tabular.dataset.DataSetUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping(value = "v1/accelex")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class AccelexController {

  private final AccelexService accelexService;

  @Autowired
  AccelexController(AccelexService accelexService) {
    this.accelexService = accelexService;
  }

  @GetMapping(value = "/enabled")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary =
          "Given a list of accountIds, return true if Accelex is enabled for all accounts, false otherwise")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Accelex enabled status for group of accounts",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Map<Long, Boolean> getEnabledStatusByAccountIds(
      @RequestParam("accountIds") Set<Long> accounts) {
    return accelexService.getEnabledStatusByAccountIds(accounts);
  }

  @PostMapping(value = "/uploadCanoeDocument")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary =
          "Given a CIK / CanoeId / DocumentName will resolve the CIK into account/security combo and save the document into document-service. "
              + "Will return true if the document should be sent through FTP")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description =
                "Given Document metadata, will return true if the document should be uploaded or not",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Boolean uploadCanoeDocument(@RequestBody DocumentMetaData documentMetaData) {
    log.info("Received request to upload document: {}", JsonUtils2.objToJson(documentMetaData));
    try {
      return accelexService.uploadDocumentData(documentMetaData).size() > 0;
    } catch (Exception e) {
      log.error("Error while uploading document: {}", JsonUtils2.objToJson(documentMetaData), e);
      return false;
    }
  }

  @RequestMapping(value = "portfolioCompanies/securities", method = RequestMethod.GET)
  @Operation(summary = "Retrieve Accelex Portfolio Companies by SecurityIds")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = PortfolioCompanyEntity.class))
            })
      })
  public Collection<AccelexPortfolioCompanyEntity> getPortfolioCompaniesBySecurityIds(
      @Parameter(description = "SecurityId filter") @RequestParam Set<Long> securityIds,
      @Parameter(description = "As of date to get data for")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          @RequestParam
          LocalDate asOfDate) {
    return accelexService.getAccelexPortfolioCompanies(securityIds, asOfDate);
  }

  @RequestMapping(value = "investments/securities", method = RequestMethod.GET)
  @Operation(summary = "Retrieve Accelex Investments by SecurityId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = PortfolioCompanyEntity.class))
            })
      })
  public Collection<AccelexInvestmentsEntity> getAccelexInvestmentsBySecurityIds(
      @Parameter(description = "SecurityId filter") @RequestParam Set<Long> securityIds,
      @Parameter(description = "As of date to get data for")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          @RequestParam
          LocalDate asOfDate) {
    return accelexService.getAccelexInvestments(securityIds, asOfDate);
  }

  @RequestMapping(value = "/fundReferenceData", method = RequestMethod.GET)
  @Operation(summary = "Get all fund reference data for the given accountIds")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity<byte[]> getFundReferenceDataForAccounts(
      @Parameter(description = "accountId filter") @RequestParam("accountIds") Set<Long> accountIds,
      @Parameter(description = "boolean to determine if for UI display") @RequestParam("forDisplay")
          boolean forUI,
      @Parameter(description = "type of output to send") @RequestParam("referenceType")
          ReferenceFileType referenceType)
      throws IOException {
    DataSet<Column> fundReferenceData =
        accelexService.getFundEntityReferenceData(accountIds, referenceType, forUI);
    var fileName =
        "reference_data_"
            + referenceType.name()
            + "_"
            + LocalDate.now().format(DateTimeFormatter.ISO_DATE)
            + ".csv";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSVWithoutQuotes(fundReferenceData).getBytes());
  }

  @RequestMapping(value = "all/fundReferenceData", method = RequestMethod.GET)
  @Operation(summary = "Get all fund reference data for the given accountIds")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity<byte[]> getAllFundReferenceData(
      @Parameter(description = "type of output to send") @RequestParam("referenceType")
          ReferenceFileType referenceType)
      throws IOException {
    DataSet<Column> fundReferenceData =
        accelexService.getFundEntityReferenceData(referenceType, false);
    var fileName =
        "reference_data_"
            + referenceType.name()
            + "_"
            + LocalDate.now().format(DateTimeFormatter.ISO_DATE)
            + ".csv";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSVWithoutQuotes(fundReferenceData).getBytes());
  }

  @RequestMapping(value = "/claritySetUpStatus", method = RequestMethod.GET)
  @Operation(summary = "Get data for Clarity Set Up Status")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public List<LpData> getClaritySetUpStatus(
      @Parameter(description = "Ultimate Parent Id") @RequestParam("ultimateParentClient")
          Long ultimateParentClient,
      @Parameter(description = "User Id") @RequestParam("userId") Integer userId) {
    return accelexService.getAccelexEnabledSecuritiesAndAccounts(ultimateParentClient, userId);
  }
}
