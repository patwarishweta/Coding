package com.cwan.privatefund.security.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityCurrency implements Serializable {
  private Long securityId;
  private Long currencyId;
  private LocalDateTime modifiedOn;
}
