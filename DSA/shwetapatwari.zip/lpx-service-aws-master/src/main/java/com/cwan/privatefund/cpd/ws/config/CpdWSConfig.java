package com.cwan.privatefund.cpd.ws.config;

import com.cwan.privatefund.client.ClientRequest;
import com.cwan.privatefund.config.properties.CpdConfigProperties;
import com.cwan.privatefund.cpd.ws.client.CpdWSClient;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Configuration
public class CpdWSConfig {

  private final CpdConfigProperties cpdConfigProperties;

  public CpdWSConfig(CpdConfigProperties cpdConfigProperties) {
    this.cpdConfigProperties = cpdConfigProperties;
  }

  @Bean
  WebClient cpdWebClient(ReactorClientHttpConnector reactorClientHttpConnector) {
    return WebClient.builder()
        .baseUrl(cpdConfigProperties.getWebService().getBaseUrl())
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(
                    configurer ->
                        configurer
                            .defaultCodecs()
                            .maxInMemorySize(
                                cpdConfigProperties.getWebService().getMaxMemorySize()))
                .build())
        .filter(ClientRequest.logRequest(CpdWSClient.class.getName() + ".START_TIME"))
        .clientConnector(reactorClientHttpConnector)
        .build();
  }

  @Bean
  Cache<Long, ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>>
      tagEntriesCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(cpdConfigProperties.getCache().getMaxSize())
        .expireAfterWrite(cpdConfigProperties.getCache().getTimeoutInHours(), TimeUnit.HOURS)
        .build();
  }
}
