package com.cwan.privatefund.document.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class DocumentTypeData implements Serializable {

  private Integer id;
  private String documentType;
  private String category;
  private Boolean needsCustomAllocation;
}
