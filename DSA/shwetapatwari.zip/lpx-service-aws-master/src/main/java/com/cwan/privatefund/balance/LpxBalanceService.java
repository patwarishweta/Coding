package com.cwan.privatefund.balance;

import static com.cwan.privatefund.constant.Constants.EntityActions.CANCEL;

import com.cwan.lpx.domain.Balance;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.balance.model.BalanceRequest;
import com.cwan.privatefund.publisher.MessagePublisher;
import com.cwan.privatefund.util.DateUtils;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class LpxBalanceService {

  private final LpxBalanceEntityService lpxBalanceEntityService;
  private final MessagePublisher<Balance> balanceMessagePublisher;
  private final AccountService accountService;

  public LpxBalanceService(
      LpxBalanceEntityService lpxBalanceEntityService,
      MessagePublisher<Balance> balanceMessagePublisher,
      AccountService accountService) {
    this.lpxBalanceEntityService = lpxBalanceEntityService;
    this.balanceMessagePublisher = balanceMessagePublisher;
    this.accountService = accountService;
  }

  public Mono<Void> addBalance(BalanceRequest request, String generateActivity) {
    request.getBalances().forEach(balance -> publishBalance(balance, generateActivity));
    return Mono.empty();
  }

  public Flux<Balance> getBalanceByBalanceId(Set<Long> ids) {
    return lpxBalanceEntityService.getBalancesByIds(ids);
  }

  public Mono<Void> deleteBalanceByBalanceId(Set<Long> ids) {
    return lpxBalanceEntityService
        .getBalancesByIds(ids)
        .flatMap(
            balance -> {
              balance.setKnowledgeEndDate(LocalDateTime.now());
              balance.setAction(CANCEL);
              return publishBalance(balance);
            })
        .then();
  }

  public Mono<Void> updateBalances(BalanceRequest balanceRequest) {
    return Flux.fromIterable(balanceRequest.getBalances()).flatMap(this::publishBalance).then();
  }

  public Flux<Balance> getBalancesByDocumentId(Long documentId) {
    return lpxBalanceEntityService.getBalancesByDocumentIds(Set.of(documentId));
  }

  public Flux<Balance> getAccountBalances(
      Long accountId, LocalDate balanceDate, LocalDate knowledgeDate) {
    return accountService
        .expandAccountId(accountId)
        .flatMap(
            expandedAccountIds ->
                lpxBalanceEntityService.getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
                    expandedAccountIds, balanceDate, DateUtils.atEndOfDay(knowledgeDate)));
  }

  public Flux<Balance> getAccountsBalances(
      Set<Long> accountIds, LocalDate balanceDate, LocalDate knowledgeDate) {
    if (CollectionUtils.isEmpty(accountIds)) {
      return lpxBalanceEntityService.getBalancesOnBalanceDate(
          balanceDate, DateUtils.atEndOfDay(knowledgeDate));
    }
    return Flux.fromIterable(accountIds)
        .flatMap(accountService::expandAccountId)
        .collectList()
        .flatMapMany(
            expandedSimples ->
                Optional.ofNullable(expandedSimples)
                    .filter(CollectionUtils::isNotEmpty)
                    .map(HashSet::new)
                    .map(
                        expandedAccountIds ->
                            lpxBalanceEntityService.getBalancesOnBalanceDateForAccounts(
                                expandedAccountIds,
                                balanceDate,
                                DateUtils.atEndOfDay(knowledgeDate)))
                    .orElse(Flux.empty()));
  }

  private Mono<Void> publishBalance(Balance balance) {
    Map<String, String> attributesMap = new HashMap<>();
    attributesMap.put("generateActivity", "true");
    attributesMap.put(
        "messageGroupId",
        balance.getAccount().getId() + "-" + balance.getSecurity().getSecurityId());
    return Mono.fromRunnable(
        () -> balanceMessagePublisher.publishMessage(balance, attributesMap, true));
  }

  private void publishBalance(Balance balance, String generateActivity) {
    Map<String, String> attributesMap = new HashMap<>();
    attributesMap.put("generateActivity", generateActivity);
    attributesMap.put(
        "messageGroupId",
        balance.getAccount().getId() + "-" + balance.getSecurity().getSecurityId());
    balanceMessagePublisher.publishMessage(balance, attributesMap, true);
  }
}
