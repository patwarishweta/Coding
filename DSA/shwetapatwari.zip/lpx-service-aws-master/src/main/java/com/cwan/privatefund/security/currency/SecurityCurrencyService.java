package com.cwan.privatefund.security.currency;

import com.cwan.privatefund.security.model.SecurityCurrency;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SecurityCurrencyService {
  private SecurityCurrencyRepository securityCurrencyRepository;
  private SecurityCurrencyEntityTransformer securityCurrencyEntityTransformer;
  private SecurityCurrencyTransformer securityCurrencyTransformer;

  public SecurityCurrencyService() {}

  @Autowired
  public SecurityCurrencyService(
      final SecurityCurrencyRepository securityCurrencyRepository,
      final SecurityCurrencyEntityTransformer securityCurrencyEntityTransformer,
      final SecurityCurrencyTransformer securityCurrencyTransformer) {
    this.securityCurrencyRepository = securityCurrencyRepository;
    this.securityCurrencyEntityTransformer = securityCurrencyEntityTransformer;
    this.securityCurrencyTransformer = securityCurrencyTransformer;
  }

  public Set<SecurityCurrency> findAllByCurrencyIdIn(Set<Long> currencyIds) {
    return securityCurrencyRepository.findAllByCurrencyIdIn(currencyIds).stream()
        .map(securityCurrencyTransformer)
        .collect(Collectors.toSet());
  }

  public Set<SecurityCurrency> saveSecurityCurrencies(Set<SecurityCurrency> securityCurrencies) {
    return securityCurrencies.stream()
        .map(securityCurrencyEntityTransformer)
        .map(securityCurrencyRepository::saveAndFlush)
        .map(securityCurrencyTransformer)
        .collect(Collectors.toSet());
  }
}
