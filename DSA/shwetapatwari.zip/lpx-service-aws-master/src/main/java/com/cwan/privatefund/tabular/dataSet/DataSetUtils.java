package com.cwan.privatefund.tabular.dataset;

import com.ca.relalg.Column;
import com.ca.relalg.data.DataSet;
import com.ca.relalg.data.DataSetBuilder;
import com.ca.relalg.data.Row;
import com.cwan.lpx.client.tabular.LPField;
import com.google.common.annotations.VisibleForTesting;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Collectors;

public final class DataSetUtils {

  private static final String NULL_CHECK = "null";
  private static final String NULL_REPLACE = "";

  private DataSetUtils() {}

  public static String convertDataSetToCSV(DataSet<Column> dataSet) throws IOException {
    var csv = new StringBuilder();
    dataSet.toCsv(csv);
    return csv.toString().replace(NULL_CHECK, NULL_REPLACE).trim();
  }

  public static String convertDataSetToCSVWithoutQuotes(DataSet<Column> dataSet)
      throws IOException {
    return convertDataSetToCSV(dataSet).replace("\"", "");
  }

  public static Set<Integer> distinctValuesForIntColumn(
      DataSet<Column> columnDataSet, Column column) {
    Set<Integer> accountIds = new HashSet<>();
    for (Row<Column> row : columnDataSet.getRows()) {
      accountIds.add(row.getInt(column));
    }
    return accountIds;
  }

  @VisibleForTesting
  public static DataSet<Column> convertToDataSet(List<List<Object>> rows, List<LPField> headers) {
    List<Column> columns =
        headers.stream().map(lpField -> (Column) lpField).collect(Collectors.toList());
    var builder = DataSetBuilder.configureStandard().setColumns(columns).createBuilder();
    List<List<Comparable>> rightData = new ArrayList<>();
    for (List<Object> row : rows) {
      rightData.add(row.stream().map(o -> (Comparable) o).collect(Collectors.toList()));
    }
    rightData.forEach(row -> builder.addRow(row.toArray(Comparable[]::new)));
    return builder.build();
  }

  public static Long getUltimateParentClientId(
      Map<Long, SortedMap<Integer, Long>> ultimateParentMapFromAccounts, Integer accountId) {
    var clientHierarchyMap = ultimateParentMapFromAccounts.get(Long.valueOf(accountId));
    // the structure of the business response posts the ultimate parent as the last
    // item in the map
    return clientHierarchyMap.get(clientHierarchyMap.lastKey());
  }
}
