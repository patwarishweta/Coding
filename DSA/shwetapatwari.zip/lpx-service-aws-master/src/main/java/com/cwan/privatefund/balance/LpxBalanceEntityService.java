package com.cwan.privatefund.balance;

import com.cwan.lpx.domain.Balance;
import com.cwan.pbor.balance.api.Balances;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
public class LpxBalanceEntityService {

  private final AccountService accountService;
  private final Balances balances;
  private final SecurityService securityService;
  private final Documents documents;

  public LpxBalanceEntityService(
      AccountService accountService,
      Balances balances,
      SecurityService securityService,
      Documents documents) {
    this.accountService = accountService;
    this.balances = balances;
    this.securityService = securityService;
    this.documents = documents;
  }

  public Flux<Balance> addBalance(Set<Balance> balancesToAdd) {
    return hydrateSecurityAndAccountData(balances.addBalance(balancesToAdd));
  }

  public Flux<Balance> getBalancesByIds(Set<Long> balanceIds) {
    return hydrateSecurityAndAccountData(balances.getBalancesByIds(balanceIds));
  }

  public Flux<Balance> deleteBalanceById(Set<Long> balanceIds) {
    return hydrateSecurityAndAccountData(balances.deleteBalanceById(balanceIds));
  }

  public Flux<Balance> updateBalanceInfo(Set<Balance> balancesToUpdate) {
    return hydrateSecurityAndAccountData(balances.updateBalanceInfo(balancesToUpdate));
  }

  public Flux<Balance> getBalancesByAccountAndDate(Set<Long> accountIds, LocalDate asOfDate) {
    return hydrateSecurityAndAccountData(
        balances.getBalancesByAccountAndDate(accountIds, asOfDate));
  }

  public Flux<Balance> getBalancesByDocumentIds(Set<Long> documentIds) {
    return hydrateSecurityAndAccountData(balances.getBalancesByDocumentIds(documentIds));
  }

  public Flux<Balance> getBalanceByAccountAndSecurityIdAndType(
      Long accountId, Long securityId, String type) {
    return hydrateSecurityAndAccountData(
        balances.getBalanceByAccountAndSecurityIdAndType(accountId, securityId, type));
  }

  public Flux<Balance> getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
      Long accountId, LocalDate balanceDate, LocalDateTime knowledgeStartDate) {
    return hydrateSecurityAndAccountData(
        balances.getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
            accountId, balanceDate, knowledgeStartDate));
  }

  public Flux<Balance> getBalancesOnBalanceDateForAccounts(
      Set<Long> accountIds, LocalDate balanceDate, LocalDateTime knowledgeStartDate) {
    return hydrateSecurityAndAccountData(
        balances.getBalancesOnBalanceDateForAccounts(accountIds, balanceDate, knowledgeStartDate));
  }

  public Flux<Balance> getBalancesOnBalanceDate(
      LocalDate balanceDate, LocalDateTime knowledgeStartDate) {
    return hydrateSecurityAndAccountData(
        balances.getBalancesOnBalanceDate(balanceDate, knowledgeStartDate));
  }

  public Flux<Balance>
      getBalancesByKnowledgeStartDateGreaterThanEqualAndKnowledgeStartDateLessThanAndKnowledgeEndDateAfter(
          LocalDateTime knowledgeStartDateGreaterThan,
          LocalDateTime knowledgeStartDateLessThan,
          LocalDateTime knowledgeEndDateGreaterThan) {
    return hydrateSecurityAndAccountData(
        balances
            .getBalancesByKnowledgeStartDateGreaterThanEqualAndKnowledgeStartDateLessThanAndKnowledgeEndDateAfter(
                knowledgeStartDateGreaterThan,
                knowledgeStartDateLessThan,
                knowledgeEndDateGreaterThan));
  }

  private Flux<Balance> hydrateSecurityAndAccountData(Flux<Balance> balanceFlux) {
    return balanceFlux
        .flatMap(this::addAccountDataToBalance)
        .flatMap((this::addSecurityDataToBalance))
        .flatMap(this::addDocumentDataToBalance);
  }

  private Mono<Balance> addSecurityDataToBalance(Balance balance) {
    return securityService
        .getSecurity(
            balance.getAccount().getClientId(),
            balance.getAccount().getId(),
            balance.getSecurity().getSecurityId())
        .map(security -> balance.toBuilder().security(security).build());
  }

  private Mono<Balance> addAccountDataToBalance(Balance balance) {
    return accountService
        .getAccountData(balance.getAccount().getId())
        .map(account -> balance.toBuilder().account(account).build());
  }

  private Mono<Balance> addDocumentDataToBalance(Balance balance) {
    if ((null != balance.getDocument()) && (null != balance.getDocument().getId())) {
      return documents
          .getDocumentById(balance.getDocument().getId())
          .map(document -> balance.toBuilder().document(document).build());
    }
    return Mono.just(balance);
  }
}
