package com.cwan.privatefund.document.model;

import com.cwan.privatefund.issuestore.model.Issue;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocumentAudit {

  private long documentId;
  private String documentName;
  private String documentType;
  private long accountId;
  private long securityId;
  private String client;
  private String investor;
  private String canoeId;
  private String knowledgeDate;
  private String cashMovementDate;
  private String assignee;
  private Issue issue;
  private String actionBy;
  private Boolean validated;
  private String validatedBy;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDateTime validatedOn;
}
