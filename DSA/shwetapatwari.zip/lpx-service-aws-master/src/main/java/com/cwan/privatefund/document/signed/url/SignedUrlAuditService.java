package com.cwan.privatefund.document.signed.url;

import com.cwan.privatefund.auth.SecurityContextService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
public class SignedUrlAuditService {

  private final SignedUrlAuditRepository signedUrlAuditRepository;
  private final BusinessWSCache businessWebCache;
  private final SecurityContextService securityContextService;

  public SignedUrlAuditService(
      SignedUrlAuditRepository signedUrlAuditRepository,
      BusinessWSCache businessWebCache,
      SecurityContextService securityContextService) {
    this.signedUrlAuditRepository = signedUrlAuditRepository;
    this.businessWebCache = businessWebCache;
    this.securityContextService = securityContextService;
  }

  public Mono<Void> performAudit(Long documentId) {
    return securityContextService
        .getContext()
        .doOnNext(sc -> log.debug("Retrieved SecurityContext: {}", sc))
        .flatMap(this::validateAndRetrieveUserDetails)
        .flatMap(user -> auditSignedUrlAccess(documentId, user))
        .doOnSuccess(v -> log.info("Completed audit for documentId: {}", documentId))
        .onErrorResume(
            e -> {
              log.error("Failed to save audit for documentId: {}", documentId, e);
              return Mono.empty();
            });
  }

  private Mono<User> validateAndRetrieveUserDetails(SecurityContext securityContext) {
    log.debug("Validating and retrieving user details from SecurityContext");
    return validateAndGetUserId(securityContext)
        .flatMap(this::fetchAndValidateUserDetails)
        .switchIfEmpty(Mono.defer(Mono::empty));
  }

  private Mono<Integer> validateAndGetUserId(SecurityContext securityContext) {
    log.debug("Extracting userId from SecurityContext");
    var authentication = securityContext.getAuthentication();
    if (Objects.nonNull(authentication)) {
      log.debug("Authentication object found: {}", authentication);
      if (authentication.getPrincipal() instanceof Integer userId) {
        log.info("UserId extracted: {}", userId);
        return Mono.just(userId);
      }
    }
    return Mono.empty();
  }

  private Mono<User> fetchAndValidateUserDetails(Integer userId) {
    return businessWebCache
        .fetchUserDetails(userId)
        .doOnNext(user -> log.debug("Fetched user details: {}", user))
        .flatMap(this::validateAndBuildUserDetails)
        .switchIfEmpty(Mono.defer(Mono::empty));
  }

  private Mono<User> validateAndBuildUserDetails(User user) {
    log.debug("Validating user details: {}", user);
    if (Objects.isNull(user)
        || Objects.isNull(user.getId())
        || StringUtils.isBlank(user.getEmail())
        || user.isInternalUser()) {
      return Mono.empty();
    }
    User validUser =
        User.builder().id(user.getId()).fullname(user.getFullname()).email(user.getEmail()).build();
    log.info("User validated: {}", validUser);
    return Mono.just(validUser);
  }

  private Mono<Void> auditSignedUrlAccess(Long documentId, User user) {
    if (Objects.nonNull(user)) {
      log.info("Auditing access for userId: {} on documentId: {}", user.getId(), documentId);
      var audit =
          SignedUrlAudit.builder()
              .userId(user.getId())
              .userEmail(user.getEmail())
              .documentId(documentId)
              .build();
      log.debug("Created SignedUrlAudit object: {}", audit);
      return Mono.fromRunnable(
              () -> {
                log.debug("Saving SignedUrlAudit to repository");
                signedUrlAuditRepository.saveAndFlush(audit);
                log.info("SignedUrlAudit saved successfully for userId: {}", user.getId());
              })
          .subscribeOn(Schedulers.boundedElastic())
          .then();
    }
    return Mono.empty();
  }
}
