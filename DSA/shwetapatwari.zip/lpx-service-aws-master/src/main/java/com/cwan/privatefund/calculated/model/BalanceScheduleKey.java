package com.cwan.privatefund.calculated.model;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import lombok.Data;

@Data
public class BalanceScheduleKey {
  private final long accountId;
  private final long securityId;
  private final transient Account account;
  private final transient Security security;
  private final transient String source;
}
