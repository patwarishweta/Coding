package com.cwan.privatefund.capital.call.management.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankBlacklistResponse(
    String bankBlacklistUuid,
    String bankUuid,
    String bankName,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdAt,
    String creatorName,
    String creatorEmail)
    implements Serializable {

  public static class BankBlacklistResponseBuilder {

    public BankBlacklistResponse.BankBlacklistResponseBuilder bankBlacklistUuid(
        String bankBlacklistUuid) {
      this.bankBlacklistUuid =
          StringUtils.trimToNull(StringUtils.normalizeSpace(bankBlacklistUuid));
      return this;
    }

    public BankBlacklistResponse.BankBlacklistResponseBuilder bankUuid(String bankUuid) {
      this.bankUuid = StringUtils.trimToNull(StringUtils.normalizeSpace(bankUuid));
      return this;
    }

    public BankBlacklistResponse.BankBlacklistResponseBuilder bankName(String bankName) {
      this.bankName = StringUtils.trimToNull(StringUtils.normalizeSpace(bankName));
      return this;
    }

    public BankBlacklistResponse.BankBlacklistResponseBuilder creatorName(String creatorName) {
      this.creatorName = StringUtils.trimToNull(StringUtils.normalizeSpace(creatorName));
      return this;
    }

    public BankBlacklistResponse.BankBlacklistResponseBuilder creatorEmail(String creatorEmail) {
      this.creatorEmail = StringUtils.trimToNull(StringUtils.normalizeSpace(creatorEmail));
      return this;
    }
  }
}
