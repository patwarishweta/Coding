package com.cwan.privatefund.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/** Service for getting SecurityContext. */
@Service
public class SecurityContextService {

  private final ISecurityContextProvider securityContextProvider;

  /**
   * Constructor for injecting dependencies.
   *
   * @param securityContextProvider the provider of SecurityContext
   */
  @Autowired
  public SecurityContextService(ISecurityContextProvider securityContextProvider) {
    this.securityContextProvider = securityContextProvider;
  }

  /**
   * Get the current SecurityContext.
   *
   * @return the current SecurityContext wrapped in a Mono.
   */
  public Mono<SecurityContext> getContext() {
    return securityContextProvider.provideContext();
  }
}
