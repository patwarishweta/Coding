package com.cwan.privatefund.cpd.ws.model;

import com.ca.tabular.field.DataType;
import java.util.Map;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class CpdFieldAndData {
  private Integer id;
  private Long clientId;
  private String tagType;
  private String name;
  private DataType dataType;
  private String definition;
  private boolean active;
  private Set<String> properties;
  private boolean staticField;
  private Map<Integer, String> data;

  public CpdFieldAndData(CpdField cpdField, Map<Integer, String> data) {
    this.id = cpdField.id();
    this.clientId = cpdField.clientId();
    this.tagType = cpdField.tagType();
    this.name = cpdField.name();
    this.dataType = cpdField.dataType();
    this.definition = cpdField.definition();
    this.active = cpdField.active();
    this.properties = cpdField.properties();
    this.staticField = cpdField.staticField();
    this.data = data;
  }
}
