package com.cwan.privatefund.clientSpecificData;

import com.cwan.lpx.domain.ClientSpecificData;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping(value = "v1/client-specific-data")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class ClientSpecificDataController {
  private final LpxClientSpecificDataService lpxClientSpecificDataService;

  ClientSpecificDataController(LpxClientSpecificDataService clientSpecificDataService) {
    this.lpxClientSpecificDataService = clientSpecificDataService;
  }

  @PostMapping()
  @Operation(
      summary = "Saves/Updates the client specific data for the given accountId and securityId")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Client Specific Data Saved/Updated"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public List<ClientSpecificData> saveClientSpecificData(
      @Parameter(description = "clientSpecificData") @RequestBody
          Set<ClientSpecificData> clientSpecificData) {
    return lpxClientSpecificDataService.saveClientSpecificData(clientSpecificData);
  }
}
