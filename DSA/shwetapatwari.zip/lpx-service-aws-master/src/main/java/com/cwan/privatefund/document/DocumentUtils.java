package com.cwan.privatefund.document;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.util.DateUtils;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

@Slf4j
public final class DocumentUtils {

  /**
   * Appends timestamp to filename before its extension.
   *
   * @param fileName Original file name
   * @param uploadDate Date to append
   * @param maxLength Maximum length allowed for the name part
   * @return Modified file name with timestamp
   */
  public static String appendTimestampBeforeExtension(
      String fileName, LocalDateTime uploadDate, int maxLength) {
    String dateString = DateUtils.convertDateTimeFormat(uploadDate);
    int lastDotIndex = fileName.lastIndexOf(".");
    if (lastDotIndex == -1) {
      fileName = truncateFileName(fileName, maxLength);
      return fileName + "_" + dateString;
    }
    String namePart = fileName.substring(0, lastDotIndex);
    String extensionPart = fileName.substring(lastDotIndex);
    namePart = truncateFileName(namePart, maxLength);
    return namePart + "_" + dateString + extensionPart;
  }

  /**
   * Creates a map of entities keyed by their IDs, with optional merge function for duplicates.
   *
   * @param entities Collection of entities to map
   * @param idGetter Function to extract ID from entity
   * @param mergeFunction Function to resolve duplicate keys
   * @return TreeMap of entities sorted by ID in reverse order
   */
  public static <T, I extends Comparable<? super I>> Map<I, T> createEntityMap(
      Collection<T> entities, Function<T, I> idGetter, BinaryOperator<T> mergeFunction) {
    if (CollectionUtils.isEmpty(entities)) {
      return Collections.emptyMap();
    }
    return entities.stream()
        .filter(Objects::nonNull)
        .filter(entity -> Objects.nonNull(idGetter.apply(entity)))
        .collect(
            Collectors.toMap(
                idGetter,
                Function.identity(),
                Objects.requireNonNullElse(mergeFunction, (existing, replacement) -> replacement),
                () -> new TreeMap<>(Comparator.reverseOrder())));
  }

  /**
   * Extracts a set of IDs from documents based on provided entity and ID getter functions.
   *
   * @param documents Collection of documents
   * @param entityGetter Function to extract entity from document
   * @param idGetter Function to extract ID from entity
   * @return Set of extracted IDs
   */
  public static <T, R> Set<R> extractIds(
      Collection<Document> documents, Function<Document, T> entityGetter, Function<T, R> idGetter) {
    if (CollectionUtils.isEmpty(documents)) {
      return Collections.emptySet();
    }
    return documents.stream()
        .filter(Objects::nonNull)
        .map(entityGetter)
        .filter(Objects::nonNull)
        .map(idGetter)
        .filter(Objects::nonNull)
        .collect(Collectors.toSet());
  }

  /**
   * Hydrates a document with account and security information from provided maps.
   *
   * @param document Document to hydrate
   * @param accountMap Map of accounts
   * @param securityMap Map of securities
   * @return Hydrated document
   */
  public static Document hydrateDocument(
      Document document, Map<Long, Account> accountMap, Map<Long, Security> securityMap) {
    Document hydratedDoc = document.toBuilder().build();
    Account account = hydratedDoc.getAccount();
    if (Objects.nonNull(account) && Objects.nonNull(account.getId())) {
      hydratedDoc.setAccount(accountMap.get(account.getId()));
    }
    Security security = hydratedDoc.getSecurity();
    if (Objects.nonNull(security) && Objects.nonNull(security.getSecurityId())) {
      hydratedDoc.setSecurity(securityMap.get(security.getSecurityId()));
    }
    return hydratedDoc;
  }

  /**
   * Truncates a filename to the specified maximum length.
   *
   * @param fileName File name to truncate
   * @param maxLength Maximum length allowed
   * @return Truncated file name
   */
  public static String truncateFileName(String fileName, int maxLength) {
    if (fileName.length() <= maxLength) {
      return fileName;
    }
    return fileName.substring(0, maxLength);
  }

  private DocumentUtils() {
    // Private constructor to prevent instantiation
  }
}
