package com.cwan.privatefund.calculated;

import com.cwan.privatefund.calculated.model.CalculatedBalance;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v2/backend/calculated/balance")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class BackendCalculatedBalanceController {

  private final CalculatedBalanceService calculatedBalanceService;

  BackendCalculatedBalanceController(CalculatedBalanceService calculatedBalanceService) {
    this.calculatedBalanceService = calculatedBalanceService;
  }

  @GetMapping(value = "/account")
  @Operation(summary = "get calculated balances by accountId", hidden = true)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = CalculatedBalance.class))
            })
      })
  public Flux<CalculatedBalance> getCalculatedBalances(
      @RequestParam("accountId") Long accountId,
      @RequestParam(value = "asOfDate", required = false)
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate asOfDate,
      @RequestParam(value = "knowledgeDate", required = false)
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    log.info(
        "received request for accountId: {}, asOfDate: {}, knowledgeDate: {}",
        accountId,
        asOfDate,
        knowledgeDate);
    return calculatedBalanceService.calculateBalances(accountId, asOfDate, knowledgeDate, false);
  }
}
