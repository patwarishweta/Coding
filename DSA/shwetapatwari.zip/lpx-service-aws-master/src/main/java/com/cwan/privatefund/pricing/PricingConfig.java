package com.cwan.privatefund.pricing;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import com.cwan.privatefund.client.WebResponseMapper;
import com.cwan.privatefund.pricing.model.PricingData;
import com.cwan.privatefund.pricing.model.PricingRequest;
import com.cwan.privatefund.pricing.model.PricingResponse;
import com.cwan.privatefund.util.LoggingUtils;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class PricingConfig {

  @Value("${pricing.server}")
  private String pricingServer;

  @Value("${pricing.cache.maxsize}")
  private Integer maxCacheSize;

  @Value("${pricing.cache.timeout.hours}")
  private Integer cacheDurationHrs;

  @Value("${pricing.client.request.batchsize}")
  private Integer pricingClientBatchSize;

  @Bean(value = "pricingClient")
  PricingClient pricingClient() {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(pricingServer, 443, "pricing-data-ws", Resource.Scheme.HTTPS);
    PricingClient pricingClient =
        LoggingUtils.logMethodCalls(
            new PricingClient(WsHttpClientBuilder.getSharedDefault(), serverConfiguration),
            PricingClient.class,
            PricingClient.class.getName() + ".START_TIME");
    return pricingClient;
  }

  @Bean(value = "pricingResponseMapper")
  WebResponseMapper<PricingException> pricingResponseMapper() {
    return new WebResponseMapper<>() {
      @Override
      protected PricingException getException(String msg) {
        return new PricingException(msg);
      }
    };
  }

  @Bean(value = "pricingCache")
  LoadingCache<PricingRequest, PricingResponse> pricingCache(PricingClient pricingClient) {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build(
            new CacheLoader<>() {
              @Override
              public PricingResponse load(PricingRequest pricingRequest) {
                List<PricingResponse> responses = new ArrayList<>();
                List<List<Long>> batches =
                    Lists.partition(pricingRequest.getSecurityIds(), pricingClientBatchSize);
                for (List<Long> securityIds : batches) {
                  responses.add(
                      pricingClient.getPricingData(
                          pricingRequest.getAccountId(), securityIds, pricingRequest.getDate()));
                }

                Map<String, Map<Long, PricingData>> combinedResponse =
                    responses.stream()
                        .filter(Objects::nonNull)
                        .flatMap(e -> e.getRawData().entrySet().stream())
                        .collect(
                            Collectors.toMap(
                                Entry::getKey,
                                Entry::getValue,
                                (v1, v2) -> {
                                  v1.putAll(v2);
                                  return v1;
                                },
                                HashMap::new));
                return new PricingResponse(combinedResponse);
              }
            });
  }
}
