package com.cwan.privatefund.auth.ws;

import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.google.common.cache.Cache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class AuthWSCache {

  private final AuthWSClient authWSClient;
  private final Cache<SessionValidRequest, Boolean> sessionValidCache;

  public AuthWSCache(
      AuthWSClient authWSClient, Cache<SessionValidRequest, Boolean> sessionValidCache) {
    this.authWSClient = authWSClient;
    this.sessionValidCache = sessionValidCache;
  }

  public Mono<Boolean> isSessionValid(SessionValidRequest request) {
    var isValid = sessionValidCache.getIfPresent(request);
    if (isValid != null) {
      return Mono.just(isValid);
    }
    return authWSClient
        .isSessionValid(request)
        .doOnNext(valid -> sessionValidCache.put(request, valid));
  }
}
