package com.cwan.privatefund.directory;

import static java.util.stream.Collectors.toMap;

import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryEntity;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class DirectoryService {

  private final DirectoryRepository directoryRepository;
  private final DirectoryTransformer directoryTransformer;
  private final DirectoryEntityTransformer directoryEntityTransformer;

  @Autowired
  public DirectoryService(
      DirectoryRepository directoryRepository,
      DirectoryTransformer directoryTransformer,
      DirectoryEntityTransformer directoryEntityTransformer) {
    this.directoryRepository = directoryRepository;
    this.directoryTransformer = directoryTransformer;
    this.directoryEntityTransformer = directoryEntityTransformer;
  }

  public Flux<Directory> getAllDirectoriesByAccountId(Long accountId) {
    try {
      return Flux.fromIterable(directoryRepository.findAllByAccountId(accountId))
          .map(directoryTransformer);
    } catch (Exception e) {
      throw new DirectoryException(
          HttpStatus.INTERNAL_SERVER_ERROR, "Unable to find the Directory for given accountId", e);
    }
  }

  public Mono<Directory> getById(Long directoryId) {
    return Mono.justOrEmpty(directoryRepository.findById(directoryId)).map(directoryTransformer);
  }

  public Flux<Directory> addDirectories(final Set<Directory> directories) {
    directories.stream()
        .filter(directory -> directory.getId() != null)
        .forEach(
            directory ->
                log.warn(
                    "Directory with Id {} can't be added. Id should be null.", directory.getId()));
    return Flux.fromIterable(directories)
        .filter(Objects::nonNull)
        .filter(directory -> directory.getId() == null)
        .map(directoryEntityTransformer)
        .map(this::saveDirectory)
        .map(
            directoryEntity -> {
              log.info("Directory saved in pabor db with id " + directoryEntity.getId());
              return directoryTransformer.apply(directoryEntity);
            });
  }

  public Flux<Directory> updateDirectoryInfo(final Set<Directory> directories) {
    var idToDirectoryMap =
        directories.stream()
            .filter(directory -> directory.getId() != null)
            .collect(toMap(Directory::getId, directoryEntityTransformer));
    var requestedDirectoryIds = new HashSet<>(idToDirectoryMap.keySet());
    return findAllByIds(requestedDirectoryIds)
        .log("updateDirectoryInfo")
        .filter(directory -> requestedDirectoryIds.remove(directory.getId()))
        .mapNotNull(directory -> idToDirectoryMap.get(directory.getId()))
        .map(this::saveDirectory)
        .map(directoryTransformer)
        .doOnComplete(
            () -> {
              for (var directoryId : requestedDirectoryIds) {
                log.info(
                    "Could not update directory id: {} because it does not exist.", directoryId);
              }
            });
  }

  private Flux<DirectoryEntity> findAllByIds(Set<Long> directoryIds) {
    return Flux.fromIterable(directoryRepository.findAllById(directoryIds));
  }

  private DirectoryEntity saveDirectory(DirectoryEntity directoryEntity) {
    return directoryRepository.saveAndFlush(directoryEntity);
  }
}
