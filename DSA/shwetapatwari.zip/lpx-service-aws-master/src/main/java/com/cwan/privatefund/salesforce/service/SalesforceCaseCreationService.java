package com.cwan.privatefund.salesforce.service;

import com.cwan.privatefund.salesforce.common.SalesforceProperties;
import com.cwan.privatefund.salesforce.config.SaleForceUtils;
import com.cwan.privatefund.salesforce.exception.SalesforceException;
import com.cwan.privatefund.salesforce.model.SalesforceObjectDetails;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class SalesforceCaseCreationService {

  private static final String CASE_STATUS = "closed";
  private static final String CASE_PRIORITY = "Minor";
  private static final String ORIGIN = "Capital Call";
  private final RestTemplate restTemplate;
  private static final String CASE_SERVICE_URL = "https://%s/services/data/v57.0/sobjects/Case/";
  private final SalesforceProperties salesforceProperties;

  public SalesforceCaseCreationService(
      SalesforceProperties salesforceProperties, RestTemplate restTemplate) {
    this.salesforceProperties = salesforceProperties;
    this.restTemplate = restTemplate;
  }

  public String createSalesforceCase(String authToken, String accountId) {
    var salesforceObjectDetails = getSalesforceObjectDetailsRequest(accountId);
    return executeSFCaseRequest(authToken, salesforceObjectDetails);
  }

  private SalesforceObjectDetails getSalesforceObjectDetailsRequest(String accountId) {
    return SalesforceObjectDetails.builder()
        .status(CASE_STATUS)
        .subject("Emails for New and Updated Capital Calls")
        .priority(CASE_PRIORITY)
        .description(
            "This case contains all emails sent that are related to new capital calls or changes in existing capital calls within the account : "
                + accountId)
        .recordTypeId(salesforceProperties.getSfRecordTypeID().trim())
        .origin(ORIGIN)
        .capitalCallAccountId(accountId)
        .build();
  }

  private String executeSFCaseRequest(
      String authToken, SalesforceObjectDetails salesforceObjectDetails) {
    var headers = SaleForceUtils.createHttpHeaders(MediaType.APPLICATION_JSON, authToken);
    var entity = new HttpEntity<>(salesforceObjectDetails, headers);
    var url = String.format(CASE_SERVICE_URL, salesforceProperties.getSfInstanceHost());
    ResponseEntity<JsonNode> responseEntity =
        SaleForceUtils.makeRequest(restTemplate, url, HttpMethod.POST, entity, JsonNode.class);
    if (!HttpStatus.CREATED.equals(responseEntity.getStatusCode())) {
      throw new SalesforceException(
          "Failed to create a case in Salesforce. Error: " + responseEntity.getBody());
    }
    var caseId =
        Optional.ofNullable(responseEntity.getBody())
            .map(body -> body.get("id").asText())
            .orElse(
                null); // The "NullPointerException" could not be thrown; "response" should be here.
    if (caseId == null) {
      throw new SalesforceException("No case Id returned in response body");
    }
    log.info(
        "The generated case ID for the account ID: {} is: {}",
        salesforceObjectDetails.getCapitalCallAccountId(),
        caseId);
    return caseId;
  }
}
