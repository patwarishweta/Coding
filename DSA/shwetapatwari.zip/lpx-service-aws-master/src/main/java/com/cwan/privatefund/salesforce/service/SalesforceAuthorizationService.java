package com.cwan.privatefund.salesforce.service;

import com.cwan.privatefund.salesforce.common.SalesforceProperties;
import com.cwan.privatefund.salesforce.config.SaleForceUtils;
import com.cwan.privatefund.salesforce.exception.SalesforceException;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class SalesforceAuthorizationService {

  private final SalesforceProperties salesforceProperties;
  private final RestTemplate restTemplate;
  private static final String OAUTH_TOKEN_URL = "https://%s/services/oauth2/token";
  public static final String GRANT_TYPE = "client_credentials";

  public SalesforceAuthorizationService(
      SalesforceProperties salesforceProperties, RestTemplate restTemplate) {
    this.salesforceProperties = salesforceProperties;
    this.restTemplate = restTemplate;
  }

  public String getSalesforceAuthToken() {
    var response = executeSalesforceAuthRequest();
    var accessToken =
        Optional.ofNullable(response)
            .map(body -> body.get("access_token").asText())
            .orElse(
                null); // The "NullPointerException" could not be thrown; "response" should be here.
    if (accessToken == null) {
      throw new SalesforceException("No access token returned in response body");
    }
    return accessToken;
  }

  private JsonNode executeSalesforceAuthRequest() {
    var headers = SaleForceUtils.createHttpHeaders(MediaType.APPLICATION_FORM_URLENCODED, null);
    var builder =
        UriComponentsBuilder.fromHttpUrl(
                String.format(OAUTH_TOKEN_URL, salesforceProperties.getSfAuthHost()))
            .queryParam("grant_type", GRANT_TYPE)
            .queryParam("client_id", salesforceProperties.getClientId().trim())
            .queryParam("client_secret", salesforceProperties.getClientSecret().trim());
    HttpEntity<?> entity = new HttpEntity<>(headers);
    ResponseEntity<JsonNode> responseEntity =
        SaleForceUtils.makeRequest(
            restTemplate, builder.toUriString(), HttpMethod.POST, entity, JsonNode.class);
    if (responseEntity.getStatusCode().isError()) {
      throw new SalesforceException(
          "Error: " + responseEntity.getStatusCode() + ", Message: " + responseEntity.getBody());
    }
    log.info("The auth token has been successfully generated");
    return responseEntity.getBody();
  }
}
