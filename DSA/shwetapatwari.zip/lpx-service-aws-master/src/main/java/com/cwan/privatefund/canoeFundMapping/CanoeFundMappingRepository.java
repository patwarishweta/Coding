package com.cwan.privatefund.canoeFundMapping;

import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingAccountResponse;
import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingClientResponse;
import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingEntity;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CanoeFundMappingRepository extends JpaRepository<CanoeFundMappingEntity, String> {

  @Query(
      "SELECT DISTINCT NEW com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingClientResponse(cfm.clientId, cfm.clientName)"
          + " FROM CanoeFundMappingEntity cfm where cfm.clientId is not NULL and cfm.clientName is not NULL ")
  Set<CanoeFundMappingClientResponse> findAllClientNames();

  @Query(
      "SELECT DISTINCT NEW com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingAccountResponse(cfm.accountId, cfm.accountName) "
          + "FROM CanoeFundMappingEntity cfm "
          + "WHERE cfm.clientId = :clientId")
  List<CanoeFundMappingAccountResponse> findAccountByClientId(@Param("clientId") Long clientId);
}
