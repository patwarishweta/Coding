package com.cwan.privatefund.calculated;

import com.cwan.privatefund.calculated.model.AccountingCalculatedBalance;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import com.cwan.privatefund.transaction.model.NavSchedules;
import com.google.common.base.Stopwatch;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/calculated/balance")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class CalculatedBalanceController {

  private final CalculatedBalanceService calculatedBalanceService;

  CalculatedBalanceController(CalculatedBalanceService calculatedBalanceService) {
    this.calculatedBalanceService = calculatedBalanceService;
  }

  @GetMapping(value = "/account")
  @Operation(summary = "get calculated balances by accountId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = CalculatedBalance.class))
            })
      })
  public Flux<CalculatedBalance> getCalculatedBalances(
      @RequestParam("accountId") Long accountId,
      @RequestParam(value = "asOfDate", required = false)
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate asOfDate,
      @RequestParam(value = "knowledgeDate", required = false)
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    log.info(
        "received request for accountId: {}, asOfDate: {}, knowledgeDate: {}",
        accountId,
        asOfDate,
        knowledgeDate);
    Stopwatch timer = Stopwatch.createUnstarted();
    timer.start();
    return calculatedBalanceService
        .calculateBalances(accountId, asOfDate, knowledgeDate, false)
        .doFinally(
            signalType -> {
              timer.stop();
              log.info(
                  "{} TOTAL TIME TAKEN FOR CALCULATED BALANCE API CALL accId:{} asOfdate:{}",
                  timer,
                  accountId,
                  asOfDate);
            });
  }

  @GetMapping(value = "/account/accounting")
  @Operation(summary = "get calculated balances by accountId for the accounting etl")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = CalculatedBalance.class))
            })
      })
  public Flux<AccountingCalculatedBalance> getCalculatedBalancesForAccounting(
      @RequestParam("accountId") Long accountId,
      @RequestParam(value = "asOfDate", required = false)
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate asOfDate,
      @RequestParam(value = "knowledgeDate", required = false)
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    Stopwatch timer = Stopwatch.createUnstarted();
    timer.start();
    return calculatedBalanceService
        .calculateBalances(accountId, asOfDate, knowledgeDate, true)
        .onErrorResume(Flux::error)
        .map(CalculatedBalance::toAccountingCalculatedBalance)
        .doFinally(
            signalType -> {
              timer.stop();
              log.info(
                  "TOTAL TIME TAKEN: {} FOR CALCULATED BALANCE ACCOUNTING API CALL accId:{} asOfdate:{}",
                  timer,
                  accountId,
                  asOfDate);
            });
  }

  @GetMapping(value = "/nav-schedule")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get nav schedule")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Nav schedules fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<NavSchedules> getNavSchedule(
      @RequestParam("accountId") Long accountId,
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    return calculatedBalanceService
        .getNavSchedule(accountId, beginDate, endDate, knowledgeDate, false)
        .onErrorResume(Flux::error);
  }

  @GetMapping(value = "/nav-schedule/accounting")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get nav schedule")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Nav schedules fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<NavSchedules> getNavScheduleForAccounting(
      @RequestParam("accountId") Long accountId,
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {

    return calculatedBalanceService
        .getNavSchedule(accountId, beginDate, endDate, knowledgeDate, true)
        .<NavSchedules>handle(
            (navSchedules, sink) -> {
              if (navSchedules.getGaapNavSchedule().isEmpty()
                  && navSchedules.getStatNavSchedule().isEmpty()) {
                log.error(
                    "NavSchedules is empty for accountId: {}, beginDate: {}, endDate: {}, knowledgeDate: {}",
                    accountId,
                    beginDate,
                    endDate,
                    knowledgeDate);
                sink.error(
                    new IllegalStateException("NavSchedules is empty for accountId: " + accountId));
                return;
              }
              sink.next(navSchedules);
            })
        .onErrorResume(Flux::error);
  }
}
