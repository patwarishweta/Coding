package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.cashflow.bankdetail.api.BankDetails;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.IntStream;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import reactor.core.publisher.Mono;

/**
 * Service responsible for handling and sending Capital Call related emails. This service utilizes a
 * template engine to generate email content based on the provided Capital Call document.
 */
@Service
@Slf4j
public class CapitalCallPaymentInitiationService {

  private final TemplateEngine thymeleafTemplateEngine;
  private final BankDetails bankDetails;

  /**
   * Initializes a new instance of the CapitalCallEmailNotificationService with the provided
   * services and template engine.
   *
   * @param thymeleafTemplateEngine Template engine to generate email content.
   * @param bankDetails Bank Details
   */
  public CapitalCallPaymentInitiationService(
      TemplateEngine thymeleafTemplateEngine, BankDetails bankDetails) {
    this.thymeleafTemplateEngine = thymeleafTemplateEngine;
    this.bankDetails = bankDetails;
  }

  /**
   * Processes payment initiation for a given capital call document. Validates the status of the
   * capital call document before proceeding. Generates a payment initiation XML string based on the
   * document details.
   *
   * @param capitalCallDocument The capital call document to process.
   * @return A Mono of String containing the payment initiation XML.
   * @throws IllegalStateException if the capital call document status is not COMPLETE.
   */
  public Mono<String> processPaymentInitiation(CapitalCallDocument capitalCallDocument) {
    log.debug("Initiating payment processing for document: {}", capitalCallDocument);
    return Mono.fromCallable(
        () -> {
          if (!CapitalCallStatus.COMPLETED.equals(capitalCallDocument.status())) {
            log.error("Document status is not COMPLETE for document: {}", capitalCallDocument);
            throw new IllegalStateException("Capital Call Document status is not COMPLETE");
          }
          log.info("Document status verified as COMPLETE for document: {}", capitalCallDocument);
          var context = new Context();
          context.setVariables(
              new HashMap<>(preparePropsForPaymentInitiation(capitalCallDocument)));
          var writer = new StringWriter();
          writer.write(thymeleafTemplateEngine.process("payment-initiation.xml", context));
          log.info("Payment initiation processing completed for document: {}", capitalCallDocument);
          return writer.toString();
        });
  }

  private Map<String, String> preparePropsForPaymentInitiation(CapitalCallDocument document) {
    Map<String, String> props = new HashMap<>();
    var properties = getProps(document);
    trimAndSetValue(props, properties.msgId(), "msgId");
    trimAndSetValue(props, properties.creDtTm(), "creDtTm");
    trimAndSetValue(props, properties.nbOfTxs(), "nbOfTxs");
    trimAndSetValue(props, properties.paymentAmount(), "ctrlSum");
    trimAndSetValue(props, properties.clientName(), "initgPtyNm");
    trimAndSetValue(props, properties.documentId(), "pmtInfId");
    trimAndSetValue(props, properties.pmtMtd(), "pmtMtd");
    trimAndSetValue(props, properties.btchBookg(), "btchBookg");
    trimAndSetValue(props, properties.dueDateString(), "reqdExctnDt");
    trimAndSetValue(props, properties.clientName(), "dbtrNm");
    trimAndSetValue(props, properties.accountNumber(), "dbtrAcctId");
    trimAndSetValue(props, properties.instrId(), "instrId");
    trimAndSetValue(props, properties.instrId(), "endToEndId");
    trimAndSetValue(props, properties.paymentAmount(), "instdAmt");
    trimAndSetValue(props, properties.currency(), "ccy");
    trimAndSetValue(props, properties.gpName(), "cdtrNm");
    trimAndSetValue(props, properties.accountNumber(), "cdtrAcctId");
    trimAndSetValue(props, properties.purpCd(), "purpCd");
    setCreditAgent(properties.capitalCallBankDetail(), props);
    setAddressLines(properties.capitalCallBankDetail(), props);
    return props;
  }

  private static void setCreditAgent(
      CapitalCallBankDetail capitalCallBankDetail, Map<String, String> props) {
    if (Objects.nonNull(capitalCallBankDetail)) {
      var cdtrAgtBICFI = "cdtrAgtBICFI";
      if (Objects.nonNull(capitalCallBankDetail.swiftOrChips())) {
        trimAndSetValue(props, capitalCallBankDetail.swiftOrChips(), cdtrAgtBICFI);
      } else {
        trimAndSetValue(
            props,
            Objects.nonNull(capitalCallBankDetail.abaRoutingNumber())
                ? capitalCallBankDetail.abaRoutingNumber()
                : null,
            cdtrAgtBICFI);
      }
    }
  }

  void setAddressLines(CapitalCallBankDetail capitalCallBankDetail, Map<String, String> props) {
    if (Objects.nonNull(capitalCallBankDetail)
        && Objects.nonNull(capitalCallBankDetail.bankDetailId())) {
      var bankDetailByIds =
          bankDetails.getBankDetailByIds(Set.of(capitalCallBankDetail.bankDetailId()));
      bankDetailByIds
          .next()
          .filter(Objects::nonNull)
          .filter(bankDetail -> Objects.nonNull(bankDetail.getAddress()))
          .subscribe(
              bankDetail -> {
                var split = StringUtils.split(bankDetail.getAddress(), ",");
                IntStream.range(0, 4)
                    .filter(i -> i < split.length)
                    .forEach(i -> trimAndSetValue(props, split[i], "adrLine" + i));
              });
    }
  }

  private static void trimAndSetValue(Map<String, String> props, String value, String key) {
    props.put(
        key,
        StringUtils.normalizeSpace(StringUtils.trimToNull(Objects.nonNull(value) ? value : "")));
  }

  private static Props getProps(CapitalCallDocument document) {
    var account = document.account();
    var clientId = Objects.nonNull(account) ? account.getClientId() : null;
    var accountId = Objects.nonNull(account) ? account.getId() : null;
    var documentId = Long.toString(document.documentId());
    var msgIdList = new ArrayList<Long>(3);
    if (Objects.nonNull(clientId)) {
      msgIdList.add(clientId);
    }
    if (Objects.nonNull(accountId)) {
      msgIdList.add(accountId);
    }
    var msgId = StringUtils.join(msgIdList, '/');
    var paymentAmount =
        Objects.nonNull(document.paymentAmount())
            ? document.paymentAmount().abs().toString()
            : null;
    var clientName =
        Objects.nonNull(account) && Objects.nonNull(account.getClient())
            ? account.getClient().getName()
            : null;
    var dueDateString =
        Objects.nonNull(document.dueDate())
            ? document.dueDate().format(DateTimeFormatter.ISO_LOCAL_DATE)
            : null;
    var capitalCallBankDetail = document.bankDetail();
    var accountNumber =
        Objects.nonNull(capitalCallBankDetail) ? capitalCallBankDetail.accountNumber() : null;
    msgIdList.add(1L);
    var instrId = StringUtils.join(msgIdList, '/');
    var currency = Objects.nonNull(document.currency()) ? document.currency() : null;
    var security = document.security();
    var fundDetail = Objects.nonNull(security) ? security.getFundDetail() : null;
    var gpName = Objects.nonNull(fundDetail) ? fundDetail.getGpName() : null;
    var creDtTm = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    var nbOfTxs = Long.toString(1L);
    var pmtMtd = "TRF";
    var btchBookg = "FALSE";
    var purpCd = "Capital Call Notice Payment";
    return Props.builder()
        .documentId(documentId)
        .msgId(msgId)
        .paymentAmount(paymentAmount)
        .clientName(clientName)
        .dueDateString(dueDateString)
        .capitalCallBankDetail(capitalCallBankDetail)
        .accountNumber(accountNumber)
        .instrId(instrId)
        .currency(currency)
        .gpName(gpName)
        .creDtTm(creDtTm)
        .nbOfTxs(nbOfTxs)
        .pmtMtd(pmtMtd)
        .btchBookg(btchBookg)
        .purpCd(purpCd)
        .build();
  }

  @Builder(toBuilder = true)
  private record Props(
      String documentId,
      String msgId,
      String paymentAmount,
      String clientName,
      String dueDateString,
      CapitalCallBankDetail capitalCallBankDetail,
      String accountNumber,
      String instrId,
      String currency,
      String gpName,
      String creDtTm,
      String nbOfTxs,
      String pmtMtd,
      String btchBookg,
      String purpCd) {}
}
