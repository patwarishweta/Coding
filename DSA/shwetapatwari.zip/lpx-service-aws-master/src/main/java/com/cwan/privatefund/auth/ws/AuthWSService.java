package com.cwan.privatefund.auth.ws;

import reactor.core.publisher.Mono;

public class AuthWSService {

  private final AuthWSClient authWSClient;

  public AuthWSService(AuthWSClient authWSClient) {
    this.authWSClient = authWSClient;
  }

  public Mono<SAMLResponse> initiatePartnerSSO(String partnerCode, String authorization) {
    return authWSClient.initiatePartnerSSO(partnerCode, authorization);
  }
}
