package com.cwan.privatefund.directory;

import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/directory")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class DirectoryController {

  private final DirectoryService directoryService;

  public DirectoryController(DirectoryService directoryService) {
    this.directoryService = directoryService;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add all directories")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added Directory successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Directory.class))
            })
      })
  public Flux<Directory> addDirectories(
      @Parameter(description = "Directory Data") @RequestBody DirectoryRequest directories) {
    return directoryService.addDirectories(directories.getDirectories());
  }

  @PutMapping
  @Operation(summary = "update all directories info")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Directory.class))
            })
      })
  public Flux<Directory> updateDirectoryInfo(@RequestBody DirectoryRequest request) {
    return directoryService.updateDirectoryInfo(request.getDirectories());
  }

  @GetMapping(value = "/account")
  @Operation(summary = "get all directories by account id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Directory.class))
            })
      })
  public Flux<Directory> getAllDirectoriesByAccountId(@RequestParam("accountId") Long accountId) {
    return directoryService.getAllDirectoriesByAccountId(accountId);
  }

  @GetMapping
  @Operation(summary = "get directory by directoryId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Directory.class))
            })
      })
  public Mono<Directory> getAllById(@RequestParam("directoryId") Long directoryId) {
    return directoryService.getById(directoryId);
  }
}
