package com.cwan.privatefund.tabular.controller;

import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_DISPOSITION_HEADER;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_ENCODING_HEADER;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_TYPE_CSV;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_TYPE_HEADER;

import com.ca.json2.utils.JsonUtils2;
import com.ca.ws.json.JsonTabularDataStreamingOutput;
import com.cwan.privatefund.tabular.dataset.DataSetUtils;
import com.cwan.privatefund.tabular.service.TabularTransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.ws.rs.core.StreamingOutput;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@Slf4j
@RequestMapping(value = "/tabular/transaction")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class TabularTransactionController {

  private final TabularTransactionService tabularTransactionService;

  @Autowired
  public TabularTransactionController(TabularTransactionService tabularTransactionService) {
    this.tabularTransactionService = tabularTransactionService;
  }

  @PostMapping
  @Operation(summary = "Get tabular transaction data")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = String.class))
            })
      })
  public Mono<String> getTabularTransactionDataPost(
      @Parameter(
              description =
                  "Transaction requests include fields, accounts, as well as a begin and end date")
          @RequestBody
          LpxTransactionRequest lpxTransactionRequest,
      @RequestParam(value = "offset", required = false) boolean offset) {
    return fetchTabularTransactionData(
        lpxTransactionRequest.getFieldIds(),
        lpxTransactionRequest.getAccountIds(),
        lpxTransactionRequest.getBeginDate(),
        lpxTransactionRequest.getEndDate(),
        lpxTransactionRequest.isQueryWithEntryDate(),
        lpxTransactionRequest.isQueryWithValidationDate(),
        offset);
  }

  private Mono<String> fetchTabularTransactionData(
      Set<Integer> fieldIds,
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      boolean queryByEntryDate,
      boolean queryByValidationDate,
      boolean offset) {
    return tabularTransactionService
        .getTabularTransactionDataReactive(
            fieldIds,
            accountIds,
            beginDate,
            endDate,
            queryByEntryDate,
            queryByValidationDate,
            offset)
        .publishOn(Schedulers.boundedElastic())
        .handle(
            (supplier, sink) -> {
              try {
                StreamingOutput jsonStreamOutput =
                    new JsonTabularDataStreamingOutput<>(
                        "transactionData", JsonUtils2.getJsonFactory(), supplier);
                var output = new ByteArrayOutputStream();
                jsonStreamOutput.write(output);
                sink.next(output.toString(StandardCharsets.UTF_8));
              } catch (Exception e) {
                log.error("Error occurred for getTabularTransactionDataReactive", e);
                sink.error(new RuntimeException(e));
              }
            });
  }

  @RequestMapping(value = "/knowledge-date", method = RequestMethod.GET)
  @Operation(
      summary =
          "Get transactions created between supplied knowledge start dates converted into Accelex columns")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getTransactionInfoByKnowledgeDateBetween(
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam(value = "isInitialLoad", defaultValue = "false") boolean initialLoad)
      throws IOException, ExecutionException, InterruptedException {
    var dataSet =
        tabularTransactionService.getAccelexMappedTransactionData(
            beginDate, endDate, LocalDateTime.now(), null, initialLoad);
    var fileName =
        "cashflow_metrics_"
            + beginDate.format(DateTimeFormatter.ISO_DATE)
            + "_"
            + endDate.format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSV(dataSet).getBytes());
  }

  @RequestMapping(value = "/knowledge-date/accounts", method = RequestMethod.GET)
  @Operation(
      summary =
          "Get transactions created between supplied knowledge start dates converted into Accelex columns")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getTransactionInfoByKnowledgeDateBetween(
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam(value = "initialLoad", defaultValue = "false") boolean initialLoad,
      @RequestParam("accountIds") String accountCSV)
      throws IOException, ExecutionException, InterruptedException {
    Set<Long> accountIds =
        new HashSet<>(Arrays.asList(accountCSV.split(",")))
            .stream().map(Long::parseLong).collect(Collectors.toSet());
    var dataSet =
        tabularTransactionService.getAccelexMappedTransactionData(
            beginDate, endDate, LocalDateTime.now(), accountIds, initialLoad);
    var fileName =
        "cashflow_metrics_"
            + beginDate.format(DateTimeFormatter.ISO_DATE)
            + "_"
            + endDate.format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSV(dataSet).getBytes());
  }

  @RequestMapping(value = "/knowledge-date-baseline", method = RequestMethod.GET)
  @Operation(
      summary =
          "Get baseline transactional pabor data created between supplied knowledge start dates")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getBaselineTransactionInfoByKnowledgeDateBetween(
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate)
      throws IOException, ExecutionException, InterruptedException {
    var dataSet =
        tabularTransactionService.getAllPrismTransactionsBetweenDates(
            beginDate, endDate, LocalDateTime.now(), null);
    var fileName =
        "transactions"
            + beginDate.format(DateTimeFormatter.ISO_DATE)
            + "_"
            + endDate.format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSVWithoutQuotes(dataSet).getBytes());
  }

  @RequestMapping(value = "/knowledge-date-baseline-by-account", method = RequestMethod.GET)
  @Operation(
      summary =
          "Get baseline transactional pabor data created between supplied knowledge start dates")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getBaselineTransactionInfoByKnowledgeDateBetween(
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam("accountIds") String accountCSV)
      throws IOException, ExecutionException, InterruptedException {
    Set<Long> accountIds =
        new HashSet<>(Arrays.asList(accountCSV.split(",")))
            .stream().map(Long::parseLong).collect(Collectors.toSet());
    var dataSet =
        tabularTransactionService.getAllPrismTransactionsBetweenDates(
            beginDate, endDate, LocalDateTime.now(), accountIds);
    var fileName =
        "transactions_account_"
            + beginDate.format(DateTimeFormatter.ISO_DATE)
            + "_"
            + endDate.format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSVWithoutQuotes(dataSet).getBytes());
  }
}
