package com.cwan.privatefund.config;

import com.ca.secrets.NoSecretFoundException;
import com.ca.secrets.impl.SystemPropertiesKeeper;
import com.ca.status.StatusRegistry;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.clearwateranalytics.secrets.awssecretmanager.SecretManagerSecretKeeper;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.lpx.domain.Transaction;
import com.cwan.lpx.domain.TransferRequest;
import com.cwan.pbor.balance.api.Balances;
import com.cwan.pbor.clientspecific.FundService;
import com.cwan.pbor.document.DocumentService;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.fxrate.FXRateService;
import com.cwan.pbor.trans.TransactionService;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.pbor.trans.openingtransactions.LoadTransactionDetailService;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.accountconfig.AccountConfigServiceClient;
import com.cwan.privatefund.auth.LPxAuthTokenCore;
import com.cwan.privatefund.auth.SecurityContextService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.auth.ws.AuthWSClient;
import com.cwan.privatefund.auth.ws.AuthWSService;
import com.cwan.privatefund.balance.LpxBalanceEntityService;
import com.cwan.privatefund.balance.LpxBalanceService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.document.CwanGptDocumentRequest;
import com.cwan.privatefund.document.DocumentAuditService;
import com.cwan.privatefund.document.LpxDocumentService;
import com.cwan.privatefund.document.LpxDocumentServiceClient;
import com.cwan.privatefund.document.signed.url.SignedUrlAuditRepository;
import com.cwan.privatefund.document.signed.url.SignedUrlAuditService;
import com.cwan.privatefund.documentcashflow.DocumentCashflowHydrationService;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.fxrate.AverageFxRateCalculator;
import com.cwan.privatefund.fxrate.FxServiceApacheClient;
import com.cwan.privatefund.fxrate.LpxFxRateService;
import com.cwan.privatefund.fxrate.source.AccountFxSourceService;
import com.cwan.privatefund.hydrate.TransactionDataHydrationService;
import com.cwan.privatefund.issuestore.IssueStoreClient;
import com.cwan.privatefund.portfolio.model.CalculationTask;
import com.cwan.privatefund.publisher.MessagePublisher;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.security.currency.SecurityCurrencyService;
import com.cwan.privatefund.serializer.NormalizedStringDeserializer;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.cwan.privatefund.watchlist.WatchlistService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.netty.handler.ssl.SslContextBuilder;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.impl.client.HttpClients;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.client.RestTemplate;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import reactor.netty.tcp.SslProvider;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.sns.AmazonSNSExtendedClient;
import software.amazon.sns.SNSExtendedClientConfiguration;

@Configuration
@Slf4j
public class LPxServiceConfig {

  @Bean
  ObjectMapper objectMapper() {
    return new ObjectMapper()
        .registerModule(new JavaTimeModule())
        .registerModule(
            new SimpleModule().addDeserializer(String.class, new NormalizedStringDeserializer()))
        .registerModule(new Jdk8Module()) // for serializing/deserializing optionals
        .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
  }

  @Bean
  ReactorClientHttpConnector reactorClientHttpConnector() {
    ConnectionProvider connectionProvider =
        ConnectionProvider.builder("lpx-common-connection-pool")
            .maxConnections(800)
            .maxIdleTime(Duration.ofSeconds(20))
            .maxLifeTime(Duration.ofSeconds(60))
            .pendingAcquireTimeout(Duration.ofSeconds(60))
            .evictInBackground(Duration.ofSeconds(120))
            .build();
    return new ReactorClientHttpConnector(
        HttpClient.create(connectionProvider)
            .secure(
                spec ->
                    spec.sslContext(SslContextBuilder.forClient())
                        .defaultConfiguration(SslProvider.DefaultConfigurationType.TCP)
                        .handshakeTimeout(Duration.ofSeconds(30))
                        .closeNotifyFlushTimeout(Duration.ofSeconds(20))
                        .closeNotifyReadTimeout(Duration.ofSeconds(20))));
  }

  @Bean
  LpxTransactionService lpxTransactionService(
      Transactions transactions,
      AccountConfigServiceCache accountConfigServiceCache,
      DocumentService documentService,
      AccountService accountService,
      TransactionDataHydrationService hydrationService,
      SecurityService securityService,
      LoadTransactionDetailService loadTransactionDetailService,
      FundService fundService,
      AccountConfigServiceClient accountConfigServiceClient,
      WatchlistService watchlistService) {
    return new LpxTransactionService(
        transactions,
        accountConfigServiceCache,
        documentService,
        accountService,
        hydrationService,
        securityService,
        loadTransactionDetailService,
        fundService,
        accountConfigServiceClient,
        watchlistService);
  }

  @Bean
  LpxDocumentService lpxDocumentService(
      AccountService accountService,
      Documents documents,
      SecurityService securityService,
      LpxDocumentServiceClient lpxDocumentServiceClient,
      LpxTransactionService lpxTransactionService,
      LpxBalanceEntityService lpxBalanceEntityService,
      IssueStoreClient issueStoreClient,
      BusinessWSClient businessWSClient,
      DocumentAuditService documentAuditService,
      SignedUrlAuditService signedUrlAuditService,
      SecurityContextUserService securityContextUserService) {
    return new LpxDocumentService(
        accountService,
        documents,
        securityService,
        lpxDocumentServiceClient,
        HttpClients.createDefault(),
        lpxTransactionService,
        lpxBalanceEntityService,
        issueStoreClient,
        businessWSClient,
        documentAuditService,
        signedUrlAuditService,
        securityContextUserService);
  }

  @Bean
  SignedUrlAuditService signedUrlAuditService(
      SignedUrlAuditRepository signedUrlAuditRepository,
      BusinessWSCache businessWebCache,
      SecurityContextService securityContextService) {
    return new SignedUrlAuditService(
        signedUrlAuditRepository, businessWebCache, securityContextService);
  }

  @Bean
  LpxBalanceService lpxBalanceService(
      LpxBalanceEntityService lpxBalanceEntityService,
      MessagePublisher<Balance> balanceMessagePublisher,
      AccountService accountService) {
    return new LpxBalanceService(lpxBalanceEntityService, balanceMessagePublisher, accountService);
  }

  @Bean
  LpxBalanceEntityService lpxBalanceEntityService(
      AccountService accountService,
      Balances balances,
      SecurityService securityService,
      Documents documents) {
    return new LpxBalanceEntityService(accountService, balances, securityService, documents);
  }

  @Bean
  LpxFxRateService lpxFxRateService(
      FXRateService fxRateService,
      LpxFundMasterService lpxFundMasterService,
      SecurityCurrencyService securityCurrencyService,
      TransactionService transactionService,
      BusinessWSCache businessWSCache,
      AverageFxRateCalculator averageFxRateCalculator,
      FxServiceApacheClient fxServiceApacheClient,
      AccountFxSourceService accountFxSourceService) {
    return new LpxFxRateService(
        fxRateService,
        lpxFundMasterService,
        securityCurrencyService,
        transactionService,
        businessWSCache,
        averageFxRateCalculator,
        fxServiceApacheClient,
        accountFxSourceService);
  }

  @Bean
  StatusRegistry statusRegistry() {
    return StatusRegistry.create();
  }

  @Bean
  AwsCredentialsProvider awsCredentialsProvider() {
    return DefaultCredentialsProvider.create();
  }

  @Bean
  SnsClient snsClient(AwsCredentialsProvider awsCredentialsProvider) {
    return SnsClient.builder()
        .region(getAWSRegion())
        .credentialsProvider(awsCredentialsProvider)
        .build();
  }

  @Bean
  S3Client s3Client(AwsCredentialsProvider awsCredentialsProvider) {
    return S3Client.builder()
        .region(getAWSRegion())
        .credentialsProvider(awsCredentialsProvider)
        .build();
  }

  @Bean
  AmazonSNSExtendedClient amazonSNSExtendedClient(
      SnsClient snsClient,
      S3Client s3Client,
      @Value("${s3.transaction.bucket.name}") String bucketName) {
    SNSExtendedClientConfiguration snsExtendedClientConfiguration =
        new SNSExtendedClientConfiguration().withPayloadSupportEnabled(s3Client, bucketName);
    return new AmazonSNSExtendedClient(snsClient, snsExtendedClientConfiguration);
  }

  @Bean
  SecretsManagerClient secretsManagerClient(AwsCredentialsProvider awsCredentialsProvider) {
    return SecretsManagerClient.builder()
        .region(getAWSRegion())
        .credentialsProvider(awsCredentialsProvider)
        .build();
  }

  @Bean("transactionMessagePublisher")
  MessagePublisher<Transaction> transactionMessagePublisher(
      @Value("${transaction.publish.topic.arn}") String transactionTopic,
      AmazonSNSExtendedClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    return new MessagePublisher<>(
        transactionTopic, snsClient, objectMapper, transactionDataHydrationService);
  }

  @Bean("balanceMessagePublisher")
  MessagePublisher<Balance> balanceMessagePublisher(
      @Value("${balance.publish.topic.arn}") String balanceTopic,
      SnsClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    return new MessagePublisher<>(
        balanceTopic, snsClient, objectMapper, transactionDataHydrationService);
  }

  @Bean("transferMessagePublisher")
  MessagePublisher<TransferRequest> transferMessagePublisher(
      @Value("${transfer.publish.topic.arn}") String transferTopic,
      SnsClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    return new MessagePublisher<>(
        transferTopic, snsClient, objectMapper, transactionDataHydrationService);
  }

  @Bean("cwanGptDocumentPublisher")
  MessagePublisher<CwanGptDocumentRequest> cwanGptDocumentPublisher(
      @Value("${cwan-gpt-document-upload.publish.topic.arn}") String clearwaterGptDocumentTopic,
      SnsClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    return new MessagePublisher<>(
        clearwaterGptDocumentTopic, snsClient, objectMapper, transactionDataHydrationService);
  }

  @Bean
  AuthWSService authWSService(AuthWSClient authWSClient) {
    return new AuthWSService(authWSClient);
  }

  @Bean
  LPxAuthTokenCore authTokenCore(@Value("${spring.application.name}") String appName) {
    return new LPxAuthTokenCore(
        Optional.ofNullable(System.getenv("JWT_SECRET_ACCOUNT"))
            .map(secret -> new SecretManagerSecretKeeper().get("app/common/jwt_secret"))
            .orElseGet(
                () -> {
                  try {
                    return new SystemPropertiesKeeper().get("app/common/jwt_secret");
                  } catch (NoSecretFoundException e) {
                    log.warn(
                        "No secret found in SystemPropertiesKeeper, using default value. Error: {}",
                        e.getMessage());
                    return "secret";
                  }
                }),
        appName);
  }

  @Bean("performanceMessagePublisher")
  MessagePublisher<CalculationTask> performanceMessagePublisher(
      @Value("${performance.publish.topic.arn}") String performanceTopic,
      SnsClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    return new MessagePublisher<>(
        performanceTopic, snsClient, objectMapper, transactionDataHydrationService);
  }

  @Bean("documentCashflowMessagePublisher")
  MessagePublisher<DocumentCashFlow> documentCashFlowMessagePublisher(
      @Value("${document-cashflow.publish.topic.arn}") String documentCashflowTopic,
      SnsClient snsClient,
      ObjectMapper objectMapper,
      TransactionDataHydrationService transactionDataHydrationService) {
    return new MessagePublisher<>(
        documentCashflowTopic, snsClient, objectMapper, transactionDataHydrationService);
  }

  @Bean
  DocumentCashflowHydrationService documentCashflowHydrationService(
      AccountService accountService,
      DocumentService documentService,
      SecurityService securityService) {
    return new DocumentCashflowHydrationService(accountService, documentService, securityService);
  }

  private Region getAWSRegion() {
    String systemAWSRegion = System.getenv("REGION");
    return Region.of(systemAWSRegion == null ? "us-west-2" : systemAWSRegion);
  }

  @Bean
  public ExecutorService executorService() {
    return Executors.newSingleThreadExecutor();
  }

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  @Bean
  WsHttpClient wsHttpClient() {
    return WsHttpClientBuilder.getSharedDefault();
  }

  @Bean
  public Tika apacheTika() {
    return new Tika();
  }
}
