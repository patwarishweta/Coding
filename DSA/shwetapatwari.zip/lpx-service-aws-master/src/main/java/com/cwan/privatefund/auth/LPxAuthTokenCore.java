package com.cwan.privatefund.auth;

import com.ca.authtoken.core.AuthTokenCore;

public class LPxAuthTokenCore extends AuthTokenCore {

  public LPxAuthTokenCore(String secret, String appName) {
    super(() -> secret, appName, null);
  }
}
