package com.cwan.privatefund.config.properties;

import jakarta.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Objects;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;

@Data
@Slf4j
@ConfigurationProperties(prefix = "salesforce")
public class SalesforceConfigProperties {

  private final SecretsManagerClient secretsManagerClient;
  private String clientId;
  private String clientSecret;
  private static final String SALESFORCE_CLIENT_ID = "salesforce_client_id";
  private static final String SALESFORCE_CLIENT_SECRET = "salesforce_client_secret";

  @Autowired
  public SalesforceConfigProperties(SecretsManagerClient secretsManagerClient) {
    this.secretsManagerClient = secretsManagerClient;
  }

  @PostConstruct
  public void extractSecretsFromManager() {
    if (Objects.isNull(clientId)) {
      clientId = getSecretAsString(SALESFORCE_CLIENT_ID);
    }
    if (Objects.isNull(clientSecret)) {
      clientSecret = getSecretAsString(SALESFORCE_CLIENT_SECRET);
    }
  }

  public String getSecretAsString(String secretName) {
    try {
      var encodedSecretValue =
          secretsManagerClient
              .getSecretValue(GetSecretValueRequest.builder().secretId(secretName).build())
              .secretString();
      if (Objects.nonNull(encodedSecretValue)) {
        var decodedSecretValue =
            new String(Base64.getDecoder().decode(encodedSecretValue), StandardCharsets.UTF_8);
        log.info("Successfully fetched secret for {}", secretName);
        return decodedSecretValue;
      }
      throw new RuntimeException("The fetched secret for " + secretName + " is null");
    } catch (Exception e) {
      log.error("Error in getting secret value for {}", secretName, e);
      throw new RuntimeException("Error in getting secret value for " + secretName, e);
    }
  }
}
