package com.cwan.privatefund.transaction;

import com.cwan.lpx.domain.Transaction;
import com.cwan.lpx.domain.TransactionType;
import com.cwan.pbor.trans.Constants.TransactionBasisAffects;
import com.cwan.privatefund.transaction.model.AwsTransaction;
import com.cwan.privatefund.transaction.model.BalanceField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import reactor.core.publisher.Flux;

@Slf4j
public class LpxAwsTransactionUtil {
  // These types are not stored as transactions in perseus, so MUST go to the accounting etl
  // through LMC. Any new transaction type with nav affect which is not stored in perseus should
  // be included here
  private static final Set<String> AWS_NAV_INCLUDED_TYPES =
      Set.of("NAV", "COMMITMENT_ADJUSTMENT", "GENERAL_ADJUSTMENT");
  private static final int AMORT_ACTIVITY_TYPE_ID = -4;

  private LpxAwsTransactionUtil() {}

  static Flux<AwsTransaction> getTransactionAffect(
      Transaction transaction,
      Flux<TransactionType> transactionTypeFlux) { // ignored unfunded affect
    return Flux.fromIterable(getAffectsForTransactionSubType(transaction).entrySet())
        .filter(affect -> (affect.getValue() != null) && (affect.getValue() != 0.0))
        .flatMap(affect -> getAwsTransaction(transaction, affect, transactionTypeFlux));
  }

  private static Flux<AwsTransaction> getAwsTransaction(
      Transaction transaction,
      Map.Entry<String, Double> affect,
      Flux<TransactionType> transactionTypes) {
    return transactionTypes
        .filter(transactionType -> transaction.getType().equals(transactionType.getCode()))
        .map(
            transactionType -> {
              if ("navAffect".equals(affect.getKey())) {
                return transactionType.getAccountingNavChangeTypeId();
              } else if ("amortAffect".equals(affect.getKey())) {
                return AMORT_ACTIVITY_TYPE_ID;
              }
              return transactionType.getAccountingCommitmentChangeTypeId();
            })
        .filter(Objects::nonNull)
        .flatMap(
            typeId ->
                generateAwsActivities(transaction, typeId, affect.getKey(), affect.getValue()));
  }

  private static Flux<AwsTransaction> generateAwsActivities(
      Transaction transaction, Integer typeId, String affectType, Double transactionAffect) {
    val balanceField = getTxnBalanceLinkage().get(affectType);
    List<AwsTransaction> results = new ArrayList<>();
    if (balanceField.getGaapFieldId() != -1
        && (transaction.getBasisAffect().equals(TransactionBasisAffects.GAAP)
            || transaction.getBasisAffect().equals(TransactionBasisAffects.ALL))) {
      results.add(
          getAwsTransaction(typeId, balanceField.getGaapFieldId(), transactionAffect, transaction));
    }
    if (balanceField.getTaxFieldId() != -1
        && transaction.getBasisAffect().equals(TransactionBasisAffects.ALL)) {
      results.add(
          getAwsTransaction(typeId, balanceField.getTaxFieldId(), transactionAffect, transaction));
    }
    if (balanceField.getStatFieldId() != -1
        && (transaction.getBasisAffect().equals(TransactionBasisAffects.STAT)
            || transaction.getBasisAffect().equals(TransactionBasisAffects.ALL))) {
      results.add(
          getAwsTransaction(typeId, balanceField.getStatFieldId(), transactionAffect, transaction));
    }
    return Flux.fromIterable(results);
  }

  private static AwsTransaction getAwsTransaction(
      Integer typeId, Integer fieldId, Double transactionAffect, Transaction transaction) {
    return AwsTransaction.builder()
        .awsActivityTypeId(typeId)
        .awsBalanceFieldId(fieldId)
        .amount(transactionAffect)
        .securityId(transaction.getSecurity().getSecurityId())
        .date(transaction.getSettleDate())
        .source("LMC")
        .originalTransactionType(transaction.getType())
        .build();
  }

  private static Map<String, BalanceField> getTxnBalanceLinkage() {
    return Map.of(
        "amortAffect",
        BalanceField.CHANGE_IN_UNREALIZED_GAIN_LOSS,
        "navAffect",
        BalanceField.CHANGE_IN_UNREALIZED_GAIN_LOSS,
        "fundedCommitmentAffect",
        BalanceField.FUNDED_COMMITMENT,
        "recallableCommitmentAffect",
        BalanceField.RECALLABLE_DISTRIBUTION,
        "totalCommitmentAffect",
        BalanceField.TOTAL_COMMITMENT);
  }

  private static Map<String, Double> getAffectsForTransactionSubType(Transaction transaction) {
    Map<String, Double> map = new HashMap<>();
    if ("NAV".equals(transaction.getType()) && "AMORT".equals(transaction.getSubType())) {
      map.put("amortAffect", transaction.getNavImpact());
    } else if (AWS_NAV_INCLUDED_TYPES.contains(transaction.getType())) {
      map.put("navAffect", transaction.getNavImpact());
    }
    map.put("recallableCommitmentAffect", transaction.getRecallableImpact());
    map.put("totalCommitmentAffect", transaction.getTotalCommitmentImpact());
    map.put("fundedCommitmentAffect", transaction.getFundedCommitmentImpact());
    return map;
  }
}
