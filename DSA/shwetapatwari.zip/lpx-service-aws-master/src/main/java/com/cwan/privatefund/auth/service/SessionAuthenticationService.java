package com.cwan.privatefund.auth.service;

import static com.cwan.privatefund.util.AuthenticationUtils.getAuthenticationToken;

import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.cwan.privatefund.auth.ws.AuthWSCache;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class SessionAuthenticationService implements AuthenticationService {

  private final AuthWSCache authWSCache;
  private final String applicationName;
  private final AuthorityService authorityService;

  private static final String USER_ID = "USER_ID";
  private static final String SESSION_ID = "SESSION_ID";
  private static final String PRIVATE_LABEL_ID = "PRIVATE_LABEL_ID";

  public SessionAuthenticationService(
      AuthWSCache authWSCache,
      @Value("${session.application.name}") String applicationName,
      AuthorityService authorityService) {
    this.authWSCache = authWSCache;
    this.applicationName = applicationName;
    this.authorityService = authorityService;
  }

  @Override
  public Mono<Authentication> getAuthentication(ServerWebExchange swe) {
    var cookieMap = swe.getRequest().getCookies();
    var userCookie = cookieMap.getFirst(USER_ID);
    var privateLabelCookie = cookieMap.getFirst(PRIVATE_LABEL_ID);
    var sessionCookie = cookieMap.getFirst(SESSION_ID);
    if ((userCookie == null) || (privateLabelCookie == null) || (sessionCookie == null)) {
      return Mono.empty();
    }
    var userId = userCookie.getValue();
    var privateLabelId = privateLabelCookie.getValue();
    var sessionId = sessionCookie.getValue();
    return authWSCache
        .isSessionValid(new SessionValidRequest(userId, privateLabelId, sessionId, applicationName))
        .map(
            valid ->
                getAuthenticationToken(
                    userId,
                    Set.of(privateLabelId, sessionId),
                    valid,
                    authorityService.getAuthorities(swe)));
  }
}
