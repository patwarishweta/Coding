package com.cwan.privatefund.documentmanager.enums;

import lombok.Getter;

@Getter
public enum MiscDocumentStatus {
  ACTIVE("Active");

  private final String value;

  MiscDocumentStatus(String value) {
    this.value = value;
  }
}
