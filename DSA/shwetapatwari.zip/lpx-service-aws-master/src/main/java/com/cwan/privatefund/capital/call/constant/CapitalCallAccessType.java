package com.cwan.privatefund.capital.call.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/** Enum to represent the types of access a user can have on a capital call. */
@Getter
@AllArgsConstructor
public enum CapitalCallAccessType {
  /** Represents read-only access to a capital call. */
  READ("Read Access"),
  /** Represents the ability to take action on a capital call. */
  WRITE("Write Access");
  private final String description;
}
