package com.cwan.privatefund.document;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.PostRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.cwan.lpx.domain.Document;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.InputStream;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LpxDocumentServiceApacheClient {

  private final WsHttpClient wsHttpClient;
  private final Resource documentResource;

  public LpxDocumentServiceApacheClient(
      WsHttpClient wsHttpClient, ServerConfiguration serverConfiguration) {
    this.wsHttpClient = wsHttpClient;
    this.documentResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("v1/document")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public Document saveDocument(Document document, String source) {
    log.info(
        "LpxDocumentServiceApacheClient saveDocument document: {}, source: {}", document, source);
    PostRequest request =
        documentResource
            .doPOST(wsHttpClient)
            .addQueryParam("source", source == null ? "LMC" : source)
            .setRequestEntity(JsonUtils2.objToJson(document), MimeType.JSON)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      List<Document> documents = JsonUtils2.parseJson(is, new TypeReference<>() {});
      return documents.get(0);
    } catch (Exception e) {
      log.error("Failed to save document: {} with error", document, e);
      return null;
    }
  }
}
