package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.pbor.document.capital.call.management.api.CapitalCallManagement;
import com.cwan.privatefund.util.StringOperationUtils;
import java.time.Duration;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/** Service to manage the checks for new bank accounts in capital calls. */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallBankAccountVerifierService {

  private final CapitalCallManagement capitalCallManagement;

  /**
   * Checks if the bank account in the provided CapitalCallDocument is new.
   *
   * @param document the CapitalCallDocument to check.
   * @return A Mono<Boolean> indicating if the bank account is new.
   */
  public Mono<Boolean> isNewBankAccount(CapitalCallDocument document) {
    log.debug("Checking if bank account is new for documentId: {}", document.documentId());
    return Mono.fromCallable(
            () -> {
              log.debug(
                  "Fetching all bank accounts from the management system for documentId: {}",
                  document.documentId());
              return capitalCallManagement.findAllBankAccounts();
            })
        .subscribeOn(Schedulers.boundedElastic())
        .cache(Duration.ofMinutes(5))
        .doOnSuccess(
            bankAccounts ->
                log.debug(
                    "Fetched and cached bank accounts for documentId: {}", document.documentId()))
        .flatMap(
            bankAccounts -> {
              log.debug(
                  "Checking bank account against existing accounts for documentId: {}",
                  document.documentId());
              return checkBankAccount(document, bankAccounts)
                  .doOnNext(
                      isNew ->
                          log.debug(
                              "Bank account check for documentId: {}: isNew = {}",
                              document.documentId(),
                              isNew));
            })
        .doOnError(
            e ->
                log.error(
                    "Error checking if bank account is new for documentId: {}",
                    document.documentId(),
                    e));
  }

  /**
   * Verifies and updates the newAccount flag for a batch of CapitalCallDocuments.
   *
   * @param batch The list of documents to process.
   * @return A Flux emitting documents with the newAccount flag set after verification against
   *     cached bank accounts.
   */
  public Flux<CapitalCallDocument> verifyAndSetBufferedNewBankAccountFlag(
      List<CapitalCallDocument> batch) {
    log.debug("Starting verification of new bank accounts for batch of size {}", batch.size());
    return Mono.fromCallable(
            () -> {
              log.debug("Fetching all bank accounts from management system for batch verification");
              return capitalCallManagement.findAllBankAccounts();
            })
        .subscribeOn(Schedulers.boundedElastic())
        .cache(Duration.ofMinutes(5))
        .doOnSuccess(
            bankAccounts -> log.debug("Fetched and cached bank accounts for batch verification"))
        .flatMapMany(
            bankAccounts ->
                Flux.fromIterable(batch)
                    .flatMap(
                        document -> {
                          log.debug(
                              "Verifying bank account for documentId: {}", document.documentId());
                          return checkBankAccount(document, bankAccounts)
                              .map(
                                  isNewBankAccount -> {
                                    log.debug(
                                        "Setting new bank account flag for documentId: {} to {}",
                                        document.documentId(),
                                        isNewBankAccount);
                                    var bankDetail = document.bankDetail();
                                    bankDetail =
                                        Objects.nonNull(bankDetail)
                                            ? bankDetail.toBuilder()
                                                .newAccount(isNewBankAccount)
                                                .build()
                                            : CapitalCallBankDetail.builder()
                                                .newAccount(isNewBankAccount)
                                                .build();
                                    return document.toBuilder().bankDetail(bankDetail).build();
                                  });
                        }))
        .doOnError(
            e -> log.error("Error in verifying and setting new bank account flag for batch", e));
  }

  public Mono<Boolean> checkBankAccount(
      CapitalCallDocument document, List<BankAccount> bankAccounts) {
    if (Objects.isNull(document.bankDetail())) {
      log.warn("Bank Detail is null for document ID: {}", document.documentId());
      return Mono.just(true);
    }
    if (Objects.isNull(document.account())) {
      log.warn("Account is null for document ID: {}", document.documentId());
      return Mono.just(true);
    }
    var abaRoutingNumber =
        normalizeAndTrim(document.bankDetail(), CapitalCallBankDetail::abaRoutingNumber);
    var swiftChipsCode =
        normalizeAndTrim(document.bankDetail(), CapitalCallBankDetail::swiftOrChips);
    var accountNumber =
        normalizeAndTrim(document.bankDetail(), CapitalCallBankDetail::accountNumber);
    var iban = normalizeAndTrim(document.bankDetail(), CapitalCallBankDetail::accountIban);
    if (isValidInput(document, abaRoutingNumber, swiftChipsCode, accountNumber, iban)) {
      log.debug(
          "Checking beneficiary bank account details for accountNumber: '{}' and iban: '{}'",
          accountNumber,
          iban);
      return checkIfBankAccountIsNew(
          abaRoutingNumber,
          swiftChipsCode,
          accountNumber,
          iban,
          bankAccounts.stream()
              .filter(
                  bankAccount ->
                      Objects.equals(bankAccount.accountId(), document.account().getId()))
              .collect(Collectors.toList()));
    }
    return Mono.just(true);
  }

  private String normalizeAndTrim(
      CapitalCallBankDetail bankDetail, Function<CapitalCallBankDetail, String> extractor) {
    return Optional.ofNullable(bankDetail)
        .map(extractor)
        .map(StringOperationUtils::normalizeAndTrimToNull)
        .orElse(null);
  }

  private boolean isValidInput(
      CapitalCallDocument document,
      String abaRoutingNumber,
      String swiftChipsCode,
      String accountNumber,
      String iban) {
    var areRoutingNumbersAbsent =
        Objects.isNull(abaRoutingNumber) && Objects.isNull(swiftChipsCode);
    var areAccountIdentifiersAbsent = Objects.isNull(accountNumber) && Objects.isNull(iban);
    if (areRoutingNumbersAbsent || areAccountIdentifiersAbsent) {
      log.warn(
          "Invalid input for document ID: {}. " + "Issues: {}{}",
          document.documentId(),
          (areRoutingNumbersAbsent
              ? "Both ABA Routing Number and SWIFT/CHIPS Code are null. "
              : ""),
          (areAccountIdentifiersAbsent ? "Both Account Number and IBAN are null. " : ""));
      return false;
    }
    return true;
  }

  private Mono<Boolean> checkIfBankAccountIsNew(
      String abaRoutingNumber,
      String swiftChipsCode,
      String accountNumber,
      String iban,
      List<BankAccount> bankAccounts) {
    for (BankAccount bankAccount : bankAccounts) {
      if ((StringUtils.equalsIgnoreCase(bankAccount.bank().abaRoutingNumber(), abaRoutingNumber)
              || StringUtils.equalsIgnoreCase(bankAccount.bank().swiftChipsCode(), swiftChipsCode))
          && (StringUtils.equalsIgnoreCase(bankAccount.accountNumber(), accountNumber)
              || StringUtils.equalsIgnoreCase(bankAccount.iban(), iban))) {
        return Mono.just(false);
      }
    }
    return Mono.just(true);
  }
}
