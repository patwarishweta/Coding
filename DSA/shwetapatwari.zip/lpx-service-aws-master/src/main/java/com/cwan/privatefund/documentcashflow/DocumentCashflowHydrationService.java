package com.cwan.privatefund.documentcashflow;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class DocumentCashflowHydrationService {

  private final AccountService accountService;
  private final Documents documents;
  private final SecurityService securityService;

  public DocumentCashflowHydrationService(
      AccountService accountService, Documents documents, SecurityService securityService) {
    this.accountService = accountService;
    this.documents = documents;
    this.securityService = securityService;
  }

  public Mono<List<DocumentCashFlow>> hydrate(
      List<DocumentCashFlow> documentCashFlows, Long documentId) {
    return Mono.just(documentCashFlows)
        .flatMap(documentCashFlowList -> hydrateDocumentData(documentCashFlowList, documentId))
        .flatMap(this::hydrateAccountData)
        .flatMap(this::hydrateSecurityData);
  }

  private Mono<List<DocumentCashFlow>> hydrateAccountData(
      Collection<DocumentCashFlow> documentCashFlows) {
    var accountIds =
        documentCashFlows.stream()
            .map(documentCashFlow -> documentCashFlow.getDocument().getAccount().getId())
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
    return accountService
        .getAccountsData(accountIds)
        .map(
            accounts -> {
              var accountsMap =
                  accounts.stream().collect(Collectors.toMap(Account::getId, Function.identity()));
              return documentCashFlows.stream()
                  .map(
                      documentCashFlow -> {
                        var accountId = documentCashFlow.getDocument().getAccount().getId();
                        if (!accountsMap.containsKey(accountId)) {
                          return documentCashFlow;
                        }
                        Document document =
                            documentCashFlow.getDocument().toBuilder()
                                .account(accountsMap.get(accountId))
                                .build();
                        documentCashFlow.setDocument(document);
                        return documentCashFlow;
                      })
                  .toList();
            });
  }

  private Mono<List<DocumentCashFlow>> hydrateDocumentData(
      Collection<DocumentCashFlow> documentCashFlows, Long documentId) {
    return documents
        .getDocumentById(documentId)
        .flatMap(
            document ->
                Flux.fromIterable(documentCashFlows)
                    .map(
                        documentCashFlow -> documentCashFlow.toBuilder().document(document).build())
                    .collectList());
  }

  private Mono<List<DocumentCashFlow>> hydrateSecurityData(
      Collection<DocumentCashFlow> documentCashFlows) {
    return Flux.fromIterable(documentCashFlows)
        .flatMap(
            documentCashFlow ->
                securityService
                    .getSecurity(
                        documentCashFlow.getDocument().getAccount().getClientId(),
                        documentCashFlow.getDocument().getAccount().getId(),
                        documentCashFlow.getDocument().getSecurity().getSecurityId())
                    .map(
                        security -> {
                          Document document =
                              documentCashFlow.getDocument().toBuilder().security(security).build();
                          documentCashFlow.setDocument(document);
                          return documentCashFlow;
                        }))
        .collectList();
  }
}
