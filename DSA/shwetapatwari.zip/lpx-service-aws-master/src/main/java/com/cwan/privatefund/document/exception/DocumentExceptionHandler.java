package com.cwan.privatefund.document.exception;

import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@RestControllerAdvice(basePackages = "com.cwan.privatefund.document")
@Slf4j
public class DocumentExceptionHandler {

  @ExceptionHandler(ResponseStatusException.class)
  public Mono<ResponseEntity<ValidationErrorResponse>> handleResponseStatusException(
      ResponseStatusException ex) {
    log.error("Response status exception: {}", ex.getMessage());
    ValidationErrorResponse response =
        ValidationErrorResponse.of(
            ex.getStatusCode().value(),
            Optional.ofNullable(ex.getReason()).orElse("Unknown error"),
            null);
    return Mono.just(ResponseEntity.status(ex.getStatusCode()).body(response));
  }

  @ExceptionHandler(Exception.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public Mono<ValidationErrorResponse> handleUnexpectedError(Exception ex) {
    log.error("Unexpected error occurred", ex);
    return Mono.just(
        ValidationErrorResponse.of(
            HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected error occurred", null));
  }

  @ExceptionHandler(WebExchangeBindException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public Mono<ValidationErrorResponse> handleValidationErrors(WebExchangeBindException ex) {
    Map<String, String> errors =
        ex.getBindingResult().getAllErrors().stream()
            .collect(
                Collectors.toMap(
                    error -> {
                      if (error instanceof FieldError fieldError) {
                        return fieldError.getField();
                      }
                      return StringUtils.defaultIfEmpty(error.getObjectName(), "global");
                    },
                    error -> Optional.ofNullable(error.getDefaultMessage()).orElse("Unknown error"),
                    (existing, replacement) -> StringUtils.join(existing, "; ", replacement)));
    log.warn("Validation failed: {}", errors);
    return Mono.just(
        ValidationErrorResponse.of(HttpStatus.BAD_REQUEST.value(), "Validation failed", errors));
  }
}
