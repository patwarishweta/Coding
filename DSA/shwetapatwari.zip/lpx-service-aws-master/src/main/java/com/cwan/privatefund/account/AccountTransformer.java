package com.cwan.privatefund.account;

import com.cwan.lpx.domain.Account;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class AccountTransformer implements Function<BusinessAccount, Account> {

  @Override
  public Account apply(BusinessAccount businessAccount) {
    return Account.builder()
        .id(businessAccount.getId())
        .name(businessAccount.getName())
        .multiCurrency(businessAccount.getMultiCurrency())
        .aggregate(businessAccount.getAggregate())
        .displayed(businessAccount.getDisplayed())
        .functionalCurrencyId(businessAccount.getFunctionalCurrencyId())
        .functionalCurrencyCode(businessAccount.getFunctionalCurrencyCode())
        .currencyFxRateSourceId(businessAccount.getCurrencyFxRateSourceId())
        .sourceAccount(businessAccount.getSourceAccount())
        .sourceAccountName(businessAccount.getSourceAccountName())
        .clientId(businessAccount.getClientId())
        .stat(businessAccount.getStat())
        .simpleWeight(businessAccount.getSimpleWeight())
        .numRatingsRequired(businessAccount.getNumRatingsRequired())
        .active(businessAccount.getActive())
        .demo(businessAccount.getDemo())
        .naic(businessAccount.getNaic())
        .tax(businessAccount.getTax())
        .premiumUseWalForEffectiveMaturity(businessAccount.getPremiumUseWalForEffectiveMaturity())
        .discountUseWalForEffectiveMaturity(businessAccount.getDiscountUseWalForEffectiveMaturity())
        .tradingReconciled(businessAccount.getTradingReconciled())
        .stableDate(businessAccount.getStableDate())
        .reconciled(businessAccount.getReconciled())
        .mmfundInterestAccrued(businessAccount.getMmfundInterestAccrued())
        .simpleAccountIds(businessAccount.getSimpleAccountIds())
        .build();
  }
}
