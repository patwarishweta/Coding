package com.cwan.privatefund.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

/**
 * Configuration class responsible for setting up Thymeleaf TemplateEngine. Thymeleaf is a Java
 * library used for modern server-side Java template engine for both web and standalone
 * environments.
 */
@Configuration
public class ThymeleafConfig {

  /**
   * Configures and returns a Thymeleaf TemplateEngine bean.
   *
   * @return Configured instance of {@link TemplateEngine}.
   */
  @Bean
  public TemplateEngine thymeleafTemplateEngine() {
    var templateEngine = new TemplateEngine();
    templateEngine.addTemplateResolver(htmlTemplateResolver());
    templateEngine.addTemplateResolver(xmlTemplateResolver());
    return templateEngine;
  }

  /**
   * Configures and returns a Thymeleaf ClassLoaderTemplateResolver bean. This resolver looks up
   * Thymeleaf templates in the classpath under the "/templates/" directory.
   *
   * @return Configured instance of {@link ClassLoaderTemplateResolver}.
   */
  @Bean
  public ClassLoaderTemplateResolver htmlTemplateResolver() {
    return getClassLoaderTemplateResolver(".html", TemplateMode.HTML, 1);
  }

  /**
   * Configures and returns a Thymeleaf ClassLoaderTemplateResolver bean. This resolver looks up
   * Thymeleaf templates in the classpath under the "/templates/" directory.
   *
   * @return Configured instance of {@link ClassLoaderTemplateResolver}.
   */
  @Bean
  public ClassLoaderTemplateResolver xmlTemplateResolver() {
    return getClassLoaderTemplateResolver(".xml", TemplateMode.XML, 2);
  }

  private static ClassLoaderTemplateResolver getClassLoaderTemplateResolver(
      String suffix, TemplateMode templateMode, int order) {
    var templateResolver = new ClassLoaderTemplateResolver();
    templateResolver.setPrefix("/templates/");
    templateResolver.setSuffix(suffix);
    templateResolver.setTemplateMode(templateMode);
    templateResolver.setCharacterEncoding("UTF-8");
    templateResolver.setOrder(order);
    return templateResolver;
  }
}
