package com.cwan.privatefund.transaction.model;

public enum BalanceField {
  CHANGE_IN_UNREALIZED_GAIN_LOSS(2036, 3036, 5036),
  FUNDED_COMMITMENT(2207, 3444, -1),
  TOTAL_COMMITMENT(2206, 3443, -1),
  RECALLABLE_DISTRIBUTION(2226, 3459, 5529); // similar to RECALLABLE_COMMITMENT in LPAR
  private final Integer gaapFieldId;
  private final Integer statFieldId;
  private final Integer taxFieldId;

  BalanceField(Integer gaapFieldId, Integer statFieldId, Integer taxFieldId) {
    this.gaapFieldId = gaapFieldId;
    this.statFieldId = statFieldId;
    this.taxFieldId = taxFieldId;
  }

  public Integer getGaapFieldId() {
    return gaapFieldId;
  }

  public Integer getStatFieldId() {
    return statFieldId;
  }

  public Integer getTaxFieldId() {
    return taxFieldId;
  }
}
