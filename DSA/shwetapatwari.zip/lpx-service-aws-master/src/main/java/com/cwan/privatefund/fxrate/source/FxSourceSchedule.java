package com.cwan.privatefund.fxrate.source;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class FxSourceSchedule {
  private Map<Integer, NavigableMap<LocalDate, List<Long>>> sourceScheduleByBasisId;

  public static FxSourceSchedule build(Collection<AccountFxSource> fxSources) {
    return new FxSourceSchedule(
        fxSources.stream()
            .sorted(Comparator.comparingInt(AccountFxSource::getRankId))
            .collect(
                Collectors.groupingBy(
                    AccountFxSource::getBasisId,
                    Collectors.groupingBy(
                        AccountFxSource::getDate,
                        TreeMap::new,
                        Collectors.mapping(
                            AccountFxSource::getFxRateSourceId, Collectors.toList())))));
  }

  public Set<Integer> getBasisIds() {
    return sourceScheduleByBasisId.keySet();
  }

  public NavigableMap<LocalDate, List<Long>> getScheduleForBasis(Integer basisId) {
    return sourceScheduleByBasisId.getOrDefault(basisId, new TreeMap<>());
  }
}
