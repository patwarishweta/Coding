package com.cwan.privatefund.document;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class CwanGptDocument implements Serializable {

  private Long id;
  private String cloudStorageId;
}
