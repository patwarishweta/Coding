package com.cwan.privatefund.auth.ws;

import jakarta.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SAMLResponse {

  private String encodedSamlResponse;
  private String acsUrl;
  @Nullable private String relayState;
  @Nullable private String partnerMarketingUrl;
}
