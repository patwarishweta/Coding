package com.cwan.privatefund.fundmaster;

import com.cwan.lpx.domain.FundIdNameResponseProjection;
import com.cwan.pbor.fundmaster.Fund;
import com.cwan.pbor.fundmaster.FundAliasKey;
import com.cwan.pbor.fundmaster.FundIdentifier;
import com.cwan.pbor.fundmaster.FundInternalMappingEntity;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.FundMasterOverrideEntity;
import com.cwan.pbor.fundmaster.ManagementFeesEntity;
import com.cwan.pbor.fundmaster.PortfolioCompanyEntity;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/fundmaster")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class FundMasterController {
  private final LpxFundMasterService lpxFundMasterService;

  public FundMasterController(LpxFundMasterService lpxFundMasterService) {
    this.lpxFundMasterService = lpxFundMasterService;
  }

  @PostMapping(value = "/portfolioCompany")
  @Operation(summary = "Save portfolio company information")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = PortfolioCompanyEntity.class))
            })
      })
  public List<PortfolioCompanyEntity> savePortfolioCompany(
      @Parameter(description = "Set of Portfolio Companies to save") @RequestBody
          Set<PortfolioCompanyEntity> portfolioCompanyEntities) {
    return lpxFundMasterService.savePortfolioCompanies(portfolioCompanyEntities);
  }

  @PostMapping(value = "/alias")
  @Operation(summary = "Save fund alias information")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FundAliasKey.class))
            })
      })
  public FundAliasKey saveFundAlias(
      @Parameter(description = "Fund Alias Key to save") @RequestBody FundAliasKey fundAliasKey) {
    return lpxFundMasterService.saveFundAliasKey(fundAliasKey);
  }

  @PostMapping(value = "/managementFees")
  @Operation(summary = "Save management fees information")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ManagementFeesEntity.class))
            })
      })
  public List<ManagementFeesEntity> saveManagementFees(
      @Parameter(description = "Set of Portfolio Companies to save") @RequestBody
          Set<ManagementFeesEntity> managementFees) {
    return lpxFundMasterService.saveManagementFees(managementFees);
  }

  @PostMapping(value = "/fundInternalMapping")
  @Operation(summary = "Save fund internal mapping information")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FundInternalMappingEntity.class))
            })
      })
  public List<FundInternalMappingEntity> saveFundInternalMappings(
      @Parameter(description = "Fund Internal Mappings") @RequestBody
          Set<FundInternalMappingEntity> fundInternalMappingEntity) {
    return lpxFundMasterService.saveFundInternalMapping(fundInternalMappingEntity);
  }

  @DeleteMapping(value = "/fundInternalMapping")
  @Operation(summary = "Delete fund internal mapping information")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FundInternalMappingEntity.class))
            })
      })
  public void deleteFundInternalMappings(
      @Parameter(description = "Fund Internal Mappings") @RequestBody
          Set<FundInternalMappingEntity> fundInternalMappingEntity) {
    lpxFundMasterService.deleteFundMasterEntity(fundInternalMappingEntity);
  }

  @PostMapping(value = "")
  @Operation(summary = "Save fund master data")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FundMasterEntity.class))
            })
      })
  public List<FundMasterEntity> saveFundMasterData(
      @Parameter(description = "Fund master attributes") @RequestBody
          Set<FundMasterEntity> fundMasterEntities) {
    return lpxFundMasterService.saveFundMasterEntity(fundMasterEntities);
  }

  @GetMapping(value = "/internal")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get all Internal Funds")
  public Collection<FundMasterEntity> getAllInternalFunds() {
    return lpxFundMasterService.getAllInternalFunds();
  }

  @GetMapping(value = "/fundName/internal")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get all Internal Funds Name and Ids")
  public Collection<FundIdNameResponseProjection> getAllInternalFundsNameId() {
    return lpxFundMasterService.getAllInternalFundsNameId();
  }

  @RequestMapping(value = "/bySecurityId", method = RequestMethod.GET)
  @Operation(summary = "Retrieve Fund data by SecurityIds")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Fund.class))
            })
      })
  public Collection<Fund> getFundDataBySecurities(
      @Parameter(description = "SecurityIds to return data for") @RequestParam
          Set<Long> securityIds) {
    return lpxFundMasterService.getFundDataBySecurities(securityIds);
  }

  @RequestMapping(value = "/bySecurityIdWithOverrides", method = RequestMethod.GET)
  @Operation(summary = "Retrieve Fund data by SecurityIds with Overrides applied")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Fund.class))
            })
      })
  public Collection<Fund> getFundDataWithOverridesBySecurities(
      @Parameter(description = "ClientId that is requesting information")
          @RequestParam(required = false)
          Long clientId,
      @Parameter(description = "AccountId that is requesting information")
          @RequestParam(required = false)
          Long accountId,
      @Parameter(description = "SecurityIds to return data for") @RequestParam
          Set<Long> securityIds) {
    if (clientId == null && accountId == null) {
      throw new ResponseStatusException(
          HttpStatus.BAD_REQUEST,
          "Please include either clientId or accountId to complete this request");
    }
    return lpxFundMasterService.getFundDataWithOverridesBySecurities(
        clientId, accountId, securityIds);
  }

  @RequestMapping(value = "/bySecurityIdAndClientIdOverrideAndOriginal", method = RequestMethod.GET)
  @Operation(
      summary =
          "Retrieve a map containing original fundMasterEntity and overrideEntity by SecurityId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Fund.class))
            })
      })
  public Map<String, FundMasterEntity> getFundDataBySecurityAndClientOverrideAndOriginal(
      @Parameter(description = "ClientId that is requesting information") @RequestParam
          Long clientId,
      @Parameter(description = "SecurityId to return data for") @RequestParam Long securityId) {
    return lpxFundMasterService.getFundMasterAndOverrideEntitiesBySecurityAndClient(
        securityId, clientId);
  }

  @RequestMapping(
      value = "/bySecurityIdAndAccountIdOverrideAndOriginal",
      method = RequestMethod.GET)
  @Operation(
      summary =
          "Retrieve a map containing original fundMasterEntity and overrideEntity by SecurityId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Fund.class))
            })
      })
  public Map<String, FundMasterEntity> getFundDataBySecurityAndAccountOverrideAndOriginal(
      @Parameter(description = "AccountId that is requesting information") @RequestParam
          Long accountId,
      @Parameter(description = "SecurityId to return data for") @RequestParam Long securityId) {
    return lpxFundMasterService.getFundMasterAndOverrideEntitiesBySecurityAndAccount(
        securityId, accountId);
  }

  @RequestMapping(value = "/byEINs", method = RequestMethod.GET)
  @Operation(summary = "Retrieve Fund data by EIN")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Fund.class))
            })
      })
  public Collection<Fund> getFundDataByEins(
      @Parameter(description = "EINs to return data for") @RequestParam Set<String> eins) {
    return lpxFundMasterService.getFundDataByEins(eins);
  }

  @RequestMapping(value = "/fundIdentifiers", method = RequestMethod.GET)
  @Operation(summary = "Retrieve all fund identification information")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FundIdentifier.class))
            })
      })
  public Collection<FundIdentifier> getFundIdentifiers() {
    return lpxFundMasterService.getFundIdentifiers();
  }

  @DeleteMapping(value = "/deleteOverride")
  @Operation(summary = "Delete fund master override")
  @ResponseStatus(HttpStatus.OK)
  public void deleteOverride(
      @Parameter(description = "clientId") @RequestParam Long clientId,
      @Parameter(description = "securityId") @RequestParam Long securityId) {
    lpxFundMasterService.deleteOverride(clientId, securityId);
  }

  @PostMapping(value = "/saveFundMasterOverrides")
  @Operation(summary = "Save FundMaster Overrides")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FundMasterOverrideEntity.class))
            })
      })
  public Collection<FundMasterOverrideEntity> saveFundMasterOverrides(
      @Parameter(description = "Set of FundMaster Overrides to save  (DEV ONLY)") @RequestBody
          Set<FundMasterOverrideEntity> overrideEntities) {
    return lpxFundMasterService.saveFundMasterOverrides(overrideEntities);
  }

  @RequestMapping(value = "/allForClientOriginalAndOverride", method = RequestMethod.GET)
  @Operation(
      summary =
          "Retrieves all of the securities for a client, with their corresponding fundmaster entries, fundmaster overrides and override level.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Fund.class))
            })
      })
  public Flux<Map<String, Object>> getAllForClientOriginalAndOverride(
      @RequestParam Long clientId, @RequestParam Integer userId) {
    return lpxFundMasterService.getAllEntitiesForClientOriginalAndOverride(clientId, userId);
  }
}
