package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.util.ExceptionUtils;
import com.cwan.privatefund.util.StringOperationUtils;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallStatusUpdaterService {

  private final CapitalCalls capitalCalls;
  private final CapitalCallEnrichmentService capitalCallEnrichmentService;
  private final CapitalCallBankAccountVerifierService capitalCallBankAccountVerifierService;

  /**
   * Method to update the status of a Capital Call document.
   *
   * @param user the authenticated user performing the action
   * @param documentId the ID of the document to update
   * @param currentStatus the current status of the capital call
   * @param action the action to take on the capital call
   * @param comment a comment related to the action
   * @return a Mono of the updated and transformed CapitalCallDocument
   */
  public Mono<CapitalCallDocument> updateStatusAndTransform(
      User user,
      Long documentId,
      CapitalCallStatus currentStatus,
      CapitalCallAction action,
      String comment) {
    return capitalCalls
        .updateCapitalCallStatus(
            CapitalCallAuditAction.builder()
                .documentId(documentId)
                .currentStatus(currentStatus)
                .comment(comment)
                .user(
                    CapitalCallUser.builder()
                        .id(user.getId())
                        .fullName(user.getFullname())
                        .email(user.getEmail())
                        .build())
                .build(),
            action)
        .doOnSuccess(
            updatedCall ->
                log.debug(
                    "Document ID {} status updated. New status: {}",
                    documentId,
                    updatedCall.status()))
        .doOnError(
            error ->
                log.error(
                    "Failed to update status for document id: {}. Error is: {}",
                    documentId,
                    ExceptionUtils.getStackTraceAsString(error)))
        .flatMapMany(
            updatedCall ->
                capitalCallEnrichmentService.enrichCapitalCallWithData(
                    updatedCall, user.getEmail()))
        .next()
        .doOnError(
            error ->
                log.error(
                    "Enrichment failed for document id: {}. Error is: {}",
                    documentId,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Handles the bank account verification.
   *
   * @param document the Capital Call document to be updated
   * @param systemUser the system user performing the action
   * @return a Mono of the updated CapitalCallDocument, with additional handling if the bank account
   *     is not new
   */
  public Mono<CapitalCallDocument> handleNewBankAccount(
      CapitalCallDocument document, User systemUser) {
    log.debug("Initiating new bank account handling for documentId: {}", document.documentId());
    return capitalCallBankAccountVerifierService
        .isNewBankAccount(document)
        .doOnNext(
            isNewAccount ->
                log.debug(
                    "Bank account verification result for documentId {}: isNewAccount = {}",
                    document.documentId(),
                    isNewAccount))
        .flatMap(
            isNewAccount -> {
              if (Boolean.FALSE.equals(isNewAccount)) {
                log.debug(
                    "Identified existing bank account for documentId: {}. Handling existing bank account.",
                    document.documentId());
                return handleExistingBankAccount(document, systemUser)
                    .doOnNext(
                        existingAccount ->
                            log.debug(
                                "Existing bank account handled for documentId: {}",
                                document.documentId()));
              }
              log.debug(
                  "No existing bank account found for documentId: {}. Proceeding without additional handling.",
                  document.documentId());
              return Mono.just(document);
            })
        .doOnError(
            e ->
                log.error(
                    "Error handling new bank account for documentId: {}",
                    document.documentId(),
                    e));
  }

  Mono<CapitalCallDocument> handleExistingBankAccount(
      CapitalCallDocument document, User systemUser) {
    log.debug("Handling existing bank account for documentId: {}", document.documentId());
    var defaultMessage = "Automatic transition to initial review; account details verified.";
    return buildBankAccountInfo(document)
        .defaultIfEmpty(defaultMessage)
        .flatMap(
            accountInfo -> {
              var newComment =
                  StringUtils.equalsIgnoreCase(accountInfo, defaultMessage)
                      ? defaultMessage
                      : "Automatic transition to initial review; account details ["
                          + accountInfo
                          + "] verified.";
              log.debug(
                  "Updating status for documentId: {} with new comment: {}",
                  document.documentId(),
                  newComment);
              return updateStatusAndTransform(
                      systemUser,
                      document.documentId(),
                      document.status(),
                      CapitalCallAction.APPROVE,
                      newComment)
                  .doOnNext(
                      updatedDocument ->
                          log.debug(
                              "Status update and transform completed for documentId: {}",
                              document.documentId()));
            })
        .doOnError(
            e ->
                log.error(
                    "Error handling existing bank account for documentId: {}",
                    document.documentId(),
                    e));
  }

  Mono<String> buildBankAccountInfo(CapitalCallDocument document) {
    if (Objects.isNull(document.bankDetail())) {
      log.warn("Bank Detail is null for document ID: {}", document.documentId());
      return Mono.empty();
    }
    return Mono.fromSupplier(
        () -> {
          var accountNumber =
              StringOperationUtils.normalizeAndTrimToNull(document.bankDetail().accountNumber());
          var iban =
              StringOperationUtils.normalizeAndTrimToNull(document.bankDetail().accountIban());
          var accountInfoBuilder = new StringBuilder();
          if (Objects.nonNull(accountNumber)) {
            accountInfoBuilder.append("Account Number '").append(accountNumber).append("'");
          }
          if (Objects.nonNull(iban)) {
            if (!accountInfoBuilder.isEmpty()) {
              accountInfoBuilder.append(" and ");
            }
            accountInfoBuilder.append("IBAN '").append(iban).append("'");
          }
          return accountInfoBuilder.toString();
        });
  }
}
