package com.cwan.privatefund.security.currency;

import com.cwan.privatefund.security.model.SecurityCurrency;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class SecurityCurrencyEntityTransformer
    implements Function<SecurityCurrency, SecurityCurrencyEntity> {
  @Override
  public SecurityCurrencyEntity apply(SecurityCurrency securityCurrencyInfo) {
    return SecurityCurrencyEntity.builder()
        .securityId(securityCurrencyInfo.getSecurityId())
        .currencyId(securityCurrencyInfo.getCurrencyId())
        .modifiedOn(
            securityCurrencyInfo.getModifiedOn() != null
                ? securityCurrencyInfo.getModifiedOn()
                : LocalDateTime.now(ZoneOffset.UTC))
        .build();
  }
}
