package com.cwan.privatefund.calculated.model;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class CalculatedBalance {

  private String source;
  private Security security;
  private Account account;
  private String currency;
  private Double navImpact;
  private Double watchlistNavImpact;
  private Double gaapNavImpact;
  private Double statNavImpact;
  private Double fundedCommitmentImpact;
  private Double unfundedCommitmentImpact;
  private Double recallableImpact;
  private Double totalCommitment;
  private Double totalContributions;
  private Double totalDistributions;

  public boolean hasMaterialBalances() {
    return navImpact != 0
        || fundedCommitmentImpact != 0
        || unfundedCommitmentImpact != 0
        || recallableImpact != 0
        || totalCommitment != 0
        || totalContributions != 0
        || totalDistributions != 0
        || watchlistNavImpact != 0;
  }

  public static AccountingCalculatedBalance toAccountingCalculatedBalance(
      CalculatedBalance balance) {
    return AccountingCalculatedBalance.builder()
        .source(balance.source)
        .security(balance.security)
        .account(balance.account)
        .currency(balance.currency)
        .navImpact(balance.watchlistNavImpact)
        .fundedCommitmentImpact(balance.fundedCommitmentImpact)
        .unfundedCommitmentImpact(balance.unfundedCommitmentImpact)
        .recallableImpact(balance.recallableImpact)
        .totalCommitment(balance.totalCommitment)
        .totalContributions(balance.totalContributions)
        .totalDistributions(balance.totalDistributions)
        .build();
  }
}
