package com.cwan.privatefund.documentmanager;

import com.cwan.lpx.domain.Document;
import com.cwan.pbor.document.misc.document.entity.MiscDocumentEntity;
import com.cwan.privatefund.account.UltimateParents;
import com.cwan.privatefund.documentmanager.enums.MiscDocumentStatus;
import java.util.Objects;
import org.springframework.stereotype.Component;

@Component
public class MiscDocumentTransformer {

  public MiscDocumentEntity transform(Document document, UltimateParents ultimateParent) {
    return MiscDocumentEntity.builder()
        .documentId(document.getId())
        .accountId(document.getAccount().getId())
        .accountName(document.getAccount().getName())
        .securityId(
            Objects.isNull(document.getSecurity()) ? null : document.getSecurity().getSecurityId())
        .securityName(
            Objects.isNull(document.getSecurity())
                ? null
                : document.getSecurity().getSecurityName())
        .documentType(document.getType())
        .receivedDate(document.getReceivedDate())
        .cashMovementDate(document.getCashMovementDate())
        .docDate(document.getDocumentDate())
        .status(MiscDocumentStatus.ACTIVE.getValue())
        .ultimateParentId(ultimateParent.getUltimateParentId())
        .ultimateParentName(ultimateParent.getUltimateParentName())
        .createdBy(document.getCreatedBy())
        .modifiedBy(document.getModifiedBy())
        .build();
  }
}
