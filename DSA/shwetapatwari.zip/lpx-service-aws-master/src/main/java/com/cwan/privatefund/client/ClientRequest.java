package com.cwan.privatefund.client;

import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;

public interface ClientRequest {

  Logger LOGGER = LoggerFactory.getLogger(ClientRequest.class);

  static ExchangeFilterFunction logRequest(String webClientMetrics) {
    return (clientRequest, next) ->
        next.exchange(clientRequest)
            .doOnEach(
                signal -> {
                  if (!signal.isOnComplete()) {
                    Optional.of(signal.getContextView().get(webClientMetrics))
                        .filter(Long.class::isInstance)
                        .map(Long.class::cast)
                        .ifPresent(
                            metricsValue ->
                                LOGGER.info(
                                    "Time Taken by this request {}ms [{}] {}",
                                    System.currentTimeMillis() - metricsValue,
                                    clientRequest.method(),
                                    clientRequest.url()));
                  }
                })
            .contextWrite(ctx -> ctx.put(webClientMetrics, System.currentTimeMillis()));
  }
}
