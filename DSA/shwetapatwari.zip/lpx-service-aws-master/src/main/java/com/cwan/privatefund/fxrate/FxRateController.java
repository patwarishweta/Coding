package com.cwan.privatefund.fxrate;

import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_DISPOSITION_HEADER;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_ENCODING_HEADER;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_TYPE_CSV;
import static com.cwan.privatefund.tabular.controller.TabularBalanceController.CONTENT_TYPE_HEADER;

import com.cwan.privatefund.fxrate.source.AccountFxSource;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.ws.rs.QueryParam;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/fx-rates")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class FxRateController {
  private final LpxFxRateService lpxFxRateService;
  private final FxRateJobRunner fxRateJobRunner;
  private final ObjectMapper objectMapper;

  FxRateController(
      LpxFxRateService lpxFxRateService,
      FxRateJobRunner fxRateJobRunner,
      ObjectMapper objectMapper) {
    this.lpxFxRateService = lpxFxRateService;
    this.fxRateJobRunner = fxRateJobRunner;
    this.objectMapper = objectMapper;
  }

  @GetMapping(value = "/average/base-currency/{baseCurrencyId}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary =
          "Get the average FX rates for a given baseCurrencyId, filtered by accountId. Organized by securityId -> date. "
              + "Rates are calculated using the non-basis-specific sourceId for the account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Average FX rates fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getAverageFxRates(
      @PathVariable("baseCurrencyId") Long baseCurrencyId,
      @QueryParam("accountId") Long accountId,
      @RequestParam(value = "exportAsFile", defaultValue = "false") boolean exportAsFile) {
    Map<Long, Map<LocalDate, Double>> fxRate =
        lpxFxRateService
            .getSecurityAverageFxRatesByBasis(baseCurrencyId, accountId)
            .getOrDefault(AccountFxSource.NOT_BASIS_SPECIFIC_ID, Map.of());

    if (exportAsFile) {
      StringBuilder csvBuilder = new StringBuilder();
      DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

      csvBuilder.append("Security ID,Date,Average FX Rate\n");

      for (Map.Entry<Long, Map<LocalDate, Double>> basisEntry : fxRate.entrySet()) {
        Long basisId = basisEntry.getKey();
        Map<LocalDate, Double> ratesByDate = basisEntry.getValue();

        for (Map.Entry<LocalDate, Double> dateEntry : ratesByDate.entrySet()) {
          LocalDate date = dateEntry.getKey();
          Double averageFxRate = dateEntry.getValue();

          csvBuilder
              .append(basisId)
              .append(",")
              .append(date.format(dateFormatter))
              .append(",")
              .append(averageFxRate)
              .append("\n");
        }
      }

      return ResponseEntity.ok()
          .header(
              CONTENT_DISPOSITION_HEADER,
              "attachment; filename=\"average-fx-rates-"
                  + baseCurrencyId
                  + "-"
                  + accountId
                  + ".csv\"")
          .header(CONTENT_ENCODING_HEADER, "binary")
          .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
          .body(csvBuilder.toString().getBytes());
    }
    return ResponseEntity.ok(fxRate);
  }

  @GetMapping(value = "/average/base-currency/{baseCurrencyId}/basis")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary =
          "Get the average FX rates for a given baseCurrencyId, filtered by accountId. Organized by basisId -> securityId -> date. "
              + "basisId = -1 means that the values apply to all basis' where there isn't a basis-specific override")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Average FX rates fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getAverageFxRatesByBasis(
      @PathVariable("baseCurrencyId") Long baseCurrencyId,
      @QueryParam("accountId") Long accountId,
      @RequestParam(value = "exportAsFile", defaultValue = "false") boolean exportAsFile) {
    Map<Integer, Map<Long, Map<LocalDate, Double>>> fxRate =
        lpxFxRateService.getSecurityAverageFxRatesByBasis(baseCurrencyId, accountId);

    if (exportAsFile) {
      StringBuilder csvBuilder = new StringBuilder();
      DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

      csvBuilder.append("Basis ID,Security ID,Date,Average FX Rate\n");

      for (Map.Entry<Integer, Map<Long, Map<LocalDate, Double>>> basisEntry : fxRate.entrySet()) {
        Integer basisId = basisEntry.getKey();
        Map<Long, Map<LocalDate, Double>> securityRates = basisEntry.getValue();

        for (Map.Entry<Long, Map<LocalDate, Double>> securityEntry : securityRates.entrySet()) {
          Long securityId = securityEntry.getKey();
          Map<LocalDate, Double> ratesByDate = securityEntry.getValue();

          for (Map.Entry<LocalDate, Double> dateEntry : ratesByDate.entrySet()) {
            LocalDate date = dateEntry.getKey();
            Double averageFxRate = dateEntry.getValue();

            csvBuilder
                .append(basisId)
                .append(",")
                .append(securityId)
                .append(",")
                .append(date.format(dateFormatter))
                .append(",")
                .append(averageFxRate)
                .append("\n");
          }
        }
      }

      return ResponseEntity.ok()
          .header(
              CONTENT_DISPOSITION_HEADER,
              "attachment; filename=\"average-fx-rates-" + accountId + ".csv\"")
          .header(CONTENT_ENCODING_HEADER, "binary")
          .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
          .body(csvBuilder.toString().getBytes());
    }

    return ResponseEntity.ok(fxRate);
  }

  @GetMapping(value = "/average")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary =
          "Get or calculate the average FX rate for a given accountId, securityId, localCurrencyId, and date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Average FX rate fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Double> getAverageFxRate(
      @QueryParam("accountId") Long accountId,
      @QueryParam("securityId") Long securityId,
      @QueryParam("localCurrencyId") Long localCurrencyId,
      @QueryParam("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
    return lpxFxRateService.getAverageFxRate(accountId, securityId, localCurrencyId, date);
  }

  @PostMapping("/job/daily/start")
  @Operation(summary = "Start running the daily FX rate job")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Daily FX rate job started"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public ResponseEntity<String> runDailyFxRateJob() {
    CompletableFuture.runAsync(fxRateJobRunner::runDailyFxRateJob);
    return ResponseEntity.ok("Daily FX rate job started");
  }

  @PostMapping("/job/recalculate/account/{accountId}/start")
  @Operation(
      summary = "Start running a job that will recalculate FX rates for the provided account")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Recalculation FX rate job started"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public ResponseEntity<String> runRecalculationFxRateJob(
      @PathVariable("accountId") Long accountId,
      @RequestParam(required = false) Set<Long> securityIds) {
    CompletableFuture.runAsync(
        () -> fxRateJobRunner.runRecalculationFxRateJob(accountId, securityIds));
    return ResponseEntity.ok("Recalculation FX rate job started");
  }
}
