package com.cwan.privatefund.issuestore.model;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IssueExpiration {

  private LocalDate date;
  private IssueStatusName statusName;
}
