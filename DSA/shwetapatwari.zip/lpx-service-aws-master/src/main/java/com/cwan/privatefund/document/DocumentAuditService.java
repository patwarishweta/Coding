package com.cwan.privatefund.document;

import com.cwan.lpx.domain.Document;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.privatefund.document.model.DocumentAuditValidationEntity;
import com.cwan.privatefund.util.DateUtils;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class DocumentAuditService {

  private final DocumentAuditValidationRepository documentAuditValidationRepository;

  public DocumentAuditService(DocumentAuditValidationRepository documentAuditValidationRepository) {
    this.documentAuditValidationRepository = documentAuditValidationRepository;
  }

  public void saveDocumentAuditInfo(Document document) {
    DocumentAuditValidationEntity newEntity = new DocumentAuditValidationEntity();
    newEntity.setDocumentId(document.getId());
    newEntity.setFileName(document.getFileName());
    newEntity.setChecked(document.getChecked());
    newEntity.setModifiedBy(document.getModifiedBy());
    newEntity.setModifiedOn(document.getModifiedOn());
    newEntity.setCanoeId(document.getCanoeId());
    documentAuditValidationRepository.save(newEntity);
  }

  public Flux<DocumentInfo> getDocumentsWithAuditInfo(Flux<Document> documentFlux) {
    return documentFlux
        .map(Document::getId)
        .collectList()
        .flatMapMany(
            documentIds -> {
              // Fetch audit information based on all collected document IDs
              List<Object[]> queryResult =
                  documentAuditValidationRepository.findDocumentsWithAuditInfo(documentIds);

              // Create a mapping from document ID to its corresponding audit data
              Map<Long, DocumentDbInfo> auditMap =
                  queryResult.stream()
                      .filter(result -> result[1] != null)
                      .collect(
                          Collectors.toMap(
                              result -> ((DocumentAuditValidationEntity) result[1]).getDocumentId(),
                              result ->
                                  new DocumentDbInfo(
                                      (DocumentEntity) result[0],
                                      (DocumentAuditValidationEntity) result[1]),
                              (existing, replacement) ->
                                  existing
                                          .auditEntity
                                          .getModifiedOn()
                                          .isAfter(replacement.auditEntity.getModifiedOn())
                                      ? existing
                                      : replacement));

              // Return the original documents along with their corresponding audit info
              return documentFlux.map(
                  document -> {
                    DocumentDbInfo documentDbInfo = auditMap.get(document.getId());
                    if (documentDbInfo == null) {
                      log.warn(
                          "No audit information found for document with ID: {}", document.getId());
                      return new DocumentInfo(null, null, document);
                    }
                    return new DocumentInfo(
                        documentDbInfo.documentEntity, documentDbInfo.auditEntity, document);
                  });
            });
  }

  public Flux<DocumentDbInfo> getRecentlyValidatedDocuments(
      LocalDate startDate, LocalDate endDate, Set<Long> accountIds) {
    return Flux.fromIterable(
        documentAuditValidationRepository
            .findRecentlyValidatedDocuments(
                startDate.atStartOfDay(), DateUtils.atEndOfDay(endDate), accountIds)
            .stream()
            .map(
                result ->
                    new DocumentDbInfo(
                        (DocumentEntity) result[0], (DocumentAuditValidationEntity) result[1]))
            .collect(Collectors.toSet()));
  }

  public record DocumentDbInfo(
      DocumentEntity documentEntity, DocumentAuditValidationEntity auditEntity) {}
}
