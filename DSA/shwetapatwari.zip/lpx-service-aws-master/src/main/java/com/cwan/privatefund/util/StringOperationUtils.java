package com.cwan.privatefund.util;

import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

@UtilityClass
public final class StringOperationUtils {

  /**
   * Trims the input string, replaces consecutive whitespace characters with a single space, and
   * then returns null if the result is an empty string.
   *
   * @param input the input string
   * @return the normalized and trimmed string, or null if the result is an empty string
   */
  public static String normalizeAndTrimToNull(String input) {
    return StringUtils.trimToNull(StringUtils.normalizeSpace(input));
  }
}
