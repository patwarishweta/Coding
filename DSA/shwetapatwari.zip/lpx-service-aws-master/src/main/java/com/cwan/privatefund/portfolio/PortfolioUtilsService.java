package com.cwan.privatefund.portfolio;

import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.portfolio.model.PortfolioData;
import com.cwan.privatefund.security.SecurityService;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
@Service
public class PortfolioUtilsService {

  private final AccountService accountService;
  private final SecurityService securityService;
  private final PortfolioWsClient portfolioWsClient;

  public PortfolioUtilsService(
      AccountService accountService,
      SecurityService securityService,
      PortfolioWsClient portfolioWsClient) {
    this.accountService = accountService;
    this.securityService = securityService;
    this.portfolioWsClient = portfolioWsClient;
  }

  public Mono<Map<Long, Collection<Security>>> getAllSecuritiesByAccountId(Long accountId) {
    return accountService
        .expandAccountId(accountId)
        .collectList()
        .flatMap(portfolioWsClient::getPortfolioDataWithCacheCheck)
        .flatMapIterable(Function.identity())
        .subscribeOn(Schedulers.boundedElastic())
        .filter(portfolioData -> portfolioData.getSecurityId() != null)
        .collect(
            Collectors.groupingBy(
                PortfolioData::getAccountId,
                Collectors.mapping(PortfolioData::getSecurityId, Collectors.toList())))
        .flatMap(
            accountToSecurityIds ->
                Flux.fromIterable(accountToSecurityIds.entrySet())
                    .flatMap(
                        entry ->
                            securityService
                                .getSecurities(null, entry.getKey(), entry.getValue())
                                .map(securities -> Map.entry(entry.getKey(), securities)))
                    .collectMap(Map.Entry::getKey, Map.Entry::getValue));
  }
}
