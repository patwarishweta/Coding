package com.cwan.privatefund.capital.call.service;

import static com.cwan.lpx.domain.CapitalCallStatus.BLACKLISTED;
import static com.cwan.lpx.domain.CapitalCallStatus.COMPLETED;
import static com.cwan.lpx.domain.CapitalCallStatus.FINAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.INITIAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK_REJECTED;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.CommonConstants.BUFFER_SIZE;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DateConstants;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.constant.CapitalCallAccessType;
import com.cwan.privatefund.capital.call.model.ComprehensiveAuditDetail;
import com.cwan.privatefund.util.ExceptionUtils;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** This service class provides methods to manage Capital Calls. */
@Service
@Slf4j
@RequiredArgsConstructor
public class LpxCapitalCallService {

  private final CapitalCalls capitalCalls;
  private final AccountService accountService;
  private final SecurityContextUserService securityContextUserService;
  private final CapitalCallEnrichmentService capitalCallEnrichmentService;
  private final CapitalCallAuditService capitalCallAuditService;
  private final CapitalCallAccessService capitalCallAccessService;
  private final CapitalCallEmailNotificationService capitalCallEmailNotificationService;
  private final CapitalCallBankAccountVerifierService capitalCallBankAccountVerifierService;
  private final CapitalCallStatusUpdaterService capitalCallStatusUpdaterService;
  private final CapitalCallPaymentInitiationService capitalCallPaymentInitiationService;

  /**
   * Fetches capital calls based on the date range and filter type provided, optionally filtered by
   * an ultimate parent client ID.
   *
   * @param filterType the type of date filter to apply
   * @param startDate the beginning of the date range
   * @param endDate the end of the date range
   * @param ultimateParentClientId the optional Ultimate Parent Client ID
   * @return a Flux stream of CapitalCallDocument objects
   */
  public Flux<CapitalCallDocument> fetchCapitalCallsWithinDateRange(
      CapitalCallDateFilterType filterType,
      LocalDate startDate,
      LocalDate endDate,
      Integer ultimateParentClientId) {
    log.debug(
        "Initiating fetch for capital calls with filterType {} from {} to {} (ultimateParentClientId: {})",
        filterType,
        startDate,
        endDate,
        ultimateParentClientId);
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .flatMapMany(
            user ->
                retrieveCapitalCallsForUser(
                    user, filterType, startDate, endDate, ultimateParentClientId))
        .doOnError(
            error ->
                log.error(
                    "Failed to fetch capital calls between {} and {}. Error: {}",
                    startDate,
                    endDate,
                    ExceptionUtils.getStackTraceAsString(error)))
        .sort(Comparator.comparing(CapitalCallDocument::documentId).reversed());
  }

  /**
   * Fetches all capital calls associated with accounts, optionally filtered by an ultimate parent
   * client ID.
   *
   * @param ultimateParentClientId the optional Ultimate Parent Client ID
   * @return a Flux of CapitalCallDocument objects.
   */
  public Flux<CapitalCallDocument> fetchAllCapitalCallsByAccounts(Integer ultimateParentClientId) {
    return fetchCapitalCallsWithinDateRange(
        CapitalCallDateFilterType.RECEIVED_DATE,
        DateConstants.MIN_START_DATE,
        DateConstants.MAX_END_DATE,
        ultimateParentClientId);
  }

  /**
   * Fetches detailed audit information for capital calls based on the date range and filter type
   * provided.
   *
   * @param filterType the type of date filter to apply.
   * @param startDate the beginning of the date range.
   * @param endDate the end of the date range.
   * @param ultimateParentClientId the optional Ultimate Parent Client ID
   * @return a Flux stream of ComprehensiveAuditDetail objects.
   */
  public Flux<ComprehensiveAuditDetail> fetchDetailedAuditForCapitalCalls(
      CapitalCallDateFilterType filterType,
      LocalDate startDate,
      LocalDate endDate,
      Integer ultimateParentClientId) {
    log.info(
        "Initiating comprehensive audit detail fetch with filter type {} from {} to {}",
        filterType,
        startDate,
        endDate);
    return fetchCapitalCallsWithinDateRange(filterType, startDate, endDate, ultimateParentClientId)
        .flatMap(ComprehensiveAuditDetail::transformDocumentToAuditDetail)
        .doOnError(
            error ->
                log.error(
                    "Failed to fetch comprehensive audit details between {} and {}. Error: {}",
                    startDate,
                    endDate,
                    ExceptionUtils.getStackTraceAsString(error)));
  }

  /**
   * Updates the status of a specific Capital Call document.
   *
   * @param documentId the ID of the document to update
   * @param currentStatus the current status of the capital call
   * @param action the action to take on the capital call
   * @param comment a comment related to the action
   * @return a Mono of the updated CapitalCallDocument
   */
  public Mono<CapitalCallDocument> updateCapitalCallStatus(
      Long documentId, CapitalCallStatus currentStatus, CapitalCallAction action, String comment) {
    log.info("Initiating status update for capital call document ID {}", documentId);
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .flatMap(
            user ->
                capitalCallAccessService
                    .checkUserAccess(user, documentId, CapitalCallAccessType.WRITE)
                    .flatMap(
                        callDocument ->
                            capitalCallStatusUpdaterService.updateStatusAndTransform(
                                user, documentId, currentStatus, action, comment)))
        .doOnNext(capitalCallEmailNotificationService::enqueueDocumentForEmail);
  }

  /**
   * Initiates the process of payment initiation for a given document ID. This method triggers a
   * series of steps to validate user details and check user access before proceeding with the
   * payment initiation process.
   *
   * @param documentId The ID of the document for which payment initiation is to be processed.
   * @return A Mono of String, representing the outcome of the payment initiation process.
   */
  public Mono<String> processPaymentInitiation(Long documentId) {
    log.info("Processing payment initiation for document ID: {}", documentId);
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .flatMap(
            user ->
                capitalCallAccessService
                    .checkUserAccess(user, documentId, CapitalCallAccessType.READ)
                    .flatMap(capitalCallPaymentInitiationService::processPaymentInitiation));
  }

  /**
   * Retrieves the audit log for a given Capital Call document.
   *
   * @param documentId the ID of the Capital Call document to retrieve the audit log for
   * @return a Mono of the CapitalCallAuditLog for the provided document ID
   */
  public Mono<CapitalCallAuditLog> getCapitalCallAuditByDocument(Long documentId) {
    log.info("Initiating retrieval of capital call audit log for document ID {}", documentId);
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .flatMap(
            user ->
                capitalCallAccessService
                    .checkUserAccess(user, documentId, CapitalCallAccessType.READ)
                    .flatMap(callDocument -> capitalCallAuditService.getAuditLog(documentId)));
  }

  /**
   * Retrieves Capital Call documents based on the given set of statuses.
   *
   * @param capitalCallStatuses Set of statuses for which Capital Call documents are to be retrieved
   * @return a Flux of enriched CapitalCallDocument objects corresponding to the provided statuses
   */
  public Flux<CapitalCallDocument> getCapitalCallsByStatuses(
      Set<CapitalCallStatus> capitalCallStatuses) {
    log.info("Fetching capital calls for statuses: {}", capitalCallStatuses);
    return capitalCalls
        .getCapitalCallsByStatuses(capitalCallStatuses)
        .buffer(BUFFER_SIZE)
        .concatMap(capitalCallBankAccountVerifierService::verifyAndSetBufferedNewBankAccountFlag)
        .concatMap(
            doc ->
                capitalCallEnrichmentService.enrichCapitalCallWithData(
                    doc, SystemUserConstants.EMAIL))
        .doOnComplete(
            () ->
                log.info(
                    "Successfully fetched capital calls for statuses: {}", capitalCallStatuses))
        .doOnError(
            error ->
                log.error(
                    "Failed to fetch capital calls for statuses: {}. Error is: {}",
                    capitalCallStatuses,
                    ExceptionUtils.getStackTraceAsString(error)))
        .sort(Comparator.comparing(CapitalCallDocument::documentId).reversed());
  }

  /**
   * Inserts any missed Capital Calls into the system. This method ensures that no capital calls are
   * missed due to interruptions or failures. It initiates the insertion process, logs information
   * on how many capital calls (if any) were inserted, and completes the process with either a
   * success or failure log entry.
   *
   * @return A Mono of Boolean indicating whether any missed capital calls were inserted.
   */
  public Mono<Boolean> insertMissedCapitalCalls() {
    log.info("Initiating process to insert missed capital calls");
    return capitalCalls
        .insertMissedCapitalCalls()
        .map(
            rowsInserted -> {
              if (rowsInserted > 0) {
                log.info("Successfully inserted {} missed capital calls.", rowsInserted);
                return true;
              }
              log.info("No missed capital calls found to be inserted.");
              return false;
            })
        .doOnTerminate(() -> log.info("Completed the insertion process for missed capital calls"))
        .doOnError(
            error ->
                log.error(
                    "Failed to insert missed capital calls. Error is: {}",
                    ExceptionUtils.getStackTraceAsString(error)))
        .onErrorReturn(false);
  }

  /**
   * Retrieves CapitalCallDocument entities for a specific user within a given date range and filter
   * type, optionally filtered by an ultimate parent client ID.
   *
   * @param user The target user
   * @param filterType The date filter type
   * @param startDate The start of the date range
   * @param endDate The end of the date range
   * @param ultimateParentClientId The optional Ultimate Parent Client ID
   * @return A Flux of CapitalCallDocument entities
   */
  private Flux<CapitalCallDocument> retrieveCapitalCallsForUser(
      User user,
      CapitalCallDateFilterType filterType,
      LocalDate startDate,
      LocalDate endDate,
      Integer ultimateParentClientId) {
    log.info(
        "Fetching capital calls for user ID {} (ultimateParentClientId: {})",
        user.getId(),
        ultimateParentClientId);
    return (Objects.nonNull(ultimateParentClientId)
            ? getAccountIdsForUltimateParent(user.getId(), ultimateParentClientId)
            : accountService.retrieveUserAccessibleAccountIds(user.getId()))
        .flatMapMany(
            accountIds -> {
              var userId = user.getId();
              if (Objects.nonNull(ultimateParentClientId)) {
                log.debug(
                    "Retrieved account IDs {} for user ID {} and ultimateParentClientId {}",
                    accountIds,
                    userId,
                    ultimateParentClientId);
              } else {
                log.debug("Retrieved account IDs {} for user ID {}", accountIds, userId);
              }
              return processAccountIds(accountIds, user, filterType, startDate, endDate);
            })
        .doOnError(
            error -> {
              var errorMessage =
                  String.format(
                      "Error retrieving capital calls for user ID %d%s. Error: %s",
                      user.getId(),
                      Objects.nonNull(ultimateParentClientId)
                          ? " (ultimateParentClientId: " + ultimateParentClientId + ")"
                          : "",
                      ExceptionUtils.getStackTraceAsString(error));
              log.error(errorMessage);
            });
  }

  /**
   * Fetches account IDs from the Ultimate Parent Map, ensuring that the parent/client is associated
   * with this user. Throws UNAUTHORIZED if not found.
   *
   * @param userId The user ID
   * @param ultimateParentClientId The Ultimate Parent Client ID to filter by
   * @return A Mono containing the filtered set of account IDs
   */
  private Mono<Set<Long>> getAccountIdsForUltimateParent(
      Integer userId, Integer ultimateParentClientId) {
    return accountService
        .retrieveAccountMapByUltimateParent(userId)
        .flatMap(
            ultimateParentMap -> {
              if (!ultimateParentMap.containsKey(ultimateParentClientId)) {
                log.error(
                    "Ultimate Parent Client ID {} is not associated with user ID {}",
                    ultimateParentClientId,
                    userId);
                return Mono.error(
                    new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "Unauthorized: Ultimate Parent Client ID not associated with this user"));
              }
              return Mono.just(ultimateParentMap.get(ultimateParentClientId));
            });
  }

  /**
   * Processes sets of account IDs to retrieve associated CapitalCallDocument entities.
   *
   * @param allAccountIds A set containing account IDs.
   * @param user The target user.
   * @param filterType The date filter type.
   * @param startDate The start of the date range.
   * @param endDate The end of the date range.
   * @return A Flux of CapitalCallDocument entities.
   */
  private Flux<CapitalCallDocument> processAccountIds(
      Set<Long> allAccountIds,
      User user,
      CapitalCallDateFilterType filterType,
      LocalDate startDate,
      LocalDate endDate) {
    return Flux.fromIterable(allAccountIds)
        .buffer(500)
        .flatMap(
            bufferedList -> {
              Set<Long> bufferedSet = new HashSet<>(bufferedList);
              log.debug("Processing buffered account IDs: {}", bufferedSet);
              return fetchBufferedCapitalCalls(bufferedSet, user, filterType, startDate, endDate);
            });
  }

  /**
   * Fetches CapitalCallDocument entities based on buffered sets of account IDs.
   *
   * @param bufferedAccountIds Set of account IDs.
   * @param user The target user.
   * @param filterType The date filter type.
   * @param startDate The start of the date range.
   * @param endDate The end of the date range.
   * @return A Flux of CapitalCallDocument entities.
   */
  private Flux<CapitalCallDocument> fetchBufferedCapitalCalls(
      Set<Long> bufferedAccountIds,
      User user,
      CapitalCallDateFilterType filterType,
      LocalDate startDate,
      LocalDate endDate) {
    return capitalCalls
        .getCapitalCallsByAccounts(
            filterType,
            startDate,
            endDate,
            bufferedAccountIds,
            Set.of(
                WIRE_CHECK,
                INITIAL_REVIEW,
                FINAL_REVIEW,
                COMPLETED,
                BLACKLISTED,
                WIRE_CHECK_REJECTED))
        .buffer(BUFFER_SIZE)
        .concatMap(capitalCallBankAccountVerifierService::verifyAndSetBufferedNewBankAccountFlag)
        .buffer(BUFFER_SIZE)
        .concatMap(
            batch ->
                capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(
                    batch, user.getEmail()))
        .doOnComplete(
            () -> log.info("Successfully fetched capital calls for user ID {}", user.getId()))
        .doOnError(
            error ->
                log.error(
                    "Failed to fetch capital calls for user ID {}. Error: {}",
                    user.getId(),
                    ExceptionUtils.getStackTraceAsString(error)));
  }
}
