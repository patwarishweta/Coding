package com.cwan.privatefund.watchlist;

import com.cwan.privatefund.watchlist.model.Watchlist;
import com.cwan.privatefund.watchlist.model.WatchlistRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/watchlist")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class WatchlistController {

  private final WatchlistService watchlistService;

  public WatchlistController(WatchlistService watchlistService) {
    this.watchlistService = watchlistService;
  }

  // adding new security to watchlist
  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add watchlist security")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added watchlist security successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Watchlist.class))
            })
      })
  public Flux<Watchlist> addWatchlistEntry(
      @Parameter(description = "Watchlist Data") @RequestBody WatchlistRequest request) {
    return watchlistService.addWatchlistEntries(request.getWatchlistInfo());
  }

  @PutMapping
  @ResponseStatus(HttpStatus.ACCEPTED)
  @Operation(summary = "Update watchlist security")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "watchlist security successfully updated",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Watchlist.class))
            })
      })
  public Flux<Watchlist> updateWatchlistEntry(
      @Parameter(description = "Watchlist Data") @RequestBody WatchlistRequest request) {
    return watchlistService.updateWatchlistEntries(request.getWatchlistInfo());
  }

  // retreiving watchlist entries to display
  @RequestMapping(value = "/account/{accountId}", method = RequestMethod.GET)
  @Operation(summary = "get watchlist entries by account id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Watchlist.class))
            })
      })
  public Flux<Watchlist> getCommentsByAccountId(@PathVariable("accountId") Long accountId) {
    return watchlistService.getEntriesByAccountId(accountId);
  }

  @DeleteMapping
  @Operation(summary = "Delete watchlist entry")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "watchlist entry deleted successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Watchlist.class))
            })
      })
  public void deleteCommentsById(
      @Parameter(description = "watchlist ids") @RequestParam Set<Long> ids) {
    watchlistService.deleteEntriesById(ids);
  }
}
