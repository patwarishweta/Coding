package com.cwan.privatefund.capital.call.management.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankAccountResponse(
    String bankAccountUuid,
    String bankUuid,
    String bankName,
    Long accountId,
    String accountName,
    String accountNumber,
    String iban,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdAt,
    String creatorName,
    String creatorEmail)
    implements Serializable {

  public static class BankAccountResponseBuilder {

    public BankAccountResponse.BankAccountResponseBuilder bankAccountUuid(String bankAccountUuid) {
      this.bankAccountUuid = StringUtils.trimToNull(StringUtils.normalizeSpace(bankAccountUuid));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder bankUuid(String bankUuid) {
      this.bankUuid = StringUtils.trimToNull(StringUtils.normalizeSpace(bankUuid));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder bankName(String bankName) {
      this.bankName = StringUtils.trimToNull(StringUtils.normalizeSpace(bankName));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder accountName(String accountName) {
      this.accountName = StringUtils.trimToNull(StringUtils.normalizeSpace(accountName));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder accountNumber(String accountNumber) {
      this.accountNumber = StringUtils.trimToNull(StringUtils.normalizeSpace(accountNumber));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder iban(String iban) {
      this.iban = StringUtils.trimToNull(StringUtils.normalizeSpace(iban));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder creatorName(String creatorName) {
      this.creatorName = StringUtils.trimToNull(StringUtils.normalizeSpace(creatorName));
      return this;
    }

    public BankAccountResponse.BankAccountResponseBuilder creatorEmail(String creatorEmail) {
      this.creatorEmail = StringUtils.trimToNull(StringUtils.normalizeSpace(creatorEmail));
      return this;
    }
  }
}
