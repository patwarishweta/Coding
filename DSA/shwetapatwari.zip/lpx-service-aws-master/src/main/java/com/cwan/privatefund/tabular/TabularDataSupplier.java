package com.cwan.privatefund.tabular;

import com.ca.ws.Field;
import com.ca.ws.TabularFieldDataSupplier;
import com.cwan.lpx.client.tabular.LPBalanceField;
import com.cwan.lpx.client.tabular.LPTransactionField;
import java.util.List;
import java.util.stream.Collectors;

public class TabularDataSupplier implements TabularFieldDataSupplier {

  private final List<Field> header;
  private final List<Iterable<Object>> data;

  private TabularDataSupplier(List<Field> header, List<Iterable<Object>> data) {
    this.data = data;
    this.header = header;
  }

  public static TabularDataSupplier createBalanceDataSupplier(
      List<Integer> header, List<Iterable<Object>> data) {
    List<Field> balanceHeader =
        header.stream().map(LPBalanceField::fromId).collect(Collectors.toList());
    return new TabularDataSupplier(balanceHeader, data);
  }

  public static TabularDataSupplier createTransactionDataSupplier(
      List<Integer> header, List<Iterable<Object>> data) {
    List<Field> transactionHeader =
        header.stream().map(LPTransactionField::fromId).collect(Collectors.toList());
    return new TabularDataSupplier(transactionHeader, data);
  }

  @Override
  public Iterable<Iterable<Object>> getDataIterator() {
    return this.data;
  }

  @Override
  public Iterable<Field> getHeaderIterator() {
    return this.header;
  }
}
