package com.cwan.privatefund.fxrate.source;

import java.util.Collection;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountFxSourceRepository
    extends JpaRepository<AccountFxSourceEntity, AccountFxSourceKey> {
  Collection<AccountFxSourceEntity> findAllByAccountIdIn(Set<Long> accountIds);
}
