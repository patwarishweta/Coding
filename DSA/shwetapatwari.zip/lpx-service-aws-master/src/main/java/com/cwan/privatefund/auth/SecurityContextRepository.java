package com.cwan.privatefund.auth;

import com.cwan.privatefund.auth.service.AuthenticationService;
import java.util.Set;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.web.server.context.ServerSecurityContextRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class SecurityContextRepository implements ServerSecurityContextRepository {

  private final Set<AuthenticationService> authServices;

  public SecurityContextRepository(Set<AuthenticationService> authServices) {
    this.authServices = authServices;
  }

  @Override
  public Mono<Void> save(ServerWebExchange swe, SecurityContext sc) {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Override
  public Mono<SecurityContext> load(ServerWebExchange swe) {
    return Flux.fromIterable(authServices)
        .flatMap(authService -> authService.getAuthentication(swe))
        .filter(Authentication::isAuthenticated)
        .next()
        .map(SecurityContextImpl::new);
  }
}
