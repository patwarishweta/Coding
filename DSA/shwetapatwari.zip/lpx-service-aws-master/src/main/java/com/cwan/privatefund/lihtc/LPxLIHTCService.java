package com.cwan.privatefund.lihtc;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.TaxType;
import com.cwan.pbor.lihtc.api.LIHTCService;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.portfolio.PortfolioService;
import com.cwan.privatefund.security.SecurityService;
import com.google.common.annotations.VisibleForTesting;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class LPxLIHTCService {

  private final AccountService accountService;
  private final SecurityService securityService;
  private final LIHTCService lihtcService;
  private final PortfolioService portfolioService;

  public LPxLIHTCService(
      AccountService accountService,
      SecurityService securityService,
      LIHTCService lihtcService,
      PortfolioService portfolioService) {
    this.accountService = accountService;
    this.securityService = securityService;
    this.lihtcService = lihtcService;
    this.portfolioService = portfolioService;
  }

  public Flux<LIHTCBenefitSchedule> addBenefitSchedules(
      Collection<LIHTCBenefitSchedule> lihtcBenefitSchedules) {
    Set<AccountSecurityPair> schedulesToSubmit = new HashSet<>();
    return lihtcService
        .addBenefitSchedules(lihtcBenefitSchedules)
        .doOnNext(
            benefitSchedule -> {
              AccountSecurityPair pair =
                  new AccountSecurityPair(
                      benefitSchedule.account().getId(),
                      benefitSchedule.security().getSecurityId());
              schedulesToSubmit.add(pair);
            })
        .doOnComplete(
            () -> {
              // Must be a doOnComplete to ensure the entire benefit schedule has been saved to the
              // DB.
              schedulesToSubmit.forEach(
                  accountSecurityPair -> {
                    portfolioService.submitAmortCalculationTask(
                        accountSecurityPair.accountId(), accountSecurityPair.securityId());
                  });
            });
  }

  public Mono<Map<LocalDate, Collection<LIHTCBenefitSchedule>>>
      getBenefitSchedulesForAccountSecurityPair(Long accountId, Long securityId) {
    return benefitScheduleResolveAccountSecurityData(
            lihtcService.getBenefitSchedulesForAccountSecurityPair(accountId, securityId))
        .collectMultimap(LIHTCBenefitSchedule::reportingDate, Function.identity());
  }

  public Mono<Map<LocalDate, Collection<LIHTCBenefitSchedule>>>
      getBenefitSchedulesForAccountSecurityReportingDate(
          Long accountId, Long securityId, LocalDate reportingDate) {
    return benefitScheduleResolveAccountSecurityData(
            lihtcService.getBenefitSchedulesForAccountSecurityForReportingDate(
                accountId, securityId, reportingDate))
        .collectMultimap(LIHTCBenefitSchedule::reportingDate, Function.identity());
  }

  public Mono<Map<LocalDate, Collection<LIHTCBenefitSchedule>>>
      deleteBenefitSchedulesForAccountSecurityTaxType(
          Long accountId, Long securityId, LocalDate reportingDate, TaxType taxType) {
    return lihtcService
        .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
            accountId, securityId, reportingDate, taxType)
        .collectMultimap(LIHTCBenefitSchedule::reportingDate, Function.identity())
        .doOnSuccess(entry -> portfolioService.submitAmortCalculationTask(accountId, securityId));
  }

  public Mono<Map<LocalDate, Collection<LIHTCBenefitSchedule>>>
      deleteBenefitSchedulesForAccountSecurityTaxTypeReportingDateScheduleDate(
          Long accountId,
          Long securityId,
          LocalDate reportingDate,
          TaxType taxType,
          LocalDate scheduleDate) {
    return lihtcService
        .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
            accountId, securityId, reportingDate, taxType, scheduleDate)
        .collectMultimap(LIHTCBenefitSchedule::reportingDate, Function.identity())
        .doOnSuccess(entry -> portfolioService.submitAmortCalculationTask(accountId, securityId));
  }

  @VisibleForTesting
  protected Flux<LIHTCBenefitSchedule> benefitScheduleResolveAccountSecurityData(
      Flux<LIHTCBenefitSchedule> benefitScheduleFlux) {
    return benefitScheduleFlux
        .flatMap(this::addAccountDataToBenefitSchedule)
        .flatMap(this::addSecurityDataToBenefitSchedule);
  }

  @VisibleForTesting
  protected Mono<LIHTCBenefitSchedule> addAccountDataToBenefitSchedule(
      LIHTCBenefitSchedule benefitSchedule) {
    return accountService
        .getAccountData(benefitSchedule.account().getId())
        .map(account -> benefitSchedule.toBuilder().account(account).build());
  }

  @VisibleForTesting
  protected Mono<LIHTCBenefitSchedule> addSecurityDataToBenefitSchedule(
      LIHTCBenefitSchedule benefitSchedule) {
    return securityService
        .getSecurity(
            benefitSchedule.account().getClientId(),
            benefitSchedule.account().getId(),
            benefitSchedule.security().getSecurityId())
        .map(security -> benefitSchedule.toBuilder().security(security).build());
  }

  public Flux<LIHTCTaxRate> addTaxRates(Collection<LIHTCTaxRate> lihtcTaxRates) {
    return lihtcService.addTaxRates(lihtcTaxRates);
  }

  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>> getTaxRatesForAccountSecurityPair(
      Long accountId, Long securityId) {
    return taxRateResolveAccountSecurityData(
            lihtcService.getTaxRatesForAccountSecurityPair(accountId, securityId))
        .collectMultimap(LIHTCTaxRate::taxRateStartDate, Function.identity());
  }

  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>> getTaxRatesForAccountSecurityForTaxType(
      Long accountId, Long securityId, TaxType taxType) {
    return taxRateResolveAccountSecurityData(
            lihtcService.getTaxRatesForAccountSecurityForTaxType(accountId, securityId, taxType))
        .collectMultimap(LIHTCTaxRate::taxRateStartDate, Function.identity());
  }

  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>> deleteTaxRatesForAccountSecurity(
      Long accountId, Long securityId) {
    return lihtcService
        .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(accountId, securityId)
        .collectMultimap(LIHTCTaxRate::taxRateStartDate, Function.identity());
  }

  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>> deleteTaxRatesForAccountSecurityTaxType(
      Long accountId, Long securityId, TaxType taxType) {
    return lihtcService
        .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
            accountId, securityId, taxType)
        .collectMultimap(LIHTCTaxRate::taxRateStartDate, Function.identity());
  }

  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>>
      deleteTaxRatesForAccountSecurityTaxTypeTaxRateStartDate(
          Long accountId, Long securityId, TaxType taxType, LocalDate taxRateStartDate) {
    return lihtcService
        .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
            accountId, securityId, taxType, taxRateStartDate)
        .collectMultimap(LIHTCTaxRate::taxRateStartDate, Function.identity());
  }

  @VisibleForTesting
  protected Flux<LIHTCTaxRate> taxRateResolveAccountSecurityData(Flux<LIHTCTaxRate> taxRateFlux) {
    return taxRateFlux
        .flatMap(this::addAccountDataToTaxRate)
        .flatMap(this::addSecurityDataToTaxRate);
  }

  @VisibleForTesting
  protected Mono<LIHTCTaxRate> addAccountDataToTaxRate(LIHTCTaxRate taxRate) {
    if (taxRate.account().getId() == -1) {
      return Mono.just(taxRate);
    } else {
      return accountService
          .getAccountData(taxRate.account().getId())
          .map(account -> taxRate.toBuilder().account(account).build());
    }
  }

  @VisibleForTesting
  protected Mono<LIHTCTaxRate> addSecurityDataToTaxRate(LIHTCTaxRate taxRate) {
    if (taxRate.account().getId() == -1) {
      return Mono.just(taxRate);
    } else {
      return securityService
          .getSecurity(
              taxRate.account().getClientId(),
              taxRate.account().getId(),
              taxRate.security().getSecurityId())
          .map(security -> taxRate.toBuilder().security(security).build());
    }
  }

  public Set<ManualAmortSegment> getManualAmortSegments(
      long accountId, long securityId, int basisId) {
    return lihtcService.getSegments(accountId, securityId, basisId);
  }

  public void updateManualAmortSegments(
      Set<ManualAmortSegment> segments, boolean invalidateExistingEntities) {
    if (invalidateExistingEntities) {
      Set<ManualAmortSegment> entitiesToDeactivate = new HashSet<>();
      segments.stream()
          .map(
              segment ->
                  new ManualAmortSegmentKey(
                      new AccountSecurityPair(segment.accountId(), segment.securityId()),
                      segment.basisId()))
          .distinct()
          .forEach(
              key -> {
                entitiesToDeactivate.addAll(
                    lihtcService.getSegments(
                        key.accountSecurityPair.accountId(),
                        key.accountSecurityPair.securityId(),
                        key.basisId()));
              });

      // flip active flag to false
      lihtcService.saveManualAmortSegments(
          entitiesToDeactivate.stream()
              .map(c -> c.toBuilder().isActive(false).build())
              .collect(Collectors.toSet()));
    }
    lihtcService.saveManualAmortSegments(segments);

    segments.stream()
        .map(segment -> new AccountSecurityPair(segment.accountId(), segment.securityId()))
        .distinct()
        .forEach(
            pair ->
                portfolioService.submitAmortCalculationTask(pair.accountId(), pair.securityId()));
  }

  private record AccountSecurityPair(Long accountId, Long securityId) {}

  private record ManualAmortSegmentKey(AccountSecurityPair accountSecurityPair, int basisId) {}
}
