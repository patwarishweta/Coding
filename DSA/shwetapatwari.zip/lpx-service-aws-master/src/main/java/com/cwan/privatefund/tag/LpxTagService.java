package com.cwan.privatefund.tag;

import com.cwan.lpx.domain.Tag;
import com.cwan.pbor.tag.TagEntity;
import com.cwan.pbor.tag.TagTransformer;
import java.util.Collection;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class LpxTagService {

  private final LpxTagRepository lpxTagRepository;
  private final TagTransformer tagTransformer;

  public LpxTagService(LpxTagRepository lpxTagRepository, TagTransformer tagTransformer) {
    this.lpxTagRepository = lpxTagRepository;
    this.tagTransformer = tagTransformer;
  }

  public Flux<Tag> getAllByDocumentId(Long documentId) {
    try {
      return Flux.fromIterable(lpxTagRepository.findAllByDocumentId(documentId))
          .map(tagTransformer);
    } catch (RuntimeException e) {
      throw new TagException(
          HttpStatus.INTERNAL_SERVER_ERROR, "Error getting tags by document id", e);
    }
  }

  public Flux<Tag> getAllByTag(String tag) {
    try {
      return Flux.fromIterable(lpxTagRepository.findAllByTagContainingIgnoreCase(tag))
          .map(tagTransformer);
    } catch (RuntimeException e) {
      throw new TagException(
          HttpStatus.INTERNAL_SERVER_ERROR, "Error getting tags by given tag", e);
    }
  }

  @Transactional
  public Flux<Tag> updateTagsForDocumentId(Long documentId, Set<String> tags) {
    Collection<TagEntity> tagEntities =
        tags.stream()
            .map(tag -> TagEntity.builder().documentId(documentId).tag(tag).build())
            .collect(Collectors.toList());
    deleteTagsForDocumentId(documentId);
    return saveTags(tagEntities);
  }

  @Transactional
  public void deleteTagsForDocumentId(Long documentId) {
    lpxTagRepository.deleteAllByDocumentId(documentId);
  }

  protected Flux<Tag> saveTags(Collection<TagEntity> tags) {
    return Flux.fromIterable(tags)
        .filter(Objects::nonNull)
        .map(lpxTagRepository::saveAndFlush)
        .map(
            tagEntity -> {
              log.info("Tag saved in pabor db with id " + tagEntity.getId());
              return tagTransformer.apply(tagEntity);
            });
  }
}
