package com.cwan.privatefund.security;

import com.cwan.privatefund.client.WebResponseMapper;
import com.cwan.privatefund.client.WsClientStatus;
import com.cwan.privatefund.security.model.SecurityRequest;
import com.cwan.privatefund.security.model.SecurityResponse;
import java.net.UnknownHostException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class SecurityClient {

  private final WebClient securityWebClient;

  public SecurityClient(
      WebClient securityWebClient, WebResponseMapper<SecurityException> securityResponseMapper) {
    this.securityWebClient = securityWebClient;
  }

  public Mono<List<SecurityResponse>> getSecurityInformation(SecurityRequest req) {
    return securityWebClient
        .post()
        .uri("/security-data/simple")
        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
        .body(Mono.just(req), SecurityRequest.class)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res, "SecurityWsClient getSecurityInformation 4xxClientError req: " + req))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res, "SecurityWsClient getSecurityInformation is5xxServerError req: : " + req))
        .bodyToMono(new ParameterizedTypeReference<List<SecurityResponse>>() {})
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response getSecurityInformation, desired service not present :: UnknownHostException {}",
                    e);
              } else {
                log.error(
                    "Failed to get response getSecurityInformation for Request:{} Exception:{}",
                    req,
                    e);
              }
              return Mono.empty();
            });
  }
}
