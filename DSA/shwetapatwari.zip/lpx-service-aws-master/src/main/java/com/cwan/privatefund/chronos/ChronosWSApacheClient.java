package com.cwan.privatefund.chronos;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.PostRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ChronosWSApacheClient {

  private final WsHttpClient wsHttpClient;
  private final Resource lockDownResource;
  private final AuthTokenCore authTokenCore;

  public ChronosWSApacheClient(
      WsHttpClient wsHttpClient,
      ServerConfiguration serverConfiguration,
      AuthTokenCore authTokenCore) {
    this.wsHttpClient = wsHttpClient;
    this.authTokenCore = authTokenCore;
    this.lockDownResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("dates/lockdowns/v3.5/next")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public Map<String, LockdownAccountDetails> getLatestLockdownDateForAccounts(
      Collection<Long> accountIds) {
    PostRequest request =
        lockDownResource
            .doPOST(wsHttpClient)
            .withHeader("Authorization", "Bearer " + authTokenCore.createApplicationToken())
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addFormParams(
                "aid",
                accountIds.stream().map(accountId -> "1:" + accountId).collect(Collectors.toSet()))
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error("Chronos getLatestLockdownDateForAccounts: {}", accountIds, e);
      throw new RuntimeException("Failed to get latest lockdown date for accounts", e);
    }
  }

  public record LockdownAccountDetails(LockdownData currentLockdownData) {}

  public record LockdownData(@JsonFormat(pattern = "MM/dd/yyyy") LocalDate lockdownDate) {}
}
