package com.cwan.privatefund.directory;

import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class DirectoryTransformer implements Function<DirectoryEntity, Directory> {

  @Override
  public Directory apply(DirectoryEntity directoryEntity) {
    return Directory.builder()
        .id(directoryEntity.getId())
        .name(directoryEntity.getName())
        .parentDirectoryId(directoryEntity.getParentDirectoryId())
        .accountId(directoryEntity.getAccountId())
        .isDisabled(directoryEntity.getIsDisabled())
        .build();
  }
}
