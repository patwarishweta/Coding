package com.cwan.privatefund.transaction.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AwsTransaction {

  private Integer awsActivityTypeId;
  private Integer awsBalanceFieldId;
  private Long securityId;
  private Double amount;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate date;

  private String source;
  private String originalTransactionType;
}
