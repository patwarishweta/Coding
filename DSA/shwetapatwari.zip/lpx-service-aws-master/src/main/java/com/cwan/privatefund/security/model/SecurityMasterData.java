package com.cwan.privatefund.security.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityMasterData implements Serializable {

  @Serial private static final long serialVersionUID = 2511226059581050962L;

  @JsonProperty("Cusip")
  private String cusip;

  @JsonProperty("ID")
  private Long id;

  @JsonProperty("Name")
  private String name;

  @JsonProperty("CurrencyID")
  private Long currencyId;

  @JsonProperty("CurrencyCode")
  private String currencyCode;
}
