package com.cwan.privatefund.portfolio.model;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Collection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
public class PortfolioData implements Serializable {

  @Serial private static final long serialVersionUID = 2109664894401131775L;
  private Long accountId;
  private Long securityId;
  @EqualsAndHashCode.Exclude private Collection<Ranges> ranges;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  @Getter
  public static class Ranges implements Serializable {

    @Serial private static final long serialVersionUID = -8356488915664599890L;
    private LocalDate atLeast;
    private LocalDate lessThan;
  }
}
