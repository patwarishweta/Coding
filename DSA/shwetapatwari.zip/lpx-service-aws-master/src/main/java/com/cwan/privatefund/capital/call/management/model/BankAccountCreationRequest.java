package com.cwan.privatefund.capital.call.management.model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankAccountCreationRequest(
    @NotBlank(message = "Bank UUID cannot be blank")
        @Size(max = 36, message = "Bank UUID cannot exceed 36 characters")
        String bankUuid,
    @NotNull(message = "Account ID cannot be null")
        @Min(value = 1, message = "Account ID must be greater than 0")
        Long accountId,
    @NotBlank(message = "Account name cannot be blank")
        @Size(max = 500, message = "Account name cannot exceed 500 characters")
        String accountName,
    @Size(max = 100, message = "Account number cannot exceed 100 characters") String accountNumber,
    @Size(max = 150, message = "IBAN cannot exceed 150 characters") String iban)
    implements Serializable {

  public static class BankAccountCreationRequestBuilder {

    public BankAccountCreationRequest.BankAccountCreationRequestBuilder bankUuid(String bankUuid) {
      this.bankUuid = StringUtils.trimToNull(StringUtils.normalizeSpace(bankUuid));
      return this;
    }

    public BankAccountCreationRequest.BankAccountCreationRequestBuilder accountName(
        String accountName) {
      this.accountName = StringUtils.trimToNull(StringUtils.normalizeSpace(accountName));
      return this;
    }

    public BankAccountCreationRequest.BankAccountCreationRequestBuilder accountNumber(
        String accountNumber) {
      this.accountNumber = StringUtils.trimToNull(StringUtils.normalizeSpace(accountNumber));
      return this;
    }

    public BankAccountCreationRequest.BankAccountCreationRequestBuilder iban(String iban) {
      this.iban = StringUtils.trimToNull(StringUtils.normalizeSpace(iban));
      return this;
    }
  }
}
