package com.cwan.privatefund.salesforce.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
public class SoapEnvelopeService {

  public String generateSoapEnvelope(
      String token, String emailAddresses, String subject, String htmlMessage, String caseId)
      throws IOException {
    Resource resource = new ClassPathResource("soap-envelope-template.xml");
    String soapEnvelope;
    try (var inputStream = resource.getInputStream();
        var reader =
            new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
      var sb = new StringBuilder();
      String line;
      while ((line = reader.readLine()) != null) {
        sb.append(line);
      }
      soapEnvelope = sb.toString();
    }
    // Building multiple <urn:toAddresses> tags in the XML file present in the resource
    var bccAddressesXml = generateEmailAddressXml("bccAddresses", emailAddresses);
    return String.format(soapEnvelope, token, bccAddressesXml, subject, htmlMessage, caseId);
  }

  private String generateEmailAddressXml(String tag, String emailAddresses) {
    var sb = new StringBuilder();
    var emails = emailAddresses.split(",");
    for (String email : emails) {
      sb.append(String.format("<urn:%s>%s</urn:%s>", tag, email.trim(), tag));
    }
    return sb.toString();
  }
}
