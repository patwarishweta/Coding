package com.cwan.privatefund.auth.ws;

import com.cwan.privatefund.auth.AuthenticationException;
import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.cwan.privatefund.client.WebResponseMapper;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AuthWSConfig {

  @Value("${auth.ws.base.url}")
  private String authWSBaseUrl;

  @Value("${session.cache.maxsize}")
  private Integer maxCacheSize;

  @Value("${session.cache.timeout.minutes}")
  private Integer cacheDurationMinutes;

  @Bean(value = "authWebClient")
  WebClient authWebClient(ReactorClientHttpConnector reactorClientHttpConnector) {
    return WebClient.builder()
        .baseUrl(authWSBaseUrl)
        .clientConnector(reactorClientHttpConnector)
        .build();
  }

  @Bean(value = "sessionValidCache")
  Cache<SessionValidRequest, Boolean> sessionValidCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationMinutes, TimeUnit.MINUTES)
        .build();
  }

  @Bean(value = "authResponseMapper")
  WebResponseMapper<AuthenticationException> authResponseMapper() {
    return new WebResponseMapper<>() {
      @Override
      protected AuthenticationException getException(String msg) {
        return new AuthenticationException(msg);
      }
    };
  }
}
