package com.cwan.privatefund.watchlist.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@EqualsAndHashCode
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "watchlist", catalog = "pabor")
public class WatchlistEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long securityId;
  private Long accountId;
  private LocalDate startDate;
  private LocalDate endDate;
  private String createdBy;
  private LocalDate tsCreatedOn;
  private String modifiedBy;
  private LocalDate tsModifiedOn;
}
