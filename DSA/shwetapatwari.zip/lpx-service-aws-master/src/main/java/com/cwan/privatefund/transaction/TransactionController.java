package com.cwan.privatefund.transaction;

import static com.cwan.privatefund.constant.Constants.EntityActions.CANCEL;

import com.cwan.lpx.domain.Transaction;
import com.cwan.lpx.domain.TransactionIdentifier;
import com.cwan.lpx.domain.TransactionSubType;
import com.cwan.lpx.domain.TransactionType;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.pbor.trans.identifiers.TransactionIdentifierService;
import com.cwan.privatefund.constant.Constants;
import com.cwan.privatefund.publisher.MessagePublisher;
import com.cwan.privatefund.transaction.model.AwsTransaction;
import com.cwan.privatefund.transaction.model.TransactionRequest;
import com.google.common.collect.Lists;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/transactions")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class TransactionController {

  private final LpxTransactionService lpxTransactionService;
  private final Transactions transactions;
  private final MessagePublisher<Transaction> transactionMessagePublisher;
  private final TransactionIdentifierService transactionIdentifierService;

  public TransactionController(
      LpxTransactionService lpxTransactionService,
      Transactions transactions,
      MessagePublisher<Transaction> transactionMessagePublisher,
      TransactionIdentifierService transactionIdentifierService) {
    this.lpxTransactionService = lpxTransactionService;
    this.transactions = transactions;
    this.transactionMessagePublisher = transactionMessagePublisher;
    this.transactionIdentifierService = transactionIdentifierService;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add transaction")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added Transaction successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Mono<ResponseEntity<Object>> addTransaction(
      @Parameter(description = "Transaction Data") @RequestBody TransactionRequest request,
      @RequestParam(required = false) Integer userId,
      @RequestParam(required = false, defaultValue = "false") Boolean validation) {
    log.info("addTransaction API called {} -> {}", userId, validation);
    if (Boolean.TRUE.equals(validation)) {
      if (userId == null) {
        return Mono.just(
            ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(List.of("BAD REQUEST: userId is mandatory if validation flag is true")));
      }
      return lpxTransactionService
          .validateOpeningTransactions(userId, request.getTransactions())
          .flatMap(
              errorResponse -> {
                if (errorResponse.getResponse() != null && !errorResponse.getResponse().isEmpty()) {
                  return Mono.just(
                      ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
                          .body(errorResponse.getResponse()));
                } else {
                  transactionMessagePublisher.publishMessageCollection(request.getTransactions());
                  return Mono.just(
                      ResponseEntity.status(HttpStatus.OK)
                          .body(List.of("Transactions Published Successfully")));
                }
              });
    } else {
      transactionMessagePublisher.publishMessageCollection(request.getTransactions());
      return Mono.just(
          ResponseEntity.status(HttpStatus.OK)
              .body(List.of("Transactions Published Successfully")));
    }
  }

  @GetMapping
  @Operation(summary = "Get transactions")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Transaction> getTransactionInfoById(
      @Parameter(description = "Transaction Ids") @RequestParam Set<Long> ids) {
    return lpxTransactionService.getTransactionsByIds(ids);
  }

  @DeleteMapping
  @Operation(summary = "Delete transactions")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "transactions deleted successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Mono<Void> deleteTransactionById(
      @Parameter(description = "transactions") @RequestBody TransactionRequest transactionRequest) {
    var deletedTransactions =
        transactionRequest.getTransactions().stream()
            .filter(transaction -> transaction.getId() != null)
            .map(transaction -> transaction.toBuilder().action(CANCEL).build())
            .collect(Collectors.toList());
    log.info("Transactions to delete size - {}", deletedTransactions.size());
    if (!deletedTransactions.isEmpty()) {
      transactionMessagePublisher.publishMessageCollection(deletedTransactions);
    }
    return Mono.empty();
  }

  @DeleteMapping(value = "/deactivate")
  @Operation(summary = "Deactivate transactions")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "transactions deactivated successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Integer> deactivateTransactionById(
      @Parameter(description = "transactions") @RequestBody Set<Long> transactionIds,
      @RequestParam(value = "useremail", required = false) String useremail) {

    log.info("Total Transaction to be deleted {}", transactionIds.size());
    return Mono.just(transactionIds)
        .map(txnIds -> Lists.partition(List.copyOf(txnIds), 500))
        .flatMapIterable(Function.identity())
        .flatMap(
            txnIds ->
                lpxTransactionService
                    .getTransactionsByIds(Set.copyOf(txnIds))
                    .filter(transaction -> !CANCEL.equalsIgnoreCase(transaction.getAction()))
                    .map(
                        transaction ->
                            transaction.toBuilder()
                                .action(CANCEL)
                                .modifiedBy(useremail)
                                .modifiedOn(LocalDateTime.now())
                                .build())
                    .groupBy(transaction -> Boolean.TRUE.equals(transaction.getIsHistoric())))
        .flatMap(
            groupedFlux -> {
              if (groupedFlux.key()) {
                return groupedFlux
                    .collectList()
                    .map(txns -> Lists.partition(txns, 200))
                    .flatMapIterable(Function.identity())
                    .map(
                        txns ->
                            transactions.updateTransactionInfoNonReactive(null, Set.copyOf(txns)))
                    .map(
                        txns -> {
                          log.info(
                              "Total Transaction Deactivated directly from API {}", txns.size());
                          return txns.size();
                        });
              } else {
                return groupedFlux
                    .collectList()
                    .map(txns -> Lists.partition(txns, 100))
                    .flatMapIterable(Function.identity())
                    .map(
                        txns -> {
                          log.info("Total Transaction published for deletion {}", txns.size());
                          transactionMessagePublisher.publishMessageCollection(txns);
                          return txns.size();
                        });
              }
            });
  }

  @PutMapping
  @Operation(summary = "Update transactions")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "transactions updated successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Mono<Void> updateTransactionInfo(
      @Parameter(description = "transaction update request") @RequestBody
          TransactionRequest transactionRequest) {
    transactionMessagePublisher.publishMessageCollection(transactionRequest.getTransactions());
    return Mono.empty();
  }

  @GetMapping(value = "/document/{documentId}")
  @Operation(summary = "get transactions by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Transaction> getTransactionsByDocumentId(
      @PathVariable("documentId") Long documentId,
      @RequestParam(value = "offset", required = false) boolean offset) {
    if (offset) {
      return lpxTransactionService.getTransactionsByDocumentId(documentId);
    }
    return lpxTransactionService.getTransactionsByDocumentIdAndTypeNotIn(
        documentId, List.of(Constants.OFFSET_TRANSACTION_TYPE));
  }

  @GetMapping(value = "/account")
  @Operation(
      summary = "get account transactions by account id, begin date, end date, and knowledge date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Transaction> getAccountTransactions(
      @RequestParam("accountId") Long accountId,
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate,
      @RequestParam(value = "offset", required = false) boolean offset) {
    return lpxTransactionService.getAccountLiveTransactions(
        accountId, beginDate, endDate, knowledgeDate, offset, false);
  }

  @GetMapping(value = "/types")
  @Operation(summary = "get all transaction types")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = TransactionType.class))
            })
      })
  public Flux<TransactionType> getTransactionTypes() {
    return lpxTransactionService.getAllTransactionTypes();
  }

  @GetMapping(value = "/sub-types")
  @Operation(summary = "get all transaction sub types")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = TransactionSubType.class))
            })
      })
  public Flux<TransactionSubType> getTransactionSubTypes() {
    return lpxTransactionService.getAllTransactionSubTypes();
  }

  @GetMapping(value = "/audit")
  @Operation(summary = "get audit transactions by account ids, begin date end date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Transaction> getAuditTransactions(
      @RequestParam("accountIds") Set<Long> accountIds,
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
    return lpxTransactionService.getAllTransactionsByAccountAndDateRange(
        accountIds, beginDate, endDate);
  }

  @GetMapping(value = "/historic")
  @Operation(summary = "get historic transactions by account ids, begin date end date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Transaction> getHistoricTransactions(
      @RequestParam("accountId") Set<Long> accountIds,
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    return lpxTransactionService.getHistoricTransactions(
        accountIds, beginDate, endDate, knowledgeDate);
  }

  @GetMapping(value = "/accounting")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get aws activity")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Aws activities fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<AwsTransaction> getAwsActivity(
      @RequestParam("accountId") Long accountId,
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate beginDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    return lpxTransactionService.getAwsActivity(accountId, beginDate, endDate, knowledgeDate, true);
  }

  @GetMapping(value = "/load")
  @Operation(summary = "Get opening/load transactions by account ids")
  public Flux<Transaction> getLoadTransactions(@RequestParam("accountId") Long accountId) {
    return lpxTransactionService.getOpeningTransactionsByAccountIds(accountId);
  }

  @GetMapping(value = "/date/{date}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get all transactions modified on a particular date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Transactions modified on the given date fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<Transaction> getAllTransactionsModifiedOnDate(
      @PathVariable("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate providedDate) {
    return lpxTransactionService.getAllTransactionsModifiedOnDate(providedDate);
  }

  @GetMapping(value = "/ownership")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Returns true if one of ownership percentage/rule id exists")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Boolean> getOwnershipOrRule(
      @RequestParam("accountId") Long accountId, @RequestParam("securityId") Long securityId) {
    return lpxTransactionService.checkIfOwnershipRuleIdExists(accountId, securityId);
  }

  @GetMapping(value = "/identifiers")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Returns transaction identifier mapped with txnId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Map<Long, List<TransactionIdentifier>>> getTransactionIdentifiers(
      @RequestParam("transactionIds") List<Long> transactionIds) {

    return Flux.fromIterable(transactionIds)
        .flatMap(
            txnId -> transactionIdentifierService.getTransactionExternalIdentifiersByTxnId(txnId))
        .collectMultimap(TransactionIdentifier::getTransactionId)
        .map(
            longCollectionMap ->
                longCollectionMap.entrySet().stream()
                    .collect(
                        Collectors.toMap(
                            Entry::getKey,
                            longCollectionEntry ->
                                longCollectionEntry.getValue().stream()
                                    .sorted(
                                        Comparator.comparing(TransactionIdentifier::getCreatedOn)
                                            .reversed())
                                    .collect(Collectors.toList()))));
  }
}
