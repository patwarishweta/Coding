package com.cwan.privatefund.documentmanager;

public enum DocumentUploadStatus {
  SUCCESS,
  FAILED
}
