package com.cwan.privatefund.redis;

import com.cwan.privatefund.capital.call.scheduling.CapitalCallScheduledService;
import com.cwan.privatefund.constant.RedisConstants;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Slf4j
@Service
public class ScheduledRedisEvictionCacheService {

  private final CapitalCallScheduledService capitalCallScheduledService;
  private final RedisTemplate<String, Object> redisTemplate;

  public ScheduledRedisEvictionCacheService(
      CapitalCallScheduledService capitalCallScheduledService,
      RedisTemplate<String, Object> redisTemplate) {
    this.capitalCallScheduledService = capitalCallScheduledService;
    this.redisTemplate = redisTemplate;
  }

  @Scheduled(cron = "0 0 6 * * *")
  public void securityCache() {
    log.info("Scheduled Job triggered to clean up cache");
    capitalCallScheduledService.executeScheduledTask(
        "cleanUpSecurityCache",
        () -> {
          cleanupSecurityCache();
          cleanUpBusinessWsCache();
          cleanUpPortfolioDataCache();
          return Flux.empty();
        });
  }

  private void cleanUpBusinessWsCache() {
    clearCacheByName(RedisConstants.BUSINESS_ACCOUNT_DATA_CACHE, 1000);
    clearCacheByName(RedisConstants.BUSINESS_USER_DETAILS_CACHE, 10000);
    clearCacheByName(RedisConstants.BUSINESS_CLIENT_DATA_CACHE, 20000);
    clearCacheByName(RedisConstants.BUSINESS_EXPANDED_ACCOUNTS_CACHE, 30000);
    clearCacheByName(RedisConstants.BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE, 40000);
    clearCacheByName(RedisConstants.BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE, 50000);
    clearCacheByName(RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID, 60000);
    clearCacheByName(RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_CLIENT_ID, 70000);
  }

  private void cleanUpPortfolioDataCache() {
    clearCacheByName(RedisConstants.PORTFOLIO_ACCOUNT_SECURITY_CACHE, 100);
  }

  private void cleanupSecurityCache() {
    clearCacheByName(RedisConstants.SECURITY, 1);
  }

  public void clearCacheByName(String cacheName, long timeout) {
    log.info("Clean up {} cache in {} ms", cacheName, timeout);
    redisTemplate.expire(cacheName, timeout, TimeUnit.MILLISECONDS);
  }

  public int getCacheSize(String cacheName) {
    int size = redisTemplate.opsForHash().values(cacheName).size();
    log.info("{} Cache size is {}", cacheName, size);
    return size;
  }
}
