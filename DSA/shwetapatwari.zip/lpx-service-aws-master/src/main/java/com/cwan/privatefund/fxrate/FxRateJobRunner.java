package com.cwan.privatefund.fxrate;

import com.ca.util.date.localdate.LocalDateRange;
import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.fxrate.api.FXRates;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import com.cwan.privatefund.fxrate.source.AccountFxSourceService;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.security.currency.SecurityCurrencyService;
import com.cwan.privatefund.security.model.SecurityCurrency;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class FxRateJobRunner {

  private final AccountConfigServiceCache accountConfigServiceCache;
  private final AverageFxRateCalculator averageFxRateCalculator;
  private final Transactions transactions;
  private final BusinessWSCache businessWSCache;
  private final SecurityService securityService;
  private final LpxFxRateService lpxFxRateService;
  private final FXRates fxRates;
  private final LpxFundMasterService lpxFundMasterService;
  private final SecurityCurrencyService securityCurrencyService;
  private final FxServiceApacheClient fxServiceApacheClient;
  private final AccountFxSourceService accountFxSourceService;
  // Technically we are calculating "average" fx rates and not "blended" fx rates, but this is the
  // feature name
  protected static final String AVERAGE_FX_RATE_START_DATE = "blendedFxRateStartDate";

  public FxRateJobRunner(
      AccountConfigServiceCache accountConfigServiceCache,
      AverageFxRateCalculator averageFxRateCalculator,
      Transactions transactions,
      BusinessWSCache businessWSCache,
      SecurityService securityService,
      LpxFxRateService lpxFxRateService,
      FXRates fxRates,
      LpxFundMasterService lpxFundMasterService,
      SecurityCurrencyService securityCurrencyService,
      FxServiceApacheClient fxServiceApacheClient,
      AccountFxSourceService accountFxSourceService) {
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.averageFxRateCalculator = averageFxRateCalculator;
    this.transactions = transactions;
    this.businessWSCache = businessWSCache;
    this.securityService = securityService;
    this.lpxFxRateService = lpxFxRateService;
    this.fxRates = fxRates;
    this.lpxFundMasterService = lpxFundMasterService;
    this.securityCurrencyService = securityCurrencyService;
    this.fxServiceApacheClient = fxServiceApacheClient;
    this.accountFxSourceService = accountFxSourceService;
  }

  // Calculates and stores any fx rate that meets the following criteria:
  // (1) Has a base currency that is attached to an account that is enabled for average fx rate
  // calculation
  // (2) Has a local currency / reporting frequency that is attached to a security that is
  // associated with the enabled account in our system (we use transactions to determine this)
  // (3) Has a date that is not in the future, and is after/on the start date for the feature
  // (4) Is not already stored in the database
  public void runDailyFxRateJob() {
    log.info("FX Rate Job: Daily job has been started");
    getAccountToStartDateMap()
        .subscribe(
            accountToStartDateMap -> {
              log.info(
                  "FX Rate Job: Found {} enabled accounts", accountToStartDateMap.keySet().size());
              Map<Long, Set<Long>> accountToSecurityIdsMap =
                  getAccountToSecurityIdsMap(accountToStartDateMap.keySet());
              log.info("FX Rate Job: Loaded security ids for accounts");
              runFxRateJobForAccounts(accountToStartDateMap, accountToSecurityIdsMap, false);
            });
  }

  private void runFxRateJobForAccounts(
      Map<Long, LocalDate> accountToStartDateMap,
      Map<Long, Set<Long>> accountToSecurityIdsMap,
      boolean forceRecalculate) {
    Set<Long> accountIds = accountToSecurityIdsMap.keySet();
    businessWSCache
        .getAccountsData(accountIds)
        .subscribe(
            accounts -> {
              log.info("FX Rate Job: Loaded account data from business-ws");
              List<Long> securityIds =
                  accountToSecurityIdsMap.values().stream()
                      .flatMap(Set::stream)
                      .distinct()
                      .toList();
              securityService
                  .getSecurities(null, null, securityIds)
                  .subscribe(
                      securities ->
                          determineFxRateJobsAndRun(
                              securities,
                              accounts,
                              accountToSecurityIdsMap,
                              accountToStartDateMap,
                              forceRecalculate));
            });
  }

  // Calculates and stores all FX rates for a given account and set of securities - if no securities
  // are provided, run for all securities associated with the account in the LPx system. If the FX
  // rate is already in the database, it will be recalculated and stored.
  public void runRecalculationFxRateJob(Long accountId, Set<Long> securityIds) {
    log.info(
        "FX Rate Job: Recalculation job has been started for accountId={}, securityIds={}",
        accountId,
        securityIds);
    getFxRateStartDateForAccount(accountId)
        .subscribe(
            startDate -> {
              if (startDate != null) {
                Map<Long, LocalDate> accountToStartDateMap = Map.of(accountId, startDate);
                Map<Long, Set<Long>> accountToSecurityIdsMap;
                if (securityIds == null || securityIds.isEmpty()) {
                  accountToSecurityIdsMap =
                      getAccountToSecurityIdsMap(accountToStartDateMap.keySet());
                } else {
                  accountToSecurityIdsMap = Map.of(accountId, securityIds);
                }
                runFxRateJobForAccounts(accountToStartDateMap, accountToSecurityIdsMap, true);
              }
            });
  }

  private void determineFxRateJobsAndRun(
      List<Security> securities,
      List<BusinessAccount> accounts,
      Map<Long, Set<Long>> accountToSecurityIdsMap,
      Map<Long, LocalDate> accountToStartDateMap,
      boolean forceRecalculate) {
    log.info("FX Rate Job: Loaded security data from security master");
    Map<Long, Pair<Long, ReportingFrequency>> securityToLocalCurrencyMap =
        createSecurityToLocalCurrencyMap(securities);
    // Save off currency data to allow for quick lookups when AWS requests the data
    log.info("FX Rate Job: Saving security currency data");
    Set<SecurityCurrency> securityCurrencies = saveSecurityCurrencyData(securities);
    log.info("FX Rate Job: Saved {} security currencies to database", securityCurrencies.size());

    Map<Long, Set<BusinessAccount>> baseCurrencyToAccountsMap =
        createBaseCurrencyToAccountsMap(accounts);
    List<FxRateJob> fxRateJobs =
        determineFxRateJobsToRun(
            baseCurrencyToAccountsMap,
            securityToLocalCurrencyMap,
            accountToSecurityIdsMap,
            accountToStartDateMap,
            forceRecalculate);
    log.info("FX Rate Job: Running calculations for {} base currencies", fxRateJobs.size());
    fxRateJobs.forEach(this::runFxRateJob);
    log.info(
        "FX Rate Job: All jobs have completed. {} base currencies were ran", fxRateJobs.size());
  }

  private Set<SecurityCurrency> saveSecurityCurrencyData(Collection<Security> securities) {
    Set<SecurityCurrency> securityCurrencies =
        securities.stream()
            .map(
                security ->
                    SecurityCurrency.builder()
                        .securityId(security.getSecurityId())
                        .currencyId(security.getCurrency().getCurrencyId())
                        .modifiedOn(LocalDateTime.now(ZoneOffset.UTC))
                        .build())
            .collect(Collectors.toSet());
    return securityCurrencyService.saveSecurityCurrencies(securityCurrencies);
  }

  // Calculates and saves any fx rates for the specified base currency + local currencies + date
  // range. If forceRecalculate = false, skip calculating fx rates that are already in the database
  private void runFxRateJob(FxRateJob fxRateJob) {
    log.info("Running FX rate job for {}", fxRateJob);

    for (Long sourceId : fxRateJob.getFxRateSourceIds()) {
      AverageFxRateMap ratesToSkipCalculationFor;
      if (fxRateJob.isForceRecalculate()) {
        ratesToSkipCalculationFor = AverageFxRateMap.build(Set.of());
      } else {
        // If we are not forcing recalculation, skip calculating fx rates that are already in the
        // database
        ratesToSkipCalculationFor =
            lpxFxRateService.getAverageFxRates(fxRateJob.getBaseCurrencyId(), sourceId);
      }

      // For each local currency that is associated with the base currency, generate any missing fx
      // rates
      for (Pair<Long, ReportingFrequency> localCurrency : fxRateJob.getLocalCurrencies()) {
        try {
          // Get a map of fx rates for the local currency that do not need to be recalculated
          Map<LocalDate, Double> ratesToSkipForCurrency =
              ratesToSkipCalculationFor
                  .getRatesForLocalCurrency(localCurrency.getFirst(), localCurrency.getSecond())
                  .entrySet()
                  .stream()
                  // Only want to skip recalculation for fx rates that are in the past
                  // Allow one day buffer to ensure fx rates are populated
                  .filter(entry -> entry.getKey().isBefore(LocalDate.now().minusDays(1)))
                  .collect(Collectors.toMap(Entry::getKey, Entry::getValue));

          Set<FXRate> calculateFxRates =
              calculateFxRates(
                  fxRateJob.getBaseCurrencyId(),
                  sourceId,
                  localCurrency,
                  ratesToSkipForCurrency,
                  fxRateJob.getDateRange());
          Set<FXRate> savedFxRates = fxRates.addFXRates(calculateFxRates);
          log.info(
              "Saved {} FX rates for baseCurrencyId={}, localCurrencyId={}, reportingFrequency={}, sourceId={}",
              savedFxRates.size(),
              fxRateJob.getBaseCurrencyId(),
              localCurrency.getFirst(),
              localCurrency.getSecond(),
              sourceId);
        } catch (Exception e) {
          log.error(
              "Failed to calculate FX rates for baseCurrencyId={}, localCurrency={}, sourceId={}",
              fxRateJob.getBaseCurrencyId(),
              localCurrency,
              sourceId,
              e);
        }
      }
    }
    log.info("Completed saving FX rates for baseCurrencyId={}", fxRateJob.getBaseCurrencyId());
  }

  // Computes and returns any fx rates that are not in the existingRates map
  private Set<FXRate> calculateFxRates(
      Long baseCurrencyId,
      Long sourceId,
      Pair<Long, ReportingFrequency> localCurrency,
      Map<LocalDate, Double> existingRates,
      LocalDateRange dateRange) {
    return StreamSupport.stream(dateRange.spliterator(), false)
        .filter(date -> !existingRates.containsKey(date))
        .map(
            date ->
                averageFxRateCalculator.calculateAverageFxRate(
                    sourceId,
                    baseCurrencyId,
                    localCurrency.getFirst(),
                    localCurrency.getSecond(),
                    date))
        .filter(Objects::nonNull)
        .collect(Collectors.toSet());
  }

  private Mono<LocalDate> getFxRateStartDateForAccount(Long accountId) {
    return accountConfigServiceCache
        .getByAccountId(accountId)
        .map(
            config -> {
              String startDate = config.getAttributes().get(AVERAGE_FX_RATE_START_DATE);
              return startDate != null && !startDate.isEmpty() ? LocalDate.parse(startDate) : null;
            });
  }

  private Mono<Map<Long, LocalDate>> getAccountToStartDateMap() {
    return accountConfigServiceCache
        .getAllAccountConfigs()
        .map(
            configs ->
                configs.stream()
                    .filter(
                        config ->
                            config.getAttributes().get(AVERAGE_FX_RATE_START_DATE) != null
                                && !config
                                    .getAttributes()
                                    .get(AVERAGE_FX_RATE_START_DATE)
                                    .isEmpty())
                    .collect(Collectors.groupingBy(config -> config.getAccount().getId()))
                    .entrySet()
                    .stream()
                    .collect(
                        Collectors.toMap(
                            Entry::getKey,
                            // Protect against multiple account configs for the same accountId
                            entry ->
                                entry.getValue().stream()
                                    .map(
                                        config ->
                                            LocalDate.parse(
                                                config
                                                    .getAttributes()
                                                    .get(AVERAGE_FX_RATE_START_DATE)))
                                    .min(LocalDate::compareTo)
                                    .get())));
  }

  private Map<Long, Set<Long>> getAccountToSecurityIdsMap(Set<Long> accountIds) {
    return transactions.getTransactionsByAccountIdsNonReactive(accountIds).stream()
        .collect(
            Collectors.groupingBy(
                transaction -> transaction.getAccount().getId(),
                Collectors.mapping(
                    transaction -> transaction.getSecurity().getSecurityId(), Collectors.toSet())));
  }

  private Map<Long, Pair<Long, ReportingFrequency>> createSecurityToLocalCurrencyMap(
      Collection<Security> securities) {
    Map<Long, ReportingFrequency> frequencyMap =
        lpxFundMasterService.getReportingFrequencies(
            securities.stream().map(Security::getSecurityId).collect(Collectors.toSet()));
    return securities.stream()
        .filter(sec -> frequencyMap.containsKey(sec.getSecurityId()))
        .collect(
            Collectors.toMap(
                Security::getSecurityId,
                sec ->
                    Pair.of(
                        sec.getCurrency().getCurrencyId(), frequencyMap.get(sec.getSecurityId()))));
  }

  private Map<Long, Set<BusinessAccount>> createBaseCurrencyToAccountsMap(
      Collection<BusinessAccount> accounts) {
    return accounts.stream()
        .collect(
            Collectors.groupingBy(
                BusinessAccount::getFunctionalCurrencyId,
                Collectors.mapping(Function.identity(), Collectors.toSet())));
  }

  // Create a FxRateJob for each baseCurrencyId that may need fx rate data
  private List<FxRateJob> determineFxRateJobsToRun(
      Map<Long, Set<BusinessAccount>> baseCurrencyToAccountsMap,
      Map<Long, Pair<Long, ReportingFrequency>> securityToLocalCurrencyMap,
      Map<Long, Set<Long>> accountToSecurityIdsMap,
      Map<Long, LocalDate> accountToStartDateMap,
      boolean forceRecalculate) {
    return baseCurrencyToAccountsMap.entrySet().stream()
        .map(
            baseCurrencyToAccounts -> {
              Long baseCurrencyId = baseCurrencyToAccounts.getKey();
              Set<BusinessAccount> accountsForCurrency = baseCurrencyToAccounts.getValue();
              Set<AccountFxSource> accountFxSources =
                  accountsForCurrency.stream()
                      .map(BusinessAccount::getId)
                      .map(fxServiceApacheClient::getAccountFxSources)
                      .flatMap(Set::stream)
                      .collect(Collectors.toSet());

              accountFxSourceService.updateFxSources(accountFxSources);
              log.info("FX Rate Job: Updated {} account FX sources", accountFxSources.size());
              // Get all local currencies that the base currency needs average fx rates for
              Set<Pair<Long, ReportingFrequency>> localCurrencies =
                  accountsForCurrency.stream()
                      .map(
                          account ->
                              accountToSecurityIdsMap.getOrDefault(account.getId(), Set.of()))
                      .flatMap(Set::stream)
                      .map(securityToLocalCurrencyMap::get)
                      .filter(Objects::nonNull)
                      .collect(Collectors.toSet());
              if (accountsForCurrency.isEmpty() || localCurrencies.isEmpty()) {
                return null;
              }
              // Have the job run from the earliest feature flag date for the base currency to
              // today's date
              Optional<LocalDate> earliestStartDate =
                  accountsForCurrency.stream()
                      .map(account -> accountToStartDateMap.get(account.getId()))
                      .min(LocalDate::compareTo);
              return FxRateJob.builder()
                  .baseCurrencyId(baseCurrencyId)
                  .localCurrencies(localCurrencies)
                  .fxRateSourceIds(
                      accountFxSources.stream()
                          .map(AccountFxSource::getFxRateSourceId)
                          .collect(Collectors.toSet()))
                  .firstDayToGenerateFor(earliestStartDate.get())
                  .lastDayToGenerateFor(LocalDate.now().plusMonths(1))
                  .forceRecalculate(forceRecalculate)
                  .build();
            })
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }
}
