package com.cwan.privatefund.portfolio;

import com.cwan.lpx.client.tabular.AmountType;
import com.cwan.lpx.domain.Performance;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.portfolio.model.PortfolioSummaryResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/portfolio")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class PortfolioController {

  private final PortfolioService portfolioService;
  private final PortfolioUtilsService portfolioUtilsService;

  PortfolioController(
      PortfolioService portfolioService, PortfolioUtilsService portfolioUtilsService) {
    this.portfolioService = portfolioService;
    this.portfolioUtilsService = portfolioUtilsService;
  }

  @RequestMapping(value = "/performance/metrics/accounts", method = RequestMethod.GET)
  @Operation(summary = "get ")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<PortfolioSummaryResponse> getPortfolioBalances(
      @Parameter(description = "AccountIds") @RequestParam List<Long> accountIds,
      @Parameter(description = "calculationDate")
          @RequestParam("calculationDate")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate calculationDate) {
    return portfolioService.getPortfolioBalances(Set.copyOf(accountIds), calculationDate);
  }

  @RequestMapping(value = "/performance/account/{accountId}/dates", method = RequestMethod.GET)
  @Operation(
      summary = "get performance calculations in bulk for a myriad of dates for a single account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<Performance> getPerformanceCalculationsForDates(
      @PathVariable("accountId") Long accountId,
      @Parameter(
              description =
                  "the frequency of which the data is calculated for (ex: ITD, MTD, QTD, YTD")
          @RequestParam("frequency")
          AmountType frequency,
      @Parameter(description = "Dates to return the calculated datapoints on")
          @RequestParam("calculationDates")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          List<LocalDate> calculationDates) {
    return portfolioService.getPerformancesForDates(
        accountId,
        frequency.name(),
        calculationDates.stream().map(LocalDate::atStartOfDay).collect(Collectors.toSet()));
  }

  @RequestMapping(
      value = "/performance/account/{accountId}/securities/earliest",
      method = RequestMethod.GET)
  @Operation(summary = "get the earliest active performance for each security under an account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<Performance> getEarliestActivePerformancesForAccount(
      @PathVariable("accountId") Long accountId,
      @Parameter(
              description =
                  "the frequency of which the data is calculated for (ex: ITD, MTD, QTD, YTD")
          @RequestParam("frequency")
          AmountType frequency) {
    return portfolioService.getEarliestActivePerformancesForAccount(accountId, frequency.name());
  }

  @RequestMapping(value = "/account/{accountId}/securities", method = RequestMethod.GET)
  @Operation(
      summary = "get a map of accountId to security list for all securities under an account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Map<Long, Collection<Security>>> getAllSecuritiesForAccount(
      @PathVariable("accountId") Long accountId) {
    return portfolioUtilsService.getAllSecuritiesByAccountId(accountId);
  }

  @RequestMapping(value = "/account/securities", method = RequestMethod.GET)
  @Operation(
      summary = "get a map of accountIds to security list for all securities under an account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Map<Long, Collection<Security>>> getAllSecuritiesForAccounts(
      @RequestParam("accountIds") List<Long> accountIds) {
    return Flux.fromIterable(accountIds)
        .flatMap(portfolioService::fetchAllSecuritiesByAccountId)
        .flatMap(entry -> Flux.fromIterable(entry.entrySet()))
        .collectMap(Map.Entry::getKey, Map.Entry::getValue);
  }

  @RequestMapping(value = "/performance/metrics/accounts/refresh", method = RequestMethod.PUT)
  @Operation(summary = "refresh performance based on accountId, calculationDate ")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public void refreshPerformance(
      @Parameter(description = "AccountIds") @RequestParam List<Long> accountIds,
      @Parameter(description = "calculationDate")
          @RequestParam("calculationDate")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate calculationDate,
      @Parameter(description = "frequency, ex: ITD, MTD, QTD, YTD")
          @RequestParam(value = "frequency", required = false)
          AmountType frequency) {
    portfolioService.refreshPerformance(
        accountIds, calculationDate, frequency == null ? AmountType.ITD.name() : frequency.name());
  }

  @RequestMapping(value = "/modified/transactions", method = RequestMethod.GET)
  @Operation(summary = "reload performance for transactions modified today")
  public Mono<String> getModifiedAccountTransactions() {
    portfolioService.reloadPerformanceTillCurrentDate();
    return Mono.just(
        "Job submitted for performance recalculation of old Transactions Modified Today");
  }
}
