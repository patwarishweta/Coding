package com.cwan.privatefund.financialstatement;

import com.cwan.lpx.domain.FinancialStatement;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/financialstatements")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class FinancialStatementController {
  private final FinancialStatementService financialStatementService;

  public FinancialStatementController(FinancialStatementService financialStatementService) {
    this.financialStatementService = financialStatementService;
  }

  @RequestMapping(value = "/ids", method = RequestMethod.GET)
  @Operation(summary = "Get financial reports by Ids")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FinancialStatement.class))
            })
      })
  public Flux<FinancialStatement> getReportsByIds(
      @Parameter(description = "Report Ids") @RequestParam Set<Long> ids) {
    return financialStatementService.getFinancialStatementsByIds(ids);
  }

  @RequestMapping(value = "/document/{documentId}", method = RequestMethod.GET)
  @Operation(summary = "Get financial reports by document")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = FinancialStatement.class))
            })
      })
  public Flux<FinancialStatement> getFinancialStatementsByDocumentId(
      @Parameter(description = "Document Id") @PathVariable("documentId") Long documentId) {
    return financialStatementService.getFinancialStatementsByDocumentId(documentId);
  }
}
