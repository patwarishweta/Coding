package com.cwan.privatefund.canoeFundMapping;

import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingAccountResponse;
import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingClientResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping(value = "v1/directory")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class CanoeFundMappingController {

  private final CanoeFundMappingService canoeFundMappingService;

  @Autowired
  public CanoeFundMappingController(CanoeFundMappingService canoeFundMappingService) {
    this.canoeFundMappingService = canoeFundMappingService;
  }

  @GetMapping(value = "/clientDetails")
  @Operation(summary = "get all clients within LP Universe")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Set<CanoeFundMappingClientResponse> getAllClientDetails() {
    return canoeFundMappingService.getClientDetails();
  }

  @GetMapping(value = "/accountDetails")
  @Operation(summary = "get account details by client id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public List<CanoeFundMappingAccountResponse> getAllById(@RequestParam("clientId") Long clientId) {
    return canoeFundMappingService.getAccountDetails(clientId);
  }
}
