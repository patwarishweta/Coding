package com.cwan.privatefund.documentmanager;

import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Tag;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.document.LpxDocumentServiceClient;
import com.cwan.privatefund.documentmanager.exception.DocumentUploadFailedException;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.tag.LpxTagService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class LpxDocumentManagerService {

  private final Documents documents;
  private final LpxTagService lpxTagService;
  private final SecurityService securityService;
  private final LpxDocumentServiceClient lpxDocumentServiceClient;
  private final AccountService accountService;
  private final Tika tika;
  private final SecurityContextUserService securityContextUserService;
  private final DocumentManagerRequestValidator documentManagerRequestValidator;
  private final MiscDocumentTransformer miscDocumentTransformer;

  public LpxDocumentManagerService(
      Documents documents,
      LpxTagService lpxTagService,
      SecurityService securityService,
      LpxDocumentServiceClient lpxDocumentServiceClient,
      AccountService accountService,
      Tika tika,
      SecurityContextUserService securityContextUserService,
      DocumentManagerRequestValidator documentManagerRequestValidator,
      MiscDocumentTransformer miscDocumentTransformer) {
    this.documents = documents;
    this.lpxTagService = lpxTagService;
    this.securityService = securityService;
    this.lpxDocumentServiceClient = lpxDocumentServiceClient;
    this.accountService = accountService;
    this.tika = tika;
    this.securityContextUserService = securityContextUserService;
    this.documentManagerRequestValidator = documentManagerRequestValidator;
    this.miscDocumentTransformer = miscDocumentTransformer;
  }

  public Flux<DocumentManagerData> getActiveDocumentsByAccountIdAndTag(Long accountId, String tag) {
    return lpxTagService
        .getAllByTag(tag)
        .collectList()
        .flux()
        .flatMap(
            tags -> {
              var documentIds = tags.stream().map(Tag::getDocumentId).collect(Collectors.toSet());
              return documents
                  .getAllDocumentsByAccountIdAndIsDisabled(Set.of(accountId), false)
                  .filter(document -> documentIds.contains(document.getId()));
            })
        .flatMap(this::fillOutDocumentManagerFields);
  }

  public Flux<DocumentManagerData> getActiveDocumentsByAccountIdAndFileName(
      Long accountId, String fileName) {
    return documents
        .getAllActiveDocumentsByAccountIdAndFileName(accountId, fileName)
        .flatMap(this::fillOutDocumentManagerFields);
  }

  public Flux<DocumentManagerData> getActiveDocumentsByDirectoryId(Long directoryId) {
    return documents
        .getAllActiveDocumentsByDirectoryId(directoryId)
        .flatMap(this::fillOutDocumentManagerFields);
  }

  public Flux<DocumentManagerData> getDisabledDocumentsForAccount(Long accountId)
      throws ExecutionException, InterruptedException {
    Set<Long> simpleAccounts =
        new HashSet<>(accountService.expandAccountId(accountId).collectList().toFuture().get());
    return documents
        .getAllDocumentsByAccountIdAndIsDisabled(simpleAccounts, true)
        .flatMap(this::fillOutDocumentManagerFields)
        .map(this::hydrateSecurityData);
  }

  public Flux<DocumentManagerData> getActiveDocumentsForAccount(Long accountId)
      throws ExecutionException, InterruptedException {
    Set<Long> simpleAccounts =
        new HashSet<>(accountService.expandAccountId(accountId).collectList().toFuture().get());
    return documents
        .getAllDocumentsByAccountIdAndIsDisabled(simpleAccounts, false)
        .filter(doc -> !("DataForge".equalsIgnoreCase(doc.getSource())))
        .flatMap(this::fillOutDocumentManagerFields)
        .map(this::hydrateSecurityData);
  }

  public Mono<DocumentManagerData> saveNewDocument(
      FilePart file, DocumentManagerData documentManagerData) {
    return lpxDocumentServiceClient
        .uploadFile(file)
        .filter(cloudStorageId -> !("UPLOAD_FAILED".equals(cloudStorageId)))
        .flatMap(
            cloudStorageId -> {
              var documentToSave =
                  documentManagerData.getDocument().toBuilder()
                      .cloudStorageId(cloudStorageId)
                      .build();
              return lpxDocumentServiceClient
                  .saveDocument(documentToSave)
                  .collectList()
                  .flatMap(
                      savedDocumentList ->
                          lpxTagService
                              .updateTagsForDocumentId(
                                  savedDocumentList.get(0).getId(), documentManagerData.getTags())
                              .map(Tag::getTag)
                              .collectList()
                              .flatMap(
                                  tags ->
                                      Mono.just(
                                          DocumentManagerData.builder()
                                              .document(savedDocumentList.get(0))
                                              .tags(Set.copyOf(tags))
                                              .build())));
            });
  }

  public Mono<ResponseEntity<DocumentUploadResponse>> uploadDocument(
      DocumentUploadRequest request) {
    DocumentUploadResponse response = new DocumentUploadResponse();
    List<DocumentUploadFileDetails> uploadFileDetailsList = new ArrayList<>();
    return documentManagerRequestValidator
        .validateDocumentUploadRequest(request)
        .flatMap(documentManagerRequestValidator::authorizeDocumentUploadRequest)
        .flatMap(documentManagerRequestValidator::validateAndFetchNeedsCustomAllocation)
        .flatMap(
            needsCustomAllocation ->
                Flux.fromIterable(request.getFiles())
                    .flatMap(
                        file ->
                            lpxDocumentServiceClient
                                .uploadFile(file)
                                .map(
                                    cloudStorageId ->
                                        request.getDocumentDetails().getDocument().toBuilder()
                                            .fileName(file.filename())
                                            .cloudStorageId(cloudStorageId)
                                            .build()))
                    .filter(
                        document -> {
                          if ("UPLOAD_FAILED".equals(document.getCloudStorageId())) {
                            uploadFileDetailsList.add(
                                DocumentUploadFileDetails.builder()
                                    .fileName(document.getFileName())
                                    .status(DocumentUploadStatus.FAILED)
                                    .build());
                            return false;
                          }
                          return true;
                        })
                    .collectList()
                    .flatMapMany(
                        uploadedDocs -> {
                          if (uploadedDocs.isEmpty()) {
                            return Mono.error(
                                new DocumentUploadFailedException(uploadFileDetailsList));
                          }
                          return Flux.fromIterable(uploadedDocs);
                        })
                    .flatMap(this::hydrateUserDataInDocument)
                    .flatMap(lpxDocumentServiceClient::saveDocument)
                    .flatMap(
                        document -> {
                          if (Boolean.FALSE.equals(needsCustomAllocation)) {
                            return Mono.just(
                                    request.getDocumentDetails().getDocument().toBuilder()
                                        .id(document.getId())
                                        .createdBy(document.getCreatedBy())
                                        .modifiedBy(document.getModifiedBy())
                                        .build())
                                .map(
                                    reqDoc ->
                                        miscDocumentTransformer.transform(
                                            reqDoc,
                                            request.getDocumentDetails().getUltimateParent()))
                                .flatMap(lpxDocumentServiceClient::saveMiscDocument)
                                .flatMap(savedMiscDoc -> Mono.just(document));
                          }
                          return Mono.just(document);
                        })
                    .flatMap(
                        savedDoc ->
                            lpxTagService
                                .updateTagsForDocumentId(
                                    savedDoc.getId(), request.getDocumentDetails().getTags())
                                .map(Tag::getTag)
                                .collectList()
                                .flatMap(
                                    tags -> {
                                      uploadFileDetailsList.add(
                                          DocumentUploadFileDetails.builder()
                                              .documentId(savedDoc.getId())
                                              .status(DocumentUploadStatus.SUCCESS)
                                              .cloudStorageId(savedDoc.getCloudStorageId())
                                              .fileName(savedDoc.getFileName())
                                              .build());
                                      return Mono.just(
                                          DocumentManagerData.builder()
                                              .tags(Set.copyOf(tags))
                                              .document(savedDoc)
                                              .build());
                                    }))
                    .collectList()
                    .flatMap(
                        documentManagerDataList -> {
                          response.setDocumentDetails(documentManagerDataList.get(0));
                          response.setUploadedFileDetails(uploadFileDetailsList);
                          if (Boolean.TRUE.equals(
                              uploadFileDetailsList.stream()
                                  .anyMatch(
                                      uploadFileDetail ->
                                          DocumentUploadStatus.FAILED.equals(
                                              uploadFileDetail.getStatus())))) {
                            return Mono.just(
                                new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED));
                          }
                          return Mono.just(new ResponseEntity<>(response, HttpStatus.CREATED));
                        }));
  }

  public Flux<DocumentManagerData> getActiveDocumentsWithoutDirectoryByAccount(Long accountId) {
    return documents
        .getAllActiveDocumentsWithoutDirectoryByAccountId(accountId)
        .flatMap(this::fillOutDocumentManagerFields);
  }

  private Flux<DocumentManagerData> fillOutDocumentManagerFields(Document document) {
    return lpxTagService
        .getAllByDocumentId(document.getId())
        .map(Tag::getTag)
        .collectList()
        .flux()
        .flatMap(
            tags ->
                Flux.just(
                    DocumentManagerData.builder()
                        .document(document)
                        .tags(Set.copyOf(tags))
                        .build()));
  }

  private DocumentManagerData hydrateSecurityData(DocumentManagerData documentManagerData) {
    try {
      return this.addSecurityDataToDocumentManagerData(documentManagerData);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      log.error("Thread was interrupted while hydrating security data.", e);
      return documentManagerData;
    } catch (Exception e) {
      log.error("Error retrieving security data for DocumentManagerData.", e);
      return documentManagerData;
    }
  }

  private DocumentManagerData addSecurityDataToDocumentManagerData(
      DocumentManagerData documentManagerData) throws ExecutionException, InterruptedException {
    if ((documentManagerData.getDocument().getSecurity() == null)
        || (documentManagerData.getDocument().getSecurity().getSecurityId() == null)) {
      return documentManagerData;
    }
    Mono<Security> securityData =
        securityService.getSecurity(
            documentManagerData.getDocument().getAccount().getClientId(),
            documentManagerData.getDocument().getAccount().getId(),
            documentManagerData.getDocument().getSecurity().getSecurityId());
    if (securityData == null) {
      return documentManagerData;
    }
    return securityData
        .map(security -> documentManagerData.getDocument().toBuilder().security(security).build())
        .map(document -> documentManagerData.toBuilder().document(document).build())
        .toFuture()
        .get();
  }

  private Mono<Document> hydrateUserDataInDocument(Document document) {
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .map(
            user ->
                document.toBuilder()
                    .createdBy(user.getEmail())
                    .createdOn(LocalDateTime.now())
                    .modifiedOn(LocalDateTime.now())
                    .modifiedBy(user.getEmail())
                    .build());
  }
}
