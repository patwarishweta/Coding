package com.cwan.privatefund.security.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Builder;

@Builder(toBuilder = true)
public record SecurityTypeData(
    @JsonProperty("isLIHTC") Boolean isLIHTC,
    @JsonProperty("isAmortizingLP") Boolean isAmortizingLP,
    @JsonProperty("isLimitedPartnership") Boolean isLimitedPartnership)
    implements Serializable {}
