package com.cwan.privatefund.tag;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class TagException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = 1149237670324522567L;

  public TagException(HttpStatus status, String msg, Throwable e) {
    super(status, msg, e);
  }
}
