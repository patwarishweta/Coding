package com.cwan.privatefund.aum;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Aum;
import com.cwan.pbor.aum.AumService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ExcelCreationService {

  private final AumService aumService;
  private final LpxAumService lpxAumService;
  private final AccountConfigServiceCache accountConfigService;

  private static final List<String> AUM_FIELDS =
      List.of(
          "id",
          "accountId",
          "securityId",
          "ultimateParentId",
          "clientId",
          "aum",
          "calculatedOn",
          "isActive");
  private static final List<String> ADDITIONAL_FIELDS =
      List.of(
          "capitalCallManagerDate",
          "LPxClarity",
          "LIHTC_ENABLED",
          "LPxFullService",
          "LPxSelfService",
          "LPxPrismReporting",
          "ultimateParentName",
          "clientName");

  public ExcelCreationService(
      AumService aumService,
      AccountConfigServiceCache accountConfigService,
      LpxAumService lpxAumService) {
    this.aumService = aumService;
    this.accountConfigService = accountConfigService;
    this.lpxAumService = lpxAumService;
  }

  public byte[] generateExcelFile(Set<Long> clientIds, LocalDate calculationDate) {
    try (Workbook workbook = new XSSFWorkbook()) {
      Sheet sheet = workbook.createSheet("AUM Data");

      Map<Long, List<Aum>> aumData = new HashMap<>();
      Set<Long> missingClientIds = new HashSet<>();
      clientIds.forEach(
          id -> {
            List<Aum> aumList = aumService.findAllByClientIdAndCalculatedOn(id, calculationDate);
            if (aumList.isEmpty()) {
              missingClientIds.add(id);
            } else {
              aumData.put(id, aumList);
            }
          });

      if (!missingClientIds.isEmpty()) {
        Map<Long, List<Aum>> aumByUltimateParentIds =
            lpxAumService.getAumByUltimateParentIds(missingClientIds);
        aumData.putAll(aumByUltimateParentIds);
      }

      List<String> allFields =
          Stream.concat(AUM_FIELDS.stream(), ADDITIONAL_FIELDS.stream())
              .collect(Collectors.toList());

      createHeaderRow(sheet, allFields);
      Map<Long, Map<String, String>> additionalAttributeValues = getAdditionalAttributes(clientIds);

      int rowNum = 1;
      for (List<Aum> aumList : aumData.values()) {
        for (Aum aum : aumList) {
          createRow(
              sheet, AUM_FIELDS, aum, rowNum++, additionalAttributeValues.get(aum.getClientId()));
        }
      }

      IntStream.range(0, AUM_FIELDS.size() + ADDITIONAL_FIELDS.size())
          .forEach(sheet::autoSizeColumn);

      return writeWorkbookToByteArray(workbook);
    } catch (Exception e) {
      log.error("Error while creating AUM excel file", e);
      throw new IllegalStateException("Error while creating AUM excel file", e);
    }
  }

  private void createHeaderRow(Sheet sheet, List<String> allFields) {
    Row headerRow = sheet.createRow(0);
    IntStream.range(0, allFields.size())
        .forEach(i -> headerRow.createCell(i).setCellValue(allFields.get(i)));
  }

  private void createRow(
      Sheet sheet,
      List<String> aumFields,
      Aum aum,
      int rowNum,
      Map<String, String> additionalAttributesMap) {
    Row row = sheet.createRow(rowNum);

    List<String> aumData =
        List.of(
            aum.getId().toString(),
            aum.getAccountId().toString(),
            aum.getSecurityId().toString(),
            aum.getUltimateParentId().toString(),
            aum.getClientId().toString(),
            String.valueOf(aum.getAum()),
            aum.getCalculatedOn().toString(),
            String.valueOf(aum.getIsActive()));

    for (int i = 0; i < aumFields.size(); i++) {
      Cell cell = row.createCell(i);
      cell.setCellValue(aumData.get(i));
    }

    for (int i = 0; i < ExcelCreationService.ADDITIONAL_FIELDS.size(); i++) {
      Cell cell = row.createCell(aumFields.size() + i);
      String value =
          additionalAttributesMap != null
              ? additionalAttributesMap.getOrDefault(
                  ExcelCreationService.ADDITIONAL_FIELDS.get(i), "False")
              : "False";
      cell.setCellValue(value);
    }
  }

  private byte[] writeWorkbookToByteArray(Workbook workbook) throws IOException {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    workbook.write(outputStream);
    return outputStream.toByteArray();
  }

  public Map<Long, Map<String, String>> getAdditionalAttributes(Set<Long> clientIds)
      throws ExecutionException, InterruptedException {
    Map<Long, Map<String, String>> attributesByClientId = new HashMap<>();
    List<AccountConfig> accountConfigs =
        accountConfigService.getAllAccountConfigs().toFuture().get();
    Set<String> attributeToColumnSet =
        Set.of("capitalCallManagerDate", "LPxClarity", "LIHTC_ENABLED");
    Set<String> serviceToColumnSet =
        Set.of("LPxFullService", "LPxSelfService", "LPxPrismReporting");

    for (Long clientId : clientIds) {
      Map<String, String> additionalAttributes = new HashMap<>();
      accountConfigs.stream()
          .filter(accountConfig -> accountConfig.getClientId().equals(clientId))
          .forEach(
              accountConfig -> {
                accountConfig.getAttributes().entrySet().stream()
                    .filter(entry -> attributeToColumnSet.contains(entry.getKey()))
                    .forEach(
                        entry ->
                            additionalAttributes.put(
                                entry.getKey(),
                                entry.getValue().equals("true") ? "True" : "False"));

                String serviceName = accountConfig.getService().getName();
                if (serviceToColumnSet.contains(serviceName)) {
                  additionalAttributes.put(serviceName, "True");
                } else {
                  additionalAttributes.put(serviceName, "False");
                }

                String ultimateParenName = accountConfig.getUltimateParentName();
                if (ultimateParenName != null && !ultimateParenName.isEmpty()) {
                  additionalAttributes.put(
                      "ultimateParentName", accountConfig.getUltimateParentName());
                }

                String clientName = accountConfig.getClientName();
                if (clientName != null && !clientName.isEmpty()) {
                  additionalAttributes.put("clientName", clientName);
                }
              });
      attributesByClientId.put(clientId, additionalAttributes);
    }
    return attributesByClientId;
  }
}
