package com.cwan.privatefund.documentmanager;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.http.codec.multipart.FilePart;

@Getter
@Setter
@Builder(toBuilder = true)
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
public class DocumentUploadRequest {

  private List<FilePart> files;
  private DocumentManagerData documentDetails;
}
