package com.cwan.privatefund.salesforce.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SalesforceObjectDetails {

  @JsonProperty("Status")
  private String status;

  @JsonProperty("Subject")
  private String subject;

  @JsonProperty("Priority")
  private String priority;

  @JsonProperty("Description")
  private String description;

  @JsonProperty("RecordTypeId")
  private String recordTypeId;

  @JsonProperty("Origin")
  private String origin;

  @JsonProperty("Capital_Call_Account_ID__c")
  private String capitalCallAccountId;
}
