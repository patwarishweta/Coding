package com.cwan.privatefund.cpd.ws.constant;

import lombok.Getter;

@Getter
public enum CpdWSField {
  WIRE_TRANSFER("wireTransfer"),
  INITIAL("initial"),
  FINAL("final");
  private final String fieldName;

  CpdWSField(String fieldName) {
    this.fieldName = fieldName;
  }
}
