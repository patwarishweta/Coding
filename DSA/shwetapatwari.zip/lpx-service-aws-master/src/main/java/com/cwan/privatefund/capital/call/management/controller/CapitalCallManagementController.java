package com.cwan.privatefund.capital.call.management.controller;

import com.cwan.lpx.domain.Bank;
import com.cwan.privatefund.capital.call.management.model.BankAccountCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankAccountResponse;
import com.cwan.privatefund.capital.call.management.model.BankBlacklistResponse;
import com.cwan.privatefund.capital.call.management.model.BankCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankResponse;
import com.cwan.privatefund.capital.call.management.service.LpxCapitalCallManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Validated
@RequestMapping("/v1/capitalCallManagement")
@ApiResponses(
    value = {
      @ApiResponse(
          responseCode = "403",
          description = "Forbidden - Not authorized to access this resource",
          content = @Content(schema = @Schema(hidden = true))),
      @ApiResponse(
          responseCode = "500",
          description = "Internal server error",
          content = @Content(schema = @Schema(hidden = true))),
      @ApiResponse(
          responseCode = "400",
          description = "Bad Request - Invalid input",
          content = @Content(schema = @Schema(hidden = true))),
      @ApiResponse(
          responseCode = "404",
          description = "Resource not found",
          content = @Content(schema = @Schema(hidden = true)))
    })
public class CapitalCallManagementController {

  private final LpxCapitalCallManagementService lpxCapitalCallManagementService;

  public CapitalCallManagementController(
      LpxCapitalCallManagementService lpxCapitalCallManagementService) {
    this.lpxCapitalCallManagementService = lpxCapitalCallManagementService;
  }

  // ----------------- BANK ------------------
  @PostMapping("/banks")
  @Operation(summary = "Create a new bank")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "201",
            description = "Successfully created a bank",
            content = @Content(schema = @Schema(implementation = BankResponse.class))),
        @ApiResponse(
            responseCode = "422",
            description = "Unprocessable Entity - Semantic errors in request")
      })
  public Mono<ResponseEntity<BankResponse>> createBank(
      @RequestBody
          @Valid
          @NotNull
          @Parameter(description = "Bank details to create a new bank", required = true)
          BankCreationRequest bank) {
    return lpxCapitalCallManagementService
        .createBank(bank)
        .map(bankResponse -> ResponseEntity.status(HttpStatus.CREATED).body(bankResponse));
  }

  @GetMapping("/clients/{clientId}/banks")
  @Operation(summary = "Fetch banks associated with a given client")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved list of banks",
            content = @Content(schema = @Schema(implementation = BankResponse.class)))
      })
  public Mono<ResponseEntity<List<BankResponse>>> fetchBanksByClient(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "ID of the client to get banks for", required = true)
          @Min(value = 1, message = "Client ID must be greater than 0")
          Long clientId) {
    return lpxCapitalCallManagementService
        .fetchBanksByClient(clientId)
        .collectList()
        .map(ResponseEntity::ok);
  }

  @GetMapping("/banks/{bankUuid}")
  @Operation(summary = "Fetch details of a bank by its UUID")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully fetched bank details",
            content = @Content(schema = @Schema(implementation = Bank.class)))
      })
  public Mono<ResponseEntity<BankResponse>> fetchBank(
      @PathVariable
          @Parameter(description = "UUID of the bank to retrieve", required = true)
          @Valid
          @NotNull
          @Size(min = 36, max = 36, message = "Bank UUID must be 36 characters.")
          String bankUuid) {
    return lpxCapitalCallManagementService
        .fetchBank(bankUuid)
        .map(ResponseEntity::ok)
        .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
  }

  @DeleteMapping("/banks/{bankUuid}")
  @Operation(summary = "Delete a bank by its UUID")
  @ApiResponses(
      value = {@ApiResponse(responseCode = "204", description = "Successfully deleted the bank")})
  public Mono<ResponseEntity<Void>> deleteBank(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "UUID of the bank to delete", required = true)
          @Size(min = 36, max = 36, message = "Bank UUID must be 36 characters.")
          String bankUuid) {
    return lpxCapitalCallManagementService
        .deleteBank(bankUuid)
        .then(Mono.just(ResponseEntity.noContent().build()));
  }

  // ----------------- BANK ACCOUNT ------------------
  @PostMapping("/bankAccounts")
  @Operation(
      summary = "Create a new bank account",
      responses = {
        @ApiResponse(
            responseCode = "201",
            description = "Successfully created a bank account",
            content = @Content(schema = @Schema(implementation = BankAccountResponse.class))),
        @ApiResponse(
            responseCode = "422",
            description = "Unprocessable Entity - Semantic errors in request")
      })
  public Mono<ResponseEntity<BankAccountResponse>> createBankAccount(
      @RequestBody @Valid @NotNull BankAccountCreationRequest bankAccountCreationRequest) {
    return lpxCapitalCallManagementService
        .createBankAccount(bankAccountCreationRequest)
        .map(ResponseEntity.status(HttpStatus.CREATED)::body);
  }

  @GetMapping("/accounts/{accountId}/bankAccounts")
  @Operation(
      summary = "Fetch bank accounts associated with a given account",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved list of bank accounts",
            content = @Content(schema = @Schema(implementation = BankAccountResponse.class)))
      })
  public Mono<ResponseEntity<List<BankAccountResponse>>> fetchBankAccountsByAccount(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "ID of the account to get bank accounts for", required = true)
          @Min(value = 1, message = "Account ID must be greater than 0")
          Long accountId) {
    return lpxCapitalCallManagementService
        .fetchBankAccountsByAccount(accountId)
        .collectList()
        .map(ResponseEntity::ok);
  }

  @GetMapping("/clients/{clientId}/bankAccounts")
  @Operation(
      summary = "Fetch bank accounts associated with a given client",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved list of bank accounts",
            content = @Content(schema = @Schema(implementation = BankAccountResponse.class)))
      })
  public Mono<ResponseEntity<List<BankAccountResponse>>> fetchBankAccountsByClient(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "ID of the client to get bank accounts for", required = true)
          @Min(value = 1, message = "Client ID must be greater than 0")
          Long clientId) {
    return lpxCapitalCallManagementService
        .fetchBankAccountsByClient(clientId)
        .collectList()
        .map(ResponseEntity::ok);
  }

  @GetMapping("/bankAccounts/{bankAccountUuid}")
  @Operation(
      summary = "Fetch details of a bank account by its UUID",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully fetched bank account details",
            content = @Content(schema = @Schema(implementation = BankAccountResponse.class)))
      })
  public Mono<ResponseEntity<BankAccountResponse>> fetchBankAccount(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "UUID of the bank account to retrieve", required = true)
          @Size(min = 36, max = 36, message = "Bank account UUID must be 36 characters.")
          String bankAccountUuid) {
    return lpxCapitalCallManagementService
        .fetchBankAccount(bankAccountUuid)
        .map(ResponseEntity::ok)
        .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
  }

  @DeleteMapping("/bankAccounts/{bankAccountUuid}")
  @Operation(
      summary = "Delete a bank account by its UUID",
      responses = {
        @ApiResponse(responseCode = "204", description = "Successfully deleted the bank account")
      })
  public Mono<ResponseEntity<Void>> deleteBankAccount(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "UUID of the bank account to delete", required = true)
          @Size(min = 36, max = 36, message = "Bank account UUID must be 36 characters.")
          String bankAccountUuid) {
    return lpxCapitalCallManagementService
        .deleteBankAccount(bankAccountUuid)
        .then(Mono.just(ResponseEntity.noContent().build()));
  }

  // ----------------- BANK BLACKLIST ------------------
  @PostMapping("/banks/{bankUuid}/bankBlacklists")
  @Operation(summary = "Create a new bank blacklist entry")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "201",
            description = "Successfully created a bank blacklist entry",
            content = @Content(schema = @Schema(implementation = BankBlacklistResponse.class))),
        @ApiResponse(
            responseCode = "422",
            description = "Unprocessable Entity - Semantic errors in request",
            content = @Content(schema = @Schema(hidden = true)))
      })
  public Mono<ResponseEntity<BankBlacklistResponse>> addBankToBlacklist(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(
              description = "UUID of the bank to create blacklist entry for",
              required = true)
          @Size(min = 36, max = 36, message = "Bank UUID must be 36 characters.")
          String bankUuid) {
    return lpxCapitalCallManagementService
        .addBankToBlacklist(bankUuid)
        .map(
            bankBlacklistResponse ->
                ResponseEntity.status(HttpStatus.CREATED).body(bankBlacklistResponse));
  }

  @GetMapping("/clients/{clientId}/bankBlacklists")
  @Operation(summary = "Fetch bank blacklist entries associated with a given client")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved list of bank blacklist entries",
            content = @Content(schema = @Schema(implementation = BankBlacklistResponse.class)))
      })
  public Mono<ResponseEntity<List<BankBlacklistResponse>>> fetchBankBlacklistsByClient(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(
              description = "ID of the client to get bank blacklist entries for",
              required = true)
          @Min(value = 1, message = "Client ID must be greater than 0")
          Long clientId) {
    return lpxCapitalCallManagementService
        .fetchBlacklistedBanksByClient(clientId)
        .collectList()
        .map(ResponseEntity::ok);
  }

  @GetMapping("/bankBlacklists/{bankBlacklistUuid}")
  @Operation(summary = "Fetch details of a bank blacklist entry by its UUID")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully fetched bank blacklist entry details",
            content = @Content(schema = @Schema(implementation = BankBlacklistResponse.class)))
      })
  public Mono<ResponseEntity<BankBlacklistResponse>> fetchBankBlacklist(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "UUID of the bank blacklist entry to retrieve", required = true)
          @Size(min = 36, max = 36, message = "Bank blacklist UUID must be 36 characters.")
          String bankBlacklistUuid) {
    return lpxCapitalCallManagementService
        .fetchBlacklistedBank(bankBlacklistUuid)
        .map(ResponseEntity::ok)
        .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
  }

  @DeleteMapping("/bankBlacklists/{bankBlacklistUuid}")
  @Operation(summary = "Delete a bank blacklist entry by its UUID")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "Successfully deleted the bank blacklist entry",
            content = @Content(schema = @Schema(hidden = true)))
      })
  public Mono<ResponseEntity<Void>> removeBankFromBlacklist(
      @PathVariable
          @Valid
          @NotNull
          @Parameter(description = "UUID of the bank blacklist entry to delete", required = true)
          @Size(min = 36, max = 36, message = "Bank blacklist UUID must be 36 characters.")
          String bankBlacklistUuid) {
    return lpxCapitalCallManagementService
        .removeBankFromBlacklist(bankBlacklistUuid)
        .then(Mono.just(ResponseEntity.noContent().build()));
  }
}
