package com.cwan.privatefund.documentmanager;

import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.auth.accesscontrolfiltering.AccessControlFilteringService;
import com.cwan.privatefund.document.LpxDocumentServiceCache;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class DocumentManagerRequestValidator {

  private final LpxDocumentServiceCache lpxDocumentServiceCache;
  private final SecurityContextUserService securityContextUserService;
  private final AccessControlFilteringService accessControlFilteringService;
  private final AccountService accountService;

  public DocumentManagerRequestValidator(
      LpxDocumentServiceCache lpxDocumentServiceCache,
      SecurityContextUserService securityContextUserService,
      AccessControlFilteringService accessControlFilteringService,
      AccountService accountService) {
    this.lpxDocumentServiceCache = lpxDocumentServiceCache;
    this.securityContextUserService = securityContextUserService;
    this.accessControlFilteringService = accessControlFilteringService;
    this.accountService = accountService;
  }

  public Mono<DocumentUploadRequest> validateDocumentUploadRequest(DocumentUploadRequest request) {
    return Mono.just(request)
        .flatMap(
            documentUploadRequest -> {
              DocumentManagerData documentDetails = documentUploadRequest.getDocumentDetails();
              if (documentDetails == null) {
                return Mono.error(
                    new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "documentDetails cannot be null"));
              }
              if (documentDetails.getDocument() == null) {
                return Mono.error(
                    new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "document cannot be null."));
              }
              if (documentDetails.getDocument().getType() == null
                  || documentDetails.getDocument().getType().isEmpty()) {
                return Mono.error(
                    new ResponseStatusException(HttpStatus.BAD_REQUEST, "type cannot be null."));
              }
              if (documentDetails.getUltimateParent() == null
                  || documentDetails.getUltimateParent().getUltimateParentId() == null) {
                return Mono.error(
                    new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "ultimateParentId cannot be null."));
              }
              if (documentDetails.getUltimateParent().getUltimateParentName() == null
                  || documentDetails.getUltimateParent().getUltimateParentName().isEmpty()) {
                return Mono.error(
                    new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "ultimateParentName cannot be null."));
              }
              return Mono.just(documentUploadRequest);
            });
  }

  public Mono<Boolean> validateAndFetchNeedsCustomAllocation(DocumentUploadRequest request) {
    return Mono.just(request)
        .map(DocumentUploadRequest::getDocumentDetails)
        .map(DocumentManagerData::getDocument)
        .flatMap(
            extenderDocumentRequest ->
                lpxDocumentServiceCache
                    .getDocumentTypeData(extenderDocumentRequest.getType())
                    .flatMap(
                        documentTypeData -> {
                          if (documentTypeData == null
                              || documentTypeData.getNeedsCustomAllocation() == null) {
                            return Mono.error(
                                new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST, "Invalid documentType."));
                          }
                          return Mono.just(documentTypeData.getNeedsCustomAllocation());
                        })
                    .flatMap(
                        needsCustomAllocation -> {
                          if (Boolean.TRUE.equals(needsCustomAllocation)
                              && (extenderDocumentRequest.getAccount() == null
                                  || extenderDocumentRequest.getAccount().getId() == null
                                  || extenderDocumentRequest.getAccount().getId() == 0L)) {
                            return Mono.error(
                                new ResponseStatusException(
                                    HttpStatus.BAD_REQUEST,
                                    "If needsCustomAllocation is true then accountId & securityId is mandatory."));
                          }
                          return Mono.just(needsCustomAllocation);
                        }));
  }

  public Mono<DocumentUploadRequest> authorizeDocumentUploadRequest(DocumentUploadRequest request) {
    Long ultimateParentId = request.getDocumentDetails().getUltimateParent().getUltimateParentId();
    Long accountId =
        request.getDocumentDetails().getDocument().getAccount() != null
                && request.getDocumentDetails().getDocument().getAccount().getId() != null
            ? request.getDocumentDetails().getDocument().getAccount().getId()
            : null;
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .filterWhen(
            user -> {
              if (accountId != null) {
                return accessControlFilteringService.checkResourceAccessByAccount(user, accountId);
              }
              return Mono.just(Boolean.TRUE);
            })
        .switchIfEmpty(
            Mono.defer(
                () ->
                    Mono.error(
                        new ResponseStatusException(
                            HttpStatus.FORBIDDEN,
                            "User does not have access to the accountId : " + accountId))))
        .flatMap(
            user ->
                accountService
                    .retrieveAccountsGroupedByUltimateParent(user.getId())
                    .filter(
                        ultimateParentsAccountMap ->
                            ultimateParentsAccountMap
                                .getUltimateParentId()
                                .equals(ultimateParentId.intValue()))
                    .collectList()
                    .flatMapMany(
                        filteredUltimateParentMap -> {
                          if (filteredUltimateParentMap.isEmpty()) {
                            return Flux.error(
                                new ResponseStatusException(
                                    HttpStatus.FORBIDDEN, "ultimateParentId does not exist"));
                          }
                          return Flux.fromIterable(filteredUltimateParentMap);
                        })
                    .filter(
                        ultimateParentsAccountMap -> {
                          if (accountId != null) {
                            return ultimateParentsAccountMap.getAccounts().stream()
                                .anyMatch(account -> account.getId().equals(accountId));
                          }
                          return Boolean.TRUE;
                        })
                    .switchIfEmpty(
                        Mono.error(
                            new ResponseStatusException(
                                HttpStatus.FORBIDDEN,
                                String.format(
                                    "accountId : %s is not associated with the provided ultimateParentId : %s",
                                    accountId, ultimateParentId))))
                    .collectList())
        .flatMap(ultimateParentsAccountMapList -> Mono.just(request));
  }
}
