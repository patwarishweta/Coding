package com.cwan.privatefund.accelex;

import static com.cwan.privatefund.constant.Constants.LPX_CLARITY;
import static com.cwan.privatefund.constant.Constants.OPEN_TRAN_TYPES;
import static com.cwan.privatefund.tabular.dataset.DataSetUtils.getUltimateParentClientId;
import static com.cwan.privatefund.util.DateUtils.convertDateFormat;
import static com.cwan.privatefund.util.DateUtils.convertDateTimeFormat;

import com.ca.relalg.Column;
import com.ca.relalg.data.DataSet;
import com.ca.relalg.data.DataSetBuilder;
import com.ca.util.date.GlobalDate;
import com.ca.util.time.UTCTimestamp;
import com.cwan.lpx.client.tabular.LPBalanceField;
import com.cwan.lpx.client.tabular.LPField;
import com.cwan.lpx.client.tabular.LPTransactionField;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.accelex.api.AccelexCommonService;
import com.cwan.pbor.trans.TransactionService;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSApacheClient;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.document.LpxDocumentServiceApacheClient;
import com.cwan.privatefund.feature.Feature;
import com.cwan.privatefund.feature.FeatureFlagsWSClient;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.portfolio.PortfolioUtilsService;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient;
import com.cwan.privatefund.security.SecurityResolverClient;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.tabular.dataset.DataSetUtils;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.scheduler.Schedulers;

@Service
@Slf4j
public class AccelexService {

  private final BusinessWSApacheClient businessWSApacheClient;
  private final LpxDocumentServiceApacheClient lpxDocumentServiceApacheClient;
  private final PortfolioWsApacheClient portfolioWsApacheClient;
  private final SecurityResolverClient securityResolverClient;
  private final AccelexCommonService accelexCommonService;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final TransactionService transactionService;
  private final LpxFundMasterService fundMasterService;
  private final BusinessWSCache businessWSCache;
  private final SecurityService securityService;
  private final PortfolioUtilsService portfolioUtilsService;
  private final AccountService accountService;
  private final FeatureFlagsWSClient featureFlagsWSClient;

  private static final Map<ClearwaterFundType, AccelexFundType> FUND_TYPE_MAPPING = new HashMap<>();
  private static final Map<String, String> COUNTRY_ISO_CODES = new HashMap<>();
  private static final Map<String, String> TYPE_TO_ACCELEX_INVESTMENT_TYPE = new HashMap<>();

  static {
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Opportunistic"),
        new AccelexFundType("Real Estate", "Opportunistic"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Fund of Funds"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Multi-Strategy"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Growth"),
        new AccelexFundType("Growth Equity", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Venture Capital", "Venture (General)"),
        new AccelexFundType("Venture Capital", "Balanced"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Buyout"),
        new AccelexFundType("Buyout", "Mid Cap"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Equity Strategies"),
        new AccelexFundType("Hedge Funds", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Venture Capital", "Early Stage: Start-up"),
        new AccelexFundType("Venture Capital", "Early Stage"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Co-Investment"),
        new AccelexFundType("Co-Investments", "Single Manager"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Credit Strategies"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Venture Capital", "Early Stage"),
        new AccelexFundType("Venture Capital", "Early Stage"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Value Added"),
        new AccelexFundType("Real Estate", "Value-Add"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Venture Capital", "Early Stage: Seed"),
        new AccelexFundType("Venture Capital", "Early Stage"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Direct Lending"),
        new AccelexFundType("Debt - Credit", "Private Debt"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Relative Value Strategies"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Distressed Debt"),
        new AccelexFundType("Debt - Credit", "Distressed"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Direct Lending - Blended / Opportunistic Debt"),
        new AccelexFundType("Debt - Credit", "Special Situations"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Venture Capital", "Expansion / Late Stage"),
        new AccelexFundType("Venture Capital", "Expansion Stage"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Debt"),
        new AccelexFundType("Debt - Credit", "Real Estate"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Event Driven Strategies"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Balanced"),
        new AccelexFundType("Venture Capital", "Balanced"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Fund of Funds"),
        new AccelexFundType("Fund of Funds", "Real Estate"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Core-Plus"),
        new AccelexFundType("Real Estate", "Core"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Core Plus"),
        new AccelexFundType("Infrastructure", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Macro Strategies"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Natural Resources", "Natural Resources"),
        new AccelexFundType("Natural Resources", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Multi-Strategy"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Core"),
        new AccelexFundType("Real Estate", "Core"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Equity Strategies"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Credit Strategies"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Direct Lending - Senior Debt"),
        new AccelexFundType("Debt - Credit", "Private Debt"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Direct Secondaries"),
        new AccelexFundType("Secondaries", "Direct Interests"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Value Added"),
        new AccelexFundType("Infrastructure", "Equity"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Turnaround"),
        new AccelexFundType("Buyout", "Turnaround"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Niche Strategies"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Niche Strategies"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Debt"),
        new AccelexFundType("Infrastructure", "Debt"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Core"),
        new AccelexFundType("Infrastructure", "Equity"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Macro Strategies"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Secondaries"),
        new AccelexFundType("Secondaries", "Fund Interests"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Special Situations"),
        new AccelexFundType("Debt - Credit", "Special Situations"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "Co-Investment Multi-Manager"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("CTA", "Managed Futures/CTA"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Direct Lending - Unitranche Debt"),
        new AccelexFundType("Debt - Credit", "Private Debt"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Mezzanine"),
        new AccelexFundType("Debt - Credit", "Mezzanine"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Direct Lending - Junior / Subordinated Debt"),
        new AccelexFundType("Debt - Credit", "Private Debt"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Multi", "Special Situations"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Secondaries"),
        new AccelexFundType("Secondaries", "Fund Interests"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Venture Capital", "Venture Debt"),
        new AccelexFundType("Venture Capital", "Lending & Leasing"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Fund of Funds"),
        new AccelexFundType("Fund of Funds", "Infrastructure"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Opportunistic"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Relative Value Strategies"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("CTA", "Fund of CTAs"), new AccelexFundType("Fund of Funds", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Hedge Fund Other"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Event Driven Strategies"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Natural Resources", "Timber"),
        new AccelexFundType("Natural Resources", "Timber"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Private Debt Fund of Funds"),
        new AccelexFundType("Fund of Funds", "Credit"));
    FUND_TYPE_MAPPING.put(new ClearwaterFundType("Multi", "Hybrid"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Hedge Funds", "Fund of Hedge Funds Other"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Co-Investment"),
        new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Distressed"),
        new AccelexFundType("Debt - Credit", "Distressed"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Multi", "Real Asset"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure Secondaries"),
        new AccelexFundType("Secondaries", "Direct Interests"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Equity", "PIPE"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Multi", "Real Asset Fund of Funds"), new AccelexFundType("", ""));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Multi", "Hybrid Fund Of Funds"),
        new AccelexFundType("Fund of Funds", "Multi Focus"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate"),
        new AccelexFundType("Real Estate", "Balanced"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Infrastructure", "Infrastructure"),
        new AccelexFundType("Infrastructure", "Opportunistic"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Private Debt", "Special Situations Event Driven Strategies"),
        new AccelexFundType("Debt - Credit", "Special Situations"));
    FUND_TYPE_MAPPING.put(
        new ClearwaterFundType("Real Estate", "Real Estate Credit Strategies"),
        new AccelexFundType("Debt - Credit", "Real Estate"));

    COUNTRY_ISO_CODES.put("US", "US");
    COUNTRY_ISO_CODES.put("Switzerland", "CH");
    COUNTRY_ISO_CODES.put("China", "CN");
    COUNTRY_ISO_CODES.put("UK", "GB");
    COUNTRY_ISO_CODES.put("Japan", "JP");
    COUNTRY_ISO_CODES.put("France", "FR");
    COUNTRY_ISO_CODES.put("India", "IN");
    COUNTRY_ISO_CODES.put("Gibraltar", "GI");
    COUNTRY_ISO_CODES.put("United Arab Emirates", "AE");
    COUNTRY_ISO_CODES.put("Denmark", "DK");
    COUNTRY_ISO_CODES.put("Hong Kong SAR - China", "HK");
    COUNTRY_ISO_CODES.put("Israel", "IL");
    COUNTRY_ISO_CODES.put("South Korea", "KR");
    COUNTRY_ISO_CODES.put("Spain", "ES");
    COUNTRY_ISO_CODES.put("Guernsey", "GG");
    COUNTRY_ISO_CODES.put("Saudi Arabia", "SA");
    COUNTRY_ISO_CODES.put("Germany", "DE");
    COUNTRY_ISO_CODES.put("Singapore", "SG");
    COUNTRY_ISO_CODES.put("Australia", "AU");
    COUNTRY_ISO_CODES.put("Italy", "IT");
    COUNTRY_ISO_CODES.put("Mexico", "MX");
    COUNTRY_ISO_CODES.put("Norway", "NO");
    COUNTRY_ISO_CODES.put("Armenia", "AM");
    COUNTRY_ISO_CODES.put("Canada", "CA");
    COUNTRY_ISO_CODES.put("South Africa", "ZA");
    COUNTRY_ISO_CODES.put("Luxembourg", "LU");
    COUNTRY_ISO_CODES.put("Austria", "AT");
    COUNTRY_ISO_CODES.put("Czech Republic", "CZ");
    COUNTRY_ISO_CODES.put("Philippines", "PH");
    COUNTRY_ISO_CODES.put("Poland", "PL");
    COUNTRY_ISO_CODES.put("Ireland", "IE");
    COUNTRY_ISO_CODES.put("Taiwan - China", "TW");
    COUNTRY_ISO_CODES.put("Netherlands", "NL");
    COUNTRY_ISO_CODES.put("Brazil", "BR");
    COUNTRY_ISO_CODES.put("Sweden", "SE");
    COUNTRY_ISO_CODES.put("Belgium", "BE");
    COUNTRY_ISO_CODES.put("Brunei", "BN");
    COUNTRY_ISO_CODES.put("Bahrain", "BH");
    COUNTRY_ISO_CODES.put("Malaysia", "MY");
    COUNTRY_ISO_CODES.put("Finland", "FI");
    COUNTRY_ISO_CODES.put("Cayman Islands", "KY");
    COUNTRY_ISO_CODES.put("British Virgin Islands", "VG");
    COUNTRY_ISO_CODES.put("Bulgaria", "BG");
    COUNTRY_ISO_CODES.put("United States", "US");
    COUNTRY_ISO_CODES.put("Vietnam", "VN");
    COUNTRY_ISO_CODES.put("Kenya", "KE");
    COUNTRY_ISO_CODES.put("Portugal", "PT");
    COUNTRY_ISO_CODES.put("Jersey", "JE");
    COUNTRY_ISO_CODES.put("Bahamas", "BS");
    COUNTRY_ISO_CODES.put("Nigeria", "NG");
    COUNTRY_ISO_CODES.put("Colombia", "CO");
    COUNTRY_ISO_CODES.put("Puerto Rico", "PR");
    COUNTRY_ISO_CODES.put("Monaco", "MC");
    COUNTRY_ISO_CODES.put("Chile", "CL");
    COUNTRY_ISO_CODES.put("New Zealand", "NZ");
    COUNTRY_ISO_CODES.put("Hungary", "HU");
    COUNTRY_ISO_CODES.put("Nicaragua", "NI");
    COUNTRY_ISO_CODES.put("Argentina", "AR");
    COUNTRY_ISO_CODES.put("Indonesia", "ID");
    COUNTRY_ISO_CODES.put("Egypt", "EG");
    COUNTRY_ISO_CODES.put("Jordan", "JO");
    COUNTRY_ISO_CODES.put("Croatia", "HR");
    COUNTRY_ISO_CODES.put("Nepal", "NP");
    COUNTRY_ISO_CODES.put("Russia", "RU");
    COUNTRY_ISO_CODES.put("Greece", "GR");
    COUNTRY_ISO_CODES.put("Bangladesh", "BD");
    COUNTRY_ISO_CODES.put("Mauritius", "MU");
    COUNTRY_ISO_CODES.put("Bermuda", "BM");
    COUNTRY_ISO_CODES.put("Malta", "MT");
    COUNTRY_ISO_CODES.put("Lithuania", "LT");
    COUNTRY_ISO_CODES.put("Romania", "RO");
    COUNTRY_ISO_CODES.put("Oman", "OM");
    COUNTRY_ISO_CODES.put("Slovakia", "SK");
    COUNTRY_ISO_CODES.put("Latvia", "LV");
    COUNTRY_ISO_CODES.put("Estonia", "EE");
    COUNTRY_ISO_CODES.put("Cyprus", "CY");
    COUNTRY_ISO_CODES.put("Iceland", "IS");
    COUNTRY_ISO_CODES.put("Ivory Coast", "CI");
    COUNTRY_ISO_CODES.put("Ghana", "GH");
    COUNTRY_ISO_CODES.put("Zimbabwe", "ZW");
    COUNTRY_ISO_CODES.put("Tunisia", "TN");
    COUNTRY_ISO_CODES.put("Thailand", "TH");
    COUNTRY_ISO_CODES.put("Pakistan", "PK");
    COUNTRY_ISO_CODES.put("Dominican Republic", "DO");
    COUNTRY_ISO_CODES.put("Slovenia", "SI");
    COUNTRY_ISO_CODES.put("Seychelles", "SC");
    COUNTRY_ISO_CODES.put("United Kingdom", "GB");
    COUNTRY_ISO_CODES.put("Namibia", "NA");
    COUNTRY_ISO_CODES.put("Turkey", "TR");
    COUNTRY_ISO_CODES.put("Kazakhstan", "KZ");
    COUNTRY_ISO_CODES.put("Liechtenstein", "LI");
    COUNTRY_ISO_CODES.put("Venezuela", "VE");
    COUNTRY_ISO_CODES.put("Morocco", "MA");
    COUNTRY_ISO_CODES.put("Uruguay", "UY");
    COUNTRY_ISO_CODES.put("Ukraine", "UA");
    COUNTRY_ISO_CODES.put("Kuwait", "KW");
    COUNTRY_ISO_CODES.put("Lebanon", "LB");
    COUNTRY_ISO_CODES.put("Azerbaijan", "AZ");
    COUNTRY_ISO_CODES.put("Andorra", "AD");
    COUNTRY_ISO_CODES.put("Ethiopia", "ET");
    COUNTRY_ISO_CODES.put("Costa Rica", "CR");
    COUNTRY_ISO_CODES.put("Qatar", "QA");
    COUNTRY_ISO_CODES.put("Peru", "PE");
    COUNTRY_ISO_CODES.put("Barbados", "BB");
    COUNTRY_ISO_CODES.put("Panama", "PA");
    COUNTRY_ISO_CODES.put("Jamaica", "JM");
    COUNTRY_ISO_CODES.put("Democratic Republic of Congo", "CD");
    COUNTRY_ISO_CODES.put("Cambodia", "KH");
    COUNTRY_ISO_CODES.put("Palestine", "PS");
    COUNTRY_ISO_CODES.put("El Salvador", "SV");
    COUNTRY_ISO_CODES.put("Trinidad and Tobago", "TT");
    COUNTRY_ISO_CODES.put("Bolivia", "BO");
    COUNTRY_ISO_CODES.put("Serbia", "RS");
    COUNTRY_ISO_CODES.put("Uganda", "UG");
    COUNTRY_ISO_CODES.put("Rwanda", "RW");
    COUNTRY_ISO_CODES.put("Netherlands Antilles", "AN");
    COUNTRY_ISO_CODES.put("Macedonia", "MK");
    COUNTRY_ISO_CODES.put("Togo", "TG");
    COUNTRY_ISO_CODES.put("Ecuador", "EC");
    COUNTRY_ISO_CODES.put("Tajikistan", "TJ");
    COUNTRY_ISO_CODES.put("Senegal", "SN");
    COUNTRY_ISO_CODES.put("Honduras", "HN");
    COUNTRY_ISO_CODES.put("Macao SAR - China", "MO");
    COUNTRY_ISO_CODES.put("Mongolia", "MN");
    COUNTRY_ISO_CODES.put("Angola", "AO");
    COUNTRY_ISO_CODES.put("Botswana", "BW");
    COUNTRY_ISO_CODES.put("Maldives", "MV");
    COUNTRY_ISO_CODES.put("Isle of Man", "IM");
    COUNTRY_ISO_CODES.put("Fiji Island", "FJ");
    COUNTRY_ISO_CODES.put("Georgia", "GE");
    COUNTRY_ISO_CODES.put("Sierra Leone", "SL");
    COUNTRY_ISO_CODES.put("Saint Vincent", "VC");
    COUNTRY_ISO_CODES.put("Saint Kitts and Nevis", "KN");
    COUNTRY_ISO_CODES.put("Vanuatu", "VU");
    COUNTRY_ISO_CODES.put("US Virgin Islands", "VI");
    COUNTRY_ISO_CODES.put("Zambia", "ZM");
    COUNTRY_ISO_CODES.put("Iran", "IR");
    COUNTRY_ISO_CODES.put("Tanzania", "TZ");
    COUNTRY_ISO_CODES.put("Sri Lanka", "LK");
    COUNTRY_ISO_CODES.put("Samoa", "WS");
    COUNTRY_ISO_CODES.put("Iraq", "IQ");
    COUNTRY_ISO_CODES.put("Sudan", "SD");
    COUNTRY_ISO_CODES.put("Uzbekistan", "UZ");
    COUNTRY_ISO_CODES.put("Myanmar", "MM");
    COUNTRY_ISO_CODES.put("Guyana", "GY");
    COUNTRY_ISO_CODES.put("Guatemala", "GT");
    COUNTRY_ISO_CODES.put("Kyrgyzstan", "KG");
    COUNTRY_ISO_CODES.put("Madagascar", "MG");

    TYPE_TO_ACCELEX_INVESTMENT_TYPE.put("Real Estate", "Real Estate Deals");
    TYPE_TO_ACCELEX_INVESTMENT_TYPE.put("Private Equity", "Private Equity");
    TYPE_TO_ACCELEX_INVESTMENT_TYPE.put("Venture Capital", "Venture Capital");
    TYPE_TO_ACCELEX_INVESTMENT_TYPE.put("Private Debt", "Private Debt Deals");
    TYPE_TO_ACCELEX_INVESTMENT_TYPE.put("Infrastructure", "Infrastructure");
  }

  public static final Set<LPBalanceField> ACCELEX_BALANCE_FIELDS =
      Set.of(
          LPBalanceField.REPORTED_RECALLABLE_DISTRIBUTION_AMOUNT,
          LPBalanceField.REPORTED_TOTAL_COMMITMENT_AMOUNT,
          LPBalanceField.CUM_CONTRIBUTION_AMOUNT,
          LPBalanceField.CUM_DISTRIBUTION_AMOUNT,
          LPBalanceField.NET_IRR,
          LPBalanceField.TVPI,
          LPBalanceField.RVPI,
          LPBalanceField.DPI);
  public static final List<LPField> FUND_MASTER_FIELDS =
      List.of(
          FundMasterField.NAME,
          FundMasterField.TYPE,
          FundMasterField.SUB_TYPE,
          FundMasterField.FUND_CURRENCY,
          FundMasterField.VINTAGE_YEAR,
          FundMasterField.GEOGRAPHY,
          FundMasterField.COUNTRY_OF_DOMICILE,
          FundMasterField.TOTAL_FUND_SIZE,
          FundMasterField.CLEARWATER_ACCOUNT_ID,
          FundMasterField.CLEARWATER_CLIENT_NAME,
          FundMasterField.COMMITMENT_SIZE,
          FundMasterField.CLEARWATER_SECURITY_ID);

  public AccelexService(
      BusinessWSApacheClient businessWSApacheClient,
      LpxDocumentServiceApacheClient lpxDocumentServiceApacheClient,
      PortfolioWsApacheClient portfolioWsApacheClient,
      SecurityResolverClient securityResolverClient,
      AccountConfigServiceCache accountConfigServiceCache,
      AccelexCommonService accelexCommonService,
      TransactionService transactionService,
      LpxFundMasterService fundMasterService,
      BusinessWSCache businessWSCache,
      SecurityService securityService,
      AccountService accountService,
      PortfolioUtilsService portfolioUtilsService,
      FeatureFlagsWSClient featureFlagsWSClient) {
    this.businessWSApacheClient = businessWSApacheClient;
    this.lpxDocumentServiceApacheClient = lpxDocumentServiceApacheClient;
    this.portfolioWsApacheClient = portfolioWsApacheClient;
    this.securityResolverClient = securityResolverClient;
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.accelexCommonService = accelexCommonService;
    this.transactionService = transactionService;
    this.fundMasterService = fundMasterService;
    this.businessWSCache = businessWSCache;
    this.securityService = securityService;
    this.accountService = accountService;
    this.portfolioUtilsService = portfolioUtilsService;
    this.featureFlagsWSClient = featureFlagsWSClient;
  }

  public DataSet<Column> convertBalanceColumnsToAccelexMappingDataSet(
      DataSet<Column> columnDataSet) {
    Set<Long> accountIds =
        DataSetUtils.distinctValuesForIntColumn(columnDataSet, LPBalanceField.ACCOUNT_ID).stream()
            .map(Long::valueOf)
            .collect(Collectors.toSet());
    var ultimateParentMapFromAccounts =
        businessWSApacheClient.getUltimateParentMapFromAccounts(accountIds);
    var combinedDataSet =
        buildDataSetForLPBalanceField(
            LPBalanceField.REPORTED_ENDING_NAV_AMOUNT,
            columnDataSet,
            ultimateParentMapFromAccounts);
    for (LPBalanceField lpBalanceField : ACCELEX_BALANCE_FIELDS) {
      combinedDataSet =
          combinedDataSet
              .query()
              .unionAll(
                  buildDataSetForLPBalanceField(
                      lpBalanceField, columnDataSet, ultimateParentMapFromAccounts))
              .go();
    }
    return combinedDataSet;
  }

  public DataSet<Column> convertBalanceColumnsToAccelexMappingDataSetForAggregates(
      DataSet<Column> columnDataSet) {
    Set<Long> accountIds =
        DataSetUtils.distinctValuesForIntColumn(columnDataSet, LPBalanceField.ACCOUNT_ID).stream()
            .map(Long::valueOf)
            .collect(Collectors.toSet());

    Map<Long, String> accountToClientNames =
        accountConfigServiceCache.getAllAccountConfigs().toFuture().join().stream()
            .filter(c -> accountIds.contains(c.getAccount().getId()))
            .filter(c -> c.getClientName() != null)
            .collect(
                Collectors.groupingBy(
                    AccountConfig::getClientName,
                    Collectors.mapping(c -> c.getAccount().getId(), Collectors.toSet())))
            .entrySet()
            .stream()
            .filter(entry -> entry.getValue().size() == 1)
            .collect(Collectors.toMap(entry -> entry.getValue().iterator().next(), Entry::getKey));

    DataSet<Column> combinedDataSet = null;
    for (LPBalanceField lpBalanceField : ACCELEX_BALANCE_FIELDS) {
      if (combinedDataSet == null) {
        combinedDataSet =
            buildDataSetForLPBalanceFieldForAggregates(
                lpBalanceField, columnDataSet, accountToClientNames);
      } else {
        combinedDataSet =
            combinedDataSet
                .query()
                .unionAll(
                    buildDataSetForLPBalanceFieldForAggregates(
                        lpBalanceField, columnDataSet, accountToClientNames))
                .go();
      }
    }
    return combinedDataSet;
  }

  private DataSet<Column> buildDataSetForLPBalanceFieldForAggregates(
      LPBalanceField lpBalanceField,
      DataSet<Column> columnDataSet,
      Map<Long, String> accountToClientName) {

    return columnDataSet
        .query()
        .extend(row -> "REPORTING", AccelexField.EVENT_TYPE)
        .extend(
            row -> accountToClientName.get(row.getLong(LPBalanceField.ACCOUNT_ID)),
            AccelexField.VEHICLE_NAME)
        .extend(
            row -> getAccelexMetricNameFromBalanceField(lpBalanceField), AccelexField.METRIC_NAME)
        .extend(
            row ->
                convertDateTimeFormat((UTCTimestamp) row.get(LPBalanceField.KNOWLEDGE_START_DATE)),
            AccelexField.REPORT_DATE)
        .extend(
            row -> convertDateFormat((GlobalDate) row.get(LPBalanceField.BALANCE_DATE)),
            AccelexField.DATE)
        .extend(row -> getPeriodFromBalanceField(lpBalanceField), AccelexField.PERIOD)
        .extend(row -> row.get(LPBalanceField.FUND_CURRENCY), AccelexField.CURRENCY)
        .extend(row -> "ACTUAL", AccelexField.VALUE_TYPE)
        .extend(row -> validateValue(row.get(lpBalanceField), lpBalanceField), AccelexField.VALUE)
        .filter(row -> removeNonAccelexEnabledClients(row.getInt(LPBalanceField.ACCOUNT_ID)))
        .exclude(columnDataSet.getHeader().getColumns())
        .go();
  }

  private DataSet<Column> buildDataSetForLPBalanceField(
      LPBalanceField lpBalanceField,
      DataSet<Column> columnDataSet,
      Map<Long, SortedMap<Integer, Long>> ultimateParentMapFromAccounts) {
    return columnDataSet
        .query()
        .extend(row -> "", AccelexField.DOCUMENT_TYPE)
        .extend(
            row -> row.get(LPBalanceField.ACCOUNT_ID) + ":" + row.get(LPBalanceField.SECURITY_ID),
            AccelexField.EVENT_REF)
        .extend(row -> "COMMITMENT", AccelexField.EVENT_TYPE)
        .extend(
            row ->
                getUltimateParentClientId(
                    ultimateParentMapFromAccounts, row.getInt(LPBalanceField.ACCOUNT_ID)),
            AccelexField.VEHICLE_REF)
        .extend(row -> row.get(LPBalanceField.SECURITY_ID), AccelexField.ASSET_REF)
        .extend(
            row -> getAccelexMetricNameFromBalanceField(lpBalanceField), AccelexField.METRIC_NAME)
        .extend(
            row ->
                convertDateTimeFormat((UTCTimestamp) row.get(LPBalanceField.KNOWLEDGE_START_DATE)),
            AccelexField.REPORT_DATE)
        .extend(
            row -> convertDateFormat((GlobalDate) row.get(LPBalanceField.BALANCE_DATE)),
            AccelexField.DATE)
        .extend(row -> getPeriodFromBalanceField(lpBalanceField), AccelexField.PERIOD)
        .extend(row -> row.get(LPBalanceField.FUND_CURRENCY), AccelexField.CURRENCY)
        .extend(row -> validateValue(row.get(lpBalanceField), lpBalanceField), AccelexField.VALUE)
        .extend(row -> row.get(LPBalanceField.DOCUMENT_ID), AccelexField.DOCUMENT_ID)
        .filter(row -> removeNonAccelexEnabledClients(row.getInt(LPBalanceField.ACCOUNT_ID)))
        .exclude(columnDataSet.getHeader().getColumns())
        .go();
  }

  protected static Comparable validateValue(Comparable comparable, LPBalanceField balanceField) {
    if ((balanceField == LPBalanceField.NET_IRR) && (comparable instanceof Double)) {
      return Math.abs((Double) comparable) > 500 ? null : (Double) comparable / 100;
    }
    return comparable;
  }

  private static String getPeriodFromBalanceField(LPBalanceField lpBalanceField) {
    return switch (lpBalanceField) {
      case REPORTED_ENDING_NAV_AMOUNT,
          REPORTED_RECALLABLE_DISTRIBUTION_AMOUNT,
          REPORTED_TOTAL_COMMITMENT_AMOUNT -> "";
      default -> "INCEPTION";
    };
  }

  private boolean removeNonAccelexEnabledClients(int accountId) {
    AccountConfig accountConfig =
        accountConfigServiceCache.getByAccountId(accountId).toFuture().join();
    return (accountConfig.getAttributes().get(LPX_CLARITY) != null)
        && Boolean.parseBoolean(accountConfig.getAttributes().get(LPX_CLARITY));
  }

  public DataSet<Column> convertTransactionColumnsToAccelexMappingDataSet(
      DataSet<Column> columnDataSet) {
    Set<Long> accountIds =
        DataSetUtils.distinctValuesForIntColumn(columnDataSet, LPTransactionField.ACCOUNT_ID)
            .stream()
            .map(Long::valueOf)
            .collect(Collectors.toSet());
    var ultimateParentMapFromAccounts =
        businessWSApacheClient.getUltimateParentMapFromAccounts(accountIds);
    return columnDataSet
        .query()
        .extend(row -> "", AccelexField.DOCUMENT_TYPE)
        .extend(
            row ->
                row.get(LPTransactionField.ACCOUNT_ID)
                    + ":"
                    + row.get(LPTransactionField.SECURITY_ID),
            AccelexField.EVENT_REF)
        .extend(row -> "COMMITMENT", AccelexField.EVENT_TYPE)
        .extend(
            row ->
                getUltimateParentClientId(
                    ultimateParentMapFromAccounts, row.getInt(LPTransactionField.ACCOUNT_ID)),
            AccelexField.VEHICLE_REF)
        .extend(row -> row.get(LPTransactionField.SECURITY_ID), AccelexField.ASSET_REF)
        .extend(row -> "net_payment", AccelexField.METRIC_NAME)
        .extend(
            row ->
                convertDateTimeFormat(
                    (UTCTimestamp) row.get(LPTransactionField.KNOWLEDGE_START_DATE)),
            AccelexField.REPORT_DATE)
        .extend(
            row -> convertDateFormat((GlobalDate) row.get(LPTransactionField.SETTLE_DATE)),
            AccelexField.DATE)
        .extend(row -> "", AccelexField.PERIOD)
        .extend(row -> row.get(LPTransactionField.CURRENCY), AccelexField.CURRENCY)
        .extend(row -> row.get(LPTransactionField.CASH_IMPACT), AccelexField.VALUE)
        .extend(
            row ->
                getAccelexPaymentTypeFromTransactionType(
                    row.getString(LPTransactionField.TYPE),
                    row.getString(LPTransactionField.SUB_TYPE)),
            AccelexField.PAYMENT_TYPE)
        .extend(row -> row.get(LPTransactionField.SUB_TYPE), AccelexField.PAYMENT_SUBTYPE)
        .extend(row -> row.get(LPTransactionField.DOCUMENT_ID), AccelexField.DOCUMENT_ID)
        .filter(row -> !row.getString(AccelexField.PAYMENT_TYPE).isBlank())
        .filter(row -> removeNonAccelexEnabledClients(row.getInt(LPTransactionField.ACCOUNT_ID)))
        .exclude(columnDataSet.getHeader().getColumns())
        .go();
  }

  public static DataSet<Column> createInvestorEntityDataSet(
      Collection<String> clientNames, DataSet<Column> fundEntities) {
    var builder = DataSetBuilder.configureFromReference(fundEntities).createBuilder();
    clientNames.forEach(
        c ->
            builder.addRow(
                c.replace(",", ""),
                "INVESTOR",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                ""));
    return builder.build();
  }

  public DataSet<Column> createFundEntityDataSet(DataSet<Column> columnDataSet) {
    return columnDataSet
        .query()
        .extend(row -> row.get(FundMasterField.NAME), AccelexField.ENTITY_NAME)
        .extend(row -> "FUND", AccelexField.ENTITY_TYPE)
        .extend(row -> "", AccelexField.ENTITY_REF)
        .extend(row -> "", AccelexField.ENTITY_SYNONYMS)
        .extend(row -> "", AccelexField.ENTITY_KEY)
        .extend(
            row ->
                securityService
                    .getSecurity(row.getLong(FundMasterField.CLEARWATER_SECURITY_ID))
                    .subscribeOn(Schedulers.boundedElastic())
                    .toFuture()
                    .join()
                    .getCurrency()
                    .getCode(),
            AccelexField.ENTITY_CURRENCY)
        .extend(
            row ->
                getAccelexFundType(
                        row.getString(FundMasterField.TYPE),
                        row.getString(FundMasterField.SUB_TYPE))
                    .type(),
            AccelexField.TYPE_OF_FUND)
        .extend(
            row ->
                getAccelexFundType(
                        row.getString(FundMasterField.TYPE),
                        row.getString(FundMasterField.SUB_TYPE))
                    .subtype(),
            AccelexField.SUB_TYPE_OF_FUND)
        .extend(row -> row.get(FundMasterField.TOTAL_FUND_SIZE), AccelexField.TOTAL_FUND_SIZE)
        .extend(row -> row.get(FundMasterField.VINTAGE_YEAR), AccelexField.VINTAGE_YEAR)
        .extend(
            row ->
                row.get(FundMasterField.GEOGRAPHY) != null
                    ? row.get(FundMasterField.GEOGRAPHY)
                    : row.get(FundMasterField.COUNTRY_OF_DOMICILE),
            AccelexField.GEOGRAPHIC_FOCUS)
        .extend(
            row -> getCountryISOCode(row.getString(FundMasterField.COUNTRY_OF_DOMICILE)),
            AccelexField.COUNTRY_OF_DOMICILE)
        .extend(row -> "", AccelexField.GICS_SECTOR)
        .extend(row -> "", AccelexField.GICS_INDUSTRY_SECTOR)
        .extend(row -> "", AccelexField.GICS_INDUSTRY)
        .extend(row -> "", AccelexField.INVESTOR_TYPE)
        .exclude(columnDataSet.getHeader().getColumns())
        .go();
  }

  private String getCountryISOCode(String country) {
    return COUNTRY_ISO_CODES.getOrDefault(country, "US");
  }

  private AccelexFundType getAccelexFundType(String type, String subType) {
    return FUND_TYPE_MAPPING.getOrDefault(
        new ClearwaterFundType(type, subType), new AccelexFundType(null, null));
  }

  public static DataSet<Column> createEventDataSet(DataSet<Column> columnDataSet) {
    return columnDataSet
        .query()
        .extend(row -> "COMMITMENT", AccelexField.EVENT_TYPE)
        .extend(row -> row.get(FundMasterField.CLEARWATER_CLIENT_NAME), AccelexField.VEHICLE_NAME)
        .extend(row -> row.get(FundMasterField.NAME), AccelexField.ASSET_NAME)
        .extend(row -> "", AccelexField.EVENT_STATUS)
        .extend(
            row ->
                row.get(FundMasterField.CLEARWATER_ACCOUNT_ID)
                    + ":"
                    + row.get(FundMasterField.CLEARWATER_SECURITY_ID),
            AccelexField.EVENT_REF)
        .extend(
            row -> getInvestmentType(row.getString(FundMasterField.TYPE)),
            AccelexField.INVESTMENT_TYPE)
        .extend(row -> "", AccelexField.DEAL_TYPE)
        .extend(row -> "", AccelexField.SUB_DEAL_TYPE)
        .extend(row -> "", AccelexField.ENTRY_DATE)
        .extend(row -> "", AccelexField.EXIT_DATE)
        .extend(row -> "", AccelexField.COMMITMENT_TYPE)
        .extend(row -> "", AccelexField.COMMITMENT_NAME)
        .extend(row -> row.get(FundMasterField.COMMITMENT_SIZE), AccelexField.COMMITMENT_SIZE)
        .exclude(columnDataSet.getHeader().getColumns())
        .go();
  }

  private static String getInvestmentType(String type) {
    return TYPE_TO_ACCELEX_INVESTMENT_TYPE.getOrDefault(type, null);
  }

  private static String getAccelexPaymentTypeFromTransactionType(
      String transactionType, String subType) {
    return switch (transactionType) {
      case "DVD", "RCAP", "CAPD", "INC" -> "DISTRIBUTION";
      case "CAPC", "EXP" -> "CALL";
      case "FTW" -> {
        if ("TAX_REFUND".equals(subType)) {
          yield "DISTRIBUTION";
        } else {
          yield "CALL";
        }
      }
      default -> "";
    };
  }

  private static String getAccelexMetricNameFromBalanceField(LPBalanceField lpBalanceField) {
    return switch (lpBalanceField) {
      case REPORTED_ENDING_NAV_AMOUNT -> "account_balance";
      case REPORTED_TOTAL_COMMITMENT_AMOUNT -> "total_commitment";
      case REPORTED_RECALLABLE_DISTRIBUTION_AMOUNT -> "recallable_distributions";
      case TVPI -> "tvpi";
      case RVPI -> "rvpi";
      case DPI -> "dpi";
      case NET_IRR -> "irr_net";
      case CUM_CONTRIBUTION_AMOUNT -> "capital_contributions";
      case CUM_DISTRIBUTION_AMOUNT -> "capital_distributions";
      default -> throw new IllegalStateException(
          "Tried to convert an LPBalance field into an Accelex field that has no equivalent");
    };
  }

  public Map<Long, Boolean> getEnabledStatusByAccountIds(Set<Long> accountIds) {
    return accountConfigServiceCache
        .getAccountConfigs(accountIds, LocalDate.now())
        .toFuture()
        .join()
        .stream()
        .collect(
            Collectors.toMap(
                c -> c.getAccount().getId(),
                c ->
                    (c.getAttributes().get(LPX_CLARITY) != null)
                        && Boolean.parseBoolean(c.getAttributes().get(LPX_CLARITY))));
  }

  /**
   * Used for GENERIC FUND DOCUMENTS that have no tie to accountIds and all accounts that hold the
   * fund should get copies of the file.
   *
   * <p>Uploads the document data if we can resolve a Clearwater SecurityId from the CIK for each
   * account that holds the security at the time the document is uploaded.
   *
   * @param documentMetaData
   * @return a list of accountIds that are enabled for Accelex that we uploaded documents to
   */
  public Set<Long> uploadDocumentData(DocumentMetaData documentMetaData) {
    Collection<Long> securityIds = resolveSecurityIds(documentMetaData);
    if (securityIds.isEmpty()) {
      log.error(
          "No security found for identifierType: {}, identifiers: {}",
          documentMetaData.identifierType(),
          documentMetaData.identifierValues());
      return Set.of();
    }
    log.info(
        "Finding accounts that hold generic document: {} for securityIds: {}",
        documentMetaData.documentName(),
        securityIds);
    Set<Long> accelexAccountsWithUploads = new HashSet<>();
    for (Long security : securityIds) {
      Set<Long> accounts =
          portfolioWsApacheClient.getAccountIdsBySecurityId(
              security, documentMetaData.documentDate());
      Map<Long, Boolean> enabledStatusByAccountIds = getEnabledStatusByAccountIds(accounts);
      accelexAccountsWithUploads.addAll(
          accounts.stream().filter(enabledStatusByAccountIds::get).collect(Collectors.toSet()));
      Set<Document> documentsToUpload =
          accounts.stream()
              .map(account -> createBasicDocument(documentMetaData, security, account))
              .collect(Collectors.toSet());
      documentsToUpload.forEach(
          document -> lpxDocumentServiceApacheClient.saveDocument(document, "CANOE"));
    }
    return accelexAccountsWithUploads;
  }

  private Collection<Long> resolveSecurityIds(DocumentMetaData documentMetaData) {
    Set<String> identifierValues =
        Arrays.stream(documentMetaData.identifierValues().split(",")).collect(Collectors.toSet());
    Set<Long> retValue = new HashSet<>();
    // The Canoe variable will be named by operations, therefore we can't assert the
    // exact name they
    // will provide
    if (documentMetaData.identifierType().toLowerCase().contains("cik")) {
      for (String identifierValue : identifierValues) {
        retValue.addAll(securityResolverClient.resolveCIK(identifierValue));
      }
    } else if (documentMetaData.identifierType().toLowerCase().contains("security")) {
      identifierValues.stream().map(Long::parseLong).forEach(retValue::add);
    }
    return retValue;
  }

  private static Document createBasicDocument(
      DocumentMetaData documentMetaData, Long securityId, Long account) {
    return Document.builder()
        .security(Security.builder().securityId(securityId).build())
        .account(Account.builder().id(account).build())
        .documentDate(documentMetaData.documentDate())
        .type(getLPxDocumentType(documentMetaData.documentType()))
        .fileName(documentMetaData.documentName())
        .canoeId(documentMetaData.canoeId())
        .modifiedOn(LocalDateTime.now(ZoneOffset.UTC))
        .modifiedBy("lpx-service")
        .createdOn(LocalDateTime.now(ZoneOffset.UTC))
        .createdBy("lpx-service")
        .dataSource("Canoe")
        .source("lpx-service")
        .canoeId(documentMetaData.canoeId())
        .build();
  }

  private static String getLPxDocumentType(String canoeDocumentType) {
    if ("Financials".equals(canoeDocumentType)) {
      return "Financial Statement";
    }
    return canoeDocumentType;
  }

  public Collection<AccelexPortfolioCompanyEntity> getAccelexPortfolioCompanies(
      Collection<Long> securityIds, LocalDate asOfDate) {
    return accelexCommonService.getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
        securityIds, asOfDate);
  }

  public Collection<AccelexInvestmentsEntity> getAccelexInvestments(
      Collection<Long> securityIds, LocalDate asOfDate) {
    return accelexCommonService.getAccelexInvestmentsBySecurityIds(securityIds, asOfDate);
  }

  public DataSet<Column> getFundEntityReferenceData(
      ReferenceFileType referenceFileType, boolean forUI) {
    Set<AccountConfig> accountConfigsWithClarityEnabled =
        accountConfigServiceCache.getAllAccountConfigsWithAttribute(null, LPX_CLARITY);
    Set<Long> enabledClients =
        accountConfigsWithClarityEnabled.stream()
            .map(AccountConfig::getUltimateParentId)
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());

    Set<Long> automatedReferenceDataClients = new HashSet<>();
    for (Long client : enabledClients) {
      Boolean disabled =
          featureFlagsWSClient.getCachedFeatureFlag(
              Feature.CLIENTS_NOT_TO_SEND_ACCELEX_REFERENCE_DATA_FOR, client.toString());
      if (!disabled) {
        automatedReferenceDataClients.add(client);
      }
    }

    Set<Long> enabledAccounts =
        accountConfigsWithClarityEnabled.stream()
            .filter(c -> automatedReferenceDataClients.contains(c.getUltimateParentId()))
            .map(c -> c.getAccount().getId())
            .collect(Collectors.toSet());

    return getFundEntityReferenceData(enabledAccounts, referenceFileType, forUI);
  }

  public DataSet<Column> getFundEntityReferenceData(
      Set<Long> accountIds, ReferenceFileType referenceFileType, boolean forUI) {
    Map<Long, List<AccountConfig>> enabledAccountConfigs =
        accountConfigServiceCache
            .getAccountConfigs(accountIds, LocalDate.now())
            .toFuture()
            .join()
            .stream()
            .collect(Collectors.groupingBy(c -> c.getAccount().getId()));
    // Get a list of clients on the accounts and above to create as investors
    Collection<Long> clientSet =
        businessWSCache
            .ultimateParentCacheByAccountId(accountIds)
            .subscribeOn(Schedulers.boundedElastic())
            .toFuture()
            .join()
            .values()
            .stream()
            .flatMap(map -> map.values().stream())
            .collect(Collectors.toSet());
    Collection<String> investorsToCreate =
        clientSet.stream()
            .map(
                c ->
                    businessWSCache
                        .getClientData(c)
                        .subscribeOn(Schedulers.boundedElastic())
                        .toFuture()
                        .join()
                        .getName())
            .collect(Collectors.toSet());
    List<Transaction> transactions =
        transactionService
            .getTransactions(
                enabledAccountConfigs.keySet(),
                LocalDate.MIN,
                LocalDate.now(),
                LocalDateTime.now(),
                "TRAN",
                false,
                false)
            .collectList()
            .toFuture()
            .join();
    // total commitment transactions
    Map<LpIdentifier, Double> commitmentByAccount =
        transactions.stream()
            .filter(c -> c.getTotalCommitmentImpact() != null)
            .collect(
                Collectors.groupingBy(
                    c -> new LpIdentifier(c.getAccount().getId(), c.getSecurity().getSecurityId()),
                    Collectors.summingDouble(Transaction::getTotalCommitmentImpact)));
    // accountId -> fundmasterkeys
    Map<Long, List<LpIdentifier>> securityIdsByAccount =
        transactions.stream()
            .filter(c -> OPEN_TRAN_TYPES.contains(c.getType()))
            .map(c -> new LpIdentifier(c.getAccount().getId(), c.getSecurity().getSecurityId()))
            .collect(Collectors.groupingBy(c -> c.accountId));
    Map<FundMasterKey, FundMasterEntity> fundMasterKeyToEntity = new HashMap<>();
    for (Entry<Long, List<LpIdentifier>> entry : securityIdsByAccount.entrySet()) {
      Set<Long> securityIds =
          entry.getValue().stream().map(c -> c.securityId).collect(Collectors.toSet());
      // securityId to fundmasterentity
      Map<Long, FundMasterEntity> fundMasterEntitiesWithOverridesBySecurities =
          fundMasterService.getFundMasterEntitiesWithOverridesBySecurities(
              null, entry.getKey(), securityIds);
      fundMasterKeyToEntity.putAll(
          fundMasterEntitiesWithOverridesBySecurities.entrySet().stream()
              .collect(
                  Collectors.toMap(
                      c ->
                          new FundMasterKey(
                              new LpIdentifier(entry.getKey(), c.getKey()),
                              enabledAccountConfigs.get(entry.getKey()).get(0).getClientName(),
                              commitmentByAccount.get(
                                  new LpIdentifier(entry.getKey(), c.getKey()))),
                      Entry::getValue)));
    }
    if (forUI) {
      Set<LpIdentifier> lpsWithFundMasterOverrides =
          fundMasterKeyToEntity.keySet().stream()
              .map(c -> c.lpIdentifier)
              .collect(Collectors.toSet());
      Set<LpIdentifier> allLps =
          securityIdsByAccount.values().stream()
              .flatMap(Collection::stream)
              .collect(Collectors.toSet());
      allLps.removeAll(lpsWithFundMasterOverrides);
      // fill out blank rows for lps that don't have fund master overrides
      for (LpIdentifier lp : allLps) {
        fundMasterKeyToEntity.put(
            new FundMasterKey(
                lp,
                enabledAccountConfigs.get(lp.accountId).get(0).getClientName(),
                commitmentByAccount.get(lp)),
            new FundMasterEntity()); // creating dummy row to show it isn't filled out to display in
        // UI
      }
    }
    DataSet<Column> columnDataSet =
        convertFundMasterRowsToDataset(fundMasterKeyToEntity, FUND_MASTER_FIELDS);
    if (ReferenceFileType.EVENT_REFERENCE_DATA.equals(referenceFileType)) {
      return createEventDataSet(columnDataSet);
    }
    DataSet<Column> fundEntities = createFundEntityDataSet(columnDataSet);
    DataSet<Column> investorEntities = createInvestorEntityDataSet(investorsToCreate, fundEntities);
    return fundEntities.query().unionAll(investorEntities).go();
  }

  private static DataSet<Column> convertFundMasterRowsToDataset(
      Map<FundMasterKey, FundMasterEntity> fundRows, List<LPField> fundMasterFields) {
    List<List<Object>> data =
        fundRows.entrySet().stream()
            .map(br -> getRowList(br, fundMasterFields))
            .collect(Collectors.toList());
    return DataSetUtils.convertToDataSet(data, fundMasterFields);
  }

  private static List<Object> getRowList(
      Entry<FundMasterKey, FundMasterEntity> fundMasterEntityEntry,
      List<LPField> fundMasterHeader) {
    return fundMasterHeader.stream()
        .map(field -> field.apply(fundMasterEntityEntry))
        .collect(Collectors.toList());
  }

  public record LpIdentifier(Long accountId, Long securityId) {}

  public record FundMasterKey(
      LpIdentifier lpIdentifier, String clientName, Double totalCommitment) {}

  public enum ReferenceFileType {
    ENTITY_REFERENCE_DATA,
    EVENT_REFERENCE_DATA
  }

  public List<LpData> getAccelexEnabledSecuritiesAndAccounts(Long clientId, Integer userId) {
    // This should return a list of Maps
    List<LpData> returnList = new ArrayList<>();
    // get list of accounts from accountService.getClientAccounts
    Map<Long, Account> accountMap =
        accountService
            .getClientAccounts(clientId, userId)
            .collectList()
            .subscribeOn(Schedulers.boundedElastic())
            .toFuture()
            .join()
            .stream()
            .collect(Collectors.toMap(Account::getId, account -> account));
    // get list of accelexEnabled for each account from getEnabledStatusByAccountIds
    Map<Long, Boolean> enabledStatusList =
        getEnabledStatusByAccountIds(
            accountMap.values().stream().map(Account::getId).collect(Collectors.toSet()));
    // get list of securities for accounts from
    // portfolioService.getAllSecuritiesByAccountId
    enabledStatusList.forEach(
        (key, value) -> {
          Account account = accountMap.get(key);
          account.setAttributes(Map.of("LPxClarity", value.toString()));
          Collection<Security> securities =
              portfolioUtilsService
                  .getAllSecuritiesByAccountId(key)
                  .subscribeOn(Schedulers.boundedElastic())
                  .toFuture()
                  .join()
                  .get(key);
          if ((securities != null) && !securities.isEmpty()) {
            securities.stream()
                .filter(s -> s.getSecurityTypeDataDetail().isLimitedPartnership())
                .distinct()
                .forEach(security -> returnList.add(new LpData(account, security)));
          }
        });
    return returnList;
  }

  public record LpData(Account account, Security security) {}

  // Record to hold the Clearwater fund type
  public record ClearwaterFundType(String type, String subtype) {}

  // Record to hold the Accelex fund type
  public record AccelexFundType(String type, String subtype) {}
}
