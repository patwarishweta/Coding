package com.cwan.privatefund.capital.call.scheduling;

import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.CommonConstants.BUFFER_SIZE;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.ScheduledServiceConstants.TIME_FORMAT;

import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.privatefund.capital.call.service.CapitalCallBlacklistService;
import com.cwan.privatefund.capital.call.service.CapitalCallEmailNotificationService;
import com.cwan.privatefund.capital.call.service.LpxCapitalCallService;
import com.cwan.privatefund.leadership.service.LpxLeadershipManager;
import com.cwan.privatefund.util.ExceptionUtils;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/** Scheduled service related to Capital Calls that runs specific tasks at specified intervals. */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallScheduledService {

  private final LpxCapitalCallService capitalCallService;
  private final LpxLeadershipManager leadershipManager;
  private final CapitalCallEmailNotificationService capitalCallEmailNotificationService;
  private final CapitalCallBlacklistService capitalCallBlacklistService;

  /** Scheduled task to evaluate new Capital Calls against a blacklist. */
  @Scheduled(
      fixedRateString = "${scheduler.evaluateCapitalCallsFixedRate}",
      initialDelayString = "${scheduler.initialDelay}")
  public void sendNewCapitalCallNotifications() {
    executeScheduledTask(
        "sendNewCapitalCallNotifications",
        () ->
            capitalCallService
                .getCapitalCallsByStatuses(
                    Collections.singleton(CapitalCallStatus.NEW_CAPITAL_CALL))
                .buffer(BUFFER_SIZE)
                .publishOn(Schedulers.boundedElastic())
                .concatMap(
                    batch ->
                        Flux.fromIterable(batch)
                            .concatMap(
                                document ->
                                    capitalCallBlacklistService
                                        .evaluateBlacklistStatus(document)
                                        .flatMap(
                                            isBlacklisted ->
                                                capitalCallBlacklistService.updateCapitalCallStatus(
                                                    document, isBlacklisted))))
                .concatMap(capitalCallEmailNotificationService::sendNewCapitalCallEmail)
                .subscribeOn(Schedulers.boundedElastic()));
  }

  /** Scheduled task to insert missed Capital Calls into the database. */
  @Scheduled(
      fixedRateString = "${scheduler.insertMissedCapitalCallsFixedRate}",
      initialDelayString = "${scheduler.initialDelay}")
  public void insertMissedCapitalCalls() {
    executeScheduledTask(
        "insertMissedCapitalCalls",
        () -> capitalCallService.insertMissedCapitalCalls().thenMany(Flux.empty()));
  }

  public <T> void executeScheduledTask(String taskName, Supplier<Flux<T>> actionFluxSupplier) {
    var startTime = System.currentTimeMillis();
    runIfLeader(taskName, actionFluxSupplier)
        .doFinally(signalType -> logTaskCompletion(taskName, startTime))
        .onErrorResume(
            e -> {
              var duration = System.currentTimeMillis() - startTime;
              log.error(
                  "Task '{}' failed after {} ms: {}",
                  taskName,
                  duration,
                  ExceptionUtils.getStackTraceAsString(e));
              return Mono.empty();
            })
        .subscribe(
            null,
            error -> {
              var duration = System.currentTimeMillis() - startTime;
              log.error(
                  "Error in '{}' after {} ms: {}",
                  taskName,
                  duration,
                  ExceptionUtils.getStackTraceAsString(error));
            });
  }

  private <T> Flux<T> runIfLeader(String taskName, Supplier<Flux<T>> actionFluxSupplier) {
    return Mono.justOrEmpty(leadershipManager.getLpxLeadershipContext())
        .switchIfEmpty(
            Mono.defer(
                () -> {
                  log.warn("Host not leader for task '{}'. Skipping execution.", taskName);
                  return Mono.empty();
                }))
        .zipWith(fetchReactiveCurrentTime())
        .doOnNext(tuple -> log.info("Triggered task '{}' at {}", taskName, tuple.getT2()))
        .filter(tuple -> tuple.getT1().isLeader())
        .doOnNext(tuple -> log.info("Host is leader. Executing task '{}'", taskName))
        .flatMapMany(tuple -> actionFluxSupplier.get());
  }

  private void logTaskCompletion(String taskName, long startTime) {
    var endTime = System.currentTimeMillis();
    var duration = endTime - startTime;
    log.info("Task '{}' completed and took {} ms", taskName, duration);
  }

  private Mono<String> fetchReactiveCurrentTime() {
    return Mono.fromCallable(
            () -> LocalDateTime.now().format(DateTimeFormatter.ofPattern(TIME_FORMAT)))
        .subscribeOn(Schedulers.boundedElastic());
  }
}
