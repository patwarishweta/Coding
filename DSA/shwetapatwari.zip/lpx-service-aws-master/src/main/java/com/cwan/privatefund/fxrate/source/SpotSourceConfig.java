package com.cwan.privatefund.fxrate.source;

import com.ca.util.date.GlobalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SpotSourceConfig {
  private GlobalDate beginDate;
  private int activitySourceId;
  private int bsSourceId;
  private int rank;
  private Integer basisId;
  private Integer allowedWeekdaysStaleForClientSources;
}
