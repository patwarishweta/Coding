package com.cwan.privatefund.transfer;

import com.cwan.lpx.domain.TransferDestination;
import com.cwan.lpx.domain.TransferRequest;

public class TransferRequestValidator {

  private TransferRequestValidator() {}

  public static boolean validateTransferRequestUnits(TransferRequest transferRequest) {

    double unitTotal =
        transferRequest.destinations().stream().mapToDouble(TransferDestination::units).sum();
    return !(unitTotal > 1 || unitTotal <= 0);
  }
}
