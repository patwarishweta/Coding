package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.privatefund.util.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * Service class for capital call operations. This class provides methods to retrieve the audit log
 * of a capital call document.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallAuditService {

  private final CapitalCalls capitalCalls;

  /**
   * Retrieves the audit log of a capital call document.
   *
   * @param documentId - the id of the document to get the audit log from.
   * @return a Mono with the capital call audit log.
   */
  public Mono<CapitalCallAuditLog> getAuditLog(Long documentId) {
    return capitalCalls
        .getCapitalCallAuditByDocument(documentId)
        .doOnSuccess(
            auditLog ->
                log.debug("Successfully retrieved audit log for document ID {}", documentId))
        .doOnError(
            error ->
                log.error(
                    "Error occurred while retrieving audit log for document id: {}. Error is: {}",
                    documentId,
                    ExceptionUtils.getStackTraceAsString(error)));
  }
}
