package com.cwan.privatefund.salesforce.service;

import com.cwan.privatefund.salesforce.common.SalesforceProperties;
import com.cwan.privatefund.salesforce.config.SaleForceUtils;
import com.cwan.privatefund.salesforce.exception.SalesforceException;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class SalesforceCaseQueryService {

  private static final String CASE_QUERY_URL =
      "https://%s/services/data/v57.0/query?q=SELECT+Id+FROM+Case+WHERE+Capital_Call_Account_ID__c='%s'";
  private final SalesforceCaseCreationService caseCreationService;
  private final RestTemplate restTemplate;
  private final SalesforceProperties salesforceProperties;

  public SalesforceCaseQueryService(
      SalesforceProperties salesforceProperties,
      SalesforceCaseCreationService caseCreationService,
      RestTemplate restTemplate) {
    this.salesforceProperties = salesforceProperties;
    this.caseCreationService = caseCreationService;
    this.restTemplate = restTemplate;
  }

  public String querySalesforceCaseIdOnAccountId(String authToken, String accountId) {
    var queryURL = String.format(CASE_QUERY_URL, salesforceProperties.getSfAuthHost(), accountId);
    var headers = SaleForceUtils.createHttpHeaders(MediaType.APPLICATION_JSON, authToken);
    var entity = new HttpEntity<String>(headers);
    ResponseEntity<JsonNode> responseEntity =
        SaleForceUtils.makeRequest(restTemplate, queryURL, HttpMethod.GET, entity, JsonNode.class);
    if (responseEntity.getStatusCode() != HttpStatus.OK) {
      throw new SalesforceException(
          "Error: " + responseEntity.getStatusCode() + ", Message: " + responseEntity.getBody());
    }
    var totalSize =
        Optional.ofNullable(responseEntity.getBody())
            .map(body -> body.get("totalSize").asInt())
            .orElse(0);
    if (totalSize < 1) {
      log.info("Generating a case for account: {}", accountId);
      return caseCreationService.createSalesforceCase(authToken, accountId);
    }
    var caseId =
        Optional.ofNullable(responseEntity.getBody())
            .map(body -> body.get("records").get(0).get("Id").asText())
            .orElse(null);
    if (caseId == null) {
      throw new SalesforceException("No case ID returned in response body");
    }
    log.info("A case ID is already present for account: {}, ID: {}", accountId, caseId);
    return caseId;
  }
}
