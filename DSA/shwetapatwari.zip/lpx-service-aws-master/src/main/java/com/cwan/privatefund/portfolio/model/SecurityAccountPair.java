package com.cwan.privatefund.portfolio.model;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class SecurityAccountPair {

  private Security security;
  private Account account;
}
