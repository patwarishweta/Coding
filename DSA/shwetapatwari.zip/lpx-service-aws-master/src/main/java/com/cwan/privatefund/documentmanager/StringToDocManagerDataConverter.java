package com.cwan.privatefund.documentmanager;

import com.ca.json2.utils.JsonUtils2;
import lombok.NonNull;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class StringToDocManagerDataConverter implements Converter<String, DocumentManagerData> {

  @Override
  public DocumentManagerData convert(@NonNull String source) {
    return JsonUtils2.parseJson(source, DocumentManagerData.class);
  }
}
