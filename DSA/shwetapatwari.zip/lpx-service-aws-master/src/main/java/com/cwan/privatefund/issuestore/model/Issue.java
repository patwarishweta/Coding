package com.cwan.privatefund.issuestore.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Issue {

  private UUID identifier;
  private String sourceName;
  private LocalDate startDate;
  private IssueStatus status;
  private String typeName;
  private String note;
  private LocalDate endDate;
  private LocalDateTime createdDateTime;
  private String metaData;
  private Map<String, List<String>> attributes;
}
