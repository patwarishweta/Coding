package com.cwan.privatefund.canoeFundMapping.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "canoe_fund_mapping", catalog = "pabor")
public class CanoeFundMappingEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private String customAllocationId;

  private String canoeAccountName;
  private String canoeClientName;
  private String canoeSecurityName;
  private Long accountId;
  private String accountName;
  private Long securityId;
  private String securityName;
  private Long ultimateParentId;
  private String ultimateParentName;
  private Long clientId;
  private String clientName;
  private String issuerName;
  private String canoeConnect;
}
