package com.cwan.privatefund.fxrate;

import static java.lang.String.valueOf;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import com.cwan.privatefund.fxrate.source.AccountSpotSourceHistory;
import com.cwan.privatefund.fxrate.source.SpotSourceConfig;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FxServiceApacheClient {

  private final WsHttpClient wsHttpClient;
  private final Resource sourceHistoryResource;
  private final Resource fxRateResource;
  private final AuthTokenCore authTokenCore;
  private static final String DATE_FORMAT = "MM/dd/yyyy";

  public FxServiceApacheClient(
      WsHttpClient wsHttpClient,
      ServerConfiguration serverConfiguration,
      AuthTokenCore authTokenCore) {
    this.wsHttpClient = wsHttpClient;
    this.authTokenCore = authTokenCore;
    this.sourceHistoryResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("spot/sourceHistory/basis")
            .withAcceptType(MimeType.JSON)
            .toResource();
    this.fxRateResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("spot/rates/sparse")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public AccountSpotSourceHistory getSourceHistory(Long accountId) {
    GetRequest request =
        sourceHistoryResource
            .doGET(wsHttpClient)
            .withHeader("Authorization", "Bearer " + authTokenCore.createApplicationToken())
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addQueryParam("accountId", accountId)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error("FxServiceApacheClient getSourceHistory for account: {}", accountId, e);
      throw new RuntimeException(e);
    }
  }

  public Set<AccountFxSource> getAccountFxSources(Long accountId) {
    AccountSpotSourceHistory sourceHistory = getSourceHistory(accountId);
    Set<AccountFxSource> sources =
        sourceHistory.getDefaultSortedHistory().stream()
            .map(config -> createAccountFxSource(accountId, config))
            .collect(Collectors.toSet());
    sources.addAll(
        sourceHistory.getSortedHistoriesByBasisId().values().stream()
            .flatMap(Collection::stream)
            .map(config -> createAccountFxSource(accountId, config))
            .collect(Collectors.toSet()));
    return sources;
  }

  private AccountFxSource createAccountFxSource(Long accountId, SpotSourceConfig spotSourceConfig) {
    return AccountFxSource.builder()
        .accountId(accountId)
        .date(spotSourceConfig.getBeginDate().getLocalDate())
        .fxRateSourceId((long) spotSourceConfig.getBsSourceId())
        .rankId(spotSourceConfig.getRank())
        .basisId(
            spotSourceConfig.getBasisId() == null
                ? AccountFxSource.NOT_BASIS_SPECIFIC_ID
                : spotSourceConfig.getBasisId())
        .modifiedOn(LocalDateTime.now(ZoneOffset.UTC))
        .build();
  }

  public Map<String, Map<String, Map<String, Double>>> getFxRate(
      Long sourceId, LocalDate beginDate, LocalDate endDate, Long currencyId) {
    GetRequest request =
        fxRateResource
            .doGET(wsHttpClient)
            .withHeader("Authorization", "Bearer " + authTokenCore.createApplicationToken())
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addQueryParam("sourceIds", sourceId)
            .addQueryParam("beginDate", beginDate)
            .addQueryParam("endDate", endDate)
            .addQueryParam("currencyIds", currencyId)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error(
          "FxServiceApacheClient getFxRate for sourceId: {}, beginDate: {}, endDate: {}, currencyId: {}",
          sourceId,
          beginDate,
          endDate,
          currencyId,
          e);
      throw new RuntimeException(e);
    }
  }

  public TreeMap<LocalDate, Double> getFxRateMap(
      LocalDate startDate, LocalDate endDate, Long sourceId, Long currencyId) {
    Map<String, Map<String, Map<String, Double>>> fxRateMap =
        getFxRate(sourceId, startDate, endDate, currencyId);
    Map<String, Double> dateToFxRate =
        fxRateMap
            .getOrDefault(valueOf(sourceId), new TreeMap<>())
            .getOrDefault(valueOf(currencyId), new TreeMap<>());
    return dateToFxRate.entrySet().stream()
        .collect(
            Collectors.toMap(
                entry -> getLocalDateFromString(entry.getKey()),
                Entry::getValue,
                (a, b) -> b,
                TreeMap::new));
  }

  private static LocalDate getLocalDateFromString(String localDate) {
    return LocalDate.parse(localDate, DateTimeFormatter.ofPattern(DATE_FORMAT));
  }
}
