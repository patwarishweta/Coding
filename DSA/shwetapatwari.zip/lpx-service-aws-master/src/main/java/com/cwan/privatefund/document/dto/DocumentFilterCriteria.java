package com.cwan.privatefund.document.dto;

import com.cwan.privatefund.document.validation.ValidDateRange;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;
import java.util.Collection;
import lombok.Builder;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.format.annotation.DateTimeFormat;

@Builder
@ValidDateRange
public record DocumentFilterCriteria(
    @NotEmpty(message = "At least one account ID is required")
        Collection<@Positive(message = "Account IDs must be positive numbers") Long> accountIds,
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @NotNull(message = "Begin date is required")
        LocalDate beginDate,
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @NotNull(message = "End date is required")
        LocalDate endDate,
    Collection<@Positive(message = "Security IDs must be positive numbers") Long> securityIds) {

  @Override
  public Collection<Long> accountIds() {
    return CollectionUtils.emptyIfNull(accountIds);
  }

  @Override
  public Collection<Long> securityIds() {
    return CollectionUtils.emptyIfNull(securityIds);
  }
}
