package com.cwan.privatefund.watchlist;

import com.cwan.privatefund.watchlist.model.Watchlist;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class WatchlistEntityTransformer implements Function<Watchlist, WatchlistEntity> {

  @Override
  public WatchlistEntity apply(Watchlist watchlist) {
    return WatchlistEntity.builder()
        .id(watchlist.getId())
        .accountId(watchlist.getAccountId())
        .securityId(watchlist.getSecurityId())
        .startDate(watchlist.getStartDate())
        .endDate(watchlist.getEndDate())
        .createdBy(watchlist.getCreatedBy())
        .tsCreatedOn(watchlist.getCreatedOn())
        .modifiedBy(watchlist.getModifiedBy())
        .tsModifiedOn(watchlist.getModifiedOn())
        .build();
  }
}
