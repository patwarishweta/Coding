package com.cwan.privatefund.capital.call.management.model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankCreationRequest(
    @NotNull(message = "Client ID cannot be null")
        @Min(value = 1, message = "Client ID must be greater than 0")
        Long clientId,
    @NotBlank(message = "Bank name cannot be blank")
        @Size(max = 500, message = "Bank name cannot exceed 500 characters")
        String bankName,
    @Size(max = 50, message = "ABA Routing Number cannot exceed 50 characters")
        String abaRoutingNumber,
    @Size(max = 50, message = "SWIFT/CHIPS code cannot exceed 50 characters") String swiftChipsCode)
    implements Serializable {

  public static class BankCreationRequestBuilder {

    public BankCreationRequest.BankCreationRequestBuilder bankName(String bankName) {
      this.bankName = StringUtils.trimToNull(StringUtils.normalizeSpace(bankName));
      return this;
    }

    public BankCreationRequest.BankCreationRequestBuilder abaRoutingNumber(
        String abaRoutingNumber) {
      this.abaRoutingNumber = StringUtils.trimToNull(StringUtils.normalizeSpace(abaRoutingNumber));
      return this;
    }

    public BankCreationRequest.BankCreationRequestBuilder swiftChipsCode(String swiftChipsCode) {
      this.swiftChipsCode = StringUtils.trimToNull(StringUtils.normalizeSpace(swiftChipsCode));
      return this;
    }
  }
}
