package com.cwan.privatefund.feature;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeatureKeyResponse implements Serializable {

  @Serial private static final long serialVersionUID = -336892361539011037L;
  private String id;
  private Long createdTime;
  private Boolean enabled;
}
