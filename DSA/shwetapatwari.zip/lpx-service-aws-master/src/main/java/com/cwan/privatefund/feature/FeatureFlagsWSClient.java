package com.cwan.privatefund.feature;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.cache.Cache;
import java.io.InputStream;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FeatureFlagsWSClient {
  private final WsHttpClient wsHttpClient;
  private final Resource keyedFeatureResource;
  private final Cache<String, FeatureResponse> enabledFeatureToResponseCache;

  public FeatureFlagsWSClient(
      WsHttpClient wsHttpClient,
      ServerConfiguration serverConfiguration,
      Cache<String, FeatureResponse> enabledFeatureToResponseCache) {
    this.wsHttpClient = wsHttpClient;
    this.enabledFeatureToResponseCache = enabledFeatureToResponseCache;
    this.keyedFeatureResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("application/lpx/feature/{featureName}")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public Boolean getCachedFeatureFlag(Feature featureName, String keyName) {
    FeatureResponse featureResponse;
    try {
      featureResponse =
          enabledFeatureToResponseCache.get(
              featureName.name(), () -> getFeatureFlag(featureName.name()));
    } catch (ExecutionException e) {
      return false;
    }

    if (featureResponse.isEnabled()) {
      if (featureResponse.getKeys().isEmpty()) {
        return true; // if there are no keys and the feature is enabled the feature is enabled for
        // all uses.
      }
      return featureResponse.getKeys().stream()
          .filter(key -> key.getId().equals(keyName))
          .map(FeatureKeyResponse::getEnabled)
          .findFirst()
          .orElse(false);
    }
    return false;
  }

  public Set<String> getEnabledKeysForFeature(Feature featureName) {
    try {
      FeatureResponse featureResponse =
          enabledFeatureToResponseCache.get(
              featureName.name(), () -> getFeatureFlag(featureName.name()));

      if (featureResponse.isEnabled() && featureResponse.getKeys() != null) {
        return featureResponse.getKeys().stream()
            .filter(FeatureKeyResponse::getEnabled)
            .map(FeatureKeyResponse::getId)
            .collect(Collectors.toSet());
      }
    } catch (ExecutionException ignored) {
    }
    return null;
  }

  protected FeatureResponse getFeatureFlag(String feature) {
    log.info("Getting feature flag for feature: {}", feature);
    GetRequest request =
        keyedFeatureResource
            .doGET(wsHttpClient)
            .withPathParam("featureName", feature)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (Exception e) {
      log.error("Error getting feature flag for feature: {}", feature, e);
      return new FeatureResponse();
    }
  }
}
