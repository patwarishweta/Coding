package com.cwan.privatefund.watchlist.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class Watchlist implements Serializable {

  @Serial private static final long serialVersionUID = -1698702913884979638L;
  private Long id;

  private Long accountId;
  private Long securityId;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate startDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate endDate;

  private String createdBy;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate createdOn;

  private String modifiedBy;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate modifiedOn;
}
