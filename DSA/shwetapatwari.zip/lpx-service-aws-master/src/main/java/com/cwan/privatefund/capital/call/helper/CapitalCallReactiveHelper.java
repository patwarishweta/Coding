package com.cwan.privatefund.capital.call.helper;

import java.util.NoSuchElementException;
import reactor.core.publisher.Mono;

public final class CapitalCallReactiveHelper {

  public static <T> Mono<T> validateNotEmptyOrElseThrow(Mono<T> mono, String uuid) {
    return mono.switchIfEmpty(
        Mono.error(new NoSuchElementException("Details with UUID " + uuid + " not found.")));
  }

  private CapitalCallReactiveHelper() {
    // Adding a private constructor to hide the implicit public one.
  }
}
