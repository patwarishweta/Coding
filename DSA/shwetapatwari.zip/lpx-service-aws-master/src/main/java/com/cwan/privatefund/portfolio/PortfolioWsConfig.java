package com.cwan.privatefund.portfolio;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient.PortfolioLot;
import com.cwan.privatefund.portfolio.model.PortfolioData;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class PortfolioWsConfig {

  @Value("${portfolio.ws.base.url}")
  private String portfolioWsBaseUrl;

  @Value("${portfolio.ws.base.server}")
  private String portfolioWsBaseServer;

  @Value("${portfolio.ws.memory.maxsize}")
  private Integer maxInMemorySize;

  @Bean(value = "portfolioWebServiceClient")
  WebClient portfolioWsClient(ReactorClientHttpConnector reactorClientHttpConnector) {
    return WebClient.builder()
        .clientConnector(reactorClientHttpConnector)
        .baseUrl(portfolioWsBaseUrl)
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(maxInMemorySize))
                .build())
        .build();
  }

  @Bean(value = "portfolioWsApacheClient")
  PortfolioWsApacheClient portfolioWebApacheClient(
      Cache<Long, List<PortfolioLot>> accountToPortfolioLotsCache) {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(portfolioWsBaseServer, 443, "portfolio-ws", Resource.Scheme.HTTPS);
    return new PortfolioWsApacheClient(
        WsHttpClientBuilder.getSharedDefault(), serverConfiguration, accountToPortfolioLotsCache);
  }

  @Bean(value = "portfolioAccountSecurityCache")
  public Cache<Long, List<PortfolioData>> portfolioAccountSecurityCache() {
    return CacheBuilder.newBuilder().maximumSize(50000).expireAfterWrite(4, TimeUnit.HOURS).build();
  }

  @Bean(value = "accountToPortfolioLotsCache")
  public Cache<Long, List<PortfolioLot>> accountToPortfolioLotsCache() {
    return CacheBuilder.newBuilder().maximumSize(50000).expireAfterWrite(4, TimeUnit.HOURS).build();
  }
}
