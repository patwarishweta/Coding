package com.cwan.privatefund.calculated.model;

import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.pbor.trans.Constants.TransactionBasisAffects;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
public class BalanceTypeKey {
  private final BalanceType balanceType;
  private final String basisAffect;

  public BalanceTypeKey(BalanceType balanceType, String basisAffect) {
    this.balanceType = balanceType;
    this.basisAffect = basisAffect == null ? TransactionBasisAffects.ALL : basisAffect;
  }
}
