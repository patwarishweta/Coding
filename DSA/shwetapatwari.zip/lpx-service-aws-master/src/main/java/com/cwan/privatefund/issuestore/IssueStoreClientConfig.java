package com.cwan.privatefund.issuestore;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class IssueStoreClientConfig {

  private final ObjectMapper objectMapper;

  @Value("${issue.store.base.url}")
  private String issueStoreBaseUrl;

  public IssueStoreClientConfig(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  @Bean(value = "issueStoreWebClient")
  WebClient issueStoreClient() {
    return WebClient.builder()
        .baseUrl(issueStoreBaseUrl)
        // Adding this exchange Strategy because LocalDateTime fields are not serializing properly
        // And by adding @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss[.SSS]) breaks deserialization
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(
                    configurer -> {
                      configurer
                          .defaultCodecs()
                          .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                      configurer
                          .defaultCodecs()
                          .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                    })
                .build())
        .build();
  }
}
