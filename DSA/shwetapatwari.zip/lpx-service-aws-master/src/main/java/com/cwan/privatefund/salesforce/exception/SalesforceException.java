package com.cwan.privatefund.salesforce.exception;

import com.ca.client.WsClientException;
import java.io.Serial;

public class SalesforceException extends WsClientException {

  @Serial private static final long serialVersionUID = -357666336026802894L;

  public SalesforceException(String message) {
    super(message);
  }
}
