package com.cwan.privatefund.documentcashflow;

import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.pbor.cashflow.documentcashflow.api.DocumentCashflows;
import com.cwan.privatefund.publisher.MessagePublisher;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/cash-flows")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class DocumentCashflowController {

  private final DocumentCashflows documentCashflows;
  private final DocumentCashflowHydrationService hydrationService;
  private final MessagePublisher<DocumentCashFlow> documentCashFlowMessagePublisher;

  public DocumentCashflowController(
      DocumentCashflows documentCashflows,
      DocumentCashflowHydrationService hydrationService,
      MessagePublisher<DocumentCashFlow> documentCashFlowMessagePublisher) {
    this.documentCashflows = documentCashflows;
    this.hydrationService = hydrationService;
    this.documentCashFlowMessagePublisher = documentCashFlowMessagePublisher;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add document cashflows")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added Document Cashflow successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentCashFlow.class))
            })
      })
  public Mono<Void> addDocumentCashflows(
      @Parameter(description = "Document Cashflow") @RequestBody
          DocumentCashFlow documentCashFlow) {
    documentCashFlowMessagePublisher.publishMessage(
        documentCashFlow,
        Map.of("messageGroupId", documentCashFlow.getDocument().getId().toString()),
        true);
    return Mono.empty();
  }

  @PutMapping
  @ResponseStatus(HttpStatus.ACCEPTED)
  @Operation(summary = "Update Document Cashflows")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Updated Document Cashflow successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentCashflows.class))
            })
      })
  public Mono<Void> updateDocumentCashflows(
      @Parameter(description = "Document Data") @RequestBody DocumentCashFlow documentCashFlow) {
    documentCashFlowMessagePublisher.publishMessage(
        documentCashFlow,
        Map.of("messageGroupId", documentCashFlow.getDocument().getId().toString()),
        true);
    return Mono.empty();
  }

  @GetMapping(value = "/document/{documentId}")
  @Operation(summary = "Get document cashflows by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentCashFlow.class))
            })
      })
  public Mono<DocumentCashFlow> getDocumentCashflow(@PathVariable("documentId") Long documentId) {
    return documentCashflows
        .getCashflowsByDocumentId(documentId)
        .collectList()
        .flatMap(documentCashflowList -> hydrationService.hydrate(documentCashflowList, documentId))
        .filter(documentCashFlows -> !documentCashFlows.isEmpty())
        .flatMap(documentCashFlows -> Mono.just(documentCashFlows.get(0)));
  }
}
