package com.cwan.privatefund.document.exception;

import com.cwan.privatefund.document.validation.ValidDateRange;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.Builder;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

@Builder
@ValidDateRange
public record ValidationErrorResponse(
    int status, String message, LocalDateTime timestamp, Map<String, String> errors) {

  public static ValidationErrorResponse of(int status, String message, Map<String, String> errors) {
    return ValidationErrorResponse.builder()
        .status(status)
        .message(StringUtils.defaultIfEmpty(message, "Validation failed"))
        .timestamp(LocalDateTime.now())
        .errors(MapUtils.emptyIfNull(errors))
        .build();
  }
}
