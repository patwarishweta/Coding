package com.cwan.privatefund.logger;

import jakarta.annotation.Nonnull;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class LPxServiceWebLoggerFilter implements WebFilter {

  private static final int MAX_LOG_LENGTH = 8000;
  private static final Pattern WHITESPACE_PATTERN = Pattern.compile("[\\r\\n\\t]");
  private static final Set<String> EXCLUDED_PATHS = Set.of("/actuator/health", "/status");

  @Override
  public @Nonnull Mono<Void> filter(@Nonnull ServerWebExchange exchange, WebFilterChain chain) {
    var decorator = new LPxServiceHttpLogDecorator(exchange);
    return chain.filter(decorator).doOnSuccess(se -> logRequest(decorator));
  }

  private static void logRequest(LPxServiceHttpLogDecorator decorator) {
    var path = decorator.getRequest().getPath().toString();
    if (EXCLUDED_PATHS.stream().noneMatch(path::contains)) {
      log.info("Request received: {}", getRequestMessage(decorator.getRequest()));
      log.info(
          "Response returned: status={}, body={}",
          decorator.getResponse().getStatusCode(),
          sanitizeAndTruncateLogMessage(decorator.getResponse().getResponseBody()));
    }
  }

  private static String getRequestMessage(RequestBodyContentWrapper request) {
    var queryParams = request.getQueryParams().toString();
    return String.format(
        "uri=%s%s;method=%s;client=%s;payload=%s",
        request.getPath(),
        StringUtils.isNotBlank(queryParams) ? "?" + queryParams : "",
        request.getMethod(),
        request.getRemoteAddress(),
        sanitizeAndTruncateLogMessage(Optional.ofNullable(request.getPayload()).orElse("")));
  }

  private static String sanitizeAndTruncateLogMessage(String message) {
    return Optional.ofNullable(message)
        .map(msg -> WHITESPACE_PATTERN.matcher(msg).replaceAll(" "))
        .filter(msg -> msg.length() > MAX_LOG_LENGTH)
        .map(msg -> msg.substring(0, MAX_LOG_LENGTH) + "...[truncated]")
        .orElse(message);
  }
}
