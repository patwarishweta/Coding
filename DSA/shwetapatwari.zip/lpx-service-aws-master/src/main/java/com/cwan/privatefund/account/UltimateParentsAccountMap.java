package com.cwan.privatefund.account;

import com.cwan.lpx.domain.Account;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UltimateParentsAccountMap {
  private Integer ultimateParentId;
  private List<Account> accounts;
}
