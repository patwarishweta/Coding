package com.cwan.privatefund.fxrate.source;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@EqualsAndHashCode
public class AccountFxSourceKey implements Serializable {

  @Serial private static final long serialVersionUID = 7351223847506724113L;

  private Long accountId;
  private LocalDate date;
  private Integer basisId;
  private Integer rankId;
}
