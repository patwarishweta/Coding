package com.cwan.privatefund.watchlist;

import com.cwan.privatefund.watchlist.model.Watchlist;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class WatchlistTransformer implements Function<WatchlistEntity, Watchlist> {

  @Override
  public Watchlist apply(WatchlistEntity watchlistEntity) {
    return Watchlist.builder()
        .id(watchlistEntity.getId())
        .accountId(watchlistEntity.getAccountId())
        .securityId(watchlistEntity.getSecurityId())
        .startDate(watchlistEntity.getStartDate())
        .endDate(watchlistEntity.getEndDate())
        .createdBy(watchlistEntity.getCreatedBy())
        .createdOn(watchlistEntity.getTsCreatedOn())
        .modifiedBy(watchlistEntity.getModifiedBy())
        .modifiedOn(watchlistEntity.getTsModifiedOn())
        .build();
  }
}
