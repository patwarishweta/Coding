package com.cwan.privatefund.salesforce.common;

import com.cwan.privatefund.config.properties.SalesforceConfigProperties;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Component
public class SalesforceProperties {

  @Getter
  @Value("${salesforce.authHost}")
  private String sfAuthHost;

  @Getter
  @Value("${salesforce.instanceHost}")
  private String sfInstanceHost;

  @Getter
  @Value("${salesforce.recordTypeId}")
  private String sfRecordTypeID;

  private final SalesforceConfigProperties salesforceConfigProperties;

  public SalesforceProperties(SalesforceConfigProperties salesforceConfigProperties) {
    this.salesforceConfigProperties = salesforceConfigProperties;
  }

  public String getClientId() {
    return salesforceConfigProperties.getClientId();
  }

  public String getClientSecret() {
    return salesforceConfigProperties.getClientSecret();
  }
}
