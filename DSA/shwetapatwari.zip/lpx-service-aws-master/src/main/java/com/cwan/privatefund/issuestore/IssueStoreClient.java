package com.cwan.privatefund.issuestore;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.issuestore.model.Issue;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class IssueStoreClient {

  private final WebClient issueStoreWebClient;
  private final String sourceName;
  private final AuthTokenCore authTokenCore;

  public IssueStoreClient(
      WebClient issueStoreWebClient,
      @Value("${issue.store.source.name}") String sourceName,
      AuthTokenCore authTokenCore) {
    this.issueStoreWebClient = issueStoreWebClient;
    this.sourceName = sourceName;
    this.authTokenCore = authTokenCore;
  }

  public Flux<Issue> getIssuesByTag(String tag) {
    return issueStoreWebClient
        .get()
        .uri(
            uriBuilder -> uriBuilder.path("/api/v1/tags/{tag}/{sourceName}").build(tag, sourceName))
        .accept(MediaType.APPLICATION_JSON)
        .exchangeToMono(response -> response.bodyToMono(Issue[].class))
        .flux()
        .flatMap(issues -> Flux.fromIterable(Arrays.asList(issues)));
  }

  public Flux<Issue> getIssuesByTypeName(String typeName) {
    return issueStoreWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/api/v1/types/{typeName}/sources/{sourceName}")
                    .build(typeName, sourceName))
        .accept(MediaType.APPLICATION_JSON)
        .exchangeToMono(response -> response.bodyToMono(Issue[].class))
        .flux()
        .flatMap(issues -> Flux.fromIterable(Arrays.asList(issues)));
  }

  public Mono<Issue> updateIssue(Issue issue) {
    return issueStoreWebClient
        .put()
        .uri(
            uriBuilder ->
                uriBuilder.path("/api/v1/issues/{identifier}").build(issue.getIdentifier()))
        .headers(httpHeaders -> httpHeaders.setBearerAuth(authTokenCore.createApplicationToken()))
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(issue), Issue.class)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(Issue.class);
  }
}
