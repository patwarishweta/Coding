package com.cwan.privatefund.auth;

import java.io.Serial;

public class AuthenticationException extends RuntimeException {

  @Serial private static final long serialVersionUID = 2572211696556746L;

  public AuthenticationException(String msg) {
    super(msg);
  }
}
