package com.cwan.privatefund.calculated.model;

import java.io.Serial;

public class CalculatedBalanceException extends RuntimeException {

  @Serial private static final long serialVersionUID = -7519239645042233754L;

  public CalculatedBalanceException(String msg, Throwable cause) {
    super(msg, cause);
  }
}
