package com.cwan.privatefund.capital.call.management.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankResponse(
    String bankUuid,
    Long clientId,
    String clientName,
    String bankName,
    String abaRoutingNumber,
    String swiftChipsCode,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdAt,
    String creatorName,
    String creatorEmail)
    implements Serializable {

  public static class BankResponseBuilder {

    public BankResponse.BankResponseBuilder bankUuid(String bankUuid) {
      this.bankUuid = StringUtils.trimToNull(StringUtils.normalizeSpace(bankUuid));
      return this;
    }

    public BankResponse.BankResponseBuilder clientName(String clientName) {
      this.clientName = StringUtils.trimToNull(StringUtils.normalizeSpace(clientName));
      return this;
    }

    public BankResponse.BankResponseBuilder bankName(String bankName) {
      this.bankName = StringUtils.trimToNull(StringUtils.normalizeSpace(bankName));
      return this;
    }

    public BankResponse.BankResponseBuilder abaRoutingNumber(String abaRoutingNumber) {
      this.abaRoutingNumber = StringUtils.trimToNull(StringUtils.normalizeSpace(abaRoutingNumber));
      return this;
    }

    public BankResponse.BankResponseBuilder swiftChipsCode(String swiftChipsCode) {
      this.swiftChipsCode = StringUtils.trimToNull(StringUtils.normalizeSpace(swiftChipsCode));
      return this;
    }

    public BankResponse.BankResponseBuilder creatorName(String creatorName) {
      this.creatorName = StringUtils.trimToNull(StringUtils.normalizeSpace(creatorName));
      return this;
    }

    public BankResponse.BankResponseBuilder creatorEmail(String creatorEmail) {
      this.creatorEmail = StringUtils.trimToNull(StringUtils.normalizeSpace(creatorEmail));
      return this;
    }
  }
}
