package com.cwan.privatefund;

import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.portfolio.PortfolioWsClient;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import reactor.core.scheduler.Schedulers;

@Component
@Slf4j
public class CacheLoadOnStartUp {

  @Value("${cacheLoadOnStartUp.isEnabled:false}")
  private Boolean isEnabled;

  private final AccountConfigServiceCache accountConfigServiceCache;
  private final BusinessWSCache businessWSCache;
  private final PortfolioWsClient portfolioWsClient;
  private final SecurityService securityService;

  public CacheLoadOnStartUp(
      AccountConfigServiceCache accountConfigServiceCache,
      BusinessWSCache businessWSCache,
      PortfolioWsClient portfolioWsClient,
      SecurityService securityService) {
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.businessWSCache = businessWSCache;
    this.portfolioWsClient = portfolioWsClient;
    this.securityService = securityService;
  }

  @EventListener(ApplicationReadyEvent.class)
  public void runAfterStartup() {
    Optional.ofNullable(isEnabled)
        .ifPresentOrElse(
            enabled -> {
              if (Boolean.FALSE.equals(enabled)) {
                log.info("Cache loading is disabled.");
              } else {
                loadCache();
              }
            },
            this::loadCache);
  }

  private void loadCache() {
    log.info("Loading cache...");
    accountConfigServiceCache
        .getAllAccountConfigs()
        .flatMapIterable(accountConfigs -> accountConfigs)
        .map(accountConfig -> accountConfig.getAccount().getId())
        .publishOn(Schedulers.parallel())
        .map(businessWSCache::getExpandedAccountIds)
        .flatMap(Function.identity())
        .flatMapIterable(Function.identity())
        .publishOn(Schedulers.boundedElastic())
        .map(businessWSCache::getAccountData)
        .flatMap(Function.identity())
        .map(BusinessAccount::getId)
        .collectList()
        .publishOn(Schedulers.boundedElastic())
        .flatMap(
            accountIds ->
                businessWSCache
                    .ultimateParentCacheByAccountId(Set.copyOf(accountIds))
                    .thenReturn(accountIds))
        .publishOn(Schedulers.immediate())
        .map(portfolioWsClient::getPortfolioDataWithCacheCheck)
        .flatMapMany(Function.identity())
        .flatMapIterable(Function.identity())
        .map(
            portfolioData ->
                securityService
                    .getSecurity(null, portfolioData.getAccountId(), portfolioData.getSecurityId())
                    .map(security -> portfolioData))
        .flatMap(Function.identity())
        .map(
            portfolioData ->
                accountConfigServiceCache
                    .getByAccountId(portfolioData.getAccountId())
                    .map(
                        accountConfig ->
                            ImmutableTriple.of(
                                portfolioData.getAccountId(),
                                portfolioData.getSecurityId(),
                                accountConfig.getSubscriptionStartDate())))
        .flatMap(Function.identity())
        .filter(
            accSecurityDateImmutableTriple ->
                !accSecurityDateImmutableTriple.right.isEqual(LocalDate.of(1900, 1, 1)))
        .publishOn(Schedulers.parallel())
        .subscribe();
  }
}
