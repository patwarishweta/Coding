package com.cwan.privatefund.business.ws;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.constant.RedisConstants;
import com.cwan.privatefund.redis.ScheduledRedisEvictionCacheService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/business")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class BusinessWsController {

  private final BusinessWSCache businessWSCache;
  private final AccountService accountService;
  private final ScheduledRedisEvictionCacheService scheduledRedisEvictionCacheService;

  public BusinessWsController(
      BusinessWSCache businessWSCache,
      AccountService accountService,
      ScheduledRedisEvictionCacheService scheduledRedisEvictionCacheService) {
    this.businessWSCache = businessWSCache;
    this.accountService = accountService;
    this.scheduledRedisEvictionCacheService = scheduledRedisEvictionCacheService;
  }

  @GetMapping("/expandedAccount")
  @Operation(summary = "Get Expanded Accounts")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Map.class))
            })
      })
  public Mono<Map<Long, List<Long>>> getExpandedAccountByIds(
      @Parameter(description = "Account Ids") @RequestParam Set<Long> ids) {
    log.info("GET EXPANDED ACCOUNTS API CALL {}", ids);
    return businessWSCache.getExpandedAccountByIdsFromCache(ids);
  }

  @GetMapping("/clientData")
  @Operation(summary = "Get Client Data by ClientId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Map.class))
            })
      })
  public Mono<Map<Long, Client>> getClientDataByClientId(
      @Parameter(description = "Client Ids") @RequestParam List<Long> clientIds) {
    log.info("GET CLIENT DATA FOR CLIENTIDS API CALL {}", clientIds);
    return businessWSCache.getClientDataFromCache(clientIds);
  }

  @GetMapping("/userDetails")
  @Operation(summary = "Get User Details by UserId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = User.class))
            })
      })
  public Mono<User> getUserDetailsByUserId(
      @Parameter(description = "User Id") @RequestParam Integer userId) {
    return businessWSCache.fetchUserDetails(userId);
  }

  @GetMapping("/businessAccountData")
  @Operation(summary = "Get Business Account Data by AccountId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = User.class))
            })
      })
  public Mono<Map<Long, BusinessAccount>> getBusinessAccountDataByAccountId(
      @Parameter(description = "Account Id") @RequestParam List<Long> accountIds) {
    return businessWSCache.getAccountsDataFromCache(accountIds);
  }

  @GetMapping("/accountData")
  @Operation(summary = "Get Account Data by AccountId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = User.class))
            })
      })
  public Mono<List<Account>> getAccountDataByAccountId(
      @Parameter(description = "Account Id") @RequestParam List<Long> accountIds) {
    return accountService.getAccountsData(accountIds);
  }

  @GetMapping("/clear/cache")
  @Operation(summary = "clear caches except account cache")
  public String clearBusinessCache(
      @Parameter(
              description = "cacheName",
              schema =
                  @Schema(
                      type = "string",
                      allowableValues = {
                        RedisConstants.ACCOUNT,
                        RedisConstants.SECURITY,
                        RedisConstants.BUSINESS_ACCOUNT_DATA_CACHE,
                        RedisConstants.BUSINESS_USER_DETAILS_CACHE,
                        RedisConstants.BUSINESS_CLIENT_DATA_CACHE,
                        RedisConstants.BUSINESS_EXPANDED_ACCOUNTS_CACHE,
                        RedisConstants.BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE,
                        RedisConstants.BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE,
                        RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID,
                        RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_CLIENT_ID,
                        RedisConstants.PORTFOLIO_ACCOUNT_SECURITY_CACHE
                      }))
          @RequestParam
          String cacheName) {
    scheduledRedisEvictionCacheService.clearCacheByName(cacheName, 1);
    int size = scheduledRedisEvictionCacheService.getCacheSize(cacheName);
    return MessageFormat.format("After cache {0} clear size is {1} ", cacheName, size);
  }
}
