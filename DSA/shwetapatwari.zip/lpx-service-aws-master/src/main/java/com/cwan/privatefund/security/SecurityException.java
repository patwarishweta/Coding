package com.cwan.privatefund.security;

import java.io.Serial;

public class SecurityException extends RuntimeException {

  @Serial private static final long serialVersionUID = -505465591178379102L;

  public SecurityException(String msg) {
    super(msg);
  }
}
