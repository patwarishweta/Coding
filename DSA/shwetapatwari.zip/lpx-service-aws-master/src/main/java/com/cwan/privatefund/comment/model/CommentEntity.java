package com.cwan.privatefund.comment.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@EqualsAndHashCode
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "comments", catalog = "pabor")
public class CommentEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String message;
  private Long documentId;
  private String createdBy;
  private LocalDateTime tsCreatedOn;
  private String modifiedBy;
  private LocalDateTime tsModifiedOn;
}
