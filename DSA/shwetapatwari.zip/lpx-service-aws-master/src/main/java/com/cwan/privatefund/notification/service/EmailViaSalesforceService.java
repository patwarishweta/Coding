package com.cwan.privatefund.notification.service;

import com.cwan.privatefund.notification.exception.NotificationException;
import com.cwan.privatefund.salesforce.common.SalesforceProperties;
import com.cwan.privatefund.salesforce.config.SaleForceUtils;
import com.cwan.privatefund.salesforce.service.SalesforceAuthorizationService;
import com.cwan.privatefund.salesforce.service.SalesforceCaseQueryService;
import com.cwan.privatefund.salesforce.service.SoapEnvelopeService;
import java.io.IOException;
import java.util.Collection;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class EmailViaSalesforceService {

  //  This constant value is used to passed as value in the headers of the soap request.
  private static final String SOAP_ACTION = "\"\"";
  private final RestTemplate restTemplate;
  private static final String EMAIL_SERVICE_URL = "https://%s/services/Soap/u/57.0/";
  private final SalesforceAuthorizationService salesforceAuthorizationService;
  private final SalesforceCaseQueryService salesforceCaseQueryService;
  private final SoapEnvelopeService soapEnvelopeService;
  private final SalesforceProperties salesforceProperties;

  public EmailViaSalesforceService(
      SalesforceAuthorizationService salesforceAuthorizationService,
      SalesforceCaseQueryService salesforceCaseQueryService,
      SoapEnvelopeService soapEnvelopeService,
      RestTemplate restTemplate,
      SalesforceProperties salesforceProperties) {
    this.salesforceAuthorizationService = salesforceAuthorizationService;
    this.salesforceCaseQueryService = salesforceCaseQueryService;
    this.soapEnvelopeService = soapEnvelopeService;
    this.restTemplate = restTemplate;
    this.salesforceProperties = salesforceProperties;
  }

  public Mono<Void> sendEmailNotification(
      String subject, String htmlMessage, Collection<String> bccEmailAddresses, String accountId) {

    var bccEmailAddressesString = String.join(",", bccEmailAddresses);
    String authToken = salesforceAuthorizationService.getSalesforceAuthToken();
    String caseId =
        salesforceCaseQueryService.querySalesforceCaseIdOnAccountId(authToken, accountId);

    try {
      String envelope =
          soapEnvelopeService.generateSoapEnvelope(
              authToken, bccEmailAddressesString, subject, htmlMessage, caseId);
      sendRequestToSalesforce(envelope);
      log.info("Email sent successful to bcc {} with subject {}.", bccEmailAddresses, subject);
    } catch (NotificationException | IOException e) {
      log.warn("Failed to send email due to: {}", e.getMessage(), e);
    }
    return Mono.empty();
  }

  private void sendRequestToSalesforce(String soapEnvelope) {
    HttpHeaders headers = SaleForceUtils.createHttpHeaders(MediaType.TEXT_XML, null);
    headers.set("SOAPAction", SOAP_ACTION);
    HttpEntity<String> entity = new HttpEntity<>(soapEnvelope, headers);

    try {
      ResponseEntity<String> responseEntity =
          SaleForceUtils.makeRequest(
              restTemplate,
              String.format(EMAIL_SERVICE_URL, salesforceProperties.getSfInstanceHost()),
              HttpMethod.POST,
              entity,
              String.class);
      handleResponse(responseEntity.getBody());
    } catch (HttpClientErrorException | HttpServerErrorException e) {
      throw new NotificationException("Error in response" + e.getResponseBodyAsString(), e);
    }
  }

  private void handleResponse(String response) {
    Document doc = Jsoup.parse(response, "", Parser.xmlParser());
    String errorMsg = doc.select("errors > message").text();
    if (!errorMsg.isEmpty()) {
      throw new NotificationException("Error in response" + errorMsg);
    }
  }
}
