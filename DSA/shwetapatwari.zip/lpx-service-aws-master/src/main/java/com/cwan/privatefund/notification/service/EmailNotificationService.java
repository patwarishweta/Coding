package com.cwan.privatefund.notification.service;

import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.EmailNotificationConstants.FROM_ADDRESS;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.EmailNotificationConstants.SERVICE_NAME;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.ScheduledServiceConstants.TIME_FORMAT;

import com.ca.notification.client.NotificationClient;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * Service class responsible for sending email notifications. It communicates with an external
 * notification system via the NotificationClient.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class EmailNotificationService {

  private final NotificationClient notificationClient;

  /**
   * Sends an email notification based on the provided parameters.
   *
   * @param identifier Unique identifier for the email, used for tracking.
   * @param subject Subject of the email.
   * @param htmlMessage HTML formatted content of the email.
   * @param toEmailAddresses List of recipients' email addresses.
   * @param ccEmailAddresses List of recipients' email addresses
   * @param bccEmailAddresses List of recipients' email addresses
   * @return Mono<Boolean> indicating whether the email was successfully sent.
   */
  public Mono<Void> sendEmail(
      String identifier,
      String subject,
      String htmlMessage,
      Collection<String> toEmailAddresses,
      Collection<String> ccEmailAddresses,
      Collection<String> bccEmailAddresses) {
    var emailAddresses = getEmailAddresses(toEmailAddresses, ccEmailAddresses, bccEmailAddresses);
    return Mono.fromRunnable(
            () -> {
              validateEmailParameters(
                  identifier,
                  subject,
                  htmlMessage,
                  toEmailAddresses,
                  ccEmailAddresses,
                  bccEmailAddresses,
                  emailAddresses);
              var entryIdentifier =
                  String.format(
                      "%s - %s - %s",
                      subject,
                      identifier,
                      LocalDateTime.now().format(DateTimeFormatter.ofPattern(TIME_FORMAT)));
              notificationClient
                  .newNotification()
                  .serviceName(SERVICE_NAME)
                  .entryIdentifier(entryIdentifier)
                  .subject(subject)
                  .htmlMessage(htmlMessage)
                  .from(FROM_ADDRESS)
                  .to(toEmailAddresses)
                  .cc(ccEmailAddresses)
                  .bcc(bccEmailAddresses)
                  .send();
              log.debug(
                  "Sent email with subject: '{}', to addresses: {}",
                  subject,
                  String.join(", ", emailAddresses));
            })
        .then()
        .onErrorResume(
            e -> {
              log.warn(
                  "Failed to send email with subject: '{}', to addresses: {}",
                  subject,
                  String.join(", ", emailAddresses),
                  e);
              return Mono.empty();
            });
  }

  private static Set<String> getEmailAddresses(
      Collection<String> toEmailAddresses,
      Collection<String> ccEmailAddresses,
      Collection<String> bccEmailAddresses) {
    return Stream.of(
            Optional.ofNullable(toEmailAddresses).orElse(Collections.emptyList()),
            Optional.ofNullable(ccEmailAddresses).orElse(Collections.emptyList()),
            Optional.ofNullable(bccEmailAddresses).orElse(Collections.emptyList()))
        .flatMap(Collection::stream)
        .collect(Collectors.toSet());
  }

  private static void validateEmailParameters(
      String identifier,
      String subject,
      String htmlMessage,
      Collection<String> toEmailAddresses,
      Collection<String> ccEmailAddresses,
      Collection<String> bccEmailAddresses,
      Collection<String> emailAddresses) {
    var errorMessage = new StringBuilder();
    if (StringUtils.isBlank(identifier)) {
      errorMessage.append("Identifier is blank. ");
    }
    if (StringUtils.isBlank(subject)) {
      errorMessage.append("Subject is blank. ");
    }
    if (StringUtils.isBlank(htmlMessage)) {
      errorMessage.append("HTML message body is blank. ");
    }
    if (Objects.isNull(toEmailAddresses)
        || Objects.isNull(ccEmailAddresses)
        || Objects.isNull(bccEmailAddresses)
        || emailAddresses.isEmpty()) {
      errorMessage.append("Recipient list is null or empty. ");
    }
    if (!errorMessage.isEmpty()) {
      throw new IllegalArgumentException("Invalid email parameters: " + errorMessage);
    }
  }
}
