package com.cwan.privatefund.hydrate;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.document.DocumentAuditService;
import com.cwan.privatefund.document.DocumentInfo;
import com.cwan.privatefund.security.SecurityService;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class TransactionDataHydrationService {

  private final AccountService accountService;
  private final Documents documents;
  private final SecurityService securityService;
  private final DocumentAuditService documentAuditService;

  public TransactionDataHydrationService(
      AccountService accountService,
      Documents documents,
      SecurityService securityService,
      DocumentAuditService documentAuditService) {
    this.accountService = accountService;
    this.documents = documents;
    this.securityService = securityService;
    this.documentAuditService = documentAuditService;
  }

  public Mono<List<Transaction>> hydrate(List<Transaction> transactions) {
    return Mono.just(transactions)
        .flatMap(this::hydrateAccountData)
        .flatMap(this::hydrateDocumentData)
        .flatMap(this::hydrateSecurityData);
  }

  public Mono<List<Transaction>> hydrateWithDocumentAudit(List<Transaction> transactions) {
    return Mono.just(transactions)
        .flatMap(this::hydrateAccountData)
        .flatMap(this::hydrateDocumentAndAuditData)
        .flatMap(this::hydrateSecurityData);
  }

  public Mono<List<Transaction>> hydrateAccountData(Collection<Transaction> transactions) {
    var accountIds =
        transactions.stream()
            .map(transaction -> transaction.getAccount().getId())
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
    return accountService
        .getAccountsData(accountIds)
        .map(
            accounts -> {
              var accountsMap =
                  accounts.stream().collect(Collectors.toMap(Account::getId, Function.identity()));
              return transactions.stream()
                  .map(
                      transaction -> {
                        var accountId = transaction.getAccount().getId();
                        if (!accountsMap.containsKey(accountId)) {
                          return transaction;
                        }
                        return transaction.toBuilder().account(accountsMap.get(accountId)).build();
                      })
                  .toList();
            });
  }

  private Mono<List<Transaction>> hydrateDocumentData(Collection<Transaction> transactions) {
    var documentIds =
        transactions.stream()
            .map(Transaction::getDocument)
            .map(Document::getId)
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
    return documents
        .getDocumentsByIds(documentIds)
        .collectList()
        .map(
            documentList -> {
              var documentsMap =
                  documentList.stream()
                      .collect(Collectors.toMap(Document::getId, Function.identity()));
              return transactions.stream()
                  .map(
                      transaction -> {
                        var documentId = transaction.getDocument().getId();
                        if (!documentsMap.containsKey(documentId)) {
                          return transaction;
                        }
                        return transaction.toBuilder()
                            .document(documentsMap.get(documentId))
                            .build();
                      })
                  .toList();
            });
  }

  protected Mono<List<Transaction>> hydrateDocumentAndAuditData(
      Collection<Transaction> transactions) {
    var documentIds =
        transactions.stream()
            .map(Transaction::getDocument)
            .map(Document::getId)
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
    return documents
        .getDocumentsByIds(documentIds)
        .collectList()
        .flatMapMany(c -> documentAuditService.getDocumentsWithAuditInfo(Flux.fromIterable(c)))
        .collectList()
        .map(
            documentList -> {
              var documentsMap =
                  documentList.stream()
                      .collect(
                          Collectors.toMap(doc -> doc.getDocument().getId(), Function.identity()));
              return transactions.stream()
                  .map(
                      transaction -> {
                        var documentId = transaction.getDocument().getId();
                        if (!documentsMap.containsKey(documentId)) {
                          return transaction;
                        }
                        DocumentInfo documentInfo = documentsMap.get(documentId);
                        documentInfo.getDocument().setValidationDate(documentInfo.validationDate());

                        return transaction.toBuilder().document(documentInfo.getDocument()).build();
                      })
                  .toList();
            });
  }

  public Mono<List<Transaction>> hydrateSecurityData(Collection<Transaction> transactions) {
    var accountToSecurities =
        transactions.stream()
            .collect(Collectors.groupingBy(Transaction::getAccount))
            .entrySet()
            .stream()
            .map(
                entry -> {
                  var account = entry.getKey();
                  var securityIds =
                      entry.getValue().stream()
                          .map(Transaction::getSecurity)
                          .map(Security::getSecurityId)
                          .filter(Objects::nonNull)
                          .distinct()
                          .toList();
                  return Map.entry(account, securityIds);
                })
            .toList();
    return Flux.fromIterable(accountToSecurities)
        .flatMap(
            entry -> {
              var account = entry.getKey();
              return securityService.getSecurities(
                  account.getClientId(), account.getId(), entry.getValue());
            })
        .flatMapIterable(Function.identity())
        .distinct()
        .collect(
            (Collectors.toMap(
                Security::getSecurityId,
                Function.identity(),
                (s1, s2) -> s1, // <-- Merge function to handle duplicate key
                LinkedHashMap::new)))
        .map(
            securitiesMap ->
                transactions.stream()
                    .map(
                        transaction -> {
                          var securityId = transaction.getSecurity().getSecurityId();
                          if (!securitiesMap.containsKey(securityId)) {
                            return transaction;
                          }
                          return transaction.toBuilder()
                              .security(securitiesMap.get(securityId))
                              .build();
                        })
                    .toList());
  }
}
