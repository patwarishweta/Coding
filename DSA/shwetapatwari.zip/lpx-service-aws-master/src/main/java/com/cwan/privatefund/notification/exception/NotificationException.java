package com.cwan.privatefund.notification.exception;

import java.io.Serial;

public class NotificationException extends RuntimeException {

  @Serial private static final long serialVersionUID = -357666336026802895L;

  public NotificationException(String message) {
    super(message);
  }

  public NotificationException(String message, Throwable cause) {
    super(message, cause);
  }
}
