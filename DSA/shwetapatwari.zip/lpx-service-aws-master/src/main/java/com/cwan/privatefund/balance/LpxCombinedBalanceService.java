package com.cwan.privatefund.balance;

import com.cwan.privatefund.balance.model.LmcBalance;
import com.cwan.privatefund.calculated.CalculatedBalanceService;
import java.time.LocalDate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
public class LpxCombinedBalanceService {

  private final CalculatedBalanceService calculatedBalanceService;
  private final LpxBalanceService balanceService;

  public LpxCombinedBalanceService(
      CalculatedBalanceService calculatedBalanceService, LpxBalanceService balanceService) {
    this.calculatedBalanceService = calculatedBalanceService;
    this.balanceService = balanceService;
  }

  public Flux<LmcBalance> getAccountBalances(
      Long accountId, LocalDate balanceDate, LocalDate knowledgeDate) {
    Flux<LmcBalance> calculatedBalances =
        calculatedBalanceService
            .calculateBalances(accountId, balanceDate, knowledgeDate, false)
            .map(LmcBalance::convertToLmcBalance);

    Flux<LmcBalance> documentBalances =
        balanceService
            .getAccountBalances(accountId, balanceDate, knowledgeDate)
            .collectList()
            .map(LmcBalance::convertToLmcBalance)
            .flatMapMany(Flux::fromIterable);

    return documentBalances.concatWith(calculatedBalances);
  }
}
