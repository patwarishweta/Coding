package com.cwan.privatefund.fxrate.source;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class AccountFxSourceEntityTransformer
    implements Function<AccountFxSource, AccountFxSourceEntity> {
  @Override
  public AccountFxSourceEntity apply(AccountFxSource accountFxSource) {
    return AccountFxSourceEntity.builder()
        .accountId(accountFxSource.getAccountId())
        .basisId(accountFxSource.getBasisId())
        .date(accountFxSource.getDate())
        .fxRateSourceId(accountFxSource.getFxRateSourceId())
        .rankId(accountFxSource.getRankId())
        .modifiedOn(
            accountFxSource.getModifiedOn() != null
                ? accountFxSource.getModifiedOn()
                : LocalDateTime.now(ZoneOffset.UTC))
        .build();
  }
}
