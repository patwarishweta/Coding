package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.pbor.document.capital.call.management.api.CapitalCallManagement;
import com.cwan.privatefund.util.StringOperationUtils;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/** Service to manage the blacklist checks for ABA routing numbers in capital calls. */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallBlacklistAbaRoutingService {

  private final CapitalCallManagement capitalCallManagement;

  /**
   * Checks if the abaRoutingNumber for a given CapitalCallDocument is blacklisted.
   *
   * @param document Document to check the abaRoutingNumber from.
   * @return A Mono<Boolean> indicating if the abaRoutingNumber is blacklisted.
   */
  public Mono<Boolean> isAbaRoutingNumberBlacklisted(CapitalCallDocument document) {
    if (Objects.isNull(document.bankDetail())) {
      log.warn("Bank Detail is null for document ID: {}", document.documentId());
      return Mono.just(false);
    }
    if (Objects.isNull(document.account())) {
      log.warn("Account is null for document ID: {}", document.documentId());
      return Mono.just(false);
    }
    var clientId = document.account().getClientId();
    var abaRoutingNumber =
        (Objects.nonNull(document.bankDetail()))
            ? StringOperationUtils.normalizeAndTrimToNull(
                (document.bankDetail().abaRoutingNumber()))
            : null;
    var swiftChipsCode =
        (Objects.nonNull(document.bankDetail()))
            ? StringOperationUtils.normalizeAndTrimToNull((document.bankDetail().swiftOrChips()))
            : null;
    if (Objects.isNull(clientId)
        || (Objects.isNull(abaRoutingNumber) && Objects.isNull(swiftChipsCode))) {
      log.warn(
          "Invalid clientId or both routing numbers are blank for document ID: {}",
          document.documentId());
      return Mono.just(false);
    }
    log.debug(
        "Checking blacklist status for abaRoutingNumber: '{}' and swiftChipsCode: '{}'",
        abaRoutingNumber,
        swiftChipsCode);
    return Mono.just(
        fetchBlacklistedBanks(clientId).stream()
            .anyMatch(
                bank ->
                    StringUtils.equalsIgnoreCase(bank.abaRoutingNumber(), abaRoutingNumber)
                        || StringUtils.equalsIgnoreCase(bank.swiftChipsCode(), swiftChipsCode)));
  }

  /**
   * Retrieves a list of blacklisted banks for a specific client.
   *
   * @param clientId the client's unique identifier.
   * @return a list of blacklisted Bank objects associated with the clientId.
   */
  private List<Bank> fetchBlacklistedBanks(Long clientId) {
    return capitalCallManagement.fetchBankBlacklistsByClient(clientId).stream()
        .map(
            bankBlacklist -> {
              log.debug("Derived blacklisted banks for clientId: {}", clientId);
              return bankBlacklist.bank();
            })
        .collect(Collectors.toList());
  }
}
