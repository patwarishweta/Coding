package com.cwan.privatefund.document;

import com.cwan.privatefund.feature.Feature;
import com.cwan.privatefund.feature.FeatureFlagsWSClient;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Component
@Slf4j
@AllArgsConstructor
public class MissingDocumentFeatureFlagWebFilter implements WebFilter {

  private FeatureFlagsWSClient featureFlagsWSClient;
  private final String restrictedPathPrefix = "/v1/documents/missing";

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    if (isRestrictedApi(exchange.getRequest().getPath().toString())
        && !featureFlagsWSClient.getCachedFeatureFlag(
            Feature.DETECT_MISSING_DOCUMENT_ENABLED, null)) {
      log.warn(
          "{} flag is not enabled, blocking api {}",
          Feature.DETECT_MISSING_DOCUMENT_ENABLED.name(),
          exchange.getRequest().getPath());
      exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
      return exchange
          .getResponse()
          .writeWith(
              Mono.just(
                  exchange
                      .getResponse()
                      .bufferFactory()
                      .wrap(
                          "Access forbidden. Feature DETECT_MISSING_DOCUMENT_ENABLED flag is set to false."
                              .getBytes())));
    }
    return chain.filter(exchange);
  }

  private boolean isRestrictedApi(String requestPath) {
    return requestPath.contains(restrictedPathPrefix);
  }
}
