package com.cwan.privatefund.capital.call.management.builder;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.management.model.BankAccountCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankAccountResponse;
import com.cwan.privatefund.capital.call.management.model.BankBlacklistResponse;
import com.cwan.privatefund.capital.call.management.model.BankCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankResponse;
import lombok.experimental.UtilityClass;

@UtilityClass
public class CapitalCallManagementBuilder {

  public static BankResponse buildBankResponse(User user, Client client, Bank bank) {
    return BankResponse.builder()
        .bankUuid(bank.bankUuid())
        .bankName(bank.bankName())
        .clientId(bank.clientId())
        .clientName(client.getName())
        .abaRoutingNumber(bank.abaRoutingNumber())
        .swiftChipsCode(bank.swiftChipsCode())
        .createdAt(bank.createdAt())
        .creatorName(user.getFullname())
        .creatorEmail(user.getEmail())
        .build();
  }

  public static Bank buildBank(BankCreationRequest bankCreationRequest, User user) {
    return Bank.builder()
        .clientId(bankCreationRequest.clientId())
        .bankName(bankCreationRequest.bankName())
        .abaRoutingNumber(bankCreationRequest.abaRoutingNumber())
        .swiftChipsCode(bankCreationRequest.swiftChipsCode())
        .createdBy(user.getId().longValue())
        .build();
  }

  public static BankAccountResponse buildBankAccountResponse(
      User user, BankAccount createdBankAccount) {
    return BankAccountResponse.builder()
        .bankAccountUuid(createdBankAccount.bankAccountUuid())
        .bankUuid(createdBankAccount.bank().bankUuid())
        .bankName(createdBankAccount.bank().bankName())
        .accountId(createdBankAccount.accountId())
        .accountName(createdBankAccount.accountName())
        .accountNumber(createdBankAccount.accountNumber())
        .iban(createdBankAccount.iban())
        .createdAt(createdBankAccount.createdAt())
        .creatorName(user.getFullname())
        .creatorEmail(user.getEmail())
        .build();
  }

  public static BankAccount buildBankAccount(
      BankAccountCreationRequest bankAccountCreationRequest, User user) {
    return BankAccount.builder()
        .bank(Bank.builder().bankUuid(bankAccountCreationRequest.bankUuid()).build())
        .accountId(bankAccountCreationRequest.accountId())
        .accountName(bankAccountCreationRequest.accountName())
        .accountNumber(bankAccountCreationRequest.accountNumber())
        .iban(bankAccountCreationRequest.iban())
        .createdBy(user.getId().longValue())
        .build();
  }

  public static BankBlacklistResponse buildBankBlacklistResponse(User user, BankBlacklist bank) {
    return BankBlacklistResponse.builder()
        .bankBlacklistUuid(bank.bankBlacklistUuid())
        .bankUuid(bank.bank().bankUuid())
        .bankName(bank.bank().bankName())
        .createdAt(bank.createdAt())
        .creatorName(user.getFullname())
        .creatorEmail(user.getEmail())
        .build();
  }

  public static BankBlacklist buildBankBlacklist(Bank bank, User user) {
    return BankBlacklist.builder().bank(bank).createdBy(user.getId().longValue()).build();
  }
}
