package com.cwan.privatefund.documentmanager;

import com.cwan.lpx.domain.Document;
import com.cwan.privatefund.account.UltimateParents;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class DocumentManagerData {

  private Document document;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private UltimateParents ultimateParent;

  private Set<String> tags;
}
