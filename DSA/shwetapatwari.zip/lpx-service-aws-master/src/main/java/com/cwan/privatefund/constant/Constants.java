package com.cwan.privatefund.constant;

import java.util.List;
import java.util.Set;

public class Constants {

  public static final String CALCULATED_SOURCE = "Calculated";
  public static final String OFFSET_TRANSACTION_TYPE = "TRN";
  public static final String FTW_TRANSACTION_TYPE = "FTW";
  public static final String ECONOMIC_NAV_SUB_TYPE = "ECONOMIC_NAV";
  public static final long AGGREGATE_SECURITY_ID = -2L;
  public static final String WATCHLIST_NAV_SUB_TYPE = "WATCHLIST";
  public static final String NAV_TRANSACTION_TYPE = "NAV";
  public static final String COMMITMENT_ADJUSTMENT_TRANSACTION_TYPE = "COMMITMENT_ADJUSTMENT";
  public static final String TOTAL_COMMITMENT_SUBTYPE = "TOTAL_COMMITMENT";
  public static final String OTHER_COMMITMENT_SUBTYPE = "OTHER_COMMITMENT";
  public static final String MISCELLANEOUS = "MISCELLANEOUS";
  public static final Set<String> OPEN_TRAN_TYPES = Set.of("BUY", "TRNI", "INITIAL_LOAD");
  public static final Set<String> CUM_CONTRIBUTION_TYPES_LIST =
      Set.of("CAPC", "EXP", "GENERAL_ADJUSTMENT");
  public static final List<String> CUM_DISTRIBUTION_TYPES_LIST =
      List.of("CAPD", "INC", "DVD", "RCAP");

  public static final String GEN_AI_DOCUMENTS_SOURCE = "DataForge";
  public static final String LPX_CLARITY = "LPxClarity";
  public static final String LPX_PRISM = "LPxPrismReporting";
  public static final String EXCLUDE_HISTORIC_TRANSACTIONS_FOR_CONTRIBUTION =
      "EXCLUDE_HISTORIC_TRANSACTIONS_FOR_CONTRIBUTION";
  public static final List<String> CREATE_CANCEL_ACTION = List.of("Create", "Cancel");
  public static final String EML_FILE_TYPE = "eml";
  public static final String XLS_MIME_TYPE = "x-tika-msoffice";
  public static final String XLSX_MIME_TYPE = "x-tika-ooxml";
  public static final String CSV_MIME_TYPE = "plain";
  public static final String EML_MIME_TYPE = "rfc822";
  public static final String XLS_FILE_TYPE = "xls";
  public static final String XLSX_FILE_TYPE = "xlsx";
  public static final String CSV_FILE_TYPE = "csv";
  public static final String PNG_FILE_TYPE = "png";
  public static final String JPEG_FILE_TYPE = "jpeg";
  public static final String JPG_FILE_TYPE = "jpg";
  public static final List<String> PERFORMANCE_CALCULATION_MANDATORY_FIELDS =
      List.of(
          "settleDate",
          "type",
          "fxRate",
          "netAmount",
          "cashImpact",
          "navImpact",
          "unfundedCommitment");
  public static final int BATCH_SIZE = 100;

  private Constants() {}

  public static class DocumentTypes {

    public static final String CAPITAL_CALL = "Capital Call Notice";
    public static final String DISTRIBUTION = "Capital Distribution Notice";
    public static final String ACCOUNT_STATEMENT = "Capital Account Statement";

    private DocumentTypes() {}
  }

  public static class BalanceRelations {

    public static final String FUND = "Fund";
    public static final String LP = "LP";
    public static final String GP = "GP";
    public static final String NONE = "None";

    private BalanceRelations() {}
  }

  public static class EntityActions {

    public static final String CREATE = "Create";
    public static final String UPDATE = "Update";
    public static final String CANCEL = "Cancel";

    private EntityActions() {}
  }

  public static class IssueTypes {

    public static final String DOCUMENT_VALIDATION = "DOCUMENT_VALIDATION";
    public static final String MISSING_DOCUMENT = "MISSING_DOCUMENT";

    private IssueTypes() {}
  }
}
