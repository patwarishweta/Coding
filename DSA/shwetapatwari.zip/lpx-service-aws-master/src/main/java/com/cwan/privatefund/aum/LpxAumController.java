package com.cwan.privatefund.aum;

import com.cwan.lpx.domain.Aum;
import com.cwan.privatefund.aum.model.AumRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.ws.rs.QueryParam;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping(value = "v1/aum/")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class LpxAumController {

  private final LpxAumService lpxAumService;
  private final ExcelCreationService excelCreationService;

  LpxAumController(LpxAumService lpxAumService, ExcelCreationService excelCreationService) {
    this.lpxAumService = lpxAumService;
    this.excelCreationService = excelCreationService;
  }

  @ResponseStatus(HttpStatus.ACCEPTED)
  @Operation(summary = "Update aum")
  @RequestMapping(value = "update", method = RequestMethod.PUT)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Update Aum successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Aum.class))
            })
      })
  public Map<Long, Set<Aum>> updateAum(
      @Parameter(description = "Aum Data") @RequestBody AumRequest request) {
    return lpxAumService.updateAums(request);
  }

  @RequestMapping(value = "ultimate-parent-ids", method = RequestMethod.GET)
  @Operation(summary = "Get aums by ultimate parent ids")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Map<Long, List<Aum>> getAumByUltimateParentId(@QueryParam("ultimateParentId") String id) {
    log.info("Fetching aums for ids: {}", id);
    Set<Long> ids = Arrays.stream(id.split(" ")).map(Long::parseLong).collect(Collectors.toSet());
    return lpxAumService.getAumByUltimateParentIds(ids);
  }

  @RequestMapping(value = "excel/ultimate-parent-ids", method = RequestMethod.GET)
  @Operation(summary = "Get Excel of AUMs By Ultimate Parent Id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity<ByteArrayResource> getAumByCalculationDateAndClientId(
      @RequestParam("calculationDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate calculationDate,
      @QueryParam("ultimateParentIds") String ultimateParentIds) {
    Set<Long> clientIds =
        Arrays.stream(ultimateParentIds.replaceAll(" ", "").split(","))
            .map(Long::parseLong)
            .collect(Collectors.toSet());

    byte[] excelBytes = excelCreationService.generateExcelFile(clientIds, calculationDate);
    ByteArrayResource resource = new ByteArrayResource(excelBytes);

    HttpHeaders headers = new HttpHeaders();
    headers.add(
        "Content-Disposition",
        String.format("attachment; filename=Aum_by_Parent_ID_%s.xlsx", calculationDate));

    return ResponseEntity.ok()
        .headers(headers)
        .contentLength(excelBytes.length)
        .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
        .body(resource);
  }
}
