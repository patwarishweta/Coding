package com.cwan.privatefund.business.ws;

import static com.cwan.privatefund.constant.RedisConstants.ACCOUNT;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_ACCOUNT_DATA_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_CLIENT_ID;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_EXPANDED_ACCOUNTS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_USER_DETAILS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE;

import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.business.ws.model.UserAccounts;
import com.cwan.privatefund.constant.RedisConstants;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class BusinessWSCache {

  private final BusinessWSClient businessWSClient;
  private final RedisTemplate redisTemplate;

  public BusinessWSCache(BusinessWSClient businessWSClient, RedisTemplate redisTemplate) {
    this.businessWSClient = businessWSClient;
    this.redisTemplate = redisTemplate;
  }

  public Mono<BusinessAccount> getAccountData(Long accountId) {
    log.info("getAccountData accountId:{}", accountId);
    if (accountId == null) {
      return Mono.empty();
    }
    BusinessAccount businessAccount =
        (BusinessAccount) redisTemplate.opsForHash().get(BUSINESS_ACCOUNT_DATA_CACHE, accountId);
    if (businessAccount != null) {
      log.debug("getAccountData :: Account found in cache");
      return Mono.just(businessAccount);
    }
    return businessWSClient
        .getAccountsInformation(List.of(accountId))
        .onErrorResume(Mono::error)
        .filter(accounts -> !accounts.isEmpty())
        .<BusinessAccount>handle(
            (accounts, sink) -> {
              if (accounts.size() > 1) {
                sink.error(
                    new BusinessWSException(
                        "There is more than one account data for accountId= " + accountId));
                return;
              }
              sink.next(accounts.get(0));
            })
        .flatMap(this::enrichClientUltimateParentIdOnBusinessAccount)
        .flatMap(
            businessAccountData -> {
              if (Boolean.TRUE.equals(businessAccountData.getAggregate())) {
                return getExpandedAccountIds(businessAccountData.getId())
                    .map(
                        simpleAccountIds ->
                            businessAccountData.toBuilder()
                                .simpleAccountIds(simpleAccountIds)
                                .build());
              }
              return Mono.just(businessAccountData);
            })
        .map(
            businessAccountData -> {
              redisTemplate
                  .opsForHash()
                  .put(BUSINESS_ACCOUNT_DATA_CACHE, accountId, businessAccountData);
              return businessAccountData;
            });
  }

  public Mono<Map<Long, Client>> getClientDataFromCache(List<Long> clientIds) {
    log.info("getClientDataFromCache method call : {}", clientIds);
    if ((clientIds == null) || clientIds.isEmpty()) {
      return Mono.empty();
    }
    AtomicBoolean missingClientFlag = new AtomicBoolean(false);
    Map<Long, Client> clientDataMap =
        clientIds.parallelStream()
            .collect(
                HashMap::new,
                (map, clientId) -> {
                  Client clientData =
                      (Client)
                          redisTemplate
                              .opsForHash()
                              .get(RedisConstants.BUSINESS_CLIENT_DATA_CACHE, clientId);
                  if (clientData == null) {
                    missingClientFlag.set(true);
                  }
                  map.put(clientId, clientData);
                },
                HashMap::putAll);
    if (!missingClientFlag.get()) {
      log.debug("getClientDataFromCache :: All clients found in cache");
      return Mono.just(clientDataMap);
    }
    List<Long> missingClientIds =
        clientDataMap.entrySet().stream()
            .filter(longListEntry -> longListEntry.getValue() == null)
            .map(Map.Entry::getKey)
            .toList();
    log.info("getClientDataFromCache :: Few clients missing in cache {}", missingClientIds);
    return businessWSClient
        .getClientInfo(missingClientIds)
        .filter(clientMap -> !clientMap.isEmpty())
        .map(
            missingClientDataMap -> {
              missingClientDataMap.entrySet().parallelStream()
                  .forEach(
                      entry -> {
                        clientDataMap.put(entry.getKey(), entry.getValue());
                        redisTemplate
                            .opsForHash()
                            .put(
                                RedisConstants.BUSINESS_CLIENT_DATA_CACHE,
                                entry.getKey(),
                                entry.getValue());
                      });
              return missingClientDataMap;
            })
        .onErrorResume(
            e -> {
              log.error(
                  "Exception BusinessWs : Client Data for clientIds not found for {}",
                  missingClientIds,
                  e);
              return Mono.empty();
            })
        .then(Mono.just(clientDataMap));
  }

  public Mono<Map<Long, BusinessAccount>> getAccountsDataFromCache(Collection<Long> accountIds) {
    log.info("getAccountsDataFromCache method call : {}", accountIds);
    if ((accountIds == null) || accountIds.isEmpty()) {
      return Mono.empty();
    }
    AtomicBoolean missingBusinessAccountDataFlag = new AtomicBoolean(false);
    Map<Long, BusinessAccount> businessAccountDataMap =
        accountIds.parallelStream()
            .collect(
                HashMap::new,
                (map, accountId) -> {
                  BusinessAccount businessAccount =
                      (BusinessAccount)
                          redisTemplate.opsForHash().get(BUSINESS_ACCOUNT_DATA_CACHE, accountId);
                  if (businessAccount == null) {
                    missingBusinessAccountDataFlag.set(true);
                  }
                  map.put(accountId, businessAccount);
                },
                HashMap::putAll);
    if (!missingBusinessAccountDataFlag.get()) {
      log.debug("getAccountsDataFromCache :: All accounts found in cache");
      return Mono.just(businessAccountDataMap);
    }
    List<Long> missingAccountIds = new ArrayList<>();
    businessAccountDataMap
        .entrySet()
        .removeIf(
            e -> {
              if (e.getValue() == null) {
                missingAccountIds.add(e.getKey());
                return true;
              }
              return false;
            });
    log.info("getAccountsDataFromCache :: Few account missing in cache {}", missingAccountIds);
    Mono<Map<Long, BusinessAccount>> resultMap =
        Mono.zip(
                businessWSClient.getAccountsInformation(missingAccountIds),
                ultimateParentCacheByAccountId(Set.copyOf(missingAccountIds)))
            .flatMap(
                x -> {
                  var t1 = x.getT1();
                  var t2 = x.getT2();
                  if (t1.isEmpty()) {
                    log.error("No BusinessAccount Info found for accounts {}", missingAccountIds);
                    return Mono.empty();
                  }
                  Map<Long, BusinessAccount> enrichedparentInfoBusinessAccMap =
                      t1.stream()
                          .collect(
                              HashMap::new,
                              (map, businessAccount) -> {
                                var parentMap = t2.get(businessAccount.getId());
                                if (t2.isEmpty() || (parentMap == null)) {
                                  map.put(businessAccount.getId(), businessAccount);
                                }
                                BusinessAccount enrichedParentMap =
                                    businessAccount.toBuilder()
                                        .ultimateParentId(
                                            Objects.requireNonNull(parentMap)
                                                .get(parentMap.lastKey()))
                                        .build();
                                map.put(businessAccount.getId(), enrichedParentMap);
                              },
                              HashMap::putAll);
                  return Mono.just(enrichedparentInfoBusinessAccMap);
                });
    return resultMap
        .flatMapIterable(Map::entrySet)
        .flatMap(
            entry -> {
              BusinessAccount businessAccount = entry.getValue();
              if (Boolean.TRUE.equals(businessAccount.getAggregate())) {
                return getExpandedAccountIds(businessAccount.getId())
                    .map(
                        simpleAccountIds ->
                            businessAccount.toBuilder().simpleAccountIds(simpleAccountIds).build());
              }
              return Mono.just(businessAccount);
            })
        .map(
            businessAccount -> {
              businessAccountDataMap.put(businessAccount.getId(), businessAccount);
              redisTemplate
                  .opsForHash()
                  .put(BUSINESS_ACCOUNT_DATA_CACHE, businessAccount.getId(), businessAccount);
              return businessAccount;
            })
        .onErrorResume(
            e -> {
              log.error(
                  "Exception BusinessWs : AccountData for accountIds not found for {}",
                  accountIds,
                  e);
              return Mono.empty();
            })
        .then(Mono.just(businessAccountDataMap));
  }

  public Mono<List<BusinessAccount>> getAccountsData(Collection<Long> accountIds) {
    return getAccountsDataFromCache(accountIds)
        .map(longBusinessAccountMap -> longBusinessAccountMap.values().stream().toList());
  }

  public Mono<Map<Long, List<Long>>> getExpandedAccountByIdsFromCache(Collection<Long> accountIds) {
    log.info("getExpandedAccountByIdsFromCache method call : {}", accountIds);
    if (CollectionUtils.isEmpty(accountIds)) {
      return Mono.empty();
    }
    Set<Long> cleanAccountIds =
        accountIds.stream().filter(Objects::nonNull).collect(Collectors.toSet());
    if (CollectionUtils.isEmpty(cleanAccountIds)) {
      return Mono.empty();
    }
    AtomicBoolean missingAccountsFlag = new AtomicBoolean(false);
    Map<Long, List<Long>> expandedAccountsMap =
        cleanAccountIds.stream()
            .collect(
                Collectors.toMap(
                    Function.identity(),
                    accId -> {
                      List<Long> expandedAccIds =
                          (List<Long>)
                              redisTemplate
                                  .opsForHash()
                                  .get(BUSINESS_EXPANDED_ACCOUNTS_CACHE, accId);
                      if ((expandedAccIds == null) || expandedAccIds.isEmpty()) {
                        missingAccountsFlag.set(true);
                        return List.of();
                      }
                      if (expandedAccIds.size() > 1) {
                        return expandedAccIds;
                      }
                      return List.of(accId);
                    }));
    if (!missingAccountsFlag.get()) {
      log.info("getExpandedAccountByIdsFromCache :: All accounts found in cache");
      return Mono.just(expandedAccountsMap);
    }
    List<Long> missingAccountIds =
        expandedAccountsMap.entrySet().stream()
            .filter(longListEntry -> longListEntry.getValue().isEmpty())
            .map(Map.Entry::getKey)
            .toList();
    log.info(
        "getExpandedAccountByIdsFromCache :: Few account missing in cache {}", missingAccountIds);
    return Flux.fromIterable(missingAccountIds)
        .flatMap(
            accId ->
                businessWSClient
                    .getExpandedAccountIds(accId)
                    .map(
                        expandedIds -> {
                          expandedAccountsMap.put(accId, expandedIds);
                          redisTemplate
                              .opsForHash()
                              .put(BUSINESS_EXPANDED_ACCOUNTS_CACHE, accId, expandedIds);
                          return expandedIds;
                        })
                    .onErrorResume(
                        e -> {
                          log.error(
                              "Exception BusinessWs : Expanded Accounts not found for accId {}",
                              accId,
                              e);
                          return Mono.empty();
                        }))
        .then(Mono.just(expandedAccountsMap));
  }

  public Mono<List<Long>> getExpandedAccountIds(Long accountId) {
    return getExpandedAccountByIdsFromCache(Set.of(accountId))
        .filter(longListMap -> longListMap.containsKey(accountId))
        .map(longListMap -> longListMap.get(accountId))
        .onErrorResume(Mono::error);
  }

  public Mono<User> fetchUserDetails(Integer userId) {
    log.info("fetchUserDetails method call : {}", userId);
    if (userId == null) {
      return Mono.empty();
    }
    User userDetail = (User) redisTemplate.opsForHash().get(BUSINESS_USER_DETAILS_CACHE, userId);
    if (userDetail != null) {
      log.info("fetchUserDetails :: User detail found in cache");
      return Mono.just(userDetail);
    }
    log.info("fetchUserDetails :: userId missing in cache {}", userId);
    return businessWSClient
        .fetchUserDetails(userId)
        .map(
            user -> {
              redisTemplate.opsForHash().put(BUSINESS_USER_DETAILS_CACHE, userId, user);
              return user;
            });
  }

  public Mono<UserAccounts> getUserAccountAccessFromCache(Integer userId) {
    log.info("getUserAccountAccessFromCache method call : {}", userId);
    if (userId == null) {
      return Mono.empty();
    }
    Set<Long> userAccounts =
        (Set<Long>)
            redisTemplate.opsForHash().get(BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE, userId);
    if ((userAccounts != null) && (!userAccounts.isEmpty())) {
      log.info("getUserAccountAccessFromCache :: User's account access found in cache");
      return Mono.just(new UserAccounts(userId, userAccounts));
    }
    log.info(
        "getUserAccountAccessFromCache :: userId missing in cache, loading for all accounts {}",
        userId);
    Set<Long> allAccountsList = redisTemplate.opsForHash().entries(ACCOUNT).keySet();
    return businessWSClient
        .getUserAccountAccess(userId, allAccountsList)
        .map(
            userAccountAccessMap -> {
              Set<Long> accIdsUserhasAccess =
                  userAccountAccessMap.entrySet().stream()
                      .filter(entry -> Boolean.TRUE.equals(entry.getValue()))
                      .map(Map.Entry::getKey)
                      .collect(Collectors.toSet());
              redisTemplate
                  .opsForHash()
                  .put(BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE, userId, accIdsUserhasAccess);
              return new UserAccounts(userId, accIdsUserhasAccess);
            });
  }

  public Mono<Map<Long, Boolean>> getUserAccountAccess(Integer userId, Set<Long> accountIds) {
    log.info("getUserAccountAccess method call : userId: {} accIds:{}", userId, accountIds);
    if ((userId == null) || (accountIds == null) || accountIds.isEmpty()) {
      return Mono.empty();
    }
    return getUserAccountAccessFromCache(userId)
        .map(
            userAccounts ->
                accountIds.stream()
                    .map(
                        aLong -> {
                          if (userAccounts.accountIds().contains(aLong)) {
                            return Map.of(aLong, Boolean.TRUE);
                          }
                          return Map.of(aLong, Boolean.FALSE);
                        })
                    .flatMap(y -> y.entrySet().stream())
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
  }

  public Mono<Map<Long, SortedMap<Integer, Long>>> ultimateParentCacheByAccountId(
      Set<Long> accountIds) {
    log.info("ultimateParentCacheByAccountId method call : {}", accountIds);
    if ((accountIds == null) || accountIds.isEmpty()) {
      return Mono.empty();
    }
    AtomicBoolean missingAccountFlag = new AtomicBoolean(false);
    Map<Long, SortedMap<Integer, Long>> ultimateParentDataMap =
        accountIds.stream()
            .collect(
                HashMap::new,
                (map, accountId) -> {
                  SortedMap<Integer, Long> ultimateParentData =
                      (SortedMap<Integer, Long>)
                          redisTemplate
                              .opsForHash()
                              .get(BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID, accountId);
                  if (ultimateParentData == null) {
                    missingAccountFlag.set(true);
                  }
                  map.put(accountId, ultimateParentData);
                },
                HashMap::putAll);
    if (!missingAccountFlag.get()) {
      log.info("ultimateParentCacheByAccountId :: All accounts found in cache");
      return Mono.just(ultimateParentDataMap);
    }
    Set<Long> missingAccountIds =
        ultimateParentDataMap.entrySet().stream()
            .filter(longListEntry -> longListEntry.getValue() == null)
            .map(Map.Entry::getKey)
            .collect(Collectors.toSet());
    log.info("ultimateParentCacheByAccountId :: accountIds missing in cache {}", missingAccountIds);
    return businessWSClient
        .getUltimateParentMapFromAccounts(missingAccountIds)
        .filter(clientMap -> !clientMap.isEmpty())
        .map(
            missingClientDataMap -> {
              missingClientDataMap.entrySet().parallelStream()
                  .forEach(
                      entry -> {
                        ultimateParentDataMap.put(entry.getKey(), entry.getValue());
                        redisTemplate
                            .opsForHash()
                            .put(
                                BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID,
                                entry.getKey(),
                                entry.getValue());
                      });
              return missingClientDataMap;
            })
        .onErrorResume(
            e -> {
              log.error(
                  "Exception BusinessWs : Ultimate Parent Data for accountIds not found for {}",
                  missingAccountIds,
                  e);
              return Mono.empty();
            })
        .then(Mono.just(ultimateParentDataMap));
  }

  public Mono<Map<Long, SortedMap<Integer, Long>>> ultimateParentCacheByClientId(
      Set<Long> clientIds) {
    log.info("ultimateParentCacheByClientId method call : {}", clientIds);
    if ((clientIds == null) || clientIds.isEmpty()) {
      return Mono.empty();
    }
    AtomicBoolean missingClientsFlag = new AtomicBoolean(false);
    Map<Long, SortedMap<Integer, Long>> clientAccountsMap =
        clientIds.parallelStream()
            .collect(
                Collectors.toMap(
                    Function.identity(),
                    clientId -> {
                      SortedMap<Integer, Long> clientsAccountIds =
                          (SortedMap<Integer, Long>)
                              redisTemplate
                                  .opsForHash()
                                  .get(
                                      BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_CLIENT_ID, clientId);
                      if ((clientsAccountIds == null) || clientsAccountIds.isEmpty()) {
                        missingClientsFlag.set(true);
                        return new TreeMap<>();
                      }
                      return clientsAccountIds;
                    }));
    if (!missingClientsFlag.get()) {
      log.info("ultimateParentCacheByClientId :: All clients found in cache");
      return Mono.just(clientAccountsMap);
    }
    Set<Long> missingClientIds =
        clientAccountsMap.entrySet().stream()
            .filter(longListEntry -> longListEntry.getValue().isEmpty())
            .map(Map.Entry::getKey)
            .collect(Collectors.toSet());
    log.info("ultimateParentCacheByClientId :: clientIds missing in cache {}", missingClientIds);
    return Flux.fromIterable(missingClientIds)
        .flatMap(
            clientId ->
                businessWSClient
                    .getUltimateParentMapFromClients(Set.of(clientId))
                    .map(
                        accIds -> {
                          clientAccountsMap.put(clientId, accIds.get(clientId));
                          redisTemplate
                              .opsForHash()
                              .put(
                                  BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_CLIENT_ID,
                                  clientId,
                                  accIds.get(clientId));
                          return accIds;
                        })
                    .onErrorResume(
                        e -> {
                          log.error(
                              "Exception BusinessWs : Client has access to accounts not found for clientId {}",
                              clientId,
                              e);
                          return Mono.empty();
                        }))
        .then(Mono.just(clientAccountsMap));
  }

  public Mono<BusinessAccount> enrichClientUltimateParentIdOnBusinessAccount(
      BusinessAccount businessAccount) {
    log.info("enrichClientUltimateParentIdOnBusinessAccount method call : {}", businessAccount);
    if (businessAccount == null) {
      return Mono.empty();
    }
    SortedMap<Integer, Long> clientsAccountIds =
        (SortedMap<Integer, Long>)
            redisTemplate
                .opsForHash()
                .get(BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID, businessAccount.getId());
    if ((clientsAccountIds == null) || clientsAccountIds.isEmpty()) {
      log.info("Account:{} Not present in clientUltimateParentCache ", businessAccount.getId());
      return businessWSClient
          .getUltimateParentMapFromAccounts(Set.of(businessAccount.getId()))
          .map(
              ultimateParentSortedMap -> {
                if ((ultimateParentSortedMap != null)
                    && ultimateParentSortedMap.containsKey(businessAccount.getId())) {
                  redisTemplate
                      .opsForHash()
                      .putAll(
                          BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID, ultimateParentSortedMap);
                  var parentMap = ultimateParentSortedMap.get(businessAccount.getId());
                  return businessAccount.toBuilder()
                      .ultimateParentId(parentMap.get(parentMap.lastKey()))
                      .build();
                }
                return businessAccount.toBuilder().build();
              });
    }
    SortedMap<Integer, Long> parentMap =
        (SortedMap<Integer, Long>)
            redisTemplate
                .opsForHash()
                .get(BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID, businessAccount.getId());
    if ((parentMap != null) && !parentMap.isEmpty()) {
      log.info(
          "Account:{} present in clientUltimateParentCacheByAccId, parentId:{} ",
          businessAccount.getId(),
          parentMap.get(parentMap.lastKey()));
      return Mono.just(
          businessAccount.toBuilder().ultimateParentId(parentMap.get(parentMap.lastKey())).build());
    }
    return Mono.just(businessAccount.toBuilder().build());
  }

  public Mono<Map<Long, List<Long>>> getClientsAccountIds(List<Long> clientIds) {
    log.info("getClientsAccountIds method call : {}", clientIds);
    if ((clientIds == null) || clientIds.isEmpty()) {
      return Mono.empty();
    }
    AtomicBoolean missingClientsFlag = new AtomicBoolean(false);
    Map<Long, List<Long>> clientAccountsMap =
        clientIds.stream()
            .collect(
                Collectors.toMap(
                    Function.identity(),
                    clientId -> {
                      List<Long> clientsAccountIds =
                          (List<Long>)
                              redisTemplate
                                  .opsForHash()
                                  .get(BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE, clientId);
                      if ((clientsAccountIds == null) || clientsAccountIds.isEmpty()) {
                        missingClientsFlag.set(true);
                        return List.of();
                      }
                      return clientsAccountIds;
                    }));
    if (!missingClientsFlag.get()) {
      log.info("getClientsAccountIds :: All clients found in cache");
      return Mono.just(clientAccountsMap);
    }
    List<Long> missingClientIds =
        clientAccountsMap.entrySet().stream()
            .filter(longListEntry -> longListEntry.getValue().isEmpty())
            .map(Map.Entry::getKey)
            .toList();
    log.info("getClientsAccountIds :: clientIds missing in cache {}", missingClientIds);
    return Flux.fromIterable(missingClientIds)
        .flatMap(
            clientId ->
                businessWSClient
                    .getClientAccountIds(clientId)
                    .map(
                        accIds -> {
                          clientAccountsMap.put(clientId, accIds);
                          redisTemplate
                              .opsForHash()
                              .put(BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE, clientId, accIds);
                          return accIds;
                        })
                    .onErrorResume(
                        e -> {
                          log.error(
                              "Exception BusinessWs : Client Has access to accounts not found for accId {}",
                              clientId,
                              e);
                          return Mono.empty();
                        }))
        .then(Mono.just(clientAccountsMap));
  }

  public Mono<List<Long>> getClientAccountIds(Long clientId) {
    if (clientId == null) {
      return Mono.empty();
    }
    return getClientsAccountIds(List.of(clientId))
        .filter(longListMap -> longListMap.containsKey(clientId))
        .map(longListMap -> longListMap.get(clientId))
        .onErrorResume(Mono::error);
  }

  public Mono<Client> getClientData(Long clientId) {
    if (clientId == null) {
      return Mono.empty();
    }
    return getClientDataFromCache(List.of(clientId))
        .filter(longClientMap -> longClientMap.containsKey(clientId))
        .filter(longClientMap -> longClientMap.get(clientId) != null)
        .map(longClientMap -> longClientMap.get(clientId));
  }
}
