package com.cwan.privatefund.comment;

import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class CommentEntityTransformer implements Function<Comment, CommentEntity> {

  @Override
  public CommentEntity apply(Comment comment) {
    return CommentEntity.builder()
        .id(comment.getId())
        .message(comment.getMessage())
        .documentId(comment.getDocumentId())
        .createdBy(comment.getCreatedBy())
        .tsCreatedOn(comment.getCreatedOn())
        .modifiedBy(comment.getModifiedBy())
        .tsModifiedOn(comment.getModifiedOn())
        .build();
  }
}
