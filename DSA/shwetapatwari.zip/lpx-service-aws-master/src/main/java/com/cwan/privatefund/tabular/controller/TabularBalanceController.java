package com.cwan.privatefund.tabular.controller;

import com.ca.json2.utils.JsonUtils2;
import com.ca.ws.json.JsonTabularDataStreamingOutput;
import com.cwan.privatefund.tabular.dataset.DataSetUtils;
import com.cwan.privatefund.tabular.service.TabularBalanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.ws.rs.core.StreamingOutput;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@Slf4j
@RequestMapping(value = "/tabular/balance")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class TabularBalanceController {

  private final TabularBalanceService tabularBalanceService;
  public static final String CONTENT_DISPOSITION_HEADER = "Content-Disposition";
  public static final String CONTENT_TYPE_CSV = "text/csv";
  public static final String CONTENT_TYPE_HEADER = "Content-Type";
  public static final String CONTENT_ENCODING_HEADER = "Content-Transfer-Encoding";

  @Autowired
  public TabularBalanceController(TabularBalanceService tabularBalanceService) {
    this.tabularBalanceService = tabularBalanceService;
  }

  @PostMapping
  @Operation(summary = "Get tabular balance data")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = String.class))
            })
      })
  public Mono<String> getTabularBalanceDataPost(
      @Parameter(
              description =
                  "The request for balances contains the fieldIds, accounts, and date of the request")
          @RequestBody
          LpxBalanceRequest lpxBalanceRequest) {
    return tabularBalanceService
        .getTabularBalanceData(
            lpxBalanceRequest.getFieldIds(),
            lpxBalanceRequest.getAccountIds(),
            lpxBalanceRequest.getBeginDate() == null
                ? lpxBalanceRequest.getDate()
                : lpxBalanceRequest.getBeginDate(),
            lpxBalanceRequest.getDate())
        .publishOn(Schedulers.boundedElastic())
        .<String>handle(
            (supplier, sink) -> {
              StreamingOutput jsonStreamOutput =
                  new JsonTabularDataStreamingOutput<>(
                      "balanceData", JsonUtils2.getJsonFactory(), supplier);
              var output = new ByteArrayOutputStream();
              try {
                jsonStreamOutput.write(output);
              } catch (IOException e) {
                sink.error(new RuntimeException(e));
                return;
              }
              sink.next(output.toString(StandardCharsets.UTF_8));
            })
        .onErrorResume(
            throwable -> {
              log.info("Exception during getTabularBalanceDataPost", throwable);
              return Mono.error(throwable);
            });
  }

  @RequestMapping(value = "/knowledge-date", method = RequestMethod.GET)
  @Operation(
      summary =
          "Get balances created between supplied knowledge start dates converted into accelex format")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getBalanceInfoByKnowledgeDateBetween(
      @RequestParam(value = "forAggregates", defaultValue = "false") boolean forAggregates)
      throws IOException {
    var paborBalanceData = tabularBalanceService.getAccelexBalanceDataset(Set.of(), forAggregates);
    var dataSet =
        tabularBalanceService.getTabularAccelexBalanceData(paborBalanceData, forAggregates);
    var fileName =
        "inception_metrics_latest_at" + LocalDateTime.now().format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSV(dataSet).getBytes());
  }

  @RequestMapping(value = "/knowledge-date/accounts", method = RequestMethod.GET)
  @Operation(
      summary =
          "Get balances created between supplied knowledge start dates converted into accelex format")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getBalanceInfoByKnowledgeDateBetweenForAccounts(
      @RequestParam("beginDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate,
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate balanceDate,
      @RequestParam("accountIds") String accountCsv)
      throws IOException, ExecutionException, InterruptedException {
    Set<Long> accountIds =
        Arrays.stream(accountCsv.replaceAll(" ", "").split(","))
            .map(Long::parseLong)
            .collect(Collectors.toSet());
    if (knowledgeDate.isBefore(balanceDate)) {
      knowledgeDate = LocalDate.now();
    }
    var paborBalanceData = tabularBalanceService.getAccelexBalanceDataset(balanceDate, accountIds);
    var dataSet = tabularBalanceService.getTabularAccelexBalanceData(paborBalanceData, false);
    var fileName =
        "inception_metrics_"
            + balanceDate.format(DateTimeFormatter.ISO_DATE)
            + "_at_"
            + knowledgeDate.format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSV(dataSet).getBytes());
  }

  @RequestMapping(value = "/knowledge-date-baseline", method = RequestMethod.GET)
  @Operation(summary = "Get Prism balance created between supplied knowledge start dates")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getBaselineBalanceInfoByKnowledgeDateBetween(
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate balanceDate)
      throws IOException, ExecutionException, InterruptedException {
    var dataSet =
        tabularBalanceService.getPrismBalanceDataset(
            balanceDate, null); // accountIds are null because we want all balances
    var fileName =
        "balances"
            + balanceDate.format(DateTimeFormatter.ISO_DATE)
            + "_at_"
            + LocalDate.now().format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSVWithoutQuotes(dataSet).getBytes());
  }

  @RequestMapping(value = "/knowledge-date-baseline-by-account", method = RequestMethod.GET)
  @Operation(
      summary = "Get balance created between supplied knowledge start dates for specific account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public ResponseEntity getBaselineBalanceInfoByKnowledgeDateBetweenAndAccount(
      @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate balanceDate,
      @RequestParam("accountIds") String accountCsv)
      throws IOException, ExecutionException, InterruptedException {
    Set<Long> accountIds =
        Arrays.stream(accountCsv.replaceAll(" ", "").split(","))
            .map(Long::parseLong)
            .collect(Collectors.toSet());

    var dataSet =
        tabularBalanceService.getBaselineBalanceDataSet(LocalDate.now(), balanceDate, accountIds);
    var fileName =
        "balances_account"
            + "_"
            + balanceDate.format(DateTimeFormatter.ISO_DATE)
            + "_at_"
            + LocalDate.now().format(DateTimeFormatter.ISO_DATE);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION_HEADER, "attachment; filename=\"" + fileName + ".csv" + "\"")
        .header(CONTENT_ENCODING_HEADER, "binary")
        .header(CONTENT_TYPE_HEADER, CONTENT_TYPE_CSV)
        .body(DataSetUtils.convertDataSetToCSVWithoutQuotes(dataSet).getBytes());
  }
}
