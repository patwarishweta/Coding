package com.cwan.privatefund.security.currency;

import java.util.Collection;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecurityCurrencyRepository extends JpaRepository<SecurityCurrencyEntity, Long> {
  Collection<SecurityCurrencyEntity> findAllByCurrencyIdIn(Set<Long> currencyIds);
}
