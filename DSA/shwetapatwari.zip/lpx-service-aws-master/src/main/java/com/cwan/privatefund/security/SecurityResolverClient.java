package com.cwan.privatefund.security;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.PostRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.cwan.privatefund.security.SecurityResolverClient.SecurityResolverRequest.Request;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SecurityResolverClient {

  private final WsHttpClient wsHttpClient;
  private final Resource matchesResource;

  public SecurityResolverClient(
      WsHttpClient wsHttpClient, ServerConfiguration serverConfiguration) {
    this.wsHttpClient = wsHttpClient;
    this.matchesResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("v1/security/match")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public List<Long> resolveCIK(String cik) {
    SecurityResolverRequest securityRequest =
        new SecurityResolverRequest(List.of(new Request(cik)));
    log.info(
        "SecurityResolver resolveCIK CIK: {}, and securityRequest: {}",
        cik,
        JsonUtils2.objToJson(securityRequest));
    PostRequest request =
        matchesResource
            .doPOST(wsHttpClient)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .setRequestEntity(JsonUtils2.objToJson(securityRequest), MimeType.JSON)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      List<MatchData> matches = JsonUtils2.parseJson(is, List.class, MatchData.class);
      return matches.stream()
          .flatMap(md -> md.matches().stream())
          .map(match -> match.securityId)
          .collect(Collectors.toList());
    } catch (IOException e) {
      log.error("SecurityResolver resolveCIK error CIK: {}", cik, e);
      return List.of(); // not resolving securities should not be a fatal error
    }
  }

  public record SecurityResolverRequest(List<Request> requests) implements Serializable {
    public record Request(String cik) implements Serializable {}
  }

  public record MatchData(List<Match> matches, String uniqueRequestId) implements Serializable {
    public record Match(
        Long securityId, boolean deficient, String matchType, Integer overrideId, Integer typeId)
        implements Serializable {}
  }
}
