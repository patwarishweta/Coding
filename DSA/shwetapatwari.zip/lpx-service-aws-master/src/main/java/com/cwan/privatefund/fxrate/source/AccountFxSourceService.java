package com.cwan.privatefund.fxrate.source;

import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.SetUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountFxSourceService {
  private AccountFxSourceRepository accountFxSourceRepository;
  private AccountFxSourceEntityTransformer accountFxSourceEntityTransformer;
  private AccountFxSourceTransformer accountFxSourceTransformer;

  public AccountFxSourceService() {}

  @Autowired
  public AccountFxSourceService(
      final AccountFxSourceRepository accountFxSourceRepository,
      final AccountFxSourceEntityTransformer accountFxSourceEntityTransformer,
      final AccountFxSourceTransformer accountFxSourceTransformer) {
    this.accountFxSourceRepository = accountFxSourceRepository;
    this.accountFxSourceEntityTransformer = accountFxSourceEntityTransformer;
    this.accountFxSourceTransformer = accountFxSourceTransformer;
  }

  public FxSourceSchedule getFxSourceSchedule(Long accountId) {
    return FxSourceSchedule.build(findAllByAccountIdIn(Set.of(accountId)));
  }

  private Set<AccountFxSource> findAllByAccountIdIn(Set<Long> accountIds) {
    return accountFxSourceRepository.findAllByAccountIdIn(accountIds).stream()
        .map(accountFxSourceTransformer)
        .collect(Collectors.toSet());
  }

  public void updateFxSources(Set<AccountFxSource> updatedFxSources) {
    Set<Long> accountIds =
        updatedFxSources.stream().map(AccountFxSource::getAccountId).collect(Collectors.toSet());
    Set<AccountFxSource> storedFxSources = findAllByAccountIdIn(accountIds);
    Set<AccountFxSource> fxSourcesToSave =
        Set.copyOf(SetUtils.difference(updatedFxSources, storedFxSources));
    Set<AccountFxSource> fxSourcesToDelete =
        Set.copyOf(SetUtils.difference(storedFxSources, updatedFxSources));
    deleteAccountFxSources(fxSourcesToDelete);
    saveAccountFxSources(fxSourcesToSave);
  }

  private void deleteAccountFxSources(Set<AccountFxSource> accountFxSources) {
    Set<AccountFxSourceKey> keysToDelete =
        accountFxSources.stream()
            .map(accountFxSourceEntityTransformer)
            .map(AccountFxSourceEntity::toKey)
            .collect(Collectors.toSet());
    if (!keysToDelete.isEmpty()) {
      accountFxSourceRepository.deleteAllById(keysToDelete);
    }
  }

  private Set<AccountFxSource> saveAccountFxSources(Set<AccountFxSource> accountFxSources) {
    return accountFxSources.stream()
        .map(accountFxSourceEntityTransformer)
        .map(accountFxSourceRepository::saveAndFlush)
        .map(accountFxSourceTransformer)
        .collect(Collectors.toSet());
  }
}
