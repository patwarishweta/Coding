package com.cwan.privatefund.business.ws;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.PostRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BusinessWSApacheClient {

  private final WsHttpClient wsHttpClient;
  private final Resource accountHierarchyResource;
  private final Resource basicAccountInfoResource;
  private final AuthTokenCore authTokenCore;

  public BusinessWSApacheClient(
      WsHttpClient wsHttpClient,
      ServerConfiguration serverConfiguration,
      AuthTokenCore authTokenCore) {
    this.wsHttpClient = wsHttpClient;
    this.authTokenCore = authTokenCore;
    this.accountHierarchyResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("client/tree/accounts")
            .withAcceptType(MimeType.JSON)
            .toResource();
    this.basicAccountInfoResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("account/basicInfo")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public Map<Long, SortedMap<Integer, Long>> getUltimateParentMapFromAccounts(Set<Long> accounts) {
    int batchSize = 100;
    List<List<Long>> batches = Lists.partition(new ArrayList<>(accounts), batchSize);

    Map<Long, SortedMap<Integer, Long>> ultimateParentMap = new HashMap<>();
    for (List<Long> batch : batches) {
      ultimateParentMap.putAll(requestAccountHierarchyInBatches(batch));
    }
    return ultimateParentMap;
  }

  private Map<Long, SortedMap<Integer, Long>> requestAccountHierarchyInBatches(
      Collection<Long> accountIds) {
    PostRequest request =
        accountHierarchyResource
            .doPOST(wsHttpClient)
            .withHeader("Authorization", "Bearer " + authTokenCore.createApplicationToken())
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addQueryParams("aid", accountIds)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error(
          "BusinessWSApacheClient getUltimateParentMapFromAccounts for accounts: {}",
          accountIds,
          e);
      return Map.of(); // not resolving holding accounts should not be a fatal error
    }
  }

  public Map<Long, BasicAccountInfo> getAccountsBasicInfo(Collection<Long> accountIds) {
    GetRequest request =
        basicAccountInfoResource
            .doGET(wsHttpClient)
            .withHeader("Authorization", "Bearer " + authTokenCore.createApplicationToken())
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addQueryParams("aid", accountIds)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (Exception e) {
      log.error("BusinessWSApacheClient getAccountsBasicInfo for accountIds: {}", accountIds, e);
      throw new BusinessWSException("Error getting account basic info");
    }
  }

  public record BasicAccountInfo(
      long id,
      int clientId,
      String shortName,
      @JsonFormat(pattern = "MM/dd/yyyy") LocalDate performanceDate,
      @JsonFormat(pattern = "MM/dd/yyyy") LocalDate startDate,
      boolean aggregate,
      int custodyBankId) {}
}
