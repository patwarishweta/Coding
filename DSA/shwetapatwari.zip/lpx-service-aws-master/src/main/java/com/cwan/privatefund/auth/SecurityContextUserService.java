package com.cwan.privatefund.auth;

import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecurityContextUserService {

  private final BusinessWSCache businessWebCache;
  private final SecurityContextService securityContextService;

  /**
   * Retrieves and validates the authenticated user details from the security context.
   *
   * @return a Mono of the validated User details
   */
  public Mono<User> validateAndRetrieveUserDetails() {
    return securityContextService.getContext().flatMap(this::validateAndRetrieveUserDetails);
  }

  /**
   * Retrieves and validates the authenticated user details from the security context.
   *
   * @param securityContext the security context containing the authenticated user details
   * @return a Mono of the validated User details
   */
  public Mono<User> validateAndRetrieveUserDetails(SecurityContext securityContext) {
    return validateAndGetUserId(securityContext)
        .flatMap(businessWebCache::fetchUserDetails)
        .flatMap(this::validateAndBuildUserDetails);
  }

  /**
   * Retrieves and validates user details from the user ID.
   *
   * @param userId the user ID
   * @return a Mono of the User details
   */
  public Mono<User> validateAndRetrieveUserDetails(Long userId) {
    return businessWebCache
        .fetchUserDetails(Math.toIntExact(userId))
        .flatMap(this::validateAndBuildUserDetails);
  }

  /**
   * Validates the authentication object from the current security context and retrieves the
   * authenticated user ID.
   *
   * @return a Mono containing the authenticated user's ID if validation is successful
   * @throws AuthenticationException if the authentication object or principal is null
   */
  public Mono<Integer> validateAndGetUserId() {
    return securityContextService.getContext().flatMap(this::validateAndGetUserId);
  }

  /**
   * Validates the authentication object from the security context and retrieves the authenticated
   * user ID.
   *
   * @param securityContext the current security context
   * @return a Mono containing the authenticated user's ID if validation is successful
   * @throws AuthenticationException if the authentication object or principal is null
   */
  public Mono<Integer> validateAndGetUserId(SecurityContext securityContext) {
    var authentication = securityContext.getAuthentication();
    if (Objects.nonNull(authentication) && Objects.nonNull(authentication.getPrincipal())) {
      var userId = (Integer) authentication.getPrincipal();
      log.debug("Authenticated user ID: {}", userId);
      return Mono.just(userId);
    }
    log.error("Authentication failed. The authentication object or the principal is null");
    return Mono.error(
        new AuthenticationException(
            "Authentication failed. The authentication object or the principal is null"));
  }

  /**
   * Validates the provided user details and builds a new User object.
   *
   * @param user the User object to be validated
   * @return a Mono of the validated and built User object
   * @throws RuntimeException if the user ID, full name, or email is null or blank
   */
  Mono<User> validateAndBuildUserDetails(User user) {
    if (Objects.isNull(user.getId())
        || StringUtils.isBlank(user.getFullname())
        || StringUtils.isBlank(user.getEmail())) {
      log.error("Validation failed. User ID, full name, or email is null or blank");
      return Mono.error(
          new RuntimeException("Validation failed. User ID, full name, or email is null or blank"));
    }
    return Mono.just(
        User.builder()
            .id(user.getId())
            .fullname(user.getFullname())
            .email(user.getEmail())
            .build());
  }
}
