package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.util.StringOperationUtils;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallBlacklistService {

  private final CapitalCallBlacklistAbaRoutingService blacklistService;
  private final CapitalCallStatusUpdaterService capitalCallStatusUpdaterService;

  public Mono<Boolean> evaluateBlacklistStatus(CapitalCallDocument document) {
    return blacklistService.isAbaRoutingNumberBlacklisted(document);
  }

  public Mono<CapitalCallDocument> updateCapitalCallStatus(
      CapitalCallDocument document, Boolean isBlacklisted) {
    var routingInfo = buildRoutingInfo(document);
    var blacklistStatus = Boolean.TRUE.equals(isBlacklisted) ? "" : "not ";
    var comment =
        Objects.isNull(routingInfo)
            ? "Bank is " + blacklistStatus + "blacklisted."
            : "Bank with " + routingInfo + " is " + blacklistStatus + "blacklisted.";
    var action =
        Boolean.TRUE.equals(isBlacklisted) ? CapitalCallAction.REJECT : CapitalCallAction.APPROVE;
    var systemUser =
        User.builder()
            .id(SystemUserConstants.ID)
            .fullname(SystemUserConstants.FULL_NAME)
            .email(SystemUserConstants.EMAIL)
            .build();
    return capitalCallStatusUpdaterService
        .updateStatusAndTransform(
            systemUser, document.documentId(), document.status(), action, comment)
        .flatMap(
            updatedDocument -> {
              log.debug("Updated document status for documentId: {}", updatedDocument.documentId());
              if (Boolean.FALSE.equals(isBlacklisted)) {
                log.debug(
                    "Document not blacklisted. Proceeding with handleNewBankAccount for documentId: {}",
                    updatedDocument.documentId());
                return capitalCallStatusUpdaterService
                    .handleNewBankAccount(updatedDocument, systemUser)
                    .doOnNext(
                        bankAccount ->
                            log.debug(
                                "handleNewBankAccount completed for documentId: {}",
                                updatedDocument.documentId()))
                    .thenReturn(updatedDocument);
              }
              log.debug(
                  "Document is blacklisted. Skipping handleNewBankAccount for documentId: {}",
                  updatedDocument.documentId());
              return Mono.just(updatedDocument);
            })
        .doOnError(
            e ->
                log.error(
                    "Error processing capital call for documentId: {}", document.documentId(), e));
  }

  String buildRoutingInfo(CapitalCallDocument document) {
    if (Objects.isNull(document.bankDetail())) {
      log.warn("Bank Detail is null for document ID: {}", document.documentId());
      return null;
    }
    var abaRoutingNumber =
        StringOperationUtils.normalizeAndTrimToNull(document.bankDetail().abaRoutingNumber());
    var swiftChipsCode =
        StringOperationUtils.normalizeAndTrimToNull(document.bankDetail().swiftOrChips());
    var routingInfoBuilder = new StringBuilder();
    if (Objects.nonNull(abaRoutingNumber)) {
      routingInfoBuilder.append("ABA '").append(abaRoutingNumber).append("'");
    }
    if (Objects.nonNull(swiftChipsCode)) {
      if (!routingInfoBuilder.isEmpty()) {
        routingInfoBuilder.append(" and ");
      }
      routingInfoBuilder.append("SWIFT/CHIPS '").append(swiftChipsCode).append("'");
    }
    var routingInfo = routingInfoBuilder.toString();
    return StringUtils.isBlank(routingInfo) ? null : routingInfo;
  }
}
