package com.cwan.privatefund.tabular.service;

import static com.cwan.privatefund.constant.Constants.AGGREGATE_SECURITY_ID;
import static com.cwan.privatefund.constant.Constants.DocumentTypes.ACCOUNT_STATEMENT;
import static com.cwan.privatefund.constant.Constants.DocumentTypes.CAPITAL_CALL;
import static com.cwan.privatefund.constant.Constants.DocumentTypes.DISTRIBUTION;
import static com.cwan.privatefund.constant.Constants.LPX_CLARITY;
import static com.cwan.privatefund.constant.Constants.LPX_PRISM;
import static com.cwan.privatefund.tabular.dataset.DataSetUtils.getUltimateParentClientId;
import static com.cwan.privatefund.util.DateUtils.getStartOfQuarter;
import static java.util.stream.Collectors.groupingBy;

import com.ca.relalg.Column;
import com.ca.relalg.data.DataSet;
import com.ca.util.date.localdate.LocalDateRange;
import com.cwan.lpx.client.tabular.BalanceAmountData;
import com.cwan.lpx.client.tabular.BalanceRow;
import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.client.tabular.DocumentAuditStatus;
import com.cwan.lpx.client.tabular.LPBalanceField;
import com.cwan.lpx.client.tabular.LPBalanceField.Visiblity;
import com.cwan.lpx.client.tabular.LPField;
import com.cwan.lpx.client.tabular.PerformanceData;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.balance.BalanceService;
import com.cwan.pbor.document.DocumentService;
import com.cwan.privatefund.accelex.AccelexService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.balance.LpxBalanceService;
import com.cwan.privatefund.business.ws.BusinessWSApacheClient;
import com.cwan.privatefund.business.ws.BusinessWSApacheClient.BasicAccountInfo;
import com.cwan.privatefund.calculated.CalculatedBalanceService;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import com.cwan.privatefund.chronos.ChronosWSApacheClient;
import com.cwan.privatefund.chronos.ChronosWSApacheClient.LockdownAccountDetails;
import com.cwan.privatefund.document.DocumentInfo;
import com.cwan.privatefund.document.LpxDocumentService;
import com.cwan.privatefund.fxrate.LpxFxRateService;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient;
import com.cwan.privatefund.tabular.TabularDataSupplier;
import com.cwan.privatefund.tabular.TransactionAmountCalculator;
import com.cwan.privatefund.tabular.dataset.DataSetUtils;
import com.cwan.privatefund.tabular.service.PerformanceDataService.PerformanceKey;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.cwan.privatefund.watchlist.WatchlistService;
import com.google.common.collect.HashMultimap;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.VisibleForTesting;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class TabularBalanceService {
  public static final List<LPField> ALL_BALANCE_FIELDS;

  static {
    ALL_BALANCE_FIELDS = new ArrayList<>();
    LPBalanceField[] values = LPBalanceField.values();
    for (LPBalanceField value : values) {
      if (value.getVisibility() != Visiblity.PUBLIC) {
        ALL_BALANCE_FIELDS.add(value);
      }
    }
  }

  private final AccelexService accelexService;
  private final BalanceService balances;
  private final DocumentService documents;
  private final TransactionAmountCalculator tranAmountCalculator;
  private final PerformanceDataService performanceDataService;
  private final BusinessWSApacheClient businessWSApacheClient;
  private final ChronosWSApacheClient chronosWSApacheClient;
  private final CalculatedBalanceService calculatedBalanceService;
  private final LpxBalanceService lpxBalanceService;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final PortfolioWsApacheClient portfolioService;
  private final LpxDocumentService lpxDocumentService;
  private final LpxTransactionService transactionService;
  private final LpxFxRateService lpxFxRateService;
  private final WatchlistService watchlistService;
  private static final int MAX_SUPPORTED_PRISM_BALANCE_FIELD_ID = 227;

  public TabularBalanceService(
      final BalanceService balances,
      final DocumentService documents,
      final TransactionAmountCalculator tranAmountCalculator,
      final PerformanceDataService performanceDataService,
      final AccelexService accelexService,
      final BusinessWSApacheClient businessWSApacheClient,
      final ChronosWSApacheClient chronosWSApacheClient,
      final CalculatedBalanceService calculatedBalanceService,
      final LpxBalanceService lpxBalanceService,
      final AccountConfigServiceCache accountConfigServiceCache,
      final PortfolioWsApacheClient portfolioService,
      final LpxDocumentService lpxDocumentService,
      final LpxTransactionService transactionService,
      final LpxFxRateService lpxFxRateService,
      WatchlistService watchlistService) {
    this.balances = balances;
    this.documents = documents;
    this.tranAmountCalculator = tranAmountCalculator;
    this.performanceDataService = performanceDataService;
    this.accelexService = accelexService;
    this.businessWSApacheClient = businessWSApacheClient;
    this.chronosWSApacheClient = chronosWSApacheClient;
    this.calculatedBalanceService = calculatedBalanceService;
    this.lpxBalanceService = lpxBalanceService;
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.portfolioService = portfolioService;
    this.lpxDocumentService = lpxDocumentService;
    this.transactionService = transactionService;
    this.lpxFxRateService = lpxFxRateService;
    this.watchlistService = watchlistService;
  }

  public Mono<TabularDataSupplier> getTabularBalanceData(
      Set<Integer> fieldIds, Set<Long> accountIds, LocalDate beginDate, LocalDate asOfDate) {
    log.info(
        "Fields Requested: {} for accounts: {}  for asOfDate {}", fieldIds, accountIds, asOfDate);
    List<Integer> header =
        fieldIds.stream().sorted(Comparator.comparingInt(a -> a)).collect(Collectors.toList());

    Mono<List<CalculatedBalance>> calculatedBalanceFlux =
        Flux.fromIterable(accountIds)
            .flatMap(
                aId ->
                    calculatedBalanceService.calculateBalances(
                        aId, asOfDate, LocalDate.now(), false))
            .collectList();

    return documents
        .getDocumentsByAccountsAndDocumentDateBetween(
            accountIds, LocalDate.of(1900, 1, 1), asOfDate)
        .filter(doc -> ACCOUNT_STATEMENT.equals(doc.getType()))
        .filter(doc -> doc.getDocumentDate() != null)
        .collectMultimap(
            doc -> new LpIdentifier(doc.getAccount().getId(), doc.getSecurity().getSecurityId()),
            Function.identity())
        .flatMap(
            lpIdentifierToAllAccountStatementDocuments -> {
              // Retrieve capital account statements for supplied accountIds and date
              if ((lpIdentifierToAllAccountStatementDocuments == null)
                  || lpIdentifierToAllAccountStatementDocuments.isEmpty()) {
                return Mono.just(TabularDataSupplier.createBalanceDataSupplier(header, List.of()));
              } else {
                lpIdentifierToAllAccountStatementDocuments.forEach(
                    (key, val) -> {
                      List<String> docDateAndIdPair =
                          val.stream()
                              .map(document -> document.getDocumentDate() + ":" + document.getId())
                              .collect(Collectors.toList());
                      log.info(
                          "Documents retrieved from DB for tabular balance data  {} => {}",
                          key,
                          docDateAndIdPair);
                    });

                // find the most recent document date
                Map<Document, Collection<Balance>> latestMostDistinctBalancesByDoc =
                    getTheMostRecentDocumentForThisLPWithTheMostDistinctSetOfBalances(
                        lpIdentifierToAllAccountStatementDocuments);
                Map<LpIdentifier, Document> recentCapitalCalls =
                    getLatestDocumentsByType(accountIds, asOfDate, CAPITAL_CALL);
                Map<LpIdentifier, Document> recentDistributionNotice =
                    getLatestDocumentsByType(accountIds, asOfDate, DISTRIBUTION);

                //    currentDocuments.addAll(recentCapitalCalls.values());
                //    currentDocuments.addAll(recentDistributionNotice.values());

                Map<Long, Document> docIdToDocument =
                    latestMostDistinctBalancesByDoc.keySet().stream()
                        .collect(Collectors.toMap(Document::getId, Function.identity()));
                // Retrieve the lp-related balances that are on the documents
                // TODO Un-comment out once relates-to is implemented
                // .filter(balance -> RELATES_TO_LP.equals(balance.getRelatesTo()))

                Mono<List<Balance>> balanceListMono =
                    Mono.just(
                        latestMostDistinctBalancesByDoc.entrySet().stream()
                            .filter(Objects::nonNull)
                            .map(
                                balanceList -> {
                                  if (balanceList.getValue() == null
                                      || balanceList
                                          .getValue()
                                          .isEmpty()) { // hack in case the most recent document
                                    // doesn't contain any balances
                                    Balance dummyBalance = new Balance();
                                    dummyBalance.setAccount(balanceList.getKey().getAccount());
                                    dummyBalance.setSecurity(balanceList.getKey().getSecurity());
                                    dummyBalance.setDocument(balanceList.getKey());
                                    dummyBalance.setAmount(0.0);
                                    return Collections.singletonList(dummyBalance);
                                  }
                                  return balanceList.getValue();
                                })
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList()));

                return mergeBalanceRowsIntoSupplier(
                    accountIds,
                    beginDate,
                    asOfDate,
                    header,
                    calculatedBalanceFlux,
                    recentCapitalCalls,
                    recentDistributionNotice,
                    docIdToDocument,
                    balanceListMono);
              }
            });
  }

  /**
   * This logic is due to bad data existing in LMC. It is a gross bandaid to ensure we're sending
   * our best data to core as much as possible. It first grabs the most recent date of docs. which
   * satisfies the condition 99% of the time. The trouble occurs with multiple docs for the same
   * date for the same lp exist.
   *
   * <p>According to Eric in that case we need to grab the document for that lp and date that has
   * the most distinct set of balance types available. So that is what this function does :).
   */
  @VisibleForTesting
  protected Map<Document, Collection<Balance>>
      getTheMostRecentDocumentForThisLPWithTheMostDistinctSetOfBalances(
          Map<LpIdentifier, Collection<Document>> lpIdentifierToAllAccountStatementDocuments) {
    Map<LpIdentifier, Set<Document>> documentsToRetrieveForLp = new HashMap<>();
    for (var entry : lpIdentifierToAllAccountStatementDocuments.entrySet()) {
      LocalDate mostRecentDocDate =
          entry.getValue().stream()
              .map(Document::getDocumentDate)
              .max(Comparator.naturalOrder())
              .orElse(null);

      if (mostRecentDocDate == null) {
        continue;
      }

      documentsToRetrieveForLp.put(
          entry.getKey(),
          entry.getValue().stream()
              .filter(f -> f.getDocumentDate().equals(mostRecentDocDate))
              .collect(Collectors.toSet()));
    }

    Map<Long, Collection<Balance>> docToBalances =
        balances
            .getBalancesByDocumentIds(
                documentsToRetrieveForLp.values().stream()
                    .flatMap(Collection::stream)
                    .map(Document::getId)
                    .collect(Collectors.toSet()))
            .collectMultimap(f -> f.getDocument().getId())
            .toFuture()
            .join();

    Map<Document, Collection<Balance>> returnMap = new HashMap<>();

    // breaks ties in case more than 1 document is marked as most recent, returns the one with the
    // most distinct balance types
    for (var entry : documentsToRetrieveForLp.entrySet()) {
      entry.getValue().stream()
          .map(
              doc ->
                  new DocumentBalanceCount(
                      doc,
                      docToBalances.get(doc.getId()) == null
                          ? 0
                          : docToBalances.get(doc.getId()).stream()
                              .map(Balance::getType)
                              .distinct()
                              .count()))
          .max(Comparator.comparing(DocumentBalanceCount::count))
          .ifPresent(
              documentBalanceCount ->
                  returnMap.put(
                      documentBalanceCount.document,
                      docToBalances.get(documentBalanceCount.document.getId())));
    }
    return returnMap;
  }

  private void setPublicFields(
      Collection<BalanceRow> balanceRows,
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate) {
    List<Transaction> allTransactions =
        transactionService
            .getTransactions(
                accountIds,
                beginDate.minusDays(1),
                endDate,
                LocalDateTime.now(),
                "TRN",
                false,
                false)
            .collectList()
            .toFuture()
            .join();
    Map<LpIdentifier, List<Transaction>> navTransactionsByLp =
        allTransactions.stream()
            .filter(c -> c.getType().equals("NAV"))
            .collect(
                Collectors.groupingBy(
                    c ->
                        new LpIdentifier(c.getAccount().getId(), c.getSecurity().getSecurityId())));
    Map<LpIdentifier, TreeMap<LocalDate, Double>> lpIdentifierToTreeMap = new HashMap<>();
    for (Long accountId : accountIds) {
      Map<Long, Map<LocalDate, Double>> securityFxRateMap =
          lpxFxRateService.getSecurityAverageFxRatesByBasis(1L, accountId).get(-1);
      if (securityFxRateMap == null) {
        continue;
      }
      for (Entry<Long, Map<LocalDate, Double>> entry : securityFxRateMap.entrySet()) {
        lpIdentifierToTreeMap.put(
            new LpIdentifier(accountId, entry.getKey()), new TreeMap<>(entry.getValue()));
      }
    }

    for (BalanceRow balanceRow : balanceRows) {
      LpIdentifier lpIdentifier =
          new LpIdentifier(balanceRow.getAccountId(), balanceRow.getSecurityId());
      List<Transaction> navTransactionsForLp = navTransactionsByLp.get(lpIdentifier);
      List<LocalDate> orderedNavTransactions = new ArrayList<>();
      Map<LocalDate, Double> dateToNavImpact = Collections.emptyMap();
      if (navTransactionsForLp != null) {
        dateToNavImpact =
            navTransactionsForLp.stream()
                .collect(
                    Collectors.toMap(
                        Transaction::getSettleDate, Transaction::getNavImpact, Double::sum));
        orderedNavTransactions =
            dateToNavImpact.keySet().stream().sorted().collect(Collectors.toList());
      }

      balanceRow.setDatesOfNAVTransactionsInPeriod(orderedNavTransactions);
      TreeMap<LocalDate, Double> averageFxMap =
          lpIdentifierToTreeMap.getOrDefault(lpIdentifier, new TreeMap<>());
      averageFxMap.keySet().retainAll(orderedNavTransactions);

      balanceRow.setAverageFXSchedule(
          lpIdentifierToTreeMap.getOrDefault(lpIdentifier, new TreeMap<>()));
      balanceRow.setNavAmountsSchedule(dateToNavImpact);
    }
  }

  private Mono<TabularDataSupplier> mergeBalanceRowsIntoSupplier(
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      List<Integer> header,
      Mono<List<CalculatedBalance>> finalCalculatedBalanceFlux,
      Map<LpIdentifier, Document> recentCapitalCalls,
      Map<LpIdentifier, Document> recentDistributionNotice,
      Map<Long, Document> docIdToDocument,
      Mono<List<Balance>> balanceListMono) {
    return Mono.zip(
        balanceListMono,
        finalCalculatedBalanceFlux,
        (balance, calculatedBalances) -> {
          var balanceList = getLatestBalancesPerType(balance);

          var balanceRows =
              convertBalancesToBalanceRows(
                  balanceList,
                  docIdToDocument,
                  recentCapitalCalls,
                  recentDistributionNotice,
                  calculatedBalances,
                  endDate);

          balanceRows = filterToOpenLotsOnly(balanceRows, endDate);

          // Fill-in transaction data if any transaction fields are being requested
          if (!Collections.disjoint(header, LPBalanceField.getTransactionSumFieldIds())) {
            tranAmountCalculator.addTransactionSumsToBalanceRows(balanceRows);
          }
          // Fill-in performance data if any performance fields are being requested
          if (!Collections.disjoint(header, LPBalanceField.getPerformanceFieldIds())) {
            Map<PerformanceKey, PerformanceData> performanceDataMap =
                performanceDataService.getPerformanceData(accountIds, endDate);
            setPerformanceData(performanceDataMap, balanceRows);
          }

          Set<Integer> publicFieldIds =
              Arrays.stream(LPBalanceField.values())
                  .filter(c -> c.getVisibility() == Visiblity.PUBLIC)
                  .map(LPBalanceField::getId)
                  .collect(Collectors.toSet());

          if (!Collections.disjoint(header, publicFieldIds)) {
            setPublicFields(balanceRows, accountIds, beginDate, endDate);
          }

          return convertBalanceRowsToTabularDataSupplier(header, balanceRows);
        });
  }

  @NotNull
  private TabularDataSupplier convertBalanceRowsToTabularDataSupplier(
      List<Integer> header, Set<BalanceRow> balanceRows) {
    List<Iterable<Object>> data =
        balanceRows.stream().map(br -> getRow(br, header)).collect(Collectors.toList());
    return TabularDataSupplier.createBalanceDataSupplier(header, data);
  }

  private static void setPerformanceData(
      Map<PerformanceKey, PerformanceData> performanceDataMap, Collection<BalanceRow> balanceRows) {
    balanceRows.forEach(
        br -> {
          PerformanceData performanceData =
              performanceDataMap.get(new PerformanceKey(br.getAccountId(), br.getSecurityId()));
          br.setPerformanceData(
              performanceData == null ? PerformanceData.builder().build() : performanceData);
        });
  }

  private Map<LpIdentifier, Document> getLatestDocumentsByType(
      Set<Long> accountIds, LocalDate asOfDate, String documentType) {
    // Retrieve documents for supplied accountIds and date
    var documentList =
        documents
            .getDocumentsByAccountsAndDocumentDateBetween(
                accountIds, LocalDate.of(1900, 1, 1), asOfDate)
            .filter(doc -> documentType.equals(doc.getType()))
            .filter(doc -> doc.getDocumentDate() != null)
            .collectMultimap(
                doc ->
                    new LpIdentifier(doc.getAccount().getId(), doc.getSecurity().getSecurityId()),
                Function.identity())
            .share()
            .block();
    // find the most recent document date
    Map<LpIdentifier, Document> recentDocuments = new HashMap<>();
    if (documentList != null) {
      documentList.forEach(
          (lpIdentifier, documentsCollection) -> {
            recentDocuments.put(
                lpIdentifier,
                documentsCollection.stream()
                    .max(Comparator.comparing(Document::getDocumentDate))
                    .orElseThrow(
                        () -> new IllegalStateException("This state should not be reachable")));
          });
    }
    return recentDocuments;
  }

  private Iterable<Object> getRow(BalanceRow balanceRow, List<Integer> headerFieldIds) {
    return headerFieldIds.stream()
        .map(fieldId -> LPBalanceField.fromId(fieldId).apply(balanceRow))
        .collect(Collectors.toList());
  }

  private List<Object> getRowList(BalanceRow balanceRow, List<LPField> balanceFields) {
    return balanceFields.stream()
        .map(field -> field.apply(balanceRow))
        .collect(Collectors.toList());
  }

  private Set<BalanceRow> convertBalancesToBalanceRows(
      List<Balance> balanceList,
      Map<Long, Document> docIdToDocument,
      @NonNull Map<LpIdentifier, Document> recentCapitalCalls,
      @NonNull Map<LpIdentifier, Document> recentDistributionNotice,
      List<CalculatedBalance> calculatedBalances,
      LocalDate asOfDate) {
    if (balanceList == null) {
      return new HashSet<>();
    }
    Map<Long, Map<Long, Boolean>> watchlistEntities = getWatchlistEntities(balanceList, asOfDate);
    Map<Long, DocumentInfo> documentInfoById =
        lpxDocumentService
            .getDocumentInfos(Flux.fromIterable(docIdToDocument.values()))
            .collectList()
            .toFuture()
            .join()
            .stream()
            .filter(
                documentInfo ->
                    documentInfo.getDocumentEntity() != null
                        && documentInfo.getDocumentAuditValidationEntity().getDocumentId() != null)
            .collect(
                Collectors.toMap(
                    documentInfo -> documentInfo.getDocumentAuditValidationEntity().getDocumentId(),
                    Function.identity()));

    Map<LpIdentifier, CalculatedBalance> securityIdToCalculatedBalanceMap;
    if (calculatedBalances != null && (!calculatedBalances.isEmpty())) {
      securityIdToCalculatedBalanceMap =
          calculatedBalances.stream()
              .collect(
                  Collectors.toMap(
                      b ->
                          new LpIdentifier(b.getAccount().getId(), b.getSecurity().getSecurityId()),
                      Function.identity(),
                      (a, b) -> b)); // if we have a collision on LP we probably loaded an agg and
      // calculated a simple twice, we'll just pick one
    } else {
      securityIdToCalculatedBalanceMap = null;
    }

    Map<LpIdentifier, BalanceRow> lpIdentifierToBalanceRow = new HashMap<>();
    Map<LpIdentifier, Balance> lpIdentifierToBalance = new HashMap<>();
    for (Balance balance : balanceList) {
      var docId = balance.getDocument().getId();
      if (docId == null) {
        break;
      }
      LpIdentifier lpIdentifier =
          new LpIdentifier(balance.getAccount().getId(), balance.getSecurity().getSecurityId());

      if ("ENDING_NAV".equalsIgnoreCase(balance.getType())) {
        lpIdentifierToBalance.put(lpIdentifier, balance);
      }

      lpIdentifierToBalanceRow.computeIfAbsent(
          lpIdentifier,
          id -> {
            var document = docIdToDocument.get(docId);
            var latestCapitalCall =
                recentCapitalCalls.get(
                    new LpIdentifier(
                        document.getAccount().getId(), document.getSecurity().getSecurityId()));
            var latestDistributionNotice =
                recentDistributionNotice.get(
                    new LpIdentifier(
                        document.getAccount().getId(), document.getSecurity().getSecurityId()));
            // Lookup the calculated Balance for this security
            CalculatedBalance calculatedBalance = null;
            if (securityIdToCalculatedBalanceMap != null) {
              calculatedBalance =
                  securityIdToCalculatedBalanceMap.get(
                      new LpIdentifier(
                          document.getAccount().getId(), document.getSecurity().getSecurityId()));
            }
            DocumentInfo documentInfo = documentInfoById.get(docId);
            Pair<DocumentAuditStatus, LocalDate> documentAuditStatus =
                getLatestAccountStatementValidationStatus(documentInfo, document);

            return new BalanceRow(
                docId,
                document.getAccount().getId().intValue(),
                document.getSecurity().getSecurityId().intValue(),
                document.getReceivedDate(),
                document.getDocumentDate(),
                balance.getEntryDate(),
                balance.getBalanceDate() == null
                    ? document.getDocumentDate()
                    : balance.getBalanceDate(),
                balance.getSource(),
                balance.getKnowledgeStartDate(),
                balance.getKnowledgeEndDate(),
                calculatedBalance == null ? balance.getCurrency() : calculatedBalance.getCurrency(),
                calculatedBalance == null
                    ? balance.getFxCurrency()
                    : calculatedBalance.getCurrency(),
                document.getDocumentDate(), // latest account statement
                latestCapitalCall != null ? latestCapitalCall.getDocumentDate() : null,
                latestDistributionNotice != null
                    ? latestDistributionNotice.getDocumentDate()
                    : null,
                calculatedBalance != null ? calculatedBalance.getNavImpact() : null,
                calculatedBalance != null ? calculatedBalance.getTotalCommitment() : null,
                calculatedBalance != null ? calculatedBalance.getUnfundedCommitmentImpact() : null,
                calculatedBalance != null ? calculatedBalance.getFundedCommitmentImpact() : null,
                calculatedBalance != null ? calculatedBalance.getRecallableImpact() : null,
                null,
                null,
                documentAuditStatus.getLeft(),
                documentAuditStatus.getRight(),
                watchlistEntities != null
                    && watchlistEntities.get(lpIdentifier.accountId) != null
                    && watchlistEntities
                        .get(lpIdentifier.accountId())
                        .containsKey(lpIdentifier.securityId()),
                calculatedBalance != null ? calculatedBalance.getWatchlistNavImpact() : null,
                calculatedBalance != null ? calculatedBalance.getGaapNavImpact() : null,
                calculatedBalance != null ? calculatedBalance.getStatNavImpact() : null);
          });
      var amountData =
          new BalanceAmountData(
              balance.getAmount(),
              balance.getAmountMTD() == null ? 0.0 : balance.getAmountMTD(),
              balance.getAmountQTD() == null ? 0.0 : balance.getAmountQTD(),
              balance.getAmountYTD() == null ? 0.0 : balance.getAmountYTD(),
              balance.getAmountITD() == null ? 0.0 : balance.getAmountITD());
      lpIdentifierToBalanceRow.get(lpIdentifier).addBalanceUnsafe(balance.getType(), amountData);
      Double reportedUnits =
          lpIdentifierToBalance.containsKey(lpIdentifier)
              ? lpIdentifierToBalance.get(lpIdentifier).getUnits()
              : null;
      Double reportedNavPerShare =
          reportedUnits != null && reportedUnits != 0
              ? lpIdentifierToBalance.get(lpIdentifier).getAmount() / reportedUnits
              : null;
      log.info("lpIdentifierToBalance {}", lpIdentifierToBalance);
      lpIdentifierToBalanceRow.get(lpIdentifier).setReportedUnit(reportedUnits);
      lpIdentifierToBalanceRow.get(lpIdentifier).setReportedNavPerShare(reportedNavPerShare);
    }
    // Extract unique security Ids from BalanceRows created so far
    Set<LpIdentifier> usedLpIdentifiers =
        lpIdentifierToBalanceRow.values().stream()
            .map(br -> new LpIdentifier(br.getAccountId(), br.getSecurityId()))
            .collect(Collectors.toSet());

    if (calculatedBalances != null) {
      for (CalculatedBalance calculatedBalance : calculatedBalances) {
        LpIdentifier calculatedBalanceIdentifier =
            new LpIdentifier(
                calculatedBalance.getAccount().getId(),
                calculatedBalance.getSecurity().getSecurityId());

        // If balance with this lpIdentifier already exists, skip
        if (usedLpIdentifiers.contains(calculatedBalanceIdentifier)) {
          continue;
        }

        Document latestCapitalCall = recentCapitalCalls.get(calculatedBalanceIdentifier);
        Document latestDistributionNotice =
            recentDistributionNotice.get(calculatedBalanceIdentifier);

        // Create new BalanceRow based on the CalculatedBalance
        BalanceRow balanceRow =
            new BalanceRow(
                0,
                calculatedBalance.getAccount().getId().intValue(),
                calculatedBalance.getSecurity().getSecurityId().intValue(),
                null,
                null,
                null,
                null,
                calculatedBalance.getSource(),
                null,
                null,
                calculatedBalance.getCurrency(),
                calculatedBalance.getCurrency(),
                null,
                latestCapitalCall != null ? latestCapitalCall.getDocumentDate() : null,
                latestDistributionNotice != null
                    ? latestDistributionNotice.getDocumentDate()
                    : null,
                calculatedBalance.getNavImpact(),
                calculatedBalance.getTotalCommitment(),
                calculatedBalance.getUnfundedCommitmentImpact(),
                calculatedBalance.getFundedCommitmentImpact(),
                calculatedBalance.getRecallableImpact(),
                null,
                null,
                DocumentAuditStatus
                    .MISSING, // if we got here we have no documents, so it has to be missing
                null,
                watchlistEntities != null
                    && watchlistEntities.get(calculatedBalance.getAccount().getId()) != null
                    && watchlistEntities
                        .get(calculatedBalance.getAccount().getId())
                        .containsKey(calculatedBalance.getSecurity().getSecurityId()),
                calculatedBalance.getWatchlistNavImpact(),
                calculatedBalance.getGaapNavImpact(),
                calculatedBalance.getStatNavImpact());

        var amountData = new BalanceAmountData(0.0, 0.0, 0.0, 0.0, 0.0);
        balanceRow.addBalanceUnsafe(
            BalanceType.REPORTED_ENDING_NAV.getCode(),
            amountData); // Updating the placeholder for BalanceType with the correct one

        lpIdentifierToBalanceRow.put(
            new LpIdentifier(balanceRow.getAccountId(), balanceRow.getSecurityId()),
            balanceRow); // Using accountId for uniqueness (adjust as needed)
      }
    }
    return new HashSet<>(lpIdentifierToBalanceRow.values());
  }

  private Map<Long, Map<Long, Boolean>> getWatchlistEntities(
      List<Balance> balanceList, LocalDate asOfDate) {
    Map<Long, Map<Long, Boolean>> watchlistEntities =
        watchlistService.getActiveOnWatchlist(
            balanceList.stream().map(b -> b.getAccount().getId()).collect(Collectors.toList()),
            asOfDate);
    return watchlistEntities;
  }

  @VisibleForTesting
  protected static Pair<DocumentAuditStatus, LocalDate> getLatestAccountStatementValidationStatus(
      DocumentInfo documentInfo, Document document) {
    // If the document is missing, then the validation status is missing
    if (document == null || document.getDocumentDate() == null) {
      return Pair.of(DocumentAuditStatus.MISSING, null);
    }
    DocumentAuditStatus documentAuditStatus =
        document.getChecked() != null && document.getChecked()
            ? DocumentAuditStatus.VALIDATED
            : DocumentAuditStatus.NOT_VALIDATED;
    LocalDate validationDate =
        documentInfo == null || documentInfo.validationDate() == null
            ? null
            : documentInfo.validationDate().toLocalDate();
    return Pair.of(
        documentAuditStatus,
        documentAuditStatus == DocumentAuditStatus.VALIDATED && validationDate == null
            ? document.getModifiedOn().toLocalDate()
            : validationDate);
  }

  private List<Balance> getLatestBalancesPerType(List<Balance> balanceList) {
    if ((Objects.isNull(balanceList)) || (balanceList.isEmpty())) {
      return List.of();
    }
    Map<String, Balance> balanceMap = new HashMap<>();
    balanceList.forEach(
        balance -> {
          var type =
              balance.getType()
                  + ":"
                  + balance.getAccount().getId()
                  + ":"
                  + balance.getSecurity().getSecurityId();

          if (!balanceMap.containsKey(type)
              || (balanceMap.containsKey(type)
                  && balanceMap.get(type).getModifiedOn().isBefore(balance.getModifiedOn()))) {
            balanceMap.put(type, balance);
          }
        });
    List<Balance> resultBalanceList = new ArrayList<>();
    balanceMap.forEach((type, balance) -> resultBalanceList.add(balance));
    return resultBalanceList;
  }

  public DataSet<Column> getAccelexBalanceDataset(Set<Long> accountIds, boolean forAggregates) {
    Set<Long> accelexAccounts =
        accountConfigServiceCache.getAllAccountsWithAttribute(accountIds, LPX_CLARITY);

    Set<Long> relevantAccounts =
        businessWSApacheClient.getAccountsBasicInfo(accelexAccounts).values().stream()
            .filter(c -> c.aggregate() == forAggregates)
            .map(BasicAccountInfo::id)
            .collect(Collectors.toSet());

    // this dataset only contains calculated balances for this date
    Map<String, LockdownAccountDetails> latestLockdownDateForAccounts =
        chronosWSApacheClient.getLatestLockdownDateForAccounts(relevantAccounts);
    Map<LocalDate, Set<Long>> lockdownDateMap = getLockdownDateMap(latestLockdownDateForAccounts);
    Map<LocalDate, Collection<Long>> fullRunDateMapForAccelex =
        getPriorThreeQuarterEndDateMap(lockdownDateMap);
    return getColumnDataSet(
        fullRunDateMapForAccelex, relevantAccounts, ALL_BALANCE_FIELDS, forAggregates);
  }

  @VisibleForTesting
  protected static Map<LocalDate, Collection<Long>> getPriorThreeQuarterEndDateMap(
      Map<LocalDate, Set<Long>> lockdownDateMap) {
    HashMultimap<LocalDate, Long> dateMap = HashMultimap.create();
    for (Map.Entry<LocalDate, Set<Long>> entry : lockdownDateMap.entrySet()) {
      LocalDate lockdownDate = entry.getKey(); // lockdownDate
      LocalDate priorQuarter = getStartOfQuarter(lockdownDate).minusDays(1); // end of prior quarter
      LocalDate priorPriorQuarter = getStartOfQuarter(priorQuarter).minusDays(1); // 2 quarters ago
      LocalDate priorPriorPriorQuarter =
          getStartOfQuarter(priorPriorQuarter).minusDays(1); // 3 quarters ago
      dateMap.putAll(lockdownDate, entry.getValue());
      dateMap.putAll(priorQuarter, entry.getValue());
      dateMap.putAll(priorPriorQuarter, entry.getValue());
      dateMap.putAll(priorPriorPriorQuarter, entry.getValue());
    }
    return dateMap.asMap();
  }

  private static Map<LocalDate, Set<Long>> getLockdownDateMap(
      Map<String, LockdownAccountDetails> latestLockdownDateForAccounts) {
    return latestLockdownDateForAccounts.entrySet().stream()
        .map(
            c ->
                new LockdownData(
                    Long.parseLong(c.getKey().split(":")[1]),
                    c.getValue().currentLockdownData().lockdownDate() == null
                        ? LocalDate.now()
                        : c.getValue().currentLockdownData().lockdownDate()))
        .collect(
            groupingBy(
                LockdownData::lockdownDate,
                Collectors.mapping(c -> c.accountId, Collectors.toSet())));
  }

  public DataSet<Column> getAccelexBalanceDataset(LocalDate balanceDate, Set<Long> accountIds)
      throws ExecutionException, InterruptedException {
    Set<Long> simpleAccounts =
        accountConfigServiceCache.getAllAccountsWithAttribute(accountIds, LPX_CLARITY);
    // this dataset only contains calculated balances for this date
    return getColumnDataSet(
        Map.of(balanceDate, simpleAccounts), simpleAccounts, ALL_BALANCE_FIELDS, false);
  }

  public DataSet<Column> getPrismBalanceDataset(LocalDate balanceDate, Set<Long> accountIds)
      throws ExecutionException, InterruptedException {
    Set<Long> simpleAccounts =
        accountConfigServiceCache.getAllAccountsWithAttribute(accountIds, LPX_PRISM);
    List<LPField> supportedFields =
        ALL_BALANCE_FIELDS.stream()
            .filter(f -> f.getId() < MAX_SUPPORTED_PRISM_BALANCE_FIELD_ID)
            .toList();
    // this dataset only contains calculated balances for this date
    return getColumnDataSet(
        Map.of(balanceDate, simpleAccounts), simpleAccounts, supportedFields, false);
  }

  private DataSet<Column> getColumnDataSet(
      Map<LocalDate, Collection<Long>> dateToAccount,
      Set<Long> simpleAccounts,
      List<LPField> requestedFields,
      boolean forAggregates) {
    var ultimateParentMapFromAccounts =
        businessWSApacheClient.getUltimateParentMapFromAccounts(simpleAccounts);
    DataSet<Column> allData = new DataSet<>();
    for (Entry<LocalDate, Collection<Long>> entry : dateToAccount.entrySet()) {

      DataSet<Column> calculatedBalancesForDate =
          getCalculatedBalancesForDate(
              new HashSet<>(entry.getValue()), entry.getKey(), requestedFields, forAggregates);
      if (allData.isEmpty()) {
        allData = calculatedBalancesForDate;
      } else {
        allData = allData.query().unionAll(calculatedBalancesForDate).go();
      }
    }
    return allData
        .query()
        .filter(
            row ->
                row.get(LPBalanceField.ACCOUNT_ID) != null
                    && simpleAccounts.contains(row.getLong(LPBalanceField.ACCOUNT_ID)))
        .extend(
            row ->
                getUltimateParentClientId(
                    ultimateParentMapFromAccounts, row.getInt(LPBalanceField.ACCOUNT_ID)),
            () -> "ultimateParentClientId")
        .go();
  }

  public DataSet<Column> getCalculatedBalancesForDate(
      Set<Long> accountIds,
      LocalDate effectiveDate,
      List<LPField> requestedFields,
      boolean forAggregates) {
    Set<CalculatedBalance> calculatedBalances = new HashSet<>();
    for (Long accountId : accountIds) {
      List<CalculatedBalance> calculatedBalancesForAccount =
          calculatedBalanceService
              .calculateBalances(accountId, effectiveDate, LocalDate.now(), false)
              .collectList()
              .toFuture()
              .join();
      if (forAggregates) {
        calculatedBalances.add(buildCalculatedBalancesAgg(calculatedBalancesForAccount, accountId));
      } else {
        calculatedBalances.addAll(calculatedBalancesForAccount);
      }
    }
    Collection<BalanceRow> balanceRows =
        convertCalculatedBalancesToBalanceRow(calculatedBalances, effectiveDate, forAggregates);
    return convertBalanceRowsToTabular(balanceRows, requestedFields, effectiveDate);
  }

  @VisibleForTesting
  protected static CalculatedBalance buildCalculatedBalancesAgg(
      List<CalculatedBalance> calculatedBalances, long accountId) {
    Double aggNav =
        calculatedBalances.stream()
            .map(CalculatedBalance::getNavImpact)
            .reduce(Double::sum)
            .orElse(0.0);
    Double aggWatchlistNav =
        calculatedBalances.stream()
            .map(CalculatedBalance::getWatchlistNavImpact)
            .reduce(Double::sum)
            .orElse(0.0);
    Double aggRecallable =
        calculatedBalances.stream()
            .map(CalculatedBalance::getRecallableImpact)
            .reduce(Double::sum)
            .orElse(0.0);
    Double aggTotalCommitment =
        calculatedBalances.stream()
            .map(CalculatedBalance::getTotalCommitment)
            .reduce(Double::sum)
            .orElse(0.0);
    Double aggFundedCommitment =
        calculatedBalances.stream()
            .map(CalculatedBalance::getFundedCommitmentImpact)
            .reduce(Double::sum)
            .orElse(0.0);
    Double aggTotalContributions =
        calculatedBalances.stream()
            .map(CalculatedBalance::getTotalContributions)
            .reduce(Double::sum)
            .orElse(0.0);
    Double aggTotalDistributions =
        calculatedBalances.stream()
            .map(CalculatedBalance::getTotalDistributions)
            .reduce(Double::sum)
            .orElse(0.0);
    Set<String> currencies =
        calculatedBalances.stream().map(CalculatedBalance::getCurrency).collect(Collectors.toSet());

    return CalculatedBalance.builder()
        .account(Account.builder().id(accountId).build())
        .security(Security.builder().securityId(AGGREGATE_SECURITY_ID).build())
        .totalCommitment(aggTotalCommitment)
        .fundedCommitmentImpact(aggFundedCommitment)
        .watchlistNavImpact(aggWatchlistNav)
        .totalDistributions(aggTotalDistributions)
        .totalContributions(aggTotalContributions)
        .recallableImpact(aggRecallable)
        .navImpact(aggNav)
        .currency(currencies.size() == 1 ? currencies.iterator().next() : "USD")
        .build();
  }

  public DataSet<Column> getBaselineBalanceDataSet(
      LocalDate knowledgeDate, LocalDate balanceDate, Set<Long> accountIds)
      throws ExecutionException, InterruptedException {
    Set<Long> simpleAccounts =
        accountConfigServiceCache.getAllAccountsWithAttribute(accountIds, LPX_PRISM);

    DataSet<Column> allDocumentBalanceFields =
        getAllDocumentBalanceFields(knowledgeDate, balanceDate, simpleAccounts);

    var ultimateParentMapFromAccounts =
        businessWSApacheClient.getUltimateParentMapFromAccounts(simpleAccounts);
    return allDocumentBalanceFields
        .query()
        .extend(
            row ->
                getUltimateParentClientId(
                    ultimateParentMapFromAccounts, row.getInt(LPBalanceField.ACCOUNT_ID)),
            () -> "ultimateParentClientId")
        .go();
  }

  private DataSet<Column> getAllDocumentBalanceFields(
      LocalDate knowledgeDate, LocalDate balanceDate, Set<Long> accountIds)
      throws ExecutionException, InterruptedException {
    Map<LpIdentifier, Document> recentCapitalCalls =
        getLatestDocumentByAccountId(accountIds, CAPITAL_CALL);
    Map<LpIdentifier, Document> recentDistributionNotice =
        getLatestDocumentByAccountId(accountIds, DISTRIBUTION);
    List<CalculatedBalance> calculatedBalances = new ArrayList<>();
    for (Long accountId : accountIds) {
      calculatedBalances.addAll(
          calculatedBalanceService
              .calculateBalances(accountId, balanceDate, knowledgeDate, true)
              .collectList()
              .toFuture()
              .get());
    }
    List<Balance> accountsBalances =
        lpxBalanceService
            .getAccountsBalances(accountIds, balanceDate, knowledgeDate)
            .collectList()
            .toFuture()
            .get();
    return convertBalanceRowsToTabular(
        convertBalanceListToBalanceRows(
            accountsBalances,
            recentCapitalCalls,
            recentDistributionNotice,
            calculatedBalances,
            balanceDate),
        ALL_BALANCE_FIELDS,
        balanceDate);
  }

  private Map<LpIdentifier, Document> getLatestDocumentByAccountId(
      Set<Long> accountIds, String documentType) {
    var documentList =
        documents
            .getDocumentsByAccountId(accountIds)
            .filter(doc -> documentType.equals(doc.getType()))
            .filter(doc -> doc.getDocumentDate() != null)
            .collectMultimap(
                doc ->
                    new LpIdentifier(doc.getAccount().getId(), doc.getSecurity().getSecurityId()),
                Function.identity())
            .share()
            .block();
    // find the most recent document date
    Map<LpIdentifier, Document> recentDocuments = new HashMap<>();
    if (documentList != null) {
      documentList.forEach(
          (lpIdentifier, documentsCollection) -> {
            recentDocuments.put(
                lpIdentifier,
                documentsCollection.stream()
                    .max(Comparator.comparing(Document::getDocumentDate))
                    .orElseThrow(
                        () -> new IllegalStateException("This state should not be reachable")));
          });
    }
    return recentDocuments;
  }

  private Collection<BalanceRow> convertBalanceListToBalanceRows(
      List<Balance> balanceList,
      Map<LpIdentifier, Document> latestCapitalCall,
      Map<LpIdentifier, Document> latestDistributionNotice,
      List<CalculatedBalance> calculatedBalances,
      LocalDate balanceDate)
      throws InterruptedException, ExecutionException {
    Set<Long> collect =
        balanceList.stream().map(c -> c.getDocument().getId()).collect(Collectors.toSet());
    var documentMap =
        documents.getDocumentsByIds(collect).collectMap(Document::getId, c -> c).toFuture().get();
    return convertBalancesToBalanceRows(
        balanceList,
        documentMap,
        latestCapitalCall,
        latestDistributionNotice,
        calculatedBalances,
        balanceDate);
  }

  public Collection<BalanceRow> convertCalculatedBalancesToBalanceRow(
      Set<CalculatedBalance> calculatedBalances, LocalDate startDate, boolean forAggregates) {
    Set<CalculatedBalance> hasMaterialBalances =
        calculatedBalances.stream()
            .filter(CalculatedBalance::hasMaterialBalances)
            .collect(Collectors.toSet());
    Set<BalanceRow> balanceRows = new HashSet<>(hasMaterialBalances.size());
    hasMaterialBalances.forEach(
        calculatedBalance -> {
          BalanceRow balanceRow =
              new BalanceRow(
                  -1, // placeholder for documentId
                  calculatedBalance.getAccount().getId(),
                  calculatedBalance.getSecurity().getSecurityId(),
                  startDate, // placeholder for documentReceivedDate
                  startDate, // placeholder for documentDate
                  startDate, // placeholder for entryDate
                  startDate, // placeholder for balanceDate
                  calculatedBalance.getSource(), // placeholder for source
                  startDate.atStartOfDay(), // placeholder for knowledgeStartDate
                  startDate.atStartOfDay(), // placeholder for knowledgeEndDate
                  calculatedBalance.getCurrency(), // placeholder for currency
                  null,
                  startDate,
                  startDate,
                  startDate,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null);
          balanceRow.addBalance(
              BalanceType.REPORTED_ENDING_NAV.getCode(),
              new BalanceAmountData(
                  calculatedBalance.getWatchlistNavImpact(),
                  0,
                  0,
                  0,
                  calculatedBalance.getWatchlistNavImpact()));
          balanceRow.addBalance(
              BalanceType.REPORTED_TOTAL_COMMITMENT.getCode(),
              new BalanceAmountData(
                  calculatedBalance.getTotalCommitment(),
                  0,
                  0,
                  0,
                  calculatedBalance.getTotalCommitment()));
          balanceRow.addBalance(
              BalanceType.REPORTED_RECALLABLE_DISTRIBUTION.getCode(),
              new BalanceAmountData(
                  calculatedBalance.getRecallableImpact(),
                  0,
                  0,
                  0,
                  calculatedBalance.getRecallableImpact()));
          balanceRow.addBalance(
              BalanceType.FUNDED_COMMITMENT.getCode(),
              new BalanceAmountData(
                  calculatedBalance.getFundedCommitmentImpact(),
                  0,
                  0,
                  0,
                  calculatedBalance.getFundedCommitmentImpact()));
          balanceRow.addBalance(
              BalanceType.CUM_CONTRIBUTION.getCode(),
              new BalanceAmountData(
                  calculatedBalance.getTotalContributions(),
                  0,
                  0,
                  0,
                  calculatedBalance.getTotalContributions()));
          balanceRow.addBalance(
              BalanceType.CUM_DISTRIBUTION.getCode(),
              new BalanceAmountData(
                  calculatedBalance.getTotalDistributions(),
                  0,
                  0,
                  0,
                  calculatedBalance.getTotalDistributions()));
          balanceRows.add(balanceRow);
        });
    return forAggregates ? balanceRows : filterToOpenLotsOnly(balanceRows, startDate);
  }

  protected Set<BalanceRow> filterToOpenLotsOnly(Set<BalanceRow> balanceRows, LocalDate startDate) {
    Set<BalanceRow> openBalances = new HashSet<>();
    Map<Long, List<BalanceRow>> accountToBalanceRow =
        balanceRows.stream().collect(groupingBy(BalanceRow::getAccountId));
    for (Entry<Long, List<BalanceRow>> entry : accountToBalanceRow.entrySet()) {
      List<BalanceRow> balanceRowsForAccount = entry.getValue();
      Map<Long, List<LocalDateRange>> lotEffectiveRangeMap =
          portfolioService.getLotEffectiveRangeMap(
              entry.getKey(),
              balanceRowsForAccount.stream()
                  .map(BalanceRow::getSecurityId)
                  .collect(Collectors.toSet()));
      for (BalanceRow balanceRow : balanceRowsForAccount) {
        List<LocalDateRange> lotEffectiveRanges =
            lotEffectiveRangeMap.get(balanceRow.getSecurityId());
        if (lotEffectiveRanges == null) {
          continue;
        }
        for (LocalDateRange lotEffectiveRange : lotEffectiveRanges) {
          if (lotEffectiveRange.contains(startDate)) {
            openBalances.add(balanceRow);
            break;
          }
        }
      }
    }
    return openBalances;
  }

  private DataSet<Column> convertBalanceRowsToTabular(
      Collection<BalanceRow> balanceRows, List<LPField> allBalanceFields, LocalDate effectiveDate) {
    // Fill-in transaction data if any transaction fields are being requested
    if (!Collections.disjoint(allBalanceFields, LPBalanceField.getTransactionSumFieldIds())) {
      tranAmountCalculator.addTransactionSumsToBalanceRows(balanceRows);
    }

    setPerformanceData(
        performanceDataService.getPerformanceData(
            balanceRows.stream().map(BalanceRow::getAccountId).collect(Collectors.toSet()),
            effectiveDate),
        balanceRows);

    List<List<Object>> data =
        balanceRows.stream()
            .map(br -> getRowList(br, allBalanceFields))
            .collect(Collectors.toList());
    return DataSetUtils.convertToDataSet(data, allBalanceFields);
  }

  public DataSet<Column> getTabularAccelexBalanceData(
      DataSet<Column> dataSet, boolean forAggregates) {
    if (forAggregates) {
      return accelexService.convertBalanceColumnsToAccelexMappingDataSetForAggregates(dataSet);
    }
    return accelexService.convertBalanceColumnsToAccelexMappingDataSet(dataSet);
  }

  @VisibleForTesting
  protected record LpIdentifier(long accountId, long securityId) {}

  public record LockdownData(long accountId, LocalDate lockdownDate) {}

  public record DocumentBalanceCount(Document document, long count) {}
}
