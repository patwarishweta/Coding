package com.cwan.privatefund.issuestore.model;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IssueStatus {

  private IssueStatusName statusName;
  private Integer userId;
  private String toolName;
  private String note;
  private String researchNote;
  private LocalDateTime dateTime;
  private IssueExpiration expiration;
  private String metaData;
}
