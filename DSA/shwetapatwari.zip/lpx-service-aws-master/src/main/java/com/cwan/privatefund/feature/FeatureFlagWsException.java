package com.cwan.privatefund.feature;

import java.io.Serial;

public class FeatureFlagWsException extends RuntimeException {

  @Serial private static final long serialVersionUID = -2974108294969654636L;

  public FeatureFlagWsException(String msg) {
    super(msg);
  }
}
