package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.privatefund.capital.call.helper.CapitalCallPermissionHelper;
import com.cwan.privatefund.cpd.ws.client.CpdWSCache;
import com.cwan.privatefund.util.ExceptionUtils;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/** Service to manage action permissions for capital calls. */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallPermissionService {

  private final CpdWSCache cpdWSCache;

  /**
   * Updates the permission status for a capital call document based on user email.
   *
   * @param capitalCallDocument Document for which permission needs to be updated.
   * @param userEmail The email of the user for which the permission check is done.
   * @return Modified capital call document with updated permission.
   */
  public Mono<CapitalCallDocument> updatePermissionBasedOnUserEmail(
      CapitalCallDocument capitalCallDocument, String userEmail) {
    var account = capitalCallDocument.account();
    var clientId = (Objects.nonNull(account)) ? account.getClientId() : null;
    var capitalCallPermissions =
        CapitalCallPermissionHelper.getDefaultPermissionsForUser(userEmail);
    if (Objects.isNull(account) || Objects.isNull(clientId) || StringUtils.isBlank(userEmail)) {
      log.warn(
          "Invalid parameters for updating permissions. Account: {}, ClientId: {}, UserEmail: {}",
          account,
          clientId,
          userEmail);
      return Mono.just(capitalCallDocument.toBuilder().permissions(capitalCallPermissions).build());
    }
    log.debug(
        "Updating permission based on user email: {}, document {}, account {}, client {}",
        userEmail,
        capitalCallDocument.documentId(),
        account.getId(),
        clientId);
    return fetchAndDeterminePermissionByUserEmail(
            capitalCallDocument.status(), clientId, account.getId(), userEmail)
        .onErrorResume(
            e -> {
              log.error(
                  "Error occurred while fetching and determining permission by user email. Error: {}",
                  ExceptionUtils.getStackTraceAsString(e));
              return Mono.just(false);
            })
        .defaultIfEmpty(false)
        .map(
            isAllowed ->
                capitalCallDocument.toBuilder()
                    .permissions(
                        Boolean.TRUE.equals(isAllowed)
                            ? capitalCallDocument.permissions()
                            : capitalCallPermissions)
                    .build());
  }

  /**
   * Fetches the tag entries for a client and determines the associated permission based on the user
   * email.
   *
   * @param status The current status of the capital call document.
   * @param clientId The ID of the client associated with the capital call document.
   * @param accountId The ID of the account associated with the capital call document.
   * @param userEmail The email of the user for which the permission check is done.
   * @return A Mono<Boolean> indicating if the action is allowed or not.
   */
  public Mono<Boolean> fetchAndDeterminePermissionByUserEmail(
      CapitalCallStatus status, Long clientId, Long accountId, String userEmail) {
    return cpdWSCache
        .getReviewers(clientId, accountId)
        .defaultIfEmpty(new ConcurrentHashMap<>())
        .map(
            tagEntries -> {
              log.debug("Derived permissions for clientId: {}", clientId);
              return CapitalCallPermissionHelper.derivePermissionForAction(
                  status, tagEntries, userEmail);
            });
  }
}
