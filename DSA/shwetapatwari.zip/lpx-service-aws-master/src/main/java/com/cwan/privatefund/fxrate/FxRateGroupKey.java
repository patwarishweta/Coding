package com.cwan.privatefund.fxrate;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import java.time.LocalDate;
import lombok.Data;

@Data
public class FxRateGroupKey {
  private final Long localCurrencyId;
  private final ReportingFrequency reportingFrequency;
  private final LocalDate date;

  public FxRateGroupKey(FXRate fxRate) {
    this.localCurrencyId = fxRate.getLocalCurrencyId();
    this.reportingFrequency = fxRate.getReportingFrequency();
    this.date = fxRate.getDate();
  }
}
