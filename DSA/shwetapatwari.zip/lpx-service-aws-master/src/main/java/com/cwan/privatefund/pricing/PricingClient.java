package com.cwan.privatefund.pricing;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.cwan.privatefund.pricing.model.PricingData;
import com.cwan.privatefund.pricing.model.PricingRequest;
import com.cwan.privatefund.pricing.model.PricingResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Joiner;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PricingClient {

  private static final String ACCOUNT_ID = "accountid";
  private static final String SECURITY_IDS = "securityIds";
  private static final String BEGIN_DATE = "beginDate";
  private static final String END_DATE = "endDate";

  private final Resource dailyPricingResource;
  private final WsHttpClient wsHttpClient;

  public PricingClient(WsHttpClient wsHttpClient, ServerConfiguration serverConfiguration) {
    this.wsHttpClient = wsHttpClient;
    this.dailyPricingResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("readonly/v4/securitypricing/getfulldailypricing")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public PricingResponse getPricingData(PricingRequest pricingRequest) {
    return getPricingData(
        pricingRequest.getAccountId(), pricingRequest.getSecurityIds(), pricingRequest.getDate());
  }

  public PricingResponse getPricingData(long accountId, List<Long> securityIds, LocalDate date) {
    String securityIdsCsv = Joiner.on(",").join(securityIds);
    GetRequest request =
        dailyPricingResource
            .doGET(wsHttpClient)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .addQueryParam(ACCOUNT_ID, accountId)
            .addQueryParam(SECURITY_IDS, securityIdsCsv)
            .addQueryParam(BEGIN_DATE, date.toString())
            .addQueryParam(END_DATE, date.toString());

    try (InputStream is = request.executeRequestAsHttpStream()) {
      Map<String, Map<Long, PricingData>> result =
          JsonUtils2.parseJson(is, new TypeReference<>() {});
      return new PricingResponse(result);
    } catch (IOException e) {
      throw new IllegalStateException(
          String.format(
              "Failed to retrieve daily prices from pricing-data-ws for account: %d, securityIds: %s, date: %s",
              accountId, securityIdsCsv, date));
    }
  }
}
