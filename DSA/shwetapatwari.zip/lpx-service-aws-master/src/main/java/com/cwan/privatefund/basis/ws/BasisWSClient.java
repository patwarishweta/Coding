package com.cwan.privatefund.basis.ws;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.cwan.privatefund.basis.ws.model.Basis;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BasisWSClient {

  private final WsHttpClient wsHttpClient;
  private final Resource getAccountBasesResource;
  private final Resource getBasesResource;

  private static final RetryCountAttemptHandler RETRY_HANDLER = new RetryCountAttemptHandler(3);

  public BasisWSClient(WsHttpClient wsHttpClient, ServerConfiguration basisWsServerConfiguration) {
    this.wsHttpClient = wsHttpClient;
    this.getAccountBasesResource =
        new ResourceBuilder()
            .forService(basisWsServerConfiguration)
            .forResource("v2/accounts/{accountId}/bases")
            .toResource();
    this.getBasesResource =
        new ResourceBuilder()
            .forService(basisWsServerConfiguration)
            .forResource("v2/bases")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public List<Integer> getEnabledBases(Long accountId) {
    GetRequest request =
        getAccountBasesResource
            .doGET(wsHttpClient)
            .withPathParam("accountId", accountId)
            .withAttemptHandler(RETRY_HANDLER)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL);
    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error("BasisWsClient getEnabledBases for account: {}", accountId, e);
    }
    return Collections.emptyList();
  }

  public List<Basis> getBases() {
    GetRequest request =
        getBasesResource
            .doGET(wsHttpClient)
            .withAttemptHandler(RETRY_HANDLER)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL);
    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (IOException e) {
      log.error("BasisWsClient getBasess", e);
    }
    return Collections.emptyList();
  }
}
