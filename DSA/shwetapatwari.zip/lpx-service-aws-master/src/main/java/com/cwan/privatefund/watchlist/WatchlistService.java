package com.cwan.privatefund.watchlist;

import com.cwan.privatefund.watchlist.model.Watchlist;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Slf4j
@Service
public class WatchlistService {

  private final WatchlistRepository watchlistRepository;
  private final WatchlistEntityTransformer watchlistEntityTransformer;
  private final WatchlistTransformer watchlistTransformer;

  public WatchlistService(
      WatchlistRepository watchlistRepository,
      WatchlistEntityTransformer watchlistEntityTransformer,
      WatchlistTransformer watchlistTransform) {
    this.watchlistRepository = watchlistRepository;
    this.watchlistEntityTransformer = watchlistEntityTransformer;
    this.watchlistTransformer = watchlistTransform;
  }

  Flux<Watchlist> addWatchlistEntries(Collection<Watchlist> entries) {
    entries.stream()
        .filter(item -> item.getId() != null)
        .forEach(
            item -> log.warn("Entry with Id {} can't be added Id should be null.", item.getId()));
    return Flux.fromIterable(entries)
        .map(watchlistEntityTransformer)
        .map(this::saveEntry)
        .map(watchlistTransformer);
  }

  Flux<Watchlist> updateWatchlistEntries(Collection<Watchlist> entries) {
    return Flux.fromIterable(entries)
        .filter(Objects::nonNull)
        .map(watchlistEntityTransformer)
        .map(this::saveEntry)
        .map(watchlistTransformer);
  }

  public Boolean isActiveOnWatchlist(Long accountId, Long securityId, LocalDate date) {
    return !getActiveWatchlistSecurities(accountId, List.of(securityId), date).isEmpty();
  }

  Flux<Watchlist> getEntriesByAccountId(Long accountId) {
    return Flux.fromIterable(watchlistRepository.findAllByAccountId(accountId))
        .map(watchlistTransformer);
  }

  public List<Long> getActiveWatchlistSecurities(
      Long accountId, List<Long> securities, LocalDate date) {
    Set<WatchlistEntity> watchlistSecurities =
        getActiveWatchlistSecuritiesByAccount(List.of(accountId), securities, date).get(accountId);
    return watchlistSecurities == null
        ? List.of()
        : watchlistSecurities.stream().map(WatchlistEntity::getSecurityId).toList();
  }

  public Map<Long, Map<Long, Boolean>> getActiveOnWatchlist(List<Long> accountIds, LocalDate date) {
    Map<Long, List<WatchlistEntity>> activeWatchlistEntites =
        getActiveWatchlistEntites(accountIds, date);
    Map<Long, Map<Long, Boolean>> activeOnWatchlist = new HashMap<>(Map.of());
    activeWatchlistEntites.forEach(
        (accountId, watchlistEntities) -> {
          Map<Long, Boolean> activeOnWatchlistForAccount = new HashMap<>();
          watchlistEntities.forEach(
              watchlistEntity ->
                  activeOnWatchlistForAccount.put(watchlistEntity.getSecurityId(), true));
          activeOnWatchlist.put(accountId, activeOnWatchlistForAccount);
        });
    return activeOnWatchlist;
  }

  public Map<Long, List<WatchlistEntity>> getActiveWatchlistEntites(
      List<Long> accountIds, LocalDate date) {
    if (accountIds.isEmpty()) {
      return Map.of();
    }
    Collection<WatchlistEntity> watchlistEntities =
        watchlistRepository.findAllByAccountIdIn(accountIds);
    return watchlistEntities.stream()
        .filter(
            entity ->
                (date.isAfter(entity.getStartDate()) || date.isEqual(entity.getStartDate()))
                        && (date.isBefore(entity.getEndDate()))
                    || date.isEqual(entity.getEndDate()))
        .collect(Collectors.groupingBy(WatchlistEntity::getAccountId));
  }

  public Map<Long, Set<WatchlistEntity>> getActiveWatchlistSecuritiesByAccount(
      List<Long> accountIds, List<Long> securities, LocalDate date) {
    if (securities.isEmpty()) {
      return Map.of();
    }
    Collection<WatchlistEntity> watchlistEntities =
        watchlistRepository.findAllByAccountIdInAndSecurityIdIn(accountIds, securities);

    return watchlistEntities.stream()
        .filter(
            entity ->
                (date.isAfter(entity.getStartDate()) || date.isEqual(entity.getStartDate()))
                        && (date.isBefore(entity.getEndDate()))
                    || date.isEqual(entity.getEndDate()))
        .collect(
            Collectors.groupingBy(
                WatchlistEntity::getAccountId, Collectors.mapping(x -> x, Collectors.toSet())));
  }

  void deleteEntriesById(Set<Long> ids) {
    watchlistRepository.deleteAllById(ids);
  }

  private WatchlistEntity saveEntry(WatchlistEntity entry) {
    return watchlistRepository.saveAndFlush(entry);
  }
}
