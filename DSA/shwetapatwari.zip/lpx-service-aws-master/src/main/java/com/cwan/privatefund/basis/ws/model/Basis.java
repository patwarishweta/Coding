package com.cwan.privatefund.basis.ws.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Basis implements Serializable {
  private Integer basisId;
  private String basisType;
  private String name;
  private String prefix;
}
