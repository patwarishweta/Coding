package com.cwan.privatefund.accountconfig;

import com.cwan.privatefund.client.WebResponseMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AccountConfigServiceConfig {

  @Value("${account-config-service.base.url}")
  private String accountConfigServiceBaseUrl;

  @Value("${account-config-service.memory.maxsize}")
  private Integer maxInMemorySize;

  @Bean(value = "accountConfigServiceWebClient")
  WebClient accountConfigServiceWebClient(ReactorClientHttpConnector reactorClientHttpConnector) {
    return WebClient.builder()
        .baseUrl(accountConfigServiceBaseUrl)
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(maxInMemorySize))
                .build())
        .clientConnector(reactorClientHttpConnector)
        .build();
  }

  @Bean(value = "accountConfigResponseMapper")
  WebResponseMapper<AccountConfigServiceException> accountConfigResponseMapper() {
    return new WebResponseMapper<>() {
      @Override
      protected AccountConfigServiceException getException(String msg) {
        return new AccountConfigServiceException(msg);
      }
    };
  }
}
