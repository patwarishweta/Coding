package com.cwan.privatefund.capital.call.service;

import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.CapitalCallEmailConstants.DOCUMENT_AUDIT_EMAIL_SUBJECT;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.CapitalCallEmailConstants.NEW_CAPITAL_CALL_EMAIL_SUBJECT;
import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.CapitalCallEmailConstants.QUEUE_CAPACITY;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.lpx.domain.Client;
import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.FundDetail;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants;
import com.cwan.privatefund.cpd.ws.client.CpdWSCache;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import com.cwan.privatefund.notification.service.EmailNotificationService;
import com.cwan.privatefund.notification.service.EmailViaSalesforceService;
import com.cwan.privatefund.util.ExceptionUtils;
import jakarta.annotation.PreDestroy;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import reactor.core.publisher.Mono;

/**
 * Service responsible for handling and sending Capital Call related emails. This service utilizes a
 * template engine to generate email content based on the provided Capital Call document.
 */
@Service
@Slf4j
public class CapitalCallEmailNotificationService {

  @Getter private volatile boolean running = true;

  @Getter
  private final BlockingQueue<CapitalCallDocument> emailQueue =
      new LinkedBlockingQueue<>(QUEUE_CAPACITY);

  @Value("${email.provider}")
  private String emailProvider;

  private final ExecutorService emailSenderService;
  private final CapitalCallAuditService capitalCallAuditService;
  private final TemplateEngine thymeleafTemplateEngine;
  private final EmailViaSalesforceService emailViaSalesforceService;
  private final EmailNotificationService emailViaNotificationService;
  private final CpdWSCache cpdWSCache;

  /**
   * Initializes a new instance of the CapitalCallEmailNotificationService with the provided
   * services and template engine.
   *
   * @param capitalCallAuditService Service to fetch audit logs for capital calls.
   * @param thymeleafTemplateEngine Template engine to generate email content.
   * @param emailViaSalesforceService Service to handle sending emails.
   * @param emailViaNotificationService Service to handle sending emails.
   * @param cpdWSCache Cache service to fetch tag entries for clients.
   */
  public CapitalCallEmailNotificationService(
      CapitalCallAuditService capitalCallAuditService,
      TemplateEngine thymeleafTemplateEngine,
      EmailViaSalesforceService emailViaSalesforceService,
      EmailNotificationService emailViaNotificationService,
      CpdWSCache cpdWSCache,
      ExecutorService emailSenderService) {
    this.capitalCallAuditService = capitalCallAuditService;
    this.thymeleafTemplateEngine = thymeleafTemplateEngine;
    this.emailViaSalesforceService = emailViaSalesforceService;
    this.emailViaNotificationService = emailViaNotificationService;
    this.cpdWSCache = cpdWSCache;
    this.emailSenderService = emailSenderService;
    emailSenderService.submit(this::processAndSendEmails);
  }

  /**
   * Enqueues a CapitalCallDocument to be processed and have an email sent out for it.
   *
   * @param document The document to enqueue.
   */
  public void enqueueDocumentForEmail(CapitalCallDocument document) {
    if (emailQueue.remainingCapacity() == 0) {
      log.warn("Email queue is full. Cannot enqueue document ID: {}", document.documentId());
      return;
    }
    try {
      emailQueue.put(document);
    } catch (InterruptedException e) {
      log.error(
          "Failed to enqueue document for email. Error is: {}",
          ExceptionUtils.getStackTraceAsString(e));
      Thread.currentThread().interrupt();
    }
  }

  /** Stops the email processing, ensuring no new emails will be processed. */
  public void stopProcessing() {
    running = false;
  }

  @PreDestroy
  void cleanup() {
    stopProcessing();
    emailSenderService.shutdown();
    try {
      if (!emailSenderService.awaitTermination(60, TimeUnit.SECONDS)) {
        log.warn(
            "Failed to process {} queued email tasks", emailSenderService.shutdownNow().size());
      }
    } catch (InterruptedException e) {
      emailSenderService.shutdownNow();
      log.error(
          "Error during service termination. Error is: {}",
          ExceptionUtils.getStackTraceAsString(e));
      Thread.currentThread().interrupt();
    }
  }

  void processAndSendEmails() {
    while (running || !emailQueue.isEmpty()) {
      try {
        var document = emailQueue.poll(5, TimeUnit.SECONDS);
        if (Objects.nonNull(document)) {
          capitalCallAuditService
              .getAuditLog(document.documentId())
              .flatMap(auditLog -> getLastAuditAndSendEmail(document, auditLog))
              .subscribe();
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      } catch (Exception e) {
        log.error(
            "Error processing email from queue. Error is: {}",
            ExceptionUtils.getStackTraceAsString(e));
      }
    }
  }

  Mono<Void> getLastAuditAndSendEmail(
      CapitalCallDocument capitalCallDocument, CapitalCallAuditLog auditLog) {
    var auditsOptional = Optional.ofNullable(auditLog.audit());
    if (auditsOptional.isEmpty() || auditsOptional.get().isEmpty()) {
      log.warn("No audit entries found for document ID: {}", auditLog.documentId());
      return Mono.empty();
    }
    return auditsOptional
        .map(audits -> audits.get(audits.size() - 1))
        .map(audit -> sendDocumentAuditEmail(capitalCallDocument, audit))
        .orElseGet(
            () -> {
              log.warn(
                  "Couldn't retrieve the last audit entry for document ID: {}",
                  auditLog.documentId());
              return Mono.error(
                  new IllegalStateException("Couldn't retrieve the last audit entry."));
            });
  }

  public Mono<Void> sendDocumentAuditEmail(
      CapitalCallDocument document, CapitalCallAudit capitalCallAudit) {
    return sendEmailForDocument(
        document,
        getReviewers(document, capitalCallAudit),
        DOCUMENT_AUDIT_EMAIL_SUBJECT,
        () -> htmlContentForDocumentAudit(document, capitalCallAudit));
  }

  public Mono<Void> sendNewCapitalCallEmail(CapitalCallDocument document) {
    return sendEmailForDocument(
        document,
        getAllReviewers(document),
        NEW_CAPITAL_CALL_EMAIL_SUBJECT,
        () -> htmlContentForNewCapitalCall(document));
  }

  private Mono<Void> sendEmailForDocument(
      CapitalCallDocument document,
      Mono<Set<String>> reviewerEmails,
      String subject,
      Supplier<String> htmlMessageSupplier) {
    return Mono.defer(
            () -> {
              log.info(
                  "Initiating the email sending process for document ID: {}",
                  document.documentId());
              return reviewerEmails
                  .filter(emailAddresses -> !emailAddresses.isEmpty())
                  .flatMap(
                      emailAddresses -> {
                        var htmlMessage = htmlMessageSupplier.get();
                        log.debug(
                            "Processed email template for document ID: {}", document.documentId());
                        if ("salesforce".equals(emailProvider)) {
                          return emailViaSalesforceService.sendEmailNotification(
                              subject,
                              htmlMessage,
                              emailAddresses,
                              String.valueOf(document.account().getId()));
                        }
                        return emailViaNotificationService.sendEmail(
                            String.valueOf(document.documentId()),
                            subject,
                            htmlMessage,
                            emailAddresses,
                            Collections.emptySet(),
                            Collections.emptySet());
                      });
            })
        .onErrorResume(
            e -> {
              log.error(
                  "Exception occurred while processing email for document ID: {}. Error is: {}",
                  document.documentId(),
                  ExceptionUtils.getStackTraceAsString(e));
              return Mono.empty();
            });
  }

  Mono<Set<String>> getReviewers(CapitalCallDocument document, CapitalCallAudit capitalCallAudit) {
    return cpdWSCache
        .getReviewers(document.account().getClientId(), document.account().getId())
        .map(
            tagEntries ->
                extractEmailAddressesBasedOnStatus(tagEntries, capitalCallAudit.nextStatus()));
  }

  Mono<Set<String>> getAllReviewers(CapitalCallDocument document) {
    return cpdWSCache
        .getReviewers(document.account().getClientId(), document.account().getId())
        .map(
            tagEntries ->
                extractEmailAddressesFromTagEntries(
                    tagEntries,
                    Arrays.asList(
                        PermissionHelperConstants.WIRE_TRANSFER,
                        PermissionHelperConstants.INITIAL,
                        PermissionHelperConstants.FINAL)));
  }

  Set<String> extractEmailAddressesBasedOnStatus(
      Map<String, TagEntry> tagEntries, CapitalCallStatus status) {
    try {
      var key =
          switch (status) {
            case WIRE_CHECK -> PermissionHelperConstants.WIRE_TRANSFER;
            case INITIAL_REVIEW -> PermissionHelperConstants.INITIAL;
            case FINAL_REVIEW -> PermissionHelperConstants.FINAL;
            default -> "";
          };
      if (StringUtils.isBlank(key)) {
        log.info(
            "Email notification skipped because the capital call status '{}' does not correspond to any known permissions key.",
            status);
        return Collections.emptySet();
      }
      if (tagEntries.containsKey(key)) {
        var cpdValue = tagEntries.get(key).cpdValue();
        if (Objects.nonNull(cpdValue)) {
          return extractCleanedEmailsFromCpdValue(cpdValue).collect(Collectors.toSet());
        }
      }
    } catch (Exception e) {
      log.error(
          "Error parsing the response to get email addresses. Error is: {}",
          ExceptionUtils.getStackTraceAsString(e));
    }
    return Collections.emptySet();
  }

  Set<String> extractEmailAddressesFromTagEntries(
      Map<String, TagEntry> tagEntries, List<String> keys) {
    return keys.stream()
        .filter(tagEntries::containsKey)
        .map(key -> tagEntries.get(key).cpdValue())
        .filter(Objects::nonNull)
        .flatMap(CapitalCallEmailNotificationService::extractCleanedEmailsFromCpdValue)
        .collect(Collectors.toSet());
  }

  private static Stream<String> extractCleanedEmailsFromCpdValue(String cpdValue) {
    return PermissionHelperConstants.EMAIL_SPLIT_PATTERN
        .splitAsStream(cpdValue)
        .map(StringUtils::trim)
        .filter(StringUtils::isNotBlank)
        .map(StringUtils::lowerCase);
  }

  public String htmlContentForDocumentAudit(
      CapitalCallDocument document, CapitalCallAudit capitalCallAudit) {
    var context = new Context();
    var props = preparePropsForDocumentAudit(document, capitalCallAudit);
    context.setVariables(new HashMap<>(props));
    return thymeleafTemplateEngine.process("capital-call-status-change.html", context);
  }

  private Map<String, String> preparePropsForDocumentAudit(
      CapitalCallDocument document, CapitalCallAudit capitalCallAudit) {
    Map<String, String> props = new HashMap<>();
    props.put("documentName", trimAndNormalizeSpace(Optional.ofNullable(document.documentName())));
    props.put(
        "clientName",
        trimAndNormalizeSpace(
            Optional.of(document)
                .map(CapitalCallDocument::account)
                .map(Account::getClient)
                .map(Client::getName)));
    props.put(
        "dueDate",
        trimAndNormalizeSpace(Optional.ofNullable(document.dueDate()).map(LocalDate::toString)));
    props.put(
        "currentStatus",
        trimAndNormalizeSpace(
            Optional.ofNullable(capitalCallAudit.nextStatus()).map(CapitalCallStatus::toString)));
    props.put(
        "userFullName",
        trimAndNormalizeSpace(
            Optional.of(capitalCallAudit)
                .map(CapitalCallAudit::user)
                .map(CapitalCallUser::fullName)));
    props.put(
        "previousStatus",
        trimAndNormalizeSpace(
            Optional.ofNullable(capitalCallAudit.previousStatus())
                .map(CapitalCallStatus::toString)));
    return props;
  }

  public String htmlContentForNewCapitalCall(CapitalCallDocument document) {
    var context = new Context();
    var props = preparePropsForNewCapitalCall(document);
    context.setVariables(new HashMap<>(props));
    return thymeleafTemplateEngine.process("new-capital-call.html", context);
  }

  private Map<String, String> preparePropsForNewCapitalCall(CapitalCallDocument document) {
    Map<String, String> props = new HashMap<>();
    props.put("documentName", trimAndNormalizeSpace(Optional.ofNullable(document.documentName())));
    var security = document.security();
    var fundDetail = Optional.ofNullable(security).map(Security::getFundDetail).orElse(null);
    props.put(
        "fundName",
        trimAndNormalizeSpace(Optional.ofNullable(fundDetail).map(FundDetail::getName)));
    props.put(
        "gpName",
        trimAndNormalizeSpace(Optional.ofNullable(fundDetail).map(FundDetail::getGpName)));
    props.put(
        "currency",
        trimAndNormalizeSpace(
            Optional.ofNullable(security).map(Security::getCurrency).map(Currency::getCode)));
    props.put(
        "amount",
        trimAndNormalizeSpace(
            Optional.ofNullable(document.paymentAmount()).map(BigDecimal::toString)));
    props.put(
        "noticeDate",
        trimAndNormalizeSpace(
            Optional.ofNullable(document.callReceivedDate()).map(LocalDate::toString)));
    props.put(
        "dueDate",
        trimAndNormalizeSpace(Optional.ofNullable(document.dueDate()).map(LocalDate::toString)));
    return props;
  }

  private static String trimAndNormalizeSpace(Optional<String> str) {
    return StringUtils.normalizeSpace(StringUtils.trimToNull(str.orElse("-")));
  }
}
