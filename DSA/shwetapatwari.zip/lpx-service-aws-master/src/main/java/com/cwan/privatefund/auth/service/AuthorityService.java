package com.cwan.privatefund.auth.service;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.auth.LPxAMPTPermissions;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

@Service
@RequiredArgsConstructor
public class AuthorityService {

  private final AuthTokenCore authTokenCore;

  Set<GrantedAuthority> getAuthorities(ServerWebExchange swe) {
    var authHeader = swe.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
    if (authHeader == null) {
      return Collections.emptySet();
    }
    var token = authHeader.replace("Bearer ", "");
    if (!authTokenCore.isValidToken(token)) {
      return Collections.emptySet();
    }
    Map<String, Object> decoded = authTokenCore.decodeToken(token);
    // check if app token
    var appName = decoded.get("appName");
    if (appName != null) {
      return Set.of(new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE));
    }
    List<Integer> amptPermissions =
        (List<Integer>) decoded.getOrDefault("ampt", Collections.emptyList());
    return amptPermissions.stream()
        .map(Object::toString)
        .map(SimpleGrantedAuthority::new)
        .collect(Collectors.toSet());
  }
}
