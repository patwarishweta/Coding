package com.cwan.privatefund.issuestore;

import com.cwan.privatefund.issuestore.model.Issue;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/issues")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class IssueController {

  private final IssueService issueService;

  IssueController(IssueService issueService) {
    this.issueService = issueService;
  }

  @RequestMapping(value = "/document/error", method = RequestMethod.GET)
  @Operation(summary = "Get document error issues from Issue Store by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Issue.class))
            })
      })
  public Flux<Issue> getErrorsByDocumentId(
      @Parameter(description = "Document Id") @RequestParam Long documentId) {
    return issueService.getDocumentErrors(documentId);
  }

  @RequestMapping(value = "/document/missing", method = RequestMethod.GET)
  @Operation(summary = "Get missing document issues from Issue Store by user and date range")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Issue.class))
            })
      })
  public Flux<Issue> getUserMissingDocuments(
      @Parameter(description = "User Id") @RequestParam Integer userId,
      @Parameter(description = "Received Begin Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate beginDate,
      @Parameter(description = "Received End Date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate endDate) {
    return issueService.getMissingDocumentsByUserId(userId, beginDate, endDate);
  }

  @PutMapping
  @Operation(summary = "Update given issues to Issue Store")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Issue.class))
            })
      })
  public Flux<Issue> updateIssues(
      @Parameter(description = "Set of issues") @RequestBody Set<Issue> issueSet) {
    return issueService.updateIssues(issueSet);
  }
}
