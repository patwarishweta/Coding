package com.cwan.privatefund.security.currency;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "security_currency", catalog = "pabor")
public class SecurityCurrencyEntity implements Serializable {
  @Id private Long securityId;
  private Long currencyId;
  private LocalDateTime modifiedOn;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (getClass() != o.getClass())) {
      return false;
    }
    var entity = (SecurityCurrencyEntity) o;
    return securityId.equals(entity.securityId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(securityId);
  }
}
