package com.cwan.privatefund.security;

import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.FundDetail;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.SecurityTypeDataDetail;
import com.cwan.privatefund.security.model.FundMasterData;
import com.cwan.privatefund.security.model.SecurityMasterData;
import com.cwan.privatefund.security.model.SecurityTypeData;
import java.util.Optional;
import org.springframework.stereotype.Component;

@Component
public class SecurityTransformer {
  public Security transform(
      SecurityMasterData securityMasterData,
      FundMasterData fundMasterData,
      SecurityTypeData securityTypeData) {
    FundDetail fundDetail =
        Optional.ofNullable(fundMasterData)
            .map(data -> FundDetail.builder().name(data.name()).gpName(data.gpName()).build())
            .orElseGet(() -> FundDetail.builder().build());

    SecurityTypeDataDetail securityTypeDataDetail =
        Optional.ofNullable(securityTypeData)
            .map(
                data ->
                    SecurityTypeDataDetail.builder()
                        .isLIHTC(data.isLIHTC())
                        .isAmortizingLP(data.isAmortizingLP())
                        .isLimitedPartnership(data.isLimitedPartnership())
                        .build())
            .orElseGet(() -> SecurityTypeDataDetail.builder().build());

    return Security.builder()
        .securityId(securityMasterData.getId())
        .securityName(securityMasterData.getName())
        .cusip(securityMasterData.getCusip())
        .currency(getCurrency(securityMasterData))
        .fundDetail(fundDetail)
        .securityTypeDataDetail(securityTypeDataDetail)
        .build();
  }

  private Currency getCurrency(SecurityMasterData securityMasterData) {
    return Currency.builder()
        .currencyId(securityMasterData.getCurrencyId())
        .code(securityMasterData.getCurrencyCode())
        .build();
  }
}
