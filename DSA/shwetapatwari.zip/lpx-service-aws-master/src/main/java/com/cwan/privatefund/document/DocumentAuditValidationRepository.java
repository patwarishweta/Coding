package com.cwan.privatefund.document;

import com.cwan.privatefund.document.model.DocumentAuditValidationEntity;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentAuditValidationRepository
    extends JpaRepository<DocumentAuditValidationEntity, Long> {
  Collection<DocumentAuditValidationEntity> findAllByDocumentId(Long documentId);

  @Query(
      "SELECT d, dav "
          + "FROM DocumentEntity d "
          + "LEFT JOIN DocumentAuditValidationEntity dav ON d.id = dav.documentId "
          + "WHERE d.id IN :documentIds")
  List<Object[]> findDocumentsWithAuditInfo(@Param("documentIds") List<Long> documentIds);

  @Query(
      "SELECT d, dav "
          + "FROM DocumentEntity d "
          + "LEFT JOIN DocumentAuditValidationEntity dav "
          + "    ON d.id = dav.documentId "
          + "WHERE dav.modifiedOn = ("
          + "    SELECT MAX(dav2.modifiedOn)"
          + "    FROM DocumentAuditValidationEntity dav2"
          + "    WHERE dav2.documentId = dav.documentId "
          + "      AND dav2.modifiedOn BETWEEN :startDate AND :endDate"
          + ") "
          + "AND d.accountId IN :accountIds "
          + "AND d.checked = true "
          + "AND dav.checked = true")
  List<Object[]> findRecentlyValidatedDocuments(
      @Param("startDate") LocalDateTime startDate,
      @Param("endDate") LocalDateTime endDate,
      @Param("accountIds") Set<Long> accountIds);
}
