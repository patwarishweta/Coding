package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.privatefund.auth.accesscontrolfiltering.AccessControlFilteringService;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.constant.CapitalCallAccessType;
import com.cwan.privatefund.util.ExceptionUtils;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * Service class for capital call operations. This class checks the user's access to a capital call.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallAccessService {

  private final CapitalCalls capitalCalls;
  private final AccessControlFilteringService accessControlFilteringService;
  private final CapitalCallPermissionService capitalCallPermissionService;
  private final CapitalCallEnrichmentService capitalCallEnrichmentService;

  /**
   * Check if a user has a specified type of access to a capital call document.
   *
   * @param user - the user to check access for.
   * @param documentId - the id of the document to check access to.
   * @param accessType - the type of access to be checked (e.g. READ, WRITE).
   * @return a Mono with the capital call document if the user has the specified access, error
   *     otherwise.
   */
  public Mono<CapitalCallDocument> checkUserAccess(
      User user, Long documentId, CapitalCallAccessType accessType) {
    return capitalCalls
        .getCapitalCallByDocument(documentId)
        .flatMap(
            doc -> capitalCallEnrichmentService.enrichCapitalCallWithData(doc, user.getEmail()))
        .flatMap(enrichedCallDocument -> validateDocumentAndUser(user, enrichedCallDocument))
        .filterWhen(
            enrichedDoc ->
                accessControlFilteringService.checkResourceAccessByAccount(
                    user, enrichedDoc.account().getId()))
        .filterWhen(
            callDocument -> {
              if (accessType == CapitalCallAccessType.WRITE) {
                return hasUserWritePermission(user, callDocument);
              }
              return Mono.just(true);
            })
        .switchIfEmpty(Mono.defer(() -> raiseAccessDenied(user, documentId)))
        .onErrorResume(e -> handleExceptions(e, user, documentId));
  }

  private static Mono<CapitalCallDocument> validateDocumentAndUser(
      User user, CapitalCallDocument callDocument) {
    if (Objects.nonNull(callDocument)
        && isDocumentValid(callDocument)
        && StringUtils.isNotBlank(user.getEmail())) {
      return Mono.just(callDocument);
    }
    var errorMsg = createErrorMessage(user, callDocument);
    log.warn(errorMsg);
    return Mono.error(new AccessDeniedException(errorMsg));
  }

  private static boolean isDocumentValid(CapitalCallDocument callDocument) {
    return Objects.nonNull(callDocument.account())
        && Objects.nonNull(callDocument.account().getId())
        && Objects.nonNull(callDocument.status())
        && Objects.nonNull(callDocument.account().getClientId());
  }

  private Mono<Boolean> hasUserWritePermission(User user, CapitalCallDocument callDocument) {
    return capitalCallPermissionService.fetchAndDeterminePermissionByUserEmail(
        callDocument.status(),
        callDocument.account().getClientId(),
        callDocument.account().getId(),
        user.getEmail());
  }

  private static String createErrorMessage(User user, CapitalCallDocument callDocument) {
    var account = Optional.ofNullable(callDocument).map(CapitalCallDocument::account).orElse(null);
    return String.format(
        "Invalid or missing data. Document: %s, Account: %s, Account ID: %s, Status: %s, Client ID: %s, User Email: %s",
        callDocument,
        account,
        Optional.ofNullable(account).map(Account::getId).orElse(null),
        Optional.ofNullable(callDocument).map(CapitalCallDocument::status).orElse(null),
        Optional.ofNullable(account).map(Account::getClientId).orElse(null),
        user.getEmail());
  }

  private static Mono<CapitalCallDocument> raiseAccessDenied(User user, Long documentId) {
    var errorMsg =
        String.format(
            "Access denied for user %s on document ID %s due to insufficient permissions or account access.",
            user.getFullname(), documentId);
    log.warn(errorMsg);
    return Mono.error(new AccessDeniedException(errorMsg));
  }

  private static Mono<CapitalCallDocument> handleExceptions(
      Throwable e, User user, Long documentId) {
    if (e instanceof AccessDeniedException) {
      log.error("Error is: {}", ExceptionUtils.getStackTraceAsString(e));
      return Mono.error(e);
    }
    var errorMessage =
        String.format(
            "Failed to check user access for User: %s with Document ID: %s. Error is: %s",
            user.getFullname(), documentId, ExceptionUtils.getStackTraceAsString(e));
    log.error(errorMessage);
    return Mono.error(new RuntimeException(errorMessage));
  }
}
