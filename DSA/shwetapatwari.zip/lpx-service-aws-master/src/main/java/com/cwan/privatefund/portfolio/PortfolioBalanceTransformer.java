package com.cwan.privatefund.portfolio;

import com.cwan.privatefund.portfolio.model.SecurityAccountPair;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class PortfolioBalanceTransformer
    implements Function<SecurityAccountPair, PortfolioBalance> {

  @Override
  public PortfolioBalance apply(SecurityAccountPair securityAccountPair) {
    return PortfolioBalance.builder()
        .account(securityAccountPair.getAccount())
        .security(securityAccountPair.getSecurity())
        .build();
  }
}
