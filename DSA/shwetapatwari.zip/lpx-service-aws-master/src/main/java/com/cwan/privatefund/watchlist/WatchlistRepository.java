package com.cwan.privatefund.watchlist;

import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WatchlistRepository extends JpaRepository<WatchlistEntity, Long> {

  Collection<WatchlistEntity> findAllByAccountId(Long accountId);

  Collection<WatchlistEntity> findAllByAccountIdIn(List<Long> accountIds);

  Collection<WatchlistEntity> findAllByAccountIdInAndSecurityIdIn(
      List<Long> accountIds, List<Long> securityIds);
}
