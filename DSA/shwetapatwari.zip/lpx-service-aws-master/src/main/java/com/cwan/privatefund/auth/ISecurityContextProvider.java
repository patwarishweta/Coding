package com.cwan.privatefund.auth;

import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;

/** Interface for classes that can provide SecurityContext. */
public interface ISecurityContextProvider {

  /**
   * Method to provide the SecurityContext.
   *
   * @return the provided SecurityContext wrapped in a Mono.
   */
  Mono<SecurityContext> provideContext();
}
