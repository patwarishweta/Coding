package com.cwan.privatefund.fundmaster;

import com.ca.json2.utils.JsonUtils2;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.FundIdNameResponseProjection;
import com.cwan.lpx.domain.ReportingFrequency;
import com.cwan.pbor.fundmaster.Fund;
import com.cwan.pbor.fundmaster.FundAliasKey;
import com.cwan.pbor.fundmaster.FundIdentifier;
import com.cwan.pbor.fundmaster.FundInternalMappingEntity;
import com.cwan.pbor.fundmaster.FundInternalMappingRepository;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.FundMasterOverrideEntity;
import com.cwan.pbor.fundmaster.FundMasterRepository;
import com.cwan.pbor.fundmaster.ManagementFeesEntity;
import com.cwan.pbor.fundmaster.PortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.api.FundMasterService;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.portfolio.PortfolioUtilsService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
@Service
public class LpxFundMasterService {

  private final FundMasterService fundMasterService;
  protected static final ReportingFrequency DEFAULT_REPORTING_FREQUENCY =
      ReportingFrequency.QUARTERLY;
  private final FundMasterRepository fundMasterRepository;
  private final FundInternalMappingRepository fundInternalMappingRepository;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final BusinessWSCache businessWSCache;
  private final RedisTemplate<String, Object> redisTemplate;
  private final AccountService accountService;
  private final PortfolioUtilsService portfolioUtilsService;

  public LpxFundMasterService(
      FundMasterService fundMasterService,
      FundMasterRepository fundMasterRepository,
      FundInternalMappingRepository fundInternalMappingRepository,
      AccountConfigServiceCache accountConfigServiceCache,
      BusinessWSCache businessWSCache,
      RedisTemplate<String, Object> redisTemplate,
      AccountService accountService,
      PortfolioUtilsService portfolioUtilsService) {
    this.fundMasterService = fundMasterService;
    this.fundMasterRepository = fundMasterRepository;
    this.fundInternalMappingRepository = fundInternalMappingRepository;
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.businessWSCache = businessWSCache;
    this.redisTemplate = redisTemplate;
    this.accountService = accountService;
    this.portfolioUtilsService = portfolioUtilsService;
  }

  public List<PortfolioCompanyEntity> savePortfolioCompanies(
      Set<PortfolioCompanyEntity> portfolioCompanyEntities) {
    Set<PortfolioCompanyEntity> mutatableItems = new HashSet<>(portfolioCompanyEntities);

    // validate data is ready
    Set<PortfolioCompanyEntity> partiallyFilledOutPortfolioCompanies =
        mutatableItems.stream().filter(pc -> pc.getFundId() == null).collect(Collectors.toSet());

    if (!partiallyFilledOutPortfolioCompanies.isEmpty()) {
      log.warn(
          String.format(
              "Tried saving the following portfolio companies with a null fundId %s",
              JsonUtils2.objToJson(partiallyFilledOutPortfolioCompanies)));
    }
    mutatableItems.removeAll(partiallyFilledOutPortfolioCompanies);

    // save valid datapoints
    return fundMasterService.savePortfolioCompanyData(mutatableItems);
  }

  public List<ManagementFeesEntity> saveManagementFees(Set<ManagementFeesEntity> managementFees) {
    // validate data is ready
    Set<ManagementFeesEntity> mutatableItems = new HashSet<>(managementFees);
    Set<ManagementFeesEntity> partiallyFilledOutData =
        mutatableItems.stream()
            .filter(mapping -> mapping.getFundId() == null)
            .collect(Collectors.toSet());

    if (!partiallyFilledOutData.isEmpty()) {
      log.warn(
          String.format(
              "Tried saving the following management fees with a null fundId %s",
              JsonUtils2.objToJson(partiallyFilledOutData)));
    }
    mutatableItems.removeAll(partiallyFilledOutData);

    // save valid datapoints
    return fundMasterService.saveManagementFeesData(mutatableItems);
  }

  public List<FundMasterEntity> saveFundMasterEntity(Set<FundMasterEntity> fundMasterEntity) {
    // save valid datapoints
    return fundMasterService.saveFundMasterData(fundMasterEntity);
  }

  public void deleteFundMasterEntity(Set<FundInternalMappingEntity> fundInternalMappingEntities) {
    fundInternalMappingRepository.deleteAll(fundInternalMappingEntities);
  }

  public List<FundInternalMappingEntity> saveFundInternalMapping(
      Set<FundInternalMappingEntity> fundInternalMappingEntity) {
    Set<FundInternalMappingEntity> mutatableItems = new HashSet<>(fundInternalMappingEntity);
    // validate data is ready
    Set<FundInternalMappingEntity> partiallyFilledOutData =
        mutatableItems.stream()
            .filter(mapping -> mapping.getId().getFundId() == null)
            .filter(mapping -> mapping.getId().getSecurityId() == null)
            .collect(Collectors.toSet());

    if (!partiallyFilledOutData.isEmpty()) {
      log.warn(
          String.format(
              "Tried saving the following portfolio companies with a null fundId %s",
              JsonUtils2.objToJson(partiallyFilledOutData)));
    }
    mutatableItems.removeAll(partiallyFilledOutData);

    // save valid datapoints
    return fundMasterService.saveFundInternalMappings(mutatableItems);
  }

  public Collection<Fund> getFundDataByEins(Set<String> eins) {
    return fundMasterService.getFundInfoFromEins(eins);
  }

  public Collection<FundMasterEntity> getAllInternalFunds() {
    return fundMasterRepository.findAllInternalFunds();
  }

  public Collection<FundIdNameResponseProjection> getAllInternalFundsNameId() {
    return fundMasterRepository.findAllInternalFundsNameAndIds();
  }

  public Collection<Fund> getFundDataBySecurities(Set<Long> securities) {
    return fundMasterService.getFundInfoFromSecurities(securities);
  }

  public Collection<Fund> getFundDataWithOverridesBySecurities(
      Long clientId, Long accountId, Set<Long> securities) {
    clientId = getClientIdForAccount(clientId, accountId);
    SortedMap<Integer, Long> clientHierarchy =
        businessWSCache
            .ultimateParentCacheByClientId(Set.of(clientId))
            .subscribeOn(Schedulers.boundedElastic())
            .toFuture()
            .join()
            .get(clientId);
    Map<Long, Set<Long>> identifiedOverridesClientSecIdMap =
        fundMasterService.identifyClientWithOverride(securities, clientHierarchy);

    Collection<Fund> fundData = new ArrayList<>();
    for (Map.Entry<Long, Set<Long>> entry : identifiedOverridesClientSecIdMap.entrySet()) {
      fundData.addAll(
          fundMasterService.getFundInfoFromSecuritiesWithOverrides(
              entry.getValue(), entry.getKey()));
    }
    return fundData;
  }

  public Map<Long, FundMasterEntity> getFundMasterEntitiesWithOverridesBySecurities(
      Long clientId, Long accountId, Set<Long> securities) {
    clientId = getClientIdForAccount(clientId, accountId);
    SortedMap<Integer, Long> clientHierarchy =
        businessWSCache
            .ultimateParentCacheByClientId(Set.of(clientId))
            .subscribeOn(Schedulers.boundedElastic())
            .toFuture()
            .join()
            .get(clientId);
    Map<Long, Set<Long>> identifiedOverridesClientSecIdMap =
        fundMasterService.identifyClientWithOverride(securities, clientHierarchy);
    Map<Long, FundMasterEntity> fundMasterEntityMap = new HashMap<>();

    for (Map.Entry<Long, Set<Long>> entry : identifiedOverridesClientSecIdMap.entrySet()) {
      fundMasterEntityMap.putAll(
          fundMasterService.getFundMasterEntitiesWithOverrides(entry.getValue(), entry.getKey()));
    }
    return fundMasterEntityMap;
  }

  private Long getClientIdForAccount(Long clientId, Long accountId) {
    if (clientId == null) {
      List<AccountConfig> accountConfigs =
          ((List<AccountConfig>) redisTemplate.opsForHash().get("Account", accountId));
      if (accountConfigs != null && !accountConfigs.isEmpty()) {
        clientId = accountConfigs.get(0).getClientId();
      }
    }
    return clientId;
  }

  // Returns a map of securityId to reportingFrequency
  // If the securityId is not associated with a fund, or the fund does not have a reportingFrequency
  // supplied, then the default reportingFrequency is returned
  public Map<Long, ReportingFrequency> getReportingFrequencies(Collection<Long> securityIds) {
    // Fill out default reportingFrequency for each securityId
    Map<Long, ReportingFrequency> frequencyMap =
        securityIds.stream()
            .collect(Collectors.toMap(Long::longValue, id -> DEFAULT_REPORTING_FREQUENCY));

    // Update the reportFrequency for securities that have a fund with a non-null reportingFrequency
    Collection<Fund> funds = fundMasterService.getFundInfoFromSecurities(securityIds);
    for (Fund fund : funds) {
      if (fund.fundMasterEntity() != null) {
        String frequencyString = fund.fundMasterEntity().getReportingFrequency();
        if (frequencyString != null && !frequencyString.isEmpty()) {
          frequencyMap.put(fund.securityId(), ReportingFrequency.valueOf(frequencyString));
        }
      }
    }
    return frequencyMap;
  }

  public ReportingFrequency getReportingFrequency(Long securityId) {
    return getReportingFrequencies(Set.of(securityId)).get(securityId);
  }

  public FundAliasKey saveFundAliasKey(FundAliasKey fundAliasKey) {
    return fundMasterService.saveFundAlias(fundAliasKey.getFundId(), fundAliasKey.getAlias());
  }

  public Collection<FundIdentifier> getFundIdentifiers() {
    return fundMasterService.getFundIdentifiers();
  }

  public Map<String, FundMasterEntity> getFundMasterAndOverrideEntitiesBySecurityAndClient(
      Long securityId, Long clientId) {
    return fundMasterService.getFundMasterEntityAndOverride(securityId, clientId);
  }

  private Long getClientIdFromAccountConfigCache(Long accountId) {
    return accountConfigServiceCache
        .getByAccountId(accountId)
        .subscribeOn(Schedulers.boundedElastic())
        .toFuture()
        .join()
        .getClientId();
  }

  private Map<Long, SortedMap<Integer, Long>> getClientHierarchy(Long clientId) {
    return businessWSCache
        .ultimateParentCacheByClientId(Set.of(clientId))
        .subscribeOn(Schedulers.boundedElastic())
        .toFuture()
        .join();
  }

  public Map<String, Object> getFundMasterAndOverrideEntitiesBySecurityAndAccountWithOverrideLevel(
      Long securityId, Long accountId) {
    Long clientId = getClientIdFromAccountConfigCache(accountId);
    Map<Long, SortedMap<Integer, Long>> clientHierarchy = getClientHierarchy(clientId);
    Map<Long, Set<Long>> clientSecIdMap =
        fundMasterService.identifyClientWithOverride(
            Set.of(securityId), clientHierarchy.get(clientId));
    Long resolvedClientId = clientSecIdMap.keySet().stream().findFirst().orElse(null);
    Map<String, Object> retMap =
        new HashMap<>(
            fundMasterService.getFundMasterEntityAndOverride(securityId, resolvedClientId));
    retMap.put("overrideLevel", resolvedClientId);
    return retMap;
  }

  public Map<String, FundMasterEntity> getFundMasterAndOverrideEntitiesBySecurityAndAccount(
      Long securityId, Long accountId) {
    Long clientId = getClientIdFromAccountConfigCache(accountId);
    Map<Long, SortedMap<Integer, Long>> clientHierarchy = getClientHierarchy(clientId);
    Map<Long, Set<Long>> clientSecIdMap =
        fundMasterService.identifyClientWithOverride(
            Set.of(securityId), clientHierarchy.get(clientId));
    Long resolvedClientId = clientSecIdMap.keySet().stream().findFirst().orElse(null);
    return fundMasterService.getFundMasterEntityAndOverride(securityId, resolvedClientId);
  }

  public void deleteOverride(Long clientId, Long securityId) {
    fundMasterService.deleteFundMasterOverride(clientId, securityId);
  }

  public Collection<FundMasterOverrideEntity> saveFundMasterOverrides(
      Collection<FundMasterOverrideEntity> overrides) {
    return fundMasterService.saveFundMasterOverrides(overrides);
  }

  public Flux<Map<String, Object>> getAllEntitiesForClientOriginalAndOverride(
      Long clientId, Integer userId) {
    return accountService
        .getClientAccounts(clientId, userId)
        .filter(account -> account.getSubscriptionStartDate() != null && !account.getAggregate())
        .flatMap(
            account ->
                portfolioUtilsService
                    .getAllSecuritiesByAccountId(account.getId())
                    .filter(accSec -> !accSec.isEmpty() && accSec.containsKey(account.getId()))
                    .flatMapIterable(accSec -> accSec.get(account.getId()))
                    .filter(sec -> sec.getSecurityTypeDataDetail().isLimitedPartnership())
                    .flatMap(
                        security ->
                            Mono.fromCallable(
                                    () ->
                                        getFundMasterAndOverrideEntitiesBySecurityAndAccountWithOverrideLevel(
                                            security.getSecurityId(), account.getId()))
                                .subscribeOn(Schedulers.boundedElastic())
                                .map(
                                    fundMasterEntities -> {
                                      Map<String, Object> retMap =
                                          new HashMap<>(
                                              Map.of("account", account, "security", security));
                                      retMap.putAll(fundMasterEntities);
                                      return retMap;
                                    })))
        .distinct();
  }
}
