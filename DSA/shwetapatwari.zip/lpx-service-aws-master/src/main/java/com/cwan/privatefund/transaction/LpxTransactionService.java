package com.cwan.privatefund.transaction;

import static com.cwan.lpx.domain.ConfigAttributes.TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE;
import static com.cwan.privatefund.calculated.BalanceAffectService.watchlistFilter;
import static com.cwan.privatefund.constant.Constants.CREATE_CANCEL_ACTION;
import static com.cwan.privatefund.constant.Constants.ECONOMIC_NAV_SUB_TYPE;
import static com.cwan.privatefund.constant.Constants.OFFSET_TRANSACTION_TYPE;
import static com.cwan.privatefund.constant.Constants.OPEN_TRAN_TYPES;
import static com.cwan.privatefund.constant.Constants.PERFORMANCE_CALCULATION_MANDATORY_FIELDS;
import static com.cwan.privatefund.constant.Constants.WATCHLIST_NAV_SUB_TYPE;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.LoadTransactionDetail;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.lpx.domain.TransactionSubType;
import com.cwan.lpx.domain.TransactionType;
import com.cwan.pbor.clientspecific.FundService;
import com.cwan.pbor.document.DocumentService;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.pbor.trans.openingtransactions.LoadTransactionDetailService;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.accountconfig.AccountConfigServiceClient;
import com.cwan.privatefund.accountconfig.AccountSubscriptionRules;
import com.cwan.privatefund.constant.Constants;
import com.cwan.privatefund.hydrate.TransactionDataHydrationService;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.transaction.model.AwsTransaction;
import com.cwan.privatefund.transaction.model.ValidationResponse;
import com.cwan.privatefund.util.DateUtils;
import com.cwan.privatefund.watchlist.WatchlistService;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import com.google.common.collect.Lists;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
public class LpxTransactionService {

  private final Transactions transactionService;
  private final AccountConfigServiceCache accountConfigServiceCache;
  private final DocumentService documentService;
  private final AccountService accountService;
  private final TransactionDataHydrationService hydrationService;
  private final SecurityService securityService;
  private final LoadTransactionDetailService loadTransactionDetailService;
  private final FundService fundService;
  private final AccountConfigServiceClient accountConfigServiceClient;
  private final WatchlistService watchlistService;
  private static final Integer BATCH_SIZE = 100;

  public LpxTransactionService(
      Transactions transactionService,
      AccountConfigServiceCache accountConfigServiceCache,
      DocumentService documentService,
      AccountService accountService,
      TransactionDataHydrationService hydrationService,
      SecurityService securityService,
      LoadTransactionDetailService loadTransactionDetailService,
      FundService fundService,
      AccountConfigServiceClient accountConfigServiceClient,
      WatchlistService watchlistService) {
    this.transactionService = transactionService;
    this.accountConfigServiceCache = accountConfigServiceCache;
    this.documentService = documentService;
    this.accountService = accountService;
    this.hydrationService = hydrationService;
    this.securityService = securityService;
    this.loadTransactionDetailService = loadTransactionDetailService;
    this.fundService = fundService;
    this.accountConfigServiceClient = accountConfigServiceClient;
    this.watchlistService = watchlistService;
  }

  public Flux<Transaction> getTransactionsByIds(Set<Long> transactionIds) {
    return transactionService.getTransactionsByIds(transactionIds);
  }

  public Flux<Transaction> getTransactions(
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDateTime knowledgeDate,
      String excludedTranType,
      boolean queryByEntryDate,
      boolean includeHistoric) {
    return getTransactions(
        accountIds,
        beginDate,
        endDate,
        knowledgeDate,
        excludedTranType,
        queryByEntryDate,
        includeHistoric,
        true);
  }

  public Flux<Transaction> getTransactions(
      Set<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDateTime knowledgeDate,
      String excludedTranType,
      boolean queryByEntryDate,
      boolean includeHistoric,
      boolean filterInvalid) {
    Mono<List<Transaction>> applicableTransactions =
        getSubscriptionStartDateMap(accountIds)
            .flatMap(
                subscriptionMap -> {
                  Flux<Transaction> transactions =
                      transactionService.getTransactions(
                          accountIds,
                          beginDate,
                          endDate,
                          knowledgeDate,
                          excludedTranType,
                          queryByEntryDate,
                          includeHistoric);
                  if (!filterInvalid) {
                    return transactions.collectList();
                  }

                  return transactions
                      .collectList()
                      .map(
                          transactionList ->
                              transactionList.stream()
                                  .filter(
                                      transaction -> {
                                        LocalDate subscriptionStartDate =
                                            subscriptionMap.get(transaction.getAccount().getId());
                                        return transaction.getSettleDate() != null
                                            && subscriptionStartDate != null
                                            && !transaction
                                                .getSettleDate()
                                                .isBefore(subscriptionStartDate);
                                      })
                                  .toList());
                });

    return applicableTransactions.flatMapIterable(Function.identity());
  }

  Flux<Transaction> getTransactionsForDisplayingActivities(
      Long accountId,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDateTime knowledgeDate,
      String excludedTranType,
      boolean skipHydrate) {
    Mono<List<Transaction>> requestedTransactions =
        getSubscriptionStartDate(accountId)
            .flatMap(
                subscriptionStartDate ->
                    transactionService
                        .getTransactions(
                            Set.of(accountId),
                            beginDate,
                            endDate,
                            knowledgeDate,
                            excludedTranType,
                            false,
                            false)
                        .filter(
                            transaction ->
                                transaction.getSettleDate() != null
                                    && !transaction
                                        .getSettleDate()
                                        .isBefore(subscriptionStartDate)))
            .collectList();

    if (!skipHydrate) {
      requestedTransactions =
          requestedTransactions.flatMap(hydrationService::hydrateWithDocumentAudit);
    }

    return requestedTransactions.flatMapIterable(Function.identity());
  }

  public Flux<Transaction> getTransactionsByDocumentId(Long documentId) {
    return documentService
        .getDocumentById(documentId)
        .map(document -> document.getAccount().getId())
        .flux()
        .flatMap(this::getSubscriptionStartDate)
        .flatMap(
            subscriptionStartDate ->
                transactionService.getTransactionsByDocumentId(documentId, subscriptionStartDate))
        .collectList()
        .flatMap(hydrationService::hydrate)
        .flatMapIterable(Function.identity());
  }

  public Flux<Transaction> getTransactionsByDocumentIds(Set<Long> documentIds) {
    return transactionService
        .getAllTransactionsByDocumentIdIn(documentIds)
        .collectList()
        .flatMap(hydrationService::hydrateWithDocumentAudit)
        .flatMapIterable(Function.identity());
  }

  public Flux<Transaction> getTransactionsByDocumentIdAndTypeNotIn(
      Long documentId, List<String> type) {
    return documentService
        .getDocumentById(documentId)
        .map(document -> document.getAccount().getId())
        .flux()
        .flatMap(this::getSubscriptionStartDate)
        .flatMap(
            subscriptionStartDate ->
                transactionService.getTransactionsByDocumentIdAndTypeNotIn(
                    documentId, subscriptionStartDate, type))
        .collectList()
        .flatMap(hydrationService::hydrate)
        .flatMapIterable(Function.identity());
  }

  public Flux<Transaction> getAllTransactionsByAccountAndDateRange(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return Flux.fromIterable(accountIds)
        .flatMap(
            accountId ->
                accountService
                    .expandAccountId(accountId)
                    .flatMap(
                        account ->
                            getSubscriptionStartDate(account)
                                .flatMap(
                                    subscriptionStartDate ->
                                        transactionService.getAllTransactionsByAccountAndDateRange(
                                            Set.of(account), beginDate, endDate))))
        .collectList()
        .flatMap(hydrationService::hydrate)
        .flatMapIterable(Function.identity());
  }

  public Flux<Transaction> getHistoricTransactions(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate, LocalDate knowledgeDate) {
    return Flux.fromIterable(accountIds)
        .flatMap(
            accountId ->
                accountService
                    .expandAccountId(accountId)
                    .flatMap(
                        account ->
                            transactionService
                                .getHistoricTransactionsByAccountAndDateRangeAndKnowledgeDate(
                                    account,
                                    beginDate,
                                    endDate,
                                    DateUtils.atEndOfDay(knowledgeDate))
                                .filter(Transaction::getIsCurrent)))
        .collectList()
        .flatMap(hydrationService::hydrate)
        .flatMapIterable(Function.identity());
  }

  public Flux<Transaction>
      getTransactionsWithKnowledgeStartDateBetweenAndKnowledgeEndDateGreaterThanAndTypeNotIn(
          LocalDateTime knowledgeStartDateGreaterThan,
          LocalDateTime knowledgeStartDateLessThan,
          LocalDateTime knowledgeEndDateGreaterThan,
          Set<String> types) {
    return transactionService
        .getActiveTransactionsWithKnowledgeStartDateBetweenAndKnowledgeEndDateGreaterThanAndTypeNotIn(
            knowledgeStartDateGreaterThan,
            knowledgeStartDateLessThan,
            knowledgeEndDateGreaterThan,
            types)
        .collectList()
        .flatMapIterable(Function.identity());
  }

  public Flux<Transaction>
      getTransactionsWithKnowledgeEndDateGreaterThanAndKnowledgeEndDateLessThanAndTypeNotIn(
          LocalDateTime knowledgeEndDateGreaterThan,
          LocalDateTime knowledgeEndDateLessThan,
          Set<String> types) {
    return transactionService
        .getTransactionsWithKnowledgeEndDateGreaterThanAndKnowledgeEndDateLessThanAndTypeNotIn(
            knowledgeEndDateGreaterThan, knowledgeEndDateLessThan, types)
        .collectList()
        .flatMapIterable(Function.identity());
  }

  public Flux<TransactionType> getAllTransactionTypes() {
    return transactionService.getAllTransactionTypes();
  }

  public Flux<TransactionSubType> getAllTransactionSubTypes() {
    return transactionService.getAllTransactionSubTypes();
  }

  public Flux<Transaction> getAccountLiveTransactions(
      Long accountId,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeDate,
      boolean includeOffsetTransaction,
      boolean skipHydrate) {
    return accountService
        .expandAccountId(accountId)
        .flatMap(
            expandedAccountId -> {
              String excludedTransType = "";
              if (!includeOffsetTransaction) {
                excludedTransType = OFFSET_TRANSACTION_TYPE;
              }
              return getTransactionsForDisplayingActivities(
                  expandedAccountId,
                  beginDate,
                  endDate,
                  DateUtils.atEndOfDay(knowledgeDate),
                  excludedTransType,
                  skipHydrate);
            });
  }

  public Flux<AwsTransaction> getAwsActivity(
      Long aggAccId,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeDate,
      boolean skipHydrate) {
    return accountService
        .expandAccountId(aggAccId)
        .collectList()
        .flatMapMany(
            accountIds ->
                getAwsActivity(accountIds, beginDate, endDate, knowledgeDate, skipHydrate));
  }

  protected Flux<AwsTransaction> getAwsActivity(
      List<Long> accountIds,
      LocalDate beginDate,
      LocalDate endDate,
      LocalDate knowledgeDate,
      boolean skipHydrate) {
    Flux<TransactionType> cachedTransactionTypes = getAllTransactionTypes();
    return accountConfigServiceCache
        .getAccountConfigs(accountIds, knowledgeDate)
        .flatMapMany(Flux::fromIterable)
        .flatMap(
            accountConfig -> {
              Flux<Transaction> allTransactions =
                  getTransactionsForDisplayingActivities(
                      accountConfig.getAccount().getId(),
                      beginDate,
                      endDate,
                      DateUtils.atEndOfDay(knowledgeDate),
                      Constants.OFFSET_TRANSACTION_TYPE,
                      skipHydrate);
              Map<String, String> attributeMap = accountConfig.getAttributes();
              attributeMap = attributeMap == null ? Collections.emptyMap() : attributeMap;
              String featureDateString =
                  attributeMap.get(TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE.toString());
              LocalDate featureDate =
                  featureDateString != null && !featureDateString.isEmpty()
                      ? LocalDate.parse(featureDateString, DateTimeFormatter.ISO_DATE)
                      : null;
              if (featureDate != null) {
                Flux<Transaction> navTransactions =
                    getNavTransactions(
                            List.of(accountConfig.getAccount().getId()),
                            beginDate,
                            endDate,
                            knowledgeDate)
                        .filter(
                            t -> !t.getKnowledgeStartDate().toLocalDate().isBefore(featureDate));
                Flux<Long> navTransactionIds = navTransactions.map(Transaction::getId);
                Flux<Transaction> nonNavTransactions =
                    allTransactions.filterWhen(
                        t -> navTransactionIds.all(tranId -> !tranId.equals(t.getId())));
                allTransactions = nonNavTransactions.mergeWith(navTransactions);
              }

              // extracting all unique securities
              List<Long> securities = new ArrayList<>();
              allTransactions
                  .filter(t -> WATCHLIST_NAV_SUB_TYPE.equals(t.getSubType()))
                  .map(transaction -> transaction.getSecurity().getSecurityId())
                  .distinct()
                  .subscribe(
                      securities::add, // onNext
                      Throwable::printStackTrace // onError
                      );

              Map<Long, Set<WatchlistEntity>> activeWatchListsMap =
                  watchlistService.getActiveWatchlistSecuritiesByAccount(
                      List.of(accountConfig.getAccount().getId()), securities, knowledgeDate);

              return allTransactions
                  .filter(
                      // Economic NAV should not be part of the accounting data returned by this API
                      t -> !ECONOMIC_NAV_SUB_TYPE.equals(t.getSubType()))
                  .filter(
                      // when active on watchlist keep all watchlist transactions
                      // and all cash effecting transactions within the watchlist period
                      t -> watchlistFilter(t, activeWatchListsMap));
            })
        .flatMap(txn -> LpxAwsTransactionUtil.getTransactionAffect(txn, cachedTransactionTypes));
  }

  public Flux<Transaction> getNavTransactions(
      List<Long> accountIds, LocalDate beginDate, LocalDate endDate, LocalDate knowledgeAsOf) {
    LocalDateTime knowledgeTimeStamp =
        DateUtils.atEndOfDay(knowledgeAsOf != null ? knowledgeAsOf : LocalDate.now());
    List<List<Long>> batches = Lists.partition(accountIds, BATCH_SIZE);
    Flux<Transaction> result = Flux.empty();

    for (List<Long> batch : batches) {
      result =
          Flux.merge(
              result,
              transactionService.getMappedNavTransactions(
                  new HashSet<>(batch), beginDate, endDate, knowledgeTimeStamp));
    }
    return result
        .map(
            t -> {
              LocalDate knowledgeStart = t.getKnowledgeStartDate().toLocalDate();
              return t.toBuilder()
                  .settleDate(
                      LocalDate.of(knowledgeStart.getYear(), knowledgeStart.getMonthValue(), 1))
                  .build();
            })
        .collectList()
        .cache()
        .flatMapIterable(Function.identity())
        .filter(transaction -> transaction.getSettleDate() != null);
  }

  public Mono<List<Transaction>> getTransactionsForCalculatingBalances(
      Long parentAccountId,
      List<Long> accountIds,
      LocalDate beginDate,
      LocalDate finalAsOfDate,
      LocalDateTime knowledgeAsOf,
      boolean skipHydration) {
    List<List<Long>> batches = Lists.partition(accountIds, BATCH_SIZE);
    List<Transaction> allTransactions =
        batches.parallelStream()
            .map(
                batch -> {
                  Set<Transaction> batchResult =
                      transactionService.getTransactionsNonReactive(
                          new HashSet<>(batch),
                          beginDate,
                          finalAsOfDate,
                          knowledgeAsOf,
                          OFFSET_TRANSACTION_TYPE,
                          false,
                          true);
                  log.info(
                      "Retrieved {} transactions from {} accounts for calculating balances. parentAccountId: {}",
                      batchResult.size(),
                      batch.size(),
                      parentAccountId);
                  return batchResult;
                })
            .flatMap(Collection::stream)
            .toList();

    if (allTransactions.isEmpty()) {
      log.error(
          "No Transactions Found For account : {} expandedAccIds : {}",
          parentAccountId,
          accountIds);
      return Mono.empty();
    }

    allTransactions =
        allTransactions.stream()
            .filter(
                transaction ->
                    (transaction.getSettleDate() != null)
                        && !transaction.getSettleDate().isAfter(finalAsOfDate))
            .toList();

    Mono<List<Transaction>> allTxns = Mono.just(allTransactions);

    if (!skipHydration) {
      // LMC seems to only use account and security data. No need to hydrate document data
      return allTxns
          .flatMap(hydrationService::hydrateAccountData)
          .publishOn(Schedulers.boundedElastic())
          .flatMap(hydrationService::hydrateSecurityData)
          .map(
              txns -> {
                log.info(
                    "Finished filtering/hydrating transactions for calculating balances. parentAccountId: {} TotalTxns {}",
                    parentAccountId,
                    txns.size());
                return txns;
              });
    }

    log.info(
        "Skipping filtering/hydrating transactions for calculating balances. parentAccountId: {} TotalTxns {}",
        parentAccountId,
        allTransactions.size());

    return allTxns;
  }

  public List<Transaction> getOpeningTransactions(List<Transaction> txns) {
    return txns.stream()
        .filter(transaction -> OPEN_TRAN_TYPES.contains(transaction.getType()))
        .toList();
  }

  public Flux<Map.Entry<String, Transaction>>
      getAllAccountsAndMinimumSettleDateTransactionModifiedToday() {
    return transactionService
        .getAllTransactionsModifiedToday()
        .filter(
            transaction ->
                Boolean.TRUE.equals(transaction.getIsCurrent())
                    && (!("TRN".equals(transaction.getType()))))
        .filter(this::isEligibleForPerformanceCalculation)
        .groupBy(
            transaction ->
                transaction.getAccount().getId() + ":" + transaction.getSecurity().getSecurityId(),
            2048)
        .flatMap(
            groupedFlux ->
                groupedFlux
                    .collectList()
                    .map(
                        transactionsList -> {
                          transactionsList.sort(Comparator.comparing(Transaction::getModifiedOn));
                          return Map.entry(groupedFlux.key(), transactionsList.get(0));
                        }))
        .switchIfEmpty(
            s -> {
              log.info("No Transactions Modified on {}", LocalDateTime.now());
              s.onComplete();
            });
  }

  public Flux<Transaction> getOpeningTransactionsByAccountIds(Long accountId) {
    return accountService
        .expandAccountId(accountId)
        .flatMap(
            accId ->
                transactionService
                    .getAllActiveTransactionsByAccountIdAndType(accId, OPEN_TRAN_TYPES)
                    .filter(
                        transaction ->
                            (!transaction.getAction().equals("Cancel"))
                                && transaction.getIsCurrent())
                    .flatMap(
                        transaction ->
                            loadTransactionDetailService
                                .getLoadTransactionDetailByTxnIdAndVersion(
                                    transaction.getId(), transaction.getVersion())
                                .collectList()
                                .flatMap(
                                    loadTransactionDetails ->
                                        Mono.just(
                                            transaction.toBuilder()
                                                .loadTransactionDetails(
                                                    Set.copyOf(loadTransactionDetails))
                                                .build()))))
        .collectList()
        .flatMap(hydrationService::hydrate)
        .flatMapIterable(Function.identity());
  }

  public Mono<ValidationResponse> validateOpeningTransactions(
      Integer userId, Set<Transaction> openingTransactions) {
    ValidationResponse validationResponse = ValidationResponse.builder().build();
    Set<Long> accountIds =
        openingTransactions.stream()
            .map(transaction -> transaction.getAccount().getId())
            .collect(Collectors.toSet());
    Map<Long, String> securityIdAndCusipMapping =
        openingTransactions.stream()
            .collect(
                Collectors.toMap(
                    transaction -> transaction.getSecurity().getSecurityId(),
                    transaction -> transaction.getSecurity().getCusip(),
                    (cusip1, cusip2) -> {
                      log.info("Duplicate key found with cusip: {}", cusip2);
                      return cusip1;
                    }));
    return Flux.fromIterable(openingTransactions)
        .flatMap(
            transaction ->
                accountService
                    .getAccountData(transaction.getAccount().getId())
                    .flatMap(
                        account -> {
                          if (!account
                              .getFunctionalCurrencyCode()
                              .equals(transaction.getFxCurrency())) {
                            List<LoadTransactionDetail> invalidDetails =
                                transaction.getLoadTransactionDetails().stream()
                                    .filter(detail -> detail.getFxBookValue() == null)
                                    .toList();
                            if (!invalidDetails.isEmpty()) {
                              return Mono.just(transaction);
                            }
                          }
                          return Mono.empty();
                        }))
        .collectList()
        .flatMap(
            invalidTransactions -> {
              if (!invalidTransactions.isEmpty()) {
                String errorDetail =
                    invalidTransactions.stream()
                        .map(
                            t -> {
                              List<String> accountingMethods =
                                  t.getLoadTransactionDetails().stream()
                                      .filter(detail -> detail.getFxBookValue() == null)
                                      .map(LoadTransactionDetail::getAccountingMethod)
                                      .toList();
                              return "AccountId: "
                                  + t.getAccount().getId()
                                  + ", SecurityId: "
                                  + t.getSecurity().getSecurityId()
                                  + ", AccountingMethods: "
                                  + accountingMethods;
                            })
                        .collect(Collectors.joining("; "));
                log.info(
                    "Account functionalCurrencyCode and transaction's fxCurrency do not match, fxBookValue(s) cannot be not null for {}",
                    errorDetail);
                setReasonMessage(
                    validationResponse,
                    "Account functionalCurrencyCode and transaction's fxCurrency do not match, fxBookValue(s) cannot be not null for",
                    errorDetail);
              }
              return validateUserAccountAccess(
                  userId, accountIds, securityIdAndCusipMapping, validationResponse);
            });
  }

  private Mono<ValidationResponse> validateUserAccountAccess(
      Integer userId,
      Set<Long> accountIds,
      Map<Long, String> securityIdAndCusipMapping,
      ValidationResponse validationResponse) {
    log.info("Validating user account access");
    return accountService
        .checkUserAccessToAccounts(userId, accountIds)
        .map(
            entryMap ->
                entryMap.entrySet().stream()
                    .collect(
                        Collectors.partitioningBy(entry -> Boolean.TRUE.equals(entry.getValue()))))
        .filter(booleanListMap -> !booleanListMap.get(Boolean.FALSE).isEmpty())
        .map(booleanListMap -> booleanListMap.get(Boolean.FALSE))
        .map(entries -> entries.stream().map(Entry::getKey).collect(Collectors.toSet()))
        .doOnNext(
            longs -> {
              log.info("User does not have access to these accounts {}", longs);
              setReasonMessage(
                  validationResponse,
                  "User does not have access to these accounts",
                  longs.toString());
            })
        .then(Mono.just(validationResponse))
        .thenMany(validateSecurityIdAndCusip(securityIdAndCusipMapping, validationResponse))
        .then(Mono.just(validationResponse));
  }

  private Mono<ValidationResponse> validateSecurityIdAndCusip(
      Map<Long, String> securityIdAndCusipMapping, ValidationResponse errorResponse) {
    log.info("Validating securityId and cusip");
    Set<Long> securityIds = securityIdAndCusipMapping.keySet();
    return securityService
        .getSecurities(null, null, List.copyOf(securityIds))
        .flatMap(
            securities ->
                validateCusip(securities, securityIdAndCusipMapping, errorResponse)
                    .thenReturn(securities))
        .map(
            securities ->
                securities.stream().map(Security::getSecurityId).collect(Collectors.toSet()))
        .filter(
            secIds -> {
              if (!secIds.isEmpty()) {
                return securityIds.removeAll(secIds) && !securityIds.isEmpty();
              } else {
                return true;
              }
            })
        .doOnNext(
            longs -> {
              log.info("invalid securities {}", securityIds);
              setReasonMessage(errorResponse, "invalid securities", securityIds.toString());
            })
        .then(Mono.just(errorResponse));
  }

  private Mono<ValidationResponse> validateCusip(
      List<Security> securityDetailsList,
      Map<Long, String> securityIdAndCusipMapping,
      ValidationResponse validationResponse) {
    log.info("validating cusip {}", securityDetailsList);
    return Flux.fromIterable(securityDetailsList)
        .filter(
            security ->
                !security
                    .getCusip()
                    .equals(securityIdAndCusipMapping.get(security.getSecurityId())))
        .map(
            security ->
                security.getSecurityId()
                    + ":"
                    + securityIdAndCusipMapping.get(security.getSecurityId()))
        .collectList()
        .doOnNext(
            securityList -> {
              if (!securityList.isEmpty()) {
                log.info("SecurityId does not match with provided cusip {}", securityList);
                setReasonMessage(
                    validationResponse,
                    "SecurityId and cusip mapping not found",
                    securityList.toString());
              }
            })
        .then(Mono.just(validationResponse));
  }

  private void setReasonMessage(
      ValidationResponse errorResponse, String errorMessage, String errorValues) {
    List<String> reasons =
        errorResponse.getResponse() == null ? new ArrayList<>() : errorResponse.getResponse();
    reasons.add(errorMessage + " " + errorValues);
    errorResponse.setResponse(reasons);
  }

  private Flux<LocalDate> getSubscriptionStartDate(Long accountId) {
    return accountConfigServiceCache
        .getByAccountId(accountId)
        .filter(config -> !Objects.isNull(config))
        .mapNotNull(AccountConfig::getSubscriptionStartDate)
        .flux();
  }

  private Mono<Map<Long, LocalDate>> getSubscriptionStartDateMap(Set<Long> accountIds) {
    return Flux.fromIterable(accountIds)
        .flatMap(accountConfigServiceCache::getByAccountId)
        .collect(
            Collectors.toMap(
                account -> account.getAccount().getId(), AccountConfig::getSubscriptionStartDate));
  }

  private boolean isEligibleForPerformanceCalculation(Transaction transaction) {
    if (CREATE_CANCEL_ACTION.contains(transaction.getAction())) {
      return true;
    } else {
      if (transaction.getModifiedAttributesResults() != null
          && !transaction.getModifiedAttributesResults().getModifiedAttributes().isEmpty()) {
        return transaction.getModifiedAttributesResults().getModifiedAttributes().stream()
            .anyMatch(
                modifiedAttr ->
                    PERFORMANCE_CALCULATION_MANDATORY_FIELDS.contains(modifiedAttr.getFieldName()));
      } else {
        return false;
      }
    }
  }

  public Flux<Transaction> getAllTransactionsModifiedOnDate(LocalDate providedDate) {
    return transactionService.getAllTransactionsModifiedOnDate(providedDate);
  }

  public Mono<Boolean> checkIfOwnershipRuleIdExists(Long accountId, Long securityId) {
    return ifRuleExists(accountId, securityId)
        .mergeWith(ifOwnershipExists(accountId, securityId))
        .collectList()
        .filter(checks -> checks.size() > 1)
        .map(checks -> checks.get(0) || checks.get(1));
  }

  private Mono<Boolean> ifRuleExists(Long accountId, Long securityId) {
    return accountConfigServiceClient
        .getAccountRules(accountId)
        .collectList()
        .map(
            accountSubscriptionRules -> {
              if (null == accountSubscriptionRules || accountSubscriptionRules.isEmpty()) {
                return Boolean.FALSE;
              }
              return checkIfRuleMatchesSecurity(accountSubscriptionRules, securityId);
            });
  }

  private Boolean checkIfRuleMatchesSecurity(
      List<AccountSubscriptionRules> accountSubscriptionRules, Long secId) {
    return accountSubscriptionRules.stream()
        .anyMatch(rule -> null == rule.getSecurityId() || rule.getSecurityId().equals(secId));
  }

  private Mono<Boolean> ifOwnershipExists(Long accountId, Long securityId) {
    val multipliers = fundService.getOwnershipPercentage(accountId, securityId);
    return Mono.just(!(null == multipliers || multipliers.isEmpty()));
  }

  private boolean isWithinWatchlistRange(
      Transaction transaction, Map<Long, Set<WatchlistEntity>> watchlistPeriods) {
    // this is only needed to calculate non-watchlist transactions as all watchlist transactions
    // want to be included
    if (watchlistPeriods.containsKey(transaction.getAccount().getId())) {
      return watchlistPeriods.get(transaction.getAccount().getId()).stream()
          .anyMatch(
              watchlistEntity ->
                  watchlistEntity.getSecurityId().equals(transaction.getSecurity().getSecurityId())
                          && (transaction.getSettleDate().isAfter(watchlistEntity.getStartDate())
                              || transaction
                                  .getSettleDate()
                                  .isEqual(watchlistEntity.getStartDate()))
                          && (transaction.getSettleDate().isBefore(watchlistEntity.getEndDate()))
                      || transaction.getSettleDate().isEqual(watchlistEntity.getEndDate()));
    }
    return false;
  }

  //  protected Flux<Transaction> transactionForOpenPositions(Flux<Transaction> transactionsFlux) {
  //    return transactionsFlux
  //        .collectList() // Collect transactions into a List
  //        .flatMapMany(transactions -> {
  //          Set<Transaction> validTransactions = new HashSet<>();
  //          Map<Long, List<Transaction>> accountToTransaction =
  //              transactions.stream()
  //                  .collect(groupingBy(t -> t.getAccount().getId()));
  //          for (Entry<Long, List<Transaction>> entry : accountToTransaction.entrySet()) {
  //            List<Transaction> transactionsForAccount = entry.getValue();
  //            Map<Long, List<LocalDateRange>> lotEffectiveRangeMap =
  //                portfolioService.getLotEffectiveRangeMap(
  //                    entry.getKey(),
  //                    transactionsForAccount.stream()
  //                        .map(t -> t.getSecurity().getSecurityId())
  //                        .collect(Collectors.toSet()));
  //            for (Transaction transaction : transactionsForAccount) {
  //              List<LocalDateRange> lotEffectiveRanges =
  //                  lotEffectiveRangeMap.get(transaction.getSecurity().getSecurityId());
  //              if (lotEffectiveRanges == null) {
  //                validTransactions.add(transaction); //add if there is no core lot created
  //                break;
  //              }
  //              for (LocalDateRange lotEffectiveRange : lotEffectiveRanges) {
  //                if (transaction.getSettleDate().isBefore(lotEffectiveRange.getSecond())) {
  //                  validTransactions.add(transaction);
  //                  break;
  //                }
  //              }
  //            }
  //          }
  //          // Return the valid transactions as a Flux
  //          return Flux.fromIterable(validTransactions);
  //        });
  //  }
}
