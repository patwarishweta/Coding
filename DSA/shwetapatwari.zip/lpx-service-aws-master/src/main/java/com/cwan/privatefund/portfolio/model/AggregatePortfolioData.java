package com.cwan.privatefund.portfolio.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class AggregatePortfolioData {
  private Double irr;
  private Double pme;
  private Double rvpi;
  private Double dpi;
  private Double tvpi;
}
