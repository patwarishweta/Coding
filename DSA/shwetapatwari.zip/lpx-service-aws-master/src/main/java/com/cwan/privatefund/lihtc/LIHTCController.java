package com.cwan.privatefund.lihtc;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.TaxType;
import com.cwan.pbor.clientspecific.LPxClientSpecificData;
import com.cwan.privatefund.lihtc.model.BenefitScheduleRequest;
import com.cwan.privatefund.lihtc.model.TaxRateRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/lihtc")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class LIHTCController {
  private final LPxLIHTCService lpxLihtcService;
  private final LPxClientSpecificData lPxClientSpecificData;

  public LIHTCController(
      LPxLIHTCService lpxLihtcService, LPxClientSpecificData lpxClientSpecificData) {
    this.lpxLihtcService = lpxLihtcService;
    this.lPxClientSpecificData = lpxClientSpecificData;
  }

  @PostMapping(value = "/benefit-schedules")
  @Operation(summary = "Add LIHTC benefit schedules")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added LIHTC benefit schedules successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = BenefitScheduleRequest.class))
            })
      })
  public Flux<LIHTCBenefitSchedule> addBenefitSchedules(
      @Parameter(description = "LIHTC Benefit Schedule Data") @RequestBody
          List<LIHTCBenefitSchedule> lihtcBenefitSchedules) {
    return lpxLihtcService.addBenefitSchedules(lihtcBenefitSchedules);
  }

  @GetMapping(value = "/benefit-schedules")
  @Operation(
      summary =
          "Get LIHTC benefit schedules for account/security with optional report date filter.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Retrieved LIHTC benefit schedules by Ids successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LIHTCBenefitSchedule.class))
            })
      })
  public Mono<Map<LocalDate, Collection<LIHTCBenefitSchedule>>>
      getBenefitSchedulesForAccountSecurity(
          @Parameter(description = "Account Id") @RequestParam Long accountId,
          @Parameter(description = "Security Id") @RequestParam Long securityId,
          @Parameter(description = "Optional Report Date")
              @RequestParam
              @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
              Optional<LocalDate> reportDate) {
    if (reportDate.isPresent()) {
      return lpxLihtcService.getBenefitSchedulesForAccountSecurityReportingDate(
          accountId, securityId, reportDate.get());
    } else {
      return lpxLihtcService.getBenefitSchedulesForAccountSecurityPair(accountId, securityId);
    }
  }

  @DeleteMapping(value = "/benefit-schedules")
  @Operation(
      summary =
          "Delete LIHTC benefit schedules for account/security with optional report date and tax type filter.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Deleted LIHTC benefit schedules successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LIHTCBenefitSchedule.class))
            })
      })
  public Mono<Map<LocalDate, Collection<LIHTCBenefitSchedule>>> deleteBenefitSchedules(
      @Parameter(description = "Account Id") @RequestParam Long accountId,
      @Parameter(description = "Security Id") @RequestParam Long securityId,
      @Parameter(description = "Report Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate reportDate,
      @Parameter(description = "Tax Type") @RequestParam TaxType taxType,
      @Parameter(description = "Optional Schedule Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          Optional<LocalDate> scheduleDate) {
    if (scheduleDate.isPresent()) {
      return lpxLihtcService
          .deleteBenefitSchedulesForAccountSecurityTaxTypeReportingDateScheduleDate(
              accountId, securityId, reportDate, taxType, scheduleDate.get());
    } else {
      return lpxLihtcService.deleteBenefitSchedulesForAccountSecurityTaxType(
          accountId, securityId, reportDate, taxType);
    }
  }

  @PostMapping(value = "/tax-rates")
  @Operation(summary = "Add LIHTC tax rates")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added LIHTC tax rates successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = TaxRateRequest.class))
            })
      })
  public Flux<LIHTCTaxRate> addTaxRates(
      @Parameter(description = "LIHTC Tax Rate Data") @RequestBody
          List<LIHTCTaxRate> lihtcTaxRates) {
    return lpxLihtcService.addTaxRates(lihtcTaxRates);
  }

  @GetMapping(value = "/tax-rates")
  @Operation(
      summary = "Get LIHTC tax rates for account/security pair with optional tax type filter.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Retrieved LIHTC tax rates for account/security successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LIHTCTaxRate.class))
            })
      })
  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>> getTaxRatesForAccountSecurity(
      @Parameter(description = "Account Id") @RequestParam Long accountId,
      @Parameter(description = "Security Id") @RequestParam Long securityId,
      @Parameter(description = "Optional Tax Type") @RequestParam Optional<TaxType> taxType) {
    if (taxType.isPresent()) {
      return lpxLihtcService.getTaxRatesForAccountSecurityForTaxType(
          accountId, securityId, taxType.get());
    } else {
      return lpxLihtcService.getTaxRatesForAccountSecurityPair(accountId, securityId);
    }
  }

  @DeleteMapping(value = "/tax-rates")
  @Operation(
      summary =
          "Delete LIHTC tax rates for account/security pair with optional tax type and start date filter.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Deleted LIHTC tax rates successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LIHTCTaxRate.class))
            })
      })
  public Mono<Map<LocalDate, Collection<LIHTCTaxRate>>> deleteTaxRates(
      @Parameter(description = "Account Id") @RequestParam Long accountId,
      @Parameter(description = "Security Id") @RequestParam Long securityId,
      @Parameter(description = "Optional Tax Type") @RequestParam Optional<TaxType> taxType,
      @Parameter(description = "Optional Tax Rate Start Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          Optional<LocalDate> taxRateStartDate) {
    if (taxType.isPresent() && taxRateStartDate.isPresent()) {
      return lpxLihtcService.deleteTaxRatesForAccountSecurityTaxTypeTaxRateStartDate(
          accountId, securityId, taxType.get(), taxRateStartDate.get());
    } else if (taxType.isPresent()) {
      return lpxLihtcService.deleteTaxRatesForAccountSecurityTaxType(
          accountId, securityId, taxType.get());
    } else {
      return lpxLihtcService.deleteTaxRatesForAccountSecurity(accountId, securityId);
    }
  }

  @GetMapping(value = "/amortization-start-date")
  @Operation(
      summary =
          "View the amortization start date for the account/security pair as set in the client specific config table.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description =
                "Retrieved amortization start date (if specified in client specific config). Will return an empty response otherwise.",
            content = {
              @Content(mediaType = MediaType.APPLICATION_JSON_VALUE),
            })
      })
  public LocalDate getAmortizationStartDate(
      @Parameter(description = "Account Id") @RequestParam Long accountId,
      @Parameter(description = "Security Id") @RequestParam Long securityId) {
    return lPxClientSpecificData.getAmortizationStartDate(accountId, securityId);
  }

  @GetMapping(value = "/manual-amort-segments")
  @Operation(summary = "Get the manual amort segments")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Retrieved manual amort segments",
            content = {
              @Content(mediaType = MediaType.APPLICATION_JSON_VALUE),
            })
      })
  public Set<ManualAmortSegment> getManualAmortSegments(
      @Parameter(description = "Account Id") @RequestParam Long accountId,
      @Parameter(description = "Security Id") @RequestParam Long securityId,
      @Parameter(description = "Basis Id") @RequestParam int basisId) {
    return lpxLihtcService.getManualAmortSegments(accountId, securityId, basisId);
  }

  @PostMapping(value = "/manual-amort-segments")
  @Operation(summary = "Updates segments, can also create new segments if no id is provided")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Updated provided amort segments and notified performance worker",
            content = {
              @Content(mediaType = MediaType.APPLICATION_JSON_VALUE),
            })
      })
  public ResponseEntity saveManualSegment(
      @Parameter(description = "Segments that were updated or need to be created") @RequestBody
          ManualAmortSegmentRequest request) {
    Set<Integer> basisIds =
        request.segments().stream().map(ManualAmortSegment::basisId).collect(Collectors.toSet());

    if (basisIds.stream().anyMatch(basisId -> basisId > 3 || basisId <= 0)) {
      log.error("Invalid basis id provided: {}", basisIds);
      return ResponseEntity.badRequest().body("Invalid basis id provided");
    }
    lpxLihtcService.updateManualAmortSegments(
        request.segments(), request.inactivateExistingEntries());
    return ResponseEntity.ok().build();
  }

  public record ManualAmortSegmentRequest(
      Set<ManualAmortSegment> segments, boolean inactivateExistingEntries) {}
}
