package com.cwan.privatefund.capital.call.constant;

import com.cwan.privatefund.cpd.ws.constant.CpdWSField;
import java.util.regex.Pattern;
import lombok.experimental.UtilityClass;

/** Contains utility constant related to Capital Call operations. */
@UtilityClass
public class CapitalCallConstants {

  @UtilityClass
  public static class CommonConstants {

    public static final Pattern SPLIT_PATTERN = Pattern.compile("[,;]");
    public static final Integer BUFFER_SIZE = 50;
  }

  @UtilityClass
  public static class PermissionHelperConstants {

    public static final String WIRE_TRANSFER = CpdWSField.WIRE_TRANSFER.getFieldName();
    public static final String INITIAL = CpdWSField.INITIAL.getFieldName();
    public static final String FINAL = CpdWSField.FINAL.getFieldName();
    public static final Pattern EMAIL_SPLIT_PATTERN = CommonConstants.SPLIT_PATTERN;
  }

  @UtilityClass
  public static class ScheduledServiceConstants {

    public static final String TIME_FORMAT = "HH:mm:ss";
  }

  @UtilityClass
  public static class CapitalCallEmailConstants {

    public static final int QUEUE_CAPACITY = 100;
    public static final String DOCUMENT_AUDIT_EMAIL_SUBJECT =
        "Capital Call Status Change - Action Required";
    public static final String NEW_CAPITAL_CALL_EMAIL_SUBJECT = "New Capital Calls";
  }

  @UtilityClass
  public static class EmailNotificationConstants {

    public static final String SERVICE_NAME = "lpx-service";
    public static final String FROM_ADDRESS = "no-reply@clearwateranalytics.com";
  }
}
