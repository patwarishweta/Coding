package com.cwan.privatefund.balance.model;

import static java.util.stream.Collectors.groupingBy;

import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Balance;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class LmcBalance {
  private String limitedPartnership;
  private String source;
  private String identifier;
  private Long lpId;
  private Long documentId;
  private Long accountId;
  private String accountName;
  private String currency;
  private Double sponsorNav;
  private Double watchListNav;
  private Double gaapNav;
  private Double statNav;
  private Double commitment;
  private Double unfundedExclRecallable;
  private Double funded;
  private Double unfundedInclRecallable;
  private Double recallableDist;

  public static Set<LmcBalance> convertToLmcBalance(Collection<Balance> balances) {
    Set<LmcBalance> retVal = new HashSet<>();

    Map<LmcBalance, List<Balance>> initialRows =
        balances.stream().collect(groupingBy(LmcBalance::initBalance));

    for (Entry<LmcBalance, List<Balance>> row : initialRows.entrySet()) {
      LmcBalanceBuilder builder = row.getKey().toBuilder();
      List<Balance> balanceList = row.getValue();

      for (Balance b : balanceList) {
        switch (BalanceType.BALANCE_TYPE_MAP.get(b.getType())) {
          case REPORTED_ENDING_NAV -> builder.sponsorNav(b.getAmount());
          case REPORTED_TOTAL_COMMITMENT -> builder.commitment(b.getAmount());
          case REPORTED_ENDING_UNFUNDED_COMMITMENT -> builder.unfundedExclRecallable(b.getAmount());
          case FUNDED_COMMITMENT -> builder.funded(b.getAmount());
          case REPORTED_RECALLABLE_DISTRIBUTION -> builder.recallableDist(b.getAmount());
          default -> {}
        }
      }
      builder.unfundedInclRecallable(
          builder.recallableDist == null || builder.unfundedExclRecallable == null
              ? null
              : builder.recallableDist + builder.unfundedExclRecallable);
      retVal.add(builder.build());
    }
    return retVal;
  }

  private static LmcBalance initBalance(Balance balance) {
    return LmcBalance.builder()
        .accountId(balance.getAccount().getId())
        .accountName(balance.getAccount().getName())
        .currency(balance.getCurrency())
        .identifier(balance.getSecurity().getCusip())
        .limitedPartnership(balance.getSecurity().getSecurityName())
        .lpId(balance.getSecurity().getSecurityId())
        .source("Document")
        .documentId(balance.getDocument().getId())
        .build();
  }

  public static LmcBalance convertToLmcBalance(CalculatedBalance calculatedBalance) {
    return new LmcBalance(
        calculatedBalance.getSecurity().getSecurityName(),
        calculatedBalance.getSource(),
        calculatedBalance.getSecurity().getCusip(),
        calculatedBalance.getSecurity().getSecurityId(),
        null, // no document id for calculated docs
        calculatedBalance.getAccount().getId(),
        calculatedBalance.getAccount().getName(),
        calculatedBalance.getCurrency(),
        calculatedBalance.getNavImpact(),
        calculatedBalance.getWatchlistNavImpact(),
        calculatedBalance.getGaapNavImpact(),
        calculatedBalance.getStatNavImpact(),
        calculatedBalance.getTotalCommitment(),
        calculatedBalance.getUnfundedCommitmentImpact(),
        calculatedBalance.getFundedCommitmentImpact(),
        calculatedBalance.getUnfundedCommitmentImpact() + calculatedBalance.getRecallableImpact(),
        calculatedBalance.getRecallableImpact());
  }
}
