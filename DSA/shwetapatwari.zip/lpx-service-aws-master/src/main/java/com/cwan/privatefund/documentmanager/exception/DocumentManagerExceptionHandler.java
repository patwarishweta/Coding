package com.cwan.privatefund.documentmanager.exception;

import com.cwan.privatefund.documentmanager.DocumentUploadResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@RestControllerAdvice(basePackages = "com.cwan.privatefund.documentmanager")
@Slf4j
public class DocumentManagerExceptionHandler {
  @ExceptionHandler(DocumentUploadFailedException.class)
  public Mono<ResponseEntity<DocumentUploadResponse>> handleDocumentUploadFailedException(
      DocumentUploadFailedException ex) {
    log.error("Document Upload Failed exception: {}", ex.getMessage());
    return Mono.just(
        ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(
                DocumentUploadResponse.builder()
                    .uploadedFileDetails(ex.getUploadFileDetailsList())
                    .build()));
  }

  @ExceptionHandler(ResponseStatusException.class)
  public Mono<ResponseEntity<String>> handleResponseStatusException(ResponseStatusException ex) {
    log.error("Response status exception: {}", ex.getMessage());
    return Mono.just(ResponseEntity.status(ex.getStatusCode()).body(ex.getMessage()));
  }
}
