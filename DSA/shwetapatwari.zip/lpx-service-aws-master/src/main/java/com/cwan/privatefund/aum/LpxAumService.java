package com.cwan.privatefund.aum;

import static java.util.Collections.emptyMap;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

import com.cwan.lpx.domain.Aum;
import com.cwan.pbor.aum.api.Aums;
import com.cwan.privatefund.aum.model.AumRequest;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.calculated.CalculatedBalanceService;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class LpxAumService {

  private final Aums aums;
  private final BusinessWSClient businessWSClient;
  private final CalculatedBalanceService calculatedBalanceService;

  public LpxAumService(
      Aums aums,
      BusinessWSClient businessWSClient,
      CalculatedBalanceService calculatedBalanceService) {
    this.aums = aums;
    this.businessWSClient = businessWSClient;
    this.calculatedBalanceService = calculatedBalanceService;
  }

  public Map<Long, Set<Aum>> addAums(AumRequest aumRequests) {
    var result = aums.addAums(aumRequests.getAums());
    return result.stream().collect(Collectors.groupingBy(Aum::getUltimateParentId, toSet()));
  }

  public Map<Long, Set<Aum>> updateAums(AumRequest aumRequests) {
    var result = aums.updateAll(aumRequests.getAums());
    return result.stream().collect(Collectors.groupingBy(Aum::getUltimateParentId, toSet()));
  }

  public Map<Long, List<Aum>> getAumByUltimateParentIds(Set<Long> ids) {
    LocalDate today = LocalDate.now();
    try {
      return Flux.fromIterable(ids)
          .flatMap(businessWSClient::getClientAccountIds)
          .flatMapIterable(Function.identity())
          .flatMap(
              accountId ->
                  calculatedBalanceService
                      .calculateBalances(accountId, today, today, false)
                      .map(
                          calculatedBalance -> {
                            Aum aum = fromCalculatedBalance(calculatedBalance, today);
                            return aums.upsertByAccountIdAndSecurityIdAndCalculatedOn(
                                calculatedBalance.getAccount().getId(),
                                calculatedBalance.getSecurity().getSecurityId(),
                                today,
                                aum);
                          }))
          .collectList()
          .map(
              aumList ->
                  aumList.stream()
                      .collect(
                          Collectors.groupingBy(Aum::getUltimateParentId, HashMap::new, toList())))
          .toFuture()
          .get();
    } catch (InterruptedException | ExecutionException e) {
      log.error("Error in getAumByUltimateParentIds", e);
      return emptyMap();
    }
  }

  private Aum fromCalculatedBalance(CalculatedBalance balance, LocalDate date) {
    return new Aum(
        null,
        balance.getAccount().getId(),
        balance.getSecurity().getSecurityId(),
        Long.valueOf(balance.getAccount().getUltimateParentClient().getParentId()),
        balance.getAccount().getClientId(),
        balance.getNavImpact(),
        date,
        true);
  }

  public Map<Integer, Integer> getLPsCountByClientId(Set<Long> ids) {
    try {
      return Flux.fromIterable(ids)
          .flatMap(businessWSClient::getClientAccountIds)
          .flatMapIterable(Function.identity())
          .flatMap(
              accountId ->
                  calculatedBalanceService.calculateBalances(
                      accountId, LocalDate.now(), LocalDate.now(), false))
          .collect(
              Collectors.groupingBy(
                  cb -> cb.getAccount().getClient().getParentId(),
                  HashMap::new,
                  Collectors.collectingAndThen(
                      mapping(
                          cb -> fromCalculatedBalance(cb, LocalDate.now()).getClientId(), toSet()),
                      Set::size)))
          .toFuture()
          .get();
    } catch (ExecutionException | InterruptedException e) {
      log.error("Error in getLPsByClientId", e);
      return emptyMap();
    }
  }
}
