package com.cwan.privatefund.aum.model;

import com.cwan.lpx.domain.Aum;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
@JsonRootName("aumRequest")
public class AumRequest {
  private Set<Aum> aums;
}
