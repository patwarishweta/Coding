package com.cwan.privatefund;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.reactive.ReactiveUserDetailsServiceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(
    exclude = {ReactiveUserDetailsServiceAutoConfiguration.class},
    scanBasePackages = {
      "com.cwan.privatefund",
      "com.cwan.pbor.trans",
      "com.cwan.pbor.balance",
      "com.cwan.pbor.k1",
      "com.cwan.pbor.document",
      "com.cwan.pbor.performance",
      "com.cwan.pbor.cashflow",
      "com.cwan.pbor.fs",
      "com.cwan.pbor.clientspecific",
      "com.cwan.pbor.fundmaster",
      "com.cwan.pbor.reporting",
      "com.cwan.pbor.lihtc",
      "com.cwan.pbor.fxrate",
      "com.cwan.pbor.aum",
      "com.cwan.pbor.tag"
    })
@EnableJpaRepositories(
    basePackages = {
      "com.cwan.pbor.trans",
      "com.cwan.pbor.balance",
      "com.cwan.pbor.k1",
      "com.cwan.pbor.document",
      "com.cwan.privatefund.comment",
      "com.cwan.privatefund.directory",
      "com.cwan.privatefund.canoeFundMapping",
      "com.cwan.pbor.performance",
      "com.cwan.pbor.cashflow",
      "com.cwan.pbor.fs",
      "com.cwan.pbor.tag",
      "com.cwan.privatefund.tag",
      "com.cwan.pbor.clientspecific",
      "com.cwan.pbor.lihtc",
      "com.cwan.pbor.fundmaster",
      "com.cwan.pbor.reporting",
      "com.cwan.privatefund.watchlist",
      "com.cwan.pbor.fxrate",
      "com.cwan.privatefund.security.currency",
      "com.cwan.privatefund.document",
      "com.cwan.privatefund.fxrate.source",
      "com.cwan.pbor.aum"
    })
@EntityScan(
    basePackages = {
      "com.cwan.pbor.trans",
      "com.cwan.pbor.balance",
      "com.cwan.pbor.k1",
      "com.cwan.pbor.document",
      "com.cwan.privatefund.comment",
      "com.cwan.privatefund.directory",
      "com.cwan.privatefund.canoeFundMapping",
      "com.cwan.pbor.performance",
      "com.cwan.pbor.cashflow",
      "com.cwan.pbor.fs",
      "com.cwan.pbor.tag",
      "com.cwan.pbor.clientspecific",
      "com.cwan.pbor.lihtc",
      "com.cwan.pbor.fundmaster",
      "com.cwan.pbor.reporting",
      "com.cwan.privatefund.watchlist",
      "com.cwan.pbor.fxrate",
      "com.cwan.privatefund.security.currency",
      "com.cwan.privatefund.document.model",
      "com.cwan.privatefund.document",
      "com.cwan.privatefund.fxrate.source",
      "com.cwan.pbor.aum"
    })
@EnableConfigurationProperties
@ConfigurationPropertiesScan("com.cwan.privatefund.config.properties")
public class LPxServiceApplication {
  public static final String REACTOR_NETTY_IO_WORKER_COUNT = "reactor.netty.ioWorkerCount";

  public static void main(String[] args) {
    Optional.ofNullable(System.getenv(REACTOR_NETTY_IO_WORKER_COUNT))
        .ifPresent(
            ioWorkerCount -> {
              if (StringUtils.isNotBlank(ioWorkerCount)) {
                System.setProperty(REACTOR_NETTY_IO_WORKER_COUNT, ioWorkerCount);
              }
            });
    SpringApplication.run(LPxServiceApplication.class);
  }
}
