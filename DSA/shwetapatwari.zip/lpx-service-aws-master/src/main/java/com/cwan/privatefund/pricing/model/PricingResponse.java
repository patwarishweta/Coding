package com.cwan.privatefund.pricing.model;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Map;

public class PricingResponse implements Serializable {
  @Serial private static final long serialVersionUID = 6167638846363409628L;
  public static final String DATE_FORMAT = "MM/dd/yyyy";
  private final Map<String, Map<Long, PricingData>> rawData;

  public PricingResponse() {
    this(Collections.emptyMap());
  }

  public PricingResponse(Map<String, Map<Long, PricingData>> rawData) {
    this.rawData = rawData;
  }

  public Map<String, Map<Long, PricingData>> getRawData() {
    return rawData;
  }

  public PricingData getPricingData(LocalDate date, Long securityId) {
    var stringDate = date.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
    return getPricingData(stringDate, securityId);
  }

  /**
   * @param date format MM/dd/yyyy
   * @param securityId
   * @return
   */
  public PricingData getPricingData(String date, Long securityId) {
    return rawData.containsKey(date) ? rawData.get(date).get(securityId) : null;
  }

  public Double getPrice(LocalDate date, Long securityId) {
    var data = getPricingData(date, securityId);
    return data == null ? null : data.getPrice();
  }
}
