package com.cwan.privatefund.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/** Utility for normalizing data objects through serialization processes. */
@Component
@RequiredArgsConstructor
public final class JsonNormalizationUtils {

  private final ObjectMapper objectMapper;

  /**
   * Normalizes a data object by re-serializing it.
   *
   * @param <T> data object's type
   * @param data object to be normalized
   * @param classType class of the data object
   * @return normalized data wrapped in a Mono
   */
  public <T> Mono<T> normalizeData(T data, Class<T> classType) {
    return Mono.fromCallable(() -> objectMapper.writeValueAsString(data))
        .flatMap(jsonData -> Mono.fromCallable(() -> objectMapper.readValue(jsonData, classType)))
        .onErrorResume(
            JsonProcessingException.class,
            e ->
                Mono.error(
                    new RuntimeException(
                        "Failed to normalize type: " + classType.getSimpleName(), e)));
  }
}
