package com.cwan.privatefund.capital.call.service;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.util.ExceptionUtils;
import com.cwan.privatefund.util.JsonNormalizationUtils;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * A service class that enriches capital call documents with additional account and security data.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallEnrichmentService {

  private final AccountService accountService;
  private final SecurityService securityService;
  private final CapitalCallPermissionService capitalCallPermissionService;
  private final JsonNormalizationUtils jsonNormalizationUtils;

  /**
   * Processes a batch of CapitalCallDocument entities and enriches each with additional data.
   *
   * @param capitalCallsBatch List of CapitalCallDocument entities to be enriched.
   * @param userEmail The email of the user for permission update.
   * @return a Flux of enriched CapitalCallDocument entities.
   */
  public Flux<CapitalCallDocument> enrichAndProcessBatchOfCapitalCalls(
      List<CapitalCallDocument> capitalCallsBatch, String userEmail) {
    log.info(
        "Enriching and processing a batch of {} capital calls for user {}",
        capitalCallsBatch.size(),
        userEmail);
    return Flux.fromIterable(capitalCallsBatch)
        .flatMap(capitalCall -> enrichCapitalCallWithData(capitalCall, userEmail))
        .doOnError(
            error ->
                log.error(
                    "Failed to process and enrich capital calls. Error: {}",
                    ExceptionUtils.getStackTraceAsString(error)))
        .doOnComplete(
            () ->
                log.debug(
                    "Successfully processed and enriched the batch of capital calls for user {}",
                    userEmail));
  }

  /**
   * Enriches the provided CapitalCallDocument with additional account and security data.
   *
   * @param capitalCall The CapitalCallDocument to be enriched.
   * @param userEmail The user's email to be used for updating permissions.
   * @return a Mono of enriched CapitalCallDocument.
   */
  public Mono<CapitalCallDocument> enrichCapitalCallWithData(
      CapitalCallDocument capitalCall, String userEmail) {
    return Mono.zip(
            addAccountDataToCapitalCall(capitalCall), addSecurityDataToCapitalCall(capitalCall))
        .flatMap(
            tuple -> {
              var enrichedCapitalCall =
                  capitalCall.toBuilder()
                      .account(tuple.getT1().account())
                      .security(tuple.getT2().security())
                      .build();
              return capitalCallPermissionService.updatePermissionBasedOnUserEmail(
                  enrichedCapitalCall, userEmail);
            })
        .doOnError(
            e ->
                log.error(
                    "Failed to enrich CapitalCallDocument with ID {}. Error: {}",
                    capitalCall.documentId(),
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  /**
   * Adds security data to the provided CapitalCallDocument instance.
   *
   * @param capitalCall the CapitalCallDocument instance
   * @return a Mono of CapitalCallDocument instance with added security data
   */
  private Mono<CapitalCallDocument> addSecurityDataToCapitalCall(CapitalCallDocument capitalCall) {
    if (Objects.isNull(capitalCall.security())
        || Objects.isNull(capitalCall.security().getSecurityId())
        || Objects.isNull(capitalCall.account())) {
      return Mono.just(capitalCall);
    }
    return securityService
        .getSecurity(
            capitalCall.account().getClientId(),
            capitalCall.account().getId(),
            capitalCall.security().getSecurityId())
        .flatMap(security -> jsonNormalizationUtils.normalizeData(security, Security.class))
        .map(normalizedSecurity -> capitalCall.toBuilder().security(normalizedSecurity).build())
        .onErrorResume(
            e -> {
              log.error(
                  "Error while fetching and normalizing security data for CapitalCallDocument with ID: {}. Error: {}",
                  capitalCall.documentId(),
                  ExceptionUtils.getStackTraceAsString(e));
              return Mono.just(capitalCall);
            });
  }

  /**
   * Adds account data to the provided CapitalCallDocument instance.
   *
   * @param capitalCall the CapitalCallDocument instance
   * @return a Mono of CapitalCallDocument instance with added account data
   */
  private Mono<CapitalCallDocument> addAccountDataToCapitalCall(CapitalCallDocument capitalCall) {
    if (Objects.isNull(capitalCall.account()) || Objects.isNull(capitalCall.account().getId())) {
      return Mono.just(capitalCall);
    }
    return accountService
        .getAccountWithClientData(capitalCall.account().getId())
        .flatMap(account -> jsonNormalizationUtils.normalizeData(account, Account.class))
        .map(normalizedAccount -> capitalCall.toBuilder().account(normalizedAccount).build())
        .onErrorResume(
            e -> {
              log.error(
                  "Error while fetching and normalizing account data for CapitalCallDocument with ID: {}. Error: {}",
                  capitalCall.documentId(),
                  ExceptionUtils.getStackTraceAsString(e));
              return Mono.just(capitalCall);
            });
  }
}
