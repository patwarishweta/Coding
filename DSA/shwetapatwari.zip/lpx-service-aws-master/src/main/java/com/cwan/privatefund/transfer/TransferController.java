package com.cwan.privatefund.transfer;

import com.cwan.lpx.domain.TransferRequest;
import com.cwan.privatefund.publisher.MessagePublisher;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "v1/transfers")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class TransferController {

  private final MessagePublisher<TransferRequest> transferMessagePublisher;

  public TransferController(MessagePublisher<TransferRequest> transferMessagePublisher) {
    this.transferMessagePublisher = transferMessagePublisher;
  }

  @PostMapping(value = "/create")
  @Operation(summary = "Submit create transfer job")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Submitted create transfer job successfully")
      })
  public ResponseEntity<String> createTransfer(
      @Parameter(description = "Transfer Request") @RequestBody TransferRequest request) {
    if (TransferRequestValidator.validateTransferRequestUnits(request)) {
      transferMessagePublisher.publishMessage(
          request,
          Map.of("messageGroupId", request.sourceAccountId() + "-" + request.securityId()),
          true);
      return ResponseEntity.ok("Create transfer job submitted successfully");
    } else {
      return ResponseEntity.badRequest().body("Destination Units sum greater than 1");
    }
  }
}
