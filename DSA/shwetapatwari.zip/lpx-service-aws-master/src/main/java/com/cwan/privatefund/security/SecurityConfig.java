package com.cwan.privatefund.security;

import com.cwan.privatefund.client.ClientRequest;
import com.cwan.privatefund.client.WebResponseMapper;
import com.cwan.privatefund.security.model.FieldsBySource;
import com.cwan.privatefund.security.model.SecurityRequest;
import com.cwan.privatefund.security.model.SecurityResponse;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

@Configuration
@Slf4j
public class SecurityConfig {

  @Value("${security.base.url}")
  private String securityWsBaseUrl;

  @Value("${security.cache.maxsize}")
  private Integer maxCacheSize;

  @Value("${business.ws.memory.maxsize}")
  private Integer maxInMemorySize;

  @Value("${security.cache.timeout.hours}")
  private Integer cacheDurationHrs;

  @Value("${security.model.format.date}")
  private String basicDateFormat;

  @Value("${security.model.format.datetime}")
  private String dateFormatWithTimezone;

  @Value("#{'${security.fields}'.split(',')}")
  private List<String> securityFields;

  @Value("#{'${fund.fields}'.split(',')}")
  private List<String> fundFields;

  @Value("#{'${securitytypedata.fields}'.split(',')}")
  private List<String> securitytypedataFields;

  @Value("#{'${derived.fields}'.split(',')}")
  private List<String> derivedFields;

  @Bean(value = "securityDateFormat")
  DateFormat securityDateFormat() {
    return new SimpleDateFormat(basicDateFormat);
  }

  @Bean(value = "securityDateTimeFormat")
  DateFormat securityDateTimeFormat() {
    return new SimpleDateFormat(dateFormatWithTimezone);
  }

  @Bean(value = "securityFieldsBySource")
  List<FieldsBySource> securityFieldsBySource() {
    return List.of(
        new FieldsBySource("SecurityMaster", securityFields),
        new FieldsBySource("FundMaster", fundFields),
        new FieldsBySource("SecurityTypeData", securitytypedataFields),
        new FieldsBySource("derived", derivedFields));
  }

  @Bean(value = "securityRequestBuilder")
  SecurityRequest.SecurityRequestBuilder securityRequestBuilder(
      DateFormat securityDateFormat,
      DateFormat securityDateTimeFormat,
      List<FieldsBySource> securityFieldsBySource) {
    return SecurityRequest.builder()
        .date(securityDateFormat.format(new Date()))
        .fieldsBySource(securityFieldsBySource)
        .asOfDatetime(securityDateTimeFormat.format(new Date()));
  }

  @Bean(value = "securityWebClient")
  WebClient securityWebClient(ReactorClientHttpConnector reactorClientHttpConnector) {
    return WebClient.builder()
        .baseUrl(securityWsBaseUrl)
        .filter(
            (request, next) ->
                next.exchange(request).retryWhen(Retry.backoff(3, Duration.ofSeconds(5))))
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(maxInMemorySize))
                .build())
        .filter(ClientRequest.logRequest(SecurityClient.class.getName() + ".START_TIME"))
        .clientConnector(reactorClientHttpConnector)
        .build();
  }

  @Bean(value = "securitiesCache")
  Cache<Long, SecurityResponse> securitiesCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "securityResponseMapper")
  WebResponseMapper<SecurityException> securityResponseMapper() {
    return new WebResponseMapper<>() {
      @Override
      protected SecurityException getException(String msg) {
        return new SecurityException(msg);
      }
    };
  }
}
