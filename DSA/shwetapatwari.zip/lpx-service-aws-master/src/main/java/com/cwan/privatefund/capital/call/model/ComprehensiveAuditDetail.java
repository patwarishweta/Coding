package com.cwan.privatefund.capital.call.model;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallPermissions;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUserAction;
import com.cwan.lpx.domain.Security;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Collectors;
import lombok.Builder;
import reactor.core.publisher.Flux;

@Builder(toBuilder = true)
public record ComprehensiveAuditDetail(
    Long documentId,
    String documentName,
    BigDecimal paymentAmount,
    BigDecimal netAmount,
    Integer daysAging,
    CapitalCallBankDetail bankDetail,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate callReceivedDate,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate dueDate,
    Security security,
    Account account,
    String currency,
    CapitalCallStatus status,
    CapitalCallPermissions permissions,
    String comment,
    CapitalCallUserAction wireCheckAction,
    CapitalCallUserAction initialReviewAction,
    CapitalCallUserAction finalReviewAction,
    CapitalCallAudit audit) {

  /**
   * Transforms a given CapitalCallDocument into its ComprehensiveAuditDetail representation.
   *
   * @param document the CapitalCallDocument to be transformed.
   * @return a Flux stream of ComprehensiveAuditDetail objects.
   */
  public static Flux<ComprehensiveAuditDetail> transformDocumentToAuditDetail(
      CapitalCallDocument document) {
    return Flux.fromIterable(
        document.audit().stream()
            .map(
                capitalCallAudit ->
                    ComprehensiveAuditDetail.builder()
                        .documentId(document.documentId())
                        .documentName(document.documentName())
                        .paymentAmount(document.paymentAmount())
                        .netAmount(document.netAmount())
                        .daysAging(document.daysAging())
                        .bankDetail(document.bankDetail())
                        .callReceivedDate(document.callReceivedDate())
                        .dueDate(document.dueDate())
                        .security(document.security())
                        .account(document.account())
                        .currency(document.currency())
                        .status(document.status())
                        .permissions(document.permissions())
                        .comment(document.comment())
                        .wireCheckAction(document.wireCheckAction())
                        .initialReviewAction(document.initialReviewAction())
                        .finalReviewAction(document.finalReviewAction())
                        .audit(capitalCallAudit)
                        .build())
            .collect(Collectors.toCollection(ArrayList::new)));
  }
}
