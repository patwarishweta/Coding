package com.cwan.privatefund.document.controller;

import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.document.CwanGptDocumentRequest;
import com.cwan.privatefund.document.DocumentRequest;
import com.cwan.privatefund.document.LpxDocumentService;
import com.cwan.privatefund.document.dto.DocumentFilterCriteria;
import com.cwan.privatefund.document.model.DocumentAudit;
import com.cwan.privatefund.publisher.MessagePublisher;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping(value = "v1/documents")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
@Validated
@Tag(name = "Document Management", description = "APIs for managing documents")
@RequiredArgsConstructor
@Slf4j
public class DocumentController {

  private final LpxDocumentService lpxDocumentService;
  private final AccountService accountService;
  private final MessagePublisher<CwanGptDocumentRequest> cwanGptDocumentMessagePublisher;

  @GetMapping(value = "/{documentId}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get document by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Document fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Document> getDocumentByDocumentId(
      @Parameter(description = "Document Id") @PathVariable Long documentId) {
    return lpxDocumentService.getDocumentById(documentId);
  }

  @DeleteMapping(value = "/{documentId}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get document by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Document disabled successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<Document> deleteDocumentByDocumentId(
      @Parameter(description = "Document Id") @PathVariable Long documentId) {
    log.info("DELETING DOCUMENT {}", documentId);
    return lpxDocumentService
        .deleteDocumentByDocId(documentId)
        .onErrorMap(
            throwable ->
                new ResponseStatusException(HttpStatus.BAD_REQUEST, throwable.getMessage()));
  }

  @DeleteMapping(value = "/missing/alert/config/delete/client/{clientId}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @Operation(summary = "Delete Alerts by clientId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "No Content - Alert Deleted Successfully",
            content = @Content)
      })
  public Mono<Void> deleteMissingDocumentsAlertByClientId(
      @Parameter(description = "clientId") @PathVariable Long clientId) {
    log.info("DELETING ALERTS FOR CLIENT ID: {}", clientId);
    return lpxDocumentService.deleteMissingDocumentAlertsByClientId(clientId);
  }

  @DeleteMapping(
      value = "/missing/expectation/config/delete/security/{securityId}/type/{documentType}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @Operation(summary = "Delete Missing Expectations by securityId and DocumentType")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "No Content - Expectation Deleted Successfully",
            content = @Content)
      })
  public Mono<Void> deleteMissingDocumentsExpectationsBySecurityIdAndDocumentType(
      @Parameter(description = "securityId") @PathVariable Long securityId,
      @Parameter(description = "documentType") @PathVariable String documentType) {
    log.info(
        "DELETING EXPECTATIONS FOR SECURITY ID: {} AND DOCUMENT TYPE {}", securityId, documentType);
    return lpxDocumentService.deleteMissingDocumentExpectationsBySecurityIdAndDocumentType(
        securityId, documentType);
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add documents")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Add Document successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Document.class))
            })
      })
  public Flux<Document> addDocuments(
      @Parameter(description = "Document Data") @RequestBody DocumentRequest request) {
    return lpxDocumentService.addDocuments(request.getDocuments());
  }

  @PostMapping(value = "/files", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Upload file")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Uploaded file successfully",
            content = {@Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)})
      })
  public Flux<String> uploadFile(@RequestPart(name = "file") Flux<FilePart> file) {
    return lpxDocumentService.uploadFile(file);
  }

  @GetMapping(value = "/signedUrl/{documentId}")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get document signed Url")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Document signed url fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Mono<String> getSignedUrlByDocumentId(
      @Parameter(description = "Document Id") @PathVariable Long documentId) {
    return lpxDocumentService.getSignedUrlByDocId(documentId);
  }

  @PutMapping
  @Operation(summary = "Update documents")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Updated Document successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Document.class))
            })
      })
  public Flux<Document> updateDocuments(
      @Parameter(description = "Document Data") @RequestBody DocumentRequest request) {
    return lpxDocumentService.updateDocumentInfo(request.getDocuments());
  }

  @PostMapping(value = "/cwan-gpt/upload")
  @Operation(summary = "Upload documents for GPT to chat")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Upload Document successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public void uploadDocumentsForClearwaterGPT(
      @Parameter(description = "Document Data") @RequestBody CwanGptDocumentRequest request) {
    // sends message to SNS topic to trigger the lambda
    cwanGptDocumentMessagePublisher.publishMessage(request, Map.of(), false);
  }

  @GetMapping(value = "/received")
  @Operation(summary = "Get documents for specific user between start and end received date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Retrieved Document successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Document.class))
            })
      })
  public Flux<Document> getUserDocumentsByReceivedDate(
      @Parameter(description = "User Id") @RequestParam Integer userId,
      @Parameter(description = "Received Begin Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate beginDate,
      @Parameter(description = "Received End Date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate endDate,
      @Parameter(description = "Document Type") @RequestParam(required = false) String type,
      @Parameter(description = "Include Demo Accounts")
          @RequestParam(required = false, defaultValue = "true")
          boolean includeDemoAccounts) {
    return accountService
        .retrieveUserAccessibleAccountIdsInBatches(userId, 2000)
        .parallel()
        .runOn(Schedulers.parallel())
        .flatMap(
            accountIds ->
                lpxDocumentService.getDocumentsByAccountsAndReceivedDateBetweenAndType(
                    Set.copyOf(accountIds), beginDate, endDate, type, includeDemoAccounts))
        .sequential();
  }

  @GetMapping(value = "/document-date", produces = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      summary = "Get documents for specific user between start and end received document date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Documents retrieved successfully",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    array = @ArraySchema(schema = @Schema(implementation = Document.class))))
      })
  public Flux<Document> getUserDocumentsByDocumentDate(
      @Parameter(description = "Document Begin Date")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          @NotNull(message = "Begin date is required")
          LocalDate beginDate,
      @Parameter(description = "Document End Date")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          @NotNull(message = "End date is required")
          LocalDate endDate) {
    return lpxDocumentService.getAuthorizedDocumentsInDateRange(beginDate, endDate);
  }

  @PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
  @Operation(summary = "Search for active documents for specific accounts within a date range")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Documents retrieved successfully",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    array = @ArraySchema(schema = @Schema(implementation = Document.class))))
      })
  public Flux<Document> getDocumentsByAccountsAndDocumentDate(
      @Valid @RequestBody DocumentFilterCriteria request) {
    log.info("Fetching documents for request: {}", request);
    return lpxDocumentService
        .getAuthorizedDocumentsInDateRange(
            request.accountIds(), request.securityIds(), request.beginDate(), request.endDate())
        .doOnError(error -> log.error("Error fetching documents: {}", error.getMessage()));
  }

  @GetMapping(value = "/period-end")
  @Operation(summary = "Get documents for specific user on period end date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Retrieved Document successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Document.class))
            })
      })
  public Flux<Document> getUserDocumentsByPeriodEndDate(
      @Parameter(description = "User Id") @RequestParam Integer userId,
      @Parameter(description = "Period Begin Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate beginDate,
      @Parameter(description = "Period End Date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate endDate) {
    return accountService
        .retrieveUserAccessibleAccountIds(userId)
        .flatMapMany(
            accountIds ->
                lpxDocumentService.getDocumentsByAccountsAndPeriodEndDateBetween(
                    accountIds, beginDate, endDate));
  }

  @GetMapping(value = "/cash-movement")
  @Operation(summary = "Get documents for specific user on cash movement date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Retrieved Document successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Document.class))
            })
      })
  public Flux<Document> getUserDocumentsByCashMovementDate(
      @Parameter(description = "User Id") @RequestParam Integer userId,
      @Parameter(description = "Cash Movement Begin Date")
          @RequestParam
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate beginDate,
      @Parameter(description = "Cash Movement End Date")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate endDate,
      @Parameter(description = "Document Type") @RequestParam(required = false) String type) {
    return accountService
        .retrieveUserAccessibleAccountIdsInBatches(userId, 2000)
        .parallel()
        .runOn(Schedulers.parallel())
        .flatMap(
            accountIds ->
                lpxDocumentService.getDocumentsByAccountsAndCashMvmtDateBetweenAndType(
                    Set.copyOf(accountIds), beginDate, endDate, type))
        .sequential();
  }

  @GetMapping(value = "/zip", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public ResponseEntity<ByteArrayResource> getZipFiles(@RequestParam Set<Long> documentIds)
      throws IOException {
    return getByteArrayResourceResponseEntity(documentIds);
  }

  @PostMapping(
      value = "/zip",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public Mono<ResponseEntity<ByteArrayResource>> getZipFilesPost(
      @RequestBody Set<Long> documentIds) {
    if ((documentIds == null) || documentIds.isEmpty()) {
      return Mono.just(ResponseEntity.badRequest().build());
    }
    return Mono.fromCallable(() -> getByteArrayResourceResponseEntity(documentIds))
        .subscribeOn(Schedulers.parallel());
  }

  private ResponseEntity<ByteArrayResource> getByteArrayResourceResponseEntity(
      @RequestBody Set<Long> documentIds) throws IOException {
    var zipBytes = lpxDocumentService.getZipFileFromDocumentIds(documentIds);
    var resource = new ByteArrayResource(zipBytes);
    var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    headers.setContentDispositionFormData("attachment", "Documents.zip");
    return ResponseEntity.ok().headers(headers).contentLength(zipBytes.length).body(resource);
  }

  @GetMapping(value = "/missing/state")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get document missing status")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Document missing status fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<MissingDocuments> getMissingDocuments(
      @Parameter(description = "Account Id") @RequestParam Long accountId) {
    return lpxDocumentService.getMissingDocuments(accountId);
  }

  @GetMapping(value = "/missing/alerts/all")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get stored Alerts for missing docs")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Alerts for missing docs fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<MissingDocumentAlertConfig> getDocumentAlerts() {
    return lpxDocumentService.getMissingDocumentsAlerts();
  }

  @GetMapping(value = "/missing/expectations/all")
  @ResponseStatus(HttpStatus.OK)
  @Operation(summary = "Get Expectations for missing docs")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Expectations for missing docs fetched successfully",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<MissingDocumentExpectationsConfig> getDocumentExpectations() {
    return lpxDocumentService.getMissingDocumentsExpectations();
  }

  @PostMapping(value = "/missing/alerts/add")
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add missing documents alert config")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Add missing documents alert config successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = MissingDocumentAlertConfig.class))
            })
      })
  public Flux<MissingDocumentAlertConfig> saveMissingDocumentAlerts(
      @Parameter(description = "Document Alert Config Data") @RequestBody
          MissingDocumentAlertConfig request) {
    return lpxDocumentService.saveMissingDocumentAlerts(request);
  }

  @PostMapping(value = "/missing/expectations/add")
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add missing documents expectation config")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Add missing documents expectation config successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = MissingDocumentExpectationsConfig.class))
            })
      })
  public Flux<MissingDocumentExpectationsConfig> saveMissingDocumentExpectationsConfigs(
      @Parameter(description = "Document Expectation Config Data") @RequestBody
          MissingDocumentExpectationsConfig request) {
    return lpxDocumentService.saveMissingDocumentExpectationsConfigs(request);
  }

  @GetMapping(value = "/audit")
  @Operation(summary = "get document audit by account ids, begin date end date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DocumentAudit.class))
            })
      })
  public Flux<DocumentAudit> getAuditDocument(
      @RequestParam Set<Long> accountIds,
      @RequestParam(required = false, defaultValue = "#{T(java.time.LocalDate).of(2024,7,7)}")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate beginDate,
      @RequestParam(required = false, defaultValue = "#{T(java.time.LocalDate).now()}")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate endDate) {
    return lpxDocumentService.getAllDocumentsByAccountAndDateRange(accountIds, beginDate, endDate);
  }
}
