package com.cwan.privatefund.balance;

import com.cwan.privatefund.balance.model.LmcBalance;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/balances/combined")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class LmcBalanceController {

  private final LpxCombinedBalanceService lpxBalanceService;

  LmcBalanceController(LpxCombinedBalanceService lpxBalanceService) {
    this.lpxBalanceService = lpxBalanceService;
  }

  @RequestMapping(value = "/account", method = RequestMethod.GET)
  @Operation(summary = "get account balances by account id, entry date, and knowledge date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LmcBalance.class))
            })
      })
  public Flux<LmcBalance> getAccountBalances(
      @RequestParam("accountId") Long accountId,
      @RequestParam("entryDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate entryDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    return lpxBalanceService.getAccountBalances(accountId, entryDate, knowledgeDate);
  }
}
