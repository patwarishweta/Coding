package com.cwan.privatefund.calculated.model;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class AccountingCalculatedBalance {

  private String source;
  private Security security;
  private Account account;
  private String currency;
  private Double navImpact;
  private Double fundedCommitmentImpact;
  private Double unfundedCommitmentImpact;
  private Double recallableImpact;
  private Double totalCommitment;
  private Double totalContributions;
  private Double totalDistributions;
}
