package com.cwan.privatefund.canoeFundMapping.model;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class CanoeFundMappingAccountResponse implements Serializable {

  @Serial private static final long serialVersionUID = -513605411193681404L;
  private Long accountId;
  private String accountName;
}
