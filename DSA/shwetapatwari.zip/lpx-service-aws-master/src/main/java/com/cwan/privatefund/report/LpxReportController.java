package com.cwan.privatefund.report;

import com.cwan.pbor.reporting.LpxReportEntity;
import com.cwan.pbor.reporting.models.CalculatedReportedBalancesReportEntry;
import com.cwan.pbor.reporting.models.DuplicateTransactionReportEntry;
import com.cwan.pbor.reporting.models.LpxVsFrontOfficeTransactionEntry;
import com.cwan.privatefund.report.LpxReportService.CommitmentManagerEntry;
import com.cwan.privatefund.report.LpxReportService.CoreAccountingEntryRequest;
import com.cwan.privatefund.report.LpxReportService.CoreTransactionEntryRequest;
import com.cwan.privatefund.report.LpxReportService.DuplicateTransactionEntryRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping(value = "v1/report")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR")
    })
public class LpxReportController {
  private final LpxReportService lpxReportService;

  public LpxReportController(LpxReportService lpxReportService) {
    this.lpxReportService = lpxReportService;
  }

  @RequestMapping(value = "/duplicate-transactions", method = RequestMethod.GET)
  @Operation(summary = "Retrieve latest report for given Report Type and Account Id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DuplicateTransactionReportEntry.class))
            })
      })
  public List<DuplicateTransactionReportEntry> getDuplicateTransactionReport(
      @Parameter(description = "AccountId that is requesting information") @RequestParam()
          Long accountId) {
    return lpxReportService.getMostRecentDuplicateTransactionReport(accountId);
  }

  @RequestMapping(value = "/commitment-manager", method = RequestMethod.GET)
  @Operation(summary = "Retrieve last commitment state")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = DuplicateTransactionReportEntry.class))
            })
      })
  public List<CommitmentManagerEntry> getCommitmentManager(
      @Parameter(description = "AccountId that is requesting information")
          @RequestParam("accountId")
          Long accountId,
      @Parameter(description = "BeginDate that is requesting information")
          @RequestParam("beginDate")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate beginDate,
      @Parameter(description = "EndDate that is requesting information")
          @RequestParam("endDate")
          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate endDate) {
    return lpxReportService.getCommitmentManagerReport(accountId, beginDate, endDate);
  }

  @RequestMapping(value = "/core-transactions", method = RequestMethod.GET)
  @Operation(summary = "Retrieve latest report for given Report Type and Account Id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LpxVsFrontOfficeTransactionEntry.class))
            })
      })
  public List<LpxVsFrontOfficeTransactionEntry> getMostRecentFrontOfficeAccountingReport(
      @Parameter(description = "AccountId that is requesting information") @RequestParam()
          Long accountId) {
    return lpxReportService.getMostRecentFrontOfficeAccountingReport(accountId);
  }

  @RequestMapping(value = "/core-accounting", method = RequestMethod.GET)
  @Operation(summary = "Retrieve latest report for given Report Type and Account Id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LpxVsFrontOfficeTransactionEntry.class))
            })
      })
  public List<CalculatedReportedBalancesReportEntry> getMostRecentCalculatedBalanceReport(
      @Parameter(description = "AccountId that is requesting information") @RequestParam()
          Long accountId) {
    return lpxReportService.getMostRecentCoreAccountingReport(accountId);
  }

  @PostMapping(value = "/core-transactions/add")
  @Operation(summary = "Inserts a new entry into the core accounting report")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LpxVsFrontOfficeTransactionEntry.class))
            })
      })
  public List<LpxReportEntity> insertCoreTransactionReport(
      @Parameter(description = "Accounting Diff Data") @RequestBody
          CoreTransactionEntryRequest coreTransactionEntryRequest)
      throws JsonProcessingException {
    return lpxReportService.save(coreTransactionEntryRequest);
  }

  @PostMapping(value = "/core-accounting/add")
  @Operation(summary = "Inserts a new entry into the core accounting report")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LpxVsFrontOfficeTransactionEntry.class))
            })
      })
  public List<LpxReportEntity> insertCoreAccountingEntry(
      @Parameter(description = "Accounting Diff Data") @RequestBody
          CoreAccountingEntryRequest coreAccountingEntryRequest)
      throws JsonProcessingException {
    return lpxReportService.save(coreAccountingEntryRequest);
  }

  @PostMapping(value = "/duplicate-transactions/add")
  @Operation(summary = "Inserts a new duplicate transaction entry")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = LpxVsFrontOfficeTransactionEntry.class))
            })
      })
  public List<LpxReportEntity> insertDuplicateTransactionEntry(
      @Parameter(description = "Insert Duplicate Transaction entry") @RequestBody
          DuplicateTransactionEntryRequest duplicateTransactionEntryRequest)
      throws JsonProcessingException {
    return lpxReportService.save(duplicateTransactionEntryRequest);
  }
}
