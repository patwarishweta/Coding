package com.cwan.privatefund.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Configuration for enabling task scheduling in the application. This configuration class is
 * responsible for enabling the scheduling of tasks within the application. The scheduling is
 * enabled conditionally based on the active profile. Scheduling will only be enabled when the
 * active profile is not one of "dev", "ci", or "local". This is to prevent scheduled tasks from
 * running during development, continuous integration, or local testing, respectively.
 */
@Configuration
@EnableScheduling
@Profile({"!dev", "!ci", "!local"})
public class LPxSchedulingConfig {
  // The class body is intentionally left empty.
  // Its purpose is to conditionally enable scheduling based on the active profile.
}
