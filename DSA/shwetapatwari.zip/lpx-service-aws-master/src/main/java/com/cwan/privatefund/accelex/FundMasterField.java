package com.cwan.privatefund.accelex;

import com.ca.tabular.WebService;
import com.ca.tabular.field.DataType;
import com.ca.tabular.field.EnumReference;
import com.ca.tabular.field.FieldLink;
import com.ca.tabular.field.FieldType;
import com.cwan.lpx.client.tabular.LPField;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.privatefund.accelex.AccelexService.FundMasterKey;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import org.jetbrains.annotations.NotNull;

public enum FundMasterField implements LPField {
  ID(1, "id", "id", DataType.LONG, FieldLink.NONE, null, b -> b.getValue().getId()),
  NAME(2, "name", "name", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getName()),
  CIK(3, "cik", "cik", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getCik()),
  EIN(4, "ein", "ein", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getEin()),
  SEC_IDENTIFIER(
      5,
      "secIdentifier",
      "secIdentifier",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSecIdentifier()),
  PARTNERSHIP_TYPE(
      6,
      "partnershipType",
      "partnershipType",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getPartnershipType()),
  TYPE(7, "type", "type", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getType()),
  SUB_TYPE(
      8,
      "subType",
      "subType",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSubType()),
  STATUS(
      9, "status", "status", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getStatus()),
  INITIAL_CLOSING_DATE(
      10,
      "initialClosingDate",
      "initialClosingDate",
      DataType.DATE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getInitialClosingDate()),
  FINAL_CLOSING_DATE(
      11,
      "finalClosingDate",
      "finalClosingDate",
      DataType.DATE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFinalClosingDate()),
  SUBSEQUENT_CLOSING_RATE(
      12,
      "subsequentClosingRate",
      "subsequentClosingRate",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSubsequentClosingRate()),
  INITIAL_INVESTMENT_DATE(
      13,
      "initialInvestmentDate",
      "initialInvestmentDate",
      DataType.DATE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getInitialInvestmentDate()),
  SECTOR1(
      14,
      "sector1",
      "sector1",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSector1()),
  SECTOR2(
      15,
      "sector2",
      "sector2",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSector2()),
  SECTOR3(
      16,
      "sector3",
      "sector3",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSector3()),
  GP_NAME(
      17, "gpName", "gpName", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getGpName()),
  GP_LEI(18, "gpLei", "gpLei", DataType.STRING, FieldLink.NONE, null, b -> b.getValue().getGpLei()),
  GP_MANAGER(
      19,
      "gpManager",
      "gpManager",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getGpManager()),
  FUND_NUMBER_SERIES(
      20,
      "fundNumberSeries",
      "fundNumberSeries",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFundNumberSeries()),
  FUND_SERIES_ID(
      21,
      "fundSeriesId",
      "fundSeriesId",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFundSeriesId()),
  FUND_SERIES_NAME(
      22,
      "fundSeriesName",
      "fundSeriesName",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFundSeriesName()),
  CAPITAL_COMMITMENT(
      23,
      "capitalCommitment",
      "capitalCommitment",
      DataType.LONG,
      FieldLink.NONE,
      null,
      b -> b.getValue().getCapitalCommitment()),
  COMMITMENT_PERIOD(
      24,
      "commitmentPeriod",
      "commitmentPeriod",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getCommitmentPeriod()),
  WATERFALL_TYPE(
      25,
      "waterfallType",
      "waterfallType",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getWaterfallType()),
  CARRIED_INTEREST(
      26,
      "carriedInterest",
      "carriedInterest",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getCarriedInterest()),
  HURDLE_RATE(
      27,
      "hurdleRate",
      "hurdleRate",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getHurdleRate()),
  INVESTMENT_PERIOD(
      28,
      "investmentPeriod",
      "investmentPeriod",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getInvestmentPeriod()),
  INVESTMENT_PERIOD_FOLLOW_ON(
      29,
      "investmentPeriodFollowOn",
      "investmentPeriodFollowOn",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getInvestmentPeriodFollowOn()),
  TERM_OF_FUND(
      30,
      "termOfFund",
      "termOfFund",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTermOfFund()),
  TERM_EXTENSIONS(
      31,
      "termExtensions",
      "termExtensions",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTermExtensions()),
  MAX_NUMBER_OF_TERM_EXTENSIONS(
      32,
      "maxNumberOfTermExtensions",
      "maxNumberOfTermExtensions",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getMaxNumberOfTermExtensions()),
  GP_CATCH_UP(
      33,
      "gpCatchUp",
      "gpCatchUp",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getGpCatchUp()),
  GP_EQUITY_CONTRIBUTION(
      34,
      "gpEquityContribution",
      "gpEquityContribution",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getGpEquityContribution()),
  PROPERTY_DETAIL(
      35,
      "propertyDetail",
      "propertyDetail",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getPropertyDetail()),
  TERMINATION_DATE(
      36,
      "terminationDate",
      "terminationDate",
      DataType.DATE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTerminationDate()),
  FINAL_EXIT_DATE(
      37,
      "finalExitDate",
      "finalExitDate",
      DataType.DATE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFinalExitDate()),
  REPORTING_FREQUENCY(
      38,
      "reportingFrequency",
      "reportingFrequency",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getReportingFrequency()),
  ASC810(39, "asc810", "asc810", DataType.INT, FieldLink.NONE, null, b -> b.getValue().getAsc810()),
  TOTAL_FUND_SIZE(
      40,
      "totalFundSize",
      "totalFundSize",
      DataType.LONG,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getTotalFundSize() != null
              ? b.getValue().getTotalFundSize() * 1000000
              : null),
  REINVESTMENT_PERIOD(
      41,
      "reinvestmentPeriod",
      "reinvestmentPeriod",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getReinvestmentPeriod()),
  LP_GIVEBACK(
      42,
      "lpGiveback",
      "lpGiveback",
      DataType.BOOLEAN,
      FieldLink.NONE,
      null,
      b -> b.getValue().getLpGiveback()),
  MANAGEMENT_FEES(
      43,
      "managementFees",
      "managementFees",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getManagementFees()),
  MANAGEMENT_FEES_DURING_COMMITMENT_PERIOD(
      44,
      "managementFeesDuringCommitmentPeriod",
      "managementFeesDuringCommitmentPeriod",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getManagementFeesDuringCommitmentPeriod()),
  MANAGEMENT_FEES_AFTER_COMMITMENT_PERIOD(
      45,
      "managementFeesAfterCommitmentPeriod",
      "managementFeesAfterCommitmentPeriod",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getManagementFeesAfterCommitmentPeriod()),
  CLAWBACK(
      46,
      "clawback",
      "clawback",
      DataType.BOOLEAN,
      FieldLink.NONE,
      null,
      b -> b.getValue().getClawback()),
  GEOGRAPHY(
      47,
      "geography",
      "geography",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getGeography()),
  MIN_INVESTMENT_OF_FUND(
      48,
      "minInvestmentOfFund",
      "minInvestmentOfFund",
      DataType.LONG,
      FieldLink.NONE,
      null,
      b -> b.getValue().getMinInvestmentOfFund()),
  INVESTMENT_TYPES(
      49,
      "investmentTypes",
      "investmentTypes",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getInvestmentTypes()),
  SECTOR_CONCENTRATION_RESTRICTIONS(
      50,
      "sectorConcentrationRestrictions",
      "sectorConcentrationRestrictions",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getSectorConcentrationRestrictions()),
  PREFERRED_RETURN(
      51,
      "preferredReturn",
      "preferredReturn",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getPreferredReturn()),
  DRY_POWDER(
      52,
      "dryPowder",
      "dryPowder",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getDryPowderMn() != null ? b.getValue().getDryPowderMn() * 1000000 : null),
  DRY_POWDER_AS_AT_DATE(
      53,
      "dryPowderAsAtDate",
      "dryPowderAsAtDate",
      DataType.DATE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getDryPowderAsAtDate()),
  FINAL_CLOSE_SIZE(
      54,
      "finalCloseSize",
      "finalCloseSize",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFinalCloseSize()),
  HARD_CAP_USD(
      55,
      "hardCapUsd",
      "hardCapUsd",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getHardCapUsdMn() != null ? b.getValue().getHardCapUsdMn() * 1000000 : null),
  INITIAL_TARGET_USD(
      56,
      "initialTargetUsd",
      "initialTargetUsd",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getInitialTargetUsdMn() != null
              ? b.getValue().getInitialTargetUsdMn() * 1000000
              : null),
  NUM_LPS_MAX(
      57,
      "numLpsMax",
      "numLpsMax",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getNumLpsMax()),
  NUM_LPS_MIN(
      58,
      "numLpsMin",
      "numLpsMin",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getNumLpsMin()),
  TARGET_IRR_GROSS_MAX(
      59,
      "targetIrrGrossMax",
      "targetIrrGrossMax",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTargetIrrGrossMax()),
  TARGET_IRR_GROSS_MIN(
      60,
      "targetIrrGrossMin",
      "targetIrrGrossMin",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTargetIrrGrossMin()),
  TARGET_IRR_NET_MAX(
      61,
      "targetIrrNetMax",
      "targetIrrNetMax",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTargetIrrNetMax()),
  TARGET_IRR_NET_MIN(
      62,
      "targetIrrNetMin",
      "targetIrrNetMin",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getValue().getTargetIrrNetMin()),
  TARGET_SIZE_CURR(
      63,
      "targetSizeCurr",
      "targetSizeCurr",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getTargetSizeCurrMn() != null
              ? b.getValue().getTargetSizeCurrMn() * 1000000
              : null),
  TARGET_SIZE_EUR(
      64,
      "targetSizeEur",
      "targetSizeEur",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getTargetSizeEurMn() != null
              ? b.getValue().getTargetSizeEurMn() * 1000000
              : null),
  TARGET_SIZE_USD(
      65,
      "targetSizeUsd",
      "targetSizeUsd",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getTargetSizeUsdMn() != null
              ? b.getValue().getTargetSizeUsdMn() * 1000000
              : null),
  UNREALISED_VALUE(
      66,
      "unrealisedValue",
      "unrealisedValue",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b ->
          b.getValue().getUnrealisedValueMn() != null
              ? b.getValue().getUnrealisedValueMn() * 1000000
              : null),
  CARRIED_INTEREST_BASIS(
      67,
      "carriedInterestBasis",
      "carriedInterestBasis",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getCarriedInterestBasis()),
  AUDITOR(
      68,
      "auditor",
      "auditor",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getAuditor()),
  ADMINISTRATOR(
      69,
      "administrator",
      "administrator",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getAdministrator()),
  CUSTODIAN(
      70,
      "custodian",
      "custodian",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getCustodian()),
  OVERVIEW(
      71,
      "overview",
      "overview",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getOverview()),
  PREQIN_FUND_ID(
      72,
      "preqinFundId",
      "preqinFundId",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getPreqinFundId()),
  VINTAGE_YEAR(
      73,
      "vintageYear",
      "vintageYear",
      DataType.INT,
      FieldLink.NONE,
      null,
      b -> b.getValue().getVintageYear()),
  GP_PORTAL_URL(
      74,
      "gpPortalUrl",
      "gpPortalUrl",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getGpPortalUrl()),
  DOCUMENT_FREQUENCY(
      75,
      "documentFrequency",
      "documentFrequency",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getDocumentFrequency()),
  CLEARWATER_ACCOUNT_ID(
      76,
      "Clearwater Account Id",
      "Clearwater Account Id",
      DataType.LONG,
      FieldLink.NONE,
      null,
      b -> b.getKey().lpIdentifier().accountId()),
  CLEARWATER_SECURITY_ID(
      77,
      "Clearwater Security Id",
      "Clearwater Security Id",
      DataType.LONG,
      FieldLink.NONE,
      null,
      b -> b.getKey().lpIdentifier().securityId()),
  COUNTRY_OF_DOMICILE(
      78,
      "country",
      "Fund country of domicile",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getCountryOfDomicile()),
  FUND_CURRENCY(
      79,
      "currency",
      "Fund currency",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getValue().getFundCurrency()),
  CLEARWATER_CLIENT_NAME(
      80,
      "Clearwater Client Name",
      "Clearwater Client Name",
      DataType.STRING,
      FieldLink.NONE,
      null,
      b -> b.getKey().clientName()),
  COMMITMENT_SIZE(
      81,
      "commitment_size",
      "Total Size of Commitment",
      DataType.DOUBLE,
      FieldLink.NONE,
      null,
      b -> b.getKey().totalCommitment());

  private final int id;
  private final String name;
  private final String definition;
  private final DataType dataType;
  private final FieldLink fieldLink;
  private final EnumReference enumReference;
  private final Function<Map.Entry<FundMasterKey, FundMasterEntity>, ?> extractor;
  private static final Map<Integer, FundMasterField> ID_TO_FUND_MASTER_FIELD = new HashMap<>();

  FundMasterField(
      int id,
      String name,
      String definition,
      DataType dataType,
      FieldLink fieldLink,
      EnumReference enumReference,
      Function<Map.Entry<FundMasterKey, FundMasterEntity>, ?> extractor) {
    this.id = id;
    this.name = name;
    this.definition = definition;
    this.dataType = dataType;
    this.fieldLink = fieldLink;
    this.enumReference = enumReference;
    this.extractor = extractor;
  }

  @Override
  public EnumReference getEnumReference() {
    return enumReference;
  }

  @Override
  public int getId() {
    return id;
  }

  @Override
  public DataType getDataType() {
    return dataType;
  }

  @Override
  public FieldType getFieldType() {
    return FieldType.DESCRIPTIVE;
  }

  @Override
  public WebService getWebService() {
    return WebService.LPX_SERVICE_BALANCE;
  }

  @Override
  public FieldLink getFieldLink() {
    return fieldLink;
  }

  @Override
  public String getColumnName() {
    return definition;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public Object apply(Object o) {
    return extractor.apply((Map.Entry<FundMasterKey, FundMasterEntity>) o);
  }

  @NotNull
  @Override
  public Function andThen(@NotNull Function after) {
    return LPField.super.andThen(after);
  }

  @NotNull
  @Override
  public Function compose(@NotNull Function before) {
    return LPField.super.compose(before);
  }
}
