package com.cwan.privatefund.issuestore.model;

public enum IssueStatusName {
  FOUND,
  IGNORED,
  WAITING,
  DISAPPEARED,
  CORRECTED,
  DELETED
}
