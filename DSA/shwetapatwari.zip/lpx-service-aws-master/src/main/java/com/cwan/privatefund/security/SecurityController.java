package com.cwan.privatefund.security;

import com.cwan.lpx.domain.Security;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.List;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/security")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class SecurityController {

  private final SecurityService securityService;

  public SecurityController(SecurityService securityService) {
    this.securityService = securityService;
  }

  @GetMapping
  @Operation(summary = "Get Security Data")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<Security> getSecurityInfo(
      @Parameter(description = "securityId") @RequestParam List<Long> securityIds) {
    return Flux.from(securityService.getSecurities(null, null, securityIds))
        .flatMapIterable(Function.identity());
  }

  @GetMapping("/account")
  @Operation(summary = "Get Security Data By ClientId, AccId and SecIds")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)})
      })
  public Flux<Security> getSecurityInfoByClientIdAccIdAndSecIds(
      @RequestParam(value = "clientId", required = false) Long clientId,
      @RequestParam(value = "accountId", required = false) Long accountId,
      @RequestParam(value = "securityIds") List<Long> securityIds) {
    return Flux.from(securityService.getSecurities(clientId, accountId, securityIds))
        .flatMapIterable(Function.identity());
  }
}
