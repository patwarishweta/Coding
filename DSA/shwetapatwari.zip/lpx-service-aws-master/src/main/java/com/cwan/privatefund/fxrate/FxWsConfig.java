package com.cwan.privatefund.fxrate;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FxWsConfig {
  @Value("${fx.ws.base.server}")
  private String fxServiceBaseServer;

  @Bean(value = "fxServiceApacheClient")
  FxServiceApacheClient fxServiceApacheClient(AuthTokenCore authTokenCore) {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(fxServiceBaseServer, 443, "fx-ws", Resource.Scheme.HTTPS);
    return new FxServiceApacheClient(
        WsHttpClientBuilder.getSharedDefault(), serverConfiguration, authTokenCore);
  }
}
