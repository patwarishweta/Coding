package com.cwan.privatefund.business.ws.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
@Builder(builderClassName = "UserBuilder", toBuilder = true)
@EqualsAndHashCode
@JsonDeserialize(builder = User.UserBuilder.class)
public class User implements Serializable {

  @Serial private static final long serialVersionUID = 973055497086140712L;

  public static final String CLEARWATER_EMAIL_DOMAIN = "@clearwateranalytics.com";

  @JsonProperty("id")
  private final Integer id;

  @JsonProperty("clientId")
  private final Long clientId;

  @JsonProperty("username")
  private final String username;

  @JsonProperty("firstName")
  private final String firstName;

  @JsonProperty("lastName")
  private final String lastName;

  @JsonProperty("fullname")
  private final String fullname;

  @JsonProperty("phone")
  private final String phone;

  @JsonProperty("email")
  private final String email;

  @JsonProperty("privateLabel")
  private final String privateLabel;

  @JsonProperty("active")
  private final Boolean active;

  private final boolean isInternalUser;

  @JsonPOJOBuilder(withPrefix = "")
  @SuppressWarnings("unused")
  public static class UserBuilder {

    public UserBuilder email(String email) {
      this.email = StringUtils.lowerCase(StringUtils.trimToNull(email));
      this.isInternalUser =
          Objects.nonNull(this.email) && StringUtils.contains(this.email, CLEARWATER_EMAIL_DOMAIN);
      return this;
    }

    public UserBuilder username(String username) {
      this.username = StringUtils.lowerCase(StringUtils.trimToNull(username));
      return this;
    }

    public UserBuilder phone(String phone) {
      this.phone = StringUtils.trimToNull(phone);
      return this;
    }

    public UserBuilder privateLabel(String privateLabel) {
      this.privateLabel = StringUtils.trimToNull(privateLabel);
      return this;
    }

    public UserBuilder firstName(String firstName) {
      this.firstName = StringUtils.trimToNull(firstName);
      return this;
    }

    public UserBuilder lastName(String lastName) {
      this.lastName = StringUtils.trimToNull(lastName);
      return this;
    }

    public UserBuilder fullname(String fullname) {
      this.fullname = StringUtils.trimToNull(fullname);
      return this;
    }

    @SuppressWarnings("unused")
    private UserBuilder isInternalUser(boolean isInternalUser) {
      return this;
    }

    public User build() {
      return new User(
          id,
          clientId,
          username,
          firstName,
          lastName,
          fullname,
          phone,
          email,
          privateLabel,
          active,
          isInternalUser);
    }
  }
}
