package com.cwan.privatefund.accountconfig;

import java.io.Serial;

public class AccountConfigServiceException extends RuntimeException {

  @Serial private static final long serialVersionUID = -5502316307661546377L;

  public AccountConfigServiceException(String msg) {
    super(msg);
  }

  public AccountConfigServiceException(Exception e) {
    super(e);
  }
}
