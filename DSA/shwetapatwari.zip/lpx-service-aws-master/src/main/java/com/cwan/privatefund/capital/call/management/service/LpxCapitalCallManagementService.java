package com.cwan.privatefund.capital.call.management.service;

import static com.cwan.privatefund.capital.call.helper.CapitalCallReactiveHelper.validateNotEmptyOrElseThrow;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.lpx.domain.Client;
import com.cwan.pbor.document.capital.call.management.api.CapitalCallManagement;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.helper.LpxCapitalCallManagementHelper;
import com.cwan.privatefund.capital.call.management.builder.CapitalCallManagementBuilder;
import com.cwan.privatefund.capital.call.management.model.BankAccountCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankAccountResponse;
import com.cwan.privatefund.capital.call.management.model.BankBlacklistResponse;
import com.cwan.privatefund.capital.call.management.model.BankCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankResponse;
import com.cwan.privatefund.util.ExceptionUtils;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class LpxCapitalCallManagementService {

  private final SecurityContextUserService securityContextUserService;
  private final AccountService accountService;
  private final BusinessWSCache businessWSCache;
  private final CapitalCallManagement capitalCallManagement;

  public Flux<BankResponse> fetchBanksByClient(Long clientId) {
    return processActionWithClientValidation(
        clientId,
        (user, client) ->
            Flux.fromIterable(capitalCallManagement.fetchBanksByClient(clientId))
                .flatMap(bank -> buildBankResponseFromDetails(bank, client))
                .doOnNext(
                    data -> log.info("Successfully fetched bank data for client ID: {}", clientId))
                .doOnError(
                    e ->
                        log.error(
                            "Error fetching banks for client ID {}: {}",
                            clientId,
                            ExceptionUtils.getStackTraceAsString(e))));
  }

  public Mono<BankResponse> createBank(BankCreationRequest bankCreationRequest) {
    return processActionWithClientValidation(
            bankCreationRequest.clientId(),
            (user, client) ->
                Mono.just(
                        capitalCallManagement.createBank(
                            CapitalCallManagementBuilder.buildBank(bankCreationRequest, user)))
                    .flatMap(bank -> buildBankResponseFromDetails(bank, client))
                    .doOnNext(
                        data ->
                            log.info(
                                "Bank created successfully for client ID: {}",
                                bankCreationRequest.clientId()))
                    .doOnError(
                        e ->
                            log.error(
                                "Failed to create bank for client ID {}: {}",
                                bankCreationRequest.clientId(),
                                ExceptionUtils.getStackTraceAsString(e)))
                    .flux())
        .next();
  }

  public Mono<BankResponse> fetchBank(String bankUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBank(bankUuid)), bankUuid)
        .flatMapMany(
            bank ->
                processActionWithClientValidation(
                    bank.clientId(),
                    (user, client) -> buildBankResponseFromDetails(bank, client).flux()))
        .next()
        .doOnNext(
            data ->
                log.info(
                    "Successfully fetched bank details for UUID {} and client ID: {}",
                    bankUuid,
                    data.clientId()))
        .doOnError(
            e ->
                log.error(
                    "Error fetching details for bank with UUID {}: {}",
                    bankUuid,
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  public Mono<Void> deleteBank(String bankUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBank(bankUuid)), bankUuid)
        .flatMap(
            bank ->
                processActionWithClientValidation(
                        bank.clientId(),
                        (user, client) ->
                            Mono.defer(() -> deleteBankAndLogOutcome(bankUuid, user)).flux())
                    .next())
        .then();
  }

  public Mono<BankAccountResponse> createBankAccount(
      BankAccountCreationRequest bankAccountCreationRequest) {
    return withUserDetailsAndAccounts(
            (user, userAccounts) ->
                LpxCapitalCallManagementHelper.checkUserAccessToAccount(
                        userAccounts, bankAccountCreationRequest.accountId(), user.getId())
                    .then(
                        validateNotEmptyOrElseThrow(
                            Mono.justOrEmpty(
                                capitalCallManagement.fetchBank(
                                    bankAccountCreationRequest.bankUuid())),
                            bankAccountCreationRequest.bankUuid()))
                    .flatMap(
                        bankResponse ->
                            accountService
                                .getAccountWithClientData(bankAccountCreationRequest.accountId())
                                .flatMap(
                                    account -> {
                                      if (!bankResponse.clientId().equals(account.getClientId())) {
                                        log.error(
                                            "Client ID mismatch for user {} while creating bank account",
                                            user.getId());
                                        return Mono.error(
                                            new AccessDeniedException(
                                                "Access denied due to a client ID mismatch."));
                                      }
                                      return Mono.justOrEmpty(
                                              capitalCallManagement.createBankAccount(
                                                  CapitalCallManagementBuilder.buildBankAccount(
                                                      bankAccountCreationRequest, user)))
                                          .flatMap(this::buildBankAccountResponseFromDetails);
                                    }))
                    .flux())
        .next();
  }

  public Flux<BankAccountResponse> fetchBankAccountsByAccount(Long accountId) {
    return withUserDetailsAndAccounts(
        (user, userAccounts) ->
            LpxCapitalCallManagementHelper.checkUserAccessToAccount(
                    userAccounts, accountId, user.getId())
                .thenMany(
                    Flux.fromIterable(capitalCallManagement.fetchBankAccountsByAccount(accountId))
                        .flatMap(this::buildBankAccountResponseFromDetails)));
  }

  public Flux<BankAccountResponse> fetchBankAccountsByClient(Long clientId) {
    return processActionWithClientValidation(
        clientId,
        (user, client) ->
            withUserDetailsAndAccounts(
                (u, userAccountIds) ->
                    Flux.fromIterable(capitalCallManagement.fetchBankAccountsByClient(clientId))
                        .filter(bankAccount -> userAccountIds.contains(bankAccount.accountId()))
                        .flatMap(this::buildBankAccountResponseFromDetails)));
  }

  public Mono<BankAccountResponse> fetchBankAccount(String bankAccountUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBankAccount(bankAccountUuid)),
            bankAccountUuid)
        .flatMap(
            bankAccount ->
                withUserDetailsAndAccounts(
                        (user, userAccounts) ->
                            Flux.from(
                                LpxCapitalCallManagementHelper.checkUserAccessToAccount(
                                        userAccounts, bankAccount.accountId(), user.getId())
                                    .then(buildBankAccountResponseFromDetails(bankAccount))))
                    .next());
  }

  public Mono<Boolean> deleteBankAccount(String bankAccountUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBankAccount(bankAccountUuid)),
            bankAccountUuid)
        .flatMapMany(
            bankAccount ->
                withUserDetailsAndAccounts(
                    (user, userAccounts) ->
                        deleteBankAccountWithValidation(
                                bankAccountUuid, bankAccount, user, userAccounts)
                            .flatMapMany(Mono::just)))
        .next();
  }

  public Flux<BankBlacklistResponse> fetchBlacklistedBanksByClient(Long clientId) {
    return processActionWithClientValidation(
            clientId,
            (user, client) ->
                Flux.fromIterable(capitalCallManagement.fetchBankBlacklistsByClient(clientId))
                    .flatMap(this::buildBankBlacklistResponseFromDetails))
        .doOnNext(
            data -> log.info("Successfully fetched blacklisted banks for client ID: {}", clientId))
        .doOnError(
            e ->
                log.error(
                    "Error fetching blacklisted banks for client ID {}: {}",
                    clientId,
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  public Mono<BankBlacklistResponse> addBankToBlacklist(String bankUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBank(bankUuid)), bankUuid)
        .flatMapMany(
            bank ->
                processActionWithClientValidation(
                    bank.clientId(),
                    (user, client) ->
                        buildBankBlacklistResponseFromDetails(
                                capitalCallManagement.createBankBlacklist(
                                    CapitalCallManagementBuilder.buildBankBlacklist(bank, user)))
                            .doOnNext(
                                data ->
                                    log.info(
                                        "Bank with UUID {} successfully added to blacklist by user {}",
                                        bankUuid,
                                        user.getId()))
                            .flux()))
        .next()
        .doOnError(
            e ->
                log.error(
                    "Error processing request to add bank with UUID {} to blacklist: {}",
                    bankUuid,
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  public Mono<BankBlacklistResponse> fetchBlacklistedBank(String bankUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBankBlacklist(bankUuid)), bankUuid)
        .flatMapMany(
            bankBlacklist ->
                processActionWithClientValidation(
                    bankBlacklist.bank().clientId(),
                    (user, client) ->
                        buildBankBlacklistResponseFromDetails(bankBlacklist)
                            .doOnNext(
                                data ->
                                    log.info(
                                        "Successfully fetched details for blacklisted bank with UUID {} and client ID: {}",
                                        bankUuid,
                                        bankBlacklist.bank().clientId()))
                            .flux()))
        .next()
        .doOnError(
            e ->
                log.error(
                    "Error fetching details for blacklisted bank with UUID {}: {}",
                    bankUuid,
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  public Mono<Void> removeBankFromBlacklist(String bankUuid) {
    return validateNotEmptyOrElseThrow(
            Mono.justOrEmpty(capitalCallManagement.fetchBankBlacklist(bankUuid)), bankUuid)
        .flatMapMany(
            bankBlacklist ->
                processActionWithClientValidation(
                    bankBlacklist.bank().clientId(),
                    (user, client) ->
                        capitalCallManagement.deleteBankBlacklist(
                                bankUuid, user.getId().longValue())
                            ? Mono.empty()
                                .doOnTerminate(
                                    () ->
                                        log.info(
                                            "Blacklisted bank with UUID {} successfully removed by user {}",
                                            bankUuid,
                                            user.getId()))
                                .flux()
                            : Mono.error(new RuntimeException("Failed to remove blacklisted bank."))
                                .flux()))
        .next()
        .doOnError(
            e ->
                log.error(
                    "Error processing request to remove blacklisted bank with UUID {}: {}",
                    bankUuid,
                    ExceptionUtils.getStackTraceAsString(e)))
        .then();
  }

  private Mono<Map<Long, Collection<Long>>> getClientAccountsForUser(User user) {
    return accountService
        .retrieveUserAccessibleAccountIds(user.getId())
        .flatMap(
            accountIds ->
                accountService
                    .getAccountsData(accountIds)
                    .flatMapMany(Flux::fromIterable)
                    .collectMultimap(Account::getClientId, Account::getId));
  }

  Mono<Boolean> deleteBankAccountWithValidation(
      String bankAccountUuid, BankAccount bankAccount, User user, Set<Long> userAccounts) {
    if (!userAccounts.contains(bankAccount.accountId())) {
      log.error(
          "User {} does not have permission to delete bank account with UUID: {}",
          user.getId(),
          bankAccountUuid);
      return Mono.error(
          new AccessDeniedException(
              "Access denied. You do not have permission to delete this bank account."));
    }
    var deletionResult =
        capitalCallManagement.deleteBankAccount(bankAccountUuid, user.getId().longValue());
    if (deletionResult) {
      log.info(
          "Bank account with UUID {} deleted successfully by user {}",
          bankAccountUuid,
          user.getId());
      return Mono.just(true);
    }
    log.error(
        "Failed to delete bank account with UUID {} by user {}", bankAccountUuid, user.getId());
    return Mono.error(new RuntimeException("Failed to delete bank account."));
  }

  Mono<Void> deleteBankAndLogOutcome(String bankUuid, User user) {
    if (capitalCallManagement.deleteBank(bankUuid, user.getId().longValue())) {
      log.info("Bank with UUID {} deleted successfully", bankUuid);
      return Mono.empty();
    }
    var errorMessage = "Failed to delete bank with UUID " + bankUuid;
    log.error(errorMessage);
    return Mono.error(new RuntimeException(errorMessage));
  }

  <T> Flux<T> processActionWithClientValidation(
      Long clientId, BiFunction<User, Client, Flux<T>> action) {
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .flatMapMany(
            user ->
                getClientAccountsForUser(user)
                    .flatMapMany(
                        clientAccounts -> {
                          if (clientAccounts.containsKey(clientId)) {
                            return businessWSCache
                                .getClientData(clientId)
                                .flatMapMany(client -> action.apply(user, client));
                          }
                          var errorMessage =
                              String.format(
                                  "Access denied for user %d to client ID %s.",
                                  user.getId(), clientId);
                          log.error(errorMessage);
                          return Flux.error(new AccessDeniedException(errorMessage));
                        }))
        .doOnError(
            e ->
                log.error(
                    "Error in operation processActionWithClientValidation: {}",
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  private <T> Flux<T> withUserDetailsAndAccounts(BiFunction<User, Set<Long>, Flux<T>> action) {
    return securityContextUserService
        .validateAndRetrieveUserDetails()
        .flatMapMany(
            user ->
                accountService
                    .retrieveUserAccessibleAccountIds(user.getId())
                    .flatMapMany(userAccountIds -> action.apply(user, userAccountIds)))
        .doOnError(
            e ->
                log.error(
                    "Error in operation withUserDetailsAndAccounts: {}",
                    ExceptionUtils.getStackTraceAsString(e)));
  }

  private Mono<BankResponse> buildBankResponseFromDetails(Bank bank, Client client) {
    return securityContextUserService
        .validateAndRetrieveUserDetails(bank.createdBy())
        .map(
            validatedUser ->
                CapitalCallManagementBuilder.buildBankResponse(validatedUser, client, bank));
  }

  private Mono<BankAccountResponse> buildBankAccountResponseFromDetails(BankAccount bankAccount) {
    return securityContextUserService
        .validateAndRetrieveUserDetails(bankAccount.createdBy())
        .map(
            validatedUser ->
                CapitalCallManagementBuilder.buildBankAccountResponse(validatedUser, bankAccount));
  }

  private Mono<BankBlacklistResponse> buildBankBlacklistResponseFromDetails(
      BankBlacklist bankBlacklist) {
    return securityContextUserService
        .validateAndRetrieveUserDetails(bankBlacklist.createdBy())
        .map(
            validatedUser ->
                CapitalCallManagementBuilder.buildBankBlacklistResponse(
                    validatedUser, bankBlacklist));
  }
}
