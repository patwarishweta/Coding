package com.cwan.privatefund.account;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class UltimateParents {
  private Long ultimateParentId;
  private String ultimateParentName;
}
