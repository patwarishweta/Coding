package com.cwan.privatefund.portfolio;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Performance;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortfolioBalance {
  private Account account;
  private Security security;
  private FundMasterEntity fundMaster;
  private Performance performance;
  private LocalDate callNoticeDate;
  private LocalDate distributionNoticeDate;
  private LocalDate accountStatementDate;
}
