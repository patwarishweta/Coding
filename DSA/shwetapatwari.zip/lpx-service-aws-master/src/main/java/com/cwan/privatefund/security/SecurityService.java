package com.cwan.privatefund.security;

import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.security.model.FieldsBySource;
import com.cwan.privatefund.security.model.SecurityRequest;
import com.cwan.privatefund.security.model.SecurityResponse;
import com.google.common.annotations.VisibleForTesting;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class SecurityService {

  private final SecurityCache securityCache;
  private final SecurityTransformer securityTransformer;
  private final SecurityRequest.SecurityRequestBuilder securityRequestBuilder;

  public SecurityService(
      SecurityCache securityCache,
      SecurityTransformer securityTransformer,
      SecurityRequest.SecurityRequestBuilder securityRequestBuilder) {
    this.securityCache = securityCache;
    this.securityTransformer = securityTransformer;
    this.securityRequestBuilder = securityRequestBuilder;
  }

  public Mono<Security> getSecurity(Long clientId, Long accountId, Long securityId) {
    return securityCache
        .getSecurities(getSecurityRequest(clientId, accountId, List.of(securityId)))
        .filter(responses -> !responses.isEmpty())
        .<SecurityResponse>handle(
            (responses, sink) -> {
              if (responses.size() > 1) {
                sink.error(
                    new SecurityException(
                        "There is more than one security response for securityId= " + securityId));
                return;
              }
              sink.next(responses.get(0));
            })
        .map(
            securityResponse ->
                securityTransformer.transform(
                    securityResponse.getSecurityMasterData(),
                    securityResponse.getFundMasterData(),
                    securityResponse.getSecurityTypeData()));
  }

  public Mono<Security> getSecurity(Long securityId) {
    var fieldsBySource = getFieldsBySourceList();

    return securityCache
        .getSecurityById(getSecurityRequest(List.of(securityId), fieldsBySource), securityId)
        .map(
            securityResponse ->
                securityTransformer.transform(
                    securityResponse.getSecurityMasterData(),
                    securityResponse.getFundMasterData(),
                    securityResponse.getSecurityTypeData()));
  }

  @VisibleForTesting
  public static List<FieldsBySource> getFieldsBySourceList() {
    var securityMasterFields =
        FieldsBySource.builder()
            .source("SecurityMaster")
            .fields(List.of("ID", "Name", "Cusip", "CurrencyID", "CurrencyCode"))
            .build();
    var fundMasterFields =
        FieldsBySource.builder().source("FundMaster").fields(List.of("name", "gpName")).build();
    var securityTypeDataFields =
        FieldsBySource.builder()
            .source("SecurityTypeData")
            .fields(List.of("isLIHTC", "isAmortizingLP", "isLimitedPartnership"))
            .build();
    var derivedFields =
        FieldsBySource.builder()
            .source("derived")
            .fields(List.of("identifier", "securityIdentifier"))
            .build();
    return List.of(securityMasterFields, fundMasterFields, securityTypeDataFields, derivedFields);
  }

  public Mono<List<Security>> getSecurities(Long clientId, Long accountId, List<Long> securityIds) {
    return securityCache
        .getSecurities(getSecurityRequest(clientId, accountId, securityIds))
        .map(
            responses ->
                responses.stream()
                    .map(
                        securityResponse -> {
                          if (securityResponse.getSecurityMasterData().getCusip() == null) {
                            securityResponse
                                .getSecurityMasterData()
                                .setCusip(securityResponse.getDerived().getIdentifier());
                          }
                          return securityTransformer.transform(
                              securityResponse.getSecurityMasterData(),
                              securityResponse.getFundMasterData(),
                              securityResponse.getSecurityTypeData());
                        })
                    .toList());
  }

  private SecurityRequest getSecurityRequest(
      Long clientId, Long accountId, List<Long> securityIds) {
    var fieldsBySource = getFieldsBySourceList();

    return securityRequestBuilder
        .clientId(clientId)
        .accountId(accountId)
        .securityIds(securityIds)
        .fieldsBySource(fieldsBySource)
        .build();
  }

  private SecurityRequest getSecurityRequest(
      List<Long> securityIds, List<FieldsBySource> fieldsBySource) {
    return securityRequestBuilder.fieldsBySource(fieldsBySource).securityIds(securityIds).build();
  }
}
