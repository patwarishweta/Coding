package com.cwan.privatefund.feature;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import com.cwan.privatefund.client.WebResponseMapper;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeatureFlagWSConfig {

  @Value("${feature.flags.ws.base.server}")
  private String featureFlagWSBaseServer;

  @Bean(value = "featureFlagsWSClient")
  FeatureFlagsWSClient featureFlagsWSClient() {
    Cache<String, FeatureResponse> cache =
        CacheBuilder.newBuilder().maximumSize(1000).expireAfterWrite(60, TimeUnit.SECONDS).build();
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(
            featureFlagWSBaseServer, 443, "feature-flags-ws", Resource.Scheme.HTTPS);
    return new FeatureFlagsWSClient(
        WsHttpClientBuilder.getSharedDefault(), serverConfiguration, cache);
  }

  @Bean(value = "featureFlagResponseMapper")
  WebResponseMapper<FeatureFlagWsException> featureFlagResponseMapper() {
    return new WebResponseMapper<>() {
      @Override
      protected FeatureFlagWsException getException(String msg) {
        return new FeatureFlagWsException(msg);
      }
    };
  }
}
