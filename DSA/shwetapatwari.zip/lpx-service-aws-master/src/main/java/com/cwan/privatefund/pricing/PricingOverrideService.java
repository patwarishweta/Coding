package com.cwan.privatefund.pricing;

import static java.util.stream.Collectors.groupingBy;

import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.pricing.model.PricingRequest;
import com.cwan.privatefund.pricing.model.PricingResponse;
import com.google.common.cache.LoadingCache;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PricingOverrideService {

  private final LoadingCache<PricingRequest, PricingResponse> pricingCache;

  public PricingOverrideService(LoadingCache<PricingRequest, PricingResponse> pricingCache) {
    this.pricingCache = pricingCache;
  }

  /**
   * Uses PricingClient (pricing-ws) to create a list of NAV (Net Asset Value) adjustment
   * transactions for a given list of transactions on a given day.
   */
  public List<Transaction> getPricingOverrideTransactions(
      LocalDate date, List<Transaction> transactions) {
    Map<Long, Map<Long, List<Transaction>>> groupedTransactions =
        transactions.stream()
            // TODO PATH-2550 Remove use of entryDate and replace with settleDate
            // TODO PATH-2551 Consistent filtering with subscription start date
            .filter(tran -> !date.isBefore(tran.getEntryDate()))
            .collect(
                groupingBy(
                    e -> e.getAccount().getId(), groupingBy(e -> e.getSecurity().getSecurityId())));

    return groupedTransactions.entrySet().stream()
        .flatMap(
            accountGroupedEntry -> {
              PricingRequest request =
                  new PricingRequest(
                      accountGroupedEntry.getKey(),
                      accountGroupedEntry.getValue().keySet().stream().toList(),
                      date);
              try {
                PricingResponse response = pricingCache.get(request);
                return accountGroupedEntry.getValue().entrySet().stream()
                    .flatMap(
                        securityGroupedEntry -> {
                          Double price = response.getPrice(date, securityGroupedEntry.getKey());
                          if (price == null) {
                            return Stream.of();
                          }
                          return securityGroupedEntry.getValue().stream()
                              .map(
                                  transaction ->
                                      Transaction.builder()
                                          .type("NAV")
                                          .account(transaction.getAccount())
                                          .security(transaction.getSecurity())
                                          .currency(transaction.getCurrency())
                                          .navImpact(price)
                                          .entryDate(date)
                                          .tradeDate(date)
                                          .settleDate(date)
                                          .build())
                              .distinct();
                        });
              } catch (ExecutionException ex) {
                String message =
                    String.format("Failed to retrieve pricing overrides for %s", request);
                log.error(message);
                throw new RuntimeException(message, ex);
              }
            })
        .collect(Collectors.toList());
  }
}
