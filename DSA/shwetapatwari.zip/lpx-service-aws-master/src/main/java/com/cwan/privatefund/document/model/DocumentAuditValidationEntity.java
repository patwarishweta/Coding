package com.cwan.privatefund.document.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "document_audit_validation")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentAuditValidationEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "document_id")
  private Long documentId;

  @Column(name = "file_name")
  private String fileName;

  @Column(name = "checked")
  private Boolean checked;

  @Column(name = "modified_by")
  private String modifiedBy;

  @Column(name = "modified_on")
  private LocalDateTime modifiedOn;

  @Column(name = "canoe_id")
  private String canoeId;
}
