package com.cwan.privatefund.salesforce.config;

import com.cwan.privatefund.salesforce.common.SalesforceProperties;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@AllArgsConstructor
@Configuration
public class SalesforceWebClientConfig {

  private final SalesforceProperties salesforceProperties;

  @Bean
  @Qualifier("salesforce-auth")
  WebClient salesforceAuthClient() {
    return WebClient.builder()
        .baseUrl(
            String.format("https://%s/services/oauth2/token", salesforceProperties.getSfAuthHost()))
        .build();
  }

  @Bean
  @Qualifier("salesforce-api")
  WebClient salesforceApiClient() {
    return WebClient.builder()
        .baseUrl(
            String.format(
                "https://%s/services/data/v57.0", salesforceProperties.getSfInstanceHost()))
        .build();
  }

  @Bean
  @Qualifier("salesforce-soap-api")
  WebClient salesforceSoapApiClient() {
    return WebClient.builder()
        .baseUrl(
            String.format(
                "https://%s/services/Soap/u/57.0", salesforceProperties.getSfInstanceHost()))
        .build();
  }
}
