package com.cwan.privatefund.cpd.ws.model;

import java.io.Serial;
import java.io.Serializable;
import lombok.Builder;

@Builder(toBuilder = true)
public record TagEntry(
    Integer fieldId,
    Long clientId,
    Integer tagId,
    Long accountId,
    Integer reportDate,
    Integer overrideLevel,
    Integer endDate,
    String cpdValue,
    Integer dataSource)
    implements Serializable {

  @Serial private static final long serialVersionUID = -8815871511323585576L;
}
