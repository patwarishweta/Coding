package com.cwan.privatefund.canoeFundMapping.model;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class CanoeFundMappingClientResponse implements Serializable {

  @Serial private static final long serialVersionUID = -9186454906156005423L;
  private Long clientId;
  private String clientName;
}
