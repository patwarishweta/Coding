package com.cwan.privatefund.comment;

import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentEntity;
import java.util.Collection;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Slf4j
@Service
public class CommentService {

  private final CommentRepository commentRepository;
  private final CommentEntityTransformer commentEntityTransformer;
  private final CommentTransformer commentTransformer;

  public CommentService(
      CommentRepository commentRepository,
      CommentEntityTransformer commentEntityTransformer,
      CommentTransformer commentTransformer) {
    this.commentRepository = commentRepository;
    this.commentEntityTransformer = commentEntityTransformer;
    this.commentTransformer = commentTransformer;
  }

  Flux<Comment> addComments(Collection<Comment> comments) {
    comments.stream()
        .filter(comment -> comment.getId() != null)
        .forEach(
            comment ->
                log.warn("comment with Id {} can't be added Id should be null.", comment.getId()));
    return Flux.fromIterable(comments)
        .filter(comment -> comment.getId() == null)
        .filter(Objects::nonNull)
        .map(commentEntityTransformer)
        .map(this::saveComment)
        .map(commentTransformer);
  }

  Flux<Comment> getCommentsByDocumentId(Long documentId) {
    return Flux.fromIterable(commentRepository.findAllByDocumentId(documentId))
        .map(commentTransformer);
  }

  void deleteCommentsById(Set<Long> ids) {
    commentRepository.deleteAllById(ids);
  }

  private CommentEntity saveComment(CommentEntity comment) {
    return commentRepository.saveAndFlush(comment);
  }
}
