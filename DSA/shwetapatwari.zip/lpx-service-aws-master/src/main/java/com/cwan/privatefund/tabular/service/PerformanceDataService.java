package com.cwan.privatefund.tabular.service;

import com.cwan.lpx.client.tabular.PerformanceData;
import com.cwan.lpx.domain.Performance;
import com.cwan.pbor.performance.api.Performances;
import java.time.LocalDate;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PerformanceDataService {

  private final Performances performances;

  public PerformanceDataService(Performances performances) {
    this.performances = performances;
  }

  public Map<PerformanceKey, PerformanceData> getPerformanceData(
      Set<Long> accountIds, LocalDate asOfDate) {
    log.info("Performance data for accounts {} and date {}", accountIds, asOfDate);
    return performances
        .getPerformancesByAccountIds(
            accountIds, asOfDate.atStartOfDay(), asOfDate.atTime(23, 59, 59), "ITD")
        .stream()
        .filter(Objects::nonNull)
        .map(this::mapPerformanceData)
        .collect(
            Collectors.toMap(
                PerformanceValue::performanceKey,
                performance -> performance.performanceData,
                (a, b) -> a));
  }

  private PerformanceValue mapPerformanceData(Performance performance) {
    PerformanceData performanceData =
        PerformanceData.builder()
            .tvpi(performance.getTvpi())
            .rvpi(performance.getRvpi())
            .dpi(performance.getDpi())
            .pic(performance.getPic())
            .dc(performance.getDc())
            .grossIRR(performance.getGrossXirr() != null ? performance.getGrossXirr() * 100 : null)
            .netIRR(performance.getNetXirr() != null ? performance.getNetXirr() * 100 : null)
            .pme(performance.getPme())
            .moic(performance.getGrossMoic())
            .pmeReferenceIndex(performance.getPmeReferenceIndex())
            .pmeReferenceIndexName(performance.getPmeReferenceIndexName())
            .vintageYear(performance.getVintageYear())
            .build();
    return new PerformanceValue(
        new PerformanceKey(performance.getAccountId(), performance.getSecurityId()),
        performanceData);
  }

  public record PerformanceKey(Long accountId, Long securityId) {}

  public record PerformanceValue(PerformanceKey performanceKey, PerformanceData performanceData) {}
}
