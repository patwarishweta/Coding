package com.cwan.privatefund.util;

import com.ca.util.collections.ImmutableRange;
import com.ca.util.collections.Range;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
import net.bytebuddy.implementation.InvocationHandlerAdapter;
import net.bytebuddy.matcher.ElementMatchers;
import org.springframework.objenesis.ObjenesisStd;

/** Adapted from accounting-common-lib ReflectionProxy class. */
@Slf4j
public final class LoggingUtils {
  public static <T> T logMethodCalls(T t, Class clazz, String label) {
    return logMethodTimes(
        t,
        clazz,
        x -> {
          long elapsed = x.getElapsed().getSecond() - x.getElapsed().getFirst();
          log.info("{} Time Taken by this request {}ms [{}]", label, elapsed, x.getMethod());
        });
  }

  public static class MethodCallMetrics {
    private final Method method;
    private final Range<Long> elapsed;

    public MethodCallMetrics(Method method, Range<Long> elapsed) {
      this.method = method;
      this.elapsed = elapsed;
    }

    public Method getMethod() {
      return method;
    }

    public Range<Long> getElapsed() {
      return elapsed;
    }
  }

  public static <T> T logMethodTimes(T t, Class clazz, Consumer<MethodCallMetrics> callback) {
    InvocationHandler invocationHandler =
        (proxy, method, args) -> {
          long start = System.currentTimeMillis();
          Object ret = method.invoke(t, args);
          long stop = System.currentTimeMillis();
          callback.accept(new MethodCallMetrics(method, new ImmutableRange<>(start, stop)));
          return ret;
        };
    // To prevent calling the constructor we define no constructor and use Objenesis to construct
    // the class.
    // This avoids the need for mocking arguments when there is no default constructor.
    Class<?> proxyClass =
        new ByteBuddy()
            .subclass(clazz, ConstructorStrategy.Default.NO_CONSTRUCTORS)
            .method(ElementMatchers.not(ElementMatchers.isDeclaredBy(Object.class)))
            .intercept(InvocationHandlerAdapter.of(invocationHandler))
            .make()
            .load(Thread.currentThread().getContextClassLoader())
            .getLoaded();
    return (T) new ObjenesisStd().getInstantiatorOf(proxyClass).newInstance();
  }
}
