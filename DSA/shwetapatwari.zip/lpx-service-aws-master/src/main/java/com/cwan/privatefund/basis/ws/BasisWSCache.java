package com.cwan.privatefund.basis.ws;

import static com.cwan.privatefund.basis.ws.BasisWSConfig.ACCOUNT_ID_TO_BASES;
import static com.cwan.privatefund.basis.ws.BasisWSConfig.BASIS_ID_TO_BASES;

import com.cwan.privatefund.basis.ws.model.Basis;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.serializer.support.SerializationFailedException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BasisWSCache {

  private final BasisWSClient basisWSClient;
  private final RedisTemplate<String, Object> redisTemplate;

  public BasisWSCache(BasisWSClient basisWSClient, RedisTemplate<String, Object> redisTemplate) {
    this.basisWSClient = basisWSClient;
    this.redisTemplate = redisTemplate;
  }

  public List<Basis> getEnabledBases(Long accountId) {
    try {
      List<Basis> cached =
          (List<Basis>) redisTemplate.opsForHash().get(ACCOUNT_ID_TO_BASES, accountId);
      if (cached != null && !cached.isEmpty()) {
        return cached;
      }
      if (cached != null && cached.isEmpty()) {
        redisTemplate.opsForHash().delete(ACCOUNT_ID_TO_BASES, accountId);
      }
    } catch (SerializationFailedException e) {
      log.error("Failed to deserialize cached bases for account: {}", accountId, e);
      redisTemplate.opsForHash().delete(ACCOUNT_ID_TO_BASES, accountId);
    }
    List<Basis> bases =
        basisWSClient.getEnabledBases(accountId).stream()
            .map(this::getBasis)
            .collect(Collectors.toList());
    bases.sort(Comparator.comparing(Basis::getBasisId));
    redisTemplate.opsForHash().put(ACCOUNT_ID_TO_BASES, accountId, bases);
    return bases;
  }

  private Basis getBasis(Integer basisId) {
    try {
      Basis basis = (Basis) redisTemplate.opsForHash().get(BASIS_ID_TO_BASES, basisId);
      if (basis != null) {
        return basis;
      }
    } catch (SerializationFailedException e) {
      log.error("Failed to deserialize cached basis for basisId: {}", basisId, e);
    }
    Map<Integer, Basis> basisMap =
        basisWSClient.getBases().stream()
            .collect(Collectors.toMap(Basis::getBasisId, Function.identity()));
    for (Map.Entry<Integer, Basis> basisEntry : basisMap.entrySet()) {
      redisTemplate.opsForHash().delete(BASIS_ID_TO_BASES, basisEntry.getKey());
      redisTemplate.opsForHash().put(BASIS_ID_TO_BASES, basisEntry.getKey(), basisEntry.getValue());
    }
    return basisMap.get(basisId);
  }
}
