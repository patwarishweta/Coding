package com.cwan.privatefund.accelex;

import com.ca.relalg.Column;
import com.ca.tabular.field.DataType;

public enum AccelexField implements Column {
  EVENT_REF(
      1,
      "event_reference",
      "The Clearwater '{accountId}:{securityId}' Accelex uses to determine a unique row of data",
      DataType.STRING),
  EVENT_TYPE(
      2,
      "event_type",
      "Options: Commitment, Investment. Commitment is used to transactions that affect the fund security",
      DataType.STRING),
  VEHICLE_REF(3, "vehicle_reference", "Ultimate Parent Clearwater Client Id", DataType.INT),
  ASSET_REF(4, "asset_reference", "Clearwater Security Id of the Fund", DataType.INT),
  METRIC_NAME(
      5,
      "metric_name",
      "The name of the Accelex data we're sending updated data for",
      DataType.STRING),
  REPORT_DATE(6, "report_date", "The knowledge start date of the data", DataType.TIME_STAMP),
  DATE(7, "date", "Corresponds to the settle date of the transactional data", DataType.TIME_STAMP),
  PERIOD(
      8,
      "period",
      "The period of data we're reporting on. Common values: INCEPTION for initial load data, or blank for daily",
      DataType.STRING),
  CURRENCY(9, "currency", "The currency value of the data, unmodified", DataType.STRING),
  VALUE(10, "value", "The value of the metric being reported on", DataType.DOUBLE),
  PAYMENT_TYPE(11, "payment_type", "CALL or DISTRIBUTION", DataType.STRING),
  PAYMENT_SUBTYPE(
      12, "payment_subtype", "The subtype of transaction as defined by EDGAR", DataType.STRING),
  ACTION(
      13,
      "action",
      "Used for cancel/rebooks. Cancels will have a value of DELETE. All other types can leave blank",
      DataType.STRING),
  DOCUMENT_ID(
      14,
      "document_id",
      "The clearwater internal documentId associated with the data",
      DataType.INT),
  DOCUMENT_TYPE(
      15,
      "document_type",
      "Such as capital account statement: CAS, CASHFLOW_NOTICE. Can be left blank",
      DataType.INT),
  ENTITY_NAME(16, "entity_name", "Name of the Fund in FundMaster", DataType.STRING),
  TYPE_OF_FUND(17, "fund_asset_class_level_1", "Type of Fund", DataType.STRING),
  SUB_TYPE_OF_FUND(18, "fund_asset_class_level_2", "Sub Type of Fund", DataType.STRING),
  ENTITY_CURRENCY(19, "entity_currency", "Currency", DataType.STRING),
  VINTAGE_YEAR(20, "fund_vintage_year", "Vintage Year", DataType.STRING),
  GEOGRAPHIC_FOCUS(21, "geography", "Geographic Focus", DataType.STRING),
  COUNTRY_OF_DOMICILE(22, "country", "Country of Domicile", DataType.STRING),
  TOTAL_FUND_SIZE(23, "fund_size", "Total Fund Size", DataType.DOUBLE),
  COMMITMENT_SIZE(24, "commitment_size", "Total Size of Commitment", DataType.DOUBLE),
  ENTITY_TYPE(25, "entity_type", "FUND + Investor", DataType.STRING),
  ENTITY_SYNONYMS(26, "entity_synonyms", "blank for now", DataType.STRING),
  ENTITY_KEY(27, "entity_synonyms", "blank for now", DataType.STRING),
  GICS_SECTOR(28, "gics_sector", "blank for now", DataType.STRING),
  GICS_INDUSTRY_SECTOR(29, "gics_industry_group", "blank for now", DataType.STRING),
  GICS_INDUSTRY(30, "gics_industry", "blank for now", DataType.STRING),
  INVESTOR_TYPE(31, "gics_industry", "blank for now", DataType.STRING),
  VEHICLE_NAME(32, "vehicle_name", "client name", DataType.STRING),
  ASSET_NAME(33, "asset_name", "fund name", DataType.STRING),
  EVENT_STATUS(34, "event_status", "blank for now", DataType.STRING),
  INVESTMENT_TYPE(35, "investment_type", "blank for now", DataType.STRING),
  DEAL_TYPE(36, "deal_type", "blank for now", DataType.STRING),
  SUB_DEAL_TYPE(37, "sub_deal_type", "blank for now", DataType.STRING),
  ENTRY_DATE(38, "entry_date", "blank for now", DataType.STRING),
  EXIT_DATE(39, "exit_date", "blank for now", DataType.STRING),
  COMMITMENT_TYPE(40, "commitment_type", "blank for now", DataType.STRING),
  COMMITMENT_NAME(41, "commitment_name", "blank for now", DataType.STRING),
  ENTITY_REF(42, "entity_ref", "blank for now", DataType.STRING),
  VALUE_TYPE(43, "value_type", "always ACTUAL for aggregates", DataType.STRING);

  private final int id;
  private final String csvName;
  private final String definition;
  private final DataType dataType;

  AccelexField(int id, String csvName, String definition, DataType dataType) {
    this.id = id;
    this.csvName = csvName;
    this.definition = definition;
    this.dataType = dataType;
  }

  @Override
  public String getName() {
    return csvName;
  }
}
