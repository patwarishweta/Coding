package com.cwan.privatefund.accountconfig;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.privatefund.client.WsClientStatus;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class AccountConfigServiceClient {

  private final WebClient accountConfigServiceWebClient;

  public AccountConfigServiceClient(WebClient accountConfigServiceWebClient) {
    this.accountConfigServiceWebClient = accountConfigServiceWebClient;
  }

  public Mono<List<AccountConfig>> getByAccountId(Long accountId) {
    return accountConfigServiceWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/account/subscription")
                    .queryParam("accountIds", accountId)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "AccountConfig getById /account/subscription 4xxClientError: " + accountId))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "AccountConfig getById /account/subscription is5xxServerError: " + accountId))
        .bodyToMono(new ParameterizedTypeReference<List<AccountConfig>>() {})
        .onErrorResume(
            e -> {
              log.error("Failed to received response due to {}", e.getMessage());
              return Mono.empty();
            });
  }

  public Mono<List<AccountConfig>> getByAccountIds(List<Long> accountIds) {
    return accountConfigServiceWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/account/subscription")
                    .queryParam("accountIds", accountIds)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "AccountConfig getById /account/subscription 4xxClientError: " + accountIds))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "AccountConfig getById /account/subscription is5xxServerError: " + accountIds))
        .bodyToMono(new ParameterizedTypeReference<List<AccountConfig>>() {})
        .onErrorResume(
            e -> {
              log.error("Failed to received response due to {}", e.getMessage());
              return Mono.empty();
            });
  }

  public Mono<List<AccountConfig>> getAllAccountConfigs(String service) {
    return accountConfigServiceWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder.path("account/subscription/all").queryParam("services", service).build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res, "AccountConfig getAll account/subscription/all 4xxClientError"))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res, "AccountConfig getAll account/subscription/all is5xxServerError"))
        .bodyToMono(new ParameterizedTypeReference<List<AccountConfig>>() {})
        .onErrorResume(
            e -> {
              log.error(
                  "Failed to received response AccountConfig getAll due to {}", e.getMessage());
              return Mono.empty();
            });
  }

  public Flux<AccountSubscriptionRules> getAccountRules(Long accountId) {
    return accountConfigServiceWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("account/rules/accountId/securityId")
                    .queryParam("accountId", accountId)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "AccountConfig getAccountRulesByAccountId account/rules/accountId/securityId 4xxClientError"))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            res ->
                WsClientStatus.onStatusError(
                    res,
                    "AccountConfig getAccountRulesByAccountId account/rules/accountId/securityId is5xxServerError"))
        .bodyToFlux(AccountSubscriptionRules.class)
        .onErrorResume(
            e -> {
              log.error(
                  "Failed to receive response AccountConfig getAccountRulesByAccountId due to {}",
                  e.getMessage());
              return Mono.empty();
            });
  }
}
