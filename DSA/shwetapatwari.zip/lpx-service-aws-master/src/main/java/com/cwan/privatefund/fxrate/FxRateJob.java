package com.cwan.privatefund.fxrate;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.cwan.lpx.domain.ReportingFrequency;
import java.time.LocalDate;
import java.util.Set;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.util.Pair;

@Data
@Builder(toBuilder = true)
public class FxRateJob {
  private Long baseCurrencyId;
  private Set<Pair<Long, ReportingFrequency>> localCurrencies;
  private LocalDate firstDayToGenerateFor;
  private LocalDate lastDayToGenerateFor;
  private Set<Long> fxRateSourceIds;
  // False = calculate only rates that are not already in the database
  // True = recalculate all rates regardless of database values
  private boolean forceRecalculate;

  public LocalDateRange getDateRange() {
    return LocalDateRanges.create(firstDayToGenerateFor, lastDayToGenerateFor);
  }
}
