package com.cwan.privatefund.cpd.ws.controller;

import com.cwan.privatefund.config.properties.CpdConfigProperties;
import com.cwan.privatefund.cpd.ws.client.CpdWSCache;
import com.cwan.privatefund.cpd.ws.model.CpdFieldAndData;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping(value = "v1/cpd-ws")
public class CpdWSController {

  private final CpdWSCache cpdWSCache;
  private final CpdConfigProperties cpdConfigProperties;

  /**
   * Endpoint to retrieve tag entries for a specific client.
   *
   * @param clientId the client ID to fetch tag entries for.
   * @param accountId the account ID to fetch tag entries for.
   * @return a Flux stream with the tag entries of the client.
   */
  @GetMapping("/tags/{clientId}/{accountId}")
  @Operation(summary = "Retrieve tag entries for a specific client")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Retrieved tag entries successfully"),
        @ApiResponse(responseCode = "400", description = "Bad Request"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public Mono<ConcurrentHashMap<String, TagEntry>> getTagEntriesForClient(
      @PathVariable Long clientId, @PathVariable Long accountId) {
    log.info("Fetching tag entries for client with id: {}", clientId);
    return cpdWSCache
        .getTagEntriesForClient(
            clientId,
            accountId,
            new HashSet<>(
                Objects.requireNonNull(
                        cpdConfigProperties.getFieldIds().getReviewers(),
                        "Reviewers configuration is missing.")
                    .values()))
        .doOnError(
            error ->
                log.error(
                    "Error occurred while fetching tag entries for client id: {}",
                    clientId,
                    error));
  }

  /**
   * Endpoint to manually clear the cache for a specific client ID.
   *
   * @param clientId the client ID for which the cache should be cleared.
   * @return a response indicating the cache for the client ID has been cleared.
   */
  @PostMapping("/clear-cache/{clientId}")
  @Operation(summary = "Manually clear the cache for a specific client ID")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Cache for client ID cleared successfully"),
        @ApiResponse(responseCode = "400", description = "Bad Request"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public Mono<ResponseEntity<String>> clearCacheForClient(@PathVariable Long clientId) {
    return cpdWSCache
        .clearCacheForClient(clientId)
        .thenReturn(ResponseEntity.ok("Cache cleared successfully for client ID: " + clientId))
        .onErrorResume(
            IllegalArgumentException.class,
            ex -> {
              log.error(ex.getMessage());
              return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage()));
            })
        .onErrorResume(
            Exception.class,
            ex -> {
              log.error("Error occurred while clearing the cache for client ID: {}", clientId, ex);
              return Mono.just(
                  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                      .body("Error occurred while clearing the cache for client ID: " + clientId));
            });
  }

  /**
   * Endpoint to manually clear the cache.
   *
   * @return a response indicating the cache has been cleared.
   */
  @PostMapping("/clear-cache")
  @Operation(summary = "Manually clear the cache")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Cache cleared successfully"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public Mono<ResponseEntity<String>> clearCache() {
    return cpdWSCache
        .clearCache()
        .thenReturn(ResponseEntity.ok("Cache cleared successfully"))
        .onErrorResume(
            Exception.class,
            ex -> {
              log.error("Error occurred while clearing the cache", ex);
              return Mono.just(
                  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                      .body("Error occurred while clearing the cache"));
            });
  }

  /**
   * Endpoint to retrieve cpd fields and corresponding data for a specific client if enabled in LMC.
   *
   * @param clientId the client ID to fetch cpd fields for.
   * @return a Flux stream with the cpd field and data entries of the client.
   */
  @GetMapping("/enabled-fields/{clientId}")
  @Operation(summary = "Retrieve cpd fields and their data for a specific client if enabled in LMC")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Retrieved field entries successfully"),
        @ApiResponse(responseCode = "400", description = "Bad Request"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error")
      })
  public Mono<List<CpdFieldAndData>> getCpdFieldAndDataForClient(@PathVariable Long clientId) {
    log.info("Fetching tag entries for client with id: {}", clientId);
    return cpdWSCache
        .getCpdFieldAndDataForClient(clientId)
        .doOnError(
            error ->
                log.error(
                    "Error occurred while fetching cpd fields and data for client id: {}",
                    clientId,
                    error));
  }
}
