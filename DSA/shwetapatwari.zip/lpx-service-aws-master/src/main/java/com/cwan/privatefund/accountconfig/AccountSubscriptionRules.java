package com.cwan.privatefund.accountconfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AccountSubscriptionRules {
  private Long id;
  private Long accountConfigId;
  private Long ruleId;
  private Long securityId;
}
