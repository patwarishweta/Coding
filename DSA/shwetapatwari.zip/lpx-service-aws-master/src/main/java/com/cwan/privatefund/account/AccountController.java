package com.cwan.privatefund.account;

import com.cwan.lpx.domain.Account;
import com.cwan.privatefund.basis.ws.model.Basis;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.SortedMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/accounts")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class AccountController {

  private final AccountService accountService;

  public AccountController(AccountService accountService) {
    this.accountService = accountService;
  }

  @GetMapping
  @Operation(summary = "Get user accounts")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Account.class))
            })
      })
  public Flux<Account> userAccounts(@RequestParam(name = "userId") Integer userId) {
    return accountService.retrieveUserAccounts(userId);
  }

  @GetMapping("/client")
  @Operation(summary = "Get client accounts")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ClientAccounts.class))
            })
      })
  public Flux<ClientAccounts> userClientAccounts(@RequestParam(name = "userId") Integer userId) {
    return accountService.getClientAccountsData(userId);
  }

  @GetMapping("/ultimateParentMap")
  @Operation(summary = "Get accounts of Ultimate Parents for a user")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = ClientAccounts.class))
            })
      })
  public Flux<UltimateParentsAccountMap> userUltimateParentAccountMap(
      @RequestParam(name = "userId") Integer userId) {
    return accountService.retrieveAccountsGroupedByUltimateParent(userId);
  }

  @GetMapping("/client/{clientId}")
  @Operation(summary = "Get all accounts for a client that the user has access to")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Account.class))
            })
      })
  public Flux<Account> getClientAccounts(
      @PathVariable("clientId") Long clientId, @RequestParam(name = "userId") Integer userId) {
    return accountService.getClientAccounts(clientId, userId);
  }

  @GetMapping("/ultimate/parent")
  @Operation(summary = "Get all Ultimate Parents that the user has access to")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = UltimateParents.class))
            })
      })
  public Flux<UltimateParents> getUltimateParents(@RequestParam(name = "userId") Integer userId) {
    return accountService.retrieveUltimateParents(userId);
  }

  @GetMapping("/bases/{accountId}")
  @Operation(summary = "Get all enabled bases for an account")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Basis.class))
            })
      })
  public Flux<Basis> getEnabledBases(
      @PathVariable("accountId") Long accountId, @RequestParam(name = "userId") Integer userId) {
    return accountService.getEnabledBases(accountId, userId);
  }

  @GetMapping("/client/getClientHierarchies")
  @Operation(summary = "Returns a map of client id to a sortedMap of level to clientId")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Map.class))
            })
      })
  public Map<Long, SortedMap<Integer, Long>> getClientHierarchies(
      @RequestParam(name = "clientIds") Collection<Long> clientIds) {
    return accountService.getClientHierarchyForClients(new HashSet<>(clientIds));
  }
}
