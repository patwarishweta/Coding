package com.cwan.privatefund.comment;

import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class CommentTransformer implements Function<CommentEntity, Comment> {

  @Override
  public Comment apply(CommentEntity commentEntity) {
    return Comment.builder()
        .id(commentEntity.getId())
        .message(commentEntity.getMessage())
        .documentId(commentEntity.getDocumentId())
        .createdBy(commentEntity.getCreatedBy())
        .createdOn(commentEntity.getTsCreatedOn())
        .modifiedBy(commentEntity.getModifiedBy())
        .modifiedOn(commentEntity.getTsModifiedOn())
        .build();
  }
}
