package com.cwan.privatefund.comment;

import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@Slf4j
@RequestMapping(value = "v1/comments")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class CommentController {

  private final CommentService commentService;

  public CommentController(CommentService commentService) {
    this.commentService = commentService;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add comments")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Added comments successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Comment.class))
            })
      })
  public Flux<Comment> addComments(
      @Parameter(description = "Comment Data") @RequestBody CommentRequest request) {
    return commentService.addComments(request.getComments());
  }

  @RequestMapping(value = "/document/{documentId}", method = RequestMethod.GET)
  @Operation(summary = "get comments by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Comment.class))
            })
      })
  public Flux<Comment> getCommentsByDocumentId(@PathVariable("documentId") Long documentId) {
    return commentService.getCommentsByDocumentId(documentId);
  }

  @DeleteMapping
  @Operation(summary = "Delete comments")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "204",
            description = "commentss deleted successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Comment.class))
            })
      })
  public void deleteCommentsById(
      @Parameter(description = "comment ids") @RequestParam Set<Long> ids) {
    commentService.deleteCommentsById(ids);
  }
}
