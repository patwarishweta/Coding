package com.cwan.privatefund.auth.service;

import org.springframework.security.core.Authentication;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public interface AuthenticationService {

  Mono<Authentication> getAuthentication(ServerWebExchange swe);
}
