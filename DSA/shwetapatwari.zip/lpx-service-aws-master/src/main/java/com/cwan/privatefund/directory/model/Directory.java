package com.cwan.privatefund.directory.model;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Directory implements Serializable {

  @Serial private static final long serialVersionUID = -1481448631713621662L;
  private Long id;
  private Long accountId;
  private String name;
  private Long parentDirectoryId;
  private Boolean isDisabled;
}
