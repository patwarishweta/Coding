package com.cwan.privatefund.calculated;

import static com.cwan.pbor.trans.Constants.TransactionTypes.GENERAL_ADJUSTMENT;
import static com.cwan.privatefund.constant.Constants.CUM_CONTRIBUTION_TYPES_LIST;
import static com.cwan.privatefund.constant.Constants.CUM_DISTRIBUTION_TYPES_LIST;
import static com.cwan.privatefund.constant.Constants.MISCELLANEOUS;
import static com.cwan.privatefund.constant.Constants.OPEN_TRAN_TYPES;
import static com.cwan.privatefund.constant.Constants.WATCHLIST_NAV_SUB_TYPE;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.calculated.model.BalanceAffect;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BalanceAffectService {

  private static final List<String> WATCHLIST_EFFECTING_TRANSACTIONS =
      List.of("CAPC", "CAPD", "INC", "DVD", "RCAP", "EXP");

  private static final List<BalanceType> ONLY_NON_HISTORIC_TRANSACTIONS =
      List.of(
          BalanceType.REPORTED_ENDING_NAV,
          BalanceType.REPORTED_TOTAL_COMMITMENT,
          BalanceType.FUNDED_COMMITMENT,
          BalanceType.REPORTED_RECALLABLE_DISTRIBUTION,
          BalanceType.WATCHLIST_ENDING_NAV,
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT,
          BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION,
          BalanceType.CUM_CONTRIBUTION);
  public static final LocalDateRange ALL_INCLUSIVE_FILTER_RANGE =
      LocalDateRanges.create(LocalDate.MIN, LocalDate.MAX);

  public List<BalanceAffect> getZeroedBalanceAffects(
      LocalDate date, Map<Long, Set<WatchlistEntity>> watchlistPeriod) {
    return getBalanceAffects(
        ALL_INCLUSIVE_FILTER_RANGE,
        Transaction.builder().type("").settleDate(date).build(),
        watchlistPeriod,
        false);
  }

  /**
   * Only the balance types BalanceType.REPORTED_ENDING_NAV, BalanceType.REPORTED_TOTAL_COMMITMENT,
   * BalanceType.FUNDED_COMMITMENT, BalanceType.REPORTED_RECALLABLE_DISTRIBUTION,
   * BalanceType.CUM_CONTRIBUTION, BalanceType.CUM_DISTRIBUTION, BalanceType.WATCHLIST_ENDING_NAV,
   * BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT are used to calculate balance affects from the
   * transaction so far.
   *
   * <p>SubscriptionStartDate is used to filter transactions "specially" based on balance type. See
   * PATH-2551 for correcting this.
   *
   * @param transaction
   * @return Mutable List containing all generated balance affects
   */
  public List<BalanceAffect> getBalanceAffects(
      LocalDateRange filterRange,
      Transaction transaction,
      Map<Long, Set<WatchlistEntity>> watchlistPeriods,
      boolean excludeHistoricContributionTransactions) {
    // TODO PATH-2551 Consistent filtering with subscription start date
    List<BalanceAffect> balanceAffects = new ArrayList<>();
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.REPORTED_ENDING_NAV,
            transaction.getSettleDate(),
            getNav(filterRange, transaction)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.WATCHLIST_ENDING_NAV,
            transaction.getSettleDate(),
            getWatchlistNav(filterRange, transaction, watchlistPeriods)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT,
            transaction.getSettleDate(),
            getWatchlistNavWithAdjustments(filterRange, transaction, watchlistPeriods)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.REPORTED_RECALLABLE_DISTRIBUTION,
            transaction.getSettleDate(),
            getRecallableDist(filterRange, transaction)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.REPORTED_TOTAL_COMMITMENT,
            transaction.getSettleDate(),
            getCommitment(filterRange, transaction, BalanceType.REPORTED_TOTAL_COMMITMENT)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.FUNDED_COMMITMENT,
            transaction.getSettleDate(),
            getCommitment(filterRange, transaction, BalanceType.FUNDED_COMMITMENT)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.CUM_CONTRIBUTION,
            transaction.getSettleDate(),
            getCumulativeContributions(
                transaction,
                BalanceType.CUM_CONTRIBUTION,
                excludeHistoricContributionTransactions)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION,
            transaction.getSettleDate(),
            getCumulativeContributions(
                transaction,
                BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION,
                excludeHistoricContributionTransactions)));
    balanceAffects.add(
        new BalanceAffect(
            BalanceType.CUM_DISTRIBUTION,
            transaction.getSettleDate(),
            getCumulativeDistributions(transaction)));
    return balanceAffects;
  }

  private boolean outOfRange(LocalDateRange filterRange, Transaction transaction) {
    return !OPEN_TRAN_TYPES.contains(transaction.getType())
        && !filterRange.contains(transaction.getSettleDate());
  }

  public static boolean watchlistFilter(
      Transaction transaction, Map<Long, Set<WatchlistEntity>> watchlistPeriods) {
    return ((withinWatchlistRange(transaction, watchlistPeriods)
            && isWatchlistSupportedTransaction(transaction))
        || (!withinWatchlistRange(transaction, watchlistPeriods)
            && !WATCHLIST_NAV_SUB_TYPE.equals(transaction.getSubType())));
  }

  private static boolean isWatchlistSupportedTransaction(Transaction transaction) {
    return WATCHLIST_EFFECTING_TRANSACTIONS.contains(transaction.getType())
        || WATCHLIST_NAV_SUB_TYPE.equals(transaction.getSubType());
  }

  private static boolean withinWatchlistRange(
      Transaction transaction, Map<Long, Set<WatchlistEntity>> watchlistPeriods) {
    // this is only needed to calculate non-watchlist transactions as all watchlist transactions
    // want to be included

    if (watchlistPeriods.containsKey(transaction.getAccount().getId())) {
      return watchlistPeriods.get(transaction.getAccount().getId()).stream()
          .anyMatch(
              watchlistEntity ->
                  watchlistEntity.getSecurityId().equals(transaction.getSecurity().getSecurityId())
                          && (transaction.getSettleDate().isAfter(watchlistEntity.getStartDate())
                              || transaction
                                  .getSettleDate()
                                  .isEqual(watchlistEntity.getStartDate()))
                          && (transaction.getSettleDate().isBefore(watchlistEntity.getEndDate()))
                      || transaction.getSettleDate().isEqual(watchlistEntity.getEndDate()));
    }
    return false;
  }

  private double getNav(LocalDateRange filterRange, Transaction transaction) {
    if ((nullableToBoolean(transaction.getIsHistoric())
            && ONLY_NON_HISTORIC_TRANSACTIONS.contains(BalanceType.REPORTED_ENDING_NAV))
        || outOfRange(filterRange, transaction)
        || WATCHLIST_NAV_SUB_TYPE.equals(transaction.getSubType())) {
      return 0.0;
    }

    return nullableToDouble(transaction.getNavImpact());
  }

  private double getWatchlistNav(
      LocalDateRange filterRange,
      Transaction transaction,
      Map<Long, Set<WatchlistEntity>> watchlistPeriods) {
    if ((nullableToBoolean(transaction.getIsHistoric())
            && ONLY_NON_HISTORIC_TRANSACTIONS.contains(BalanceType.WATCHLIST_ENDING_NAV))
        || outOfRange(filterRange, transaction)
        || transaction.getAccount() == null
        || !withinWatchlistRange(transaction, watchlistPeriods)
        || !WATCHLIST_NAV_SUB_TYPE.equals(transaction.getSubType())) {
      return 0.0;
    }

    return nullableToDouble(transaction.getNavImpact());
  }

  private double getWatchlistNavWithAdjustments(
      LocalDateRange filterRange,
      Transaction transaction,
      Map<Long, Set<WatchlistEntity>> watchlistPeriods) {
    if ((nullableToBoolean(transaction.getIsHistoric())
            && ONLY_NON_HISTORIC_TRANSACTIONS.contains(
                BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT))
        || outOfRange(filterRange, transaction)
        || transaction.getAccount() == null
        || !watchlistFilter(transaction, watchlistPeriods)) {
      return 0.0;
    }

    return nullableToDouble(transaction.getNavImpact());
  }

  private double getRecallableDist(LocalDateRange filterRange, Transaction transaction) {
    if ((nullableToBoolean(transaction.getIsHistoric())
            && ONLY_NON_HISTORIC_TRANSACTIONS.contains(
                BalanceType.REPORTED_RECALLABLE_DISTRIBUTION))
        || outOfRange(filterRange, transaction)) {
      return 0.0;
    }

    return nullableToDouble(transaction.getRecallableImpact());
  }

  private double getCommitment(
      LocalDateRange filterRange, Transaction transaction, BalanceType balanceType) {
    if (nullableToBoolean(transaction.getIsHistoric())
        && ONLY_NON_HISTORIC_TRANSACTIONS.contains(balanceType)) {
      return 0.0;
    }

    double fundedCommitment = nullableToDouble(transaction.getFundedCommitmentImpact());
    double totalCommitment = nullableToDouble(transaction.getTotalCommitmentImpact());
    double value = 0.0;
    if (BalanceType.REPORTED_TOTAL_COMMITMENT.equals(balanceType)) {
      // total commitment is ONLY affected by commitment adjustments as per the LMC ui
      value = totalCommitment;
    } else if (BalanceType.FUNDED_COMMITMENT.equals(balanceType)) {

      if (outOfRange(filterRange, transaction)) {
        value = 0.0;
      } else {
        value = fundedCommitment;
      }
    }
    return value;
  }

  private double negate(double val) {
    // prevent -0.0
    return val == 0.0 ? 0.0 : -val;
  }

  private double getCumulativeContributions(
      Transaction transaction,
      BalanceType balanceType,
      boolean excludeHistoricContributionTransactions) {
    boolean isHistoric = nullableToBoolean(transaction.getIsHistoric());

    if (!CUM_CONTRIBUTION_TYPES_LIST.contains(transaction.getType())) {
      return 0.0; // not a  contribution transaction type
    }

    // needs to be non-historic for these balance types, as well as a transaction considered for
    // contributions
    if (isHistoric
        && ONLY_NON_HISTORIC_TRANSACTIONS.contains(balanceType)
        && excludeHistoricContributionTransactions) {
      return 0.0;
    }

    if (balanceType == BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION) {
      if (transaction.getType().equals(GENERAL_ADJUSTMENT)
          && transaction.getSubType() != null
          && transaction.getSubType().equalsIgnoreCase(MISCELLANEOUS)) {
        if (excludeHistoricContributionTransactions) {
          // this is a way to account for when historic transactions aren't considered, but still
          // set a value for historic contributions
          return nullableToDouble(transaction.getFundedCommitmentImpact());
        }
        // this shouldn't be used if we're considering historic transactions, as it should use the
        // default logic for calculating contributions
        return 0.0;
      }
    }

    if (balanceType == BalanceType.CUM_CONTRIBUTION) {
      return nullableToDouble(transaction.getCashImpact());
    }
    return 0.0; // didn't meet any conditions to set a value
  }

  private double getCumulativeDistributions(Transaction transaction) {
    double value = 0.0;

    if (nullableToBoolean(transaction.getIsHistoric())
        && ONLY_NON_HISTORIC_TRANSACTIONS.contains(BalanceType.CUM_DISTRIBUTION)) {
      return value;
    }

    if (CUM_DISTRIBUTION_TYPES_LIST.contains(transaction.getType())) {
      value = nullableToDouble(transaction.getCashImpact());
    }
    return value;
  }

  private double nullableToDouble(Double value) {
    return value == null ? 0.0d : value.doubleValue();
  }

  private boolean nullableToBoolean(Boolean value) {
    return value != null && value.booleanValue();
  }
}
