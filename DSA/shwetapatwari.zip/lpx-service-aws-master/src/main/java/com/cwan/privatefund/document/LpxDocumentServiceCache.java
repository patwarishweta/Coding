package com.cwan.privatefund.document;

import static com.cwan.privatefund.constant.RedisConstants.DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE;

import com.cwan.privatefund.document.model.DocumentTypeData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class LpxDocumentServiceCache {

  private final LpxDocumentServiceClient lpxDocumentServiceClient;
  private final RedisTemplate redisTemplate;

  public LpxDocumentServiceCache(
      LpxDocumentServiceClient lpxDocumentServiceClient, RedisTemplate redisTemplate) {
    this.lpxDocumentServiceClient = lpxDocumentServiceClient;
    this.redisTemplate = redisTemplate;
  }

  public Mono<DocumentTypeData> getDocumentTypeData(String documentType) {
    DocumentTypeData documentTypeData =
        (DocumentTypeData)
            redisTemplate.opsForHash().get(DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE, documentType);
    if (documentTypeData != null) {
      return Mono.just(documentTypeData);
    }
    return lpxDocumentServiceClient
        .getAllDocumentTypeData()
        .flatMap(
            documentTypesMap -> {
              if (documentTypesMap.containsKey(documentType)) {
                documentTypesMap
                    .entrySet()
                    .forEach(
                        entry ->
                            redisTemplate
                                .opsForHash()
                                .put(
                                    DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE,
                                    entry.getKey(),
                                    entry.getValue()));
                return Mono.just(documentTypesMap.get(documentType));
              }
              return Mono.error(
                  new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid document type."));
            });
  }
}
