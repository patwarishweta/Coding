package com.cwan.privatefund.directory;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class DirectoryException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = 6161557563554295822L;

  public DirectoryException(HttpStatus status, String msg, Throwable e) {
    super(status, msg, e);
  }
}
