package com.cwan.privatefund.balance;

import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.balance.model.BalanceRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.time.LocalDate;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
@RequestMapping(value = "v1/balances")
@ApiResponses(
    value = {
      @ApiResponse(responseCode = "400", description = "IMPROPER_DATA_PROVIDED"),
      @ApiResponse(responseCode = "404", description = "RESOURCE_NOT_FOUND"),
      @ApiResponse(responseCode = "500", description = "INTERNAL_SERVER_ERROR"),
    })
public class BalanceController {

  private final LpxBalanceService lpxBalanceService;

  BalanceController(LpxBalanceService lpxBalanceService) {
    this.lpxBalanceService = lpxBalanceService;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  @Operation(summary = "Add balance")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Add Balance successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Balance.class))
            })
      })
  public Mono<Void> addBalance(
      @Parameter(description = "Balance Data") @RequestBody BalanceRequest request,
      @RequestParam(value = "generateActivity", defaultValue = "true") String generateActivity) {
    return lpxBalanceService.addBalance(request, generateActivity);
  }

  @GetMapping
  @Operation(summary = "Get balances")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = BalanceRequest.class))
            })
      })
  public Flux<Balance> getBalanceByBalanceId(
      @Parameter(description = "Balance Ids") @RequestParam Set<Long> ids) {
    return lpxBalanceService.getBalanceByBalanceId(ids);
  }

  @DeleteMapping
  @Operation(summary = "Set balance KnowledgeEndDate to today")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "balance KnowledgeEndDate set successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Balance.class))
            })
      })
  public Mono<Void> deleteBalanceByBalanceId(
      @Parameter(description = "balance ids") @RequestParam Set<Long> ids) {
    return lpxBalanceService.deleteBalanceByBalanceId(ids);
  }

  @PutMapping
  @Operation(summary = "update balance")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "balances updated successfully",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Balance.class))
            })
      })
  public Mono<Void> updateBalances(
      @Parameter(description = "balance update request") @RequestBody
          BalanceRequest balanceRequest) {
    return lpxBalanceService.updateBalances(balanceRequest);
  }

  @RequestMapping(value = "/document/{documentId}", method = RequestMethod.GET)
  @Operation(summary = "get balances by document id")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Balance.class))
            })
      })
  public Flux<Balance> getBalancesByDocumentId(@PathVariable("documentId") Long documentId) {
    return lpxBalanceService.getBalancesByDocumentId(documentId);
  }

  @RequestMapping(value = "/account", method = RequestMethod.GET)
  @Operation(summary = "get account balances by account id, entry date, and knowledge date")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            content = {
              @Content(
                  mediaType = MediaType.APPLICATION_JSON_VALUE,
                  schema = @Schema(implementation = Transaction.class))
            })
      })
  public Flux<Balance> getAccountBalances(
      @RequestParam("accountId") Long accountId,
      @RequestParam("entryDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate entryDate,
      @RequestParam("knowledgeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
          LocalDate knowledgeDate) {
    return lpxBalanceService.getAccountBalances(accountId, entryDate, knowledgeDate);
  }
}
