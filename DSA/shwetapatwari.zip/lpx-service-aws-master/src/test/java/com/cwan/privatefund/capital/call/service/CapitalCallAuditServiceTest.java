package com.cwan.privatefund.capital.call.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallAuditServiceTest {

  @Mock private CapitalCalls capitalCalls;
  private CapitalCallAuditService capitalCallAuditService;

  @BeforeEach
  void setUp() {
    capitalCallAuditService = new CapitalCallAuditService(capitalCalls);
  }

  @Test
  void testGetAuditLog_success() {
    var documentId = 100L;
    var capitalCallAuditLog = CapitalCallAuditLog.builder().documentId(documentId).build();
    when(capitalCalls.getCapitalCallAuditByDocument(documentId))
        .thenReturn(Mono.just(capitalCallAuditLog));
    StepVerifier.create(capitalCallAuditService.getAuditLog(documentId))
        .expectNext(capitalCallAuditLog)
        .verifyComplete();
    verify(capitalCalls, times(1)).getCapitalCallAuditByDocument(documentId);
  }

  @Test
  void testGetAuditLog_error() {
    var documentId = 100L;
    when(capitalCalls.getCapitalCallAuditByDocument(documentId))
        .thenReturn(Mono.error(new RuntimeException("Unexpected error")));
    StepVerifier.create(capitalCallAuditService.getAuditLog(documentId))
        .expectError(RuntimeException.class)
        .verify();
    verify(capitalCalls, times(1)).getCapitalCallAuditByDocument(documentId);
  }
}
