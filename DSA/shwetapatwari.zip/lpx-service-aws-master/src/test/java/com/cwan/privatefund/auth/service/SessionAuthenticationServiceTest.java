package com.cwan.privatefund.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.cwan.privatefund.auth.ws.AuthWSCache;
import java.util.Collections;
import java.util.Objects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public class SessionAuthenticationServiceTest {

  @Mock private AuthWSCache authWSCache;
  @Mock private AuthorityService authorityService;
  @Mock private ServerWebExchange swe;
  @Mock private ServerHttpRequest request;
  @Mock private MultiValueMap<String, HttpCookie> cookieMap;

  private static final String APPLICATION_NAME = "lpx-service-test";

  private SessionAuthenticationService instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(swe.getRequest()).thenReturn(request);
    when(request.getCookies()).thenReturn(cookieMap);
    when(cookieMap.getFirst(eq("USER_ID"))).thenReturn(new HttpCookie("USER_ID", "1337"));
    when(cookieMap.getFirst(eq("SESSION_ID")))
        .thenReturn(new HttpCookie("SESSION_ID", "elitehackzor"));
    when(cookieMap.getFirst(eq("PRIVATE_LABEL_ID")))
        .thenReturn(new HttpCookie("PRIVATE_LABEL_ID", "42"));
    when(authorityService.getAuthorities(any(ServerWebExchange.class)))
        .thenReturn(Collections.emptySet());

    instance = new SessionAuthenticationService(authWSCache, APPLICATION_NAME, authorityService);
  }

  @Test
  public void should_get_valid_authentication() {
    when(authWSCache.isSessionValid(any(SessionValidRequest.class))).thenReturn(Mono.just(true));
    var actual = instance.getAuthentication(swe).block();
    assertTrue(Objects.requireNonNull(actual).isAuthenticated());
  }

  @Test
  public void should_get_invalid_authentication() {
    when(authWSCache.isSessionValid(any(SessionValidRequest.class))).thenReturn(Mono.just(false));
    var actual = instance.getAuthentication(swe).block();
    assertFalse(Objects.requireNonNull(actual).isAuthenticated());
  }

  @Test
  public void should_return_empty_mono_if_null() {
    when(cookieMap.getFirst(anyString())).thenReturn(null);
    var actual = instance.getAuthentication(swe);
    assertEquals(Mono.empty(), actual);
  }
}
