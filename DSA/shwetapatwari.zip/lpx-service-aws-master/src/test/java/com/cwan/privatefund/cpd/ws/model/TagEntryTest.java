package com.cwan.privatefund.cpd.ws.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

class TagEntryTest {

  @Test
  void testRecordInitializationUsingBuilder() {
    var entry =
        TagEntry.builder()
            .fieldId(1)
            .clientId(2L)
            .tagId(3)
            .accountId(4L)
            .reportDate(5)
            .overrideLevel(6)
            .endDate(7)
            .cpdValue("test")
            .dataSource(8)
            .build();
    assertNotNull(entry);
    assertEquals(1, entry.fieldId());
    assertEquals(2, entry.clientId());
    assertEquals(3, entry.tagId());
    assertEquals(4, entry.accountId());
    assertEquals(5, entry.reportDate());
    assertEquals(6, entry.overrideLevel());
    assertEquals(7, entry.endDate());
    assertEquals("test", entry.cpdValue());
    assertEquals(8, entry.dataSource());
  }

  @Test
  void testToString() {
    var entry =
        TagEntry.builder()
            .fieldId(1)
            .clientId(2L)
            .tagId(3)
            .accountId(4L)
            .reportDate(5)
            .overrideLevel(6)
            .endDate(7)
            .cpdValue("test")
            .dataSource(8)
            .build();
    var expected =
        "TagEntry[fieldId=1, clientId=2, tagId=3, accountId=4, reportDate=5, overrideLevel=6, endDate=7, cpdValue=test, dataSource=8]";
    assertEquals(expected, entry.toString());
  }

  @Test
  void testEqualsAndHashCode() {
    var entry1 =
        TagEntry.builder()
            .fieldId(1)
            .clientId(2L)
            .tagId(3)
            .accountId(4L)
            .reportDate(5)
            .overrideLevel(6)
            .endDate(7)
            .cpdValue("test")
            .dataSource(8)
            .build();
    var entry2 =
        TagEntry.builder()
            .fieldId(1)
            .clientId(2L)
            .tagId(3)
            .accountId(4L)
            .reportDate(5)
            .overrideLevel(6)
            .endDate(7)
            .cpdValue("test")
            .dataSource(8)
            .build();
    var entry3 =
        TagEntry.builder()
            .fieldId(10)
            .clientId(20L)
            .tagId(30)
            .accountId(40L)
            .reportDate(50)
            .overrideLevel(60)
            .endDate(70)
            .cpdValue("different")
            .dataSource(80)
            .build();
    assertEquals(entry1, entry2);
    assertEquals(entry1.hashCode(), entry2.hashCode());
    assertNotEquals(entry1, entry3);
    assertNotEquals(entry1.hashCode(), entry3.hashCode());
  }

  @Test
  void testToBuilder() {
    var original =
        TagEntry.builder()
            .fieldId(1)
            .clientId(2L)
            .tagId(3)
            .accountId(4L)
            .reportDate(5)
            .overrideLevel(6)
            .endDate(7)
            .cpdValue("test")
            .dataSource(8)
            .build();
    var fromBuilder = original.toBuilder().cpdValue("modified").build();
    assertNotEquals(original, fromBuilder);
    assertEquals("modified", fromBuilder.cpdValue());
  }
}
