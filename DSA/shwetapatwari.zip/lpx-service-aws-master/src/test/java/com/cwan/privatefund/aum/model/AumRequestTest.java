package com.cwan.privatefund.aum.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.Aum;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class AumRequestTest {

  @Test
  void testAumRequest_withMultipleAums() {
    Aum mockAum1 = Mockito.mock(Aum.class);
    Aum mockAum2 = Mockito.mock(Aum.class);
    Set<Aum> aums = Set.of(mockAum1, mockAum2);

    AumRequest aumRequest = new AumRequest(aums);

    assertEquals(aums, aumRequest.getAums());
  }

  @Test
  void testAumRequest_withSingleAum() {
    Aum mockAum = Mockito.mock(Aum.class);
    Set<Aum> aums = Set.of(mockAum);

    AumRequest aumRequest = new AumRequest(aums);

    assertEquals(aums, aumRequest.getAums());
  }

  @Test
  void testAumRequest_withNoAums() {
    AumRequest aumRequest = new AumRequest(null);

    assertEquals(null, aumRequest.getAums());
  }
}
