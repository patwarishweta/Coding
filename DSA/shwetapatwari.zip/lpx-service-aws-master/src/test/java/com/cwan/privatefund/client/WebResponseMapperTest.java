package com.cwan.privatefund.client;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import java.io.Serial;
import java.net.UnknownHostException;
import java.util.function.Function;
import java.util.function.Predicate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

class WebResponseMapperTest {

  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private ParameterizedTypeReference<Object> parameterizedTypeReference;
  private WebResponseMapper<WebResponseMapperTestException> instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance =
        new WebResponseMapper<>() {
          @Override
          protected WebResponseMapperTestException getException(String msg) {
            return new WebResponseMapperTestException(msg);
          }
        };
  }

  @Test
  void should_throw_exception_4xx_test_parameterized_type() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToType(responseSpecMock, parameterizedTypeReference).block());
  }

  @Test
  void should_throw_exception_4xx_test_class() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToClass(responseSpecMock, Object.class).block());
  }

  @Test
  void hould_throw_exception_5xx_test_parameterized_type() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToType(responseSpecMock, parameterizedTypeReference).block());
  }

  @Test
  void should_throw_exception_5xx_test_class() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToClass(responseSpecMock, Object.class).block());
  }

  @Test
  void should_throw_exception_on_error_resume_test_parameterized_type() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(eq(parameterizedTypeReference)))
        .thenReturn(Mono.error(new RuntimeException("Exception Testing ")));
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToType(responseSpecMock, parameterizedTypeReference).block());
  }

  @Test
  void should_throw_exception_on_error_resume_test_class() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(eq(Object.class)))
        .thenReturn(Mono.error(new RuntimeException("Exception Testing ")));
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToClass(responseSpecMock, Object.class).block());
  }

  @Test
  void should_throw_exception_on_error_resume_unknownhost_test_parameterized_type() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(eq(parameterizedTypeReference)))
        .thenReturn(Mono.error(new UnknownHostException("Exception UnknownHost Testing ")));
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToType(responseSpecMock, parameterizedTypeReference).block());
  }

  @Test
  void should_throw_exception_on_error_resume_unknownhost_test_class() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(eq(Object.class)))
        .thenReturn(Mono.error(new UnknownHostException("Exception UnknownHost Testing ")));
    assertThrows(
        WebResponseMapperTestException.class,
        () -> instance.mapToClass(responseSpecMock, Object.class).block());
  }

  private static class WebResponseMapperTestException extends RuntimeException {

    @Serial private static final long serialVersionUID = -8387350956837957477L;

    public WebResponseMapperTestException(String msg) {
      super(msg);
    }
  }
}
