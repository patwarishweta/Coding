package com.cwan.privatefund.capital.call.management.service;

import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.ACCOUNT_ID;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.CLIENT_ID;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.CLIENT_NAME;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.USER_ID;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.UUID_BANK;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.Client;
import com.cwan.pbor.document.capital.call.management.api.CapitalCallManagement;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.helper.LpxCapitalCallManagementHelper;
import com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class LpxCapitalCallManagementServiceTest {

  @Mock private SecurityContextUserService securityContextUserService;
  @Mock private AccountService accountService;
  @Mock private BusinessWSCache businessWSCache;
  @Mock private CapitalCallManagement capitalCallManagement;
  @InjectMocks private LpxCapitalCallManagementService service;

  @BeforeEach
  void setUp() {
    lenient()
        .when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(CapitalCallManagementTestHelper.getSampleUser()));
    lenient()
        .when(securityContextUserService.validateAndRetrieveUserDetails((long) USER_ID))
        .thenReturn(Mono.just(CapitalCallManagementTestHelper.getSampleUser()));
    lenient()
        .when(accountService.retrieveUserAccessibleAccountIds(USER_ID))
        .thenReturn(Mono.just(Set.of(CLIENT_ID)));
    lenient()
        .when(accountService.getAccountsData(Set.of(ACCOUNT_ID)))
        .thenReturn(Mono.just(List.of(CapitalCallManagementTestHelper.getSampleAccount())));
    lenient()
        .when(businessWSCache.getClientData(CLIENT_ID))
        .thenReturn(Mono.just(Client.builder().name(CLIENT_NAME).build()));
    lenient()
        .when(capitalCallManagement.deleteBank(UUID_BANK, USER_ID.longValue()))
        .thenReturn(true);
  }

  @Test
  void testFetchBanksByClient() {
    when(capitalCallManagement.fetchBanksByClient(CLIENT_ID)).thenReturn(Collections.emptyList());
    StepVerifier.create(service.fetchBanksByClient(CLIENT_ID)).expectNextCount(0).verifyComplete();
  }

  @Test
  void testCreateBank() {
    var bankRequest = CapitalCallManagementTestHelper.getSampleBankRequest();
    var createdBank = CapitalCallManagementTestHelper.getSampleBank();
    when(capitalCallManagement.createBank(any(Bank.class))).thenReturn(createdBank);
    StepVerifier.create(service.createBank(bankRequest))
        .expectNextMatches(
            bankResponse ->
                bankResponse
                    .bankUuid()
                    .equals(CapitalCallManagementTestHelper.getSampleBankResponse().bankUuid()))
        .verifyComplete();
  }

  @Test
  void testFetchBank() {
    var bank = CapitalCallManagementTestHelper.getSampleBank();
    when(capitalCallManagement.fetchBank(UUID_BANK)).thenReturn(Optional.ofNullable(bank));
    StepVerifier.create(service.fetchBank(UUID_BANK))
        .expectNextMatches(
            bankResponse ->
                bankResponse
                    .bankUuid()
                    .equals(CapitalCallManagementTestHelper.getSampleBankResponse().bankUuid()))
        .verifyComplete();
  }

  @Test
  void testDeleteBank() {
    var bank = CapitalCallManagementTestHelper.getSampleBank();
    when(capitalCallManagement.fetchBank(UUID_BANK)).thenReturn(Optional.ofNullable(bank));
    StepVerifier.create(service.deleteBank(UUID_BANK)).verifyComplete();
  }

  @Test
  void testCreateBankAccount() {
    var bankAccountRequest = CapitalCallManagementTestHelper.getSampleBankAccountRequest();
    when(capitalCallManagement.fetchBank(bankAccountRequest.bankUuid()))
        .thenReturn(Optional.of(CapitalCallManagementTestHelper.getSampleBank()));
    when(accountService.getAccountWithClientData(bankAccountRequest.accountId()))
        .thenReturn(Mono.just(CapitalCallManagementTestHelper.getSampleAccount()));
    when(capitalCallManagement.createBankAccount(any()))
        .thenReturn(CapitalCallManagementTestHelper.getSampleBankAccount());
    StepVerifier.create(service.createBankAccount(bankAccountRequest))
        .expectNextMatches(
            bankAccountResponse ->
                bankAccountResponse.equals(
                    CapitalCallManagementTestHelper.getSampleBankAccountResponse()))
        .verifyComplete();
  }

  @Test
  void testFetchBankAccountsByAccount() {
    when(capitalCallManagement.fetchBankAccountsByAccount(ACCOUNT_ID))
        .thenReturn(List.of(CapitalCallManagementTestHelper.getSampleBankAccount()));
    StepVerifier.create(service.fetchBankAccountsByAccount(ACCOUNT_ID))
        .expectNextMatches(
            bankAccountResponse ->
                bankAccountResponse.equals(
                    CapitalCallManagementTestHelper.getSampleBankAccountResponse()))
        .verifyComplete();
  }

  @Test
  void testFetchBankAccountsByClient() {
    when(capitalCallManagement.fetchBankAccountsByClient(CLIENT_ID))
        .thenReturn(List.of(CapitalCallManagementTestHelper.getSampleBankAccount()));
    StepVerifier.create(service.fetchBankAccountsByClient(CLIENT_ID))
        .expectNextMatches(
            bankAccountResponse ->
                bankAccountResponse.equals(
                    CapitalCallManagementTestHelper.getSampleBankAccountResponse()))
        .verifyComplete();
  }

  @Test
  void testFetchBankAccount() {
    when(capitalCallManagement.fetchBankAccount(UUID_BANK))
        .thenReturn(Optional.of(CapitalCallManagementTestHelper.getSampleBankAccount()));
    StepVerifier.create(service.fetchBankAccount(UUID_BANK))
        .expectNextMatches(
            bankAccountResponse ->
                bankAccountResponse.equals(
                    CapitalCallManagementTestHelper.getSampleBankAccountResponse()))
        .verifyComplete();
  }

  @Test
  void testDeleteBankAccount() {
    when(capitalCallManagement.fetchBankAccount(UUID_BANK))
        .thenReturn(Optional.of(CapitalCallManagementTestHelper.getSampleBankAccount()));
    when(capitalCallManagement.deleteBankAccount(UUID_BANK, USER_ID.longValue())).thenReturn(true);
    StepVerifier.create(service.deleteBankAccount(UUID_BANK)).expectNext(true).verifyComplete();
  }

  @Test
  void testFetchBlacklistedBanksByClient() {
    var bankBlacklist = CapitalCallManagementTestHelper.getSampleBankBlacklist();
    when(capitalCallManagement.fetchBankBlacklistsByClient(CLIENT_ID))
        .thenReturn(List.of(bankBlacklist));
    StepVerifier.create(service.fetchBlacklistedBanksByClient(CLIENT_ID))
        .expectNextMatches(
            blacklistResponse ->
                blacklistResponse.bankUuid().equals(bankBlacklist.bank().bankUuid()))
        .verifyComplete();
  }

  @Test
  void testAddBankToBlacklist() {
    var bank = CapitalCallManagementTestHelper.getSampleBank();
    when(capitalCallManagement.fetchBank(UUID_BANK)).thenReturn(Optional.of(bank));
    var bankBlacklist = CapitalCallManagementTestHelper.getSampleBankBlacklist();
    when(capitalCallManagement.createBankBlacklist(any())).thenReturn(bankBlacklist);
    StepVerifier.create(service.addBankToBlacklist(UUID_BANK))
        .expectNextMatches(
            blacklistResponse ->
                blacklistResponse.bankUuid().equals(bankBlacklist.bank().bankUuid()))
        .verifyComplete();
  }

  @Test
  void testFetchBlacklistedBank() {
    var bankBlacklist = CapitalCallManagementTestHelper.getSampleBankBlacklist();
    when(capitalCallManagement.fetchBankBlacklist(UUID_BANK))
        .thenReturn(Optional.of(bankBlacklist));
    StepVerifier.create(service.fetchBlacklistedBank(UUID_BANK))
        .expectNextMatches(
            blacklistResponse ->
                blacklistResponse.bankUuid().equals(bankBlacklist.bank().bankUuid()))
        .verifyComplete();
  }

  @Test
  void testRemoveBankFromBlacklist() {
    var bankBlacklist = CapitalCallManagementTestHelper.getSampleBankBlacklist();
    when(capitalCallManagement.fetchBankBlacklist(UUID_BANK))
        .thenReturn(Optional.of(bankBlacklist));
    when(capitalCallManagement.deleteBankBlacklist(UUID_BANK, USER_ID.longValue()))
        .thenReturn(true);
    StepVerifier.create(service.removeBankFromBlacklist(UUID_BANK)).verifyComplete();
  }

  @Test
  void testCheckUserAccessToAccount() {
    var userAccounts = Set.of(1L, 2L, 3L);
    StepVerifier.create(
            LpxCapitalCallManagementHelper.checkUserAccessToAccount(
                userAccounts, ACCOUNT_ID, USER_ID))
        .verifyComplete();
    var invalidAccountId = 4L;
    StepVerifier.create(
            LpxCapitalCallManagementHelper.checkUserAccessToAccount(
                userAccounts, invalidAccountId, USER_ID))
        .expectError(AccessDeniedException.class)
        .verify();
  }

  @Test
  void testDeleteBankAccountWithValidation() {
    var bankAccount = CapitalCallManagementTestHelper.getSampleBankAccount();
    var user = CapitalCallManagementTestHelper.getSampleUser();
    var userAccounts = Set.of(ACCOUNT_ID);
    when(capitalCallManagement.deleteBankAccount(UUID_BANK, USER_ID.longValue())).thenReturn(true);
    StepVerifier.create(
            service.deleteBankAccountWithValidation(UUID_BANK, bankAccount, user, userAccounts))
        .expectNext(true)
        .verifyComplete();
    var invalidUserAccounts = Set.of(4L, 5L);
    StepVerifier.create(
            service.deleteBankAccountWithValidation(
                UUID_BANK, bankAccount, user, invalidUserAccounts))
        .expectError(AccessDeniedException.class)
        .verify();
  }

  @Test
  void testDeleteBankAndLogOutcome() {
    var user = CapitalCallManagementTestHelper.getSampleUser();
    when(capitalCallManagement.deleteBank(UUID_BANK, USER_ID.longValue())).thenReturn(true);
    StepVerifier.create(service.deleteBankAndLogOutcome(UUID_BANK, user)).verifyComplete();
    when(capitalCallManagement.deleteBank(UUID_BANK, USER_ID.longValue())).thenReturn(false);
    StepVerifier.create(service.deleteBankAndLogOutcome(UUID_BANK, user))
        .expectError(RuntimeException.class)
        .verify();
  }

  @Test
  void testProcessActionWithClientValidation() {
    BiFunction<User, Client, Flux<String>> action = (user, client) -> Flux.just("Success");
    StepVerifier.create(service.processActionWithClientValidation(CLIENT_ID, action))
        .expectNext("Success")
        .verifyComplete();
    var invalidClientId = 4L;
    StepVerifier.create(service.processActionWithClientValidation(invalidClientId, action))
        .expectError(AccessDeniedException.class)
        .verify();
  }

  @Test
  void testDeleteBankAccountWithValidation_Failure() {
    var bankAccountUuid = "bank-account-uuid";
    var bankAccount = CapitalCallManagementTestHelper.getSampleBankAccount();
    var user = CapitalCallManagementTestHelper.getSampleUser();
    var userAccounts = Set.of(bankAccount.accountId());
    when(capitalCallManagement.deleteBankAccount(bankAccountUuid, user.getId().longValue()))
        .thenReturn(false);
    StepVerifier.create(
            service.deleteBankAccountWithValidation(
                bankAccountUuid, bankAccount, user, userAccounts))
        .expectErrorSatisfies(
            throwable -> {
              assertThat(throwable).isInstanceOf(RuntimeException.class);
              assertThat(throwable.getMessage()).isEqualTo("Failed to delete bank account.");
            })
        .verify();
  }
}
