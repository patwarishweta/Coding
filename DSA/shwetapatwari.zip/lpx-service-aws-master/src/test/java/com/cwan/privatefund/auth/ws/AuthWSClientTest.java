package com.cwan.privatefund.auth.ws;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import com.cwan.privatefund.auth.AuthenticationException;
import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.cwan.privatefund.client.WebResponseMapper;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

public class AuthWSClientTest {

  @Mock private WebClient webClient;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private WebResponseMapper<AuthenticationException> responseMapper;
  private static final SessionValidRequest REQUEST =
      new SessionValidRequest("userId", "privateLabelId", "sessionId", "appication");
  private AuthWSClient instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(webClient.get()).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.uri(any(Function.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.accept(MediaType.APPLICATION_JSON))
        .thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.retrieve()).thenReturn(responseSpecMock);
    instance = new AuthWSClient(webClient, responseMapper);
  }

  @Test
  public void should_return_session_is_valid() {
    when(responseMapper.mapToClass(eq(responseSpecMock), eq(Boolean.class)))
        .thenReturn(Mono.just(true));
    var actual = instance.isSessionValid(REQUEST).block();
    assertEquals(Boolean.TRUE, actual);
  }
}
