package com.cwan.privatefund.business.ws;

import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_ACCOUNT_DATA_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_EXPANDED_ACCOUNTS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_USER_DETAILS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.business.ws.model.User;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import reactor.core.publisher.Mono;

class BusinessWSCacheTest {

  @Mock private BusinessWSClient businessWSClient;
  @Mock private RedisTemplate redisTemplate;
  @Mock private HashOperations hashOperations;
  private static final Integer USER_ID = 9;
  private static final Long ACCOUNT_ID = 42L;
  private static final long CLIENT_ID = 24601L;
  private static final List<Long> EXPANDED_ACCOUNTS = List.of(1L, 2L, 3L);
  private static final User USER = User.builder().id(USER_ID).build();
  private static final Map<Long, Boolean> ACCOUNT_ACCESS_MAP = Map.of(ACCOUNT_ID, true);
  private static final BusinessAccount ACCOUNT =
      BusinessAccount.builder()
          .id(ACCOUNT_ID)
          .aggregate(true)
          .simpleAccountIds(List.of(1L, 2L, 3L))
          .ultimateParentId(1L)
          .build();
  private static final List<BusinessAccount> ACCOUNTS = List.of(ACCOUNT);
  private static final Set<Long> ACCOUNT_IDS = Set.of(ACCOUNT_ID);
  private BusinessWSCache instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance = new BusinessWSCache(businessWSClient, redisTemplate);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
    when(hashOperations.get(eq(BUSINESS_EXPANDED_ACCOUNTS_CACHE), any()))
        .thenReturn(EXPANDED_ACCOUNTS);
    when(hashOperations.get(eq(BUSINESS_ACCOUNT_DATA_CACHE), any())).thenReturn(ACCOUNT);
    when(hashOperations.get(eq(BUSINESS_USER_DETAILS_CACHE), any())).thenReturn(USER);
    when(hashOperations.get(eq(BUSINESS_USER_HAS_ACCOUNTS_ACCESSS_CACHE), any()))
        .thenReturn(ACCOUNT_IDS);
    when(hashOperations.get(eq(BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE), any()))
        .thenReturn(EXPANDED_ACCOUNTS);
    when(hashOperations.get(eq(BUSINESS_CLIENT_ULTIMATE_PARENT_CACHE_BY_ACC_ID), any()))
        .thenReturn(new TreeMap<>(Map.of(1, 1L)));
    when(businessWSClient.getAccountsInformation(eq(ACCOUNT_IDS))).thenReturn(Mono.just(ACCOUNTS));
    when(businessWSClient.getUltimateParentMapFromAccounts(any()))
        .thenReturn(Mono.just(Map.of(42L, new TreeMap<>(Map.of(1, 1L)))));
    when(businessWSClient.getUltimateParentMapFromClients(any()))
        .thenReturn(Mono.just(Map.of(24601L, new TreeMap<>(Map.of(1, 24601L)))));
  }

  @Test
  void should_get_account_data_by_account_id_from_cache() {
    var actual = instance.getAccountData(ACCOUNT_ID).block();
    assertEquals(ACCOUNT, actual);
    verify(businessWSClient, times(0)).getAccountInformation(anyLong());
  }

  @Test
  void should_get_ultimate_parent_map_by_client_id_from_cache() {
    var actual = instance.ultimateParentCacheByClientId(Set.of(CLIENT_ID)).block();
    assertEquals(Map.of(24601L, new TreeMap<>(Map.of(1, 24601L))), actual);
    verify(businessWSClient, times(1)).getUltimateParentMapFromClients(any());
  }

  @Test
  void should_get_account_data_by_account_id_from_client() {
    when(businessWSClient.getAccountInformation(eq(ACCOUNT_ID)))
        .thenReturn(Mono.just(List.of(ACCOUNT)));
    var actual = instance.getAccountData(ACCOUNT_ID).block();
    assertEquals(ACCOUNT, actual);
  }

  @Test
  void should_throw_error_if_multiple_account_data_from_client() {
    when(hashOperations.get(eq(BUSINESS_ACCOUNT_DATA_CACHE), any())).thenReturn(null);
    when(businessWSClient.getAccountsInformation(eq(List.of(ACCOUNT_ID))))
        .thenReturn(Mono.just(List.of(ACCOUNT, ACCOUNT)));
    assertThrows(BusinessWSException.class, () -> instance.getAccountData(ACCOUNT_ID).block());
  }

  @Test
  void should_get_accounts_data_from_cache() {
    var actual = instance.getAccountsData(ACCOUNT_IDS).block();
    assertEquals(List.of(ACCOUNT), actual);
    verify(businessWSClient, times(0)).getAccountsInformation(anyCollection());
  }

  @Test
  void should_get_accounts_data_from_client() {
    when(hashOperations.get(eq(BUSINESS_ACCOUNT_DATA_CACHE), any())).thenReturn(null);
    when(businessWSClient.getAccountsInformation(eq(List.copyOf(ACCOUNT_IDS))))
        .thenReturn(Mono.just(ACCOUNTS));
    when(businessWSClient.getUltimateParentMapFromAccounts(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(1, 1L)))));
    var actual = instance.getAccountsData(ACCOUNT_IDS).block();
    assertEquals(ACCOUNTS, actual);
  }

  @Test
  void should_get_accounts_data_from_client_from_cache() {
    when(businessWSClient.getAccountsInformation(any())).thenReturn(Mono.just(ACCOUNTS));
    when(businessWSClient.getUltimateParentMapFromAccounts(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(1, 1L)))));
    var actual = instance.getAccountsData(ACCOUNT_IDS).block();
    assertEquals(ACCOUNTS, actual);
  }

  @Test
  void should_get_expanded_accounts_from_cache() {
    var actual = instance.getExpandedAccountIds(ACCOUNT_ID).block();
    assertEquals(EXPANDED_ACCOUNTS, actual);
    verify(businessWSClient, times(0)).getExpandedAccountIds(anyLong());
  }

  @Test
  void should_get_expanded_accounts_from_client() {
    when(businessWSClient.getExpandedAccountIds(ACCOUNT_ID))
        .thenReturn(Mono.just(EXPANDED_ACCOUNTS));
    var actual = instance.getExpandedAccountIds(ACCOUNT_ID).block();
    assertEquals(EXPANDED_ACCOUNTS, actual);
  }

  @Test
  void should_get_user_details_from_cache() {
    var actual = instance.fetchUserDetails(USER_ID).block();
    assertEquals(USER, actual);
    verify(businessWSClient, times(0)).fetchUserDetails(anyInt());
  }

  @Test
  void should_get_user_details_from_client() {
    when(businessWSClient.fetchUserDetails(USER_ID)).thenReturn(Mono.just(USER));
    var actual = instance.fetchUserDetails(USER_ID).block();
    assertEquals(USER, actual);
  }

  @Test
  void should_get_user_account_access_map_from_cache() {
    var actual = instance.getUserAccountAccess(USER_ID, ACCOUNT_IDS).block();
    assertEquals(ACCOUNT_ACCESS_MAP, actual);
    verify(businessWSClient, times(0)).getUserAccountAccess(anyInt(), anyCollection());
  }

  @Test
  void should_get_user_account_access_map_from_client() {
    when(businessWSClient.getUserAccountAccess(eq(USER_ID), eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(ACCOUNT_ACCESS_MAP));
    var actual = instance.getUserAccountAccess(USER_ID, ACCOUNT_IDS).block();
    assertEquals(ACCOUNT_ACCESS_MAP, actual);
  }

  @Test
  void should_get_client_account_ids_from_cache() {
    when(hashOperations.get(eq(BUSINESS_CLIENT_HAS_ACCOUNTS_ACCESS_CACHE), any())).thenReturn(null);
    when(businessWSClient.getClientAccountIds(any())).thenReturn(Mono.just(List.of(1L, 2L, 3L)));
    var actual = instance.getClientAccountIds(CLIENT_ID).block();
    assertEquals(EXPANDED_ACCOUNTS, actual);
  }

  @Test
  void should_get_client_account_ids_from_client() {
    when(businessWSClient.getClientAccountIds(eq(CLIENT_ID)))
        .thenReturn(Mono.just(EXPANDED_ACCOUNTS));
    var actual = instance.getClientAccountIds(CLIENT_ID).block();
    assertEquals(EXPANDED_ACCOUNTS, actual);
  }
}
