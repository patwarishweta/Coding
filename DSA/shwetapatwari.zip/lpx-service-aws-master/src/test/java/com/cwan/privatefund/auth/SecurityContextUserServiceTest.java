package com.cwan.privatefund.auth;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class SecurityContextUserServiceTest {

  @Mock private SecurityContextService securityContextService;
  @Mock private BusinessWSCache businessWebCache;
  @InjectMocks private SecurityContextUserService service;

  @Test
  void validateAndRetrieveUserDetails_WithoutSecurityContext_Success() {
    var user = User.builder().id(1).fullname("Test User").email("testuser@example.com").build();
    var securityContext = mock(SecurityContext.class);
    var authentication = mock(Authentication.class);
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(1);
    when(businessWebCache.fetchUserDetails(1)).thenReturn(Mono.just(user));
    var result = service.validateAndRetrieveUserDetails().block();
    assertEquals(user, result);
  }

  @Test
  void validateAndRetrieveUserDetails_WithoutSecurityContext_FailedDueToInvalidUserDetails() {
    var user = User.builder().id(1).fullname("Test User").build();
    var securityContext = mock(SecurityContext.class);
    var authentication = mock(Authentication.class);
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(1);
    when(businessWebCache.fetchUserDetails(1)).thenReturn(Mono.just(user));
    var result = service.validateAndRetrieveUserDetails();
    StepVerifier.create(result).expectError(RuntimeException.class).verify();
  }

  @Test
  void validateAndRetrieveUserDetails_Success() {
    var user = User.builder().id(1).fullname("Test User").email("testuser@example.com").build();
    var securityContext = mock(SecurityContext.class);
    var authentication = mock(Authentication.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(1);
    when(businessWebCache.fetchUserDetails(1)).thenReturn(Mono.just(user));
    var result = service.validateAndRetrieveUserDetails(securityContext).block();
    assertEquals(user, result);
  }

  @Test
  void validateAndRetrieveUserDetails_FailedDueToInvalidUserDetails() {
    var user = User.builder().id(1).fullname("Test User").build();
    var securityContext = mock(SecurityContext.class);
    var authentication = mock(Authentication.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(1);
    when(businessWebCache.fetchUserDetails(1)).thenReturn(Mono.just(user));
    var result = service.validateAndRetrieveUserDetails(securityContext);
    StepVerifier.create(result).expectError(RuntimeException.class).verify();
  }

  @Test
  void validateAndRetrieveUserDetails_WithUserId_Success() {
    var user = User.builder().id(1).fullname("Test User").email("testuser@example.com").build();
    when(businessWebCache.fetchUserDetails(1)).thenReturn(Mono.just(user));
    var result = service.validateAndRetrieveUserDetails(1L).block();
    assertEquals(user, result);
  }

  @Test
  void validateAndGetUserId_WithoutSecurityContext_Success() {
    var securityContext = mock(SecurityContext.class);
    var authentication = mock(Authentication.class);
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(1);
    var result = service.validateAndGetUserId().block();
    assertEquals(1, result);
  }

  @Test
  void validateAndGetUserId_WithoutSecurityContext_Failed() {
    var securityContext = mock(SecurityContext.class);
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(null);
    var result = service.validateAndGetUserId();
    StepVerifier.create(result).expectError(AuthenticationException.class).verify();
  }

  @Test
  void validateAndGetUserId_Success() {
    var securityContext = mock(SecurityContext.class);
    var authentication = mock(Authentication.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(1);
    var result = service.validateAndGetUserId(securityContext).block();
    assertEquals(1, result);
  }

  @Test
  void validateAndGetUserId_Failed() {
    var securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(null);
    var result = service.validateAndGetUserId(securityContext);
    StepVerifier.create(result).expectError(AuthenticationException.class).verify();
  }

  @Test
  void validateAndBuildUserDetails_Success() {
    var user = User.builder().id(1).fullname("Test User").email("testuser@example.com").build();
    var result = service.validateAndBuildUserDetails(user).block();
    assertEquals(user, result);
  }

  @Test
  void validateAndBuildUserDetails_FailedDueToInvalidUserDetails() {
    var user = User.builder().id(1).fullname("Test User").build();
    var result = service.validateAndBuildUserDetails(user);
    StepVerifier.create(result).expectError(RuntimeException.class).verify();
  }
}
