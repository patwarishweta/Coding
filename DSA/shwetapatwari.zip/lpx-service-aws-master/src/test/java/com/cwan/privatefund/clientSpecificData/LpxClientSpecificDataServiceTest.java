package com.cwan.privatefund.clientSpecificData;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.ClientSpecificData;
import com.cwan.pbor.clientspecific.FundService;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LpxClientSpecificDataServiceTest {

  private FundService fundService;
  private LpxClientSpecificDataService INSTANCE;
  private ClientSpecificData CLIENT_SPECIFIC_DATA = ClientSpecificData.builder().id(1L).build();

  @BeforeEach
  void setUp() {
    fundService = mock(FundService.class);
    when(fundService.upsertClientSpecificData(Set.of(CLIENT_SPECIFIC_DATA)))
        .thenReturn(List.of(CLIENT_SPECIFIC_DATA));

    INSTANCE = new LpxClientSpecificDataService(fundService);
  }

  @Test
  void saveClientSpecificData() {
    var result = INSTANCE.saveClientSpecificData(Set.of(CLIENT_SPECIFIC_DATA));

    assertEquals(List.of(CLIENT_SPECIFIC_DATA), result);
  }
}
