package com.cwan.privatefund.capital.call.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.BankDetail;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.cashflow.bankdetail.api.BankDetails;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.thymeleaf.TemplateEngine;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

class CapitalCallPaymentInitiationServiceTest {

  @Mock private TemplateEngine thymeleafTemplateEngine;
  @Mock private BankDetails bankDetails;
  private CapitalCallPaymentInitiationService service;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    service = new CapitalCallPaymentInitiationService(thymeleafTemplateEngine, bankDetails);
  }

  @Test
  void testProcessPaymentInitiationWithCompletedStatus() {
    var mockDocument = createMockCapitalCallDocument(CapitalCallStatus.COMPLETED);
    when(thymeleafTemplateEngine.process(anyString(), any())).thenReturn("<payment>XML</payment>");
    var result = service.processPaymentInitiation(mockDocument);
    StepVerifier.create(result).expectNext("<payment>XML</payment>").verifyComplete();
    verify(thymeleafTemplateEngine).process(anyString(), any());
  }

  @Test
  void testProcessPaymentInitiationWithInvalidStatus() {
    var mockDocument = createMockCapitalCallDocument(CapitalCallStatus.WIRE_CHECK);
    var result = service.processPaymentInitiation(mockDocument);
    StepVerifier.create(result).expectError(IllegalStateException.class).verify();
  }

  @Test
  void testExceptionFromDependencies() {
    var mockDocument = createMockCapitalCallDocument(CapitalCallStatus.COMPLETED);
    when(thymeleafTemplateEngine.process(anyString(), any()))
        .thenThrow(new RuntimeException("Template error"));
    var result = service.processPaymentInitiation(mockDocument);
    StepVerifier.create(result).expectError(RuntimeException.class).verify();
  }

  private static CapitalCallDocument createMockCapitalCallDocument(CapitalCallStatus status) {
    Account.builder().id(123L).name("Client XYZ").build();
    CapitalCallBankDetail.builder().accountNumber("Account123").bankName("Bank XYZ");
    return CapitalCallDocument.builder()
        .status(status)
        .account(Account.builder().id(123L).name("Client XYZ").build())
        .documentId(1L)
        .paymentAmount(new BigDecimal("1000.0"))
        .currency("USD")
        .bankDetail(
            CapitalCallBankDetail.builder()
                .accountNumber("Account123")
                .bankName("Bank XYZ")
                .build())
        .dueDate(LocalDate.now())
        .build();
  }

  @Test
  void testSetAddressLinesWithNullBankDetail() {
    Map<String, String> props = new HashMap<>();
    service.setAddressLines(null, props);
    assertTrue(props.isEmpty());
  }

  @Test
  void testSetAddressLinesWithNullBankDetailId() {
    Map<String, String> props = new HashMap<>();
    var bankDetail =
        CapitalCallBankDetail.builder().bankDetailId(null).bankName("Test Bank").build();
    service.setAddressLines(bankDetail, props);
    assertTrue(props.isEmpty());
  }

  @Test
  void testSetAddressLinesWithNonNullBankDetailIdAndNullAddress() {
    Map<String, String> props = new HashMap<>();
    var bankDetail =
        CapitalCallBankDetail.builder().bankDetailId(123L).bankName("Test Bank").build();
    var mockedBankDetail = mock(BankDetail.class);
    when(mockedBankDetail.getAddress()).thenReturn(null);
    Flux<BankDetail> bankDetailMono = Flux.just(mockedBankDetail);
    when(bankDetails.getBankDetailByIds(Set.of(123L))).thenReturn(bankDetailMono);
    service.setAddressLines(bankDetail, props);
    assertTrue(props.isEmpty());
  }

  @Test
  void testSetAddressLinesWithValidAddress() {
    Map<String, String> props = new HashMap<>();
    var bankDetail =
        CapitalCallBankDetail.builder().bankDetailId(123L).bankName("Test Bank").build();
    var mockedBankDetail = mock(BankDetail.class);
    when(mockedBankDetail.getAddress()).thenReturn("123 Main St, Anytown, USA");
    Flux<BankDetail> bankDetailMono = Flux.just(mockedBankDetail);
    when(bankDetails.getBankDetailByIds(Set.of(123L))).thenReturn(bankDetailMono);
    service.setAddressLines(bankDetail, props);
    assertEquals("123 Main St", props.get("adrLine0"));
    assertEquals("Anytown", props.get("adrLine1"));
    assertEquals("USA", props.get("adrLine2"));
    assertFalse(props.containsKey("adrLine3"));
  }
}
