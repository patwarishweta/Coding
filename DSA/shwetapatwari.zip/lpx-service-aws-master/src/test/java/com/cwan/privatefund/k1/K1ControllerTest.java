package com.cwan.privatefund.k1;

import static com.cwan.privatefund.TestUtil.K1_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getK1;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.cwan.pbor.k1.K1Entity;
import com.cwan.pbor.k1.api.K1Service;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import java.time.Duration;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class K1ControllerTest extends AuthenticatedControllerTest {

  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;
  @MockBean K1Service k1Service;
  @Autowired private WebTestClient webClient;

  @BeforeEach
  void setUp() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void getCurrentK1s() {
    K1Entity k1 = getK1(1L);
    long documentId = k1.getDocumentId();
    when(k1Service.getCurrentK1s(Set.of(documentId))).thenReturn(Flux.just(k1));
    Set<K1Entity> actual =
        webClient
            .method(HttpMethod.GET)
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(K1_URI + "/documents")
                        .queryParam("documentIds", documentId)
                        .build())
            .exchange()
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(K1Entity.class)
            .getResponseBody()
            .collect(Collectors.toSet())
            .share()
            .block();
    assertEquals(Set.of(k1), actual);
  }

  @Test
  void addK1s() {
    K1Entity k1 = getK1(1L);
    when(k1Service.addK1s(Set.of(k1))).thenReturn(Flux.just(k1));
    Set<K1Entity> actual =
        webClient
            .method(HttpMethod.POST)
            .uri(format("%s%s", K1_URI, "/add"))
            .bodyValue(Set.of(k1))
            .exchange()
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(K1Entity.class)
            .getResponseBody()
            .collect(Collectors.toSet())
            .share()
            .block();
    assertEquals(Set.of(k1), actual);
  }
}
