package com.cwan.privatefund.document.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ValidationErrorResponseTest {

  @Test
  void builder_WithCustomValues() {
    int status = 500;
    String message = "Custom error";
    LocalDateTime timestamp = LocalDateTime.now();
    Map<String, String> errors = new HashMap<>();
    errors.put("key", "value");
    ValidationErrorResponse response =
        ValidationErrorResponse.builder()
            .status(status)
            .message(message)
            .timestamp(timestamp)
            .errors(errors)
            .build();
    assertEquals(status, response.status());
    assertEquals(message, response.message());
    assertEquals(timestamp, response.timestamp());
    assertEquals(errors, response.errors());
  }

  @Test
  void builder_WithNullValues() {
    ValidationErrorResponse response =
        ValidationErrorResponse.builder()
            .status(0)
            .message(null)
            .timestamp(null)
            .errors(null)
            .build();
    assertEquals(0, response.status());
    assertNull(response.message());
    assertNull(response.timestamp());
    assertNull(response.errors());
  }

  @Test
  void of_WithAllValidParameters() {
    int status = 400;
    String message = "Validation error";
    Map<String, String> errors = new HashMap<>();
    errors.put("field1", "error1");
    ValidationErrorResponse response = ValidationErrorResponse.of(status, message, errors);
    assertEquals(status, response.status());
    assertEquals(message, response.message());
    assertNotNull(response.timestamp());
    assertTrue(
        response
            .timestamp()
            .truncatedTo(ChronoUnit.SECONDS)
            .isEqual(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS)));
    assertEquals(errors, response.errors());
  }

  @Test
  void of_WithEmptyMessage_UsesDefaultMessage() {
    int status = 400;
    String message = "";
    Map<String, String> errors = new HashMap<>();
    ValidationErrorResponse response = ValidationErrorResponse.of(status, message, errors);
    assertEquals(status, response.status());
    assertEquals("Validation failed", response.message());
    assertNotNull(response.timestamp());
    assertEquals(errors, response.errors());
  }

  @Test
  void of_WithNullErrors_ReturnsEmptyMap() {
    int status = 400;
    String message = "Test message";
    ValidationErrorResponse response = ValidationErrorResponse.of(status, message, null);
    assertEquals(status, response.status());
    assertEquals(message, response.message());
    assertNotNull(response.timestamp());
    assertNotNull(response.errors());
    assertTrue(response.errors().isEmpty());
  }

  @Test
  void of_WithNullMessage_UsesDefaultMessage() {
    int status = 400;
    Map<String, String> errors = new HashMap<>();
    ValidationErrorResponse response = ValidationErrorResponse.of(status, null, errors);
    assertEquals(status, response.status());
    assertEquals("Validation failed", response.message());
    assertNotNull(response.timestamp());
    assertEquals(errors, response.errors());
  }

  @Test
  void recordMethods_EqualsHashCodeToString() {
    int status = 400;
    String message = "Test message";
    LocalDateTime timestamp = LocalDateTime.now();
    Map<String, String> errors = new HashMap<>();
    errors.put("field", "error");
    ValidationErrorResponse response1 =
        ValidationErrorResponse.builder()
            .status(status)
            .message(message)
            .timestamp(timestamp)
            .errors(errors)
            .build();
    ValidationErrorResponse response2 =
        ValidationErrorResponse.builder()
            .status(status)
            .message(message)
            .timestamp(timestamp)
            .errors(errors)
            .build();
    ValidationErrorResponse differentResponse =
        ValidationErrorResponse.builder()
            .status(500)
            .message("Different")
            .timestamp(timestamp)
            .errors(new HashMap<>())
            .build();
    assertEquals(response1, response2);
    assertNotEquals(response1, differentResponse);
    assertEquals(response1.hashCode(), response2.hashCode());
    assertNotEquals(response1.hashCode(), differentResponse.hashCode());
    assertTrue(response1.toString().contains(message));
    assertTrue(response1.toString().contains(String.valueOf(status)));
  }
}
