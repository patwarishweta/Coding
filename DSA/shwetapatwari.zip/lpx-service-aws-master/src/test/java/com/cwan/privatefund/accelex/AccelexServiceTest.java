package com.cwan.privatefund.accelex;

import static com.cwan.privatefund.accelex.AccelexField.CURRENCY;
import static com.cwan.privatefund.accelex.AccelexField.EVENT_TYPE;
import static com.cwan.privatefund.accelex.AccelexField.METRIC_NAME;
import static com.cwan.privatefund.accelex.AccelexField.PERIOD;
import static com.cwan.privatefund.accelex.AccelexField.REPORT_DATE;
import static com.cwan.privatefund.accelex.AccelexField.VALUE_TYPE;
import static com.cwan.privatefund.accelex.AccelexField.VEHICLE_NAME;
import static com.cwan.privatefund.accelex.AccelexService.ACCELEX_BALANCE_FIELDS;
import static com.cwan.privatefund.constant.Constants.LPX_CLARITY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ca.json2.utils.JsonUtils2;
import com.ca.relalg.Column;
import com.ca.relalg.data.DataSet;
import com.ca.relalg.data.DataSetBuilder;
import com.ca.util.date.GlobalDates;
import com.ca.util.time.UTCTimestamp;
import com.cwan.lpx.client.tabular.LPBalanceField;
import com.cwan.lpx.client.tabular.LPTransactionField;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Client;
import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.SecurityTypeDataDetail;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.accelex.api.AccelexCommonServiceImpl;
import com.cwan.pbor.trans.TransactionService;
import com.cwan.privatefund.accelex.AccelexService.LpData;
import com.cwan.privatefund.accelex.AccelexService.ReferenceFileType;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSApacheClient;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.document.LpxDocumentServiceApacheClient;
import com.cwan.privatefund.feature.FeatureFlagsWSClient;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.portfolio.PortfolioUtilsService;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient;
import com.cwan.privatefund.security.SecurityResolverClient;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class AccelexServiceTest {

  private AccelexService accelexService;
  @Mock private BusinessWSApacheClient businessWSClient;
  @Mock private LpxDocumentServiceApacheClient lpxDocumentServiceApacheClient;
  @Mock private PortfolioWsApacheClient portfolioWsApacheClient;
  @Mock private SecurityResolverClient securityResolverClient;
  @Mock private AccelexCommonServiceImpl accelexCommonService;
  @Mock private AccountConfigServiceCache accountConfigServiceCache;
  @Mock private TransactionService transactionService;
  @Mock private LpxFundMasterService fundMasterService;
  @Mock private BusinessWSCache businessWSCache;
  @Mock private SecurityService securityService;
  @Mock private PortfolioUtilsService portfolioUtilsService;
  @Mock private AccountService accountService;
  @Mock private FeatureFlagsWSClient featureFlagsWSClient;
  private static final Account ACCOUNT = Account.builder().id(1L).build();
  private static final Account ACCOUNT_2 = Account.builder().id(2L).build();
  private static final Security SECURITY =
      Security.builder()
          .securityId(24601L)
          .securityTypeDataDetail(
              SecurityTypeDataDetail.builder().isLimitedPartnership(true).build())
          .build();
  private static final Long SECURITY_ID_LONG = 100L;
  private static final int ACCOUNT_ID_1 = 1;
  private static final int ACCOUNT_ID_2 = 2;
  private static final int ACCOUNT_ID_3 = 3;
  private static final int SUB_CLIENT = 11;
  private static final int PARENT_CLIENT = 22;
  private static final int ULTIMATE_PARENT_CLIENT = 33;
  private static final UTCTimestamp DATE =
      UTCTimestamp.fromGlobalDate(GlobalDates.create(5, 20, 2023), TimeZone.getTimeZone("UTC"))
          .addHours(12);

  @BeforeEach
  void setup() {
    MockitoAnnotations.openMocks(this);
    accelexService =
        new AccelexService(
            businessWSClient,
            lpxDocumentServiceApacheClient,
            portfolioWsApacheClient,
            securityResolverClient,
            accountConfigServiceCache,
            accelexCommonService,
            transactionService,
            fundMasterService,
            businessWSCache,
            securityService,
            accountService,
            portfolioUtilsService,
            featureFlagsWSClient);
    when(accelexCommonService.getAccelexInvestmentsBySecurityIds(any(), any()))
        .thenReturn(List.of(AccelexInvestmentsEntity.builder().build()));
    when(accelexCommonService.getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(any(), any()))
        .thenReturn(List.of(AccelexPortfolioCompanyEntity.builder().build()));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(
            Mono.just(AccountConfig.builder().attributes(Map.of(LPX_CLARITY, "true")).build()));
    when(accountConfigServiceCache.getAccountConfigs(eq(Set.of(1L)), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .attributes(Map.of(LPX_CLARITY, "true"))
                        .account(Account.builder().id(1L).build())
                        .build())));
    when(accountConfigServiceCache.getAccountConfigs(eq(Set.of(2L)), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .attributes(Map.of(LPX_CLARITY, "true"))
                        .account(Account.builder().id(2L).build())
                        .build())));
    when(accountConfigServiceCache.getAccountConfigs(eq(Set.of(3L)), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .attributes(Map.of(LPX_CLARITY, "true"))
                        .account(Account.builder().id(3L).build())
                        .build())));
  }

  @Test
  void convertTransactionColumnsToAccelexMappingDataSet() {
    List<Column> headers =
        List.of(
            LPTransactionField.ACCOUNT_ID,
            LPTransactionField.SECURITY_ID,
            LPTransactionField.KNOWLEDGE_START_DATE,
            LPTransactionField.SETTLE_DATE,
            LPTransactionField.TYPE,
            LPTransactionField.CURRENCY,
            LPTransactionField.CASH_IMPACT,
            LPTransactionField.DOCUMENT_ID,
            LPTransactionField.SUB_TYPE);
    // [accountId, ["oridinal of client", clientId]]
    setupBusinessResponse();
    var builder = DataSetBuilder.configureFromReference(new DataSet<>(headers)).createBuilder();
    builder.addRow(
        ACCOUNT_ID_1, 2, DATE, GlobalDates.create(5, 20, 2023), "DVD", "USD", 100, 11, "TYPE1");
    builder.addRow(
        ACCOUNT_ID_1,
        2,
        DATE,
        GlobalDates.create(5, 20, 2023),
        "FTW",
        "USD",
        100,
        11,
        "TAX_REFUND");
    builder.addRow(
        ACCOUNT_ID_1, 2, DATE, GlobalDates.create(5, 20, 2023), "FTW", "USD", 100, 11, "A");
    builder.addRow(
        ACCOUNT_ID_1, 2, DATE, GlobalDates.create(5, 20, 2023), "CAPC", "USD", 200, 12, "TYPE2");
    builder.addRow(
        ACCOUNT_ID_1, 2, DATE, GlobalDates.create(5, 20, 2023), "OTHER", "USD", 200, 13, "TYPE3");
    var build = builder.build();
    var dataSet = accelexService.convertTransactionColumnsToAccelexMappingDataSet(build);
    var accelexExpectedTransactionDataSet =
        """
            [\
            ["","1:2","COMMITMENT",33,2,"net_payment","2023-05-20","2023-05-20","","USD",100,"DISTRIBUTION","TYPE1",11],\
            ["","1:2","COMMITMENT",33,2,"net_payment","2023-05-20","2023-05-20","","USD",100,"DISTRIBUTION","TAX_REFUND",11],\
            ["","1:2","COMMITMENT",33,2,"net_payment","2023-05-20","2023-05-20","","USD",100,"CALL","A",11],\
            ["","1:2","COMMITMENT",33,2,"net_payment","2023-05-20","2023-05-20","","USD",200,"CALL","TYPE2",12]\
            ]""";
    assertEquals(accelexExpectedTransactionDataSet, JsonUtils2.objToJson(dataSet.getRawData()));
  }

  @Test
  void convertBalanceColumnsToAccelexMappingDataSet() {
    List<Column> headers =
        List.of(
            LPBalanceField.ACCOUNT_ID,
            LPBalanceField.SECURITY_ID,
            LPBalanceField.KNOWLEDGE_START_DATE,
            LPBalanceField.BALANCE_DATE,
            LPBalanceField.FUND_CURRENCY,
            LPBalanceField.REPORTED_ENDING_NAV_AMOUNT,
            LPBalanceField.NET_IRR,
            LPBalanceField.TVPI,
            LPBalanceField.RVPI,
            LPBalanceField.DPI,
            LPBalanceField.REPORTED_RECALLABLE_DISTRIBUTION_AMOUNT,
            LPBalanceField.REPORTED_TOTAL_COMMITMENT_AMOUNT,
            LPBalanceField.CUM_CONTRIBUTION_AMOUNT,
            LPBalanceField.CUM_DISTRIBUTION_AMOUNT,
            LPBalanceField.DOCUMENT_ID);
    setupBusinessResponse();
    var builder = DataSetBuilder.configureFromReference(new DataSet<>(headers)).createBuilder();
    builder.addRow(
        ACCOUNT_ID_1,
        2,
        DATE,
        GlobalDates.create(5, 20, 2023),
        "USD",
        1.23,
        4.56,
        7.89,
        10.0,
        10.0,
        10.0,
        20.1,
        100.24,
        100.25,
        11);
    builder.addRow(
        ACCOUNT_ID_1,
        2,
        DATE,
        GlobalDates.create(5, 20, 2023),
        "USD",
        10.23,
        40.56,
        70.89,
        100.0,
        100.0,
        100.0,
        200.1,
        100.24,
        100.25,
        12);
    builder.addRow(
        ACCOUNT_ID_1,
        2,
        DATE,
        GlobalDates.create(5, 20, 2023),
        "USD",
        100.23,
        400.56,
        700.89,
        1000.0,
        1000.0,
        1000.0,
        2000.1,
        100.24,
        100.25,
        13);
    var build = builder.build();
    var dataSet = accelexService.convertBalanceColumnsToAccelexMappingDataSet(build);
    assertEquals(
        dataSet.getRowCount(),
        Math.multiplyExact(3, ACCELEX_BALANCE_FIELDS.size() + 1)); // 3 rows per
    // balanceType
    // are expected
  }

  @Test
  void upload_canoe_doc_from_cik() {
    setupBusinessResponse();
    LocalDate documentDate = LocalDate.of(2023, 9, 1);
    DocumentMetaData documentMetaData =
        new DocumentMetaData("CIK", "1234", "Financials", "12-34", "doc", documentDate);
    when(securityResolverClient.resolveCIK(eq("1234"))).thenReturn(List.of(1L, 2L, 3L));
    when(portfolioWsApacheClient.getAccountIdsBySecurityId(eq(1L), eq(documentDate)))
        .thenReturn(Set.of(1L));
    when(portfolioWsApacheClient.getAccountIdsBySecurityId(eq(2L), eq(documentDate)))
        .thenReturn(Set.of(2L));
    when(portfolioWsApacheClient.getAccountIdsBySecurityId(eq(3L), eq(documentDate)))
        .thenReturn(Set.of(3L));
    when(lpxDocumentServiceApacheClient.saveDocument(any(), eq("CANOE")))
        .thenReturn(
            Document.builder().id(1L).build(),
            Document.builder().id(2L).build(),
            Document.builder().id(3L).build());
    Set<Long> accountsToUpload = accelexService.uploadDocumentData(documentMetaData);
    verify(lpxDocumentServiceApacheClient, times(3)).saveDocument(any(), eq("CANOE"));
    assertEquals(3, accountsToUpload.size());
  }

  @Test
  void upload_canoe_doc_from_cik_doesnt_resolve() {
    LocalDate documentDate = LocalDate.of(2023, 9, 1);
    DocumentMetaData documentMetaData =
        new DocumentMetaData("CIK", "1234", "Financials", "12-34", "doc", documentDate);
    when(securityResolverClient.resolveCIK(eq("1234"))).thenReturn(List.of());
    Set<Long> accountsToUpload = accelexService.uploadDocumentData(documentMetaData);
    assertEquals(0, accountsToUpload.size());
  }

  @Test
  void upload_canoe_doc_from_security() {
    setupBusinessResponse();
    LocalDate documentDate = LocalDate.of(2023, 9, 1);
    DocumentMetaData documentMetaData =
        new DocumentMetaData("securityId", "1,2,3", "Financials", "12-34", "doc", documentDate);
    when(portfolioWsApacheClient.getAccountIdsBySecurityId(eq(1L), eq(documentDate)))
        .thenReturn(Set.of(1L));
    when(portfolioWsApacheClient.getAccountIdsBySecurityId(eq(2L), eq(documentDate)))
        .thenReturn(Set.of(2L));
    when(portfolioWsApacheClient.getAccountIdsBySecurityId(eq(3L), eq(documentDate)))
        .thenReturn(Set.of(3L));
    when(lpxDocumentServiceApacheClient.saveDocument(any(), eq("CANOE")))
        .thenReturn(
            Document.builder().id(1L).build(),
            Document.builder().id(2L).build(),
            Document.builder().id(3L).build());
    Set<Long> accountsToUpload = accelexService.uploadDocumentData(documentMetaData);
    assertEquals(3, accountsToUpload.size());
  }

  @Test
  void getEnabledStatusByAccountIds_featureNotEnabled() {
    setupBusinessResponse();
    when(accountConfigServiceCache.getAccountConfigs(any(), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .attributes(Map.of())
                        .account(Account.builder().id(1L).build())
                        .build())));
    Map<Long, Boolean> enabledStatusByAccountIds =
        accelexService.getEnabledStatusByAccountIds(
            Set.of(ACCOUNT_ID_1).stream().map(Integer::longValue).collect(Collectors.toSet()));
    assertFalse(enabledStatusByAccountIds.get(1L));
  }

  @Test
  void getEnabledStatusByAccountIds_featureEnabled() {
    setupBusinessResponse();
    Map<Long, Boolean> enabledStatusByAccountIds =
        accelexService.getEnabledStatusByAccountIds(
            Set.of(ACCOUNT_ID_1).stream().map(Integer::longValue).collect(Collectors.toSet()));
    assertTrue(enabledStatusByAccountIds.get(1L));
  }

  @Test
  void getPortfolioCompany() {
    Collection<AccelexPortfolioCompanyEntity> accelexPortfolioCompanies =
        accelexService.getAccelexPortfolioCompanies(Set.of(1L), LocalDate.of(2024, 6, 7));
    assertEquals(1, accelexPortfolioCompanies.size());
  }

  @Test
  void getInvestments() {
    Collection<AccelexInvestmentsEntity> accelexInvestments =
        accelexService.getAccelexInvestments(Set.of(1L), LocalDate.of(2024, 6, 7));
    assertEquals(1, accelexInvestments.size());
  }

  private void setupBusinessResponse() {
    // [accountId, ["oridinal of client", clientId]]
    SortedMap<Integer, Long> accountHierarchy =
        new TreeMap<>(
            Map.of(
                1, (long) SUB_CLIENT, 2, (long) PARENT_CLIENT, 3, (long) ULTIMATE_PARENT_CLIENT));
    Map<Long, SortedMap<Integer, Long>> businessAccount1ResponseMap =
        Map.of((long) ACCOUNT_ID_1, accountHierarchy);
    Map<Long, SortedMap<Integer, Long>> businessAccount2ResponseMap =
        Map.of((long) ACCOUNT_ID_2, accountHierarchy);
    Map<Long, SortedMap<Integer, Long>> businessAccount3ResponseMap =
        Map.of((long) ACCOUNT_ID_3, accountHierarchy);
    when(businessWSClient.getUltimateParentMapFromAccounts((eq(Set.of(1L)))))
        .thenReturn(businessAccount1ResponseMap);
    when(businessWSClient.getUltimateParentMapFromAccounts((eq(Set.of(2L)))))
        .thenReturn(businessAccount2ResponseMap);
    when(businessWSClient.getUltimateParentMapFromAccounts((eq(Set.of(3L)))))
        .thenReturn(businessAccount3ResponseMap);
    when(businessWSCache.ultimateParentCacheByAccountId(any()))
        .thenReturn(Mono.just(Map.of(1L, accountHierarchy)));
    when(businessWSCache.getClientData(any()))
        .thenReturn(Mono.just(Client.builder().name("Test Client").build()));
  }

  @Test
  void getFundReferenceData() {
    setupBusinessResponse();
    when(accountConfigServiceCache.getAccountConfigs(anySet(), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .account(ACCOUNT)
                        .attributes(Map.of(LPX_CLARITY, "true"))
                        .build())));
    when(transactionService.getTransactions(
            anySet(), any(), any(), any(), any(), anyBoolean(), anyBoolean()))
        .thenReturn(
            Flux.just(
                Transaction.builder()
                    .account(ACCOUNT)
                    .type("TRNI")
                    .security(Security.builder().securityId(SECURITY_ID_LONG).build())
                    .build()));
    when(fundMasterService.getFundMasterEntitiesWithOverridesBySecurities(
            eq(null), eq(ACCOUNT.getId()), anySet()))
        .thenReturn(
            Map.of(
                SECURITY_ID_LONG,
                FundMasterEntity.builder()
                    .id(1L)
                    .name("hello")
                    .countryOfDomicile("US")
                    .fundCurrency("haha")
                    .build()));
    when(securityService.getSecurity(anyLong()))
        .thenReturn(
            Mono.just(
                Security.builder()
                    .securityId(SECURITY_ID_LONG)
                    .currency(Currency.builder().currencyId(1L).code("USD").build())
                    .build()));
    DataSet<Column> fundReferenceData =
        accelexService.getFundEntityReferenceData(
            Set.of(ACCOUNT.getId()), ReferenceFileType.ENTITY_REFERENCE_DATA, false);
    assertEquals(2, fundReferenceData.getRowCount());
    assertEquals(
        1,
        fundReferenceData
            .query()
            .filter(c -> "Test Client".equals(c.get(AccelexField.ENTITY_NAME)))
            .go()
            .getRowCount());
    assertEquals(
        1,
        fundReferenceData
            .query()
            .filter(c -> "hello".equals(c.get(AccelexField.ENTITY_NAME)))
            .go()
            .getRowCount());
    assertEquals(
        "USD",
        fundReferenceData
            .query()
            .filter(c -> "hello".equals(c.get(AccelexField.ENTITY_NAME)))
            .go()
            .getRow(0)
            .get(AccelexField.ENTITY_CURRENCY));
    DataSet<Column> eventReferenceData =
        accelexService.getFundEntityReferenceData(
            Set.of(ACCOUNT.getId()), ReferenceFileType.EVENT_REFERENCE_DATA, true);
    assertEquals(1, eventReferenceData.getRowCount());
  }

  @Test
  void getFundReferenceData_allClients() {
    setupBusinessResponse();
    when(featureFlagsWSClient.getCachedFeatureFlag(any(), eq("1"))).thenReturn(false);
    when(featureFlagsWSClient.getCachedFeatureFlag(any(), eq("2"))).thenReturn(true);
    when(accountConfigServiceCache.getAllAccountConfigsWithAttribute(eq(null), anyString()))
        .thenReturn(
            Set.of(
                AccountConfig.builder()
                    .account(ACCOUNT)
                    .ultimateParentId(1L)
                    .attributes(Map.of(LPX_CLARITY, "true"))
                    .build(),
                AccountConfig.builder()
                    .account(ACCOUNT_2)
                    .ultimateParentId(2L)
                    .attributes(Map.of(LPX_CLARITY, "true"))
                    .build()));
    when(transactionService.getTransactions(
            anySet(), any(), any(), any(), any(), anyBoolean(), anyBoolean()))
        .thenReturn(
            Flux.just(
                Transaction.builder()
                    .account(ACCOUNT)
                    .type("TRNI")
                    .security(Security.builder().securityId(SECURITY_ID_LONG).build())
                    .build()));
    when(fundMasterService.getFundMasterEntitiesWithOverridesBySecurities(
            eq(null), eq(ACCOUNT.getId()), anySet()))
        .thenReturn(
            Map.of(
                SECURITY_ID_LONG,
                FundMasterEntity.builder()
                    .id(1L)
                    .name("hello")
                    .countryOfDomicile("US")
                    .fundCurrency("haha")
                    .build()));
    when(securityService.getSecurity(anyLong()))
        .thenReturn(
            Mono.just(
                Security.builder()
                    .securityId(SECURITY_ID_LONG)
                    .currency(Currency.builder().currencyId(1L).code("USD").build())
                    .build()));
    DataSet<Column> fundReferenceData =
        accelexService.getFundEntityReferenceData(ReferenceFileType.ENTITY_REFERENCE_DATA, false);
    assertEquals(2, fundReferenceData.getRowCount());
    assertEquals(
        1,
        fundReferenceData
            .query()
            .filter(c -> "Test Client".equals(c.get(AccelexField.ENTITY_NAME)))
            .go()
            .getRowCount());
    assertEquals(
        1,
        fundReferenceData
            .query()
            .filter(c -> "hello".equals(c.get(AccelexField.ENTITY_NAME)))
            .go()
            .getRowCount());
    assertEquals(
        "USD",
        fundReferenceData
            .query()
            .filter(c -> "hello".equals(c.get(AccelexField.ENTITY_NAME)))
            .go()
            .getRow(0)
            .get(AccelexField.ENTITY_CURRENCY));
    DataSet<Column> eventReferenceData =
        accelexService.getFundEntityReferenceData(
            Set.of(ACCOUNT.getId()), ReferenceFileType.EVENT_REFERENCE_DATA, true);
    assertEquals(1, eventReferenceData.getRowCount());
  }

  @Test
  void getFundReferenceData_missingRowsForUI() {
    setupBusinessResponse();
    when(accountConfigServiceCache.getAccountConfigs(anySet(), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .account(ACCOUNT)
                        .attributes(Map.of(LPX_CLARITY, "true"))
                        .build())));
    when(transactionService.getTransactions(
            anySet(), any(), any(), any(), any(), anyBoolean(), anyBoolean()))
        .thenReturn(
            Flux.just(
                Transaction.builder()
                    .account(ACCOUNT)
                    .type("TRNI")
                    .security(Security.builder().securityId(SECURITY_ID_LONG).build())
                    .build()));
    when(fundMasterService.getFundMasterEntitiesWithOverridesBySecurities(
            eq(null), eq(ACCOUNT.getId()), anySet()))
        .thenReturn(Map.of());
    DataSet<Column> eventReferenceData =
        accelexService.getFundEntityReferenceData(
            Set.of(ACCOUNT.getId()), ReferenceFileType.EVENT_REFERENCE_DATA, true);
    assertEquals(1, eventReferenceData.getRowCount());
  }

  @Test
  void testValidateValue() {
    assertNull(AccelexService.validateValue(600.0, LPBalanceField.NET_IRR));
    assertEquals(4.0, AccelexService.validateValue(400.0, LPBalanceField.NET_IRR));
    assertEquals(
        600.0, AccelexService.validateValue(600.0, LPBalanceField.REPORTED_ENDING_NAV_AMOUNT));
    assertNull(AccelexService.validateValue(null, LPBalanceField.NET_IRR));
  }

  @Test
  void testGetAccelexEnabledSecuritiesAndAccounts() {
    Account returnedAccount = ACCOUNT.toBuilder().attributes(Map.of(LPX_CLARITY, "true")).build();
    when(accountService.getClientAccounts(anyLong(), anyInt())).thenReturn(Flux.just(ACCOUNT));
    when(accountConfigServiceCache.getAccountConfigs(anySet(), any()))
        .thenReturn(
            Mono.just(
                List.of(
                    AccountConfig.builder()
                        .account(ACCOUNT)
                        .attributes(Map.of(LPX_CLARITY, "true"))
                        .build())));
    when(portfolioUtilsService.getAllSecuritiesByAccountId(anyLong()))
        .thenReturn(Mono.just(Map.of(1L, List.of(SECURITY))));
    List<LpData> retValue = accelexService.getAccelexEnabledSecuritiesAndAccounts(1L, 1);
    assertEquals(1, retValue.size());
    assertEquals(returnedAccount, retValue.get(0).account());
    assertEquals(SECURITY, retValue.get(0).security());
  }

  @Test
  public void testConvertBalanceColumnsToAccelexMappingDataSetForAggregates() {
    // Given
    DataSet<Column> inputDataSet = createBaseDataSet();

    AccountConfig accountConfig1 =
        AccountConfig.builder()
            .account(Account.builder().id(1L).build())
            .clientName("ClientA")
            .build();
    AccountConfig accountConfig2 =
        AccountConfig.builder()
            .account(Account.builder().id(2L).build())
            .clientName("ClientB")
            .build();

    when(accountConfigServiceCache.getAllAccountConfigs())
        .thenReturn(Mono.just(List.of(accountConfig1, accountConfig2)));

    // When
    DataSet<Column> result =
        accelexService.convertBalanceColumnsToAccelexMappingDataSetForAggregates(inputDataSet);

    // Then
    assertEquals(32, result.getRowCount());
    assertEquals(
        Set.of(
            EVENT_TYPE.getName(),
            VEHICLE_NAME.getName(),
            METRIC_NAME.getName(),
            REPORT_DATE.getName(),
            AccelexField.DATE.getName(),
            PERIOD.getName(),
            CURRENCY.getName(),
            VALUE_TYPE.getName(),
            AccelexField.VALUE.getName()),
        result.getHeader().getColumns().stream().map(Column::getName).collect(Collectors.toSet()));
    // Add more assertions as necessary to verify the contents of 'result'.
  }

  private static DataSet<Column> createBaseDataSet() {
    // Define all necessary headers from LPBalanceField, including the additional fields
    List<Column> headers =
        List.of(
            LPBalanceField.ACCOUNT_ID,
            LPBalanceField.SECURITY_ID,
            LPBalanceField.FUND_CURRENCY,
            LPBalanceField.KNOWLEDGE_START_DATE,
            LPBalanceField.BALANCE_DATE,
            LPBalanceField.DOCUMENT_ID,
            LPBalanceField.REPORTED_RECALLABLE_DISTRIBUTION_AMOUNT,
            LPBalanceField.REPORTED_TOTAL_COMMITMENT_AMOUNT,
            LPBalanceField.CUM_CONTRIBUTION_AMOUNT,
            LPBalanceField.CUM_DISTRIBUTION_AMOUNT,
            LPBalanceField.NET_IRR,
            LPBalanceField.TVPI,
            LPBalanceField.RVPI,
            LPBalanceField.DPI
            // Add other fields as necessary
            );

    LocalDateTime balanceDate = LocalDateTime.of(2023, 1, 1, 0, 0, 0);
    var builder = DataSetBuilder.configureFromReference(new DataSet<>(headers)).createBuilder();
    // Adding sample rows, make sure to adjust values based on test scenarios
    builder.addRow(
        1L,
        100L,
        "USD",
        convertToUTCTimeStamp(balanceDate),
        GlobalDates.create(balanceDate.toLocalDate()),
        "DOC-001",
        500.0,
        1000.0,
        1500.0,
        700.0,
        0.15,
        1.2,
        1.1,
        0.9);
    builder.addRow(
        1L,
        100L,
        "CAD",
        convertToUTCTimeStamp(balanceDate),
        GlobalDates.create(balanceDate.toLocalDate()),
        "DOC-002",
        600.0,
        900.0,
        1400.0,
        800.0,
        0.16,
        1.25,
        1.15,
        0.95);
    builder.addRow(
        2L,
        200L,
        "EUR",
        convertToUTCTimeStamp(balanceDate),
        GlobalDates.create(balanceDate.toLocalDate()),
        "DOC-003",
        700.0,
        1100.0,
        1600.0,
        600.0,
        0.14,
        1.3,
        1.2,
        1.0);
    builder.addRow(
        3L,
        300L,
        "GBP",
        convertToUTCTimeStamp(balanceDate),
        GlobalDates.create(balanceDate.toLocalDate()),
        "DOC-004",
        800.0,
        1200.0,
        1700.0,
        500.0,
        0.17,
        1.35,
        1.25,
        1.1);

    return builder.build();
  }

  private static UTCTimestamp convertToUTCTimeStamp(LocalDateTime localDateTime) {
    return localDateTime == null
        ? null
        : UTCTimestamp.fromLong(localDateTime.toEpochSecond(ZoneOffset.UTC) * 1000L);
  }
}
