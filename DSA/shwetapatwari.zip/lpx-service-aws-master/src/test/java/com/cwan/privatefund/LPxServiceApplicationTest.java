package com.cwan.privatefund;

import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.springframework.boot.test.mock.mockito.MockBean;

// @SpringBootTest
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class LPxServiceApplicationTest {

  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;
}
