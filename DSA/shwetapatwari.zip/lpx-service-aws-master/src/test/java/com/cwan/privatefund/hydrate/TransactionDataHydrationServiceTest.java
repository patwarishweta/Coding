package com.cwan.privatefund.hydrate;

import static com.cwan.privatefund.TestUtil.getAccount;
import static com.cwan.privatefund.TestUtil.getDocument;
import static com.cwan.privatefund.TestUtil.getSecurity;
import static com.cwan.privatefund.TestUtil.getTransaction;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.document.DocumentAuditService;
import com.cwan.privatefund.document.DocumentInfo;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class TransactionDataHydrationServiceTest {

  @Mock private AccountService accountService;
  @Mock private Documents documents;
  @Mock private SecurityService securityService;
  @Mock private DocumentAuditService documentAuditService;
  private TransactionDataHydrationService instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance =
        new TransactionDataHydrationService(
            accountService, documents, securityService, documentAuditService);
  }

  @Test
  void should_hydrate_account_security_and_document_data() {
    var transaction = getTransaction();
    var account = getAccount();
    var security = getSecurity();
    var document = getDocument();
    when(accountService.getAccountsData(eq(Set.of(transaction.getAccount().getId()))))
        .thenReturn(Mono.just(List.of(account)));
    when(securityService.getSecurities(
            eq(transaction.getAccount().getClientId()),
            eq(transaction.getAccount().getId()),
            eq(List.of(transaction.getSecurity().getSecurityId()))))
        .thenReturn(Mono.just(List.of(security)));
    when(documents.getDocumentsByIds(eq(Set.of(transaction.getDocument().getId()))))
        .thenReturn(Flux.just(document));
    var expectedTransaction =
        transaction.toBuilder().account(account).security(security).document(document).build();
    var actual = instance.hydrate(List.of(transaction)).block();
    assertEquals(List.of(expectedTransaction), actual);
  }

  @Test
  void testHydrateDocumentAndAuditData() {
    // Mock out documents and audit services
    Document document = Document.builder().id(1L).fileName("Some Document").build();
    Transaction transaction = Transaction.builder().document(document).build();
    Collection<Transaction> transactions = List.of(transaction);

    DocumentInfo mockedDocumentInfo = mock(DocumentInfo.class);
    when(mockedDocumentInfo.getDocument()).thenReturn(document);
    when(mockedDocumentInfo.validationDate()).thenReturn(LocalDateTime.of(2023, 10, 1, 0, 0));

    when(documents.getDocumentsByIds(anySet())).thenReturn(Flux.just(document));

    when(documentAuditService.getDocumentsWithAuditInfo(any()))
        .thenReturn(Flux.just(mockedDocumentInfo));

    // Call the method under test
    Mono<List<Transaction>> resultMono = instance.hydrateDocumentAndAuditData(transactions);

    // Block to get the result for assertion (only for testing, not a good practice in production)
    List<Transaction> result = resultMono.block();

    // Verify results
    assert result != null;
    assertEquals(1, result.size());
    assertEquals(mockedDocumentInfo.getDocument().getId(), result.get(0).getDocument().getId());
    assertEquals(
        mockedDocumentInfo.validationDate(), result.get(0).getDocument().getValidationDate());
  }
}
