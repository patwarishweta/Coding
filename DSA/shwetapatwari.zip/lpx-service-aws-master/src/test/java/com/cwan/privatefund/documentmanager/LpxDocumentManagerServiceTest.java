package com.cwan.privatefund.documentmanager;

import static com.cwan.privatefund.TestUtil.getDocument;
import static com.cwan.privatefund.TestUtil.getDocumentManagerData;
import static com.cwan.privatefund.TestUtil.getFilePart;
import static com.cwan.privatefund.TestUtil.getUser;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Tag;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.document.misc.document.entity.MiscDocumentEntity;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.account.UltimateParents;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.document.LpxDocumentServiceClient;
import com.cwan.privatefund.documentmanager.exception.DocumentUploadFailedException;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.tag.LpxTagService;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import org.apache.tika.Tika;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class LpxDocumentManagerServiceTest {

  @Mock private Documents documents;
  @Mock private LpxTagService lpxTagService;
  @Mock private SecurityService securityService;
  @Mock private LpxDocumentServiceClient lpxDocumentServiceClient;
  @Mock private AccountService accountService;
  @Mock private Tika tika;
  @Mock private SecurityContextUserService securityContextUserService;
  @Mock private DocumentManagerRequestValidator documentManagerRequestValidator;
  @Mock private MiscDocumentTransformer miscDocumentTransformer;
  @Mock DataBufferFactory dataBufferFactory;
  private static final Long ACCOUNT_ID = 134L;
  private LpxDocumentManagerService lpxDocumentManagerService;
  private static final Long DOCUMENT_ID = 1L;
  private static final Long DIRECTORY_ID = 2L;
  private static final Document DOCUMENT = Document.builder().id(DOCUMENT_ID).build();
  private static final Tag TAG = Tag.builder().tag("tag1").id(2L).documentId(DOCUMENT_ID).build();
  private static final DocumentManagerData DOCUMENT_MANAGER_DATA =
      DocumentManagerData.builder().document(DOCUMENT).tags(Set.of(TAG.getTag())).build();
  private static final Document DOCUMENT1 = getDocument();
  private static final UltimateParents ULTIMATE_PARENTS =
      UltimateParents.builder()
          .ultimateParentName("Ultimate Parent Name")
          .ultimateParentId(123L)
          .build();
  private final DocumentManagerData DOCUMENT_DETAILS =
      getDocumentManagerData().toBuilder().ultimateParent(ULTIMATE_PARENTS).build();
  private final FilePart FILE = getFilePart();
  private final DocumentUploadRequest DOCUMENT_UPLOAD_REQUEST =
      DocumentUploadRequest.builder()
          .documentDetails(DOCUMENT_DETAILS)
          .files(List.of(FILE))
          .build();
  private static final MiscDocumentEntity MISC_DOCUMENT_ENTITY =
      new MiscDocumentTransformer().transform(DOCUMENT1, ULTIMATE_PARENTS);
  private static final User user = getUser();

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    this.lpxDocumentManagerService =
        new LpxDocumentManagerService(
            documents,
            lpxTagService,
            securityService,
            lpxDocumentServiceClient,
            accountService,
            tika,
            securityContextUserService,
            documentManagerRequestValidator,
            miscDocumentTransformer);
    Mockito.when(lpxTagService.getAllByDocumentId(DOCUMENT_ID)).thenReturn(Flux.just(TAG));
  }

  @Test
  void should_get_all_documents_by_accountId_and_tag() {
    Mockito.when(lpxTagService.getAllByTag(TAG.getTag())).thenReturn(Flux.just(TAG));
    Mockito.when(documents.getAllDocumentsByAccountIdAndIsDisabled(Set.of(ACCOUNT_ID), false))
        .thenReturn(Flux.just(DOCUMENT));
    var actual =
        lpxDocumentManagerService
            .getActiveDocumentsByAccountIdAndTag(ACCOUNT_ID, TAG.getTag())
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT_MANAGER_DATA), actual);
  }

  @Test
  void should_get_all_documents_by_account_id_and_name() {
    Mockito.when(
            documents.getAllActiveDocumentsByAccountIdAndFileName(
                ACCOUNT_ID, DOCUMENT.getFileName()))
        .thenReturn(Flux.just(DOCUMENT));
    var actual =
        lpxDocumentManagerService
            .getActiveDocumentsByAccountIdAndFileName(ACCOUNT_ID, DOCUMENT.getFileName())
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT_MANAGER_DATA), actual);
  }

  @Test
  void should_get_all_documents_by_directory_id() {
    Mockito.when(documents.getAllActiveDocumentsByDirectoryId(DIRECTORY_ID))
        .thenReturn(Flux.just(DOCUMENT));
    var actual =
        lpxDocumentManagerService
            .getActiveDocumentsByDirectoryId(DIRECTORY_ID)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT_MANAGER_DATA), actual);
  }

  @Test
  void should_get_all_disabled_documents_by_account_id()
      throws ExecutionException, InterruptedException {
    Mockito.when(documents.getAllDocumentsByAccountIdAndIsDisabled(Set.of(ACCOUNT_ID), true))
        .thenReturn(Flux.just(DOCUMENT));
    when(accountService.expandAccountId(anyLong())).thenReturn(Flux.just(ACCOUNT_ID));
    var actual =
        lpxDocumentManagerService.getDisabledDocumentsForAccount(ACCOUNT_ID).collectList().block();
    assertEquals(List.of(DOCUMENT_MANAGER_DATA), actual);
  }

  @Test
  void should_save_new_document() {
    var mockFile = Mockito.mock(FilePart.class);
    var cloudStorageId = "testStorageId";
    // Simulate a valid file name
    Mockito.when(mockFile.filename()).thenReturn("testDocument.pdf");
    // Prepare dummy byte content for the file
    byte[] mockFileContent = "Test content".getBytes();
    // Create a DataBuffer from the byte array
    dataBufferFactory = new DefaultDataBufferFactory(); // Create a default factory
    // Create a DataBuffer from the byte array
    DataBuffer dataBuffer = dataBufferFactory.wrap(mockFileContent);
    // Mock the content method to return a Flux of DataBuffer
    Mockito.when(mockFile.content()).thenReturn(Flux.just(dataBuffer));
    Mockito.when(tika.detect(mockFileContent)).thenReturn("application/pdf");
    var newDocument = Document.builder().fileName("testDocument.pdf").build();
    var newData = DOCUMENT_MANAGER_DATA.toBuilder().document(newDocument).build();
    Mockito.when(lpxDocumentServiceClient.uploadFile(mockFile))
        .thenReturn(Mono.just(cloudStorageId));
    Mockito.when(
            documents.addDocuments(
                Set.of(newDocument.toBuilder().cloudStorageId(cloudStorageId).build())))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA.getDocument()));
    Mockito.when(
            lpxDocumentServiceClient.saveDocument(
                newDocument.toBuilder().cloudStorageId(cloudStorageId).build()))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA.getDocument()));
    Mockito.when(
            lpxTagService.updateTagsForDocumentId(
                DOCUMENT_MANAGER_DATA.getDocument().getId(), newData.getTags()))
        .thenReturn(Flux.just(TAG));
    var actual = lpxDocumentManagerService.saveNewDocument(mockFile, newData).block();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_get_all_documents_without_directory_by_account_id() {
    Mockito.when(documents.getAllActiveDocumentsWithoutDirectoryByAccountId(ACCOUNT_ID))
        .thenReturn(Flux.just(DOCUMENT));
    var actual =
        lpxDocumentManagerService
            .getActiveDocumentsWithoutDirectoryByAccount(ACCOUNT_ID)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT_MANAGER_DATA), actual);
  }

  @Test
  void should_upload_document() {
    Mockito.when(
            documentManagerRequestValidator.validateDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(Boolean.TRUE));
    Mockito.when(lpxDocumentServiceClient.uploadFile(any()))
        .thenReturn(Mono.just("1234-1234-1234"));
    Mockito.when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(user));
    Mockito.when(lpxDocumentServiceClient.saveDocument(any(Document.class)))
        .thenReturn(Flux.just(DOCUMENT1));
    Mockito.when(lpxTagService.updateTagsForDocumentId(anyLong(), anySet()))
        .thenReturn(Flux.just(Tag.builder().documentId(DOCUMENT1.getId()).tag("tag").build()));
    StepVerifier.create(lpxDocumentManagerService.uploadDocument(DOCUMENT_UPLOAD_REQUEST))
        .assertNext(
            response -> {
              assertNotNull(response);
              assertEquals(HttpStatus.CREATED, response.getStatusCode());
              assertNotNull(response.getBody());
              assertNotNull(response.getBody().getUploadedFileDetails());
              assertFalse(response.getBody().getUploadedFileDetails().isEmpty());
              assertTrue(
                  response.getBody().getUploadedFileDetails().stream()
                      .allMatch(
                          documentUploadFileDetails ->
                              documentUploadFileDetails
                                  .getStatus()
                                  .equals(DocumentUploadStatus.SUCCESS)));
            })
        .verifyComplete();
  }

  @Test
  void test_upload_document_all_upload_failed() {
    Mockito.when(
            documentManagerRequestValidator.validateDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(Boolean.FALSE));
    Mockito.when(lpxDocumentServiceClient.uploadFile(any())).thenReturn(Mono.just("UPLOAD_FAILED"));
    StepVerifier.create(lpxDocumentManagerService.uploadDocument(DOCUMENT_UPLOAD_REQUEST))
        .expectError(DocumentUploadFailedException.class)
        .verify();
  }

  @Test
  void test_upload_document_needs_custom_allocation_false() {
    Mockito.when(
            documentManagerRequestValidator.validateDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(Boolean.FALSE));
    Mockito.when(lpxDocumentServiceClient.uploadFile(any()))
        .thenReturn(Mono.just("1234-1234-1234"));
    Mockito.when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(user));
    Mockito.when(lpxDocumentServiceClient.saveDocument(any(Document.class)))
        .thenReturn(Flux.just(DOCUMENT1));
    Mockito.when(miscDocumentTransformer.transform(any(Document.class), any(UltimateParents.class)))
        .thenReturn(MISC_DOCUMENT_ENTITY);
    Mockito.when(lpxDocumentServiceClient.saveMiscDocument(any(MiscDocumentEntity.class)))
        .thenReturn(Mono.just(MISC_DOCUMENT_ENTITY));
    Mockito.when(lpxTagService.updateTagsForDocumentId(anyLong(), anySet()))
        .thenReturn(Flux.just(Tag.builder().documentId(DOCUMENT1.getId()).tag("tag").build()));
    StepVerifier.create(lpxDocumentManagerService.uploadDocument(DOCUMENT_UPLOAD_REQUEST))
        .assertNext(
            response -> {
              assertNotNull(response);
              assertEquals(HttpStatus.CREATED, response.getStatusCode());
              assertNotNull(response.getBody());
              assertNotNull(response.getBody().getUploadedFileDetails());
              assertFalse(response.getBody().getUploadedFileDetails().isEmpty());
              assertTrue(
                  response.getBody().getUploadedFileDetails().stream()
                      .allMatch(
                          documentUploadFileDetails ->
                              documentUploadFileDetails
                                  .getStatus()
                                  .equals(DocumentUploadStatus.SUCCESS)));
            })
        .verifyComplete();
  }

  @Test
  void should_upload_document_partially() {
    Mockito.when(
            documentManagerRequestValidator.validateDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(DOCUMENT_UPLOAD_REQUEST));
    Mockito.when(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                any(DocumentUploadRequest.class)))
        .thenReturn(Mono.just(Boolean.TRUE));
    Mockito.when(lpxDocumentServiceClient.uploadFile(any()))
        .thenReturn(Mono.just("1234-1234-1234"))
        .thenReturn(Mono.just("UPLOAD_FAILED"));
    Mockito.when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(user));
    Mockito.when(lpxDocumentServiceClient.saveDocument(any(Document.class)))
        .thenReturn(Flux.just(DOCUMENT1));
    Mockito.when(lpxTagService.updateTagsForDocumentId(anyLong(), anySet()))
        .thenReturn(Flux.just(Tag.builder().documentId(DOCUMENT1.getId()).tag("tag").build()));
    StepVerifier.create(
            lpxDocumentManagerService.uploadDocument(
                DOCUMENT_UPLOAD_REQUEST.toBuilder().files(List.of(FILE, FILE)).build()))
        .assertNext(
            response -> {
              assertNotNull(response);
              assertEquals(HttpStatus.EXPECTATION_FAILED, response.getStatusCode());
              assertNotNull(response.getBody());
              assertNotNull(response.getBody().getUploadedFileDetails());
              assertFalse(response.getBody().getUploadedFileDetails().isEmpty());
              assertTrue(
                  response.getBody().getUploadedFileDetails().stream()
                      .anyMatch(
                          documentUploadFileDetails ->
                              documentUploadFileDetails
                                  .getStatus()
                                  .equals(DocumentUploadStatus.SUCCESS)));
            })
        .verifyComplete();
  }
}
