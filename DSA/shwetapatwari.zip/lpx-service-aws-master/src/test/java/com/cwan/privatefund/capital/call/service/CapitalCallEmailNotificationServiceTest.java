package com.cwan.privatefund.capital.call.service;

import static com.cwan.privatefund.capital.call.constant.CapitalCallConstants.CapitalCallEmailConstants.QUEUE_CAPACITY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.FundDetail;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants;
import com.cwan.privatefund.cpd.ws.client.CpdWSCache;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import com.cwan.privatefund.notification.service.EmailNotificationService;
import com.cwan.privatefund.notification.service.EmailViaSalesforceService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.thymeleaf.TemplateEngine;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class CapitalCallEmailNotificationServiceTest {

  @Mock private CapitalCallAuditService capitalCallAuditService;
  @Mock private TemplateEngine thymeleafTemplateEngine;
  @Mock private EmailViaSalesforceService emailViaSalesforceService;
  @Mock private EmailNotificationService emailViaNotificationService;
  @Mock private CpdWSCache cpdWSCache;
  @Mock private ExecutorService emailSenderService;
  private CapitalCallEmailNotificationService capitalCallEmailNotificationService;

  @BeforeEach
  void setUp() {
    capitalCallEmailNotificationService =
        new CapitalCallEmailNotificationService(
            capitalCallAuditService,
            thymeleafTemplateEngine,
            emailViaSalesforceService,
            emailViaNotificationService,
            cpdWSCache,
            emailSenderService);
    lenient()
        .when(emailViaSalesforceService.sendEmailNotification(any(), any(), anyCollection(), any()))
        .thenReturn(Mono.empty());
  }

  @Test
  void enqueueDocumentForEmail_success() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    capitalCallEmailNotificationService.enqueueDocumentForEmail(document);
    assertEquals(1, capitalCallEmailNotificationService.getEmailQueue().size());
  }

  @Test
  void enqueueDocumentForEmail_queueIsFull() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    Stream.iterate(0, i -> i < QUEUE_CAPACITY, i -> i + 1)
        .forEach(
            i ->
                capitalCallEmailNotificationService
                    .getEmailQueue()
                    .add(CapitalCallDocument.builder().documentId(i.longValue()).build()));
    capitalCallEmailNotificationService.enqueueDocumentForEmail(document);
    assertEquals(QUEUE_CAPACITY, capitalCallEmailNotificationService.getEmailQueue().size());
  }

  @Test
  void enqueueDocumentForEmail_interrupted() {
    Thread.currentThread().interrupt();
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    capitalCallEmailNotificationService.enqueueDocumentForEmail(document);
    assertTrue(Thread.currentThread().isInterrupted());
  }

  @Test
  void stopProcessing() {
    capitalCallEmailNotificationService.stopProcessing();
    assertFalse(capitalCallEmailNotificationService.isRunning());
  }

  @Test
  void testServiceTerminationSuccessfully() {
    capitalCallEmailNotificationService.cleanup();
    verify(emailSenderService, times(1)).shutdown();
  }

  @Test
  void testServiceTerminationWithInterruption() throws InterruptedException {
    doThrow(new InterruptedException()).when(emailSenderService).awaitTermination(anyLong(), any());
    capitalCallEmailNotificationService.cleanup();
    verify(emailSenderService, times(1)).shutdownNow();
  }

  @Test
  void testServiceTerminationWhenTasksRemainUnprocessed() throws InterruptedException {
    when(emailSenderService.awaitTermination(anyLong(), any())).thenReturn(false);
    capitalCallEmailNotificationService.cleanup();
    verify(emailSenderService, times(1)).shutdownNow();
  }

  @Test
  void processDocumentWithValidAuditLogs() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    var auditLog = mock(CapitalCallAuditLog.class);
    when(capitalCallAuditService.getAuditLog(1L)).thenReturn(Mono.just(auditLog));
    capitalCallEmailNotificationService.enqueueDocumentForEmail(document);
    capitalCallEmailNotificationService.stopProcessing();
    capitalCallEmailNotificationService.processAndSendEmails();
    verify(capitalCallAuditService, times(1)).getAuditLog(1L);
  }

  @Test
  void processDocumentWithNoAuditLogs() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    when(capitalCallAuditService.getAuditLog(1L)).thenReturn(Mono.empty());
    capitalCallEmailNotificationService.enqueueDocumentForEmail(document);
    capitalCallEmailNotificationService.stopProcessing();
    capitalCallEmailNotificationService.processAndSendEmails();
    verify(capitalCallAuditService, times(1)).getAuditLog(1L);
  }

  @Test
  void testForExceptionsDuringProcessing() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    capitalCallEmailNotificationService.getEmailQueue().add(document);
    when(capitalCallAuditService.getAuditLog(1L))
        .thenThrow(new RuntimeException("Unexpected error"));
    capitalCallEmailNotificationService.stopProcessing();
    capitalCallEmailNotificationService.processAndSendEmails();
    assertFalse(capitalCallEmailNotificationService.isRunning());
  }

  @Test
  void processDocumentWithQueueNotEmptyButNotRunning() {
    capitalCallEmailNotificationService.stopProcessing();
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    capitalCallEmailNotificationService.getEmailQueue().add(document);
    capitalCallEmailNotificationService.processAndSendEmails();
    assertTrue(capitalCallEmailNotificationService.getEmailQueue().isEmpty());
  }

  @Test
  void cleanupSuccessfullyCompletesTasks() throws InterruptedException {
    when(emailSenderService.awaitTermination(60, TimeUnit.SECONDS)).thenReturn(true);
    capitalCallEmailNotificationService.cleanup();
    assertFalse(capitalCallEmailNotificationService.isRunning());
  }

  @Test
  void fetchLastAuditAndSendEmailSuccessfully() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    var audit =
        CapitalCallAudit.builder()
            .previousStatus(CapitalCallStatus.NEW_CAPITAL_CALL)
            .nextStatus(CapitalCallStatus.WIRE_CHECK)
            .build();
    var auditLog = CapitalCallAuditLog.builder().audit(Collections.singletonList(audit)).build();
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("other@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    when(emailViaSalesforceService.sendEmailNotification(any(), any(), any(), any()))
        .thenReturn(Mono.empty());
    emailViaSalesforceService.sendEmailNotification(any(), any(), any(), any());
    capitalCallEmailNotificationService.getLastAuditAndSendEmail(document, auditLog).block();
    verify(emailViaSalesforceService, times(1)).sendEmailNotification(any(), any(), any(), any());
  }

  @Test
  void handleMissingAudits() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    var auditLog =
        CapitalCallAuditLog.builder()
            .audit(
                Collections.singletonList(
                    CapitalCallAudit.builder()
                        .previousStatus(CapitalCallStatus.NEW_CAPITAL_CALL)
                        .nextStatus(CapitalCallStatus.WIRE_CHECK)
                        .build()))
            .build();
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("other@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    when(emailViaSalesforceService.sendEmailNotification(any(), any(), any(), any()))
        .thenReturn(Mono.empty());
    emailViaSalesforceService.sendEmailNotification(any(), any(), any(), any());
    capitalCallEmailNotificationService.getLastAuditAndSendEmail(document, auditLog).block();
    verify(emailViaSalesforceService, times(1)).sendEmailNotification(any(), any(), any(), any());
  }

  @Test
  void sendEmailSuccessfully() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    var audit =
        CapitalCallAudit.builder()
            .previousStatus(CapitalCallStatus.NEW_CAPITAL_CALL)
            .nextStatus(CapitalCallStatus.WIRE_CHECK)
            .build();
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("test@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    when(thymeleafTemplateEngine.process(anyString(), any())).thenReturn("Some HTML Content");
    capitalCallEmailNotificationService.sendDocumentAuditEmail(document, audit).block();
    verify(thymeleafTemplateEngine, times(1)).process(anyString(), any());
  }

  @Test
  void handleMissingEmailAddressesOrExceptions() {
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .account(Account.builder().clientId(123L).id(123L).build())
            .build();
    var audit =
        CapitalCallAudit.builder()
            .previousStatus(CapitalCallStatus.NEW_CAPITAL_CALL)
            .nextStatus(CapitalCallStatus.WIRE_CHECK)
            .build();
    when(cpdWSCache.getReviewers(any(), any()))
        .thenReturn(Mono.error(new RuntimeException("Unexpected error")));
    capitalCallEmailNotificationService.sendDocumentAuditEmail(document, audit).block();
    verify(cpdWSCache, times(1)).getReviewers(any(), any());
  }

  @Test
  void getEmailAddressSuccessfullyForWireCheckStatus() {
    var tagEntry = TagEntry.builder().cpdValue("email1@test.com,email2@test.com").build();
    var tagEntries = Map.of(PermissionHelperConstants.WIRE_TRANSFER, tagEntry);
    var result =
        capitalCallEmailNotificationService.extractEmailAddressesBasedOnStatus(
            tagEntries, CapitalCallStatus.WIRE_CHECK);
    assertTrue(result.contains("email1@test.com"));
    assertTrue(result.contains("email2@test.com"));
  }

  @Test
  void handleErrorsInGetEmailAddresses() {
    assertEquals(
        Collections.emptySet(),
        capitalCallEmailNotificationService.extractEmailAddressesBasedOnStatus(
            new HashMap<>(), CapitalCallStatus.WIRE_CHECK));
  }

  @Test
  void testExtractEmailAddressesBasedOnStatusForValidStatus() {
    var tagEntries = new HashMap<String, TagEntry>();
    tagEntries.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("test@example.com, another@example.com").build());
    var emails =
        capitalCallEmailNotificationService.extractEmailAddressesBasedOnStatus(
            tagEntries, CapitalCallStatus.WIRE_CHECK);
    assertEquals(2, emails.size());
    assertTrue(emails.contains("test@example.com"));
    assertTrue(emails.contains("another@example.com"));
  }

  @Test
  void shouldCreateHtmlContentForNewCapitalCall() {
    var document =
        CapitalCallDocument.builder()
            .documentName("Sample Document")
            .paymentAmount(new BigDecimal("1000"))
            .callReceivedDate(LocalDate.of(2023, 8, 29))
            .dueDate(LocalDate.of(2023, 9, 5))
            .security(
                Security.builder()
                    .currency(Currency.builder().code("USD").build())
                    .fundDetail(
                        FundDetail.builder().name("Sample Fund").gpName("Sample GP").build())
                    .build())
            .build();
    when(thymeleafTemplateEngine.process(anyString(), any())).thenReturn("Some HTML Content");
    var htmlContent = capitalCallEmailNotificationService.htmlContentForNewCapitalCall(document);
    assertNotNull(htmlContent);
  }

  @Test
  void shouldExtractEmailAddressesFromTagEntries() {
    Map<String, TagEntry> tagEntries =
        Map.of(
            PermissionHelperConstants.WIRE_TRANSFER,
            TagEntry.builder().cpdValue("test1@example.com").build(),
            PermissionHelperConstants.INITIAL,
            TagEntry.builder().cpdValue("test2@example.com").build());
    List<String> keys =
        Arrays.asList(PermissionHelperConstants.WIRE_TRANSFER, PermissionHelperConstants.INITIAL);
    var emails =
        capitalCallEmailNotificationService.extractEmailAddressesFromTagEntries(tagEntries, keys);
    assertEquals(2, emails.size());
    assertTrue(emails.contains("test1@example.com"));
    assertTrue(emails.contains("test2@example.com"));
  }

  @Test
  void shouldGetAllReviewers() {
    var document =
        CapitalCallDocument.builder()
            .account(Account.builder().clientId(123L).id(456L).build())
            .build();
    Map<String, TagEntry> tagEntries =
        Map.of(
            PermissionHelperConstants.WIRE_TRANSFER,
            TagEntry.builder().cpdValue("reviewer1@example.com").build(),
            PermissionHelperConstants.INITIAL,
            TagEntry.builder().cpdValue("reviewer2@example.com").build());
    when(cpdWSCache.getReviewers(123L, 456L))
        .thenReturn(Mono.just(new ConcurrentHashMap<>(tagEntries)));
    var reviewers = capitalCallEmailNotificationService.getAllReviewers(document).block();
    assert reviewers != null;
    assertEquals(2, reviewers.size());
    assertTrue(reviewers.contains("reviewer1@example.com"));
    assertTrue(reviewers.contains("reviewer2@example.com"));
  }
}
