package com.cwan.privatefund.capital.call.constant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.cwan.privatefund.cpd.ws.constant.CpdWSField;
import org.junit.jupiter.api.Test;

class CapitalCallConstantsTest {

  @Test
  void testCommonConstants() {
    var splitPattern = CapitalCallConstants.CommonConstants.SPLIT_PATTERN;
    assertNotNull(splitPattern);
    assertEquals("[,;]", splitPattern.pattern());
  }

  @Test
  void testPermissionHelperConstants() {
    var wireTransfer = CapitalCallConstants.PermissionHelperConstants.WIRE_TRANSFER;
    assertNotNull(wireTransfer);
    assertEquals(CpdWSField.WIRE_TRANSFER.getFieldName(), wireTransfer);
    var initial = CapitalCallConstants.PermissionHelperConstants.INITIAL;
    assertNotNull(initial);
    assertEquals(CpdWSField.INITIAL.getFieldName(), initial);
    var finalStr = CapitalCallConstants.PermissionHelperConstants.FINAL;
    assertNotNull(finalStr);
    assertEquals(CpdWSField.FINAL.getFieldName(), finalStr);
    var emailSplitPattern = CapitalCallConstants.PermissionHelperConstants.EMAIL_SPLIT_PATTERN;
    assertNotNull(emailSplitPattern);
    assertEquals(CapitalCallConstants.CommonConstants.SPLIT_PATTERN, emailSplitPattern);
  }

  @Test
  void testScheduledServiceConstants() {
    var timeFormat = CapitalCallConstants.ScheduledServiceConstants.TIME_FORMAT;
    assertNotNull(timeFormat);
    assertEquals("HH:mm:ss", timeFormat);
  }
}
