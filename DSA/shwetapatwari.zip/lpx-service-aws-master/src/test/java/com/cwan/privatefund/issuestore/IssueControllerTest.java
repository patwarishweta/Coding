package com.cwan.privatefund.issuestore;

import static com.cwan.privatefund.TestUtil.ISSUE_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getIssue;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.issuestore.model.Issue;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class IssueControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private IssueService issueService;
  private static final Issue ISSUE = getIssue();
  private static final Long DOCUMENT_ID = 123456789L;
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @BeforeAll
  static void beforeAll() {
    System.setProperty("env", "ci");
  }

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
    when(issueService.getDocumentErrors(DOCUMENT_ID)).thenReturn(Flux.just(ISSUE));
  }

  @Test
  void should_get_document_errors() {
    var actual =
        exchangeForEntity(
                String.format("%s%s%s", ISSUE_URI, "/document/error?documentId=", DOCUMENT_ID))
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(Issue.class)
            .getResponseBody()
            .blockFirst();
    Assertions.assertEquals(ISSUE, actual);
  }

  @Test
  void should_update_issue_store_controller() {
    Set<Issue> issueSet = new HashSet<>();
    issueSet.add(ISSUE);
    when(issueService.updateIssues(issueSet)).thenReturn(Flux.just(ISSUE));
    webClient
        .put()
        .uri("/v1/issues")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(issueSet)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(Issue.class)
        .hasSize(1)
        .contains(ISSUE);
  }

  private WebTestClient.ResponseSpec exchangeForEntity(final String uri) {
    return webClient.method(HttpMethod.GET).uri(uri).exchange();
  }
}
