package com.cwan.privatefund.document;

import static com.cwan.privatefund.TestUtil.getAccount;
import static com.cwan.privatefund.TestUtil.getDocument;
import static com.cwan.privatefund.TestUtil.getMissingDocumentAlertConfig;
import static com.cwan.privatefund.TestUtil.getMissingDocumentExpectationsConfig;
import static com.cwan.privatefund.TestUtil.getSecurity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.after;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.balance.LpxBalanceEntityService;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.constant.Constants;
import com.cwan.privatefund.document.model.DocumentAudit;
import com.cwan.privatefund.document.signed.url.SignedUrlAuditService;
import com.cwan.privatefund.issuestore.IssueStoreClient;
import com.cwan.privatefund.issuestore.model.Issue;
import com.cwan.privatefund.issuestore.model.IssueStatus;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.transaction.LpxTransactionService;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.entity.ByteArrayEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class LpxDocumentServiceTest {

  private static final Document DOCUMENT = getDocument();
  private static final Account ACCOUNT = getAccount();
  private static final Security SECURITY = getSecurity();
  private static final Set<Document> DOCUMENT_SET = Set.of(DOCUMENT);
  private static final String CLOUD_STORAGE_ID = "409d529e-fd25-4b23-b672-26ad762b5e62";
  private static final Mono<Account> ACCOUNT_MONO = Mono.just(ACCOUNT);
  private static final Mono<Security> SECURITY_MONO = Mono.just(SECURITY);
  private static final LocalDate BEGIN_DATE = LocalDate.of(2024, 4, 1);
  private static final LocalDate END_DATE = LocalDate.of(2024, 4, 30);
  private static final List<String> TYPES =
      Arrays.asList("Capital Call Notice", "Capital Account Statement");
  @Mock private AccountService accountService;
  @Mock private HttpClient httpClient;
  @Mock private HttpResponse httpResponse;
  @Mock private Documents documents;
  @Mock private SecurityService securityService;
  @Mock private LpxDocumentServiceClient lpxDocumentServiceClient;
  @Mock private FilePart filePart;
  @Mock private IssueStoreClient issueStoreClient;
  @Mock private BusinessWSClient businessWSClient;
  private LpxDocumentService lpxDocumentService;
  @Mock private LpxTransactionService lpxTransactionService;
  @Mock private LpxBalanceEntityService lpxBalanceEntityService;
  @Mock private DocumentAuditService documentAuditService;
  @Mock private SignedUrlAuditService signedUrlAuditService;
  @Mock private SecurityContextUserService securityContextUserService;

  private void setupGetHttpClientResponses(byte[] responseBody) throws IOException {
    when(httpClient.execute(any())).thenReturn(httpResponse);
    when(httpResponse.getEntity()).thenReturn(new ByteArrayEntity(responseBody));
  }

  @Test
  void appendDocumentNameBeforeExtension_multiplePeriods_test() {
    String documentName = "document.tryThis.pdf";
    String expected = "document.tryThis_20200101_200400.pdf";
    String actual =
        DocumentUtils.appendTimestampBeforeExtension(
            documentName, LocalDateTime.of(2020, 1, 1, 20, 4), 75);
    assertEquals(expected, actual);
  }

  @Test
  void appendDocumentNameBeforeExtension_noExtension_test() {
    String documentName = "document";
    String expected = "document_20200101_200400";
    String actual =
        DocumentUtils.appendTimestampBeforeExtension(
            documentName, LocalDateTime.of(2020, 1, 1, 20, 4), 75);
    assertEquals(expected, actual);
  }

  @Test
  void appendDocumentNameBeforeExtension_nullDate_test() {
    String documentName = "document.tryThis.pdf";
    String expected = "document.tryThis_.pdf";
    String actual = DocumentUtils.appendTimestampBeforeExtension(documentName, null, 75);
    assertEquals(expected, actual);
  }

  @Test
  void appendDocumentNameBeforeExtension_test() {
    String documentName = "document.pdf";
    String expected = "document_20200101_200400.pdf";
    String actual =
        DocumentUtils.appendTimestampBeforeExtension(
            documentName, LocalDateTime.of(2020, 1, 1, 20, 4), 75);
    assertEquals(expected, actual);
  }

  @Test
  void appendDocumentNameBeforeExtension_truncate() {
    String documentName = "document.tryThis.pdf";
    String expected = "doc_.pdf";
    String actual = DocumentUtils.appendTimestampBeforeExtension(documentName, null, 3);
    assertEquals(expected, actual);
  }

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(accountService.getAccountData(eq(DOCUMENT.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(accountService.getAccountWithClientData(anyLong())).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(DOCUMENT.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    when(accountService.getAccountsData(any())).thenReturn(Mono.just(List.of(ACCOUNT)));
    when(securityService.getSecurities(any(), any(), any()))
        .thenReturn(Mono.just(List.of(SECURITY)));
    when(lpxDocumentServiceClient.getDocumentDataByCanoeId(any()))
        .thenReturn(Mono.just(TestUtil.getCanoeData()));
    lpxDocumentService =
        new LpxDocumentService(
            accountService,
            documents,
            securityService,
            lpxDocumentServiceClient,
            httpClient,
            lpxTransactionService,
            lpxBalanceEntityService,
            issueStoreClient,
            businessWSClient,
            documentAuditService,
            signedUrlAuditService,
            securityContextUserService);
  }

  @Test
  void delete_document_using_doc_id_method() {
    when(documents.getDocumentById(anyLong())).thenReturn(Mono.just(DOCUMENT));
    DOCUMENT.setIsDisabled(true);
    when(documents.updateDocumentInfo(any())).thenReturn(Flux.just(DOCUMENT));
    when(lpxTransactionService.getTransactionsByDocumentId(anyLong())).thenReturn(Flux.empty());
    when(lpxBalanceEntityService.getBalancesByDocumentIds(eq(Set.of(23L))))
        .thenReturn(Flux.empty());
    StepVerifier.create(lpxDocumentService.deleteDocumentByDocId(23L))
        .expectNextMatches(Document::getIsDisabled)
        .verifyComplete();
  }

  @Test
  void delete_document_using_doc_id_method_throw_error_if_balances_found_on_doc() {
    when(lpxTransactionService.getTransactionsByDocumentId(anyLong())).thenReturn(Flux.empty());
    when(lpxBalanceEntityService.getBalancesByDocumentIds(eq(Set.of(23L))))
        .thenReturn(Flux.just(TestUtil.getBalance(anyLong())));
    StepVerifier.create(lpxDocumentService.deleteDocumentByDocId(23L))
        .expectErrorMessage(
            "This Document:23 was received from upstream or automatically added. hence cannot be deleted")
        .verify();
  }

  @Test
  void delete_document_using_doc_id_method_throw_error_if_only_transactions_found_on_doc() {
    when(lpxTransactionService.getTransactionsByDocumentId(anyLong()))
        .thenReturn(Flux.just(TestUtil.getTransaction()));
    when(lpxBalanceEntityService.getBalancesByDocumentIds(eq(Set.of(23L))))
        .thenReturn(Flux.empty());
    StepVerifier.create(lpxDocumentService.deleteDocumentByDocId(23L))
        .expectErrorMessage(
            "This document:23 has transactions associated with it either delete the transaction or change the document reference for associated transactions")
        .verify();
  }

  @Test
  void fetchActiveDocumentsInDateRange_emptyCollections() {
    Set<Long> accountIds = Set.of();
    Set<Long> securityIds = Set.of();
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(), any(), any(), any(), any()))
        .thenReturn(Flux.empty());
    var result =
        lpxDocumentService.fetchActiveDocumentsInDateRange(
            accountIds, securityIds, beginDate, endDate);
    StepVerifier.create(result).verifyComplete();
  }

  @Test
  void fetchActiveDocumentsInDateRange_errorCase() {
    Set<Long> accountIds = Set.of(42L);
    Set<Long> securityIds = Set.of(123L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(accountIds),
            eq(securityIds),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.error(new RuntimeException("Test error")));
    StepVerifier.create(
            lpxDocumentService.fetchActiveDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .expectError(RuntimeException.class)
        .verify();
  }

  @Test
  void fetchActiveDocumentsInDateRange_multipleDocuments() {
    Set<Long> accountIds = Set.of(42L);
    Set<Long> securityIds = Set.of(123L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Document doc1 = DOCUMENT;
    Document doc2 = DOCUMENT.toBuilder().id(456L).build();
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(accountIds),
            eq(securityIds),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.just(doc1, doc2));
    var result =
        lpxDocumentService.fetchActiveDocumentsInDateRange(
            accountIds, securityIds, beginDate, endDate);
    StepVerifier.create(result).expectNext(doc1, doc2).verifyComplete();
  }

  @Test
  void fetchActiveDocumentsInDateRange_onlyAccounts() {
    Set<Long> accountIds = Set.of(42L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Mockito.lenient()
        .when(
            documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                any(), any(), any(), any(), any()))
        .thenReturn(Flux.empty());
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(accountIds),
            isNull(),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.just(DOCUMENT));
    var result =
        lpxDocumentService.fetchActiveDocumentsInDateRange(accountIds, null, beginDate, endDate);
    StepVerifier.create(result).expectNext(DOCUMENT).verifyComplete();
  }

  @Test
  void fetchActiveDocumentsInDateRange_onlySecurities() {
    Set<Long> securityIds = Set.of(123L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Mockito.lenient()
        .when(
            documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                any(), any(), any(), any(), any()))
        .thenReturn(Flux.empty());
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            isNull(),
            eq(securityIds),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.just(DOCUMENT));
    var result =
        lpxDocumentService.fetchActiveDocumentsInDateRange(null, securityIds, beginDate, endDate);
    StepVerifier.create(result).expectNext(DOCUMENT).verifyComplete();
  }

  @Test
  void fetchActiveDocumentsInDateRange_withAccountsAndSecurities() {
    Set<Long> accountIds = Set.of(42L);
    Set<Long> securityIds = Set.of(123L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Mockito.lenient()
        .when(
            documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                any(), any(), any(), any(), any()))
        .thenReturn(Flux.empty());
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(accountIds),
            eq(securityIds),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.just(DOCUMENT));
    var result =
        lpxDocumentService.fetchActiveDocumentsInDateRange(
            accountIds, securityIds, beginDate, endDate);
    StepVerifier.create(result).expectNext(DOCUMENT).verifyComplete();
  }

  @Test
  void get_document_using_cash_mvmt_date_and_type_method() {
    when(documents.getDocumentsByAccountsAndCashMvmtDateBetweenAndTypes(
            (eq(Set.of(ACCOUNT.getId()))), eq(BEGIN_DATE), eq(END_DATE), eq(TYPES)))
        .thenReturn(Flux.just(DOCUMENT));
    assertEquals(
        DOCUMENT,
        lpxDocumentService
            .getDocumentsByAccountsAndCashMvmtDateBetweenAndType(
                Set.of(ACCOUNT.getId()),
                BEGIN_DATE,
                END_DATE,
                "Capital Call Notice,Capital Account Statement")
            .blockFirst());
  }

  @Test
  void get_document_using_cash_mvmt_date_and_type_method_if_type_null() {
    when(documents.getDocumentsByAccountsAndCashMvmtDateBetween(
            (eq(Set.of(ACCOUNT.getId()))), eq(BEGIN_DATE), eq(END_DATE)))
        .thenReturn(Flux.just(DOCUMENT));
    assertEquals(
        DOCUMENT,
        lpxDocumentService
            .getDocumentsByAccountsAndCashMvmtDateBetweenAndType(
                Set.of(ACCOUNT.getId()), BEGIN_DATE, END_DATE, null)
            .blockFirst());
  }

  @Test
  void get_document_using_doc_date_method() {
    when(documents.getDocumentsByAccountsAndDocumentDateBetween(
            (eq(Set.of(ACCOUNT.getId()))), eq(BEGIN_DATE), eq(END_DATE)))
        .thenReturn(Flux.just(DOCUMENT));
    assertEquals(
        DOCUMENT,
        lpxDocumentService
            .getDocumentsByAccountsAndDocumentDateBetween(
                Set.of(ACCOUNT.getId()), BEGIN_DATE, END_DATE)
            .blockFirst());
  }

  @Test
  void get_document_using_received_date_and_type_method() {
    when(documents.getDocumentsByAccountsAndReceivedDateBetweenAndTypes(
            (eq(Set.of(ACCOUNT.getId()))), eq(BEGIN_DATE), eq(END_DATE), eq(TYPES)))
        .thenReturn(Flux.just(DOCUMENT));
    assertEquals(
        DOCUMENT,
        lpxDocumentService
            .getDocumentsByAccountsAndReceivedDateBetweenAndType(
                Set.of(ACCOUNT.getId()),
                BEGIN_DATE,
                END_DATE,
                "Capital Call Notice,Capital Account Statement",
                true)
            .blockFirst());
  }

  @Test
  void get_document_using_received_date_and_type_method_if_type_null() {
    when(documents.getDocumentsByAccountsAndReceivedDateBetween(
            (eq(Set.of(ACCOUNT.getId()))), eq(BEGIN_DATE), eq(END_DATE)))
        .thenReturn(Flux.just(DOCUMENT));
    assertEquals(
        DOCUMENT,
        lpxDocumentService
            .getDocumentsByAccountsAndReceivedDateBetweenAndType(
                Set.of(ACCOUNT.getId()), BEGIN_DATE, END_DATE, null, true)
            .blockFirst());
  }

  @Test
  void get_missing_document_using_account_id() {
    var doc =
        List.of(
            MissingDocuments.builder()
                .accountId(123L)
                .documentMissingCategory(MissingDocumentStatus.RECEIVED)
                .build(),
            MissingDocuments.builder()
                .accountId(123L)
                .documentMissingCategory(MissingDocumentStatus.MISSING)
                .build());
    when(lpxDocumentServiceClient.getMissingDocuments(123L)).thenReturn(Flux.fromIterable(doc));
    assertEquals(doc, lpxDocumentService.getMissingDocuments(123L).collectList().block());
  }

  @Test
  void getAuthorizedDocumentsInDateRange_AccountExpansionFails() {
    Collection<Long> accountIds = List.of(1L);
    Collection<Long> securityIds = List.of(100L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    when(accountService.expandAccountIds(accountIds))
        .thenReturn(Mono.error(new RuntimeException("Account expansion failed")));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(Collection.class),
            any(Collection.class),
            any(LocalDate.class),
            any(LocalDate.class),
            any(Collection.class)))
        .thenReturn(Flux.empty());
    StepVerifier.create(
            lpxDocumentService.getAuthorizedDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .expectError(RuntimeException.class)
        .verify();
  }

  @Test
  void getAuthorizedDocumentsInDateRange_EmptyAccountIds() {
    Collection<Long> accountIds = Collections.emptyList();
    Collection<Long> securityIds = List.of(100L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    when(accountService.expandAccountIds(accountIds)).thenReturn(Mono.empty());
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(Collection.class),
            any(Collection.class),
            any(LocalDate.class),
            any(LocalDate.class),
            any(Collection.class)))
        .thenReturn(Flux.empty());
    StepVerifier.create(
            lpxDocumentService.getAuthorizedDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .verifyComplete();
  }

  @Test
  void getAuthorizedDocumentsInDateRange_NoAuthorizedAccounts() {
    Collection<Long> accountIds = List.of(1L);
    Collection<Long> securityIds = List.of(100L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Set<Long> expandedIds = Set.of(1L, 2L, 3L);
    Set<Long> authorizedIds = Set.of(4L, 5L);
    Integer userId = 42;
    when(accountService.expandAccountIds(accountIds)).thenReturn(Mono.just(expandedIds));
    when(securityContextUserService.validateAndGetUserId()).thenReturn(Mono.just(userId));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(authorizedIds));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(Collection.class),
            any(Collection.class),
            any(LocalDate.class),
            any(LocalDate.class),
            any(Collection.class)))
        .thenReturn(Flux.empty());
    StepVerifier.create(
            lpxDocumentService.getAuthorizedDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .verifyComplete();
  }

  @Test
  void getAuthorizedDocumentsInDateRange_NullAccountIds() {
    Collection<Long> accountIds = Arrays.asList(1L, null, 2L);
    Collection<Long> securityIds = List.of(100L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Set<Long> expandedIds = Set.of(1L, 2L);
    Set<Long> authorizedIds = Set.of(1L, 2L);
    Integer userId = 42;
    when(accountService.expandAccountIds(accountIds)).thenReturn(Mono.just(expandedIds));
    when(securityContextUserService.validateAndGetUserId()).thenReturn(Mono.just(userId));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(authorizedIds));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(Collection.class),
            any(Collection.class),
            any(LocalDate.class),
            any(LocalDate.class),
            any(Collection.class)))
        .thenReturn(Flux.just(DOCUMENT));
    StepVerifier.create(
            lpxDocumentService.getAuthorizedDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .expectNext(DOCUMENT)
        .verifyComplete();
  }

  @Test
  void getAuthorizedDocumentsInDateRange_Success() {
    Collection<Long> accountIds = List.of(1L);
    Collection<Long> securityIds = List.of(100L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Set<Long> expandedIds = new TreeSet<>(Set.of(1L, 2L));
    Set<Long> authorizedIds = new TreeSet<>(Set.of(1L, 2L));
    Integer userId = 42;
    when(accountService.expandAccountIds(accountIds)).thenReturn(Mono.just(expandedIds));
    when(securityContextUserService.validateAndGetUserId()).thenReturn(Mono.just(userId));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(authorizedIds));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(),
            any(),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.just(DOCUMENT));
    StepVerifier.create(
            lpxDocumentService.getAuthorizedDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .expectNext(DOCUMENT)
        .verifyComplete();
    ArgumentCaptor<Collection<Long>> accountsCaptor = ArgumentCaptor.forClass(Collection.class);
    ArgumentCaptor<Collection<Long>> securitiesCaptor = ArgumentCaptor.forClass(Collection.class);
    verify(documents)
        .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            accountsCaptor.capture(),
            securitiesCaptor.capture(),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE)));
    assertEquals(
        new TreeSet<>(expandedIds),
        new TreeSet<>(accountsCaptor.getValue()),
        "Account IDs should match regardless of order");
    assertEquals(
        new HashSet<>(securityIds),
        new HashSet<>(securitiesCaptor.getValue()),
        "Security IDs should match regardless of order");
  }

  @Test
  void getAuthorizedDocumentsInDateRange_UserValidationFails() {
    Collection<Long> accountIds = List.of(1L);
    Collection<Long> securityIds = List.of(100L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Set<Long> expandedIds = Set.of(1L, 2L, 3L);
    when(accountService.expandAccountIds(accountIds)).thenReturn(Mono.just(expandedIds));
    when(securityContextUserService.validateAndGetUserId())
        .thenReturn(Mono.error(new RuntimeException("User validation failed")));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            any(Collection.class),
            any(Collection.class),
            any(LocalDate.class),
            any(LocalDate.class),
            any(Collection.class)))
        .thenReturn(Flux.empty());
    StepVerifier.create(
            lpxDocumentService.getAuthorizedDocumentsInDateRange(
                accountIds, securityIds, beginDate, endDate))
        .expectError(RuntimeException.class)
        .verify();
  }

  @Test
  void getAuthorizedDocumentsInDateRange_WithDatesOnly_NoAuthorizedAccounts() {
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Integer userId = 42;
    Set<Long> authorizedAccounts = Collections.emptySet();
    when(securityContextUserService.validateAndGetUserId()).thenReturn(Mono.just(userId));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(authorizedAccounts));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(authorizedAccounts),
            eq(Collections.emptyList()),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.empty());
    StepVerifier.create(lpxDocumentService.getAuthorizedDocumentsInDateRange(beginDate, endDate))
        .verifyComplete();
  }

  @Test
  void getAuthorizedDocumentsInDateRange_WithDatesOnly_Success() {
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    Integer userId = 42;
    Set<Long> authorizedAccounts = Set.of(1L, 2L);
    when(securityContextUserService.validateAndGetUserId()).thenReturn(Mono.just(userId));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(authorizedAccounts));
    when(documents.getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(authorizedAccounts),
            eq(Collections.emptyList()),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE))))
        .thenReturn(Flux.just(DOCUMENT));
    StepVerifier.create(lpxDocumentService.getAuthorizedDocumentsInDateRange(beginDate, endDate))
        .expectNext(DOCUMENT)
        .verifyComplete();
    verify(securityContextUserService).validateAndGetUserId();
    verify(accountService).retrieveUserAccessibleAccountIds(userId);
    verify(documents)
        .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
            eq(authorizedAccounts),
            eq(Collections.emptyList()),
            eq(beginDate),
            eq(endDate),
            eq(Set.of(Constants.GEN_AI_DOCUMENTS_SOURCE)));
  }

  @Test
  void getAuthorizedDocumentsInDateRange_WithDatesOnly_UserValidationFails() {
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    when(securityContextUserService.validateAndGetUserId())
        .thenReturn(Mono.error(new RuntimeException("User validation failed")));
    StepVerifier.create(lpxDocumentService.getAuthorizedDocumentsInDateRange(beginDate, endDate))
        .expectError(RuntimeException.class)
        .verify();
  }

  @Test
  void should_add_document() {
    when(lpxDocumentServiceClient.saveDocument(eq(DOCUMENT))).thenReturn(Flux.just(DOCUMENT));
    var actual = lpxDocumentService.addDocuments(DOCUMENT_SET).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  @Timeout(10000)
  void should_update_assignee_details_on_document_info() {
    when(documents.getDocumentsByAccountsAndCashMvmtDateBetween(any(), any(), any()))
        .thenReturn(Flux.just(DOCUMENT));
    when(accountService.getAccountData(eq(DOCUMENT.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(accountService.getAccountWithClientData(anyLong())).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(DOCUMENT.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    when(lpxDocumentServiceClient.getDocumentDataByCanoeId(
            eq(Set.of("892994fa-b33c-11eb-ba61-d50ed001af0a"))))
        .thenReturn(Mono.just(TestUtil.getCanoeData()));
    when(lpxDocumentServiceClient.fetchUserDetails(
            eq(Set.of("21352b9a-bf7f-11e9-a3dc-06787d7750d6"))))
        .thenReturn(Flux.fromIterable(TestUtil.getAssigneeData()));
    when(documents.updateDocumentInfo(any()))
        .thenReturn(
            Flux.just(
                DOCUMENT.toBuilder()
                    .assigneeId("21352b9a-bf7f-11e9-a3dc-06787d7750d6")
                    .assigneeName("David Dominguez")
                    .assigneeEmail("ddominguez@clearwateranalytics.com")
                    .build()));
    when(documents.getDocumentsByAccountsAndCashMvmtDateBetween(any(), any(), any()))
        .thenReturn(Flux.just(DOCUMENT.toBuilder().createdOn(LocalDateTime.now()).build()));
    lpxDocumentService
        .getDocumentsByAccountsAndCashMvmtDateBetween(Set.of(42L), LocalDate.now(), LocalDate.now())
        .subscribe();
    verify(lpxDocumentServiceClient, after(5000).times(1)).getDocumentDataByCanoeId(any());
    verify(lpxDocumentServiceClient, after(5000).times(1)).fetchUserDetails(any());
  }

  @Test
  void should_update_document_info() {
    when(documents.updateDocumentInfo(eq(DOCUMENT_SET))).thenReturn(Flux.just(DOCUMENT));
    when(accountService.getAccountData(eq(DOCUMENT.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(accountService.getAccountWithClientData(anyLong())).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(DOCUMENT.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxDocumentService.updateDocumentInfo(DOCUMENT_SET).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_upload_File() {
    when(lpxDocumentServiceClient.uploadFile(any())).thenReturn(Mono.just(CLOUD_STORAGE_ID));
    var actual = lpxDocumentService.uploadFile(Flux.just(filePart)).blockFirst();
    assertEquals(CLOUD_STORAGE_ID, actual);
  }

  @Test
  void test_calls_deleteMissingDocumentAlerts_with_clientId_and_returns_flux() {
    Long clientId = 123L;
    when(lpxDocumentServiceClient.deleteMissingDocumentAlerts(clientId)).thenReturn(Mono.empty());
    lpxDocumentService.deleteMissingDocumentAlertsByClientId(clientId);
    verify(lpxDocumentServiceClient).deleteMissingDocumentAlerts(clientId);
  }

  @Test
  void test_delete_missing_document_expectations_successfully() {
    Long securityId = 123L;
    String documentType = "Capital Call";
    when(lpxDocumentServiceClient.deleteMissingDocumentExpectation(securityId, documentType))
        .thenReturn(Mono.empty());
    lpxDocumentService.deleteMissingDocumentExpectationsBySecurityIdAndDocumentType(
        securityId, documentType);
    verify(lpxDocumentServiceClient).deleteMissingDocumentExpectation(securityId, documentType);
  }

  @Test
  void test_document_service_exception_throw_method() {
    when(documents.getDocumentById(eq(123L))).thenReturn(Mono.just(DOCUMENT));
    assertEquals(DOCUMENT, lpxDocumentService.getDocumentById(123L).block());
  }

  @Test
  void test_expands_account_ids_correctly_before_fetching_documents() {
    Set<Long> accountIds = Set.of(1L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 12, 31);
    AccountService accountService = mock(AccountService.class);
    Documents documents = mock(Documents.class);
    IssueStoreClient issueStoreClient = mock(IssueStoreClient.class);
    BusinessWSClient businessWSClient = mock(BusinessWSClient.class);
    when(accountService.expandAccountId(1L)).thenReturn(Flux.just(1L, 2L));
    when(documents.getDocumentsByAccountsAndReceivedDateBetween(anySet(), any(), any()))
        .thenReturn(Flux.empty());
    LpxDocumentService lpxDocumentService =
        new LpxDocumentService(
            accountService,
            documents,
            null,
            null,
            null,
            null,
            null,
            issueStoreClient,
            businessWSClient,
            documentAuditService,
            signedUrlAuditService,
            securityContextUserService);
    Flux<DocumentAudit> result =
        lpxDocumentService.getAllDocumentsByAccountAndDateRange(accountIds, beginDate, endDate);
    StepVerifier.create(result).expectNextCount(0);
  }

  @Test
  void test_returns_audit_documents_for_valid_account_ids_and_date_range() {
    Set<Long> accountIds = Set.of(1L, 2L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 12, 31);
    LpxDocumentService lpxDocumentService = mock(LpxDocumentService.class);
    when(lpxDocumentService.getAllDocumentsByAccountAndDateRange(accountIds, beginDate, endDate))
        .thenReturn(Flux.just(new DocumentAudit()));
    Flux<DocumentAudit> result =
        lpxDocumentService.getAllDocumentsByAccountAndDateRange(accountIds, beginDate, endDate);
    StepVerifier.create(result).expectNextCount(1).verifyComplete();
  }

  @Test
  void test_returns_flux_of_missing_document_alerts_when_service_client_returns_non_empty_list() {
    var alertConfig = getMissingDocumentAlertConfig();
    when(lpxDocumentServiceClient.getAllMissingDocumentAlerts()).thenReturn(Flux.just(alertConfig));
    Flux<MissingDocumentAlertConfig> result = lpxDocumentService.getMissingDocumentsAlerts();
    StepVerifier.create(result).expectNext(alertConfig).verifyComplete();
  }

  @Test
  void test_returns_flux_of_missing_document_expectations() {
    var expectationsConfig = getMissingDocumentExpectationsConfig();
    when(lpxDocumentServiceClient.getMissingDocumentExpectations())
        .thenReturn(Flux.just(expectationsConfig));
    Flux<MissingDocumentExpectationsConfig> result =
        lpxDocumentService.getMissingDocumentsExpectations();
    StepVerifier.create(result).expectNext(expectationsConfig).verifyComplete();
  }

  @Test
  void test_save_single_missing_document_alert_config_successfully() {
    MissingDocumentAlertConfig config = getMissingDocumentAlertConfig();
    when(lpxDocumentServiceClient.saveMissingDocumentAlerts(any())).thenReturn(Flux.just(config));
    Flux<MissingDocumentAlertConfig> result = lpxDocumentService.saveMissingDocumentAlerts(config);
    StepVerifier.create(result).expectNext(config).verifyComplete();
  }

  @Test
  void test_saves_valid_missing_document_expectations_config() {
    MissingDocumentExpectationsConfig config = getMissingDocumentExpectationsConfig();
    when(lpxDocumentServiceClient.saveMissingDocumentExpectationsConfigs(any()))
        .thenReturn(Flux.just(config));
    Flux<MissingDocumentExpectationsConfig> result =
        lpxDocumentService.saveMissingDocumentExpectationsConfigs(config);
    StepVerifier.create(result).expectNext(config).verifyComplete();
  }

  @Test
  void test_zip_method() throws IOException {
    setupGetHttpClientResponses("this is a very good test".getBytes());
    when(lpxDocumentServiceClient.getSignedUrl(123L))
        .thenReturn(Mono.just("signedUrl.arbfund.com"));
    when(documents.getDocumentById(eq(123L))).thenReturn(Mono.just(DOCUMENT));
    var zipFileFromDocumentIds = lpxDocumentService.getZipFileFromDocumentIds(Set.of(123L));
    assertNotNull(zipFileFromDocumentIds);
  }

  @Test
  void testGetAllDocumentsByAccountAndDateRange() {
    IssueStatus issueStatus = new IssueStatus();
    issueStatus.setUserId(1);
    Issue issue = new Issue();
    issue.setStatus(issueStatus);
    Set<Long> accountIds = Set.of(1L);
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 1, 31);
    User user = Mockito.mock(User.class);
    Mockito.when(user.getFullname()).thenReturn("fullname");
    when(accountService.expandAccountId(anyLong())).thenReturn(Flux.just(2L, 3L));
    when(documents.getDocumentsByAccountsAndReceivedDateBetween(anySet(), any(), any()))
        .thenReturn(Flux.just(DOCUMENT));
    when(issueStoreClient.getIssuesByTag(anyString())).thenReturn(Flux.just(issue));
    when(businessWSClient.fetchUserDetails(anyInt())).thenReturn(Mono.just(user));
    Flux<DocumentAudit> flux =
        lpxDocumentService.getAllDocumentsByAccountAndDateRange(accountIds, beginDate, endDate);
    StepVerifier.create(flux)
        .assertNext(
            documentAudit -> {
              assertEquals(ACCOUNT.getId(), documentAudit.getAccountId());
              assertEquals(SECURITY.getSecurityId(), documentAudit.getSecurityId());
              assertEquals(issue, documentAudit.getIssue());
            });
  }
}
