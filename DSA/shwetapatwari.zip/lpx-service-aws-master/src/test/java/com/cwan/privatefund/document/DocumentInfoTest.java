package com.cwan.privatefund.document;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.pbor.document.DocumentEntity;
import com.cwan.privatefund.document.model.DocumentAuditValidationEntity;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DocumentInfoTest {

  private DocumentInfo documentInfo;
  private DocumentEntity documentEntity;
  private DocumentAuditValidationEntity documentAuditValidationEntity;

  @BeforeEach
  void setUp() {
    documentInfo = new DocumentInfo();
    documentEntity = mock(DocumentEntity.class);
    documentAuditValidationEntity = mock(DocumentAuditValidationEntity.class);

    // Set handlers for the entities
    documentInfo.setDocumentEntity(documentEntity);
    documentInfo.setDocumentAuditValidationEntity(documentAuditValidationEntity);
  }

  @Test
  void testIsValidated_withNullDocumentEntity() {
    documentInfo.setDocumentEntity(null);
    assertFalse(documentInfo.isValidated());
  }

  @Test
  void testIsValidated_withCheckedTrue() {
    when(documentEntity.getChecked()).thenReturn(true);
    assertTrue(documentInfo.isValidated());
  }

  @Test
  void testIsValidated_withCheckedFalse() {
    when(documentEntity.getChecked()).thenReturn(false);
    assertFalse(documentInfo.isValidated());
  }

  @Test
  void testIsValidated_withCheckedNull() {
    when(documentEntity.getChecked()).thenReturn(null);
    assertFalse(documentInfo.isValidated());
  }

  @Test
  void testValidationDate_withNullAuditEntity() {
    documentInfo.setDocumentAuditValidationEntity(null);
    assertNull(documentInfo.validationDate());
  }

  @Test
  void testValidationDate_withNullModifiedOn() {
    when(documentAuditValidationEntity.getModifiedOn()).thenReturn(null);
    documentInfo.setDocumentAuditValidationEntity(documentAuditValidationEntity);
    assertNull(documentInfo.validationDate());
  }

  @Test
  void testValidationDate_withNotValidated() {
    when(documentAuditValidationEntity.getModifiedOn()).thenReturn(LocalDateTime.now());
    when(documentEntity.getChecked()).thenReturn(false);
    assertNull(documentInfo.validationDate());
  }

  @Test
  void testValidationDate_withValidated() {
    LocalDateTime now = LocalDateTime.now();
    when(documentEntity.getChecked()).thenReturn(true);
    when(documentAuditValidationEntity.getModifiedOn()).thenReturn(now);
    assertEquals(now, documentInfo.validationDate());
  }
}
