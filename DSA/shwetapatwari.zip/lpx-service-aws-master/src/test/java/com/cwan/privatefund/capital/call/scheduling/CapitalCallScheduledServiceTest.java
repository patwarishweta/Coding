package com.cwan.privatefund.capital.call.scheduling;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.privatefund.capital.call.service.CapitalCallBlacklistService;
import com.cwan.privatefund.capital.call.service.CapitalCallEmailNotificationService;
import com.cwan.privatefund.capital.call.service.LpxCapitalCallService;
import com.cwan.privatefund.leadership.service.LpxLeadershipManager;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.integration.leader.Context;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class CapitalCallScheduledServiceTest {

  @Mock private LpxCapitalCallService capitalCallService;
  @Mock private Context context;
  @Mock private LpxLeadershipManager lpxLeadershipManager;
  @Mock private CapitalCallEmailNotificationService capitalCallEmailNotificationService;
  @Mock private CapitalCallBlacklistService capitalCallBlacklistService;
  private CapitalCallScheduledService service;

  @BeforeEach
  void setUp() {
    service =
        new CapitalCallScheduledService(
            capitalCallService,
            lpxLeadershipManager,
            capitalCallEmailNotificationService,
            capitalCallBlacklistService);
  }

  @Test
  void insertMissedCapitalCallsScheduledTask_LeaderScenario() {
    when(context.isLeader()).thenReturn(true);
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(context);
    when(capitalCallService.insertMissedCapitalCalls()).thenReturn(Mono.empty());
    service.insertMissedCapitalCalls();
    verify(capitalCallService, timeout(5000).times(1)).insertMissedCapitalCalls();
    verifyNoMoreInteractions(capitalCallService);
  }

  @Test
  void insertMissedCapitalCallsScheduledTask_NotLeader() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(null);
    service.insertMissedCapitalCalls();
    verify(capitalCallService, never()).insertMissedCapitalCalls();
  }

  @Test
  void sendNewCapitalCallNotifications_NotLeader() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(null);
    service.sendNewCapitalCallNotifications();
    verify(capitalCallService, never())
        .getCapitalCallsByStatuses(Collections.singleton(CapitalCallStatus.NEW_CAPITAL_CALL));
  }

  @Test
  void sendNewCapitalCallNotifications_LeaderScenario_Blacklist() {
    var document = CapitalCallDocument.builder().build();
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(context);
    when(context.isLeader()).thenReturn(true);
    when(capitalCallService.getCapitalCallsByStatuses(
            Collections.singleton(CapitalCallStatus.NEW_CAPITAL_CALL)))
        .thenReturn(Flux.just(document));
    when(capitalCallBlacklistService.evaluateBlacklistStatus(any())).thenReturn(Mono.just(true));
    when(capitalCallBlacklistService.updateCapitalCallStatus(any(), eq(true)))
        .thenReturn(Mono.just(document));
    service.sendNewCapitalCallNotifications();
    verify(capitalCallEmailNotificationService, timeout(5000)).sendNewCapitalCallEmail(any());
  }

  @Test
  void sendNewCapitalCallNotifications_LeaderScenario_NonBlacklist() {
    var document = CapitalCallDocument.builder().build();
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(context);
    when(context.isLeader()).thenReturn(true);
    when(capitalCallService.getCapitalCallsByStatuses(
            Collections.singleton(CapitalCallStatus.NEW_CAPITAL_CALL)))
        .thenReturn(Flux.just(document));
    when(capitalCallBlacklistService.evaluateBlacklistStatus(any())).thenReturn(Mono.just(false));
    when(capitalCallBlacklistService.updateCapitalCallStatus(any(), eq(false)))
        .thenReturn(Mono.just(document));
    service.sendNewCapitalCallNotifications();
    verify(capitalCallEmailNotificationService, timeout(5000)).sendNewCapitalCallEmail(any());
  }

  @Test
  void insertMissedCapitalCalls_ErrorScenario() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(context);
    when(context.isLeader()).thenReturn(true);
    when(capitalCallService.insertMissedCapitalCalls())
        .thenReturn(Mono.error(new RuntimeException("Mocked exception")));
    service.insertMissedCapitalCalls();
    verify(capitalCallService, timeout(5000)).insertMissedCapitalCalls();
  }
}
