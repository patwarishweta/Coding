package com.cwan.privatefund.capital.call.management.helper;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.management.model.BankAccountCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankAccountResponse;
import com.cwan.privatefund.capital.call.management.model.BankBlacklistResponse;
import com.cwan.privatefund.capital.call.management.model.BankCreationRequest;
import com.cwan.privatefund.capital.call.management.model.BankResponse;
import lombok.experimental.UtilityClass;

@UtilityClass
public class CapitalCallManagementTestHelper {

  public static final Integer USER_ID = 1;
  public static final Long ACCOUNT_ID = 1L;
  public static final Long CLIENT_ID = 1L;
  public static final String ABA_ROUTING_NUMBER = "123456789";
  public static final String ACCOUNT_NAME = "Sample Account";
  public static final String ACCOUNT_NUMBER = "1234567890123456";
  public static final String BANK_NAME = "ICICI Bank";
  public static final String BASE_URL = "/v1/capitalCallManagement/";
  public static final String CLIENT_NAME = "Sample Client";
  public static final String CREATOR_EMAIL = "fsarwar@clearwateranalytics.com";
  public static final String CREATOR_NAME = "Fahad Sarwar";
  public static final String EMAIL = "fsarwar@clearwateranalytics.com";
  public static final String FULL_NAME = "Fahad Sarwar";
  public static final String IBAN = "DE89370400440532013000";
  public static final String SWIFT_CHIPS_CODE = "SWIFT1234";
  public static final String UUID_ACCOUNT = "123e4567-e89b-12d3-a456-426614174001";
  public static final String UUID_BANK = "123e4567-e89b-12d3-a456-426614174000";
  public static final String UUID_BLACKLIST = "123e4567-e89b-12d3-a456-426614174333";
  public static final String UUID_NOT_FOUND = "123e4567-e89b-12d3-a456-426614174222";
  public static final long ID = 1L;
  private static final BankAccountCreationRequest SAMPLE_BANK_ACCOUNT_REQUEST;
  private static final BankAccountResponse SAMPLE_BANK_ACCOUNT_RESPONSE;
  private static final BankCreationRequest SAMPLE_BANK_REQUEST;
  private static final BankResponse SAMPLE_BANK_RESPONSE;
  private static final BankBlacklistResponse SAMPLE_BANK_BLACKLIST_RESPONSE;
  private static final Bank SAMPLE_BANK;
  private static final Account SAMPLE_ACCOUNT;
  private static final BankAccount SAMPLE_BANK_ACCOUNT;
  private static final BankBlacklist SAMPLE_BANK_BLACKLIST;
  private static final User SAMPLE_USER;

  static {
    SAMPLE_BANK_ACCOUNT_REQUEST =
        BankAccountCreationRequest.builder()
            .bankUuid(UUID_BANK)
            .accountId(ID)
            .accountName(ACCOUNT_NAME)
            .accountNumber(ACCOUNT_NUMBER)
            .iban(IBAN)
            .build();
    SAMPLE_BANK_ACCOUNT_RESPONSE =
        BankAccountResponse.builder()
            .bankAccountUuid(UUID_ACCOUNT)
            .bankUuid(UUID_BANK)
            .bankName(BANK_NAME)
            .accountId(ID)
            .accountName(ACCOUNT_NAME)
            .accountNumber(ACCOUNT_NUMBER)
            .iban(IBAN)
            .creatorName(CREATOR_NAME)
            .creatorEmail(CREATOR_EMAIL)
            .build();
    SAMPLE_BANK_REQUEST =
        BankCreationRequest.builder()
            .clientId(ID)
            .bankName(BANK_NAME)
            .abaRoutingNumber(ABA_ROUTING_NUMBER)
            .swiftChipsCode(SWIFT_CHIPS_CODE)
            .build();
    SAMPLE_BANK_RESPONSE =
        BankResponse.builder()
            .bankUuid(UUID_BANK)
            .clientId(ID)
            .clientName(CLIENT_NAME)
            .bankName(BANK_NAME)
            .abaRoutingNumber(ABA_ROUTING_NUMBER)
            .swiftChipsCode(SWIFT_CHIPS_CODE)
            .creatorName(CREATOR_NAME)
            .creatorEmail(CREATOR_EMAIL)
            .build();
    SAMPLE_BANK_BLACKLIST_RESPONSE =
        BankBlacklistResponse.builder()
            .bankBlacklistUuid(UUID_BLACKLIST)
            .bankUuid(UUID_BANK)
            .bankName(BANK_NAME)
            .creatorName(CREATOR_NAME)
            .creatorEmail(CREATOR_EMAIL)
            .build();
    SAMPLE_BANK =
        Bank.builder()
            .bankUuid(UUID_BANK)
            .clientId(CLIENT_ID)
            .bankName(BANK_NAME)
            .abaRoutingNumber(ABA_ROUTING_NUMBER)
            .swiftChipsCode(SWIFT_CHIPS_CODE)
            .createdBy(CLIENT_ID)
            .build();
    SAMPLE_ACCOUNT =
        Account.builder().id(ACCOUNT_ID).clientId(CLIENT_ID).name(ACCOUNT_NAME).build();
    SAMPLE_BANK_ACCOUNT =
        BankAccount.builder()
            .bankAccountUuid(UUID_ACCOUNT)
            .bank(SAMPLE_BANK)
            .accountId(ACCOUNT_ID)
            .accountName(ACCOUNT_NAME)
            .accountNumber(ACCOUNT_NUMBER)
            .iban(IBAN)
            .createdBy(CLIENT_ID)
            .build();
    SAMPLE_BANK_BLACKLIST =
        BankBlacklist.builder()
            .bankBlacklistUuid(UUID_BLACKLIST)
            .bank(SAMPLE_BANK)
            .createdBy(CLIENT_ID)
            .build();
    SAMPLE_USER =
        User.builder().id(USER_ID).fullname(FULL_NAME).email(EMAIL).clientId(CLIENT_ID).build();
  }

  public static BankAccountCreationRequest getSampleBankAccountRequest() {
    return SAMPLE_BANK_ACCOUNT_REQUEST;
  }

  public static BankAccountResponse getSampleBankAccountResponse() {
    return SAMPLE_BANK_ACCOUNT_RESPONSE;
  }

  public static BankCreationRequest getSampleBankRequest() {
    return SAMPLE_BANK_REQUEST;
  }

  public static BankResponse getSampleBankResponse() {
    return SAMPLE_BANK_RESPONSE;
  }

  public static BankBlacklistResponse getSampleBankBlacklistResponse() {
    return SAMPLE_BANK_BLACKLIST_RESPONSE;
  }

  public static Bank getSampleBank() {
    return SAMPLE_BANK;
  }

  public static Account getSampleAccount() {
    return SAMPLE_ACCOUNT;
  }

  public static BankAccount getSampleBankAccount() {
    return SAMPLE_BANK_ACCOUNT;
  }

  public static BankBlacklist getSampleBankBlacklist() {
    return SAMPLE_BANK_BLACKLIST;
  }

  public static User getSampleUser() {
    return SAMPLE_USER;
  }
}
