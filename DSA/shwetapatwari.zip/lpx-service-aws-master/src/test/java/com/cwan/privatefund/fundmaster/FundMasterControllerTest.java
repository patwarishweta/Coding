package com.cwan.privatefund.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.FundIdNameResponseProjection;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.fundmaster.Fund;
import com.cwan.pbor.fundmaster.FundAliasKey;
import com.cwan.pbor.fundmaster.FundInternalMappingEntity;
import com.cwan.pbor.fundmaster.FundInternalMappingKey;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.FundMasterOverrideEntity;
import com.cwan.pbor.fundmaster.ManagementFeesEntity;
import com.cwan.pbor.fundmaster.PortfolioCompanyEntity;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Flux;

class FundMasterControllerTest {

  private static FundMasterController fundMasterController;

  private static final Long SECURITY_ID = 100L;
  private static final Long CLIENT_ID = 24601L;
  private static final Integer USER_ID = 77436;
  private static final Long ACCOUNT_ID = 1337L;
  private static final Long FUND_ID = 1L;
  private static final String EIN = "string";
  private static final String ALIAS = "Hello";

  private static LpxFundMasterService fundMasterService;

  private static final FundInternalMappingEntity fundInternalMappingEntity =
      new FundInternalMappingEntity(new FundInternalMappingKey(FUND_ID, SECURITY_ID));
  private static final FundMasterEntity fundMasterEntity =
      FundMasterEntity.builder().id(FUND_ID).ein(EIN).build();
  private static final FundMasterEntity overrideEntity =
      fundMasterEntity.toBuilder().cik("testCIK").build();
  private static final FundMasterOverrideEntity overrideObject =
      FundMasterOverrideEntity.builder()
          .clientId(CLIENT_ID)
          .securityId(SECURITY_ID)
          .overrideObject(overrideEntity)
          .build();
  private static final FundIdNameResponseProjection fundIdName =
      new FundIdNameResponseProjection() {
        @Override
        public Long getId() {
          return 1L;
        }

        @Override
        public String getName() {
          return "Test Fund";
        }
      };
  private static final ManagementFeesEntity managementFeesEntity =
      ManagementFeesEntity.builder().fundId(FUND_ID).build();
  private static final PortfolioCompanyEntity portfolioCompanyEntity =
      PortfolioCompanyEntity.builder().fundId(FUND_ID).build();
  private static final Account ACCOUNT_OBJECT = Account.builder().id(ACCOUNT_ID).build();
  private static final Security SECURITYOBJECT = Security.builder().securityId(SECURITY_ID).build();
  private static final Collection<Map<String, Object>> fundManagerData =
      List.of(
          Map.of(
              "account",
              ACCOUNT_OBJECT,
              "security",
              SECURITYOBJECT,
              "overrideLevel",
              CLIENT_ID,
              "overrideEntity",
              overrideEntity,
              "fundMasterEntity",
              fundMasterEntity));

  private static final Fund starterFund =
      new Fund(
          SECURITY_ID,
          fundMasterEntity,
          List.of(managementFeesEntity),
          List.of(portfolioCompanyEntity));

  @BeforeAll
  static void beforeAll() {
    System.setProperty("env", "ci");
    fundMasterService = mock(LpxFundMasterService.class);
    when(fundMasterService.saveFundInternalMapping(Set.of(fundInternalMappingEntity)))
        .thenReturn(List.of(fundInternalMappingEntity));
    when(fundMasterService.saveFundMasterEntity(Set.of(fundMasterEntity)))
        .thenReturn(List.of(fundMasterEntity));
    when(fundMasterService.savePortfolioCompanies(Set.of(portfolioCompanyEntity)))
        .thenReturn(List.of(portfolioCompanyEntity));
    when(fundMasterService.saveManagementFees(Set.of(managementFeesEntity)))
        .thenReturn(List.of(managementFeesEntity));
    when(fundMasterService.getFundDataByEins(any())).thenReturn(List.of(starterFund));
    when(fundMasterService.getAllInternalFunds()).thenReturn(List.of(fundMasterEntity));
    when(fundMasterService.getAllInternalFundsNameId()).thenReturn(List.of(fundIdName));
    when(fundMasterService.getFundDataBySecurities(any())).thenReturn(List.of(starterFund));
    when(fundMasterService.getFundDataWithOverridesBySecurities(anyLong(), anyLong(), any()))
        .thenReturn(List.of(starterFund));
    when(fundMasterService.saveFundAliasKey(any())).thenReturn(new FundAliasKey(FUND_ID, ALIAS));
    when(fundMasterService.getFundMasterAndOverrideEntitiesBySecurityAndClient(any(), any()))
        .thenReturn(Map.of("fundMasterEntity", fundMasterEntity, "overrideEntity", overrideEntity));
    when(fundMasterService.getFundMasterAndOverrideEntitiesBySecurityAndAccount(any(), any()))
        .thenReturn(Map.of("fundMasterEntity", fundMasterEntity, "overrideEntity", overrideEntity));
    when(fundMasterService.saveFundMasterOverrides(Set.of(overrideObject)))
        .thenReturn(List.of(overrideObject));
    when(fundMasterService.getAllEntitiesForClientOriginalAndOverride(anyLong(), anyInt()))
        .thenReturn(Flux.fromStream(fundManagerData.stream()));

    fundMasterController = new FundMasterController(fundMasterService);
  }

  @Test
  void should_save_fund_master_data() {
    List<FundMasterEntity> fundMasterEntities =
        fundMasterController.saveFundMasterData(Set.of(fundMasterEntity));
    assertEquals(fundMasterEntity, fundMasterEntities.get(0));
  }

  @Test
  void savePortfolioCompany() {
    List<PortfolioCompanyEntity> portfolioCompanyEntities =
        fundMasterController.savePortfolioCompany(Set.of(portfolioCompanyEntity));
    assertEquals(portfolioCompanyEntity, portfolioCompanyEntities.get(0));
  }

  @Test
  void saveManagementFees() {
    List<ManagementFeesEntity> managementFeesEntities =
        fundMasterController.saveManagementFees(Set.of(managementFeesEntity));
    assertEquals(managementFeesEntity, managementFeesEntities.get(0));
  }

  @Test
  void saveFundInternalMappings() {
    List<FundInternalMappingEntity> fundInternalMappingEntities =
        fundMasterController.saveFundInternalMappings(Set.of(fundInternalMappingEntity));
    assertEquals(fundInternalMappingEntity, fundInternalMappingEntities.get(0));
  }

  @Test
  void getAllInternalFunds() {
    Collection<FundMasterEntity> internalFunds = fundMasterController.getAllInternalFunds();
    assertEquals(fundMasterEntity, internalFunds.iterator().next());
  }

  @Test
  void getAllInternalFundsNameId() {
    Collection<FundIdNameResponseProjection> internalFunds =
        fundMasterController.getAllInternalFundsNameId();
    assertEquals(fundIdName, internalFunds.iterator().next());
  }

  @Test
  void getFundDataBySecurities() {
    Collection<Fund> fundDataBySecurities =
        fundMasterController.getFundDataBySecurities(Set.of(SECURITY_ID));
    assertEquals(starterFund, fundDataBySecurities.stream().findAny().get());
  }

  @Test
  void getFundDataByEins() {
    Collection<Fund> fundDataByEins = fundMasterController.getFundDataByEins(Set.of(EIN));
    assertEquals(starterFund, fundDataByEins.stream().findAny().get());
  }

  @Test
  void saveAliasForFund() {
    FundAliasKey expected = new FundAliasKey(FUND_ID, ALIAS);
    FundAliasKey actual = fundMasterController.saveFundAlias(expected);
    assertEquals(expected, actual);
  }

  @Test
  void getFundIdentifiers() {
    assertEquals(0, fundMasterController.getFundIdentifiers().size());
  }

  @Test
  void getFundEntityAndOverrideEntityByClient() {
    Map<String, FundMasterEntity> result =
        fundMasterController.getFundDataBySecurityAndClientOverrideAndOriginal(
            CLIENT_ID, SECURITY_ID);
    assertEquals(fundMasterEntity, result.get("fundMasterEntity"));
    assertEquals(overrideEntity, result.get("overrideEntity"));
  }

  @Test
  void getFundEntityAndOverrideEntityByAccount() {
    Map<String, FundMasterEntity> result =
        fundMasterController.getFundDataBySecurityAndAccountOverrideAndOriginal(
            ACCOUNT_ID, SECURITY_ID);
    assertEquals(fundMasterEntity, result.get("fundMasterEntity"));
    assertEquals(overrideEntity, result.get("overrideEntity"));
  }

  @Test
  void saveOverride() {
    Collection<FundMasterOverrideEntity> result =
        fundMasterController.saveFundMasterOverrides(Set.of(overrideObject));
    assertEquals(List.of(overrideObject), result);
  }

  @Test
  void getAllForClientOriginalAndOverride() {
    Collection<Map<String, Object>> result =
        fundMasterController
            .getAllForClientOriginalAndOverride(CLIENT_ID, USER_ID)
            .collect(Collectors.toList())
            .toFuture()
            .join();
    assertEquals(CLIENT_ID, result.stream().findFirst().get().get("overrideLevel"));
    assertEquals(fundMasterEntity, result.stream().findFirst().get().get("fundMasterEntity"));
    assertEquals(overrideEntity, result.stream().findFirst().get().get("overrideEntity"));
    assertEquals(ACCOUNT_OBJECT, result.stream().findFirst().get().get("account"));
  }

  @Test
  void delete_fund_internal_mappings() {
    fundMasterController.deleteFundInternalMappings(Set.of(fundInternalMappingEntity));

    verify(fundMasterService, times(1)).deleteFundMasterEntity(Set.of(fundInternalMappingEntity));
  }
}
