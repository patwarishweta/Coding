package com.cwan.privatefund.comment;

import static com.cwan.privatefund.TestUtil.COMMENT_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getComment;
import static com.cwan.privatefund.TestUtil.getCommentRequest;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentRequest;
import com.cwan.privatefund.transaction.model.TransactionRequest;
import java.time.Duration;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class CommentControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private CommentService commentService;
  private static final Set<Comment> COMMENTS = Set.of(getComment());
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_add_comments() {
    var newComment = getComment();
    newComment.setId(1L);
    when(commentService.addComments(eq(COMMENTS))).thenReturn(Flux.just(newComment));
    var actual = getPostForEntity(Mono.just(getCommentRequest()));
    assertEquals(Set.of(newComment), actual);
  }

  @Test
  void should_get_comments_by_document_id() {
    var documentId = 9L;
    when(commentService.getCommentsByDocumentId(eq(documentId)))
        .thenReturn(Flux.fromIterable(COMMENTS));
    var actual = getCommentsEntity(format("%s%s%d", COMMENT_URI, "/document/", documentId), GET);
    assertEquals(COMMENTS, actual);
  }

  @Test
  void should_delete_comments_by_id() {
    var commentId = 1L;
    getCommentsEntity(format("%s%s%d", COMMENT_URI, "?ids=", commentId), DELETE);
    verify(commentService).deleteCommentsById(Set.of(commentId));
  }

  private Set<Comment> getCommentsEntity(final String uri, final HttpMethod httpMethod) {
    return Set.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri, httpMethod)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(Comment.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private Set<Comment> getPostForEntity(final Mono<CommentRequest> request) {
    return Set.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(request)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(Comment.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final HttpMethod httpMethod) {
    return webClient.method(httpMethod).uri(uri).exchange();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(final Mono<CommentRequest> request) {
    return webClient
        .method(HttpMethod.POST)
        .uri(com.cwan.privatefund.TestUtil.COMMENT_URI)
        .body(request, TransactionRequest.class)
        .exchange();
  }
}
