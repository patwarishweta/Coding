package com.cwan.privatefund.leadership.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.integration.leader.Context;

class LpxLeadershipManagerTest {

  private LpxLeadershipManager lpxLeadershipManager;
  @Mock private Context mockContext;

  @BeforeEach
  void setUp() {
    lpxLeadershipManager = new LpxLeadershipManager();
  }

  @Test
  void testSetAndGetLeadershipContext() {
    lpxLeadershipManager.setLpxLeadershipContext(mockContext);
    Assertions.assertEquals(
        mockContext,
        lpxLeadershipManager.getLpxLeadershipContext(),
        "The set context should match the retrieved one.");
  }
}
