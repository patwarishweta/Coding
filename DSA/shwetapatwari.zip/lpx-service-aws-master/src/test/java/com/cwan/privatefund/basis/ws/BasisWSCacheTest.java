package com.cwan.privatefund.basis.ws;

import static com.cwan.privatefund.TestUtil.getBasis;
import static com.cwan.privatefund.basis.ws.BasisWSConfig.ACCOUNT_ID_TO_BASES;
import static com.cwan.privatefund.basis.ws.BasisWSConfig.BASIS_ID_TO_BASES;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.basis.ws.model.Basis;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;

public class BasisWSCacheTest {

  @Mock private BasisWSClient basisWSClient;
  @Mock private RedisTemplate<String, Object> redisTemplate;
  @Mock private HashOperations hashOperations;

  private static final Long ACCOUNT_ID = 1337L;
  private static final Basis BASIS = getBasis();
  private static final List<Basis> BASIS_LIST = List.of(BASIS);

  private BasisWSCache instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
    when(basisWSClient.getEnabledBases(eq(ACCOUNT_ID))).thenReturn(List.of(BASIS.getBasisId()));
    instance = new BasisWSCache(basisWSClient, redisTemplate);
  }

  @Test
  void should_get_enabled_bases_from_account_id_to_bases_cache() {
    when(hashOperations.get(eq(ACCOUNT_ID_TO_BASES), eq(ACCOUNT_ID))).thenReturn(BASIS_LIST);
    var actual = instance.getEnabledBases(ACCOUNT_ID);
    assertEquals(BASIS_LIST, actual);
  }

  @Test
  void should_get_enabled_bases_from_basis_id_to_basis_cache() {
    when(hashOperations.get(eq(ACCOUNT_ID_TO_BASES), eq(ACCOUNT_ID))).thenReturn(null);
    when(hashOperations.get(eq(BASIS_ID_TO_BASES), eq(BASIS.getBasisId()))).thenReturn(BASIS);
    var actual = instance.getEnabledBases(ACCOUNT_ID);
    assertEquals(BASIS_LIST, actual);
  }

  @Test
  void should_get_enabled_bases_from_ws() {
    when(hashOperations.get(eq(ACCOUNT_ID_TO_BASES), eq(ACCOUNT_ID))).thenReturn(null);
    when(hashOperations.get(eq(BASIS_ID_TO_BASES), eq(BASIS.getBasisId()))).thenReturn(null);
    when(basisWSClient.getBases()).thenReturn(List.of(BASIS));
    var actual = instance.getEnabledBases(ACCOUNT_ID);
    assertEquals(BASIS_LIST, actual);
  }
}
