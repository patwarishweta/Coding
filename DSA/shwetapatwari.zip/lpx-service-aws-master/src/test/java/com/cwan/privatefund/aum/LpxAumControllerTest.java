package com.cwan.privatefund.aum;

import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getAumRequest;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Aum;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.aum.model.AumRequest;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
class LpxAumControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webTestClient;

  @MockBean private LpxAumService lpxAumService;
  @MockBean private ExcelCreationService excelCreationService;

  private static final AumRequest AUM_REQUEST = getAumRequest();

  private static LocalDate DATE = LocalDate.now();
  private static final Aum AUM =
      Aum.builder()
          .id(1L)
          .accountId(2L)
          .securityId(3L)
          .ultimateParentId(4L)
          .clientId(5L)
          .calculatedOn(DATE)
          .aum(324.0)
          .build();
  private static final Set<Aum> AUM_SET = Set.of(AUM);
  private static final List<Aum> AUM_LIST = List.of(AUM);
  private static final Map<Long, List<Aum>> AUM_ID_LIST_MAP = Map.of(1L, AUM_LIST);
  private static final Map<Long, Set<Aum>> AUM_ID_SET_MAP = Map.of(1L, AUM_SET);

  @Autowired private WebTestClient webClient;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_get_aum_by_ultimate_parent_id() {
    String ids = "4";
    Map<Long, List<Aum>> expectedResult = AUM_ID_LIST_MAP;
    when(lpxAumService.getAumByUltimateParentIds(Set.of(4L))).thenReturn(expectedResult);

    webTestClient
        .get()
        .uri("/v1/aum/ultimate-parent-ids?id=" + ids)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .expectBody();

    verify(lpxAumService).getAumByUltimateParentIds(Set.of(4L));
  }

  @Test
  void shouldUpdateAum() {
    when(lpxAumService.updateAums(AUM_REQUEST)).thenReturn(AUM_ID_SET_MAP);

    webTestClient
        .put()
        .uri("/v1/aum/update")
        .bodyValue(AUM_REQUEST)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .expectBody();
  }

  @Test
  void shouldTestExcelCreation() {
    String ids = "4";
    Map<Long, List<Aum>> expectedResult = AUM_ID_LIST_MAP;
    when(lpxAumService.getAumByUltimateParentIds(Set.of(4L))).thenReturn(expectedResult);
    byte[] byteArray = new byte[0];
    when(excelCreationService.generateExcelFile(Set.of(4L), DATE)).thenReturn(byteArray);
    webTestClient
        .get()
        .uri(
            "/v1/aum/excel/ultimate-parent-ids?calculationDate="
                + DATE
                + "&ultimateParentIds="
                + ids)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .expectBody();
    verify(excelCreationService).generateExcelFile(Set.of(4L), DATE);
  }
}
