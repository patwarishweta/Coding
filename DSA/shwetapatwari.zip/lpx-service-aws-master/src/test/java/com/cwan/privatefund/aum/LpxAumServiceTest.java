package com.cwan.privatefund.aum;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Aum;
import com.cwan.lpx.domain.Client;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.aum.api.Aums;
import com.cwan.privatefund.aum.model.AumRequest;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.calculated.CalculatedBalanceService;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class LpxAumServiceTest {

  @InjectMocks private LpxAumService lpxAumService;

  @Mock private Aums aums;

  @Mock private BusinessWSClient businessWSClient;

  @Mock private CalculatedBalanceService calculatedBalanceService;
  private static final LocalDate DATE = LocalDate.now();
  private static final Aum AUM =
      Aum.builder()
          .accountId(1L)
          .securityId(2L)
          .ultimateParentId(2L)
          .aum(4750.00)
          .clientId(1L)
          .calculatedOn(DATE)
          .isActive(true)
          .build();
  private static final Set<Long> IDS_SET = Set.of(1L);
  private static final Set<Aum> AUM_SET = Set.of(AUM);
  private static final AumRequest AUM_REQUEST = new AumRequest();
  private static final Client ultimateParentClient =
      Client.builder().parentId(2).shortName("Parent Client").build();
  private static final CalculatedBalance CALCULATED_BALANCE =
      CalculatedBalance.builder()
          .source("source")
          .security(Security.builder().securityId(2L).build())
          .account(
              Account.builder()
                  .id(1L)
                  .clientId(1L)
                  .client(ultimateParentClient)
                  .ultimateParentClient(ultimateParentClient)
                  .build())
          .currency("USD")
          .navImpact(4750.0)
          .watchlistNavImpact(0.0)
          .fundedCommitmentImpact(1.0)
          .unfundedCommitmentImpact(2.0)
          .recallableImpact(3.0)
          .build();
  private static final Long ID = 1L;

  @Test
  void testAddAums() {
    when(aums.addAums(AUM_SET)).thenReturn(AUM_SET);
    AUM_REQUEST.setAums(Set.of(AUM));
    Map<Long, Set<Aum>> result = lpxAumService.addAums(AUM_REQUEST);

    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  void testUpdateAums() {
    when(aums.updateAll(AUM_SET)).thenReturn(AUM_SET);
    AUM_REQUEST.setAums(Set.of(AUM));
    Map<Long, Set<Aum>> result = lpxAumService.updateAums(AUM_REQUEST);

    assertNotNull(result);
    assertEquals(1, result.size());
    verify(aums).updateAll(any());
  }

  @Test
  void testGetAumByUltimateParentIds() {
    when(businessWSClient.getClientAccountIds(anyLong())).thenReturn(Mono.just(List.of(ID)));
    when(calculatedBalanceService.calculateBalances(anyLong(), any(), any(), anyBoolean()))
        .thenReturn(Flux.just(CALCULATED_BALANCE));
    when(aums.upsertByAccountIdAndSecurityIdAndCalculatedOn(1L, 2L, DATE, AUM)).thenReturn(AUM);

    Map<Long, List<Aum>> result = lpxAumService.getAumByUltimateParentIds(Set.of(ID));

    assertNotNull(result);
    assertEquals(1, result.size());
    verify(businessWSClient).getClientAccountIds(any());
    verify(calculatedBalanceService).calculateBalances(1L, DATE, DATE, false);
    verify(aums).upsertByAccountIdAndSecurityIdAndCalculatedOn(1L, 2L, DATE, AUM);
  }

  @Test
  void testGetLPsByClientId() {
    when(businessWSClient.getClientAccountIds(any())).thenReturn(Mono.just(List.of(ID)));
    when(calculatedBalanceService.calculateBalances(anyLong(), any(), any(), anyBoolean()))
        .thenReturn(Flux.just(CALCULATED_BALANCE));

    Map<Integer, Integer> result = lpxAumService.getLPsCountByClientId(IDS_SET);

    assertNotNull(result);
    assertEquals(1, result.size());
    verify(businessWSClient).getClientAccountIds(any());
    verify(calculatedBalanceService).calculateBalances(1L, DATE, DATE, false);
  }

  @Test
  void testGetLPsByClientIdAndDateThrowError() {
    when(businessWSClient.getClientAccountIds(anyLong()))
        .thenReturn(Mono.error(new InterruptedException()));

    Map<Integer, Integer> lPsCountByClientId = lpxAumService.getLPsCountByClientId(IDS_SET);

    assertTrue(lPsCountByClientId.isEmpty());
  }

  @Test
  void testGetAumByUltimateParentIdsThrowError() {
    when(businessWSClient.getClientAccountIds(anyLong()))
        .thenReturn(Mono.error(new InterruptedException()));

    Map<Long, List<Aum>> result = lpxAumService.getAumByUltimateParentIds(Set.of(ID));

    assertTrue(result.isEmpty());
  }
}
