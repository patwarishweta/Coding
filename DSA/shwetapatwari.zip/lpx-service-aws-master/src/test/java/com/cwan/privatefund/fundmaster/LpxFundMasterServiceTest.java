package com.cwan.privatefund.fundmaster;

import static com.cwan.privatefund.TestUtil.getAccountConfig;
import static com.cwan.privatefund.fundmaster.LpxFundMasterService.DEFAULT_REPORTING_FREQUENCY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.FundIdNameResponseProjection;
import com.cwan.lpx.domain.ReportingFrequency;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.SecurityTypeDataDetail;
import com.cwan.pbor.fundmaster.Fund;
import com.cwan.pbor.fundmaster.FundAliasKey;
import com.cwan.pbor.fundmaster.FundInternalMappingEntity;
import com.cwan.pbor.fundmaster.FundInternalMappingKey;
import com.cwan.pbor.fundmaster.FundInternalMappingRepository;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.FundMasterOverrideEntity;
import com.cwan.pbor.fundmaster.FundMasterRepository;
import com.cwan.pbor.fundmaster.ManagementFeesEntity;
import com.cwan.pbor.fundmaster.PortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.api.FundMasterService;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.portfolio.PortfolioUtilsService;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

class LpxFundMasterServiceTest {

  private LpxFundMasterService INSTANCE;
  private final FundMasterService fundMasterService = mock(FundMasterService.class);
  private final FundInternalMappingRepository fundInternalMappingRepository =
      mock(FundInternalMappingRepository.class);
  private final PortfolioUtilsService portfolioUtilsService = mock(PortfolioUtilsService.class);
  private final AccountService accountService = mock(AccountService.class);
  private final BusinessWSCache businessWSCache = mock(BusinessWSCache.class);
  private final RedisTemplate redisTemplate = mock(RedisTemplate.class);
  private final AccountConfigServiceCache accountConfigServiceCache =
      mock(AccountConfigServiceCache.class);
  private static final Long SECURITY_ID = 100L;
  private static final Long CLIENT_ID = 24601L;
  private static final Long ACCOUNT_ID = 1337L;
  private static final Long FUND_ID = 1L;
  private static final Integer USER_ID = 77436;
  private static final String EIN = "string";

  private static final AccountConfig ACCOUNT_CONFIG = getAccountConfig();

  private static final FundInternalMappingEntity fundInternalMappingEntity =
      new FundInternalMappingEntity(new FundInternalMappingKey(FUND_ID, SECURITY_ID));
  private static final FundMasterEntity fundMasterEntity =
      FundMasterEntity.builder().id(FUND_ID).ein(EIN).build();
  private static final FundMasterOverrideEntity overrideEntity =
      FundMasterOverrideEntity.builder()
          .clientId(CLIENT_ID)
          .securityId(SECURITY_ID)
          .overrideObject(fundMasterEntity)
          .build();
  private static final FundIdNameResponseProjection fundIdName =
      new FundIdNameResponseProjection() {
        @Override
        public Long getId() {
          return 1L;
        }

        @Override
        public String getName() {
          return "Test Fund";
        }
      };
  private static final ManagementFeesEntity managementFeesEntity =
      ManagementFeesEntity.builder().fundId(FUND_ID).build();
  private static final PortfolioCompanyEntity portfolioCompanyEntity =
      PortfolioCompanyEntity.builder().fundId(FUND_ID).build();
  private static final FundMasterRepository fundMasterRepository = mock(FundMasterRepository.class);
  private static final Fund starterFund =
      new Fund(
          SECURITY_ID,
          fundMasterEntity,
          List.of(managementFeesEntity),
          List.of(portfolioCompanyEntity));
  private static Account ACCOUNT =
      Account.builder()
          .id(ACCOUNT_ID)
          .subscriptionStartDate(LocalDate.now())
          .aggregate(false)
          .build();
  private static Account AGGREGATE_ACCOUNT =
      Account.builder().id(1338L).subscriptionStartDate(LocalDate.now()).aggregate(true).build();
  private static Collection<Account> ACCOUNT_LIST = List.of(ACCOUNT, AGGREGATE_ACCOUNT);
  private static Security SECURITY =
      Security.builder()
          .securityId(SECURITY_ID)
          .cusip("TotallyRealCusip")
          .securityTypeDataDetail(
              SecurityTypeDataDetail.builder().isLimitedPartnership(true).build())
          .build();

  @Mock private HashOperations hashOperations;

  @BeforeEach
  void setup() {
    openMocks(this);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
    when(fundMasterService.saveFundMasterData(any())).thenReturn(List.of(fundMasterEntity));
    when(fundMasterService.saveFundInternalMappings(any()))
        .thenReturn(List.of(fundInternalMappingEntity));
    when(fundMasterService.saveManagementFeesData(any())).thenReturn(List.of(managementFeesEntity));
    when(fundMasterService.savePortfolioCompanyData(any()))
        .thenReturn(List.of(portfolioCompanyEntity));
    when(fundMasterRepository.findAllInternalFunds()).thenReturn(List.of(fundMasterEntity));
    when(fundMasterRepository.findAllInternalFundsNameAndIds()).thenReturn(List.of(fundIdName));
    when(fundMasterService.getFundInfoFromSecurities(any())).thenReturn(List.of(starterFund));
    when(fundMasterService.getFundInfoFromEins(any())).thenReturn(List.of(starterFund));
    when(fundMasterService.getFundInfoFromSecuritiesWithOverrides(any(), any()))
        .thenReturn(List.of(starterFund));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(Mono.just(AccountConfig.builder().clientId(CLIENT_ID).build()));
    when(businessWSCache.ultimateParentCacheByClientId(Set.of(CLIENT_ID)))
        .thenReturn(Mono.just(Map.of(CLIENT_ID, new TreeMap<>(Map.of(1, CLIENT_ID)))));

    INSTANCE =
        new LpxFundMasterService(
            fundMasterService,
            fundMasterRepository,
            fundInternalMappingRepository,
            accountConfigServiceCache,
            businessWSCache,
            redisTemplate,
            accountService,
            portfolioUtilsService);
  }

  @Test
  void savePortfolioCompanies() {
    List<PortfolioCompanyEntity> portfolioCompanyEntities =
        INSTANCE.savePortfolioCompanies(Set.of(portfolioCompanyEntity));
    assertEquals(portfolioCompanyEntity, portfolioCompanyEntities.get(0));
  }

  @Test
  void saveManagementFees() {
    List<ManagementFeesEntity> managementFeesEntities =
        INSTANCE.saveManagementFees(Set.of(managementFeesEntity));
    assertEquals(managementFeesEntity, managementFeesEntities.get(0));
  }

  @Test
  void saveFundMasterEntity() {
    List<FundMasterEntity> fundMasterEntities =
        INSTANCE.saveFundMasterEntity(Set.of(fundMasterEntity));
    assertEquals(fundMasterEntity, fundMasterEntities.get(0));
  }

  @Test
  void saveFundInternalMapping() {
    List<FundInternalMappingEntity> fundInternalMappingEntities =
        INSTANCE.saveFundInternalMapping(Set.of(fundInternalMappingEntity));
    assertEquals(fundInternalMappingEntity, fundInternalMappingEntities.get(0));
  }

  @Test
  void getFundDataByEins() {
    Collection<Fund> fundDataByEins = INSTANCE.getFundDataByEins(Set.of(EIN));
    assertEquals(starterFund, fundDataByEins.stream().findAny().get());
  }

  @Test
  void getAllInternalFunds() {
    Collection<FundMasterEntity> internalFunds = INSTANCE.getAllInternalFunds();
    assertEquals(fundMasterEntity, internalFunds.stream().findAny().get());
  }

  @Test
  void getAllInternalFundsNameAndIds() {
    Collection<FundIdNameResponseProjection> internalFunds = INSTANCE.getAllInternalFundsNameId();
    assertEquals(fundIdName, internalFunds.stream().findAny().get());
  }

  @Test
  void getFundDataBySecurities() {
    Collection<Fund> fundDataBySecurities = INSTANCE.getFundDataBySecurities(Set.of(SECURITY_ID));
    assertEquals(starterFund, fundDataBySecurities.stream().findAny().get());
  }

  @Test
  void getFundDataBySecuritiesWithOverrides() {
    SortedMap<Integer, Long> clientHierarchy = new TreeMap<>(Map.of(1, 0L));
    when(businessWSCache.ultimateParentCacheByClientId(Set.of(0L)))
        .thenReturn(Mono.just(Map.of(0L, clientHierarchy)));
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(0L, Set.of(SECURITY_ID)));
    Collection<Fund> fundDataBySecuritiesWithOverrides =
        INSTANCE.getFundDataWithOverridesBySecurities(0L, 0L, Set.of(SECURITY_ID));
    assertEquals(starterFund, fundDataBySecuritiesWithOverrides.stream().findAny().get());
  }

  @Test
  void getReportingFrequencies() {
    Fund fund1 =
        new Fund(
            1L,
            FundMasterEntity.builder()
                .reportingFrequency(ReportingFrequency.MONTHLY.toString())
                .build(),
            List.of(),
            List.of());
    Fund fund2 = new Fund(2L, FundMasterEntity.builder().build(), List.of(), List.of());
    when(fundMasterService.getFundInfoFromSecurities(Set.of(1L, 2L, 3L)))
        .thenReturn(Set.of(fund1, fund2));
    Map<Long, ReportingFrequency> expected =
        Map.of(
            1L,
            ReportingFrequency.MONTHLY,
            2L,
            DEFAULT_REPORTING_FREQUENCY,
            3L,
            DEFAULT_REPORTING_FREQUENCY);
    Map<Long, ReportingFrequency> actual = INSTANCE.getReportingFrequencies(Set.of(1L, 2L, 3L));
    assertEquals(expected, actual);
  }

  @Test
  void getReportingFrequency() {
    Fund fund =
        new Fund(
            SECURITY_ID,
            FundMasterEntity.builder()
                .reportingFrequency(ReportingFrequency.MONTHLY.toString())
                .build(),
            List.of(),
            List.of());
    when(fundMasterService.getFundInfoFromSecurities(Set.of(SECURITY_ID))).thenReturn(Set.of(fund));
    ReportingFrequency actual = INSTANCE.getReportingFrequency(SECURITY_ID);
    assertEquals(ReportingFrequency.MONTHLY, actual);
  }

  @Test
  void getFundMasterOverrides() {
    Fund fund =
        new Fund(
            SECURITY_ID,
            FundMasterEntity.builder()
                .reportingFrequency(ReportingFrequency.MONTHLY.toString())
                .build(),
            List.of(),
            List.of());
    when(fundMasterService.getFundInfoFromSecurities(Set.of(SECURITY_ID))).thenReturn(Set.of(fund));
    ReportingFrequency actual = INSTANCE.getReportingFrequency(SECURITY_ID);
    assertEquals(ReportingFrequency.MONTHLY, actual);
  }

  @Test
  void getFundMasterEntityAndOverrideEntitiesByClient() {
    FundMasterEntity overrideEntity = fundMasterEntity.toBuilder().cik("testCIK").build();
    Map<String, FundMasterEntity> expected =
        Map.of("overrideEntity", overrideEntity, "fundMasterEntity", fundMasterEntity);
    when(fundMasterService.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID))
        .thenReturn(expected);
    Map<String, FundMasterEntity> actual =
        INSTANCE.getFundMasterAndOverrideEntitiesBySecurityAndClient(SECURITY_ID, CLIENT_ID);
    assertEquals(fundMasterEntity, actual.get("fundMasterEntity"));
    assertEquals(overrideEntity, actual.get("overrideEntity"));
  }

  @Test
  void getFundMasterEntityAndOverrideEntitiesByAccount() {
    FundMasterEntity overrideEntity = fundMasterEntity.toBuilder().cik("testCIK").build();
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));
    Map<String, FundMasterEntity> result =
        Map.of("overrideEntity", overrideEntity, "fundMasterEntity", fundMasterEntity);
    when(fundMasterService.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID))
        .thenReturn(result);
    Map<String, FundMasterEntity> actual =
        INSTANCE.getFundMasterAndOverrideEntitiesBySecurityAndAccount(SECURITY_ID, ACCOUNT_ID);
    assertEquals(fundMasterEntity, actual.get("fundMasterEntity"));
    assertEquals(overrideEntity, actual.get("overrideEntity"));
  }

  @Test
  void saveFundAliasKeyTest() {
    FundAliasKey expected = new FundAliasKey(FUND_ID, "test");
    when(fundMasterService.saveFundAlias(FUND_ID, "test")).thenReturn(expected);
    FundAliasKey actual = INSTANCE.saveFundAliasKey(expected);
    assertEquals(expected, actual);
  }

  @Test
  void getFundIdentifiersTest() {
    when(fundMasterService.getFundIdentifiers()).thenReturn(List.of());
    assertEquals(INSTANCE.getFundIdentifiers(), List.of());
  }

  @Test
  void saveFundMasterOverrides() {
    when(fundMasterService.saveFundMasterOverrides(Set.of(overrideEntity)))
        .thenReturn(List.of(overrideEntity));
    assertEquals(INSTANCE.saveFundMasterOverrides(Set.of(overrideEntity)), List.of(overrideEntity));
  }

  @Test
  void getFundDataWithOverridesBySecuritiesAccount() {
    when(hashOperations.get(eq("Account"), eq(ACCOUNT_ID))).thenReturn(List.of(ACCOUNT_CONFIG));
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));
    Collection<Fund> result =
        INSTANCE.getFundDataWithOverridesBySecurities(null, ACCOUNT_ID, Set.of(SECURITY_ID));
    assertNotNull(result);
    assertEquals(starterFund, result.stream().findAny().get());
  }

  @Test
  void getFundDataWithOverridesBySecuritiesClient() {
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));
    Collection<Fund> result =
        INSTANCE.getFundDataWithOverridesBySecurities(CLIENT_ID, ACCOUNT_ID, Set.of(SECURITY_ID));

    assertNotNull(result);
    assertEquals(starterFund, result.stream().findAny().get());
  }

  @Test
  void getFundMasterEntitiesWithOverridesBySecurities() {
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));
    when(fundMasterService.getFundMasterEntitiesWithOverrides(Set.of(SECURITY_ID), CLIENT_ID))
        .thenReturn(Map.of(SECURITY_ID, fundMasterEntity));
    Map<Long, FundMasterEntity> result =
        INSTANCE.getFundMasterEntitiesWithOverridesBySecurities(
            CLIENT_ID, null, Set.of(SECURITY_ID));

    assertNotNull(result);
    assertTrue(result.containsKey(SECURITY_ID));
    assertEquals(fundMasterEntity, result.get(SECURITY_ID));
  }

  @Test
  void getFundMasterAndOverrideEntitiesBySecurityAndAccountWithOverrideLevel() {
    Map<String, FundMasterEntity> expected =
        Map.of(
            "overrideEntity",
            overrideEntity.getOverrideObject(),
            "fundMasterEntity",
            fundMasterEntity);
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));
    when(fundMasterService.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID))
        .thenReturn(expected);

    Map<String, Object> result =
        INSTANCE.getFundMasterAndOverrideEntitiesBySecurityAndAccountWithOverrideLevel(
            SECURITY_ID, ACCOUNT_ID);

    assertEquals(fundMasterEntity, result.get("fundMasterEntity"));
    assertEquals(overrideEntity.getOverrideObject(), result.get("overrideEntity"));
    assertEquals(24601L, result.get("overrideLevel"));
  }

  @Test
  void delete_fund_master_entity() {
    INSTANCE.deleteFundMasterEntity(
        Set.of(
            FundInternalMappingEntity.builder()
                .id(FundInternalMappingKey.builder().fundId(1L).securityId(2L).build())
                .build()));

    verify(fundInternalMappingRepository, times(1)).deleteAll(any());
  }

  @Test
  void getAllEntitiesForClientOriginalAndOverride() {
    Security badSecurity =
        Security.builder()
            .securityId(3L)
            .securityName("Name")
            .cusip("Cusip")
            .securityTypeDataDetail(
                SecurityTypeDataDetail.builder().isLimitedPartnership(false).build())
            .build();
    Map<String, FundMasterEntity> expected =
        Map.of(
            "overrideEntity",
            overrideEntity.getOverrideObject(),
            "fundMasterEntity",
            fundMasterEntity);
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));
    when(fundMasterService.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID))
        .thenReturn(expected);
    when(accountService.getClientAccounts(anyLong(), anyInt()))
        .thenReturn(Flux.fromIterable(ACCOUNT_LIST));
    when(portfolioUtilsService.getAllSecuritiesByAccountId(anyLong()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, List.of(SECURITY, badSecurity))));
    when(fundMasterService.identifyClientWithOverride(any(), any()))
        .thenReturn(Map.of(CLIENT_ID, Set.of(SECURITY_ID)));

    Collection<Map<String, Object>> result =
        INSTANCE
            .getAllEntitiesForClientOriginalAndOverride(CLIENT_ID, USER_ID)
            .collect(Collectors.toList())
            .toFuture()
            .join();

    assertEquals(1L, result.size());
    assertEquals(ACCOUNT, result.stream().findFirst().get().get("account"));
    assertEquals(SECURITY, result.stream().findFirst().get().get("security"));
    assertNotEquals(badSecurity, result.stream().findFirst().get().get("security"));
    assertEquals(fundMasterEntity, result.stream().findFirst().get().get("fundMasterEntity"));
    assertEquals(
        overrideEntity.getOverrideObject(),
        result.stream().findFirst().get().get("overrideEntity"));
    assertEquals(CLIENT_ID, result.stream().findFirst().get().get("overrideLevel"));
  }
}
