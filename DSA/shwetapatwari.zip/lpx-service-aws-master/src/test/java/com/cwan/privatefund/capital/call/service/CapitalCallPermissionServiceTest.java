package com.cwan.privatefund.capital.call.service;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallPermissions;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.privatefund.capital.call.constant.CapitalCallConstants.PermissionHelperConstants;
import com.cwan.privatefund.cpd.ws.client.CpdWSCache;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import java.util.concurrent.ConcurrentHashMap;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallPermissionServiceTest {

  @InjectMocks private CapitalCallPermissionService service;
  @Mock private CpdWSCache cpdWSCache;

  @Test
  void testUpdatePermissionWithNullAccount() {
    var document = CapitalCallDocument.builder().build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                !result.permissions().approveActionAllowed()
                    && !result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithNonNullAccountButNullClientId() {
    var document = CapitalCallDocument.builder().account(Account.builder().build()).build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                !result.permissions().approveActionAllowed()
                    && !result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithBlankUserEmail() {
    var account = Account.builder().id(123L).clientId(123L).build();
    var document = CapitalCallDocument.builder().account(account).build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, ""))
        .expectNextMatches(
            result ->
                !result.permissions().approveActionAllowed()
                    && !result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithNoMatchingTagEntryForClient() {
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder().account(account).status(CapitalCallStatus.WIRE_CHECK).build();
    when(cpdWSCache.getReviewers(anyLong(), anyLong()))
        .thenReturn(Mono.just(new ConcurrentHashMap<>()));
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                !result.permissions().approveActionAllowed()
                    && !result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithEmailNotInTagEntry() {
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("other@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder().account(account).status(CapitalCallStatus.WIRE_CHECK).build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                !result.permissions().approveActionAllowed()
                    && !result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithEmailFoundInTagEntry() {
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("test@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder()
            .account(account)
            .status(CapitalCallStatus.WIRE_CHECK)
            .permissions(
                CapitalCallPermissions.builder()
                    .approveActionAllowed(true)
                    .rejectActionAllowed(true)
                    .build())
            .build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                result.permissions().approveActionAllowed()
                    && result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithInitialReviewStatus() {
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.INITIAL, TagEntry.builder().cpdValue("test@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder()
            .account(account)
            .status(CapitalCallStatus.INITIAL_REVIEW)
            .permissions(
                CapitalCallPermissions.builder()
                    .approveActionAllowed(true)
                    .rejectActionAllowed(true)
                    .build())
            .build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                result.permissions().approveActionAllowed()
                    && result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithFinalReviewStatus() {
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.FINAL, TagEntry.builder().cpdValue("test@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder()
            .account(account)
            .status(CapitalCallStatus.FINAL_REVIEW)
            .permissions(
                CapitalCallPermissions.builder()
                    .approveActionAllowed(true)
                    .rejectActionAllowed(true)
                    .build())
            .build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                result.permissions().approveActionAllowed()
                    && result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithBlacklistedStatus() {
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.WIRE_TRANSFER,
        TagEntry.builder().cpdValue("test@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder()
            .account(account)
            .status(CapitalCallStatus.BLACKLISTED)
            .permissions(
                CapitalCallPermissions.builder()
                    .approveActionAllowed(true)
                    .rejectActionAllowed(true)
                    .build())
            .build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                result.permissions().approveActionAllowed()
                    && result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithCompletedStatus() {
    var map = new ConcurrentHashMap<String, TagEntry>();
    map.put(
        PermissionHelperConstants.FINAL, TagEntry.builder().cpdValue("test@example.com").build());
    when(cpdWSCache.getReviewers(anyLong(), anyLong())).thenReturn(Mono.just(map));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder()
            .account(account)
            .status(CapitalCallStatus.COMPLETED)
            .permissions(
                CapitalCallPermissions.builder()
                    .approveActionAllowed(true)
                    .rejectActionAllowed(true)
                    .build())
            .build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                result.permissions().approveActionAllowed()
                    && result.permissions().rejectActionAllowed())
        .verifyComplete();
  }

  @Test
  void testUpdatePermissionWithNotSpecifiedStatus() {
    when(cpdWSCache.getReviewers(anyLong(), anyLong()))
        .thenReturn(Mono.just(new ConcurrentHashMap<>()));
    var account = Account.builder().id(123L).clientId(123L).build();
    var document =
        CapitalCallDocument.builder()
            .account(account)
            .status(CapitalCallStatus.NOT_SPECIFIED)
            .build();
    StepVerifier.create(service.updatePermissionBasedOnUserEmail(document, "test@example.com"))
        .expectNextMatches(
            result ->
                !result.permissions().approveActionAllowed()
                    && !result.permissions().rejectActionAllowed())
        .verifyComplete();
  }
}
