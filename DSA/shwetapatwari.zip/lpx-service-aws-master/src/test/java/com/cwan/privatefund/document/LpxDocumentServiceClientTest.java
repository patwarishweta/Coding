package com.cwan.privatefund.document;

import static com.cwan.privatefund.TestUtil.getDocument;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Document;
import com.cwan.pbor.document.misc.document.entity.MiscDocumentEntity;
import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import com.cwan.privatefund.account.UltimateParents;
import com.cwan.privatefund.document.model.DocumentTypeData;
import com.cwan.privatefund.documentmanager.MiscDocumentTransformer;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.Part;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class LpxDocumentServiceClientTest {

  private static final String CLOUD_STORAGE_ID = "409d529e-fd25-4b23-b672-26ad762b5e62";
  private static final Document DOCUMENT = getDocument();
  private static final MiscDocumentEntity MISC_DOCUMENT =
      new MiscDocumentTransformer()
          .transform(
              DOCUMENT,
              UltimateParents.builder()
                  .ultimateParentName("Ultimate Parent Name")
                  .ultimateParentId(987L)
                  .build());
  private static final DocumentTypeData DOCUMENT_TYPE_DATA =
      DocumentTypeData.builder()
          .documentType("CAPC")
          .id(123)
          .category("Capital Call")
          .needsCustomAllocation(Boolean.TRUE)
          .build();
  private static final String SIGNED_URL =
      """
          https://storage.googleapis.com/document-bucket-core-glb-dev/\
          409d529e-fd25-4b23-b672-26ad762b5e62?GoogleAccessId=document-storage@apparent-coyote-e403.iam.\
          gserviceaccount.com&Expires=1672784807&Signature=bgROrKKqEWqImYo%2FDXOLxRspV8WkQ1wYQ8k1XQHyTfb\
          C%2FkpRnEU%2FmIBZJkwC9VHUSc4FZTV0qurJpeB0heXxhsvK76zo9Cv4peRma0mmDfL3U3CU8aF8uS3QONdBJy0AH0esal\
          pBL7f3SntoH9TgUsNvB5FhDoH7rOxw74c%2BsvBYDGV0rcXzQiCkW0CDqBp4HA%2BpTHv%2B4RtGoGV%2B%2B9iaHGu2aLWT\
          VJZcbCRbg2vZVtfvWGIbP0AbWFh0jVVhX4SBMqVRZwcTP%2BA9jTMn5q2xXT8oQ7jzPnz0bPCi8wZR3hF0aR%2Fv5BLe3MKa\
          47DqHkaKssq%2BuJOTlh1rfwPBCWFnCg%3D%3D""";
  private static final Long DOCUMENT_ID = 1L;
  @Mock private WebClient webClient;
  @Mock private WebClient.RequestBodyUriSpec requestBodyUriSpecMock;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;
  @Mock private WebClient.RequestHeadersSpec requestHeadersSpecMock;
  @Mock private WebClient.RequestBodySpec requestBodySpecMock;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private Part filePart;
  private LpxDocumentServiceClient instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance = new LpxDocumentServiceClient(webClient);
    Flux<DataBuffer> body = Flux.just();
    when(filePart.content()).thenReturn(body);
    when(filePart.name()).thenReturn("file.pdf");
    var headers = new HttpHeaders();
    headers.put(HttpHeaders.CONTENT_TYPE, List.of(MediaType.MULTIPART_FORM_DATA_VALUE));
    when(filePart.headers()).thenReturn(headers);
  }

  @Test
  void should_return_canoe_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToMono(
            new ParameterizedTypeReference<List<Map<String, Object>>>() {}))
        .thenReturn(Mono.just(List.of()));
    StepVerifier.create(instance.getDocumentDataByCanoeId(Set.of("1")))
        .expectNext(List.of())
        .verifyComplete();
  }

  @Test
  void test_4xx_error_get_canoe_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.getDocumentDataByCanoeId(Set.of("1")).block());
  }

  @Test
  void test_5xx_error_get_canoe_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.getDocumentDataByCanoeId(Set.of("1")).block());
  }

  @Test
  void test_onErrorResume_get_canoe_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToMono(
            new ParameterizedTypeReference<List<Map<String, Object>>>() {}))
        .thenReturn(Mono.error(new LpxDocumentServiceException("is5xxServerError Exception")));
    StepVerifier.create(instance.getDocumentDataByCanoeId(Set.of("1")))
        .expectNextCount(0)
        .verifyComplete();
  }

  @Test
  void should_return_assignee_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToFlux(UserDetails.class)).thenReturn(Flux.empty());
    StepVerifier.create(instance.fetchUserDetails(Set.of("1"))).expectNextCount(0).verifyComplete();
  }

  @Test
  void test_4xx_error_get_assignee_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.fetchUserDetails(Set.of("1")).blockLast());
  }

  @Test
  void test_5xx_error_get_assignee_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.fetchUserDetails(Set.of("1")).blockLast());
  }

  @Test
  void test_onErrorResume_get_assignee_data() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToFlux(UserDetails.class))
        .thenReturn(Flux.error(new Exception("is5xxServerError Exception")));
    StepVerifier.create(instance.fetchUserDetails(Set.of("1"))).expectNextCount(0).verifyComplete();
  }

  @Test
  void should_return_cloud_storage_id_after_uploading_file() {
    setupPostWebClientResponses();
    when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(CLOUD_STORAGE_ID));
    var actual = instance.uploadFile(filePart).block();
    assertEquals(CLOUD_STORAGE_ID, actual);
  }

  @Test
  void test_4xx_error_get_file() {
    setupPostWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.uploadFile(filePart).block());
  }

  @Test
  void test_5xx_error_get_file() {
    setupPostWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.uploadFile(filePart).block());
  }

  @Test
  void test_onErrorResume_get_file() {
    setupPostWebClientResponses();
    when(responseSpecMock.bodyToMono(String.class))
        .thenReturn(Mono.error(new LpxDocumentServiceException("is5xxServerError Exception")));
    assertThrows(LpxDocumentServiceException.class, () -> instance.uploadFile(filePart).block());
  }

  @Test
  void test_onErrorResume_unknownHostException_get_file() {
    setupPostWebClientResponses();
    when(responseSpecMock.bodyToMono(String.class))
        .thenReturn(Mono.error(new UnknownHostException("UnknownHost Exception")));
    assertThrows(LpxDocumentServiceException.class, () -> instance.uploadFile(filePart).block());
  }

  @Test
  void should_return_signed_url() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(SIGNED_URL));
    var actual = instance.getSignedUrl(DOCUMENT_ID).block();
    assertEquals(SIGNED_URL, actual);
  }

  @Test
  void should_save_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.bodyToFlux(Document.class)).thenReturn(Flux.just(DOCUMENT));
    var actual = instance.saveDocument(DOCUMENT);
    StepVerifier.create(actual).expectNext(DOCUMENT).verifyComplete();
  }

  @Test
  void test_4xx_error_save_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveDocument(DOCUMENT).blockFirst());
  }

  @Test
  void test_5xx_error_save_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveDocument(DOCUMENT).blockFirst());
  }

  @Test
  void test_onErrorResume_save_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.bodyToFlux(Document.class))
        .thenReturn(Flux.error(new LpxDocumentServiceException("is5xxServerError Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveDocument(DOCUMENT).blockFirst());
  }

  @Test
  void test_onErrorResume_unknownHostException_save_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.bodyToFlux(Document.class))
        .thenReturn(Flux.error(new UnknownHostException("UnknownHost Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveDocument(DOCUMENT).blockFirst());
  }

  @Test
  void test_4xx_error_get_signed_url() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getSignedUrl(DOCUMENT_ID).block());
  }

  @Test
  void test_5xx_error_get_signed_url() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getSignedUrl(DOCUMENT_ID).block());
  }

  @Test
  void test_onErrorResume_get_signed_url() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToMono(String.class))
        .thenReturn(Mono.error(new LpxDocumentServiceException("is5xxServerError Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getSignedUrl(DOCUMENT_ID).block());
  }

  @Test
  void test_onErrorResume_unknownHostException_get_signed_url() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToMono(String.class))
        .thenReturn(Mono.error(new UnknownHostException("UnknownHost Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getSignedUrl(DOCUMENT_ID).block());
  }

  @Test
  void should_save_misc_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.bodyToMono(MiscDocumentEntity.class))
        .thenReturn(Mono.just(MISC_DOCUMENT));
    var actual = instance.saveMiscDocument(MISC_DOCUMENT);
    StepVerifier.create(actual).expectNext(MISC_DOCUMENT).verifyComplete();
  }

  @Test
  void test_4xx_error_save_misc_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveMiscDocument(MISC_DOCUMENT).block());
  }

  @Test
  void test_5xx_error_save_misc_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveMiscDocument(MISC_DOCUMENT).block());
  }

  @Test
  void test_onErrorResume_save_misc_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.bodyToMono(MiscDocumentEntity.class))
        .thenReturn(Mono.error(new LpxDocumentServiceException("is5xxServerError Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveMiscDocument(MISC_DOCUMENT).block());
  }

  @Test
  void test_onErrorResume_unknownHostException_save_misc_documents() {
    setupPostWebClientResponsesForSaveDocument();
    when(responseSpecMock.bodyToMono(MiscDocumentEntity.class))
        .thenReturn(Mono.error(new UnknownHostException("UnknownHost Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.saveMiscDocument(MISC_DOCUMENT).block());
  }

  @Test
  void should_get_all_document_types() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToFlux(DocumentTypeData.class))
        .thenReturn(Flux.just(DOCUMENT_TYPE_DATA));
    var actual = instance.getAllDocumentTypeData();
    StepVerifier.create(actual).expectNext(Map.of("CAPC", DOCUMENT_TYPE_DATA)).verifyComplete();
  }

  @Test
  void test_4xx_error_get_all_document_types() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getAllDocumentTypeData().block());
  }

  @Test
  void test_5xx_error_get_all_document_types() {
    setupGetWebClientResponses();
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getAllDocumentTypeData().block());
  }

  @Test
  void test_onErrorResume_get_all_document_types() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToFlux(DocumentTypeData.class))
        .thenReturn(Flux.error(new LpxDocumentServiceException("is5xxServerError Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getAllDocumentTypeData().block());
  }

  @Test
  void test_onErrorResume_unknownHostException_get_all_document_types() {
    setupGetWebClientResponses();
    when(responseSpecMock.bodyToFlux(DocumentTypeData.class))
        .thenReturn(Flux.error(new UnknownHostException("UnknownHost Exception")));
    assertThrows(
        LpxDocumentServiceException.class, () -> instance.getAllDocumentTypeData().block());
  }

  private void setupPostWebClientResponses() {
    when(webClient.post()).thenReturn(requestBodyUriSpecMock);
    when(requestBodyUriSpecMock.uri(anyString())).thenReturn(requestBodySpecMock);
    when(requestBodyUriSpecMock.uri(any(Function.class))).thenReturn(requestBodySpecMock);
    when(requestBodySpecMock.body(any())).thenReturn(requestHeadersSpecMock);
    when(requestHeadersSpecMock.accept(any())).thenReturn(requestBodySpecMock);
    when(requestBodySpecMock.contentType(MediaType.MULTIPART_FORM_DATA))
        .thenReturn(requestBodySpecMock);
    when(requestBodySpecMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
  }

  private void setupGetWebClientResponses() {
    when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
    when(requestHeadersUriSpecMock.uri(any(Function.class))).thenReturn(requestHeadersSpecMock);
    when(requestHeadersSpecMock.accept(any())).thenReturn(requestBodySpecMock);
    when(requestBodySpecMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
  }

  private void setupPostWebClientResponsesForSaveDocument() {
    when(webClient.post()).thenReturn(requestBodyUriSpecMock);
    when(requestBodyUriSpecMock.uri(any(Function.class))).thenReturn(requestBodySpecMock);
    when(requestBodySpecMock.bodyValue(any()))
        .thenReturn(requestHeadersSpecMock); // Adjusted this line
    when(requestHeadersSpecMock.accept(any())).thenReturn(requestHeadersSpecMock);
    when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
  }
}
