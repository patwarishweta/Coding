package com.cwan.privatefund.canoeFundMapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingAccountResponse;
import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingClientResponse;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CanoeFundMappingServiceTest {

  @Mock private CanoeFundMappingRepository canoeFundMappingRepository;
  @InjectMocks private CanoeFundMappingService canoeFundMappingService;

  @Test
  void testGetClientDetails() {
    Set<CanoeFundMappingClientResponse> expectedClientDetails =
        new HashSet<>(
            Arrays.asList(
                new CanoeFundMappingClientResponse(1L, "AMT Investments"),
                new CanoeFundMappingClientResponse(2L, "Technology Insurance Company")));
    when(canoeFundMappingRepository.findAllClientNames()).thenReturn(expectedClientDetails);
    Set<CanoeFundMappingClientResponse> actualClientDetails =
        canoeFundMappingService.getClientDetails();
    assertEquals(expectedClientDetails, actualClientDetails);
  }

  @Test
  void testGetAccountDetails() {
    long clientId = 1L;
    List<CanoeFundMappingAccountResponse> expectedAccountDetails =
        Arrays.asList(
            new CanoeFundMappingAccountResponse(1L, "All State1"),
            new CanoeFundMappingAccountResponse(2L, "All State2"));
    when(canoeFundMappingRepository.findAccountByClientId(clientId))
        .thenReturn(expectedAccountDetails);
    List<CanoeFundMappingAccountResponse> actualAccountDetails =
        canoeFundMappingService.getAccountDetails(clientId);
    assertEquals(expectedAccountDetails, actualAccountDetails);
  }
}
