package com.cwan.privatefund.portfolio;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.portfolio.model.PortfolioData;
import com.cwan.privatefund.portfolio.model.PortfolioRequestData;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.security.auth.login.AccountNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
public class PortfolioWsClientTest {

  @Mock private WebClient webClient;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private WebClient.RequestBodyUriSpec requestBodyUri;
  @Mock private WebClient.RequestHeadersSpec requestHeadersSpec;
  @Mock private WebClient.ResponseSpec responseSpec;
  @Mock private AccountConfigServiceCache accountConfigServiceCache;
  @Mock private RedisTemplate redisTemplate;
  @Mock private HashOperations hashOperations;

  private PortfolioWsClient instance;
  private static final Long ACCOUNT_ID = 1L;
  private static final Long SECURITY_ID = 2L;
  private static final AccountConfig ACCOUNT_CONFIG = TestUtil.getAccountConfig();
  private static final Set<PortfolioData> PORTFOLIO_DATA =
      Set.of(PortfolioData.builder().accountId(ACCOUNT_ID).securityId(SECURITY_ID).build());

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance = new PortfolioWsClient(webClient, accountConfigServiceCache, redisTemplate);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
    mockWebClient();
  }

  @Test
  public void portfolio_ws_cache_update() {
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID))
        .thenReturn(Mono.just(ACCOUNT_CONFIG));
    when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    when(responseSpecMock.bodyToMono(new ParameterizedTypeReference<Set<PortfolioData>>() {}))
        .thenReturn(
            Mono.just(Set.of(PortfolioData.builder().accountId(2L).securityId(3L).build())));
    instance.getPortfolioDataWithCacheCheck(List.of(1L, 2L)).subscribe();
  }

  @Test
  public void account_missing_in_cache_and_portfolio_data_is_not_returned() {
    when(accountConfigServiceCache.getByAccountId(eq(2L))).thenReturn(Mono.empty());
    when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    when(responseSpecMock.bodyToMono(new ParameterizedTypeReference<Set<PortfolioData>>() {}))
        .thenReturn(
            Mono.just(Set.of(PortfolioData.builder().accountId(2L).securityId(3L).build())));
    instance.getPortfolioDataWithCacheCheck(List.of(1L, 2L)).subscribe();
  }

  @Test
  public void account_missing_in_cache() {
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID))
        .thenReturn(Mono.error(new AccountNotFoundException(ACCOUNT_ID + "")));
    when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    when(responseSpecMock.bodyToMono(new ParameterizedTypeReference<Set<PortfolioData>>() {}))
        .thenReturn(
            Mono.just(Set.of(PortfolioData.builder().accountId(2L).securityId(3L).build())));
    instance.getPortfolioDataWithCacheCheck(List.of(1L, 2L)).subscribe();
    verify(accountConfigServiceCache, times(1)).getByAccountId(anyLong());
  }

  @Test
  public void account_found_in_cache_() {
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID))
        .thenReturn(Mono.just(ACCOUNT_CONFIG));
    when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    when(responseSpecMock.bodyToMono(new ParameterizedTypeReference<Set<PortfolioData>>() {}))
        .thenReturn(
            Mono.just(Set.of(PortfolioData.builder().accountId(1L).securityId(3L).build())));
    instance.getPortfolioDataWithCacheCheck(List.of(1L)).subscribe();
    verify(accountConfigServiceCache, times(1)).getByAccountId(anyLong());
  }

  @Test
  public void should_get_portfolio_data() {
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID))
        .thenReturn(Mono.just(ACCOUNT_CONFIG));
    when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    when(responseSpecMock.bodyToMono(new ParameterizedTypeReference<Set<PortfolioData>>() {}))
        .thenReturn(Mono.just(PORTFOLIO_DATA));
    var actual = instance.getPortfolioData(Set.of(ACCOUNT_ID));
    StepVerifier.create(actual).expectNext(Set.copyOf(PORTFOLIO_DATA)).verifyComplete();
  }

  @Test
  public void should_get_error_for_portfolio_data() {
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID))
        .thenReturn(Mono.just(ACCOUNT_CONFIG));
    when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    when(responseSpec.bodyToMono(eq(new ParameterizedTypeReference<Set<PortfolioData>>() {})))
        .thenReturn(Mono.error(new UnknownHostException()));
    var actual = instance.getPortfolioData(Set.of(ACCOUNT_ID));
    StepVerifier.create(actual).expectNextCount(0);
  }

  @Test
  void businessWsClient_api_call_4xx_with_error_response_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just("4xx error sent from  portfolio ws"));
    assertThrows(Exception.class, () -> instance.getPortfolioData(Set.of(1L)).block());
  }

  @Test
  void businessWsClient_api_call_5xx_with_error_response_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just("5xx error sent from  business ws"));
    assertThrows(Exception.class, () -> instance.getPortfolioData(Set.of(1L)).block());
  }

  @Test
  void businessWsClient_api_call_error_resume_unknownhost_test() {
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID))
        .thenReturn(Mono.just(ACCOUNT_CONFIG));
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.error(new UnknownHostException("Exception UnknownHost Testing ")));
    StepVerifier.create(instance.getPortfolioData(Set.of(1L))).expectNextCount(0).verifyComplete();
  }

  private void mockWebClient() {
    when(webClient.post()).thenReturn(requestBodyUri);
    when(requestBodyUri.uri(any(String.class))).thenReturn(requestBodyUri);
    when(requestBodyUri.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUri);
    when(requestBodyUri.retrieve()).thenReturn(responseSpec);
    when(requestBodyUri.body(any(Object.class), eq(PortfolioRequestData.class)))
        .thenReturn(requestHeadersSpec);
    when(requestBodyUri.bodyValue(any())).thenReturn(requestHeadersSpec);
    when(requestHeadersSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpec);
    when(requestHeadersSpec.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenReturn(responseSpecMock);
  }
}
