package com.cwan.privatefund.aum;

import static com.cwan.privatefund.TestUtil.getAccount;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Aum;
import com.cwan.lpx.domain.Service;
import com.cwan.pbor.aum.AumService;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class ExcelCreationServiceTest {

  @InjectMocks private ExcelCreationService excelCreationService;

  @Mock private AumService aumService;
  @Mock private LpxAumService lpxAumService;
  @Mock private AccountConfigServiceCache accountConfigService;

  private static final LocalDate CALCULATION_DATE = LocalDate.of(2022, 1, 1);
  private static final Aum AUM =
      Aum.builder()
          .id(1L)
          .accountId(2L)
          .securityId(3L)
          .ultimateParentId(4L)
          .aum(4750.00)
          .clientId(2460L)
          .calculatedOn(CALCULATION_DATE)
          .isActive(true)
          .build();
  private static final List<Aum> AUM_LIST = List.of(AUM);

  public static Service getService() {
    return Service.builder().name("LPxFullService").build();
  }

  public static Service getNullService() {
    return Service.builder().name("").build();
  }

  private static final Map<String, String> ADDITIONAL_ATTRIBUTES =
      Map.of("capitalCallManagerDate", "true", "LPxClarity", "true", "LPxFullService", "true");
  private static final List<AccountConfig> ACCOUNT_CONFIG =
      List.of(
          AccountConfig.builder()
              .id(1L)
              .account(getAccount())
              .clientId(24601L)
              .service(getService())
              .ultimateParentName("Wayne Enterprises, Inc")
              .clientName("Wayne Technologies")
              .createdBy("dhruvalshah")
              .isCreatedByInternalUser(true)
              .subscriptionStartDate(LocalDate.of(2022, 1, 1))
              .subscriptionEndDate(LocalDate.of(9999, 12, 31))
              .attributes(ADDITIONAL_ATTRIBUTES)
              .build(),
          AccountConfig.builder()
              .id(2L)
              .account(getAccount())
              .clientId(1L)
              .ultimateParentName("Wayne Enterprises, Inc")
              .clientName("Wayne Technologies")
              .createdBy("dhruvalshah")
              .service(getNullService())
              .isCreatedByInternalUser(true)
              .subscriptionStartDate(LocalDate.of(2022, 1, 1))
              .subscriptionEndDate(LocalDate.of(9999, 12, 31))
              .attributes(ADDITIONAL_ATTRIBUTES)
              .build());
  private static final List<AccountConfig> ACCOUNT_CONFIG_NULL_ATTRIBUTES =
      List.of(
          AccountConfig.builder()
              .id(2L)
              .account(getAccount())
              .clientId(1L)
              .ultimateParentName("Wayne Enterprises, Inc")
              .clientName("Wayne Technologies")
              .createdBy("dhruvalshah")
              .service(getNullService())
              .isCreatedByInternalUser(true)
              .subscriptionStartDate(LocalDate.of(2022, 1, 1))
              .subscriptionEndDate(LocalDate.of(9999, 12, 31))
              .attributes(Map.of())
              .build());

  @Test
  void testGenerateExcelFile() {
    Set<Long> clientIds = Set.of(24601L, 1L);

    when(accountConfigService.getAllAccountConfigs()).thenReturn(Mono.just(ACCOUNT_CONFIG));
    when(aumService.findAllByClientIdAndCalculatedOn(24601L, CALCULATION_DATE))
        .thenReturn(AUM_LIST);
    when(aumService.findAllByClientIdAndCalculatedOn(1L, CALCULATION_DATE)).thenReturn(List.of());

    when(lpxAumService.getAumByUltimateParentIds(Set.of(1L))).thenReturn(Map.of(1L, AUM_LIST));

    byte[] excelBytes = excelCreationService.generateExcelFile(clientIds, CALCULATION_DATE);

    assertNotNull(excelBytes);
  }

  @Test
  void testGetAdditionalAttributes() throws Exception {
    when(accountConfigService.getAllAccountConfigs()).thenReturn(Mono.just(ACCOUNT_CONFIG));

    Set<Long> clientIds = Set.of(24601L);
    Map<Long, Map<String, String>> additionalAttributes =
        excelCreationService.getAdditionalAttributes(clientIds);

    assertNotNull(additionalAttributes);
    assertEquals(clientIds.size(), additionalAttributes.size());
    verify(accountConfigService).getAllAccountConfigs();
  }

  @Test
  void testExcelCreationService() {
    Set<Long> clientIds = Set.of(24601L);
    when(aumService.findAllByClientIdAndCalculatedOn(any(), any())).thenReturn(AUM_LIST);
    when(accountConfigService.getAllAccountConfigs()).thenReturn(Mono.just(ACCOUNT_CONFIG));

    byte[] excelBytes = excelCreationService.generateExcelFile(clientIds, CALCULATION_DATE);
    assertNotNull(excelBytes);
  }

  @Test
  void testGetAdditionalAttributesByClientId() throws Exception {
    Set<Long> clientIds = Set.of(24601L, 1L);
    when(accountConfigService.getAllAccountConfigs()).thenReturn(Mono.just(ACCOUNT_CONFIG));

    Map<Long, Map<String, String>> additionalAttributes =
        excelCreationService.getAdditionalAttributes(clientIds);
    assertNotNull(additionalAttributes);
    assertTrue(Boolean.parseBoolean(additionalAttributes.get(24601L).get("LPxFullService")));
  }

  @Test
  void testGenerateExcelFileException() {
    Set<Long> clientIds = Set.of(24601L);
    when(aumService.findAllByClientIdAndCalculatedOn(24601L, CALCULATION_DATE))
        .thenThrow(new IllegalStateException());
    assertThrows(
        IllegalStateException.class,
        () -> excelCreationService.generateExcelFile(clientIds, CALCULATION_DATE));
  }
}
