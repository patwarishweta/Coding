package com.cwan.privatefund.auth;

import static com.cwan.privatefund.TestUtil.getAuthentication;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.auth.service.AuthenticationService;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class SecurityContextRepositoryTest {

  @Mock private AuthenticationService authenticationService;
  @Mock private ServerWebExchange swe;
  private SecurityContextRepository instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance = new SecurityContextRepository(Set.of(authenticationService));
  }

  @Test
  public void should_return_security_context_if_valid() {
    var auth = getAuthentication();
    when(authenticationService.getAuthentication(eq(swe))).thenReturn(Mono.just(auth));
    var actual = instance.load(swe).block();
    assertEquals(new SecurityContextImpl(auth), actual);
  }

  @Test
  public void should_return_empty_not_valid() {
    var auth = new UsernamePasswordAuthenticationToken("username", "password");
    when(authenticationService.getAuthentication(eq(swe))).thenReturn(Mono.just(auth));
    var actual = instance.load(swe);
    StepVerifier.create(actual).expectNextCount(0).verifyComplete();
  }

  @Test
  public void should_return_empty_no_authentication() {
    when(authenticationService.getAuthentication(eq(swe))).thenReturn(Mono.empty());
    var actual = instance.load(swe);
    StepVerifier.create(actual).expectNextCount(0).verifyComplete();
  }
}
