package com.cwan.privatefund.document;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class DocumentUtilsTest {

  private record TestEntity(Long id, String name) {}

  private static Stream<Arguments> appendTimestampTestCases() {
    LocalDateTime testDateTime = LocalDateTime.of(2024, 1, 1, 12, 30);
    return Stream.of(
        Arguments.of("test.pdf", testDateTime, 50, "test_20240101_123000.pdf"),
        Arguments.of("test", testDateTime, 50, "test_20240101_123000"),
        Arguments.of("test.something.pdf", testDateTime, 50, "test.something_20240101_123000.pdf"),
        Arguments.of("test.pdf", null, 50, "test_.pdf"));
  }

  @ParameterizedTest(name = "{0} with date {1} and maxLength {2} should give {3}")
  @MethodSource("appendTimestampTestCases")
  void appendTimestampBeforeExtension(
      String fileName, LocalDateTime dateTime, int maxLength, String expected) {
    String result = DocumentUtils.appendTimestampBeforeExtension(fileName, dateTime, maxLength);
    assertEquals(expected, result);
  }

  @Test
  void appendTimestampBeforeExtension_TruncatedFileName() {
    String fileName = "verylongfilename.pdf";
    LocalDateTime dateTime = LocalDateTime.of(2024, 1, 1, 12, 30);
    String result = DocumentUtils.appendTimestampBeforeExtension(fileName, dateTime, 5);
    assertEquals("veryl_20240101_123000.pdf", result);
  }

  @Test
  void createEntityMap_EmptyCollection() {
    Map<Long, TestEntity> result =
        DocumentUtils.createEntityMap(Collections.emptyList(), TestEntity::id, (e1, e2) -> e1);
    assertTrue(result.isEmpty());
  }

  @Test
  void createEntityMap_Success() {
    List<TestEntity> entities =
        Arrays.asList(new TestEntity(1L, "First"), new TestEntity(2L, "Second"));
    Map<Long, TestEntity> result =
        DocumentUtils.createEntityMap(entities, TestEntity::id, (e1, e2) -> e1);
    assertEquals(2, result.size());
    assertInstanceOf(TreeMap.class, result);
    assertEquals("First", result.get(1L).name());
    assertEquals("Second", result.get(2L).name());
  }

  @Test
  void createEntityMap_WithDuplicates() {
    List<TestEntity> entities =
        Arrays.asList(new TestEntity(1L, "First"), new TestEntity(1L, "First Duplicate"));
    Map<Long, TestEntity> result =
        DocumentUtils.createEntityMap(entities, TestEntity::id, (e1, e2) -> e1);
    assertEquals(1, result.size());
    assertEquals("First", result.get(1L).name());
  }

  @Test
  void createEntityMap_WithNullElements() {
    List<TestEntity> entities =
        Arrays.asList(new TestEntity(1L, "First"), null, new TestEntity(2L, "Second"));
    Map<Long, TestEntity> result =
        DocumentUtils.createEntityMap(entities, TestEntity::id, (e1, e2) -> e1);
    assertEquals(2, result.size());
  }

  @Test
  void extractIds_EmptyCollection() {
    Set<Long> result =
        DocumentUtils.extractIds(Collections.emptyList(), Document::getAccount, Account::getId);
    assertTrue(result.isEmpty());
  }

  @Test
  void extractIds_Success() {
    Document doc1 = Document.builder().account(Account.builder().id(1L).build()).build();
    Document doc2 = Document.builder().account(Account.builder().id(2L).build()).build();
    Set<Long> result =
        DocumentUtils.extractIds(Arrays.asList(doc1, doc2), Document::getAccount, Account::getId);
    assertEquals(Set.of(1L, 2L), result);
  }

  @Test
  void extractIds_WithNullElements() {
    Document doc1 = Document.builder().account(Account.builder().id(1L).build()).build();
    Document doc2 = Document.builder().account(null).build();
    Set<Long> result =
        DocumentUtils.extractIds(
            Arrays.asList(doc1, doc2, null), Document::getAccount, Account::getId);
    assertEquals(Set.of(1L), result);
  }

  @Test
  void hydrateDocument_Success() {
    Account account = Account.builder().id(1L).clientId(100L).build();
    Security security = Security.builder().securityId(1L).securityName("Test Security").build();
    Map<Long, Account> accountMap = Collections.singletonMap(1L, account);
    Map<Long, Security> securityMap = Collections.singletonMap(1L, security);
    Document document =
        Document.builder()
            .account(Account.builder().id(1L).build())
            .security(Security.builder().securityId(1L).build())
            .build();
    Document result = DocumentUtils.hydrateDocument(document, accountMap, securityMap);
    assertEquals(account, result.getAccount());
    assertEquals(security, result.getSecurity());
  }

  @Test
  void hydrateDocument_WithNullEntities() {
    Document document = Document.builder().account(null).security(null).build();
    Document result =
        DocumentUtils.hydrateDocument(document, Collections.emptyMap(), Collections.emptyMap());
    assertNull(result.getAccount());
    assertNull(result.getSecurity());
  }

  @Test
  void hydrateDocument_WithNullIds() {
    Document document =
        Document.builder()
            .account(Account.builder().id(null).build())
            .security(Security.builder().securityId(null).build())
            .build();
    Document result =
        DocumentUtils.hydrateDocument(document, Collections.emptyMap(), Collections.emptyMap());
    assertNotNull(result.getAccount());
    assertNull(result.getAccount().getId());
    assertNotNull(result.getSecurity());
    assertNull(result.getSecurity().getSecurityId());
  }

  @Test
  void truncateFileName_NoTruncationNeeded() {
    String fileName = "test.pdf";
    String result = DocumentUtils.truncateFileName(fileName, 10);
    assertEquals(fileName, result);
  }

  @Test
  void truncateFileName_TruncationNeeded() {
    String fileName = "verylongfilename.pdf";
    String result = DocumentUtils.truncateFileName(fileName, 5);
    assertEquals("veryl", result);
  }
}
