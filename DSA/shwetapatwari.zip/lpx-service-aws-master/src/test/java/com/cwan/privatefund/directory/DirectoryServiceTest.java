package com.cwan.privatefund.directory;

import static com.cwan.privatefund.TestUtil.getDirectory;
import static com.cwan.privatefund.TestUtil.getDirectoryEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryEntity;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class DirectoryServiceTest {

  private final DirectoryRepository mockDirectoryRepository =
      Mockito.mock(DirectoryRepository.class);
  private final DirectoryTransformer mockDirectoryTransformer =
      Mockito.mock(DirectoryTransformer.class);
  private final DirectoryEntityTransformer mockDirectoryEntityTransformer =
      Mockito.mock(DirectoryEntityTransformer.class);
  private DirectoryService directoryService;
  private static final Long ACCOUNT_ID = 1L;
  private static final DirectoryEntity DIRECTORY_ENTITY = getDirectoryEntity(ACCOUNT_ID);
  private static final List<DirectoryEntity> DIRECTORY_ENTITY_LIST = List.of(DIRECTORY_ENTITY);
  private static final Directory DIRECTORY = getDirectory(ACCOUNT_ID);

  @BeforeEach
  void before_each() {
    Mockito.when(mockDirectoryTransformer.apply(eq(DIRECTORY_ENTITY))).thenReturn(DIRECTORY);
    Mockito.when(mockDirectoryEntityTransformer.apply(eq(DIRECTORY))).thenReturn(DIRECTORY_ENTITY);
    directoryService =
        new DirectoryService(
            mockDirectoryRepository, mockDirectoryTransformer, mockDirectoryEntityTransformer);
  }

  @Test
  void should_get_documents_by_accountId_and_tag() {
    Mockito.when(mockDirectoryRepository.findAllByAccountId(ACCOUNT_ID))
        .thenReturn(DIRECTORY_ENTITY_LIST);
    var actual = directoryService.getAllDirectoriesByAccountId(ACCOUNT_ID).collectList().block();
    assertEquals(List.of(DIRECTORY), actual);
  }

  @Test
  void should_convert_to_directory_exception() {
    Mockito.when(mockDirectoryRepository.findAllByAccountId(any()))
        .thenThrow(new RuntimeException());
    Assertions.assertThrows(
        DirectoryException.class, () -> directoryService.getAllDirectoriesByAccountId(ACCOUNT_ID));
  }

  @Test
  void should_get_all_directory_by_id() {
    Mockito.when(mockDirectoryRepository.findById(eq(ACCOUNT_ID)))
        .thenReturn(Optional.ofNullable(DIRECTORY_ENTITY));
    var actualMono = directoryService.getById(ACCOUNT_ID).block();
    assertEquals(DIRECTORY, actualMono);
  }

  @Test
  void should_add_directory_with_null_id() {
    var newDirectory = getDirectory(null);
    var newDirectoryEntity = getDirectoryEntity(null);
    Mockito.when(mockDirectoryEntityTransformer.apply(newDirectory)).thenReturn(newDirectoryEntity);
    Mockito.when(mockDirectoryRepository.saveAndFlush(newDirectoryEntity))
        .thenReturn(DIRECTORY_ENTITY);
    var actual = directoryService.addDirectories(Set.of(newDirectory)).collectList().block();
    assertEquals(List.of(DIRECTORY), actual);
  }

  @Test
  void should_not_add_directory_with_non_null_id() {
    directoryService.addDirectories(Set.of(DIRECTORY)).collectList().block();
    Mockito.verify(mockDirectoryRepository, never()).saveAndFlush(any(DirectoryEntity.class));
  }

  @Test
  void should_update_directory_info() {
    var updatedDirectory = DIRECTORY.toBuilder().name("new name").build();
    var updatedDirectoryEntity =
        new DirectoryEntity(
            updatedDirectory.getId(),
            updatedDirectory.getAccountId(),
            updatedDirectory.getName(),
            updatedDirectory.getParentDirectoryId(),
            updatedDirectory.getIsDisabled());
    when(mockDirectoryRepository.saveAndFlush(updatedDirectoryEntity))
        .thenReturn(updatedDirectoryEntity);
    when(mockDirectoryRepository.findAllById(Set.of(DIRECTORY.getId())))
        .thenReturn(DIRECTORY_ENTITY_LIST);
    when(mockDirectoryEntityTransformer.apply(updatedDirectory)).thenReturn(updatedDirectoryEntity);
    when(mockDirectoryTransformer.apply(updatedDirectoryEntity)).thenReturn(updatedDirectory);
    var actual =
        directoryService.updateDirectoryInfo(Set.of(updatedDirectory)).collectList().block();
    assertEquals(List.of(updatedDirectory), actual);
  }

  @Test
  void should_not_update_directory_with_null_id() {
    var updatedDirectory = getDirectory(null);
    var updatedDirectoryEntity =
        new DirectoryEntity(
            updatedDirectory.getId(),
            updatedDirectory.getAccountId(),
            updatedDirectory.getName(),
            updatedDirectory.getParentDirectoryId(),
            updatedDirectory.getIsDisabled());
    when(mockDirectoryEntityTransformer.apply(updatedDirectory)).thenReturn(updatedDirectoryEntity);
    when(mockDirectoryRepository.findAllById(Set.of())).thenReturn(List.of());
    directoryService.updateDirectoryInfo(Set.of(updatedDirectory)).collectList().block();
    Mockito.verify(mockDirectoryRepository, never()).saveAndFlush(any(DirectoryEntity.class));
  }
}
