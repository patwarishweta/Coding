package com.cwan.privatefund;

import static com.cwan.privatefund.TestUtil.getSecurityContext;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.auth.SecurityContextRepository;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public abstract class AuthenticatedControllerTest {

  static {
    System.setProperty("DEVELOPER_WORKSTATION", "true");
    System.setProperty("app/common/jwt_secret", "secret");
    System.setProperty("env", "ci");
  }

  @MockBean SecurityContextRepository securityContextRepository;

  public void mockSecurityContext() {
    when(securityContextRepository.load(any(ServerWebExchange.class)))
        .thenReturn(Mono.just(getSecurityContext()));
  }
}
