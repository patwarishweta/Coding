package com.cwan.privatefund.financialstatement;

import static com.cwan.privatefund.TestUtil.FINANCIAL_STATEMENT_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getFinancialStatements;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.GET;

import com.cwan.lpx.domain.FinancialStatement;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import java.time.Duration;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class FinancialStatementControllerTest extends AuthenticatedControllerTest {

  @MockBean FinancialStatementService financialStatementService;
  @Autowired private WebTestClient webClient;
  private static final Set<FinancialStatement> FINANCIALSTATEMENTS = getFinancialStatements();
  private static final Flux<FinancialStatement> FINANCIALSTATEMENTS_FLUX =
      Flux.fromIterable(FINANCIALSTATEMENTS);
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_retrieve_financial_statements_by_document_id() {
    Long documentId = 1L;
    when(financialStatementService.getFinancialStatementsByDocumentId(eq(documentId)))
        .thenReturn(FINANCIALSTATEMENTS_FLUX);
    var actual =
        getFinancialStatementEntity(
            format("%s%s%d", FINANCIAL_STATEMENT_URI, "/document/", documentId), GET);
    assertEquals(FINANCIALSTATEMENTS, actual);
  }

  @Test
  void should_retrieve_financial_statements_by_id() {
    Long documentId = 1L;
    when(financialStatementService.getFinancialStatementsByIds(anySet()))
        .thenReturn(FINANCIALSTATEMENTS_FLUX);
    var actual =
        getFinancialStatementEntity(
            format("%s%s", FINANCIAL_STATEMENT_URI, "/ids"), Set.of(documentId), GET);
    assertEquals(FINANCIALSTATEMENTS, actual);
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final HttpMethod httpMethod) {
    return webClient.method(httpMethod).uri(uriBuilder -> uriBuilder.path(uri).build()).exchange();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final Set<Long> qpram, final HttpMethod httpMethod) {
    return webClient
        .method(httpMethod)
        .uri(uriBuilder -> uriBuilder.path(uri).queryParam("ids", qpram).build())
        .exchange();
  }

  private Set<FinancialStatement> getFinancialStatementEntity(
      final String uri, final HttpMethod httpMethod) {
    return Set.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri, httpMethod)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(FinancialStatement.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private Set<FinancialStatement> getFinancialStatementEntity(
      final String uri, final Set<Long> qpram, final HttpMethod httpMethod) {
    return Set.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri, qpram, httpMethod)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(FinancialStatement.class)
                .getResponseBody()
                .collectList()
                .block()));
  }
}
