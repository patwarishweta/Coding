package com.cwan.privatefund.notification.service;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.ca.notification.client.NotificationClient;
import com.ca.notification.client.NotificationClient.NotificationBuilder;
import java.util.Collection;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;

@ExtendWith(MockitoExtension.class)
class EmailNotificationServiceTest {

  @Mock private NotificationClient notificationClient;
  @InjectMocks private EmailNotificationService emailNotificationService;
  private static final String IDENTIFIER = "ID123";
  private static final String SUBJECT = "Test Subject";
  private static final String HTML_MESSAGE = "<h1>Hello</h1>";
  private static final Collection<String> TO_ADDRESSES = Collections.singletonList("to@test.com");
  private static final Collection<String> CC_ADDRESSES = Collections.singletonList("cc@test.com");
  private static final Collection<String> BCC_ADDRESSES = Collections.singletonList("bcc@test.com");

  @Test
  void testSendEmail_Success() {
    var notificationBuilderMock = mock(NotificationBuilder.class);
    when(notificationClient.newNotification()).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.serviceName(anyString())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.entryIdentifier(anyString())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.subject(anyString())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.htmlMessage(anyString())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.from(anyString())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.to(anyCollection())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.cc(anyCollection())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.bcc(anyCollection())).thenReturn(notificationBuilderMock);
    when(notificationBuilderMock.send()).thenReturn(1);
    emailNotificationService
        .sendEmail(IDENTIFIER, SUBJECT, HTML_MESSAGE, TO_ADDRESSES, CC_ADDRESSES, BCC_ADDRESSES)
        .block();
    verify(notificationClient, times(1)).newNotification();
    verify(notificationBuilderMock, times(1)).entryIdentifier(anyString());
    verify(notificationBuilderMock, times(1)).subject(SUBJECT);
    verify(notificationBuilderMock, times(1)).htmlMessage(HTML_MESSAGE);
    verify(notificationBuilderMock, times(1)).from(anyString());
    verify(notificationBuilderMock, times(1)).to(TO_ADDRESSES);
    verify(notificationBuilderMock, times(1)).cc(CC_ADDRESSES);
    verify(notificationBuilderMock, times(1)).bcc(BCC_ADDRESSES);
    verify(notificationBuilderMock, times(1)).send();
  }

  @Test
  void testSendEmail_Failure_BlankIdentifier() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService
        .sendEmail("", SUBJECT, HTML_MESSAGE, TO_ADDRESSES, CC_ADDRESSES, BCC_ADDRESSES)
        .block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found");
  }

  @Test
  void testSendEmail_Failure_BlankSubject() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService
        .sendEmail(IDENTIFIER, "", HTML_MESSAGE, TO_ADDRESSES, CC_ADDRESSES, BCC_ADDRESSES)
        .block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found for blank subject");
  }

  @Test
  void testSendEmail_Failure_BlankHtmlMessage() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService
        .sendEmail(IDENTIFIER, SUBJECT, "", TO_ADDRESSES, CC_ADDRESSES, BCC_ADDRESSES)
        .block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found for blank HTML message");
  }

  @Test
  void testSendEmail_Failure_NullRecipientList() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService.sendEmail(IDENTIFIER, SUBJECT, HTML_MESSAGE, null, null, null).block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found for null recipient list");
  }

  @Test
  void testSendEmail_Failure_EmptyRecipientList() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService
        .sendEmail(
            IDENTIFIER,
            SUBJECT,
            HTML_MESSAGE,
            Collections.emptyList(),
            Collections.emptyList(),
            Collections.emptyList())
        .block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found for empty recipient list");
  }

  @Test
  void testSendEmail_Failure_NullCcEmailAddresses() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService
        .sendEmail(IDENTIFIER, SUBJECT, HTML_MESSAGE, TO_ADDRESSES, null, BCC_ADDRESSES)
        .block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found for null ccEmailAddresses");
  }

  @Test
  void testSendEmail_Failure_NullBccEmailAddresses() {
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    ((Logger) LoggerFactory.getLogger(EmailNotificationService.class)).addAppender(listAppender);
    emailNotificationService
        .sendEmail(IDENTIFIER, SUBJECT, HTML_MESSAGE, TO_ADDRESSES, CC_ADDRESSES, null)
        .block();
    var isErrorLogged =
        listAppender.list.stream()
            .anyMatch(event -> event.getFormattedMessage().contains("Failed to send email"));
    assertTrue(isErrorLogged, "Expected error log was not found for null bccEmailAddresses");
  }
}
