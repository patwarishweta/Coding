package com.cwan.privatefund.document.controller;

import static com.cwan.privatefund.TestUtil.DOCUMENT_URI;
import static com.cwan.privatefund.TestUtil.GET_DOCUMENT_SIGNED_URL_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getClearwaterDocumentRequest;
import static com.cwan.privatefund.TestUtil.getDocumentRequest;
import static com.cwan.privatefund.TestUtil.getMissingDocumentAlertConfig;
import static com.cwan.privatefund.TestUtil.getMissingDocumentExpectationsConfig;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.document.CwanGptDocument;
import com.cwan.privatefund.document.CwanGptDocumentRequest;
import com.cwan.privatefund.document.DocumentRequest;
import com.cwan.privatefund.document.LpxDocumentService;
import com.cwan.privatefund.document.dto.DocumentFilterCriteria;
import com.cwan.privatefund.document.exception.ValidationErrorResponse;
import com.cwan.privatefund.document.model.DocumentAudit;
import com.cwan.privatefund.feature.Feature;
import com.cwan.privatefund.feature.FeatureFlagsWSClient;
import com.cwan.privatefund.publisher.MessagePublisher;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class DocumentControllerTest extends AuthenticatedControllerTest {

  private static final Integer USER_ID = 9;
  private static final Long ACCOUNT_ID = 2L;
  private static final DocumentRequest DOCUMENT_REQUEST = getDocumentRequest();
  private static final Mono<DocumentRequest> REQUEST = Mono.just(DOCUMENT_REQUEST);
  private static final Set<Document> DOCUMENTS = DOCUMENT_REQUEST.getDocuments();
  private static final Flux<Document> DOCUMENT_FLUX = Flux.fromIterable(DOCUMENTS);
  private static final String CLOUD_STORAGE_ID = "409d529e-fd25-4b23-b672-26ad762b5e62";
  private static final Flux<String> CLOUD_STORAGE_ID_FLUX = Flux.just(CLOUD_STORAGE_ID);
  private static final LocalDate BEGIN_DATE = LocalDate.of(2022, 4, 1);
  private static final LocalDate END_DATE = LocalDate.of(2022, 4, 30);
  private static final String TYPES = "Capital Call Notice,Capital Account Statement";
  @Autowired private WebTestClient webClient;
  @MockBean private AccountService accountService;
  @MockBean private LpxDocumentService lpxDocumentService;
  @MockBean MessagePublisher<CwanGptDocumentRequest> cwanGptDocumentMessagePublisher;
  @MockBean FeatureFlagsWSClient featureFlagsWSClient;
  @Autowired private DocumentController documentController;

  private WebTestClient.ResponseSpec exchange() {
    var multipartBodyBuilder = new MultipartBodyBuilder();
    multipartBodyBuilder
        .part("file", TestUtil.getFile())
        .contentType(MediaType.MULTIPART_FORM_DATA);
    return webClient
        .method(HttpMethod.POST)
        .uri(TestUtil.FILE_UPLOAD_URI)
        .contentType(MediaType.MULTIPART_FORM_DATA)
        .body(BodyInserters.fromMultipartData(multipartBodyBuilder.build()))
        .accept(MediaType.APPLICATION_JSON)
        .exchange();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(HttpMethod httpMethod) {
    return webClient
        .method(httpMethod)
        .uri(TestUtil.DOCUMENT_URI)
        .body(DocumentControllerTest.REQUEST, DocumentRequest.class)
        .exchange();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(Mono<CwanGptDocumentRequest> request) {
    return webClient
        .method(HttpMethod.POST)
        .uri(TestUtil.CWAN_GPT_DOCUMENT_URI)
        .body(request, CwanGptDocumentRequest.class)
        .exchange();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(String uri) {
    return webClient.method(HttpMethod.GET).uri(uri).exchange();
  }

  private void getClearwaterGptDocumentEntity(Mono<CwanGptDocumentRequest> request) {
    Objects.requireNonNull(
        exchangeForEntity(request)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(CwanGptDocument.class)
            .getResponseBody()
            .collectList()
            .block());
  }

  private Document getDocumentById(Long documentId) {
    return exchangeForEntity(DOCUMENT_URI + "/" + documentId)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Document.class)
        .getResponseBody()
        .share()
        .blockFirst();
  }

  private Set<Document> getDocumentsEntity(String uri) {
    return Set.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(Document.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private String getDocumentSignedUrl(String uri) {
    return exchangeForEntity(uri)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(String.class)
        .getResponseBody()
        .blockFirst();
  }

  private WebTestClient.ResponseSpec performPostRequest(DocumentFilterCriteria request) {
    return webClient
        .post()
        .uri("/v1/documents/search")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(request)
        .exchange();
  }

  private Set<Document> postForDocumentEntity() {
    return exchangeForEntity(POST)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Document.class)
        .getResponseBody()
        .collect(Collectors.toSet())
        .share()
        .block();
  }

  private Flux<String> postForFileUpload() {
    return exchange()
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(String.class)
        .getResponseBody()
        .share();
  }

  private Set<Document> putForDocumentEntity() {
    return exchangeForEntity(PUT)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Document.class)
        .getResponseBody()
        .collect(Collectors.toSet())
        .share()
        .block();
  }

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
    when(accountService.retrieveUserAccessibleAccountIds(USER_ID))
        .thenReturn(Mono.just(Set.of(ACCOUNT_ID)));
    when(accountService.retrieveUserAccessibleAccountIdsInBatches(any(), any()))
        .thenReturn(Flux.just(Set.of(ACCOUNT_ID)));
    when(featureFlagsWSClient.getCachedFeatureFlag(Feature.DETECT_MISSING_DOCUMENT_ENABLED, null))
        .thenReturn(true);
  }

  @Test
  void should_add_document_successfully() {
    when(lpxDocumentService.addDocuments(DOCUMENTS)).thenReturn(DOCUMENT_FLUX);
    var actual = postForDocumentEntity();
    assertEquals(DOCUMENTS, actual);
  }

  @Test
  void should_get_document_by_id_successfully() {
    var doc = DOCUMENTS.iterator().next();
    when(lpxDocumentService.getDocumentById(doc.getId())).thenReturn(Mono.just(doc));
    var actual = getDocumentById(doc.getId());
    assertEquals(doc, actual);
  }

  @Test
  void should_get_document_signedUrl_successfully() {
    when(lpxDocumentService.getSignedUrlByDocId(ArgumentMatchers.any()))
        .thenReturn(
            Mono.just(
                "http://localhost:8080/api/v1/document/download/409d529e-fd25-4b23-b672-26ad762b5e62"));
    var actual = getDocumentSignedUrl(format("%s%s", GET_DOCUMENT_SIGNED_URL_URI, 1L));
    assertEquals(
        "http://localhost:8080/api/v1/document/download/409d529e-fd25-4b23-b672-26ad762b5e62",
        actual);
  }

  @Test
  void should_get_documents_by_filter_criteria_successfully() {
    var request =
        DocumentFilterCriteria.builder()
            .accountIds(Set.of(1L, 2L))
            .securityIds(Set.of(100L, 200L))
            .beginDate(LocalDate.of(2024, 1, 1))
            .endDate(LocalDate.of(2024, 12, 31))
            .build();
    var doc = Document.builder().id(1L).originalFileName("Test Document").build();
    when(lpxDocumentService.getAuthorizedDocumentsInDateRange(
            anyCollection(), anyCollection(), any(LocalDate.class), any(LocalDate.class)))
        .thenReturn(Flux.just(doc));
    var result =
        performPostRequest(request)
            .expectStatus()
            .isOk()
            .returnResult(Document.class)
            .getResponseBody()
            .collectList()
            .block();
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(1L, result.get(0).getId());
    assertEquals("Test Document", result.get(0).getOriginalFileName());
    ArgumentCaptor<Collection<Long>> accountIdsCaptor = ArgumentCaptor.forClass(Collection.class);
    ArgumentCaptor<Collection<Long>> securityIdsCaptor = ArgumentCaptor.forClass(Collection.class);
    ArgumentCaptor<LocalDate> beginDateCaptor = ArgumentCaptor.forClass(LocalDate.class);
    ArgumentCaptor<LocalDate> endDateCaptor = ArgumentCaptor.forClass(LocalDate.class);
    verify(lpxDocumentService)
        .getAuthorizedDocumentsInDateRange(
            accountIdsCaptor.capture(),
            securityIdsCaptor.capture(),
            beginDateCaptor.capture(),
            endDateCaptor.capture());
    assertEquals(request.accountIds(), new HashSet<>(accountIdsCaptor.getValue()));
    assertEquals(request.securityIds(), new HashSet<>(securityIdsCaptor.getValue()));
    assertEquals(request.beginDate(), beginDateCaptor.getValue());
    assertEquals(request.endDate(), endDateCaptor.getValue());
  }

  @Test
  void should_get_documents_by_received_document_date_successfully() {
    var beginDate = LocalDate.of(2024, 1, 1);
    var endDate = LocalDate.of(2024, 12, 31);
    var doc = Document.builder().id(1L).originalFileName("Test Document").build();
    when(lpxDocumentService.getAuthorizedDocumentsInDateRange(eq(beginDate), eq(endDate)))
        .thenReturn(Flux.just(doc));
    var actual =
        exchangeForEntity(
                format(
                    "%s%s%s%s%s",
                    DOCUMENT_URI,
                    "/document-date?beginDate=",
                    beginDate.format(DateTimeFormatter.ISO_DATE),
                    "&endDate=",
                    endDate.format(DateTimeFormatter.ISO_DATE)))
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(Document.class)
            .getResponseBody()
            .collectList()
            .block();
    assertNotNull(actual);
    assertEquals(1, actual.size());
    assertEquals(1L, actual.get(0).getId());
    assertEquals("Test Document", actual.get(0).getOriginalFileName());
    verify(lpxDocumentService).getAuthorizedDocumentsInDateRange(eq(beginDate), eq(endDate));
  }

  @Test
  void should_get_documents_by_user_id_and_cash_movement_date() {
    when(lpxDocumentService.getDocumentsByAccountsAndCashMvmtDateBetweenAndType(
            eq(Set.of(ACCOUNT_ID)), eq(BEGIN_DATE), eq(END_DATE), eq(TYPES)))
        .thenReturn(DOCUMENT_FLUX);
    var actual =
        getDocumentsEntity(
            format(
                "%s%s%d%s%s%s%s%s%s",
                DOCUMENT_URI,
                "/cash-movement?userId=",
                USER_ID,
                "&beginDate=",
                BEGIN_DATE.format(DateTimeFormatter.ISO_DATE),
                "&endDate=",
                END_DATE.format(DateTimeFormatter.ISO_DATE),
                "&type=",
                TYPES));
    assertEquals(DOCUMENTS, actual);
  }

  @Test
  void should_get_documents_by_user_id_and_period_end_date() {
    when(lpxDocumentService.getDocumentsByAccountsAndPeriodEndDateBetween(
            eq(Set.of(ACCOUNT_ID)), eq(BEGIN_DATE), eq(END_DATE)))
        .thenReturn(DOCUMENT_FLUX);
    var actual =
        getDocumentsEntity(
            format(
                "%s%s%d%s%s%s%s",
                DOCUMENT_URI,
                "/period-end?userId=",
                USER_ID,
                "&beginDate=",
                BEGIN_DATE.format(DateTimeFormatter.ISO_DATE),
                "&endDate=",
                END_DATE.format(DateTimeFormatter.ISO_DATE)));
    assertEquals(DOCUMENTS, actual);
  }

  @Test
  void should_get_documents_by_user_id_and_received_begin_and_end_date() {
    when(lpxDocumentService.getDocumentsByAccountsAndReceivedDateBetweenAndType(
            eq(Set.of(ACCOUNT_ID)), eq(BEGIN_DATE), eq(END_DATE), eq(TYPES), eq(true)))
        .thenReturn(DOCUMENT_FLUX);
    var actual =
        getDocumentsEntity(
            format(
                "%s%s%d%s%s%s%s%s%s",
                DOCUMENT_URI,
                "/received?userId=",
                USER_ID,
                "&beginDate=",
                BEGIN_DATE.format(DateTimeFormatter.ISO_DATE),
                "&endDate=",
                END_DATE.format(DateTimeFormatter.ISO_DATE),
                "&type=",
                TYPES));
    assertEquals(DOCUMENTS, actual);
  }

  @Test
  void should_get_missing_document_successfully() {
    var doc =
        List.of(
            MissingDocuments.builder()
                .accountId(123L)
                .documentMissingCategory(MissingDocumentStatus.RECEIVED)
                .build(),
            MissingDocuments.builder()
                .accountId(123L)
                .documentMissingCategory(MissingDocumentStatus.MISSING)
                .build());
    when(lpxDocumentService.getMissingDocuments(123L)).thenReturn(Flux.fromIterable(doc));
    var actual =
        exchangeForEntity(DOCUMENT_URI + "/missing/state?accountId=123")
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(MissingDocuments.class)
            .getResponseBody()
            .collectList()
            .block();
    assertEquals(doc, actual);
  }

  @Test
  void should_handle_response_status_exception() {
    var request =
        DocumentFilterCriteria.builder()
            .accountIds(Set.of(1L))
            .beginDate(LocalDate.of(2024, 1, 1))
            .endDate(LocalDate.of(2024, 12, 31))
            .build();
    when(lpxDocumentService.getAuthorizedDocumentsInDateRange(any(), any(), any(), any()))
        .thenReturn(
            Flux.error(new ResponseStatusException(HttpStatus.NOT_FOUND, "Documents not found")));
    performPostRequest(request)
        .expectStatus()
        .isNotFound()
        .expectBody()
        .jsonPath("$.status")
        .isEqualTo(404)
        .jsonPath("$.message")
        .isEqualTo("Documents not found");
  }

  @Test
  void should_handle_unexpected_errors() {
    var request =
        DocumentFilterCriteria.builder()
            .accountIds(Set.of(1L))
            .beginDate(LocalDate.of(2024, 1, 1))
            .endDate(LocalDate.of(2024, 12, 31))
            .build();
    when(lpxDocumentService.getAuthorizedDocumentsInDateRange(any(), any(), any(), any()))
        .thenReturn(Flux.error(new RuntimeException("Unexpected error")));
    performPostRequest(request)
        .expectStatus()
        .is5xxServerError()
        .expectBody()
        .jsonPath("$.status")
        .isEqualTo(500)
        .jsonPath("$.message")
        .isEqualTo("An unexpected error occurred");
  }

  @Test
  void should_handle_validation_error_response_creation() {
    Map<String, String> errors = Map.of("field1", "Error 1", "field2", "Error 2");
    var response = ValidationErrorResponse.of(400, "Custom message", errors);
    assertEquals(400, response.status());
    assertEquals("Custom message", response.message());
    assertEquals(errors, response.errors());
    assertNotNull(response.timestamp());
  }

  @Test
  void should_handle_validation_error_response_with_null_values() {
    var response = ValidationErrorResponse.of(400, null, null);
    assertEquals(400, response.status());
    assertEquals("Validation failed", response.message());
    assertTrue(response.errors().isEmpty());
    assertNotNull(response.timestamp());
  }

  @Test
  void should_handle_validation_errors_for_invalid_date_range() {
    var request =
        DocumentFilterCriteria.builder()
            .accountIds(Set.of(1L))
            .beginDate(LocalDate.of(2024, 12, 31))
            .endDate(LocalDate.of(2024, 1, 1))
            .build();
    performPostRequest(request)
        .expectStatus()
        .isBadRequest()
        .expectBody()
        .jsonPath("$.status")
        .isEqualTo(400)
        .jsonPath("$.message")
        .isEqualTo("Validation failed")
        .jsonPath("$.errors")
        .exists();
  }

  @Test
  void should_handle_web_exchange_bind_exception_with_multiple_field_errors() {
    var invalidRequest =
        DocumentFilterCriteria.builder()
            .accountIds(Collections.emptySet())
            .beginDate(LocalDate.now())
            .endDate(LocalDate.now().minusDays(1))
            .build();
    performPostRequest(invalidRequest)
        .expectStatus()
        .isBadRequest()
        .expectBody()
        .jsonPath("$.status")
        .isEqualTo(400)
        .jsonPath("$.message")
        .isEqualTo("Validation failed")
        .jsonPath("$.errors")
        .exists();
  }

  @Test
  void should_publish_clearwater_gpt_document_successfully() {
    var given = getClearwaterDocumentRequest();
    Mono<CwanGptDocumentRequest> request = Mono.just(given);
    getClearwaterGptDocumentEntity(request);
    verify(cwanGptDocumentMessagePublisher, atLeast(1)).publishMessage(any(), any(), eq(false));
  }

  @Test
  void should_update_document_successfully() {
    when(lpxDocumentService.updateDocumentInfo(DOCUMENTS)).thenReturn(DOCUMENT_FLUX);
    var actual = putForDocumentEntity();
    assertEquals(DOCUMENTS, actual);
  }

  @Test
  void should_upload_file_successfully() {
    when(lpxDocumentService.uploadFile(any())).thenReturn(CLOUD_STORAGE_ID_FLUX);
    StepVerifier.create(postForFileUpload()).expectNext(CLOUD_STORAGE_ID).verifyComplete();
  }

  @Test
  void test_deletes_all_missing_document_alerts() {
    Long clientId = 123L;
    when(lpxDocumentService.deleteMissingDocumentAlertsByClientId(clientId))
        .thenReturn(Mono.empty());
    var uri = "/v1/documents/missing/alert/config/delete/client/123";
    webClient.method(HttpMethod.DELETE).uri(uri).exchange().expectStatus().isNoContent();
  }

  @Test
  void test_deletes_missing_document_expectations() {
    Long securityId = 12345L;
    var documentType = "Capital Call";
    when(lpxDocumentService.deleteMissingDocumentExpectationsBySecurityIdAndDocumentType(
            securityId, documentType))
        .thenReturn(Mono.empty());
    var uri = "/v1/documents/missing/expectation/config/delete/security/12345/type/Capital Call";
    webClient.method(HttpMethod.DELETE).uri(uri).exchange().expectStatus().isNoContent();
  }

  @Test
  void test_returns_audit_documents_for_valid_account_ids_and_date_range() {
    Set<Long> accountIds = Set.of(1L, 2L);
    var beginDate = LocalDate.of(2024, 1, 1);
    var endDate = LocalDate.of(2024, 12, 31);
    var lpxDocumentService = mock(LpxDocumentService.class);
    var documentController = new DocumentController(lpxDocumentService, null, null);
    when(lpxDocumentService.getAllDocumentsByAccountAndDateRange(accountIds, beginDate, endDate))
        .thenReturn(Flux.just(new DocumentAudit()));
    var result = documentController.getAuditDocument(accountIds, beginDate, endDate);
    StepVerifier.create(result).expectNextCount(1).verifyComplete();
  }

  @Test
  void test_returns_flux_of_missing_document_alert_config() {
    var alertConfig = getMissingDocumentAlertConfig();
    when(lpxDocumentService.getMissingDocumentsAlerts()).thenReturn(Flux.just(alertConfig));
    var uri = "/v1/documents/missing/alerts/all";
    var result =
        webClient
            .method(HttpMethod.GET)
            .uri(uri)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(MissingDocumentAlertConfig.class)
            .getResponseBody();
    StepVerifier.create(result).expectNext(alertConfig).verifyComplete();
  }

  @Test
  void test_returns_flux_of_missing_document_alert_config_when_feature_is_disabled() {
    when(featureFlagsWSClient.getCachedFeatureFlag(Feature.DETECT_MISSING_DOCUMENT_ENABLED, null))
        .thenReturn(false);
    var uri = "/v1/documents/missing/alerts/all";
    webClient.method(HttpMethod.GET).uri(uri).exchange().expectStatus().isForbidden();
  }

  @Test
  void test_returns_flux_of_missing_document_expectations() {
    var expectationsConfig = getMissingDocumentExpectationsConfig();
    when(lpxDocumentService.getMissingDocumentsExpectations())
        .thenReturn(Flux.just(expectationsConfig));
    var uri = "/v1/documents/missing/expectations/all";
    var result =
        webClient
            .method(HttpMethod.GET)
            .uri(uri)
            .exchange()
            .expectStatus()
            .isOk()
            .returnResult(MissingDocumentExpectationsConfig.class)
            .getResponseBody();
    StepVerifier.create(result).expectNext(expectationsConfig).verifyComplete();
  }

  @Test
  void test_save_missing_document_alerts_successfully() {
    var request = getMissingDocumentAlertConfig();
    when(lpxDocumentService.saveMissingDocumentAlerts(request)).thenReturn(Flux.just(request));
    var uri = "/v1/documents/missing/alerts/add";
    var result =
        webClient
            .method(HttpMethod.POST)
            .uri(uri)
            .body(BodyInserters.fromValue(request))
            .exchange()
            .expectStatus()
            .isCreated()
            .returnResult(MissingDocumentAlertConfig.class)
            .getResponseBody();
    StepVerifier.create(result).expectNext(request).verifyComplete();
  }

  @Test
  void test_save_missing_document_expectations_successfully() {
    var request = getMissingDocumentExpectationsConfig();
    when(lpxDocumentService.saveMissingDocumentExpectationsConfigs(request))
        .thenReturn(Flux.just(request));
    var uri = "/v1/documents/missing/expectations/add";
    var result =
        webClient
            .method(HttpMethod.POST)
            .uri(uri)
            .body(BodyInserters.fromValue(request))
            .exchange()
            .expectStatus()
            .isCreated()
            .returnResult(MissingDocumentExpectationsConfig.class)
            .getResponseBody();
    StepVerifier.create(result).expectNext(request).verifyComplete();
  }

  @Test
  void getZipFiles_Success() throws IOException {
    var responseBytes = "This is a good test !".getBytes();
    var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    headers.setContentDispositionFormData("attachment", "Documents.zip");
    when(lpxDocumentService.getZipFileFromDocumentIds(eq(Set.of(123L)))).thenReturn(responseBytes);
    var result = documentController.getZipFiles(Set.of(123L));
    assertEquals(
        ResponseEntity.ok()
            .headers(headers)
            .contentLength(responseBytes.length)
            .body(new ByteArrayResource(responseBytes)),
        result);
  }

  @Test
  void getZipFilesPost_Success() throws IOException {
    var responseBytes = "This is a good test !".getBytes();
    var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    headers.setContentDispositionFormData("attachment", "Documents.zip");
    when(lpxDocumentService.getZipFileFromDocumentIds(eq(Set.of(123L)))).thenReturn(responseBytes);
    var result = documentController.getZipFilesPost(Set.of(123L));
    StepVerifier.create(result)
        .expectNext(
            ResponseEntity.ok()
                .headers(headers)
                .contentLength(responseBytes.length)
                .body(new ByteArrayResource(responseBytes)));
  }

  @Test
  void getZipFilesPost_BadRequests() {
    var result1 = documentController.getZipFilesPost(Set.of());
    StepVerifier.create(result1).expectNext(ResponseEntity.badRequest().build());
    var result2 = documentController.getZipFilesPost(null);
    StepVerifier.create(result2).expectNext(ResponseEntity.badRequest().build());
  }
}
