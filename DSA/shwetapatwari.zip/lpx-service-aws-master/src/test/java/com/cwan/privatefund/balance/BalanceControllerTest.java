package com.cwan.privatefund.balance;

import static com.cwan.privatefund.TestUtil.BALANCE_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getBalanceRequest;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import com.cwan.lpx.domain.Balance;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.balance.model.BalanceRequest;
import com.cwan.privatefund.publisher.MessagePublisher;
import java.time.Duration;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class BalanceControllerTest extends AuthenticatedControllerTest {

  private static final BalanceRequest BALANCE_REQUEST = getBalanceRequest();
  private static final Set<Balance> BALANCES = BALANCE_REQUEST.getBalances();
  private static final Flux<Balance> BALANCE_FLUX = Flux.fromIterable(BALANCES);
  private static final Long BALANCE_ID = 1L;
  private static final Set<Long> BALANCE_IDS = Set.of(BALANCE_ID);
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;
  @MockBean LpxBalanceEntityService lpxBalanceService;
  @MockBean MessagePublisher<Balance> balanceMessagePublisher;
  @Autowired private WebTestClient webClient;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_add_balance_successfully() {
    var given = getBalanceRequest();
    Mono<BalanceRequest> request = Mono.just(given);
    getPostForEntity(request);
    verify(balanceMessagePublisher, atLeast(1))
        .publishMessage(ArgumentMatchers.any(Balance.class), anyMap(), anyBoolean());
  }

  @Test
  void should_successfully_get_balance_by_balance_ids() {
    when(lpxBalanceService.getBalancesByIds(eq(BALANCE_IDS))).thenReturn(BALANCE_FLUX);
    var actual = getBalancesEntity(format("%s%s%d", BALANCE_URI, "?ids=", BALANCE_ID));
    assertEquals(BALANCES, actual);
  }

  @Test
  void should_delete_balance_from_balanceId() {
    var balanceRequest = getBalanceRequest();
    Set<Balance> balanceSet =
        balanceRequest.getBalances().stream()
            .peek(balance -> balance.setId(BALANCE_ID))
            .collect(Collectors.toSet());
    balanceRequest.setBalances(balanceSet);
    Mono<BalanceRequest> request = Mono.just(balanceRequest);
    getPostForEntity(request);
    verify(balanceMessagePublisher, atLeast(1))
        .publishMessage(ArgumentMatchers.any(Balance.class), anyMap(), anyBoolean());
  }

  @Test
  void should_update_balance() {
    var request = Mono.just(getBalanceRequest());
    exchangeForEntity(format("%s%s%s", BALANCE_URI, "?ids=", 1), PUT, request)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Void.class)
        .getResponseBody()
        .blockFirst();
    verify(balanceMessagePublisher, atLeast(1))
        .publishMessage(ArgumentMatchers.any(Balance.class), anyMap(), anyBoolean());
  }

  private Set<Balance> getBalancesEntity(final String uri) {
    return exchangeForEntity(uri, HttpMethod.GET)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Balance.class)
        .getResponseBody()
        .collect(Collectors.toSet())
        .share()
        .block();
  }

  private Set<Balance> deleteBalancesEntity(final Set<Long> balanceIds) {
    var idString = balanceIds.stream().map(Objects::toString).collect(Collectors.joining(","));
    return exchangeForEntity(format("%s%s%s", BALANCE_URI, "?ids=", idString), DELETE)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Balance.class)
        .getResponseBody()
        .collect(Collectors.toSet())
        .share()
        .block();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final HttpMethod httpMethod) {
    return webClient.method(httpMethod).uri(uri).exchange();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final HttpMethod httpMethod, final Mono<BalanceRequest> request) {
    return webClient.method(httpMethod).uri(uri).body(request, BalanceRequest.class).exchange();
  }

  private void getPostForEntity(final Mono<BalanceRequest> request) {
    exchangeForEntity(BALANCE_URI, POST, request)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(String.class)
        .getResponseBody()
        .blockFirst();
  }
}
