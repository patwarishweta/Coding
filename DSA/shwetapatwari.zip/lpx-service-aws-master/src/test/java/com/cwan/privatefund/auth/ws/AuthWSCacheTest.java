package com.cwan.privatefund.auth.ws;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.auth.model.SessionValidRequest;
import com.google.common.cache.Cache;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

public class AuthWSCacheTest {

  @Mock private AuthWSClient authWSClient;
  @Mock private Cache<SessionValidRequest, Boolean> sessionValidCache;
  public static final SessionValidRequest REQUEST =
      new SessionValidRequest("userId", "privateLabelId", "sessionId", "appication");
  private AuthWSCache instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance = new AuthWSCache(authWSClient, sessionValidCache);
  }

  @Test
  public void should_return_session_is_valid_from_cache() {
    when(sessionValidCache.getIfPresent(eq(REQUEST))).thenReturn(true);
    var actual = instance.isSessionValid(REQUEST).block();
    assertEquals(Boolean.TRUE, actual);
  }

  @Test
  public void should_return_session_is_valid_from_client() {
    when(sessionValidCache.getIfPresent(eq(REQUEST))).thenReturn(null);
    when(authWSClient.isSessionValid(eq(REQUEST))).thenReturn(Mono.just(true));
    var actual = instance.isSessionValid(REQUEST).block();
    assertEquals(Boolean.TRUE, actual);
    verify(sessionValidCache, times(1)).put(eq(REQUEST), eq(true));
  }
}
