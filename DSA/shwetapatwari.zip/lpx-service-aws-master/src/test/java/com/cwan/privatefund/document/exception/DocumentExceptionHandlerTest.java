package com.cwan.privatefund.document.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class DocumentExceptionHandlerTest {

  private DocumentExceptionHandler exceptionHandler;
  @Mock private BindingResult bindingResult;

  @Test
  void handleResponseStatusException_WithNullReason() {
    HttpStatus status = HttpStatus.BAD_REQUEST;
    ResponseStatusException ex = new ResponseStatusException(status);
    Mono<ResponseEntity<ValidationErrorResponse>> result =
        exceptionHandler.handleResponseStatusException(ex);
    StepVerifier.create(result)
        .assertNext(
            response -> {
              assertEquals(status, response.getStatusCode());
              assertEquals(status.value(), response.getBody().status());
              assertEquals("Unknown error", response.getBody().message());
              assertTrue(
                  (response.getBody().errors() == null) || response.getBody().errors().isEmpty());
            })
        .verifyComplete();
  }

  @Test
  void handleResponseStatusException_WithReason() {
    HttpStatus status = HttpStatus.NOT_FOUND;
    String reason = "Resource not found";
    ResponseStatusException ex = new ResponseStatusException(status, reason);
    Mono<ResponseEntity<ValidationErrorResponse>> result =
        exceptionHandler.handleResponseStatusException(ex);
    StepVerifier.create(result)
        .assertNext(
            response -> {
              assertEquals(status, response.getStatusCode());
              assertEquals(status.value(), response.getBody().status());
              assertEquals(reason, response.getBody().message());
              assertTrue(
                  (response.getBody().errors() == null) || response.getBody().errors().isEmpty());
            })
        .verifyComplete();
  }

  @Test
  void handleUnexpectedError() {
    Exception ex = new RuntimeException("Unexpected error");
    Mono<ValidationErrorResponse> result = exceptionHandler.handleUnexpectedError(ex);
    StepVerifier.create(result)
        .assertNext(
            response -> {
              assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.status());
              assertEquals("An unexpected error occurred", response.message());
              assertTrue((response.errors() == null) || response.errors().isEmpty());
            })
        .verifyComplete();
  }

  @Test
  void handleValidationErrors_WithEmptyObjectName() {
    WebExchangeBindException ex = mock(WebExchangeBindException.class);
    List<ObjectError> errors = new ArrayList<>();
    errors.add(new ObjectError("", "error message"));
    when(ex.getBindingResult()).thenReturn(bindingResult);
    when(bindingResult.getAllErrors()).thenReturn(errors);
    Mono<ValidationErrorResponse> result = exceptionHandler.handleValidationErrors(ex);
    StepVerifier.create(result)
        .assertNext(
            response -> {
              assertEquals(HttpStatus.BAD_REQUEST.value(), response.status());
              assertEquals("Validation failed", response.message());
              Map<String, String> errorMap = response.errors();
              assertNotNull(errorMap);
              assertEquals("error message", errorMap.get("global"));
            })
        .verifyComplete();
  }

  @Test
  void handleValidationErrors_WithFieldErrors() {
    WebExchangeBindException ex = mock(WebExchangeBindException.class);
    List<ObjectError> errors = new ArrayList<>();
    errors.add(new FieldError("object", "field1", "error1"));
    errors.add(new FieldError("object", "field2", "error2"));
    when(ex.getBindingResult()).thenReturn(bindingResult);
    when(bindingResult.getAllErrors()).thenReturn(errors);
    Mono<ValidationErrorResponse> result = exceptionHandler.handleValidationErrors(ex);
    StepVerifier.create(result)
        .assertNext(
            response -> {
              assertEquals(HttpStatus.BAD_REQUEST.value(), response.status());
              assertEquals("Validation failed", response.message());
              Map<String, String> errorMap = response.errors();
              assertNotNull(errorMap);
              assertEquals("error1", errorMap.get("field1"));
              assertEquals("error2", errorMap.get("field2"));
            })
        .verifyComplete();
  }

  @Test
  void handleValidationErrors_WithGlobalErrors() {
    WebExchangeBindException ex = mock(WebExchangeBindException.class);
    List<ObjectError> errors = new ArrayList<>();
    errors.add(new ObjectError("objectName", "global error"));
    ObjectError errorWithNullMessage = new ObjectError("objectName", null);
    errors.add(errorWithNullMessage);
    when(ex.getBindingResult()).thenReturn(bindingResult);
    when(bindingResult.getAllErrors()).thenReturn(errors);
    Mono<ValidationErrorResponse> result = exceptionHandler.handleValidationErrors(ex);
    StepVerifier.create(result)
        .assertNext(
            response -> {
              assertEquals(HttpStatus.BAD_REQUEST.value(), response.status());
              assertEquals("Validation failed", response.message());
              Map<String, String> errorMap = response.errors();
              assertNotNull(errorMap);
              assertEquals("global error; Unknown error", errorMap.get("objectName"));
            })
        .verifyComplete();
  }

  @BeforeEach
  void setUp() {
    exceptionHandler = new DocumentExceptionHandler();
  }
}
