package com.cwan.privatefund.capital.call.controller;

import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.capital.call.model.ComprehensiveAuditDetail;
import com.cwan.privatefund.capital.call.service.LpxCapitalCallService;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CapitalCallControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private LpxCapitalCallService lpxCapitalCallService;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void getCapitalCallsByAccounts() {
    var capitalCall1 = CapitalCallDocument.builder().build();
    // set fields for capitalCall1
    var capitalCall2 = CapitalCallDocument.builder().build();
    // set fields for capitalCall2
    when(lpxCapitalCallService.fetchAllCapitalCallsByAccounts(null))
        .thenReturn(Flux.just(capitalCall1, capitalCall2));
    webClient
        .get()
        .uri("/v1/capital-call")
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(CapitalCallDocument.class)
        .hasSize(2)
        .contains(capitalCall1, capitalCall2);
  }

  @Test
  void getCapitalCallsByAccounts_NoUserId() {
    webClient.get().uri("/v1/capital-call").exchange().expectStatus().is5xxServerError();
  }

  @Test
  void getCapitalCallsByAccounts_Error() {
    when(lpxCapitalCallService.fetchAllCapitalCallsByAccounts(null))
        .thenReturn(Flux.error(new RuntimeException("Test exception")));
    webClient.get().uri("/v1/capital-call").exchange().expectStatus().is5xxServerError();
  }

  @Test
  void updateCapitalCallStatus() {
    var request = CapitalCallAuditAction.builder().build();
    var capitalCall = CapitalCallDocument.builder().build();
    when(lpxCapitalCallService.updateCapitalCallStatus(
            any(), eq(CapitalCallStatus.WIRE_CHECK), eq(CapitalCallAction.APPROVE), anyString()))
        .thenReturn(Mono.just(capitalCall));
    webClient
        .post()
        .uri(
            "/v1/capital-call?documentId=1&currentStatus=WIRE_CHECK&action=APPROVE&comment=Test comment")
        .body(BodyInserters.fromValue(request))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(CapitalCallDocument.class)
        .isEqualTo(capitalCall);
  }

  @Test
  void updateCapitalCallStatus_Error() {
    var request = CapitalCallAuditAction.builder().build();
    when(lpxCapitalCallService.updateCapitalCallStatus(
            any(), eq(CapitalCallStatus.WIRE_CHECK), eq(CapitalCallAction.APPROVE), anyString()))
        .thenReturn(Mono.error(new RuntimeException("Test exception")));
    webClient
        .post()
        .uri(
            "/v1/capital-call?documentId=1&currentStatus=WIRE_CHECK&action=APPROVE&comment=Test comment")
        .body(BodyInserters.fromValue(request))
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  void getCapitalCallAuditByDocument() {
    var capitalCallAuditLog = CapitalCallAuditLog.builder().build();
    when(lpxCapitalCallService.getCapitalCallAuditByDocument(any()))
        .thenReturn(Mono.just(capitalCallAuditLog));
    webClient
        .get()
        .uri("/v1/capital-call/audit/1")
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CapitalCallAuditLog.class)
        .isEqualTo(capitalCallAuditLog);
  }

  @Test
  void getCapitalCallAuditByDocument_InvalidDocumentId() {
    when(lpxCapitalCallService.getCapitalCallAuditByDocument(any())).thenReturn(Mono.empty());
    webClient.get().uri("/v1/capital-call/audit/1").exchange().expectStatus().isNotFound();
  }

  @Test
  void getCapitalCallAuditByDocument_Error() {
    when(lpxCapitalCallService.getCapitalCallAuditByDocument(any()))
        .thenReturn(Mono.error(new RuntimeException("Test exception")));
    webClient.get().uri("/v1/capital-call/audit/1").exchange().expectStatus().is5xxServerError();
  }

  @Test
  void getCapitalCallsByStatus_Success() {
    var status = CapitalCallStatus.WIRE_CHECK;
    var capitalCall1 = CapitalCallDocument.builder().build();
    var capitalCall2 = CapitalCallDocument.builder().build();
    when(lpxCapitalCallService.getCapitalCallsByStatuses(Collections.singleton(status)))
        .thenReturn(Flux.just(capitalCall1, capitalCall2));
    webClient
        .get()
        .uri("/v1/capital-call/status/" + status)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(CapitalCallDocument.class)
        .hasSize(2)
        .contains(capitalCall1, capitalCall2);
  }

  @Test
  void getCapitalCallsByStatus_Error() {
    var status = CapitalCallStatus.WIRE_CHECK;
    when(lpxCapitalCallService.getCapitalCallsByStatuses(Collections.singleton(status)))
        .thenReturn(Flux.error(new RuntimeException("Test exception")));
    webClient
        .get()
        .uri("/v1/capital-call/status/" + status)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  void getCapitalCallsByDateRange_Success() {
    var startDate = LocalDate.now().minusDays(10);
    var endDate = LocalDate.now();
    when(lpxCapitalCallService.fetchCapitalCallsWithinDateRange(
            any(), eq(startDate), eq(endDate), eq(null)))
        .thenReturn(
            Flux.just(
                CapitalCallDocument.builder().build(), CapitalCallDocument.builder().build()));
    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/v1/capital-call/by-date-range")
                    .queryParam("filterType", CapitalCallDateFilterType.RECEIVED_DATE)
                    .queryParam("startDate", startDate.toString())
                    .queryParam("endDate", endDate.toString())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(CapitalCallDocument.class)
        .hasSize(2)
        .contains(CapitalCallDocument.builder().build(), CapitalCallDocument.builder().build());
  }

  @Test
  void getCapitalCallsByDateRange_Error() {
    var startDate = LocalDate.now().minusDays(10);
    var endDate = LocalDate.now();
    when(lpxCapitalCallService.fetchCapitalCallsWithinDateRange(
            any(), eq(startDate), eq(endDate), eq(null)))
        .thenReturn(Flux.error(new RuntimeException("Test exception")));
    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/v1/capital-call/by-date-range")
                    .queryParam("filterType", CapitalCallDateFilterType.RECEIVED_DATE)
                    .queryParam("startDate", startDate.toString())
                    .queryParam("endDate", endDate.toString())
                    .build())
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  void getComprehensiveAuditDetails_Success() {
    var startDate = LocalDate.now().minusDays(10);
    var endDate = LocalDate.now();
    when(lpxCapitalCallService.fetchDetailedAuditForCapitalCalls(
            any(), eq(startDate), eq(endDate), eq(null)))
        .thenReturn(
            Flux.just(
                ComprehensiveAuditDetail.builder().build(),
                ComprehensiveAuditDetail.builder().build()));
    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/v1/capital-call/comprehensive-audit")
                    .queryParam("filterType", CapitalCallDateFilterType.RECEIVED_DATE)
                    .queryParam("startDate", startDate.toString())
                    .queryParam("endDate", endDate.toString())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(ComprehensiveAuditDetail.class)
        .hasSize(2)
        .contains(
            ComprehensiveAuditDetail.builder().build(), ComprehensiveAuditDetail.builder().build());
  }

  @Test
  void getComprehensiveAuditDetails_Error() {
    var startDate = LocalDate.now().minusDays(10);
    var endDate = LocalDate.now();
    when(lpxCapitalCallService.fetchDetailedAuditForCapitalCalls(
            any(), eq(startDate), eq(endDate), eq(null)))
        .thenReturn(Flux.error(new RuntimeException("Test exception")));
    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/v1/capital-call/comprehensive-audit")
                    .queryParam("filterType", CapitalCallDateFilterType.RECEIVED_DATE)
                    .queryParam("startDate", startDate.toString())
                    .queryParam("endDate", endDate.toString())
                    .build())
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  void getPaymentInitiation_Success() {
    Long documentId = 1L;
    var mockResponse = "<xml>Payment initiation details</xml>";
    when(lpxCapitalCallService.processPaymentInitiation(documentId))
        .thenReturn(Mono.just(mockResponse));
    webClient
        .get()
        .uri("/v1/capital-call/payment-initiation?documentId=" + documentId)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .isEqualTo(mockResponse);
    verify(lpxCapitalCallService, times(1)).processPaymentInitiation(documentId);
  }

  @Test
  void getPaymentInitiation_BadRequest() {
    webClient
        .get()
        .uri("/v1/capital-call/payment-initiation")
        .exchange()
        .expectStatus()
        .isBadRequest();
  }

  @Test
  void getPaymentInitiation_InternalServerError() {
    Long documentId = 1L;
    when(lpxCapitalCallService.processPaymentInitiation(documentId))
        .thenReturn(Mono.error(new RuntimeException("Internal server error")));
    webClient
        .get()
        .uri("/v1/capital-call/payment-initiation?documentId=" + documentId)
        .exchange()
        .expectStatus()
        .is5xxServerError();
    verify(lpxCapitalCallService, times(1)).processPaymentInitiation(documentId);
  }
}
