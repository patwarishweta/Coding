package com.cwan.privatefund.accelex;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

import com.ca.relalg.data.DataSet;
import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.privatefund.accelex.AccelexService.LpData;
import com.cwan.privatefund.accelex.AccelexService.ReferenceFileType;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class AccelexControllerTest {

  @Mock private AccelexService accelexService;
  private static AccelexController instance;

  @BeforeAll
  void setup() {
    MockitoAnnotations.openMocks(this);
    instance = new AccelexController(accelexService);
  }

  @Test
  void getAccelexEnabled() {
    Long accountId = 1L;
    Map<Long, Boolean> expectedResponse = Map.of(accountId, true);
    when(accelexService.getEnabledStatusByAccountIds(any())).thenReturn(expectedResponse);
    Map<Long, Boolean> actualResponse = instance.getEnabledStatusByAccountIds(Set.of(accountId));
    assertEquals(expectedResponse, actualResponse);
  }

  @Test
  void getAccelexInvestmentsBySecurities() {
    AccelexInvestmentsEntity accelexInvestments = AccelexInvestmentsEntity.builder().build();
    when(accelexService.getAccelexInvestments(any(), any()))
        .thenReturn(List.of(accelexInvestments));
    Collection<AccelexInvestmentsEntity> accelexInvestmentsBySecurityIds =
        instance.getAccelexInvestmentsBySecurityIds(Set.of(1L), LocalDate.of(2024, 6, 7));
    assertEquals(accelexInvestmentsBySecurityIds, List.of(accelexInvestments));
  }

  @Test
  void getClaritySetUpStatus() {
    when(accelexService.getAccelexEnabledSecuritiesAndAccounts(any(), any())).thenReturn(List.of());
    List<LpData> accelexInvestmentsBySecurityIds = instance.getClaritySetUpStatus(1L, 108031);
    assertEquals(accelexInvestmentsBySecurityIds, List.of());
  }

  @Test
  void getAccelexPortfolioCompaniesBySecurities() {
    AccelexPortfolioCompanyEntity accelexPortfolioCompanyEntity =
        AccelexPortfolioCompanyEntity.builder().build();
    when(accelexService.getAccelexPortfolioCompanies(any(), any()))
        .thenReturn(List.of(accelexPortfolioCompanyEntity));
    Collection<AccelexPortfolioCompanyEntity> accelexInvestmentsBySecurityIds =
        instance.getPortfolioCompaniesBySecurityIds(Set.of(1L), LocalDate.of(2024, 6, 7));
    assertEquals(accelexInvestmentsBySecurityIds, List.of(accelexPortfolioCompanyEntity));
  }

  @Test
  void getAllFundReferenceData() throws IOException {
    when(accelexService.getFundEntityReferenceData(any(), anyBoolean()))
        .thenReturn(new DataSet<>());
    ResponseEntity<byte[]> responseEntity =
        instance.getAllFundReferenceData(ReferenceFileType.EVENT_REFERENCE_DATA);
    assertEquals(HttpStatusCode.valueOf(200), responseEntity.getStatusCode());
  }

  @Test
  void getFundReferenceDataForAccounts() throws IOException {
    when(accelexService.getFundEntityReferenceData(any(), any(), anyBoolean()))
        .thenReturn(new DataSet<>());
    ResponseEntity<byte[]> responseEntity =
        instance.getFundReferenceDataForAccounts(
            Set.of(), true, ReferenceFileType.EVENT_REFERENCE_DATA);
    assertEquals(HttpStatusCode.valueOf(200), responseEntity.getStatusCode());
  }
}
