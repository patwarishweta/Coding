package com.cwan.privatefund.clientSpecificData;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.ClientSpecificData;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ClientSpecificDataControllerTest {
  private LpxClientSpecificDataService lpxClientSpecificDataService;
  private ClientSpecificDataController INSTANCE;
  private ClientSpecificData CLIENT_SPECIFIC_DATA = ClientSpecificData.builder().id(1L).build();

  @BeforeEach
  void setUp() {
    lpxClientSpecificDataService = mock(LpxClientSpecificDataService.class);
    when(lpxClientSpecificDataService.saveClientSpecificData(Set.of(CLIENT_SPECIFIC_DATA)))
        .thenReturn(List.of(CLIENT_SPECIFIC_DATA));
    INSTANCE = new ClientSpecificDataController(lpxClientSpecificDataService);
  }

  @Test
  void saveClientSpecificData() {
    var result = INSTANCE.saveClientSpecificData(Set.of(CLIENT_SPECIFIC_DATA));

    assertEquals(List.of(CLIENT_SPECIFIC_DATA), result);
  }
}
