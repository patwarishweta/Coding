package com.cwan.privatefund.cpd.ws.config;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.config.properties.CpdConfigProperties;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;

class CpdWSConfigTest {

  @InjectMocks private CpdWSConfig cpdWSConfig;
  @Mock private CpdConfigProperties cpdConfigProperties;
  @Mock private ReactorClientHttpConnector reactorClientHttpConnector;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    var mockWebService = new CpdConfigProperties.WebService();
    mockWebService.setBaseUrl("https://test.com");
    mockWebService.setMaxMemorySize(2048);
    var mockCache = new CpdConfigProperties.Cache();
    mockCache.setMaxSize(1000);
    mockCache.setTimeoutInHours(2);
    var reviewers = new HashMap<String, Integer>();
    reviewers.put("Test", 1);
    reviewers.put("User", 2);
    var abaRoutingNumbers = new HashMap<String, Integer>();
    abaRoutingNumbers.put("123456", 100);
    abaRoutingNumbers.put("654321", 200);
    var mockFieldIds = new CpdConfigProperties.FieldIds();
    mockFieldIds.setReviewers(reviewers);
    mockFieldIds.setAbaRoutingNumbers(abaRoutingNumbers);
    when(cpdConfigProperties.getWebService()).thenReturn(mockWebService);
    when(cpdConfigProperties.getCache()).thenReturn(mockCache);
    when(cpdConfigProperties.getFieldIds()).thenReturn(mockFieldIds);
  }

  @Test
  void testCpdWebClient() {
    var webClient = cpdWSConfig.cpdWebClient(reactorClientHttpConnector);
    assertNotNull(webClient);
  }

  @Test
  void testTagEntriesCache() {
    var cache = cpdWSConfig.tagEntriesCache();
    assertNotNull(cache);
    assertNull(cache.getIfPresent(1L));
    cache.put(1L, new ConcurrentHashMap<>());
    assertNotNull(cache.getIfPresent(1L));
  }
}
