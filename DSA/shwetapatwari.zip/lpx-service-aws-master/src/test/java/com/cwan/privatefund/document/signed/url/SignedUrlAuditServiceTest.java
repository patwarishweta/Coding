package com.cwan.privatefund.document.signed.url;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.auth.SecurityContextService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class SignedUrlAuditServiceTest {

  @Mock private SignedUrlAuditRepository signedUrlAuditRepository;
  @Mock private BusinessWSCache businessWebCache;
  @Mock private SecurityContextService securityContextService;
  @InjectMocks private SignedUrlAuditService signedUrlAuditService;
  @Mock private SecurityContext securityContext;
  @Mock private Authentication authentication;
  private final Long documentId = 1L;
  private final Integer userId = 123;
  private final String fullName = "Test User";

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testPerformAuditWithValidUser() {
    var validEmail = "user@example.com";
    var user = User.builder().id(userId).email(validEmail).fullname(fullName).build();
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(userId);
    when(businessWebCache.fetchUserDetails(userId)).thenReturn(Mono.just(user));
    when(signedUrlAuditRepository.saveAndFlush(any(SignedUrlAudit.class)))
        .thenAnswer(invocation -> null);
    StepVerifier.create(signedUrlAuditService.performAudit(documentId)).verifyComplete();
    verify(signedUrlAuditRepository, times(1)).saveAndFlush(any(SignedUrlAudit.class));
    verify(securityContextService, times(1)).getContext();
    verify(businessWebCache, times(1)).fetchUserDetails(userId);
  }

  @Test
  void testPerformAuditWithInvalidEmail() {
    var invalidEmail = "user@clearwateranalytics.com";
    var user = User.builder().id(userId).email(invalidEmail).fullname(fullName).build();
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(userId);
    when(businessWebCache.fetchUserDetails(userId)).thenReturn(Mono.just(user));
    StepVerifier.create(signedUrlAuditService.performAudit(documentId)).verifyComplete();
    verify(signedUrlAuditRepository, never()).saveAndFlush(any(SignedUrlAudit.class));
  }

  @Test
  void testPerformAuditWithNoUserId() {
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(null);
    StepVerifier.create(signedUrlAuditService.performAudit(documentId)).verifyComplete();
    verify(signedUrlAuditRepository, never()).saveAndFlush(any(SignedUrlAudit.class));
  }

  @Test
  void testPerformAuditWithEmptyContext() {
    when(securityContextService.getContext()).thenReturn(Mono.empty());
    StepVerifier.create(signedUrlAuditService.performAudit(documentId)).verifyComplete();
    verify(securityContextService, times(1)).getContext();
    verify(signedUrlAuditRepository, never()).saveAndFlush(any(SignedUrlAudit.class));
  }

  @Test
  void testPerformAuditWithNullUser() {
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(userId);
    when(businessWebCache.fetchUserDetails(userId)).thenReturn(Mono.empty());
    StepVerifier.create(signedUrlAuditService.performAudit(documentId)).verifyComplete();
    verify(signedUrlAuditRepository, never()).saveAndFlush(any(SignedUrlAudit.class));
  }

  @Test
  void testPerformAuditOnError() {
    when(securityContextService.getContext())
        .thenReturn(Mono.error(new RuntimeException("Test exception")));
    StepVerifier.create(signedUrlAuditService.performAudit(documentId)).verifyComplete();
    verify(signedUrlAuditRepository, never()).saveAndFlush(any(SignedUrlAudit.class));
  }
}
