package com.cwan.privatefund.capital.call.service;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import com.cwan.privatefund.business.ws.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallBlacklistServiceTest {

  @Mock private CapitalCallBlacklistAbaRoutingService blacklistService;
  @Mock private CapitalCallStatusUpdaterService capitalCallStatusUpdaterService;
  @InjectMocks private CapitalCallBlacklistService service;
  private static final Long DOCUMENT_ID = 1L;
  private CapitalCallDocument document;

  @BeforeEach
  void setUp() {
    document = CapitalCallDocument.builder().documentId(DOCUMENT_ID).build();
  }

  @Test
  void evaluateBlacklistStatus_WhenCalled_ShouldDelegateToBlacklistService() {
    when(blacklistService.isAbaRoutingNumberBlacklisted(document)).thenReturn(Mono.just(true));
    StepVerifier.create(service.evaluateBlacklistStatus(document))
        .expectNext(true)
        .verifyComplete();
    verify(blacklistService).isAbaRoutingNumberBlacklisted(document);
  }

  @Test
  void updateCapitalCallStatus_WhenBlacklisted_ShouldUpdateStatusAndHandleNewBankAccount() {
    Boolean isBlacklisted = true;
    var systemUser =
        User.builder()
            .id(SystemUserConstants.ID)
            .fullname(SystemUserConstants.FULL_NAME)
            .email(SystemUserConstants.EMAIL)
            .build();
    when(capitalCallStatusUpdaterService.updateStatusAndTransform(
            systemUser,
            document.documentId(),
            document.status(),
            CapitalCallAction.REJECT,
            "Bank is blacklisted."))
        .thenReturn(Mono.just(document));
    StepVerifier.create(service.updateCapitalCallStatus(document, isBlacklisted))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void updateCapitalCallStatus_WhenNotBlacklisted_ShouldUpdateStatusAndHandleNewBankAccount() {
    Boolean isBlacklisted = false;
    var systemUser =
        User.builder()
            .id(SystemUserConstants.ID)
            .fullname(SystemUserConstants.FULL_NAME)
            .email(SystemUserConstants.EMAIL)
            .build();
    when(capitalCallStatusUpdaterService.updateStatusAndTransform(
            systemUser,
            document.documentId(),
            document.status(),
            CapitalCallAction.APPROVE,
            "Bank is not blacklisted."))
        .thenReturn(Mono.just(document));
    when(capitalCallStatusUpdaterService.handleNewBankAccount(document, systemUser))
        .thenReturn(Mono.just(document));
    StepVerifier.create(service.updateCapitalCallStatus(document, isBlacklisted))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void updateCapitalCallStatus_WithRoutingInfo_ShouldIncludeRoutingInfoInComment() {
    Boolean isBlacklisted = true;
    var systemUser =
        User.builder()
            .id(SystemUserConstants.ID)
            .fullname(SystemUserConstants.FULL_NAME)
            .email(SystemUserConstants.EMAIL)
            .build();
    var bankDetail =
        CapitalCallBankDetail.builder().abaRoutingNumber("12345").swiftOrChips("SWIFT123").build();
    document = CapitalCallDocument.builder().documentId(DOCUMENT_ID).bankDetail(bankDetail).build();
    when(capitalCallStatusUpdaterService.updateStatusAndTransform(
            systemUser,
            document.documentId(),
            document.status(),
            CapitalCallAction.REJECT,
            "Bank with ABA '12345' and SWIFT/CHIPS 'SWIFT123' is blacklisted."))
        .thenReturn(Mono.just(document));
    StepVerifier.create(service.updateCapitalCallStatus(document, isBlacklisted))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void buildRoutingInfo_WhenBankDetailIsNull_ShouldLogWarningAndReturnNull() {
    var routingInfo = service.buildRoutingInfo(document);
    assertNull(routingInfo);
  }
}
