package com.cwan.privatefund.directory;

import static com.cwan.privatefund.TestUtil.getDirectory;
import static com.cwan.privatefund.TestUtil.getDirectoryEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DirectoryTransformerTest {

  private static final Long DOCUMENT_ID = 1L;

  @Test
  public void should_convert_directory_entity_to_directory() {
    var expected = getDirectory(DOCUMENT_ID);
    var actual = new DirectoryTransformer().apply(getDirectoryEntity(DOCUMENT_ID));
    assertEquals(expected, actual);
  }
}
