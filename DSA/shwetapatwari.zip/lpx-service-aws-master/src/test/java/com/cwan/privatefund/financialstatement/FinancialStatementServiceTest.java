package com.cwan.privatefund.financialstatement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.FinancialStatement;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.fs.api.FinancialReports;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class FinancialStatementServiceTest {

  private FinancialStatementService financialStatementService;
  @Mock private FinancialReports financialReports;
  @Mock private AccountService accountService;
  @Mock private SecurityService securityService;
  @Mock private Documents documents;
  private static final FinancialStatement FINANCIAL_STATEMENT = TestUtil.getFinancialStatement();
  private static final Flux<FinancialStatement> FINANCIAL_STATEMENT_FLUX =
      Flux.just(FINANCIAL_STATEMENT);
  private static final Document DOCUMENT = TestUtil.getDocument();
  private static final Account ACCOUNT = TestUtil.getAccount();
  private static final Security SECURITY = TestUtil.getSecurity();
  private final Flux<FinancialStatement> expectedFinancialStatement =
      Flux.just(
          FINANCIAL_STATEMENT.toBuilder()
              .account(ACCOUNT)
              .document(DOCUMENT)
              .security(SECURITY)
              .build());

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    financialStatementService =
        new FinancialStatementService(financialReports, accountService, securityService, documents);
    when(documents.getDocumentById(anyLong())).thenReturn(Mono.just(DOCUMENT));
    when(accountService.getAccountData(anyLong())).thenReturn(Mono.just(ACCOUNT));
    when(securityService.getSecurity(anyLong(), anyLong(), anyLong()))
        .thenReturn(Mono.just(SECURITY));
  }

  @Test
  void hydrateSADDataTest() {
    Flux<FinancialStatement> result =
        financialStatementService.hydrateSADData(FINANCIAL_STATEMENT_FLUX);
    List<FinancialStatement> expectedList =
        expectedFinancialStatement.collect(Collectors.toList()).block();
    List<FinancialStatement> resultList = result.collect(Collectors.toList()).block();
    assertEquals(expectedList, resultList);
  }

  @Test
  void getFinancialStatementsByDocumentIdTest() {
    when(financialReports.getAllFinancialStatementsByDocumentId(any()))
        .thenReturn(FINANCIAL_STATEMENT_FLUX);
    Flux<FinancialStatement> result =
        financialStatementService.getFinancialStatementsByDocumentId(23L);
    List<FinancialStatement> expectedList =
        expectedFinancialStatement.collect(Collectors.toList()).block();
    List<FinancialStatement> resultList = result.collect(Collectors.toList()).block();
    assertEquals(expectedList, resultList);
  }

  @Test
  void getFinancialStatementsByIdsTest() {
    when(financialReports.getReportsByIds(any())).thenReturn(FINANCIAL_STATEMENT_FLUX);
    Flux<FinancialStatement> result =
        financialStatementService.getFinancialStatementsByIds(Set.of(1L));
    List<FinancialStatement> expectedList =
        expectedFinancialStatement.collect(Collectors.toList()).block();
    List<FinancialStatement> resultList = result.collect(Collectors.toList()).block();
    assertEquals(expectedList, resultList);
  }

  @Test
  void addDocumentDataToFinancialStatementTest() {
    FinancialStatement emptyFinancialStatement = FinancialStatement.builder().id(1L).build();
    FinancialStatement result =
        financialStatementService
            .addDocumentDataToFinancialStatement(emptyFinancialStatement)
            .block();
    assertEquals(emptyFinancialStatement, result);
  }
}
