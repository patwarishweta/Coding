package com.cwan.privatefund.directory;

import static com.cwan.privatefund.TestUtil.getDirectory;
import static com.cwan.privatefund.TestUtil.getDirectoryEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DirectoryEntityTransformerTest {

  public static final Long DIRECTORY_ID = 1L;

  @Test
  void should_convert_directory_to_directory_entity() {
    var expected = getDirectoryEntity(DIRECTORY_ID);
    var actual = new DirectoryEntityTransformer().apply(getDirectory(DIRECTORY_ID));
    assertEquals(expected, actual);
  }
}
