package com.cwan.privatefund.accountconfig;

import static com.cwan.privatefund.TestUtil.getAccountConfig;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import com.cwan.privatefund.client.WebResponseMapper;
import java.net.UnknownHostException;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class AccountConfigServiceClientTest {

  @Mock private WebClient webClient;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private WebResponseMapper<AccountConfigServiceException> responseMapper;
  private static final Long ACCOUNT_ID = 42L;
  private static final String SERVICE = "service";
  private static final List<AccountConfig> ACCOUNT_CONFIGS = List.of(getAccountConfig());
  private AccountConfigServiceClient instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(webClient.get()).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.uri(any(Function.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.accept(MediaType.APPLICATION_JSON))
        .thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just(ACCOUNT_CONFIGS));
    instance = new AccountConfigServiceClient(webClient);
  }

  @Test
  void accountConfigClient_api_call_4xx_with_error_response_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just("4xx error sent from  accountConfig ws"));
    assertThrows(RuntimeException.class, () -> instance.getByAccountId(1L).block());
  }

  @Test
  void accountConfigClient_api_call_5xx_with_error_response_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just("5xx error sent from  account-config ws"));
    assertThrows(RuntimeException.class, () -> instance.getByAccountId(1L).block());
  }

  @Test
  void accountConfigClient_api_call_error_resume_unknownhost_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.error(new UnknownHostException("Exception UnknownHost Testing ")));
    StepVerifier.create(instance.getByAccountId(1L)).expectNextCount(0).verifyComplete();
    StepVerifier.create(instance.getAllAccountConfigs("LPxFullService"))
        .expectNextCount(0)
        .verifyComplete();
  }

  @Test
  void should_return_account_config_by_account() {
    var actual = instance.getByAccountId(ACCOUNT_ID).block();
    assertEquals(ACCOUNT_CONFIGS, actual);
  }

  @Test
  void should_return_account_config_get_all() {
    var actual = instance.getAllAccountConfigs(SERVICE).block();
    assertEquals(ACCOUNT_CONFIGS, actual);
  }
}
