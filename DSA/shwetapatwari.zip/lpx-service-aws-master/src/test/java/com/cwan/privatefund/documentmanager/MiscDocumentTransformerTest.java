package com.cwan.privatefund.documentmanager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.account.UltimateParents;
import com.cwan.privatefund.documentmanager.enums.MiscDocumentStatus;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class MiscDocumentTransformerTest {

  private final MiscDocumentTransformer miscDocumentTransformer = new MiscDocumentTransformer();
  private static final LocalDate DOC_DATE = LocalDate.now();
  private static final Document DOCUMENT =
      Document.builder()
          .id(123L)
          .type("CAPC")
          .documentDate(DOC_DATE)
          .cashMovementDate(DOC_DATE)
          .receivedDate(DOC_DATE)
          .account(Account.builder().id(234L).name("Acc Name").build())
          .security(Security.builder().securityId(345L).securityName("Sec Name").build())
          .createdBy("abcd@efgh.com")
          .build();
  private static final UltimateParents ULTIMATE_PARENTS =
      UltimateParents.builder()
          .ultimateParentId(987L)
          .ultimateParentName("Ultimate Parent")
          .build();

  @Test
  void testMiscDocumentTransformer() {
    var actual = miscDocumentTransformer.transform(DOCUMENT, ULTIMATE_PARENTS);
    assertEquals(MiscDocumentStatus.ACTIVE.getValue(), actual.getStatus());
  }

  @Test
  void testMiscDocumentTransformer_NullSecurity() {
    var actual =
        miscDocumentTransformer.transform(
            DOCUMENT.toBuilder().security(null).build(), ULTIMATE_PARENTS);
    assertNull(actual.getSecurityId());
    assertNull(actual.getSecurityName());
  }
}
