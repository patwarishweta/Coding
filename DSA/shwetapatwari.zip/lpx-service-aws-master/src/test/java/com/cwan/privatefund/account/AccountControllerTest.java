package com.cwan.privatefund.account;

import static com.cwan.privatefund.TestUtil.ACCOUNT_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getAccount;
import static com.cwan.privatefund.TestUtil.getBasis;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.basis.ws.model.Basis;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class AccountControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private AccountService accountService;

  private WebTestClient.ResponseSpec exchangeForEntity(String uri, HttpMethod httpMethod) {
    return webClient.method(httpMethod).uri(uri).exchange();
  }

  private Set<Account> getAccountsEntity(String uri) {
    return Set.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri, HttpMethod.GET)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(Account.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_successfully_get_accounts_by_client_id() {
    var userId = 9;
    var clientId = 1337L;
    var account = getAccount();
    var accounts = Set.of(account);
    when(accountService.getClientAccounts(eq(clientId), eq(userId)))
        .thenReturn(Flux.fromIterable(accounts));
    var balanceResponse =
        getAccountsEntity(
            format("%s%s%d%s%d", ACCOUNT_URI, "/client/", clientId, "?userId=", userId));
    assertEquals(accounts, balanceResponse);
  }

  @Test
  void should_successfully_get_accounts_by_user_id() {
    var userId = 9;
    var account = getAccount();
    var accounts = Set.of(account);
    when(accountService.retrieveUserAccounts(eq(userId))).thenReturn(Flux.fromIterable(accounts));
    var balanceResponse = getAccountsEntity(format("%s%s%d", ACCOUNT_URI, "?userId=", userId));
    assertEquals(accounts, balanceResponse);
  }

  @Test
  void should_successfully_get_client_hierarchy() {
    Map<Long, SortedMap<Integer, Long>> expected =
        Map.of(24601L, new TreeMap<>(Map.of(1, 24601L, 2, 24602L)));
    when(accountService.getClientHierarchyForClients(eq(Set.of(24601L)))).thenReturn(expected);
    var response =
        exchangeForEntity(
                format(
                    "%s%s%s%d", ACCOUNT_URI, "/client/getClientHierarchies", "?clientIds=", 24601L),
                HttpMethod.GET)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(Map.class)
            .getResponseBody()
            .collectList()
            .block();
    assertEquals(1, Objects.requireNonNull(response).get(0).size());
    assertEquals("24601", response.get(0).keySet().iterator().next());
  }

  @Test
  void should_successfully_get_enabled_bases_by_account_id() {
    var userId = 9;
    var accountId = 1337L;
    var bases = List.of(getBasis());
    when(accountService.getEnabledBases(eq(accountId), eq(userId)))
        .thenReturn(Flux.fromIterable(bases));
    var response =
        exchangeForEntity(
                format("%s%s%d%s%d", ACCOUNT_URI, "/bases/", accountId, "?userId=", userId),
                HttpMethod.GET)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(Basis.class)
            .getResponseBody()
            .collectList()
            .block();
    assertEquals(bases, response);
  }

  @Test
  void test_get_client_accounts_by_user_id() {
    Integer userId = 1;
    List<Account> accounts = new ArrayList<>();
    accounts.add(new Account());
    Flux<ClientAccounts> expected = Flux.just(new ClientAccounts(1L, new Client(), accounts));
    when(accountService.getClientAccountsData(userId)).thenReturn(expected);
    Flux<ClientAccounts> result =
        exchangeForEntity("/v1/accounts/client?userId=1", HttpMethod.GET)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(ClientAccounts.class)
            .getResponseBody();
    StepVerifier.create(result)
        .expectNextMatches(clientAccounts -> clientAccounts.getId() == 1L)
        .expectComplete()
        .verify();
  }

  @Test
  void test_get_ultimate_parent_map_by_user_id() {
    Integer userId = 1;
    List<Account> accounts = new ArrayList<>();
    accounts.add(new Account());
    when(accountService.retrieveAccountsGroupedByUltimateParent(userId))
        .thenReturn(
            Flux.just(
                UltimateParentsAccountMap.builder()
                    .ultimateParentId(1)
                    .accounts(accounts)
                    .build()));
    Flux<UltimateParentsAccountMap> result =
        exchangeForEntity("/v1/accounts/ultimateParentMap?userId=1", HttpMethod.GET)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(UltimateParentsAccountMap.class)
            .getResponseBody();
    StepVerifier.create(result)
        .expectNextMatches(
            ultimateParentsAccountMap ->
                (ultimateParentsAccountMap.getUltimateParentId() == 1)
                    && (ultimateParentsAccountMap.getAccounts().size() == 1))
        .expectComplete()
        .verify();
  }
}
