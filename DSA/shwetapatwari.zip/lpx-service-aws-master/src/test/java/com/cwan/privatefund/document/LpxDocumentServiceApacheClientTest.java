package com.cwan.privatefund.document;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.cwan.lpx.domain.Document;
import java.util.List;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.MockitoAnnotations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class LpxDocumentServiceApacheClientTest {
  private static final TestHttpClient testClient = new TestHttpClient();
  private static final Document DOCUMENT = Document.builder().id(123L).build();
  private static final FakeWsResponse fakeDocumentResponse =
      new FakeWsResponse()
          .setRequestUrl("v1/document")
          .setStatusCode(200)
          .setBody(JsonUtils2.objToJson(List.of(DOCUMENT)));

  private static final FakeWsResponse fakeNoDocumentResponse =
      new FakeWsResponse()
          .setRequestUrl("v1/document")
          .setStatusCode(200)
          .setBody(JsonUtils2.objToJson(List.of()));
  private final LpxDocumentServiceApacheClient INSTANCE =
      new LpxDocumentServiceApacheClient(
          testClient,
          new ServerConfiguration(
              "lpx-document-service", 8084, "lpx-document-service", Scheme.HTTPS));

  @BeforeAll
  void setup() throws ExecutionException {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void saveDocument() {
    testClient.setResponses(fakeDocumentResponse);
    Document canoeDoc = INSTANCE.saveDocument(new Document(), "CANOE");
    assertEquals(DOCUMENT, canoeDoc);
  }

  @Test
  void saveDocument_noDocumentsReturned() {
    testClient.setResponses(fakeNoDocumentResponse);

    Document canoeDoc = INSTANCE.saveDocument(new Document(), "CANOE");
    assertNull(canoeDoc);
  }
}
