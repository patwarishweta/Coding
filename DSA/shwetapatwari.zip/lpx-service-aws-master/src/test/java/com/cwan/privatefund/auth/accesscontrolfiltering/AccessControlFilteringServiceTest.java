package com.cwan.privatefund.auth.accesscontrolfiltering;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.User;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class AccessControlFilteringServiceTest {

  @Mock private AccountService accountService;
  @Mock private BusinessWSCache businessWebCache;
  @InjectMocks private AccessControlFilteringService accessControlFilteringService;

  @Test
  void checkResourceAccessByAccount_HasAccess() {
    var user = User.builder().id(1).fullname("Some User").build();
    when(accountService.retrieveUserAccessibleAccountIds(any()))
        .thenReturn(Mono.just(Set.of(1L, 2L, 3L)));
    var result = accessControlFilteringService.checkResourceAccessByAccount(user, 1L).block();
    assertEquals(Boolean.TRUE, result);
  }

  @Test
  void checkResourceAccessByAccount_NoAccess() {
    var user = User.builder().id(1).fullname("Some User").build();
    when(accountService.retrieveUserAccessibleAccountIds(any()))
        .thenReturn(Mono.just(Set.of(1L, 2L, 3L)));
    var result = accessControlFilteringService.checkResourceAccessByAccount(user, 4L).block();
    assertEquals(Boolean.FALSE, result);
  }

  @Test
  void checkUserAccess_HasAccess() {
    when(businessWebCache.getUserAccountAccess(1, Set.of(1234L)))
        .thenReturn(Mono.just(Map.of(1234L, Boolean.TRUE)));
    var result =
        accessControlFilteringService.checkAccountsAccessForUserid(1, Set.of(1234L)).block();
    assertEquals(List.of(1234L), result);
  }

  @Test
  void checkUserAccess_NoAccess() {
    when(businessWebCache.getUserAccountAccess(1, Set.of(1234L, 1235L)))
        .thenReturn(Mono.just(Map.of(1234L, Boolean.FALSE, 1235L, Boolean.FALSE)));
    var result =
        accessControlFilteringService.checkAccountsAccessForUserid(1, Set.of(1234L, 1235L)).block();
    assertEquals(List.of(), result);
  }

  @Test
  void checkUserAccess_HasAccessAndNoAccess() {
    when(businessWebCache.getUserAccountAccess(1, Set.of(1234L, 1235L)))
        .thenReturn(Mono.just(Map.of(1234L, Boolean.FALSE, 1235L, Boolean.TRUE)));
    var result =
        accessControlFilteringService.checkAccountsAccessForUserid(1, Set.of(1234L, 1235L)).block();
    assertEquals(List.of(1235L), result);
  }
}
