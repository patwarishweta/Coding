package com.cwan.privatefund.cpd.ws.controller;

import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.cpd.ws.client.CpdWSCache;
import com.cwan.privatefund.cpd.ws.model.CpdFieldAndData;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CpdWSControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private CpdWSCache cpdWSCache;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void getTagEntriesForClient_ReturnsTagEntries() {
    var clientId = 1;
    var sampleMap = new ConcurrentHashMap<String, TagEntry>();
    sampleMap.put("testKey", TagEntry.builder().fieldId(1).build());
    when(cpdWSCache.getTagEntriesForClient(any(), any(), any())).thenReturn(Mono.just(sampleMap));
    webClient
        .get()
        .uri("/v1/cpd-ws/tags/" + clientId + "/1")
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(new ParameterizedTypeReference<ConcurrentHashMap<String, TagEntry>>() {})
        .isEqualTo(sampleMap);
  }

  @Test
  void getTagEntriesForClient_Error() {
    var clientId = 1;
    when(cpdWSCache.getTagEntriesForClient(any(), any(), any()))
        .thenReturn(Mono.error(new RuntimeException("Test exception")));
    webClient
        .get()
        .uri("/v1/cpd-ws/tags/" + clientId + "/1")
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }

  @Test
  void clearCacheForClient_ClearsCacheSuccessfully() {
    var clientId = 1L;
    when(cpdWSCache.clearCacheForClient(clientId)).thenReturn(Mono.empty());
    webClient
        .post()
        .uri("/v1/cpd-ws/clear-cache/" + clientId)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .isEqualTo("Cache cleared successfully for client ID: " + clientId);
  }

  @Test
  void clearCacheForClient_InvalidClientId() {
    var clientId = -1L;
    when(cpdWSCache.clearCacheForClient(clientId))
        .thenReturn(Mono.error(new IllegalArgumentException("Invalid client ID provided")));
    webClient
        .post()
        .uri("/v1/cpd-ws/clear-cache/" + clientId)
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody(String.class)
        .isEqualTo("Invalid client ID provided");
  }

  @Test
  void clearCacheForClient_InternalError() {
    var clientId = 1L;
    when(cpdWSCache.clearCacheForClient(clientId))
        .thenReturn(Mono.error(new RuntimeException("Internal error")));
    webClient
        .post()
        .uri("/v1/cpd-ws/clear-cache/" + clientId)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(String.class)
        .isEqualTo("Error occurred while clearing the cache for client ID: " + clientId);
  }

  @Test
  void clearCache_ClearsCacheSuccessfully() {
    when(cpdWSCache.clearCache()).thenReturn(Mono.empty());
    webClient
        .post()
        .uri("/v1/cpd-ws/clear-cache")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .isEqualTo("Cache cleared successfully");
  }

  @Test
  void clearCache_InternalError() {
    when(cpdWSCache.clearCache())
        .thenReturn(Mono.error(new RuntimeException("Internal error during cache clearing")));
    webClient
        .post()
        .uri("/v1/cpd-ws/clear-cache")
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(String.class)
        .isEqualTo("Error occurred while clearing the cache");
  }

  @Test
  void getFieldAndDataEntriesForClient() {
    var clientId = 1L;
    CpdFieldAndData cpdFieldAndData =
        CpdFieldAndData.builder()
            .id(101)
            .clientId(clientId)
            .properties(Set.of("prop1", "ENABLED_IN_LMC"))
            .data(Map.of(2, "CPD VALUE"))
            .build();
    List<CpdFieldAndData> list = List.of(cpdFieldAndData);
    when(cpdWSCache.getCpdFieldAndDataForClient(anyLong())).thenReturn(Mono.just(list));
    webClient
        .get()
        .uri("/v1/cpd-ws/enabled-fields/" + clientId)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(new ParameterizedTypeReference<List<CpdFieldAndData>>() {})
        .isEqualTo(list);
  }

  @Test
  void getFieldAndDataEntriesForClientReturnsError() {
    var clientId = 1L;
    when(cpdWSCache.getCpdFieldAndDataForClient(anyLong()))
        .thenReturn(Mono.error(new RuntimeException("Test exception")));
    webClient
        .get()
        .uri("/v1/cpd-ws/enabled-fields/" + clientId)
        .exchange()
        .expectStatus()
        .is5xxServerError();
  }
}
