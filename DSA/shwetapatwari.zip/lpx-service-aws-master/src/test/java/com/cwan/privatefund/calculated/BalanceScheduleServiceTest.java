package com.cwan.privatefund.calculated;

import static com.cwan.privatefund.calculated.CalculatedBalanceService.ALL_NAV_SCHEDULE;
import static com.cwan.privatefund.calculated.CalculatedBalanceService.GAAP_NAV_SCHEDULE;
import static com.cwan.privatefund.calculated.CalculatedBalanceService.STAT_NAV_SCHEDULE;
import static com.cwan.privatefund.constant.Constants.CALCULATED_SOURCE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.trans.Constants.TransactionBasisAffects;
import com.cwan.privatefund.calculated.model.BalanceSchedule;
import com.cwan.privatefund.calculated.model.BalanceScheduleKey;
import com.cwan.privatefund.calculated.model.BalanceTypeKey;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class BalanceScheduleServiceTest {

  private final BalanceAffectService balanceAffectService = new BalanceAffectService();

  private final BalanceScheduleService balanceScheduleService =
      new BalanceScheduleService(balanceAffectService);

  private static final long ACCOUNT_ID = 1;
  private static final Account ACCOUNT = Account.builder().id(1L).build();
  private static final Security SECURITY = Security.builder().securityId(2L).build();
  private static final LocalDate START_DATE = LocalDate.of(2022, 1, 1);
  private static final LocalDate DAY1 = START_DATE;
  private static final LocalDate DAY2 = START_DATE.plusDays(1);
  private static final LocalDate DAY3 = START_DATE.plusDays(2);
  private static final LocalDate DAY4 = START_DATE.plusDays(3);
  private static final LocalDate DAY5 = START_DATE.plusDays(4);
  private static final LocalDate END_DATE = LocalDate.of(2022, 1, 31);
  private static final LocalDate CONFIGURE_DATE = START_DATE.plusDays(2);
  private static final WatchlistEntity WATCHLIST_ENTITY =
      WatchlistEntity.builder()
          .accountId(1L)
          .securityId(2L)
          .startDate(START_DATE.minusMonths(1))
          .endDate(START_DATE.plusMonths(1))
          .build();
  private static final Map<Long, Set<WatchlistEntity>> WATCHLIST_PERIOD =
      Map.of(1L, Set.of(WATCHLIST_ENTITY));

  @BeforeEach
  void beforeEach() {
    openMocks(this);
  }

  @Test
  public void createBalanceMapTest() {
    Transaction BUY =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY1)
            .entryDate(DAY1)
            .type("BUY")
            .navImpact(1.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .security(SECURITY)
            .build();
    Transaction COMMITMENT_ADJUSTMENT =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .entryDate(DAY2)
            .type("COMMITMENT_ADJUSTMENT")
            .subType("TOTAL_COMMITMENT")
            .navImpact(10.0)
            .recallableImpact(20.0)
            .totalCommitmentImpact(30.0)
            .unfundedCommitmentImpact(30.0)
            .fundedCommitmentImpact(-30.0)
            .cashImpact(40.0)
            .security(SECURITY)
            .build();
    Transaction CAPC =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY3)
            .entryDate(DAY3)
            .type("CAPC")
            .navImpact(100.0)
            .recallableImpact(200.0)
            .unfundedCommitmentImpact(300.0)
            .fundedCommitmentImpact(-300.0)
            .cashImpact(400.0)
            .security(SECURITY)
            .build();
    Transaction CAPD =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY4)
            .entryDate(DAY4)
            .type("CAPD")
            .navImpact(1000.0)
            .recallableImpact(2000.0)
            .unfundedCommitmentImpact(3000.0)
            .fundedCommitmentImpact(-3000.0)
            .cashImpact(4000.0)
            .security(SECURITY)
            .build();
    Transaction OVERRIDE =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY5)
            .entryDate(DAY5)
            .type("GENERAL_ADJUSTMENT")
            .navImpact(10000.0)
            .recallableImpact(20000.0)
            .unfundedCommitmentImpact(30000.0)
            .fundedCommitmentImpact(-30000.0)
            .cashImpact(40000.0)
            .security(SECURITY)
            .build();

    Map<BalanceScheduleKey, BalanceSchedule> actual =
        balanceScheduleService.createBalanceMap(
            ACCOUNT_ID,
            List.of(BUY, COMMITMENT_ADJUSTMENT, CAPC, CAPD),
            List.of(OVERRIDE),
            List.of(BUY),
            WATCHLIST_PERIOD,
            DAY1,
            END_DATE,
            CONFIGURE_DATE,
            true);
    BalanceSchedule expectedSchedule = new BalanceSchedule();
    for (String basis :
        List.of(
            TransactionBasisAffects.ALL,
            TransactionBasisAffects.STAT,
            TransactionBasisAffects.GAAP)) {
      expectedSchedule.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY1, 1.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY2, 1.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY3, 101.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY4, 1101.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY5, 11101.0, basis);

      expectedSchedule.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY1, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY2, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY3, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY4, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY5, 0.0, basis);

      expectedSchedule.addNewBalance(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY1, 0.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY2, 0.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY3, 100.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY4, 1100.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY5, 1100.0, basis);

      expectedSchedule.addNewBalance(BalanceType.REPORTED_TOTAL_COMMITMENT, DAY1, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_TOTAL_COMMITMENT, DAY2, 30.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_TOTAL_COMMITMENT, DAY3, 30.0, basis);
      expectedSchedule.addNewBalance(BalanceType.REPORTED_TOTAL_COMMITMENT, DAY4, 30.0, basis);

      expectedSchedule.addNewBalance(BalanceType.FUNDED_COMMITMENT, DAY1, -3.0, basis);
      expectedSchedule.addNewBalance(BalanceType.FUNDED_COMMITMENT, DAY2, -3.0, basis);
      expectedSchedule.addNewBalance(BalanceType.FUNDED_COMMITMENT, DAY3, -303.0, basis);
      expectedSchedule.addNewBalance(BalanceType.FUNDED_COMMITMENT, DAY4, -3303.0, basis);

      expectedSchedule.addNewBalance(
          BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, DAY1, 2.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, DAY2, 2.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, DAY3, 202.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, DAY4, 2202.0, basis);

      expectedSchedule.addNewBalance(BalanceType.CUM_CONTRIBUTION, DAY1, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.CUM_CONTRIBUTION, DAY2, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.CUM_CONTRIBUTION, DAY3, 400.0, basis);
      expectedSchedule.addNewBalance(BalanceType.CUM_CONTRIBUTION, DAY4, 400.0, basis);

      expectedSchedule.addNewBalance(
          BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, DAY1, 0.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, DAY2, 0.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, DAY3, 0.0, basis);
      expectedSchedule.addNewBalance(
          BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, DAY4, 0.0, basis);

      expectedSchedule.addNewBalance(BalanceType.CUM_DISTRIBUTION, DAY1, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.CUM_DISTRIBUTION, DAY2, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.CUM_DISTRIBUTION, DAY3, 0.0, basis);
      expectedSchedule.addNewBalance(BalanceType.CUM_DISTRIBUTION, DAY4, 4000.0, basis);
    }
    BalanceScheduleKey key =
        new BalanceScheduleKey(
            ACCOUNT_ID, SECURITY.getSecurityId(), ACCOUNT, SECURITY, CALCULATED_SOURCE);
    Map<BalanceScheduleKey, BalanceSchedule> expected = Map.of(key, expectedSchedule);

    assertEquals(expected, actual);
  }

  @Test
  public void createBalanceScheduleTest() {
    Transaction BUY =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("BUY")
            .navImpact(1.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .build();
    Transaction COMMITMENT_ADJUSTMENT =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("COMMITMENT_ADJUSTMENT")
            .subType("TOTAL_COMMITMENT")
            .navImpact(10.0)
            .recallableImpact(20.0)
            .totalCommitmentImpact(30.0)
            .unfundedCommitmentImpact(30.0)
            .fundedCommitmentImpact(null)
            .cashImpact(40.0)
            .build();
    Transaction CAPC =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("CAPC")
            .navImpact(100.0)
            .recallableImpact(200.0)
            .unfundedCommitmentImpact(300.0)
            .fundedCommitmentImpact(-300.0)
            .cashImpact(400.0)
            .build();
    Transaction CAPD =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("CAPD")
            .navImpact(1000.0)
            .recallableImpact(2000.0)
            .unfundedCommitmentImpact(3000.0)
            .fundedCommitmentImpact(-3000.0)
            .cashImpact(4000.0)
            .build();
    Transaction OVERRIDE =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("GENERAL_ADJUSTMENT")
            .navImpact(10000.0)
            .recallableImpact(20000.0)
            .unfundedCommitmentImpact(30000.0)
            .fundedCommitmentImpact(-30000.0)
            .cashImpact(40000.0)
            .build();

    LocalDateRange filterRange = LocalDateRanges.create(DAY1, LocalDate.MAX);
    BalanceSchedule actual =
        balanceScheduleService.createBalanceSchedule(
            filterRange,
            DAY1,
            List.of(BUY, COMMITMENT_ADJUSTMENT, CAPC, CAPD),
            List.of(OVERRIDE),
            WATCHLIST_PERIOD,
            TransactionBasisAffects.ALL,
            true);
    BalanceSchedule expected = new BalanceSchedule();
    expected.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.REPORTED_TOTAL_COMMITMENT, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.FUNDED_COMMITMENT, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.CUM_CONTRIBUTION, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, DAY1, 0.0, "ALL");
    expected.addNewBalance(BalanceType.CUM_DISTRIBUTION, DAY1, 0.0, "ALL");

    expected.addNewBalance(BalanceType.REPORTED_ENDING_NAV, DAY2, 11110.0, "ALL");
    expected.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV, DAY2, 0.0, "ALL");
    expected.addNewBalance(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, DAY2, 1100.0, "ALL");
    expected.addNewBalance(BalanceType.REPORTED_TOTAL_COMMITMENT, DAY2, 30.0, "ALL");
    expected.addNewBalance(BalanceType.FUNDED_COMMITMENT, DAY2, -3303.0, "ALL");
    expected.addNewBalance(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, DAY2, 2222.0, "ALL");
    expected.addNewBalance(BalanceType.CUM_CONTRIBUTION, DAY2, 400.0, "ALL");
    expected.addNewBalance(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, DAY2, 0.0, "ALL");
    expected.addNewBalance(BalanceType.CUM_DISTRIBUTION, DAY2, 4000.0, "ALL");

    assertEquals(expected, actual);
  }

  @Test
  public void createBalanceSchedule_basisSpecificTest() {
    Transaction BUY =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY1)
            .entryDate(DAY1)
            .type("BUY")
            .navImpact(0.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .security(SECURITY)
            .build();

    Transaction STAT_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("STAT")
            .build();

    Transaction GAAP_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("GAAP")
            .build();

    Transaction ALL_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("ALL")
            .build();
    Map<BalanceScheduleKey, BalanceSchedule> balanceMap =
        balanceScheduleService.createBalanceMap(
            ACCOUNT_ID,
            List.of(ALL_NAV, GAAP_NAV, STAT_NAV),
            List.of(),
            List.of(BUY),
            Map.of(),
            DAY1,
            DAY2,
            CONFIGURE_DATE.minusDays(2),
            true);

    BalanceScheduleKey key =
        new BalanceScheduleKey(
            ACCOUNT_ID, SECURITY.getSecurityId(), null, SECURITY, CALCULATED_SOURCE);

    Map<BalanceTypeKey, NavigableMap<LocalDate, Double>> scheduleByType =
        balanceMap.get(key).getScheduleByType();
    Double all_nav =
        scheduleByType.get(ALL_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double stat_nav =
        scheduleByType.get(STAT_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double gaap_nav =
        scheduleByType.get(GAAP_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);

    assertEquals(STAT_NAV.getNavImpact() + ALL_NAV.getNavImpact(), stat_nav);
    assertEquals(GAAP_NAV.getNavImpact() + ALL_NAV.getNavImpact(), gaap_nav);
    assertEquals(ALL_NAV.getNavImpact(), all_nav);
  }

  @Test
  public void createBalanceSchedule_basisSpecificTest_withNoTransactionsWatchlistPeriod() {
    Transaction BUY =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY1)
            .entryDate(DAY1)
            .type("BUY")
            .navImpact(0.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .security(SECURITY)
            .build();

    Transaction STAT_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("STAT")
            .build();

    Transaction GAAP_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("GAAP")
            .build();

    Transaction ALL_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("ALL")
            .build();
    Map<BalanceScheduleKey, BalanceSchedule> balanceMap =
        balanceScheduleService.createBalanceMap(
            ACCOUNT_ID,
            List.of(ALL_NAV, GAAP_NAV, STAT_NAV),
            List.of(),
            List.of(BUY),
            WATCHLIST_PERIOD,
            DAY1,
            DAY2,
            CONFIGURE_DATE.minusDays(2),
            true);

    BalanceScheduleKey key =
        new BalanceScheduleKey(
            ACCOUNT_ID, SECURITY.getSecurityId(), null, SECURITY, CALCULATED_SOURCE);

    Map<BalanceTypeKey, NavigableMap<LocalDate, Double>> scheduleByType =
        balanceMap.get(key).getScheduleByType();
    Double all_nav =
        scheduleByType.get(ALL_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double stat_nav =
        scheduleByType.get(STAT_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double gaap_nav =
        scheduleByType.get(GAAP_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);

    assertEquals(0.0, stat_nav);
    assertEquals(0.0, gaap_nav);
    assertEquals(0.0, all_nav);
  }

  @Test
  public void createBalanceSchedule_basisSpecificTest_withTransactionsInWatchlistPeriod() {
    Transaction BUY =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY1)
            .entryDate(DAY1)
            .type("BUY")
            .navImpact(0.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .security(SECURITY)
            .build();

    Transaction STAT_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("STAT")
            .build();

    Transaction GAAP_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("GAAP")
            .build();

    Transaction WATCHLIST_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .subType("WATCHLIST")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("ALL")
            .build();
    Map<BalanceScheduleKey, BalanceSchedule> balanceMap =
        balanceScheduleService.createBalanceMap(
            ACCOUNT_ID,
            List.of(WATCHLIST_NAV, GAAP_NAV, STAT_NAV),
            List.of(),
            List.of(BUY),
            WATCHLIST_PERIOD,
            DAY1,
            DAY2,
            CONFIGURE_DATE.minusDays(2),
            true);

    BalanceScheduleKey key =
        new BalanceScheduleKey(
            ACCOUNT_ID, SECURITY.getSecurityId(), null, SECURITY, CALCULATED_SOURCE);

    Map<BalanceTypeKey, NavigableMap<LocalDate, Double>> scheduleByType =
        balanceMap.get(key).getScheduleByType();
    Double all_nav =
        scheduleByType.get(ALL_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double stat_nav =
        scheduleByType.get(STAT_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double gaap_nav =
        scheduleByType.get(GAAP_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);

    assertEquals(WATCHLIST_NAV.getNavImpact(), stat_nav);
    assertEquals(WATCHLIST_NAV.getNavImpact(), gaap_nav);
    assertEquals(WATCHLIST_NAV.getNavImpact(), all_nav);
  }

  @Test
  public void createBalanceSchedule_basisSpecificTest_withNoWatchlistTransactionsWatchlistPeriod() {
    Transaction BUY =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY1)
            .entryDate(DAY1)
            .type("BUY")
            .navImpact(0.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .security(SECURITY)
            .build();

    Transaction WATCHLIST_NAV =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .settleDate(DAY2)
            .type("NAV")
            .subType("NAV")
            .navImpact(100.0)
            .security(SECURITY)
            .basisAffect("ALL")
            .build();
    Map<BalanceScheduleKey, BalanceSchedule> balanceMap =
        balanceScheduleService.createBalanceMap(
            ACCOUNT_ID,
            List.of(WATCHLIST_NAV),
            List.of(),
            List.of(BUY),
            WATCHLIST_PERIOD,
            DAY1,
            DAY2,
            CONFIGURE_DATE.minusDays(2),
            true);

    BalanceScheduleKey key =
        new BalanceScheduleKey(
            ACCOUNT_ID, SECURITY.getSecurityId(), null, SECURITY, CALCULATED_SOURCE);

    Map<BalanceTypeKey, NavigableMap<LocalDate, Double>> scheduleByType =
        balanceMap.get(key).getScheduleByType();
    Double all_nav =
        scheduleByType.get(ALL_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double stat_nav =
        scheduleByType.get(STAT_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);
    Double gaap_nav =
        scheduleByType.get(GAAP_NAV_SCHEDULE).values().stream().reduce(0.0, Double::sum);

    assertEquals(0.0, stat_nav);
    assertEquals(0.0, gaap_nav);
    assertEquals(0.0, all_nav);
  }

  @Test
  public void test_isPositionClosed_returns_false_if_no_transactions() {
    assertFalse(balanceScheduleService.isPositionClosed(List.of(), DAY1));
  }

  @Test
  public void test_isPositionClosed_returns_false_if_date_is_same() {
    Transaction transaction = mock(Transaction.class);
    when(transaction.getSettleDate()).thenReturn(DAY1);
    assertFalse(balanceScheduleService.isPositionClosed(List.of(transaction), DAY1));
  }

  @Test
  public void test_isPositionClosed_returns_true_if_transaction_type_is_sell() {
    Transaction transaction = mock(Transaction.class);
    when(transaction.getSettleDate()).thenReturn(DAY1);
    when(transaction.getType()).thenReturn("SELL");
    assertTrue(balanceScheduleService.isPositionClosed(List.of(transaction), DAY2));
  }

  @Test
  public void test_isPositionClosed_returns_false_if_transaction_type_is_not_sell_or_trno() {
    Transaction transaction = mock(Transaction.class);
    when(transaction.getSettleDate()).thenReturn(DAY1);
    when(transaction.getType()).thenReturn("BUY");
    assertFalse(balanceScheduleService.isPositionClosed(List.of(transaction), DAY2));
  }

  @Test
  public void test_isPositionClosed_returns_false_if_initial_nav_is_zero() {
    Transaction transaction1 = mock(Transaction.class);
    when(transaction1.getSettleDate()).thenReturn(DAY1);
    when(transaction1.getType()).thenReturn("BUY");
    when(transaction1.getNavImpact()).thenReturn(0.0);
    Transaction transaction2 = mock(Transaction.class);
    when(transaction2.getSettleDate()).thenReturn(DAY2);
    when(transaction2.getType()).thenReturn("TRNO");
    when(transaction2.getNavImpact()).thenReturn(-1.0);
    assertFalse(balanceScheduleService.isPositionClosed(List.of(transaction1, transaction2), DAY3));
  }

  @Test
  public void test_isPositionClosed_returns_false_if_trno_nav_is_zero() {
    Transaction transaction1 = mock(Transaction.class);
    when(transaction1.getSettleDate()).thenReturn(DAY1);
    when(transaction1.getType()).thenReturn("BUY");
    when(transaction1.getNavImpact()).thenReturn(1.0);
    Transaction transaction2 = mock(Transaction.class);
    when(transaction2.getSettleDate()).thenReturn(DAY2);
    when(transaction2.getType()).thenReturn("TRNO");
    when(transaction2.getNavImpact()).thenReturn(0.0);
    assertFalse(balanceScheduleService.isPositionClosed(List.of(transaction1, transaction2), DAY3));
  }

  @Test
  public void test_isPositionClosed_returns_true_if_trno_nav_equals_initial_nav() {
    Transaction transaction1 = mock(Transaction.class);
    when(transaction1.getSettleDate()).thenReturn(DAY1);
    when(transaction1.getType()).thenReturn("BUY");
    when(transaction1.getNavImpact()).thenReturn(1.0);
    Transaction transaction2 = mock(Transaction.class);
    when(transaction2.getSettleDate()).thenReturn(DAY2);
    when(transaction2.getType()).thenReturn("TRNO");
    when(transaction2.getNavImpact()).thenReturn(-1.0);
    assertTrue(balanceScheduleService.isPositionClosed(List.of(transaction1, transaction2), DAY3));
  }

  @Test
  public void test_isPositionClosed_returns_false_if_trno_nav_does_not_equal_initial_nav() {
    Transaction transaction1 = mock(Transaction.class);
    when(transaction1.getSettleDate()).thenReturn(DAY1);
    when(transaction1.getType()).thenReturn("BUY");
    when(transaction1.getNavImpact()).thenReturn(2.0);
    Transaction transaction2 = mock(Transaction.class);
    when(transaction2.getSettleDate()).thenReturn(DAY2);
    when(transaction2.getType()).thenReturn("TRNO");
    when(transaction2.getNavImpact()).thenReturn(-1.0);
    assertFalse(balanceScheduleService.isPositionClosed(List.of(transaction1, transaction2), DAY3));
  }
}
