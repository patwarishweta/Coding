package com.cwan.privatefund.fxrate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import java.time.LocalDate;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class AverageFxRateCalculatorTest {

  @Mock private FxServiceApacheClient fxServiceClient;
  private AverageFxRateCalculator averageFxRateCalculator;
  private static final Long SOURCE_ID = 1L;
  private static final Long BASE_CURRENCY_ID = 2L;
  private static final Long LOCAL_CURRENCY_ID = 3L;
  private static final ReportingFrequency REPORTING_FREQUENCY = ReportingFrequency.MONTHLY;
  private static final LocalDate START_DATE = LocalDate.of(2023, 11, 1);
  private static final LocalDate HALFWAY_DATE = LocalDate.of(2023, 11, 15);
  private static final LocalDate END_DATE = LocalDate.of(2023, 11, 30);

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    this.averageFxRateCalculator = new AverageFxRateCalculator(fxServiceClient);
  }

  @Test
  void test_calculate_average_fx_rate() {
    mockBaseFxRateMap();
    mockLocalFxRateMap();
    FXRate actual =
        averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID, BASE_CURRENCY_ID, LOCAL_CURRENCY_ID, REPORTING_FREQUENCY, END_DATE);
    assertEquals(0.75, actual.getAverageFxRate());
    assertEquals(0.5, actual.getFxRate());
    assertEquals(SOURCE_ID, actual.getFxRateSourceId());
    assertEquals(BASE_CURRENCY_ID, actual.getBaseCurrencyId());
    assertEquals(LOCAL_CURRENCY_ID, actual.getLocalCurrencyId());
    assertEquals(REPORTING_FREQUENCY, actual.getReportingFrequency());
    assertEquals(END_DATE, actual.getDate());
  }

  @Test
  void test_calculate_average_fx_rate_empty_base_map() {
    mockEmptyBaseFxRateMap();
    mockLocalFxRateMap();
    FXRate actual =
        averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID, BASE_CURRENCY_ID, LOCAL_CURRENCY_ID, REPORTING_FREQUENCY, END_DATE);
    assertNull(actual);
  }

  @Test
  void test_calculate_average_fx_rate_empty_local_map() {
    mockBaseFxRateMap();
    mockEmptyLocalFxRateMap();
    FXRate actual =
        averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID, BASE_CURRENCY_ID, LOCAL_CURRENCY_ID, REPORTING_FREQUENCY, END_DATE);
    assertNull(actual);
  }

  private void mockEmptyBaseFxRateMap() {
    when(fxServiceClient.getFxRateMap(
            START_DATE.minusDays(1), END_DATE, SOURCE_ID, BASE_CURRENCY_ID))
        .thenReturn(new TreeMap<>());
  }

  private void mockEmptyLocalFxRateMap() {
    when(fxServiceClient.getFxRateMap(
            START_DATE.minusDays(1), END_DATE, SOURCE_ID, LOCAL_CURRENCY_ID))
        .thenReturn(new TreeMap<>());
  }

  private void mockBaseFxRateMap() {
    TreeMap<LocalDate, Double> baseFxRates = new TreeMap<>();
    baseFxRates.put(START_DATE, 0.44);
    baseFxRates.put(HALFWAY_DATE, 0.22);
    when(fxServiceClient.getFxRateMap(
            START_DATE.minusDays(1), END_DATE, SOURCE_ID, BASE_CURRENCY_ID))
        .thenReturn(baseFxRates);
  }

  private void mockLocalFxRateMap() {
    TreeMap<LocalDate, Double> localFxRates = new TreeMap<>();
    localFxRates.put(START_DATE, 0.44);
    when(fxServiceClient.getFxRateMap(
            START_DATE.minusDays(1), END_DATE, SOURCE_ID, LOCAL_CURRENCY_ID))
        .thenReturn(localFxRates);
  }
}
