package com.cwan.privatefund.calculated;

import static com.cwan.lpx.domain.ConfigAttributes.TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE;
import static com.cwan.privatefund.calculated.CalculatedBalanceService.MIN_DATE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.accountconfig.AccountConfigServiceClient;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient;
import com.cwan.privatefund.pricing.PricingOverrideService;
import com.cwan.privatefund.transaction.LpxTransactionService;
import com.cwan.privatefund.transaction.model.NavSchedules;
import com.cwan.privatefund.util.DateUtils;
import com.cwan.privatefund.watchlist.WatchlistService;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.ActiveProfiles;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest
@ActiveProfiles("ci")
class CalculatedBalanceServiceTest {

  @MockBean private AccountConfigServiceClient accountConfigServiceClient;
  @MockBean private LpxTransactionService lpxTransactionService;
  @MockBean private PricingOverrideService pricingOverrideService;
  @MockBean private BusinessWSClient businessWSClient;
  @MockBean private WatchlistService watchlistService;
  @MockBean private PortfolioWsApacheClient portfolioService;
  @MockBean private RedisTemplate<String, Object> redisTemplate;
  @Mock private HashOperations<String, Object, Object> hashOperations;
  @Autowired CalculatedBalanceService calculatedBalanceService;

  private final AccountConfigServiceCache accountConfigServiceCache =
      mock(AccountConfigServiceCache.class);
  private static final Account ACCOUNT = Account.builder().id(1L).build();
  private static final Security SECURITY =
      Security.builder().securityId(2L).currency(Currency.builder().code("USD").build()).build();
  private static final LocalDate CONFIGURE_DATE = LocalDate.of(2021, 12, 2);
  private static final LocalDate BEGIN_DATE = LocalDate.of(2022, 1, 1);
  private static final LocalDate END_DATE = LocalDate.of(2022, 1, 2);
  private static final LocalDate KNOWLEDGE_AS_OF = LocalDate.of(2022, 2, 28);
  private static final AccountConfig ACCOUNT_CONFIG =
      AccountConfig.builder()
          .account(ACCOUNT)
          .subscriptionStartDate(CONFIGURE_DATE)
          .subscriptionEndDate(LocalDate.of(9999, 1, 1))
          .attributes(Map.of(TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE.toString(), MIN_DATE.toString()))
          .build();
  private static final Transaction TRANSACTION_BUY_NO_AFFECTS = createTransactionBUY();
  private static final Transaction TRANSACTION_CAPC = createTransactionCAPC();
  private static final Transaction TRANSACTION_NAV_OVERRIDE = createTransactionNAV_OVERRIDE();
  private static final Transaction TRANSACTION_NAV = createTransactionNAV_ADJUSTMENT();
  private static final Transaction TRANSACTION_ECONOMIC_NAV = createTransactionNAV_ECONOMICS();
  private static final Transaction TRANSACTION_WATCHLIST_NAV = createTransactionWATCHLIST_NAV();
  private static final WatchlistEntity WATCHLIST_ENTITY =
      WatchlistEntity.builder()
          .accountId(1L)
          .securityId(2L)
          .startDate(END_DATE.minusMonths(2))
          .endDate(END_DATE.plusMonths(2))
          .build();
  private static final Map<Long, Set<WatchlistEntity>> WATCHLIST_PERIOD =
      Map.of(1L, Set.of(WATCHLIST_ENTITY));

  @BeforeAll
  static void beforeAll() {
    System.setProperty("DEVELOPER_WORKSTATION", "true");
    System.setProperty("app/common/jwt_secret", "secret");
    System.setProperty("env", "ci");
  }

  private void resetMocks() {
    reset(
        accountConfigServiceClient,
        lpxTransactionService,
        pricingOverrideService,
        businessWSClient,
        watchlistService);
  }

  @BeforeEach
  void beforeEach() {
    resetMocks();
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
    when(businessWSClient.getExpandedAccountIds(ACCOUNT.getId()))
        .thenReturn(Mono.just(List.of(ACCOUNT.getId())));
    when(lpxTransactionService.getOpeningTransactions(any()))
        .thenReturn(List.of(TRANSACTION_BUY_NO_AFFECTS));
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any()))
        .thenReturn(List.of(TRANSACTION_NAV_OVERRIDE));
    when(portfolioService.getLotEffectiveRangeMap(any(), any())).thenReturn(Map.of());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void should_handle_economic_nav_transactions_correctly(boolean forAccounting) {
    whenGetTransactionsForCalculatingBalances(
        List.of(TRANSACTION_ECONOMIC_NAV, TRANSACTION_NAV, TRANSACTION_CAPC));
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any())).thenReturn(List.of());
    when(lpxTransactionService.getNavTransactions(
            eq(List.of(ACCOUNT.getId())), any(), eq(END_DATE), eq(KNOWLEDGE_AS_OF)))
        .thenReturn(Flux.just(TRANSACTION_ECONOMIC_NAV, TRANSACTION_NAV));
    when(watchlistService.getActiveWatchlistSecurities(any(), any(), any())).thenReturn(List.of());
    when(hashOperations.get(eq("Account"), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    List<CalculatedBalance> calculatedBalanceList =
        calculatedBalanceService
            .calculateBalances(ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, forAccounting)
            .collectList()
            .share()
            .block();
    assertEquals(1, calculatedBalanceList.size());

    double expectedNavImpact =
        forAccounting
            ? TRANSACTION_NAV.getNavImpact() + TRANSACTION_CAPC.getNavImpact()
            : TRANSACTION_NAV.getNavImpact()
                + TRANSACTION_CAPC.getNavImpact()
                + TRANSACTION_ECONOMIC_NAV.getNavImpact();
    assertEquals(expectedNavImpact, calculatedBalanceList.get(0).getNavImpact());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void should_handle_watchlist_nav_transactions_correctly(boolean forAccounting) {
    whenGetTransactionsForCalculatingBalances(
        List.of(TRANSACTION_WATCHLIST_NAV, TRANSACTION_NAV, TRANSACTION_CAPC));
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any())).thenReturn(List.of());
    when(lpxTransactionService.getNavTransactions(
            eq(List.of(ACCOUNT.getId())), any(), eq(END_DATE), eq(KNOWLEDGE_AS_OF)))
        .thenReturn(Flux.just(TRANSACTION_WATCHLIST_NAV, TRANSACTION_NAV));
    when(watchlistService.getActiveWatchlistSecuritiesByAccount(any(), any(), any()))
        .thenReturn(WATCHLIST_PERIOD);
    when(hashOperations.get(eq("Account"), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    List<CalculatedBalance> calculatedBalanceList =
        calculatedBalanceService
            .calculateBalances(ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, forAccounting)
            .collectList()
            .share()
            .block();
    assertEquals(1, calculatedBalanceList.size());

    double expectedWatchlistNavImpact =
        TRANSACTION_WATCHLIST_NAV.getNavImpact() + TRANSACTION_CAPC.getNavImpact();

    // WATCHLIST NAV is never included in this calculation
    double expectedNavImpact = TRANSACTION_NAV.getNavImpact() + TRANSACTION_CAPC.getNavImpact();

    // we don't expect TRANSACTION_NAV to be included as it is INSIDE the watchlist nav period
    double expectedWatchlistNav =
        TRANSACTION_WATCHLIST_NAV.getNavImpact() + TRANSACTION_CAPC.getNavImpact();
    assertEquals(expectedWatchlistNavImpact, calculatedBalanceList.get(0).getWatchlistNavImpact());
    assertEquals(expectedWatchlistNav, calculatedBalanceList.get(0).getWatchlistNavImpact());
    assertEquals(expectedNavImpact, calculatedBalanceList.get(0).getNavImpact());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void should_handle_inactive_watchlist_nav_transactions_correctly(boolean forAccounting) {
    whenGetTransactionsForCalculatingBalances(
        List.of(TRANSACTION_WATCHLIST_NAV, TRANSACTION_NAV, TRANSACTION_CAPC));
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any())).thenReturn(List.of());
    when(lpxTransactionService.getNavTransactions(
            eq(List.of(ACCOUNT.getId())), any(), eq(END_DATE), eq(KNOWLEDGE_AS_OF)))
        .thenReturn(Flux.just(TRANSACTION_WATCHLIST_NAV, TRANSACTION_NAV));
    when(watchlistService.getActiveWatchlistSecuritiesByAccount(any(), any(), any()))
        .thenReturn(Map.of());
    when(hashOperations.get(eq("Account"), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    List<CalculatedBalance> calculatedBalanceList =
        calculatedBalanceService
            .calculateBalances(ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, forAccounting)
            .collectList()
            .share()
            .block();

    StepVerifier.create(
            calculatedBalanceService
                .calculateBalances(ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, forAccounting)
                .collectList())
        .expectNextMatches(x -> x.size() == 1)
        .verifyComplete();

    double expectedNavImpact = TRANSACTION_NAV.getNavImpact() + TRANSACTION_CAPC.getNavImpact();
    assertEquals(32.0, calculatedBalanceList.get(0).getWatchlistNavImpact());
    assertEquals(expectedNavImpact, calculatedBalanceList.get(0).getNavImpact());
  }

  @Test
  void should_handle_no_transactions() {
    whenGetTransactionsForCalculatingBalances(List.of());
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any())).thenReturn(List.of());
    Flux<CalculatedBalance> actual =
        calculatedBalanceService.calculateBalances(
            ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, false);
    assertEquals(List.of(), actual.collectList().share().block());
  }

  @Test
  void should_handle_no_account_config() {
    whenGetTransactionsForCalculatingBalances(List.of(TRANSACTION_BUY_NO_AFFECTS));
    when(accountConfigServiceCache.getAccountConfigs(any(), any()))
        .thenReturn(Mono.just(List.of(AccountConfig.builder().build())));
    Flux<CalculatedBalance> actual =
        calculatedBalanceService.calculateBalances(
            ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, false);
    StepVerifier.create(actual.collectList()).expectNext(List.of()).verifyComplete();
  }

  @Test
  void should_calculate_balances_for_cash_txn() {
    whenGetTransactionsForCalculatingBalances(List.of(TRANSACTION_BUY_NO_AFFECTS));
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any())).thenReturn(List.of());
    when(watchlistService.getActiveWatchlistSecurities(any(), any(), any())).thenReturn(List.of());
    when(accountConfigServiceCache.getAccountConfigs(any(), any()))
        .thenReturn(Mono.just(List.of(AccountConfig.builder().build())));
    when(hashOperations.get(eq("Account"), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    Flux<CalculatedBalance> actual =
        calculatedBalanceService.calculateBalances(
            ACCOUNT.getId(), END_DATE, KNOWLEDGE_AS_OF, false);
    StepVerifier.create(actual).expectNextCount(1).verifyComplete();

    CalculatedBalance expected =
        CalculatedBalance.builder()
            .source(TRANSACTION_BUY_NO_AFFECTS.getSource())
            .security(TRANSACTION_BUY_NO_AFFECTS.getSecurity())
            .account(TRANSACTION_BUY_NO_AFFECTS.getAccount())
            .currency(TRANSACTION_BUY_NO_AFFECTS.getCurrency())
            .navImpact(0.0)
            .gaapNavImpact(0.0)
            .statNavImpact(0.0)
            .watchlistNavImpact(0.0)
            .fundedCommitmentImpact(0.0)
            .unfundedCommitmentImpact(0.0)
            .totalCommitment(0.0)
            .recallableImpact(0.0)
            .totalContributions(0.0)
            .totalDistributions(0.0)
            .build();

    StepVerifier.create(actual.collectList()).expectNext(List.of(expected)).verifyComplete();
  }

  @Test
  void getNavSchedule_for_accounting_test() {
    whenGetTransactionsForCalculatingBalances(List.of(TRANSACTION_BUY_NO_AFFECTS, TRANSACTION_NAV));
    when(pricingOverrideService.getPricingOverrideTransactions(any(), any())).thenReturn(List.of());
    when(lpxTransactionService.getNavTransactions(
            List.of(ACCOUNT.getId()), BEGIN_DATE, END_DATE, KNOWLEDGE_AS_OF))
        .thenReturn(Flux.just(TRANSACTION_NAV));
    when(watchlistService.getActiveWatchlistSecurities(any(), any(), any())).thenReturn(List.of());
    when(hashOperations.get(eq("Account"), any())).thenReturn(List.of(ACCOUNT_CONFIG));

    NavigableMap<LocalDate, Double> navSchedule = new TreeMap<>();
    navSchedule.put(BEGIN_DATE, 0.0);
    navSchedule.put(TRANSACTION_NAV.getSettleDate(), TRANSACTION_NAV.getNavImpact());
    NavSchedules expected =
        NavSchedules.builder()
            .accountId(ACCOUNT.getId())
            .securityId(2L)
            .navSchedule(navSchedule)
            .gaapNavSchedule(navSchedule)
            .statNavSchedule(navSchedule)
            .build();

    Flux<NavSchedules> actual =
        calculatedBalanceService.getNavSchedule(
            ACCOUNT.getId(), BEGIN_DATE, END_DATE, KNOWLEDGE_AS_OF, true);
    StepVerifier.create(actual)
        .assertNext(response -> assertEquals(2, response.getNavSchedule().size()))
        .verifyComplete();
    assertEquals(List.of(expected), actual.collectList().share().block());
  }

  private static long tranId = 100L;

  private static long getTranId() {
    tranId += 1L;
    return tranId;
  }

  private static Transaction createTransactionBUY() {
    return Transaction.builder()
        .id(getTranId())
        .account(ACCOUNT)
        .security(SECURITY)
        .source("test")
        .currency("USD")
        .isCurrent(true)
        .settleDate(END_DATE.minusDays(1))
        .entryDate(END_DATE.minusDays(1))
        .knowledgeStartDate(DateUtils.atEndOfDay(KNOWLEDGE_AS_OF))
        .type("BUY")
        .isHistoric(Boolean.FALSE)
        .build();
  }

  private static Transaction createTransactionCAPC() {
    return Transaction.builder()
        .id(getTranId())
        .account(ACCOUNT)
        .security(SECURITY)
        .source("test")
        .currency("USD")
        .isCurrent(true)
        .settleDate(END_DATE.minusDays(1))
        .entryDate(END_DATE.minusDays(1))
        .knowledgeStartDate(DateUtils.atEndOfDay(KNOWLEDGE_AS_OF))
        .type("CAPC")
        .subType("INVESTMENTS")
        .navImpact(10.0)
        .cashImpact(100.0)
        .isHistoric(Boolean.FALSE)
        .build();
  }

  private static Transaction createTransactionNAV_OVERRIDE() {
    return Transaction.builder()
        .id(getTranId())
        .account(ACCOUNT)
        .security(SECURITY)
        .source("test")
        .currency("USD")
        .isCurrent(true)
        .settleDate(END_DATE.minusDays(1))
        .entryDate(END_DATE.minusDays(1))
        .type("NAV")
        .subType("INVESTMENTS")
        .navImpact(10.0)
        .isHistoric(Boolean.FALSE)
        .build();
  }

  private static Transaction createTransactionNAV_ADJUSTMENT() {
    return Transaction.builder()
        .id(getTranId())
        .account(ACCOUNT)
        .security(SECURITY)
        .source("test")
        .currency("USD")
        .isCurrent(true)
        .settleDate(END_DATE)
        .entryDate(END_DATE.minusDays(4))
        .knowledgeStartDate(DateUtils.atEndOfDay(KNOWLEDGE_AS_OF))
        .type("NAV")
        .navImpact(22.0)
        .isHistoric(Boolean.FALSE)
        .build();
  }

  private static Transaction createTransactionNAV_ECONOMICS() {
    return Transaction.builder()
        .id(getTranId())
        .account(ACCOUNT)
        .security(SECURITY)
        .source("test")
        .currency("USD")
        .isCurrent(true)
        .settleDate(END_DATE)
        .entryDate(END_DATE.minusDays(4))
        .knowledgeStartDate(DateUtils.atEndOfDay(KNOWLEDGE_AS_OF))
        .type("NAV")
        .subType("ECONOMIC_NAV")
        .navImpact(22.0)
        .isHistoric(Boolean.FALSE)
        .build();
  }

  private static Transaction createTransactionWATCHLIST_NAV() {
    return Transaction.builder()
        .id(getTranId())
        .account(ACCOUNT)
        .security(SECURITY)
        .source("test")
        .currency("USD")
        .isCurrent(true)
        .settleDate(END_DATE)
        .entryDate(END_DATE)
        .knowledgeStartDate(DateUtils.atEndOfDay(KNOWLEDGE_AS_OF))
        .type("NAV")
        .subType("WATCHLIST")
        .navImpact(6.0)
        .isHistoric(Boolean.FALSE)
        .build();
  }

  private void whenGetTransactionsForCalculatingBalances(List<Transaction> transactions) {
    when(lpxTransactionService.getTransactionsForCalculatingBalances(
            any(), any(), any(), any(), any(), anyBoolean()))
        .thenReturn(Mono.just(transactions));
  }
}
