package com.cwan.privatefund.accountconfig;

import static com.cwan.privatefund.TestUtil.getAccountConfig;
import static com.cwan.privatefund.constant.RedisConstants.ACCOUNT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import reactor.test.StepVerifier;

class AccountConfigServiceCacheTest {

  @Mock RedisTemplate redisTemplate;
  @Mock private HashOperations hashOperations;
  private static final AccountConfig ACCOUNT_CONFIG = getAccountConfig();
  private static final Long ACCOUNT_ID = 42L;
  private AccountConfigServiceCache instance;

  @BeforeEach
  void beforeEach() {
    MockitoAnnotations.openMocks(this);
    this.instance = new AccountConfigServiceCache(redisTemplate);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
  }

  @Test
  void should_get_account_config_by_account_id_from_cache() {
    when(hashOperations.get(eq(ACCOUNT), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    var actual = instance.getByAccountId(ACCOUNT_ID).block();
    assertEquals(ACCOUNT_CONFIG, actual);
  }

  @Test
  void get_account_config_should_filter_inactive_accounts() {
    var inactiveConfig = getAccountConfig();
    inactiveConfig.setSubscriptionEndDate(LocalDate.now().minusDays(1));
    when(hashOperations.get(eq(ACCOUNT), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    var actual = instance.getByAccountId(ACCOUNT_ID).block();
    assertEquals(ACCOUNT_CONFIG, actual);
  }

  @Test
  void get_account_configs_should_thow_error_for_multiple_configs_with_same_account_id() {
    when(hashOperations.get(eq(ACCOUNT), any())).thenThrow(AccountConfigServiceException.class);
    assertThrows(
        AccountConfigServiceException.class,
        () ->
            instance.getAccountConfigs(List.of(ACCOUNT_ID, 2L), LocalDate.of(2024, 1, 1)).block());
  }

  @Test
  void get_account_configs_in_batches() {
    when(hashOperations.get(eq(ACCOUNT), any())).thenReturn(List.of(ACCOUNT_CONFIG));
    StepVerifier.create(instance.getAccountConfigs(List.of(ACCOUNT_ID, 2L), LocalDate.now()))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void testGetAllAccountsWithConfig() {
    Set<Long> accountIds = Set.of(1L, 2L, 3L);
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    Account account3 = Account.builder().id(3L).build();
    AccountConfig config1 =
        AccountConfig.builder()
            .account(account1)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "false"))
            .build();
    AccountConfig config3 =
        AccountConfig.builder()
            .account(account3)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    AccountConfig config4 =
        AccountConfig.builder()
            .account(Account.builder().build())
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    when(redisTemplate.opsForHash().values(ACCOUNT))
        .thenReturn(List.of(config1, config2, config3, config4));
    Set<Long> result = instance.getAllAccountsWithAttribute(accountIds, booleanConfigName);
    Set<Long> expected = Set.of();
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_emptySet() {
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    Account account3 = Account.builder().id(3L).build();
    AccountConfig config1 =
        AccountConfig.builder()
            .account(account1)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "false"))
            .build();
    AccountConfig config3 =
        AccountConfig.builder()
            .account(account3)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(List.of(config1, config2, config3));
    Set<Long> result = instance.getAllAccountsWithAttribute(Set.of(), booleanConfigName);
    Set<Long> expected = Set.of();
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_null() {
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    Account account3 = Account.builder().id(3L).build();
    AccountConfig config1 =
        AccountConfig.builder()
            .account(account1)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "false"))
            .build();
    AccountConfig config3 =
        AccountConfig.builder()
            .account(account3)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(List.of(config1, config2, config3));
    Set<Long> result = instance.getAllAccountsWithAttribute(null, booleanConfigName);
    Set<Long> expected = Set.of();
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_withNullAttributes() {
    Set<Long> accountIds = Set.of(1L, 2L);
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    AccountConfig config1 = AccountConfig.builder().account(account1).attributes(null).build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    List<List<AccountConfig>> redisResponse = List.of(List.of(config1), List.of(config2));
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(redisResponse);
    Set<Long> result = instance.getAllAccountsWithAttribute(accountIds, booleanConfigName);
    Set<Long> expected = Set.of(2L);
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_withNullAttribute() {
    Set<Long> accountIds = Set.of(1L, 2L);
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    Map<String, String> attributesWithNull = new HashMap<>();
    attributesWithNull.put(booleanConfigName, null);
    AccountConfig config1 =
        AccountConfig.builder().account(account1).attributes(attributesWithNull).build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    List<List<AccountConfig>> redisResponse = List.of(List.of(config1), List.of(config2));
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(redisResponse);
    Set<Long> result = instance.getAllAccountsWithAttribute(accountIds, booleanConfigName);
    Set<Long> expected = Set.of(2L);
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_withInvalidBooleanValue() {
    Set<Long> accountIds = Set.of(1L, 2L);
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    AccountConfig config1 =
        AccountConfig.builder()
            .account(account1)
            .attributes(Map.of(booleanConfigName, "invalid"))
            .build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    List<List<AccountConfig>> redisResponse = List.of(List.of(config1), List.of(config2));
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(redisResponse);
    Set<Long> result = instance.getAllAccountsWithAttribute(accountIds, booleanConfigName);
    Set<Long> expected = Set.of(2L);
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_loadAllAccounts() {
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    Account account2 = Account.builder().id(2L).build();
    AccountConfig config1 =
        AccountConfig.builder()
            .account(account1)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    AccountConfig config2 =
        AccountConfig.builder()
            .account(account2)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    List<List<AccountConfig>> redisResponse = List.of(List.of(config1), List.of(config2));
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(redisResponse);
    Set<Long> result = instance.getAllAccountsWithAttribute(null, booleanConfigName);
    Set<Long> expected = Set.of(1L, 2L);
    assertEquals(expected, result);
  }

  @Test
  void testGetAllAccountsWithConfig_withNullAccount() {
    Set<Long> accountIds = Set.of(1L, 2L);
    String booleanConfigName = "enabled";
    Account account1 = Account.builder().id(1L).build();
    AccountConfig config1 =
        AccountConfig.builder()
            .account(account1)
            .attributes(Map.of(booleanConfigName, "true"))
            .build();
    AccountConfig config2 =
        AccountConfig.builder().account(null).attributes(Map.of(booleanConfigName, "true")).build();
    List<List<AccountConfig>> redisResponse = List.of(List.of(config1), List.of(config2));
    when(redisTemplate.opsForHash().values(ACCOUNT)).thenReturn(redisResponse);
    Set<Long> result = instance.getAllAccountsWithAttribute(accountIds, booleanConfigName);
    Set<Long> expected = Set.of(1L);
    assertEquals(expected, result);
  }
}
