package com.cwan.privatefund.documentmanager.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.privatefund.documentmanager.DocumentUploadFileDetails;
import com.cwan.privatefund.documentmanager.DocumentUploadStatus;
import java.util.List;
import org.junit.jupiter.api.Test;

class DocumentUploadFailedExceptionTest {

  private static final DocumentUploadFileDetails FILE_DETAILS =
      DocumentUploadFileDetails.builder()
          .status(DocumentUploadStatus.FAILED)
          .fileName("some_file_name.pdf")
          .build();

  @Test
  void testConstructor() {
    var actual = new DocumentUploadFailedException(List.of(FILE_DETAILS));
    assertEquals(List.of(FILE_DETAILS), actual.getUploadFileDetailsList());
  }
}
