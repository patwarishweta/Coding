package com.cwan.privatefund.lihtc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.lihtc.api.LIHTCService;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.portfolio.PortfolioService;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

class LPxLIHTCServiceTest {

  private LPxLIHTCService lPxLIHTCService;
  @Mock private LIHTCService lihtcService;

  @Mock private AccountService accountService;

  @Mock private SecurityService securityService;

  @Mock private PortfolioService portfolioService;

  private static final LIHTCBenefitSchedule LIHTC_BENEFIT_SCHEDULE =
      TestUtil.getLihtcBenefitSchedule();

  private static final LIHTCTaxRate LIHTC_TAX_RATE = TestUtil.getLihtcTaxRate();

  private static final Account ACCOUNT = TestUtil.getAccount();

  private static final Security SECURITY = TestUtil.getSecurity();

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    lPxLIHTCService =
        new LPxLIHTCService(accountService, securityService, lihtcService, portfolioService);
    when(accountService.getAccountData(anyLong())).thenReturn(Mono.just(ACCOUNT));
    when(securityService.getSecurity(anyLong(), anyLong(), anyLong()))
        .thenReturn(Mono.just(SECURITY));
  }

  @Test
  void addBenefitSchedules() {
    when(lihtcService.addBenefitSchedules(List.of(LIHTC_BENEFIT_SCHEDULE)))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_BENEFIT_SCHEDULE)));

    LIHTCBenefitSchedule result =
        lPxLIHTCService.addBenefitSchedules(List.of(LIHTC_BENEFIT_SCHEDULE)).blockFirst();

    assertEquals(LIHTC_BENEFIT_SCHEDULE, result);
  }

  @Test
  void getBenefitSchedulesForAccountSecurityPair() {
    when(lihtcService.getBenefitSchedulesForAccountSecurityPair(
            ACCOUNT.getId(), SECURITY.getSecurityId()))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_BENEFIT_SCHEDULE)));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> result =
        lPxLIHTCService
            .getBenefitSchedulesForAccountSecurityPair(ACCOUNT.getId(), SECURITY.getSecurityId())
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_BENEFIT_SCHEDULE.reportingDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_BENEFIT_SCHEDULE, result.values().iterator().next().iterator().next());
  }

  @Test
  void getBenefitSchedulesForAccountSecurityReportingDate() {
    LocalDate reportingDate = LIHTC_BENEFIT_SCHEDULE.reportingDate();
    when(lihtcService.getBenefitSchedulesForAccountSecurityForReportingDate(
            ACCOUNT.getId(), SECURITY.getSecurityId(), reportingDate))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_BENEFIT_SCHEDULE)));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> result =
        lPxLIHTCService
            .getBenefitSchedulesForAccountSecurityReportingDate(
                ACCOUNT.getId(), SECURITY.getSecurityId(), reportingDate)
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_BENEFIT_SCHEDULE.reportingDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_BENEFIT_SCHEDULE, result.values().iterator().next().iterator().next());
  }

  @Test
  void deleteBenefitSchedulesForAccountSecurityTaxType() {
    when(lihtcService
            .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
                ACCOUNT.getId(),
                SECURITY.getSecurityId(),
                LIHTC_BENEFIT_SCHEDULE.reportingDate(),
                LIHTC_BENEFIT_SCHEDULE.taxType()))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_BENEFIT_SCHEDULE)));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> result =
        lPxLIHTCService
            .deleteBenefitSchedulesForAccountSecurityTaxType(
                ACCOUNT.getId(),
                SECURITY.getSecurityId(),
                LIHTC_BENEFIT_SCHEDULE.reportingDate(),
                LIHTC_BENEFIT_SCHEDULE.taxType())
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_BENEFIT_SCHEDULE.reportingDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_BENEFIT_SCHEDULE, result.values().iterator().next().iterator().next());
  }

  @Test
  void deleteBenefitSchedulesForAccountSecurityTaxTypeReportingDateScheduleDate() {
    LocalDate reportingDate = LIHTC_BENEFIT_SCHEDULE.reportingDate();
    when(lihtcService
            .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
                ACCOUNT.getId(),
                SECURITY.getSecurityId(),
                LIHTC_BENEFIT_SCHEDULE.reportingDate(),
                LIHTC_BENEFIT_SCHEDULE.taxType(),
                reportingDate))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_BENEFIT_SCHEDULE)));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> result =
        lPxLIHTCService
            .deleteBenefitSchedulesForAccountSecurityTaxTypeReportingDateScheduleDate(
                ACCOUNT.getId(),
                SECURITY.getSecurityId(),
                LIHTC_BENEFIT_SCHEDULE.reportingDate(),
                LIHTC_BENEFIT_SCHEDULE.taxType(),
                reportingDate)
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_BENEFIT_SCHEDULE.reportingDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_BENEFIT_SCHEDULE, result.values().iterator().next().iterator().next());
  }

  @Test
  void benefitScheduleResolveAccountSecurityData() {
    LIHTCBenefitSchedule result =
        lPxLIHTCService
            .benefitScheduleResolveAccountSecurityData(
                Flux.fromIterable(List.of(LIHTC_BENEFIT_SCHEDULE)))
            .blockFirst();
    assertNotNull(result);
    assertEquals(ACCOUNT, result.account());
    assertEquals(SECURITY, result.security());
  }

  @Test
  void addTaxRates() {
    when(lihtcService.addTaxRates(List.of(LIHTC_TAX_RATE)))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_TAX_RATE)));

    LIHTCTaxRate result = lPxLIHTCService.addTaxRates(List.of(LIHTC_TAX_RATE)).blockFirst();

    assertEquals(LIHTC_TAX_RATE, result);
  }

  @Test
  void getTaxRatesForAccountSecurityPair() {
    when(lihtcService.getTaxRatesForAccountSecurityPair(ACCOUNT.getId(), SECURITY.getSecurityId()))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_TAX_RATE)));

    Map<LocalDate, Collection<LIHTCTaxRate>> result =
        lPxLIHTCService
            .getTaxRatesForAccountSecurityPair(ACCOUNT.getId(), SECURITY.getSecurityId())
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_TAX_RATE.taxRateStartDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_TAX_RATE, result.values().iterator().next().iterator().next());
  }

  @Test
  void getTaxRatesForAccountSecurityForTaxType() {
    when(lihtcService.getTaxRatesForAccountSecurityForTaxType(
            ACCOUNT.getId(), SECURITY.getSecurityId(), LIHTC_TAX_RATE.taxType()))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_TAX_RATE)));

    Map<LocalDate, Collection<LIHTCTaxRate>> result =
        lPxLIHTCService
            .getTaxRatesForAccountSecurityForTaxType(
                ACCOUNT.getId(), SECURITY.getSecurityId(), LIHTC_TAX_RATE.taxType())
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_TAX_RATE.taxRateStartDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_TAX_RATE, result.values().iterator().next().iterator().next());
  }

  @Test
  void deleteTaxRatesForAccountSecurity() {
    when(lihtcService.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(
            ACCOUNT.getId(), SECURITY.getSecurityId()))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_TAX_RATE)));

    Map<LocalDate, Collection<LIHTCTaxRate>> result =
        lPxLIHTCService
            .deleteTaxRatesForAccountSecurity(ACCOUNT.getId(), SECURITY.getSecurityId())
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_TAX_RATE.taxRateStartDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_TAX_RATE, result.values().iterator().next().iterator().next());
  }

  @Test
  void deleteTaxRatesForAccountSecurityTaxType() {
    when(lihtcService.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
            ACCOUNT.getId(), SECURITY.getSecurityId(), LIHTC_TAX_RATE.taxType()))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_TAX_RATE)));

    Map<LocalDate, Collection<LIHTCTaxRate>> result =
        lPxLIHTCService
            .deleteTaxRatesForAccountSecurityTaxType(
                ACCOUNT.getId(), SECURITY.getSecurityId(), LIHTC_TAX_RATE.taxType())
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_TAX_RATE.taxRateStartDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_TAX_RATE, result.values().iterator().next().iterator().next());
  }

  @Test
  void deleteTaxRatesForAccountSecurityTaxTypeTaxRateStartDate() {
    LocalDate taxRateStartDate = LIHTC_TAX_RATE.taxRateStartDate();
    when(lihtcService
            .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
                ACCOUNT.getId(),
                SECURITY.getSecurityId(),
                LIHTC_TAX_RATE.taxType(),
                taxRateStartDate))
        .thenReturn(Flux.fromIterable(List.of(LIHTC_TAX_RATE)));

    Map<LocalDate, Collection<LIHTCTaxRate>> result =
        lPxLIHTCService
            .deleteTaxRatesForAccountSecurityTaxTypeTaxRateStartDate(
                ACCOUNT.getId(),
                SECURITY.getSecurityId(),
                LIHTC_TAX_RATE.taxType(),
                taxRateStartDate)
            .block();
    assertNotNull(result);
    assertEquals(LIHTC_TAX_RATE.taxRateStartDate(), result.keySet().iterator().next());
    assertEquals(LIHTC_TAX_RATE, result.values().iterator().next().iterator().next());
  }

  @Test
  void taxRateResolveAccountSecurityData() {
    LIHTCTaxRate result =
        lPxLIHTCService
            .taxRateResolveAccountSecurityData(Flux.fromIterable(List.of(LIHTC_TAX_RATE)))
            .blockFirst();
    assertNotNull(result);
    assertEquals(ACCOUNT, result.account());
    assertEquals(SECURITY, result.security());
  }

  @Test
  void test_on_next_submits_performance_task() {
    LIHTCBenefitSchedule schedule =
        LIHTCBenefitSchedule.builder()
            .account(Account.builder().id(1L).build())
            .security(Security.builder().securityId(2L).build())
            .build();
    when(lihtcService.addBenefitSchedules(anyCollection()))
        .thenReturn(
            Flux.just(
                LIHTCBenefitSchedule.builder()
                    .account(Account.builder().id(1L).build())
                    .security(Security.builder().securityId(2L).build())
                    .build()));
    lPxLIHTCService.addBenefitSchedules(List.of(schedule)).collectList().block();
    verify(portfolioService, times(1)).submitAmortCalculationTask(any(), any());
  }

  @Test
  void test_on_next_submits_deduplicate_performance_task() {
    LIHTCBenefitSchedule schedule1 =
        LIHTCBenefitSchedule.builder()
            .account(Account.builder().id(1L).build())
            .reportingDate(LocalDate.now().minusDays(1))
            .security(Security.builder().securityId(2L).build())
            .build();
    LIHTCBenefitSchedule schedule2 =
        LIHTCBenefitSchedule.builder()
            .account(Account.builder().id(1L).build())
            .reportingDate(LocalDate.now())
            .security(Security.builder().securityId(2L).build())
            .build();
    when(lihtcService.addBenefitSchedules(anyCollection()))
        .thenReturn(Flux.just(schedule1, schedule2));
    lPxLIHTCService.addBenefitSchedules(List.of(schedule1, schedule2)).collectList().block();
    verify(portfolioService, times(1)).submitAmortCalculationTask(any(), any());
  }

  @Test
  void test_on_next_submits_different_accounts_performance_task() {
    LIHTCBenefitSchedule schedule1 =
        LIHTCBenefitSchedule.builder()
            .account(Account.builder().id(1L).build())
            .reportingDate(LocalDate.now().minusDays(1))
            .security(Security.builder().securityId(2L).build())
            .build();
    LIHTCBenefitSchedule schedule2 =
        LIHTCBenefitSchedule.builder()
            .account(Account.builder().id(2L).build())
            .reportingDate(LocalDate.now())
            .security(Security.builder().securityId(2L).build())
            .build();
    when(lihtcService.addBenefitSchedules(anyCollection()))
        .thenReturn(Flux.just(schedule1, schedule2));
    lPxLIHTCService.addBenefitSchedules(List.of(schedule1, schedule2)).collectList().block();
    verify(portfolioService, times(2)).submitAmortCalculationTask(any(), any());
  }

  @Test
  void get_manual_amort_segments() {
    when(lihtcService.getSegments(anyLong(), anyLong(), anyInt()))
        .thenReturn(Set.of(TestUtil.getManualAmortSegment()));

    Set<ManualAmortSegment> segments = lPxLIHTCService.getManualAmortSegments(1L, 1L, 1);
    assertEquals(1, segments.size());
    assertEquals(TestUtil.getManualAmortSegment(), segments.iterator().next());
  }

  @Test
  void update_manual_amort_segments() {
    ManualAmortSegment manualAmortSegment = TestUtil.getManualAmortSegment();
    Set<ManualAmortSegment> segments = Set.of(manualAmortSegment);
    lPxLIHTCService.updateManualAmortSegments(segments, false);
    verify(lihtcService, times(1)).saveManualAmortSegments(segments);
    verify(portfolioService, times(1))
        .submitAmortCalculationTask(
            eq(manualAmortSegment.accountId()), eq(manualAmortSegment.securityId()));
  }

  @Test
  void update_manual_amort_segments_invalidate_existing() {
    ManualAmortSegment manualAmortSegment = TestUtil.getManualAmortSegment();
    Set<ManualAmortSegment> segments = Set.of(manualAmortSegment);

    when(lihtcService.getSegments(anyLong(), anyLong(), anyInt()))
        .thenReturn(Set.of(ManualAmortSegment.builder().accountId(1L).isActive(true).build()));
    lPxLIHTCService.updateManualAmortSegments(segments, true);

    // 1 to delete, 1 to save
    verify(lihtcService, times(2)).saveManualAmortSegments(any());
    verify(portfolioService, times(1))
        .submitAmortCalculationTask(
            eq(manualAmortSegment.accountId()), eq(manualAmortSegment.securityId()));
  }
}
