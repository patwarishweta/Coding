package com.cwan.privatefund.feature;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.MockitoAnnotations.openMocks;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FeatureFlagsWSClientTest {

  private static TestHttpClient testClient = new TestHttpClient();
  private static Cache<String, FeatureResponse> cache =
      CacheBuilder.newBuilder().maximumSize(1000).expireAfterWrite(60, TimeUnit.SECONDS).build();
  private FeatureFlagsWSClient INSTANCE;

  private static final String ENABLED_JSON =
      JsonUtils2.objToJson(
          new FeatureResponse(
              "CLIENT_20308", true, List.of(new FeatureKeyResponse("CLIENT_20308", 1000L, true))));

  private static final String DISABLED_JSON =
      JsonUtils2.objToJson(
          new FeatureResponse(
              "CLIENT_20308",
              false,
              List.of(new FeatureKeyResponse("CLIENT_20308", 1000L, false))));

  private static final FakeWsResponse fakeEnabledResponse =
      new FakeWsResponse()
          .setRequestUrl("application/lpx/feature/DETECT_MISSING_DOCUMENT_ENABLED")
          .setStatusCode(200)
          .setBody(ENABLED_JSON);

  private static final FakeWsResponse fakeDisabledResponse =
      new FakeWsResponse()
          .setRequestUrl("application/lpx/feature/DETECT_MISSING_DOCUMENT_ENABLED")
          .setStatusCode(200)
          .setBody(DISABLED_JSON);

  private static final FakeWsResponse fakeErrorResponse =
      new FakeWsResponse()
          .setRequestUrl("application/lpx/feature/DETECT_MISSING_DOCUMENT_ENABLED")
          .setStatusCode(500)
          .setBody("{}");

  @BeforeEach
  public void setup() {
    openMocks(this);
    cache =
        CacheBuilder.newBuilder().maximumSize(1000).expireAfterWrite(60, TimeUnit.SECONDS).build();
  }

  @Test
  public void testGetCachedFeatureFlag_true() throws ExecutionException {
    setupInstance(fakeEnabledResponse);
    var enabled =
        INSTANCE.getCachedFeatureFlag(Feature.DETECT_MISSING_DOCUMENT_ENABLED, "CLIENT_20308");
    assertTrue(enabled);
  }

  @Test
  public void testGetCachedFeatureFlag_false() throws ExecutionException {
    setupInstance(fakeDisabledResponse);
    var enabled =
        INSTANCE.getCachedFeatureFlag(Feature.DETECT_MISSING_DOCUMENT_ENABLED, "CLIENT_20308");
    assertFalse(enabled);
  }

  @Test
  public void testGetCachedFeatureFlag_error() throws ExecutionException {
    setupInstance(fakeErrorResponse);
    var enabled =
        INSTANCE.getCachedFeatureFlag(Feature.DETECT_MISSING_DOCUMENT_ENABLED, "CLIENT_20308");
    assertFalse(enabled);
  }

  @Test
  public void getEnabledKeysForFeature() {
    setupInstance(fakeEnabledResponse);
    var enabledKeys = INSTANCE.getEnabledKeysForFeature(Feature.DETECT_MISSING_DOCUMENT_ENABLED);
    assertTrue(enabledKeys.contains("CLIENT_20308"));
  }

  @Test
  public void getEnabledKeysForFeature_disabled() {
    setupInstance(fakeDisabledResponse);
    var enabledKeys = INSTANCE.getEnabledKeysForFeature(Feature.DETECT_MISSING_DOCUMENT_ENABLED);
    assertNull(enabledKeys);
  }

  private void setupInstance(FakeWsResponse response) {
    testClient = new TestHttpClient();
    testClient.setResponse(response);
    INSTANCE =
        new FeatureFlagsWSClient(
            testClient,
            new ServerConfiguration("feature-flags-ws", 8084, "feature-flags-ws", Scheme.HTTPS),
            cache);
  }
}
