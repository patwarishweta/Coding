package com.cwan.privatefund.account;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.Account;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import org.junit.jupiter.api.Test;

public class AccountTransformerTest {

  private static final Long ACCOUNT_ID = 42L;

  @Test
  void should_convert_business_account_to_account() {
    var businessAccount = BusinessAccount.builder().id(ACCOUNT_ID).build();
    var expected = Account.builder().id(ACCOUNT_ID).build();
    var transformer = new AccountTransformer();
    var actual = transformer.apply(businessAccount);
    assertEquals(expected, actual);
  }
}
