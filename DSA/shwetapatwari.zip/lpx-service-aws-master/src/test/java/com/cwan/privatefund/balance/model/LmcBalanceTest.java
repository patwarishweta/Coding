package com.cwan.privatefund.balance.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LmcBalanceTest {
  private Balance mockBalance1;
  private Balance mockBalance2;
  private Balance mockBalance3;
  private Balance mockBalance4;
  private CalculatedBalance mockCalculatedBalance;

  @BeforeEach
  void setUp() {
    // Mocking Balance
    mockBalance1 = mock(Balance.class);
    when(mockBalance1.getType()).thenReturn(BalanceType.REPORTED_ENDING_NAV.getCode());
    when(mockBalance1.getAmount()).thenReturn(1000.0);
    Account account = mockAccount(1L, "Account 1");
    Document document = mockDocument(1L);
    Security security = mockSecurity("CUSIP1", "Security 1", 1L);
    when(mockBalance1.getAccount()).thenReturn(account);
    when(mockBalance1.getCurrency()).thenReturn("USD");
    when(mockBalance1.getDocument()).thenReturn(document);
    when(mockBalance1.getSecurity()).thenReturn(security);

    mockBalance2 = mock(Balance.class);
    when(mockBalance2.getType()).thenReturn(BalanceType.REPORTED_TOTAL_COMMITMENT.getCode());
    when(mockBalance2.getAmount()).thenReturn(5000.0);
    when(mockBalance2.getAccount()).thenReturn(account);
    when(mockBalance2.getCurrency()).thenReturn("USD");
    when(mockBalance2.getDocument()).thenReturn(document);
    when(mockBalance2.getSecurity()).thenReturn(security);

    mockBalance3 = mock(Balance.class);
    when(mockBalance3.getType()).thenReturn(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION.getCode());
    when(mockBalance3.getAmount()).thenReturn(5000.0);
    when(mockBalance3.getAccount()).thenReturn(account);
    when(mockBalance3.getCurrency()).thenReturn("USD");
    when(mockBalance3.getDocument()).thenReturn(document);
    when(mockBalance3.getSecurity()).thenReturn(security);

    mockBalance4 = mock(Balance.class);
    when(mockBalance4.getType())
        .thenReturn(BalanceType.REPORTED_ENDING_UNFUNDED_COMMITMENT.getCode());
    when(mockBalance4.getAmount()).thenReturn(5000.0);
    when(mockBalance4.getAccount()).thenReturn(account);
    when(mockBalance4.getCurrency()).thenReturn("USD");
    when(mockBalance4.getDocument()).thenReturn(document);
    when(mockBalance4.getSecurity()).thenReturn(security);

    // Mocking CalculatedBalance
    Account account2 = mockAccount(2L, "Account 2");
    Security security2 = mockSecurity("CUSIP2", "Security 2", 2L);
    mockCalculatedBalance = mock(CalculatedBalance.class);
    when(mockCalculatedBalance.getSecurity()).thenReturn(security2);
    when(mockCalculatedBalance.getSource()).thenReturn("Source");
    when(mockCalculatedBalance.getAccount()).thenReturn(account2);
    when(mockCalculatedBalance.getCurrency()).thenReturn("EUR");
    when(mockCalculatedBalance.getNavImpact()).thenReturn(2000.0);
    when(mockCalculatedBalance.getWatchlistNavImpact()).thenReturn(50.0);
    when(mockCalculatedBalance.getGaapNavImpact()).thenReturn(1500.0);
    when(mockCalculatedBalance.getStatNavImpact()).thenReturn(1800.0);
    when(mockCalculatedBalance.getTotalCommitment()).thenReturn(3000.0);
    when(mockCalculatedBalance.getUnfundedCommitmentImpact()).thenReturn(1200.0);
    when(mockCalculatedBalance.getFundedCommitmentImpact()).thenReturn(2000.0);
    when(mockCalculatedBalance.getRecallableImpact()).thenReturn(1000.0);
  }

  @Test
  void testConvertToLmcBalance_withMultipleBalances() {
    // Arrange
    List<Balance> balances = Arrays.asList(mockBalance1, mockBalance2, mockBalance3, mockBalance4);

    // Act
    Set<LmcBalance> lmcBalances = LmcBalance.convertToLmcBalance(balances);

    // Assert
    assertEquals(1, lmcBalances.size()); // should be one unique LmcBalance
    LmcBalance balance = lmcBalances.iterator().next();
    assertEquals("Account 1", balance.getAccountName());
    assertEquals("CUSIP1", balance.getIdentifier());
    assertEquals(1000.0, balance.getSponsorNav());
    assertEquals(5000.0, balance.getCommitment());
    assertEquals(
        5000.0 + 5000.0, balance.getUnfundedInclRecallable()); // 0.0 since no recallableDist
  }

  @Test
  void testConvertToLmcBalance_withCalculatedBalance() {
    // Act
    LmcBalance lmcBalance = LmcBalance.convertToLmcBalance(mockCalculatedBalance);

    // Assert
    assertEquals("Security 2", lmcBalance.getLimitedPartnership());
    assertEquals("CUSIP2", lmcBalance.getIdentifier());
    assertEquals("Account 2", lmcBalance.getAccountName());
    assertEquals("EUR", lmcBalance.getCurrency());
    assertEquals(2000.0, lmcBalance.getSponsorNav());
    assertEquals(3000.0, lmcBalance.getCommitment());
    assertEquals(1200.0 + 1000.0, lmcBalance.getUnfundedInclRecallable()); // 1200.0 + 1000.0
  }

  private com.cwan.lpx.domain.Account mockAccount(Long id, String name) {
    com.cwan.lpx.domain.Account account = mock(com.cwan.lpx.domain.Account.class);
    when(account.getId()).thenReturn(id);
    when(account.getName()).thenReturn(name);
    return account;
  }

  private com.cwan.lpx.domain.Document mockDocument(Long id) {
    com.cwan.lpx.domain.Document document = mock(com.cwan.lpx.domain.Document.class);
    when(document.getId()).thenReturn(id);
    return document;
  }

  private com.cwan.lpx.domain.Security mockSecurity(String cusip, String name, Long id) {
    com.cwan.lpx.domain.Security security = mock(com.cwan.lpx.domain.Security.class);
    when(security.getCusip()).thenReturn(cusip);
    when(security.getSecurityName()).thenReturn(name);
    when(security.getSecurityId()).thenReturn(id);
    return security;
  }
}
