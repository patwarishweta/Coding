package com.cwan.privatefund.documentmanager.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.cwan.privatefund.documentmanager.DocumentUploadFileDetails;
import com.cwan.privatefund.documentmanager.DocumentUploadStatus;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import reactor.test.StepVerifier;

class DocumentManagerExceptionHandlerTest {

  private DocumentManagerExceptionHandler exceptionHandler;
  private static final DocumentUploadFileDetails DOCUMENT_UPLOAD_FILE_DETAILS =
      DocumentUploadFileDetails.builder()
          .status(DocumentUploadStatus.FAILED)
          .fileName("Some_name.pdf")
          .build();
  private static final List<DocumentUploadFileDetails> DOCUMENT_UPLOAD_FILE_DETAILS_LIST =
      List.of(DOCUMENT_UPLOAD_FILE_DETAILS);
  private static final DocumentUploadFailedException DOCUMENT_UPLOAD_FAILED_EXCEPTION =
      new DocumentUploadFailedException(DOCUMENT_UPLOAD_FILE_DETAILS_LIST);
  private static final ResponseStatusException RESPONSE_STATUS_EXCEPTION =
      new ResponseStatusException(HttpStatus.BAD_REQUEST, "Bad request received");

  @BeforeEach
  void setUp() {
    exceptionHandler = new DocumentManagerExceptionHandler();
  }

  @Test
  void testHandleDocumentUploadFailedException() {
    StepVerifier.create(
            exceptionHandler.handleDocumentUploadFailedException(DOCUMENT_UPLOAD_FAILED_EXCEPTION))
        .assertNext(
            response -> {
              assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
              assertNotNull(response.getBody());
              assertEquals(
                  DOCUMENT_UPLOAD_FILE_DETAILS_LIST, response.getBody().getUploadedFileDetails());
            })
        .verifyComplete();
  }

  @Test
  void testHandleResponseStatusException() {
    StepVerifier.create(exceptionHandler.handleResponseStatusException(RESPONSE_STATUS_EXCEPTION))
        .assertNext(
            response -> {
              assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
              assertNotNull(response.getBody());
              assertEquals(RESPONSE_STATUS_EXCEPTION.getMessage(), response.getBody());
            })
        .verifyComplete();
  }
}
