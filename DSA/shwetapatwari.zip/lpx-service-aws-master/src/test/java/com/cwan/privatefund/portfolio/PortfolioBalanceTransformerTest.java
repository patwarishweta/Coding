package com.cwan.privatefund.portfolio;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.portfolio.model.SecurityAccountPair;
import org.junit.jupiter.api.Test;

public class PortfolioBalanceTransformerTest {

  private static final Long ACCOUNT_ID = 1L;

  @Test
  void should_convert_account_to_portfolio_balance() {
    var account = Account.builder().id(ACCOUNT_ID).build();
    var security = Security.builder().securityId(ACCOUNT_ID).build();
    var securityAccountPair =
        SecurityAccountPair.builder().account(account).security(security).build();
    var actual = new PortfolioBalanceTransformer().apply(securityAccountPair);
    var expected = PortfolioBalance.builder().account(account).security(security).build();
    assertEquals(expected, actual);
  }
}
