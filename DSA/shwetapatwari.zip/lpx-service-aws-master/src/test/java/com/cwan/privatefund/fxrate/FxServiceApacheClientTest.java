package com.cwan.privatefund.fxrate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import java.time.LocalDate;
import java.util.Set;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class FxServiceApacheClientTest {
  @Mock private AuthTokenCore authTokenCore;
  private static final TestHttpClient testClient = new TestHttpClient();
  private static final String FX_RATE_JSON =
      """
          {"29":{"2":{"01/01/2024":0.35,"01/02/2024":0.48}}}
      """;
  private static final FakeWsResponse FX_RATE_RESPONSE =
      new FakeWsResponse()
          .setRequestUrl("spot/rates/sparse")
          .setStatusCode(200)
          .setBody(FX_RATE_JSON);
  private static final String SOURCE_JSON =
      """
          {
              "defaultSortedHistory": [
                  {
                      "beginDate": "01/01/2024",
                      "activitySourceId": 29,
                      "bsSourceId": 29,
                      "rank": 1,
                      "basisId": null,
                      "allowedWeekdaysStaleForClientSources": null
                  }
              ],
              "sortedHistoriesByBasisId": {
                      "2": [
                          {
                              "beginDate": "01/01/2024",
                              "activitySourceId": 30,
                              "bsSourceId": 30,
                              "rank": 1,
                              "basisId": 2,
                              "allowedWeekdaysStaleForClientSources": null
                          }
                      ]
                  }
          }
      """;
  private static final FakeWsResponse SOURCE_RESPONSE =
      new FakeWsResponse()
          .setRequestUrl("spot/sourceHistory/basis")
          .setStatusCode(200)
          .setBody(SOURCE_JSON);

  private static final Long CURRENCY_ID = 2L;
  private static final LocalDate DATE_1 = LocalDate.of(2024, 1, 1);
  private static final LocalDate DATE_2 = LocalDate.of(2024, 1, 2);
  private static final double FX_RATE_1 = 0.35;
  private static final double FX_RATE_2 = 0.48;
  private static final Long SOURCE_ID_1 = 29L;
  private static final Long SOURCE_ID_2 = 30L;
  private static final int BASIS_ID_1 = -1;
  private static final int BASIS_ID_2 = 2;
  private static final Long ACCOUNT_ID = 100L;

  private FxServiceApacheClient fxServiceApacheClient;

  @BeforeEach
  void setup() {
    MockitoAnnotations.openMocks(this);
    when(authTokenCore.createApplicationToken()).thenReturn("token");
    fxServiceApacheClient =
        new FxServiceApacheClient(
            testClient,
            new ServerConfiguration("fx-ws", 8084, "fx-ws", Scheme.HTTPS),
            authTokenCore);
  }

  @Test
  void get_fx_rate_map() {
    testClient.setResponse(FX_RATE_RESPONSE);
    TreeMap<LocalDate, Double> expected = new TreeMap<>();
    expected.put(DATE_1, FX_RATE_1);
    expected.put(DATE_2, FX_RATE_2);

    TreeMap<LocalDate, Double> actual =
        fxServiceApacheClient.getFxRateMap(DATE_1, DATE_2, SOURCE_ID_1, CURRENCY_ID);
    assertEquals(expected, actual);
  }

  @Test
  void get_account_fx_sources() {
    testClient.setResponse(SOURCE_RESPONSE);
    AccountFxSource accountFxSource1 =
        AccountFxSource.builder()
            .accountId(ACCOUNT_ID)
            .date(DATE_1)
            .basisId(BASIS_ID_1)
            .fxRateSourceId(SOURCE_ID_1)
            .rankId(1)
            .build();
    AccountFxSource accountFxSource2 =
        AccountFxSource.builder()
            .accountId(ACCOUNT_ID)
            .date(DATE_1)
            .basisId(BASIS_ID_2)
            .fxRateSourceId(SOURCE_ID_2)
            .rankId(1)
            .build();
    Set<AccountFxSource> actual = fxServiceApacheClient.getAccountFxSources(ACCOUNT_ID);
    assertEquals(Set.of(accountFxSource1, accountFxSource2), actual);
  }
}
