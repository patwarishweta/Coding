package com.cwan.privatefund.business.ws;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.client.WebResponseMapper;
import io.netty.handler.timeout.ReadTimeoutException;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class BusinessWsClientTest {

  @Mock private WebClient webClient;
  @Mock private AuthTokenCore authTokenCore;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private WebClient.RequestBodyUriSpec requestBodyUriSpec;
  @Mock private WebClient.RequestBodySpec requestBodySpec;
  @Mock private WebClient.RequestHeadersSpec requestHeadersSpec;
  @Mock private WebResponseMapper<BusinessWSException> responseMapper;
  private BusinessWSClient instance;
  private static final Long ACCOUNT_ID = 9L;
  private static final List<BusinessAccount> ACCOUNTS = List.of(new BusinessAccount());
  private static final Mono<List<BusinessAccount>> ACCOUNTS_MONO = Mono.just(ACCOUNTS);
  private static final List<Long> ACCOUNT_IDS = List.of(1L, 2L, 3L, 4L);
  private static final Mono<List<Long>> ACCOUNT_IDS_MONO = Mono.just(ACCOUNT_IDS);

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance = new BusinessWSClient(webClient, responseMapper, authTokenCore);
    setupWebClientResponses();
  }

  @Test
  void should_return_account_data_from_account_id() {
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(ACCOUNTS_MONO);
    var actual = instance.getAccountInformation(ACCOUNT_ID).block();
    assertEquals(ACCOUNTS, actual);
  }

  @Test
  void should_return_get_account_data_from_ids() {
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(ACCOUNTS_MONO);
    var actual = instance.getAccountsInformation(List.of(ACCOUNT_ID)).block();
    assertEquals(ACCOUNTS, actual);
  }

  @Test
  void should_return_expanded_account_ids() {
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(ACCOUNT_IDS_MONO);
    var actual = instance.getExpandedAccountIds(ACCOUNT_ID).block();
    assertEquals(ACCOUNT_IDS, actual);
  }

  @Test
  void should_return_user_account_access() {
    Map<Long, Boolean> accountAccessMap =
        ACCOUNT_IDS.stream().collect(Collectors.toMap(Function.identity(), id -> (id % 2) == 0));
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just(accountAccessMap));
    var actual = instance.getUserAccountAccess(9, new HashSet<>(ACCOUNT_IDS)).block();
    assertEquals(accountAccessMap, actual);
  }

  @Test
  void businessWsClient_api_call_4xx_with_error_response_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just("4xx error sent from  business ws"));
    assertAll(
        () -> assertThrows(Exception.class, () -> instance.getExpandedAccountIds(1L).block()),
        () -> assertThrows(Exception.class, () -> instance.getClientInfo(List.of(1L)).block()),
        () -> assertThrows(Exception.class, () -> instance.getAccountInformation(1L).block()),
        () ->
            assertThrows(
                Exception.class, () -> instance.getAccountsInformation(List.of(1L)).block()),
        () ->
            assertThrows(
                Exception.class, () -> instance.getUserAccountAccess(1, List.of(1L)).block()),
        () -> assertThrows(Exception.class, () -> instance.getClientAccountIds(1L).block()));
  }

  @Test
  void businessWsClient_api_call_error_on_retry_exhausted_test() {
    when(webClient.get()).thenThrow(ReadTimeoutException.class);
    when(webClient.post()).thenThrow(ReadTimeoutException.class);
    assertAll(
        () ->
            assertThrows(
                ReadTimeoutException.class, () -> instance.getExpandedAccountIds(1L).block()),
        () ->
            assertThrows(
                ReadTimeoutException.class, () -> instance.getClientInfo(List.of(1L)).block()),
        () ->
            assertThrows(
                ReadTimeoutException.class, () -> instance.getAccountInformation(1L).block()),
        () ->
            assertThrows(
                ReadTimeoutException.class,
                () -> instance.getAccountsInformation(List.of(1L)).block()),
        () ->
            assertThrows(
                ReadTimeoutException.class,
                () -> instance.getUserAccountAccess(1, List.of(1L)).block()),
        () ->
            assertThrows(
                ReadTimeoutException.class, () -> instance.getClientAccountIds(1L).block()));
  }

  @Test
  void businessWsClient_api_call_5xx_with_error_response_test() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just("5xx error sent from  business ws"));
    assertAll(
        () -> assertThrows(Exception.class, () -> instance.getExpandedAccountIds(1L).block()),
        () -> assertThrows(Exception.class, () -> instance.getClientInfo(List.of(1L)).block()),
        () -> assertThrows(Exception.class, () -> instance.getAccountInformation(1L).block()),
        () ->
            assertThrows(
                Exception.class, () -> instance.getAccountsInformation(List.of(1L)).block()),
        () ->
            assertThrows(
                Exception.class, () -> instance.getUserAccountAccess(1, List.of(1L)).block()),
        () -> assertThrows(Exception.class, () -> instance.getClientAccountIds(1L).block()));
  }

  @Test
  void businessWsClient_api_call_5xx_test_2() {
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(Exception.class, () -> instance.getExpandedAccountIds(1L).block());
  }

  private void setupWebClientResponses() {
    // GET request
    when(webClient.get()).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.uri(any(Function.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.accept(MediaType.APPLICATION_JSON))
        .thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.retrieve()).thenReturn(responseSpecMock);
    // POST request
    when(webClient.post()).thenReturn(requestBodyUriSpec);
    when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
    when(requestBodySpec.contentType(any(MediaType.class))).thenReturn(requestBodySpec);
    when(requestBodySpec.body(any(BodyInserters.FormInserter.class)))
        .thenReturn(requestHeadersSpec);
    when(requestHeadersSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpec);
    when(requestHeadersSpec.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenReturn(responseSpecMock);
  }

  @Test
  void fetchUserDetails_Success() {
    var user = User.builder().id(1).fullname("Test User").build();
    when(responseSpecMock.bodyToMono(User.class)).thenReturn(Mono.just(user));
    User actual = instance.fetchUserDetails(1).block();
    assertEquals(user, actual);
  }

  @Test
  void fetchUserDetails_UnknownHostException() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToMono(User.class))
        .thenReturn(Mono.error(new UnknownHostException()));
    StepVerifier.create(instance.fetchUserDetails(1)).verifyError(UnknownHostException.class);
  }

  @Test
  void fetchUserDetails_4xx() {
    ClientResponse clientResponseMock = mock(ClientResponse.class);
    when(clientResponseMock.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              HttpStatus status = HttpStatus.BAD_REQUEST;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                ((Function<ClientResponse, Mono<? extends Throwable>>) invocation.getArgument(1))
                    .apply(clientResponseMock);
              }
              return responseSpecMock;
            });
    when(clientResponseMock.bodyToMono(any(Class.class))).thenReturn(Mono.empty());
    when(responseSpecMock.bodyToMono(User.class))
        .thenReturn(
            Mono.error(
                new WebClientResponseException(
                    "4xx Client Error", 400, "Bad Request", null, null, null)));
    StepVerifier.create(instance.fetchUserDetails(1)).verifyError(WebClientResponseException.class);
  }

  @Test
  void fetchUserDetails_5xx() {
    ClientResponse clientResponseMock = mock(ClientResponse.class);
    when(clientResponseMock.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                ((Function<ClientResponse, Mono<? extends Throwable>>) invocation.getArgument(1))
                    .apply(clientResponseMock);
              }
              return responseSpecMock;
            });
    when(clientResponseMock.bodyToMono(any(Class.class))).thenReturn(Mono.empty());
    when(responseSpecMock.bodyToMono(User.class))
        .thenReturn(
            Mono.error(
                new WebClientResponseException(
                    "5xx Server Error", 500, "Internal Server Error", null, null, null)));
    StepVerifier.create(instance.fetchUserDetails(1)).verifyError(WebClientResponseException.class);
  }

  @Test
  void should_return_client_account_ids() {
    when(responseSpecMock.bodyToMono(any(ParameterizedTypeReference.class)))
        .thenReturn(Mono.just(ACCOUNT_IDS));
    var actual = instance.getClientAccountIds(1L).block();
    assertEquals(ACCOUNT_IDS, actual);
  }
}
