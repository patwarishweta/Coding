package com.cwan.privatefund.config.properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;

@ExtendWith(MockitoExtension.class)
public class SalesforceConfigPropertiesTest {

  @InjectMocks private SalesforceConfigProperties salesforceConfigProperties;
  @Mock private SecretsManagerClient secretsManagerClient;
  private static final String SALESFORCE_CLIENT_ID = "salesforce_client_id";
  private static final String SALESFORCE_CLIENT_SECRET = "salesforce_client_secret";

  @Test
  public void testExtractSecretsFromManager() {
    mockSecrets();
    salesforceConfigProperties.extractSecretsFromManager();
    assertEquals("clientId", salesforceConfigProperties.getClientId());
    assertEquals("clientSecret", salesforceConfigProperties.getClientSecret());
  }

  @Test
  public void testExtractSecretsFromManager_exception() {
    Mockito.lenient()
        .when(secretsManagerClient.getSecretValue(any(GetSecretValueRequest.class)))
        .thenThrow(new RuntimeException("Error in getting secret value"));
    assertThrows(
        RuntimeException.class, () -> salesforceConfigProperties.extractSecretsFromManager());
  }

  @Test
  public void testExtractSecretsFromManager_nullSecret() {
    Mockito.lenient()
        .when(secretsManagerClient.getSecretValue(any(GetSecretValueRequest.class)))
        .thenReturn(GetSecretValueResponse.builder().secretString(null).build());
    assertThrows(
        RuntimeException.class, () -> salesforceConfigProperties.extractSecretsFromManager());
  }

  private void mockSecrets() {
    when(secretsManagerClient.getSecretValue(
            GetSecretValueRequest.builder().secretId(SALESFORCE_CLIENT_ID).build()))
        .thenReturn(GetSecretValueResponse.builder().secretString("Y2xpZW50SWQ=").build());
    when(secretsManagerClient.getSecretValue(
            GetSecretValueRequest.builder().secretId(SALESFORCE_CLIENT_SECRET).build()))
        .thenReturn(GetSecretValueResponse.builder().secretString("Y2xpZW50U2VjcmV0").build());
  }
}
