package com.cwan.privatefund.documentmanager;

import static com.cwan.privatefund.TestUtil.getDocument;
import static com.cwan.privatefund.TestUtil.getDocumentManagerData;
import static com.cwan.privatefund.TestUtil.getFilePart;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.account.UltimateParents;
import com.cwan.privatefund.account.UltimateParentsAccountMap;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.auth.accesscontrolfiltering.AccessControlFilteringService;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.document.LpxDocumentServiceCache;
import com.cwan.privatefund.document.model.DocumentTypeData;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest(classes = DocumentManagerRequestValidator.class)
class DocumentManagerRequestValidatorTest {

  @Mock private User USER;
  @Mock private LpxDocumentServiceCache lpxDocumentServiceCache;
  @Mock private SecurityContextUserService securityContextUserService;
  @Mock private AccessControlFilteringService accessControlFilteringService;
  @Mock private AccountService accountService;
  private DocumentManagerRequestValidator documentManagerRequestValidator;
  private final Document DOCUMENT = getDocument();
  private final DocumentManagerData DOCUMENT_DETAILS =
      getDocumentManagerData().toBuilder()
          .ultimateParent(
              UltimateParents.builder()
                  .ultimateParentName("Ultimate Parent Name")
                  .ultimateParentId(123L)
                  .build())
          .build();
  private final FilePart FILE = getFilePart();
  private final DocumentUploadRequest DOCUMENT_UPLOAD_REQUEST =
      DocumentUploadRequest.builder()
          .documentDetails(DOCUMENT_DETAILS)
          .files(List.of(FILE))
          .build();

  @BeforeEach
  void setUp() {
    documentManagerRequestValidator =
        new DocumentManagerRequestValidator(
            lpxDocumentServiceCache,
            securityContextUserService,
            accessControlFilteringService,
            accountService);
  }

  @Test
  void test_validateDocumentUploadRequest_invalidDocumentDetails() {
    DocumentUploadRequest request = DocumentUploadRequest.builder().documentDetails(null).build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateDocumentUploadRequest_nullDocument() {
    DocumentUploadRequest request1 =
        DocumentUploadRequest.builder()
            .documentDetails(DOCUMENT_DETAILS.toBuilder().document(null).build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request1))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateDocumentUploadRequest_invalidDocumentType() {
    DocumentUploadRequest request1 =
        DocumentUploadRequest.builder()
            .documentDetails(
                DOCUMENT_DETAILS.toBuilder()
                    .document(DOCUMENT.toBuilder().type(null).build())
                    .build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request1))
        .expectError(ResponseStatusException.class)
        .verify();
    DocumentUploadRequest request2 =
        DocumentUploadRequest.builder()
            .documentDetails(
                DOCUMENT_DETAILS.toBuilder()
                    .document(DOCUMENT.toBuilder().type("").build())
                    .build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request2))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateDocumentUploadRequest_invalidUltimateParentId() {
    DocumentUploadRequest request1 =
        DocumentUploadRequest.builder()
            .documentDetails(DOCUMENT_DETAILS.toBuilder().ultimateParent(null).build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request1))
        .expectError(ResponseStatusException.class)
        .verify();
    DocumentUploadRequest request2 =
        DocumentUploadRequest.builder()
            .documentDetails(
                DOCUMENT_DETAILS.toBuilder()
                    .ultimateParent(UltimateParents.builder().ultimateParentId(null).build())
                    .build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request2))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateDocumentUploadRequest_invalidUltimateParentName() {
    DocumentUploadRequest request1 =
        DocumentUploadRequest.builder()
            .documentDetails(
                DOCUMENT_DETAILS.toBuilder()
                    .ultimateParent(
                        UltimateParents.builder()
                            .ultimateParentId(123L)
                            .ultimateParentName(null)
                            .build())
                    .build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request1))
        .expectError(ResponseStatusException.class)
        .verify();
    DocumentUploadRequest request2 =
        DocumentUploadRequest.builder()
            .documentDetails(
                DOCUMENT_DETAILS.toBuilder()
                    .ultimateParent(
                        UltimateParents.builder()
                            .ultimateParentId(123L)
                            .ultimateParentName("")
                            .build())
                    .build())
            .files(List.of(FILE))
            .build();
    StepVerifier.create(documentManagerRequestValidator.validateDocumentUploadRequest(request2))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateDocumentUploadRequest_success() {
    StepVerifier.create(
            documentManagerRequestValidator.validateDocumentUploadRequest(DOCUMENT_UPLOAD_REQUEST))
        .expectNext(DOCUMENT_UPLOAD_REQUEST)
        .verifyComplete();
  }

  @Test
  void test_validateAndFetchNeedsCustomAllocation_invalidDocType() {
    when(lpxDocumentServiceCache.getDocumentTypeData(anyString()))
        .thenReturn(
            Mono.error(
                new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid document type.")));
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DOCUMENT_UPLOAD_REQUEST))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateAndFetchNeedsCustomAllocation_docTypeDataNull() {
    when(lpxDocumentServiceCache.getDocumentTypeData(anyString()))
        .thenReturn(Mono.just(DocumentTypeData.builder().needsCustomAllocation(null).build()));
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DOCUMENT_UPLOAD_REQUEST))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateAndFetchNeedsCustomAllocation_needsCustomAllocationFalse() {
    when(lpxDocumentServiceCache.getDocumentTypeData(anyString()))
        .thenReturn(
            Mono.just(DocumentTypeData.builder().needsCustomAllocation(Boolean.FALSE).build()));
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DOCUMENT_UPLOAD_REQUEST))
        .assertNext(
            needsCustomAllocation -> {
              assertNotNull(needsCustomAllocation);
              assertFalse(needsCustomAllocation);
            })
        .verifyComplete();
  }

  @Test
  void test_validateAndFetchNeedsCustomAllocation_needsCustomAllocationTrueAndInvalidAccount() {
    when(lpxDocumentServiceCache.getDocumentTypeData(anyString()))
        .thenReturn(
            Mono.just(DocumentTypeData.builder().needsCustomAllocation(Boolean.TRUE).build()));
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DocumentUploadRequest.builder()
                    .documentDetails(
                        DOCUMENT_DETAILS.toBuilder()
                            .document(DOCUMENT.toBuilder().account(null).build())
                            .build())
                    .build()))
        .expectError(ResponseStatusException.class)
        .verify();
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DocumentUploadRequest.builder()
                    .documentDetails(
                        DOCUMENT_DETAILS.toBuilder()
                            .document(
                                DOCUMENT.toBuilder()
                                    .account(Account.builder().id(null).build())
                                    .build())
                            .build())
                    .build()))
        .expectError(ResponseStatusException.class)
        .verify();
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DocumentUploadRequest.builder()
                    .documentDetails(
                        DOCUMENT_DETAILS.toBuilder()
                            .document(
                                DOCUMENT.toBuilder()
                                    .account(Account.builder().id(0L).build())
                                    .build())
                            .build())
                    .build()))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_validateAndFetchNeedsCustomAllocation_needsCustomAllocationTrue() {
    when(lpxDocumentServiceCache.getDocumentTypeData(anyString()))
        .thenReturn(
            Mono.just(DocumentTypeData.builder().needsCustomAllocation(Boolean.TRUE).build()));
    StepVerifier.create(
            documentManagerRequestValidator.validateAndFetchNeedsCustomAllocation(
                DOCUMENT_UPLOAD_REQUEST))
        .assertNext(
            needsCustomAllocation -> {
              assertNotNull(needsCustomAllocation);
              assertTrue(needsCustomAllocation);
            })
        .verifyComplete();
  }

  @Test
  void test_authorizeDocumentUploadRequest_unauthorizedUser() {
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(USER));
    when(accessControlFilteringService.checkResourceAccessByAccount(any(User.class), anyLong()))
        .thenReturn(Mono.just(Boolean.FALSE));
    StepVerifier.create(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(DOCUMENT_UPLOAD_REQUEST))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_authorizeDocumentUploadRequest_invalidUltimateParentId() {
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(USER));
    when(accessControlFilteringService.checkResourceAccessByAccount(any(User.class), anyLong()))
        .thenReturn(Mono.just(Boolean.TRUE));
    when(accountService.retrieveAccountsGroupedByUltimateParent(anyInt())).thenReturn(Flux.empty());
    StepVerifier.create(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(DOCUMENT_UPLOAD_REQUEST))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_authorizeDocumentUploadRequest_accountNotChildOfUltimateParent() {
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(USER));
    when(accessControlFilteringService.checkResourceAccessByAccount(any(User.class), anyLong()))
        .thenReturn(Mono.just(Boolean.TRUE));
    when(accountService.retrieveAccountsGroupedByUltimateParent(anyInt()))
        .thenReturn(
            Flux.just(
                UltimateParentsAccountMap.builder()
                    .ultimateParentId(123)
                    .accounts(List.of(Account.builder().id(234L).build()))
                    .build()));
    StepVerifier.create(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(DOCUMENT_UPLOAD_REQUEST))
        .expectError(ResponseStatusException.class)
        .verify();
  }

  @Test
  void test_authorizeDocumentUploadRequest_nullAccount() {
    DocumentUploadRequest nullAccountDocumentUploadRequest =
        DOCUMENT_UPLOAD_REQUEST.toBuilder()
            .documentDetails(
                DOCUMENT_DETAILS.toBuilder()
                    .document(DOCUMENT.toBuilder().account(null).build())
                    .build())
            .build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(USER));
    when(accessControlFilteringService.checkResourceAccessByAccount(any(User.class), anyLong()))
        .thenReturn(Mono.just(Boolean.TRUE));
    when(accountService.retrieveAccountsGroupedByUltimateParent(anyInt()))
        .thenReturn(
            Flux.just(
                UltimateParentsAccountMap.builder()
                    .ultimateParentId(123)
                    .accounts(List.of(Account.builder().id(234L).build()))
                    .build()));
    StepVerifier.create(
            documentManagerRequestValidator.authorizeDocumentUploadRequest(
                nullAccountDocumentUploadRequest))
        .expectNext(nullAccountDocumentUploadRequest)
        .verifyComplete();
  }
}
