package com.cwan.privatefund.account;

import static com.cwan.privatefund.TestUtil.getAccountConfig;
import static com.cwan.privatefund.TestUtil.getBasis;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Client;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.basis.ws.BasisWSCache;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class AccountServiceTest {

  private static final Integer USER_ID = 9;
  private static final Long ACCOUNT_ID = 42L;
  private static final Long CLIENT_ID = 24601L;
  private static final LocalDate SUBSCRIPTION_START_DATE = LocalDate.of(2021, 12, 31);
  private static final Set<Long> ACCOUNT_IDS = Set.of(ACCOUNT_ID);
  private static final BusinessAccount BUSINESS_ACCOUNT =
      BusinessAccount.builder().id(ACCOUNT_ID).clientId(20026L).ultimateParentId(20026L).build();
  private static final Account ACCOUNT =
      Account.builder()
          .id(ACCOUNT_ID)
          .client(Client.builder().name("20026 Client").build())
          .ultimateParentClient(Client.builder().name("20026 Client").build())
          .subscriptionStartDate(SUBSCRIPTION_START_DATE)
          .attributes(Collections.emptyMap())
          .build();
  @Mock private BusinessWSCache businessWSCache;
  @Mock AccountTransformer accountTransformer;
  @Mock private AccountConfigServiceCache accountConfigServiceCache;
  @Mock private BasisWSCache basisWSCache;
  private AccountService instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(accountConfigServiceCache.getAllAccountConfigs())
        .thenReturn(Mono.just(List.of(getAccountConfig())));
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, true)));
    when(accountTransformer.apply(eq(BUSINESS_ACCOUNT))).thenReturn(ACCOUNT);
    instance =
        new AccountService(
            businessWSCache, accountTransformer, accountConfigServiceCache, basisWSCache);
  }

  @Test
  void check_User_Access_To_Accounts() {
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, true)));
    StepVerifier.create(instance.checkUserAccessToAccounts(9, Set.of(42L)))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void get_ultimate_parent_map() {
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, true)));
    when(businessWSCache.ultimateParentCacheByAccountId(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(2, 3L)))));
    when(businessWSCache.getAccountsData(any())).thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT)));
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, BUSINESS_ACCOUNT)));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().parentId(5).build())));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(Mono.just(AccountConfig.builder().id(1L).build()));
    when(businessWSCache.getClientData(any()))
        .thenReturn(Mono.just(Client.builder().parentId(5).build()));
    StepVerifier.create(instance.retrieveAccountsGroupedByUltimateParent(USER_ID))
        .expectNextMatches(xx -> xx.getUltimateParentId() == 5)
        .verifyComplete();
  }

  @Test
  void should_filter_null_expanded_accounts() {
    Set<Long> input = Set.of(1L);
    Map<Long, List<Long>> cacheResponse = Map.of(1L, Arrays.asList(2L, null, 3L));
    when(businessWSCache.getExpandedAccountByIdsFromCache(eq(input)))
        .thenReturn(Mono.just(cacheResponse));
    Set<Long> expected = new HashSet<>(Arrays.asList(1L, 2L, 3L));
    StepVerifier.create(instance.expandAccountIds(input)).expectNext(expected).verifyComplete();
  }

  @Test
  void should_filter_null_values_in_batches() {
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), any()))
        .thenReturn(Mono.just(Map.of(1L, true, 2L, true, 3L, true)));
    StepVerifier.create(instance.retrieveUserAccessibleAccountIdsInBatches(USER_ID, 2))
        .expectNext(new HashSet<>(Arrays.asList(1L, 2L)))
        .expectNext(new HashSet<>(List.of(3L)))
        .verifyComplete();
  }

  @Test
  void should_group_accounts_by_client_id_correctly() {
    var client1 = Client.builder().name("Client 1").build();
    var client2 = Client.builder().name("Client 2").build();
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(
            Mono.just(
                Map.of(
                    1L,
                    BusinessAccount.builder().id(1L).clientId(100L).build(),
                    2L,
                    BusinessAccount.builder().id(2L).clientId(100L).build(),
                    3L,
                    BusinessAccount.builder().id(3L).clientId(200L).build())));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(100L, client1, 200L, client2)));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(Mono.just(AccountConfig.builder().build()));
    when(accountTransformer.apply(any()))
        .thenAnswer(
            invocation -> {
              var ba = (BusinessAccount) invocation.getArgument(0);
              return Account.builder().id(ba.getId()).clientId(ba.getClientId()).build();
            });
    StepVerifier.create(instance.getClientAccountsData(USER_ID))
        .expectNextMatches(clientAccounts -> clientAccounts.getAccounts().size() == 2)
        .expectNextMatches(clientAccounts -> clientAccounts.getAccounts().size() == 1)
        .verifyComplete();
  }

  @Test
  void should_handle_account_with_null_attributes() {
    var configWithNullAttributes =
        AccountConfig.builder()
            .id(1L)
            .account(ACCOUNT)
            .subscriptionStartDate(SUBSCRIPTION_START_DATE)
            .attributes(null)
            .build();
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, BUSINESS_ACCOUNT)));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().build())));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(Mono.just(configWithNullAttributes));
    when(accountTransformer.apply(any())).thenReturn(Account.builder().id(ACCOUNT_ID).build());
    StepVerifier.create(instance.retrieveUserAccounts(USER_ID))
        .expectNextMatches(
            account -> (account.getAttributes() != null) && account.getAttributes().isEmpty())
        .verifyComplete();
  }

  @Test
  void should_handle_empty_account_ids() {
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), any())).thenReturn(Mono.just(Map.of()));
    StepVerifier.create(instance.retrieveUserAccessibleAccountIdsInBatches(USER_ID, 2))
        .verifyComplete();
  }

  @Test
  void should_handle_missing_account_config() {
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, BUSINESS_ACCOUNT)));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().build())));
    when(accountConfigServiceCache.getByAccountId(anyLong())).thenReturn(Mono.empty());
    when(accountTransformer.apply(any())).thenReturn(Account.builder().id(ACCOUNT_ID).build());
    StepVerifier.create(instance.retrieveUserAccounts(USER_ID)).expectNextCount(0).verifyComplete();
  }

  @Test
  void should_handle_null_client_data_in_enrich_with_client_data() {
    var businessAccountWithNulls =
        BusinessAccount.builder().id(ACCOUNT_ID).clientId(null).ultimateParentId(null).build();
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, businessAccountWithNulls)));
    when(businessWSCache.getClientDataFromCache(eq(List.of())))
        .thenReturn(Mono.just(Collections.emptyMap()));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(Mono.just(AccountConfig.builder().build()));
    when(accountTransformer.apply(eq(businessAccountWithNulls)))
        .thenReturn(Account.builder().id(ACCOUNT_ID).build());
    StepVerifier.create(instance.retrieveUserAccounts(USER_ID))
        .expectNextMatches(
            account ->
                account.getId().equals(ACCOUNT_ID)
                    && (account.getClient() == null)
                    && (account.getUltimateParentClient() == null))
        .verifyComplete();
  }

  @Test
  void should_handle_null_user_id() {
    StepVerifier.create(instance.retrieveUserAccounts(null)).verifyComplete();
  }

  @Test
  void should_handle_single_batch() {
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), any()))
        .thenReturn(Mono.just(Map.of(1L, true, 2L, true)));
    StepVerifier.create(instance.retrieveUserAccessibleAccountIdsInBatches(USER_ID, 5))
        .expectNext(new HashSet<>(Arrays.asList(1L, 2L)))
        .verifyComplete();
  }

  @Test
  void should_return_account_ids_by_user_id_mono() {
    var actual = instance.retrieveUserAccessibleAccountIds(USER_ID).block();
    assertEquals(ACCOUNT_IDS, actual);
  }

  @Test
  void should_return_account_ids_in_batches() {
    when(businessWSCache.getUserAccountAccess(eq(USER_ID), any()))
        .thenReturn(Mono.just(Map.of(1L, true, 2L, true, 3L, true, 4L, true, 5L, true)));
    StepVerifier.create(instance.retrieveUserAccessibleAccountIdsInBatches(USER_ID, 2))
        .expectNext(new HashSet<>(Arrays.asList(1L, 2L)))
        .expectNext(new HashSet<>(Arrays.asList(3L, 4L)))
        .expectNext(new HashSet<>(List.of(5L)))
        .verifyComplete();
  }

  @Test
  void should_return_accounts_by_account_ids() {
    when(businessWSCache.getAccountsData(eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT)));
    when(accountTransformer.apply(eq(BUSINESS_ACCOUNT))).thenReturn(ACCOUNT);
    when(businessWSCache.getClientDataFromCache(eq(List.of(20026L))))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().name("20026 Client").build())));
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, BUSINESS_ACCOUNT)));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().parentId(5).build())));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(
            Mono.just(
                AccountConfig.builder()
                    .account(ACCOUNT)
                    .subscriptionStartDate(SUBSCRIPTION_START_DATE)
                    .build()));
    var actual = instance.getAccountsData(ACCOUNT_IDS).block();
    assertEquals(List.of(ACCOUNT), actual);
  }

  @Test
  void should_return_accounts_by_user_id() {
    when(businessWSCache.getAccountData(eq(ACCOUNT_ID))).thenReturn(Mono.just(BUSINESS_ACCOUNT));
    when(businessWSCache.getAccountsData(eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT)));
    when(accountTransformer.apply(eq(BUSINESS_ACCOUNT))).thenReturn(ACCOUNT);
    when(businessWSCache.ultimateParentCacheByAccountId(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(1, 1L)))));
    when(businessWSCache.getClientData(any()))
        .thenReturn(Mono.just(Client.builder().name("20026 Client").parentId(5).build()));
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, BUSINESS_ACCOUNT)));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().parentId(5).build())));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(
            Mono.just(
                AccountConfig.builder()
                    .account(ACCOUNT)
                    .subscriptionStartDate(SUBSCRIPTION_START_DATE)
                    .build()));
    var actual = instance.retrieveUserAccounts(USER_ID).blockFirst();
    assertEquals(ACCOUNT, actual);
  }

  @Test
  void should_return_accounts_with_clientData() {
    when(businessWSCache.getAccountData(eq(ACCOUNT_ID))).thenReturn(Mono.just(BUSINESS_ACCOUNT));
    when(businessWSCache.getAccountsData(eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT)));
    when(accountTransformer.apply(eq(BUSINESS_ACCOUNT))).thenReturn(ACCOUNT);
    when(businessWSCache.ultimateParentCacheByAccountId(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(1, 1L)))));
    when(businessWSCache.getClientData(any()))
        .thenReturn(Mono.just(Client.builder().parentId(5).build()));
    var actual = instance.getAccountWithClientData(ACCOUNT_ID).block();
    assertEquals(ACCOUNT, actual);
  }

  @Test
  void should_return_client_accounts() {
    var clientId = 1337L;
    when(businessWSCache.getClientAccountIds(eq(clientId)))
        .thenReturn(Mono.just(List.of(ACCOUNT_ID)));
    when(businessWSCache.getAccountsData(eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT)));
    when(accountTransformer.apply(eq(BUSINESS_ACCOUNT))).thenReturn(ACCOUNT);
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(
            Mono.just(
                AccountConfig.builder()
                    .account(ACCOUNT)
                    .subscriptionStartDate(SUBSCRIPTION_START_DATE)
                    .build()));
    var actual = instance.getClientAccounts(clientId, USER_ID).collectList().block();
    assertEquals(List.of(ACCOUNT), actual);
  }

  @Test
  void should_return_client_hierarchies() {
    Map<Long, SortedMap<Integer, Long>> expected =
        Map.of(CLIENT_ID, new TreeMap<>(Map.of(1, CLIENT_ID, 2, 24602L)));
    when(businessWSCache.ultimateParentCacheByClientId(any())).thenReturn(Mono.just(expected));
    var actual = instance.getClientHierarchyForClients(Set.of(CLIENT_ID));
    assertEquals(expected, actual);
  }

  @Test
  void should_return_empty_mono_for_empty_input() {
    StepVerifier.create(instance.expandAccountIds(Set.of())).verifyComplete();
  }

  @Test
  void should_return_empty_mono_for_null_values() {
    Set<Long> inputWithNull = new HashSet<>();
    inputWithNull.add(null);
    StepVerifier.create(instance.expandAccountIds(inputWithNull)).verifyComplete();
  }

  @Test
  void should_return_empty_mono_when_expanded_account_ids_empty() {
    when(businessWSCache.getExpandedAccountIds(ACCOUNT_ID)).thenReturn(Mono.empty());
    StepVerifier.create(instance.expandAccountIdMap(ACCOUNT_ID)).verifyComplete();
  }

  @Test
  void should_return_enabled_bases() {
    var bases = List.of(getBasis());
    when(basisWSCache.getEnabledBases(eq(ACCOUNT_ID))).thenReturn(bases);
    var actual = instance.getEnabledBases(ACCOUNT_ID, USER_ID).collectList().block();
    assertEquals(bases, actual);
  }

  @Test
  void should_return_expanded_account_ids_map_by_account() {
    List<Long> expectedExpandedAccountIds = List.of(1L, 2L);
    Map<Long, List<Long>> expectedExpandedAccountIdsMap =
        Map.of(ACCOUNT_ID, expectedExpandedAccountIds);
    when(businessWSCache.getExpandedAccountIds(ACCOUNT_ID))
        .thenReturn(Mono.just(expectedExpandedAccountIds));
    StepVerifier.create(instance.expandAccountIdMap(ACCOUNT_ID))
        .expectNext(expectedExpandedAccountIdsMap)
        .verifyComplete();
  }

  @Test
  void should_return_expanded_accounts() {
    var expected = List.of(1L, 2L);
    when(businessWSCache.getExpandedAccountIds(ACCOUNT_ID)).thenReturn(Mono.just(expected));
    var actual = instance.expandAccountId(ACCOUNT_ID).collectList().block();
    assertEquals(expected, actual);
  }

  @Test
  void should_return_expanded_accounts_from_cache() {
    Set<Long> input = Set.of(1L, 2L);
    Map<Long, List<Long>> cacheResponse = Map.of(1L, List.of(3L, 4L), 2L, List.of(5L, 6L));
    when(businessWSCache.getExpandedAccountByIdsFromCache(eq(input)))
        .thenReturn(Mono.just(cacheResponse));
    Set<Long> expected = new HashSet<>(Arrays.asList(1L, 2L, 3L, 4L, 5L, 6L));
    StepVerifier.create(instance.expandAccountIds(input)).expectNext(expected).verifyComplete();
  }

  @Test
  void should_return_input_set_when_cache_empty() {
    Set<Long> input = Set.of(1L, 2L);
    when(businessWSCache.getExpandedAccountByIdsFromCache(eq(input))).thenReturn(Mono.empty());
    StepVerifier.create(instance.expandAccountIds(input)).expectNext(input).verifyComplete();
  }

  @Test
  void should_return_ultimate_parent_clients() {
    var expected = UltimateParents.builder().build();
    var actual = instance.retrieveUltimateParents(USER_ID).next().block();
    assertEquals(expected, actual);
  }

  @Test
  void test_returns_flux_of_client_accounts_with_valid_user_id() {
    var account =
        Account.builder()
            .id(ACCOUNT_ID)
            .clientId(1L)
            .client(Client.builder().name("20026 Client").build())
            .ultimateParentClient(Client.builder().name("20026 Client").build())
            .subscriptionStartDate(SUBSCRIPTION_START_DATE)
            .attributes(Collections.emptyMap())
            .build();
    when(businessWSCache.getAccountData(eq(ACCOUNT_ID))).thenReturn(Mono.just(BUSINESS_ACCOUNT));
    when(businessWSCache.getAccountsData(eq(ACCOUNT_IDS)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT)));
    when(accountTransformer.apply(eq(BUSINESS_ACCOUNT))).thenReturn(account);
    when(businessWSCache.ultimateParentCacheByAccountId(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(1, 1L)))));
    when(businessWSCache.getClientData(any()))
        .thenReturn(Mono.just(Client.builder().name("20026 Client").build()));
    when(businessWSCache.getAccountsDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(ACCOUNT_ID, BUSINESS_ACCOUNT)));
    when(businessWSCache.getClientDataFromCache(any()))
        .thenReturn(Mono.just(Map.of(20026L, Client.builder().name("20026 Client").build())));
    when(accountConfigServiceCache.getByAccountId(anyLong()))
        .thenReturn(
            Mono.just(
                AccountConfig.builder()
                    .account(account)
                    .subscriptionStartDate(SUBSCRIPTION_START_DATE)
                    .build()));
    var result = instance.getClientAccountsData(USER_ID);
    assertEquals(
        List.of(
            new ClientAccounts(
                1L, Client.builder().name("20026 Client").build(), List.of(account))),
        result.collectList().block());
  }
}
