package com.cwan.privatefund.business.ws;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.MockitoAnnotations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class BusinessWSApacheClientTest {

  private static final TestHttpClient testClient = new TestHttpClient();
  private static final String JSON = "{\"1\":{\"1\":2,\"2\":1457,\"3\":14956}}";
  private static final FakeWsResponse fakeResponse =
      new FakeWsResponse().setRequestUrl("client/tree/accounts").setStatusCode(200).setBody(JSON);
  private final AuthTokenCore authTokenCore = mock(AuthTokenCore.class);
  private final BusinessWSApacheClient INSTANCE =
      new BusinessWSApacheClient(
          testClient,
          new ServerConfiguration("business", 8084, "business", Scheme.HTTPS),
          authTokenCore);

  @BeforeAll
  void setup() {
    MockitoAnnotations.openMocks(this);
    when(authTokenCore.createApplicationToken()).thenReturn("token");
    testClient.setResponses(fakeResponse);
  }

  @Test
  void get_account_hierarchy() {
    Map<Long, SortedMap<Integer, Long>> ultimateParentMapFromAccounts =
        INSTANCE.getUltimateParentMapFromAccounts(Set.of(1L));
    SortedMap<Integer, Long> account1Hierarchy = ultimateParentMapFromAccounts.get(1L);
    assertNotNull(account1Hierarchy);
    assertEquals(3, account1Hierarchy.size());
  }
}
