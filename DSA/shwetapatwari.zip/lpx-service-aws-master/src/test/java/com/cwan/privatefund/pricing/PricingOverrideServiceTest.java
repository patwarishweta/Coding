package com.cwan.privatefund.pricing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.pricing.model.PricingData;
import com.cwan.privatefund.pricing.model.PricingRequest;
import com.cwan.privatefund.pricing.model.PricingResponse;
import com.google.common.cache.LoadingCache;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class PricingOverrideServiceTest {

  @Mock private LoadingCache<PricingRequest, PricingResponse> pricingCache;
  private PricingOverrideService instance;
  private static final LocalDate CONFIGURE_DATE = LocalDate.of(2022, 1, 1);
  private static final String CONFIGURE_DATE_STRING =
      CONFIGURE_DATE.format(DateTimeFormatter.ofPattern(PricingResponse.DATE_FORMAT));
  private static final Account ACCOUNT = Account.builder().id(1L).build();
  private static final Security SECURITY_1 = Security.builder().securityId(2L).build();
  private static final Security SECURITY_2 = Security.builder().securityId(3L).build();

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    this.instance = new PricingOverrideService(pricingCache);
  }

  @Test
  void should_get_pricing_override_transactions() {
    var transaction1 = createTransaction(SECURITY_1, CONFIGURE_DATE.minusDays(2));
    var transaction2 = createTransaction(SECURITY_2, CONFIGURE_DATE.minusDays(2));
    var price1 = 10.0;
    var price2 = 11.0;
    var expected1 = createOverrideTransaction(SECURITY_1, price1);
    var expected2 = createOverrideTransaction(SECURITY_2, price2);
    Map<String, Map<Long, PricingData>> priceMap =
        Map.of(
            CONFIGURE_DATE_STRING,
            Map.of(
                SECURITY_1.getSecurityId(),
                new PricingData("-1", price1),
                SECURITY_2.getSecurityId(),
                new PricingData("-1", price2)));
    try {
      Mockito.when(pricingCache.get(any())).thenReturn(new PricingResponse(priceMap));
    } catch (ExecutionException e) {
      throw new RuntimeException(e);
    }

    List<Transaction> actual =
        instance.getPricingOverrideTransactions(
            CONFIGURE_DATE, List.of(transaction1, transaction2));
    assertEquals(List.of(expected1, expected2), actual);
  }

  @Test
  void should_filter_out_entry_date_after_configure_date() {
    var transaction = createTransaction(SECURITY_1, CONFIGURE_DATE.plusDays(2));
    var actual = instance.getPricingOverrideTransactions(CONFIGURE_DATE, List.of(transaction));
    assertEquals(List.of(), actual);
  }

  @Test
  void should_handle_null_price() {
    var transaction = createTransaction(SECURITY_1, CONFIGURE_DATE.minusDays(2));
    mockPricingResponse(SECURITY_1, null);
    var actual = instance.getPricingOverrideTransactions(CONFIGURE_DATE, List.of(transaction));
    assertEquals(List.of(), actual);
  }

  private Transaction createTransaction(Security security, LocalDate entryDate) {
    return Transaction.builder()
        .account(ACCOUNT)
        .security(security)
        .currency("USD")
        .entryDate(entryDate)
        .build();
  }

  private Transaction createOverrideTransaction(Security security, double navImpact) {
    return Transaction.builder()
        .account(ACCOUNT)
        .security(security)
        .currency("USD")
        .type("NAV")
        .entryDate(CONFIGURE_DATE)
        .settleDate(CONFIGURE_DATE)
        .tradeDate(CONFIGURE_DATE)
        .navImpact(navImpact)
        .build();
  }

  private void mockPricingResponse(Security security, Double price) {
    Map<String, Map<Long, PricingData>> priceMap =
        Map.of(
            CONFIGURE_DATE_STRING, Map.of(security.getSecurityId(), new PricingData("-1", price)));

    try {
      Mockito.when(pricingCache.get(any())).thenReturn(new PricingResponse(priceMap));
    } catch (ExecutionException e) {
      throw new RuntimeException(e);
    }
  }
}
