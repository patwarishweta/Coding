package com.cwan.privatefund.calculated;

import static com.cwan.privatefund.TestUtil.CALCULATED_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getCalculatedBalance;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.calculated.model.AccountingCalculatedBalance;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import com.cwan.privatefund.transaction.model.NavSchedules;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.NavigableMap;
import java.util.Objects;
import java.util.TreeMap;
import lombok.val;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CalculatedBalanceControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private CalculatedBalanceService calculatedBalanceService;
  @MockBean private AccountService accountService;
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_get_calculated_balances_by_account_id() {
    var calculatedBalance = getCalculatedBalance();
    val accountId = calculatedBalance.getAccount().getId();
    var asOfDate = LocalDate.of(2022, 1, 1);
    var knowledgeDate = LocalDate.of(2022, 1, 2);
    when(calculatedBalanceService.calculateBalances(accountId, asOfDate, knowledgeDate, false))
        .thenReturn(Flux.fromIterable(List.of(calculatedBalance)));
    when(accountService.expandAccountId(accountId)).thenReturn(Flux.just(accountId));
    var actual =
        getCalculatedBalancesEntity(
            format(
                "%s%s%d%s%s%s%s",
                CALCULATED_URI,
                "/account?accountId=",
                accountId,
                "&asOfDate=",
                asOfDate,
                "&knowledgeDate=",
                knowledgeDate));
    assertEquals(List.of(calculatedBalance), actual);
  }

  @Test
  void should_get_calculated_balances_by_account_id_for_accounting() {
    var calculatedBalance = getCalculatedBalance();
    val accountId = calculatedBalance.getAccount().getId();
    var asOfDate = LocalDate.of(2022, 1, 1);
    var knowledgeDate = LocalDate.of(2022, 1, 2);
    when(calculatedBalanceService.calculateBalances(accountId, asOfDate, knowledgeDate, true))
        .thenReturn(Flux.fromIterable(List.of(calculatedBalance)));
    when(accountService.expandAccountId(accountId)).thenReturn(Flux.just(accountId));
    var actual =
        getAccountingCalculatedBalancesEntity(
            format(
                "%s%s%d%s%s%s%s",
                CALCULATED_URI,
                "/account/accounting?accountId=",
                accountId,
                "&asOfDate=",
                asOfDate,
                "&knowledgeDate=",
                knowledgeDate));
    assertEquals(
        List.of(CalculatedBalance.toAccountingCalculatedBalance(calculatedBalance)), actual);
  }

  @Test
  void getNavScheduleTest_emptySchedule() {
    Long accountId = 1L;
    LocalDate beginDate = LocalDate.of(2022, 1, 1);
    LocalDate endDate = LocalDate.of(2022, 1, 31);
    LocalDate knowledgeDate = LocalDate.of(2022, 1, 2);
    NavSchedules navSchedule = NavSchedules.builder().build();
    when(calculatedBalanceService.getNavSchedule(
            accountId, beginDate, endDate, knowledgeDate, false))
        .thenReturn(Flux.fromIterable(List.of(navSchedule)));
    getNavScheduleFailure(
        String.format(
            "%s%s%d%s%s%s%s%s%s",
            CALCULATED_URI,
            "/nav-schedule/accounting?accountId=",
            accountId,
            "&beginDate=",
            beginDate,
            "&endDate=",
            endDate,
            "&knowledgeDate=",
            knowledgeDate));
  }

  @Test
  void getNavScheduleTest_emptySchedule_mock() {
    Long accountId = 1L;
    LocalDate beginDate = LocalDate.of(2022, 1, 1);
    LocalDate endDate = LocalDate.of(2022, 1, 31);
    LocalDate knowledgeDate = LocalDate.of(2022, 1, 2);
    NavSchedules navSchedule =
        NavSchedules.builder()
            .gaapNavSchedule(new TreeMap<>())
            .statNavSchedule(new TreeMap<>())
            .build();
    when(calculatedBalanceService.getNavSchedule(
            accountId, beginDate, endDate, knowledgeDate, true))
        .thenReturn(Flux.fromIterable(List.of(navSchedule)));
    CalculatedBalanceController calculatedBalanceController =
        new CalculatedBalanceController(calculatedBalanceService);
    assertThrows(
        IllegalStateException.class,
        () ->
            calculatedBalanceController
                .getNavScheduleForAccounting(accountId, beginDate, endDate, knowledgeDate)
                .collectList()
                .block());
  }

  @Test
  void getNavScheduleTest() {
    Long accountId = 1L;
    LocalDate beginDate = LocalDate.of(2022, 1, 1);
    LocalDate endDate = LocalDate.of(2022, 1, 31);
    LocalDate knowledgeDate = LocalDate.of(2022, 1, 2);
    NavigableMap<LocalDate, Double> navMap = new TreeMap<>();
    navMap.put(beginDate, 1.0);
    NavSchedules navSchedule =
        NavSchedules.builder().accountId(accountId).navSchedule(navMap).build();
    when(calculatedBalanceService.getNavSchedule(
            accountId, beginDate, endDate, knowledgeDate, false))
        .thenReturn(Flux.fromIterable(List.of(navSchedule)));
    List<NavSchedules> actual =
        getNavSchedule(
            String.format(
                "%s%s%d%s%s%s%s%s%s",
                CALCULATED_URI,
                "/nav-schedule?accountId=",
                accountId,
                "&beginDate=",
                beginDate,
                "&endDate=",
                endDate,
                "&knowledgeDate=",
                knowledgeDate));
    assertEquals(List.of(navSchedule), actual);
  }

  private List<CalculatedBalance> getCalculatedBalancesEntity(String uri) {
    return List.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(CalculatedBalance.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private List<AccountingCalculatedBalance> getAccountingCalculatedBalancesEntity(String uri) {
    return List.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(AccountingCalculatedBalance.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private List<NavSchedules> getNavSchedule(String uri) {
    return List.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(NavSchedules.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private void getNavScheduleFailure(String uri) {
    Objects.requireNonNull(exchangeForEntity(uri).expectStatus().is5xxServerError());
  }

  private WebTestClient.ResponseSpec exchangeForEntity(String uri) {
    return webClient.method(HttpMethod.GET).uri(uri).exchange();
  }
}
