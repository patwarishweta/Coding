package com.cwan.privatefund.documentmanager;

import static com.cwan.privatefund.TestUtil.DOCUMENT_MANAGER_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getDocumentManagerData;
import static com.cwan.privatefund.TestUtil.getFile;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.ca.json2.utils.JsonUtils2;
import com.cwan.lpx.domain.Document;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import java.net.URI;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class LpxDocumentManagerControllerTest extends AuthenticatedControllerTest {

  private static final DocumentManagerData DOCUMENT_MANAGER_DATA = getDocumentManagerData();
  private static final Document DOCUMENT = DOCUMENT_MANAGER_DATA.getDocument();
  private final String TAG = DOCUMENT_MANAGER_DATA.getTags().iterator().next();
  private final String NAME = DOCUMENT.getFileName();
  private final Long DIRECTORY_ID = DOCUMENT.getDirectoryId();
  private static final Long ACCOUNT_ID = DOCUMENT.getAccount().getId();
  private static final ClassPathResource FILE = getFile();
  private static final DocumentUploadResponse DOCUMENT_UPLOAD_RESPONSE =
      DocumentUploadResponse.builder()
          .documentDetails(DOCUMENT_MANAGER_DATA)
          .uploadedFileDetails(
              List.of(
                  DocumentUploadFileDetails.builder()
                      .documentId(DOCUMENT.getId())
                      .fileName(DOCUMENT.getFileName())
                      .cloudStorageId(DOCUMENT.getCloudStorageId())
                      .status(DocumentUploadStatus.SUCCESS)
                      .build()))
          .build();
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;
  @Autowired private WebTestClient webClient;
  @MockBean private LpxDocumentManagerService lpxDocumentManagerService;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_get_document_by_account_id_and_tag_successfully() {
    Mockito.when(lpxDocumentManagerService.getActiveDocumentsByAccountIdAndTag(ACCOUNT_ID, TAG))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA));
    var actual = getActiveDocumentsByAccountIdAndTag(TAG).blockFirst();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_get_document_by_account_id_and_name_successfully() {
    Mockito.when(
            lpxDocumentManagerService.getActiveDocumentsByAccountIdAndFileName(ACCOUNT_ID, NAME))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA));
    var actual = getActiveDocumentsByAccountIdAndFileName(NAME).blockFirst();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_get_document_by_directory_id_successfully() {
    Mockito.when(lpxDocumentManagerService.getActiveDocumentsByDirectoryId(DIRECTORY_ID))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA));
    var actual = getActiveDocumentsByDirectoryId(DIRECTORY_ID).blockFirst();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_get_disabled_document_by_account_id_successfully()
      throws ExecutionException, InterruptedException {
    Mockito.when(lpxDocumentManagerService.getDisabledDocumentsForAccount(ACCOUNT_ID))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA));
    var actual = getDisabledDocumentsByAccount().blockFirst();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_get_active_document_by_account_id_successfully()
      throws ExecutionException, InterruptedException {
    Mockito.when(lpxDocumentManagerService.getActiveDocumentsForAccount(ACCOUNT_ID))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA));
    var actual = getActiveDocumentsByAccount().blockFirst();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_upload_document_successfully() {
    when(lpxDocumentManagerService.saveNewDocument(any(), eq(DOCUMENT_MANAGER_DATA)))
        .thenReturn(Mono.just(DOCUMENT_MANAGER_DATA));
    var result = postForDocumentUpload().collectList().share().block();
    assertEquals(List.of(DOCUMENT_MANAGER_DATA), result);
  }

  @Test
  void should_get_document_by_account_id_and_null_directory_id_successfully() {
    Mockito.when(lpxDocumentManagerService.getActiveDocumentsWithoutDirectoryByAccount(ACCOUNT_ID))
        .thenReturn(Flux.just(DOCUMENT_MANAGER_DATA));
    var actual = getActiveDocumentsWithoutDirectoryByAccount().blockFirst();
    assertEquals(DOCUMENT_MANAGER_DATA, actual);
  }

  @Test
  void should_upload_document_successfully_new_method() {
    when(lpxDocumentManagerService.uploadDocument(any(DocumentUploadRequest.class)))
        .thenReturn(
            Mono.just(ResponseEntity.created(URI.create("")).body(DOCUMENT_UPLOAD_RESPONSE)));
    var result = postForNewDocumentUpload().block();
    assertEquals(JsonUtils2.objToJson(DOCUMENT_UPLOAD_RESPONSE), JsonUtils2.objToJson(result));
  }

  @Test
  void should_not_upload_document_successfully_new_method_bad_request() {
    var result1 = postForNewDocumentUpload_BadRequest_MissingFiles().block();
    assertNotNull(result1);
    assertEquals("400 BAD_REQUEST \"files cannot be null or empty\"", result1);
  }

  private Flux<DocumentManagerData> getActiveDocumentsByAccountIdAndTag(final String tag) {
    return exchangeForEntity(
            format(
                "%s%s%s%s%s",
                DOCUMENT_MANAGER_URI,
                "/account/",
                LpxDocumentManagerControllerTest.ACCOUNT_ID,
                "/tag/",
                tag))
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody()
        .share();
  }

  private Flux<DocumentManagerData> getActiveDocumentsByAccountIdAndFileName(final String name) {
    return exchangeForEntity(
            format(
                "%s%s%s%s%s",
                DOCUMENT_MANAGER_URI,
                "/account/",
                LpxDocumentManagerControllerTest.ACCOUNT_ID,
                "/name/",
                name))
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody()
        .share();
  }

  private Flux<DocumentManagerData> getActiveDocumentsByDirectoryId(final Long directoryId) {
    return exchangeForEntity(format("%s%s%s", DOCUMENT_MANAGER_URI, "/directory/", directoryId))
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody()
        .share();
  }

  private Flux<DocumentManagerData> getDisabledDocumentsByAccount() {
    return exchangeForEntity(
            format(
                "%s%s%s%s",
                DOCUMENT_MANAGER_URI,
                "/account/",
                LpxDocumentManagerControllerTest.ACCOUNT_ID,
                "/disabled"))
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody()
        .share();
  }

  private Flux<DocumentManagerData> getActiveDocumentsByAccount() {
    return exchangeForEntity(
            format(
                "%s%s%s%s",
                DOCUMENT_MANAGER_URI,
                "/account/",
                LpxDocumentManagerControllerTest.ACCOUNT_ID,
                "/active"))
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody()
        .share();
  }

  private Flux<DocumentManagerData> getActiveDocumentsWithoutDirectoryByAccount() {
    return exchangeForEntity(
            format(
                "%s%s%s%s",
                DOCUMENT_MANAGER_URI,
                "/account/",
                LpxDocumentManagerControllerTest.ACCOUNT_ID,
                "/no-directory"))
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody()
        .share();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(final String uri) {
    return webClient.method(HttpMethod.GET).uri(uri).exchange();
  }

  private Flux<DocumentManagerData> postForDocumentUpload() {
    var multipartBodyBuilder = new MultipartBodyBuilder();
    multipartBodyBuilder.part("file", FILE);
    multipartBodyBuilder.part("documentManagerData", JsonUtils2.objToJson(DOCUMENT_MANAGER_DATA));
    return webClient
        .method(HttpMethod.POST)
        .uri(com.cwan.privatefund.TestUtil.DOCUMENT_MANAGER_URI)
        .contentType(MediaType.MULTIPART_FORM_DATA)
        .body(BodyInserters.fromMultipartData(multipartBodyBuilder.build()))
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentManagerData.class)
        .getResponseBody();
  }

  private Mono<DocumentUploadResponse> postForNewDocumentUpload() {
    var multipartBodyBuilder = new MultipartBodyBuilder();
    multipartBodyBuilder.part("files", FILE);
    multipartBodyBuilder.part("documentDetails", JsonUtils2.objToJson(DOCUMENT_MANAGER_DATA));
    return webClient
        .method(HttpMethod.POST)
        .uri(com.cwan.privatefund.TestUtil.DOCUMENT_MANAGER_URI + "/upload")
        .contentType(MediaType.MULTIPART_FORM_DATA)
        .body(BodyInserters.fromMultipartData(multipartBodyBuilder.build()))
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentUploadResponse.class)
        .getResponseBody()
        .last();
  }

  private Mono<String> postForNewDocumentUpload_BadRequest_MissingFiles() {
    var multipartBodyBuilder = new MultipartBodyBuilder();
    multipartBodyBuilder.part("documentDetails", JsonUtils2.objToJson(DOCUMENT_MANAGER_DATA));
    return webClient
        .method(HttpMethod.POST)
        .uri(com.cwan.privatefund.TestUtil.DOCUMENT_MANAGER_URI + "/upload")
        .contentType(MediaType.MULTIPART_FORM_DATA)
        .body(BodyInserters.fromMultipartData(multipartBodyBuilder.build()))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .returnResult(String.class)
        .getResponseBody()
        .last();
  }
}
