package com.cwan.privatefund.basis.ws;

import static com.cwan.privatefund.TestUtil.getBasis;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.MockitoAnnotations.openMocks;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.cwan.privatefund.basis.ws.model.Basis;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BasisWSClientTest {

  private static final long ACCOUNT_ID = 1337L;
  private static final Basis BASIS = getBasis();

  private static final TestHttpClient testClient = new TestHttpClient();
  private static final String BASIS_IDS_JSON = "[" + BASIS.getBasisId() + "]";
  private static String BASES_JSON;

  static {
    try {
      BASES_JSON = "[" + new ObjectMapper().writeValueAsString(BASIS) + "]";
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
  }

  private static final FakeWsResponse fakeEnabledBasesResponse =
      new FakeWsResponse()
          .setRequestUrl("v2/accounts/" + ACCOUNT_ID + "/bases")
          .setStatusCode(200)
          .setBody(BASIS_IDS_JSON);
  private static final FakeWsResponse fakeBasesResponse =
      new FakeWsResponse().setRequestUrl("v2/bases").setStatusCode(200).setBody(BASES_JSON);

  private BasisWSClient instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    instance =
        new BasisWSClient(
            testClient, new ServerConfiguration("basis-w", 8084, "basis-ws", Scheme.HTTPS));
  }

  @Test
  void should_return_enabled_bases() {
    testClient.setResponses(fakeEnabledBasesResponse);
    var actual = instance.getEnabledBases(ACCOUNT_ID);
    assertEquals(List.of(BASIS.getBasisId()), actual);
  }

  @Test
  void should_return_bases() {
    testClient.setResponses(fakeBasesResponse);
    var actual = instance.getBases();
    assertEquals(List.of(BASIS), actual);
  }
}
