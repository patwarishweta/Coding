package com.cwan.privatefund.capital.call.model;

import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallDocument;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class ComprehensiveAuditDetailTest {

  @Test
  void testTransformDocumentToAuditDetail_Basic() {
    StepVerifier.create(
            ComprehensiveAuditDetail.transformDocumentToAuditDetail(
                mockCapitalCallDocumentWithSingleAudit()))
        .expectNextMatches(
            auditDetail ->
                auditDetail
                        .documentId()
                        .equals(mockCapitalCallDocumentWithSingleAudit().documentId())
                    && auditDetail
                        .audit()
                        .equals(mockCapitalCallDocumentWithSingleAudit().audit().get(0)))
        .verifyComplete();
  }

  @Test
  void testTransformDocumentToAuditDetail_EmptyAuditList() {
    StepVerifier.create(
            ComprehensiveAuditDetail.transformDocumentToAuditDetail(
                mockCapitalCallDocumentWithNoAudits()))
        .verifyComplete();
  }

  @Test
  void testTransformDocumentToAuditDetail_MultipleAudits() {
    StepVerifier.create(
            ComprehensiveAuditDetail.transformDocumentToAuditDetail(
                mockCapitalCallDocumentWithMultipleAudits()))
        .expectNextCount(mockCapitalCallDocumentWithMultipleAudits().audit().size())
        .verifyComplete();
  }

  private CapitalCallDocument mockCapitalCallDocumentWithSingleAudit() {
    return CapitalCallDocument.builder()
        .documentId(1L)
        .audit(Collections.singletonList(CapitalCallAudit.builder().build()))
        .build();
  }

  private CapitalCallDocument mockCapitalCallDocumentWithNoAudits() {
    return CapitalCallDocument.builder().documentId(1L).audit(Collections.emptyList()).build();
  }

  private CapitalCallDocument mockCapitalCallDocumentWithMultipleAudits() {
    return CapitalCallDocument.builder()
        .documentId(1L)
        .audit(
            Arrays.asList(CapitalCallAudit.builder().build(), CapitalCallAudit.builder().build()))
        .build();
  }
}
