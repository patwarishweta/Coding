package com.cwan.privatefund.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.thymeleaf.templatemode.TemplateMode;

class ThymeleafConfigTest {

  private final ThymeleafConfig config = new ThymeleafConfig();

  @Test
  void thymeleafTemplateEngine() {
    var engine = config.thymeleafTemplateEngine();
    assertNotNull(engine);
  }

  @Test
  void htmlTemplateResolver() {
    var resolver = config.htmlTemplateResolver();
    assertNotNull(resolver);
    assertEquals("/templates/", resolver.getPrefix());
    assertEquals(".html", resolver.getSuffix());
    assertEquals(TemplateMode.HTML, resolver.getTemplateMode());
    assertEquals("UTF-8", resolver.getCharacterEncoding());
    assertEquals(1, resolver.getOrder());
  }

  @Test
  void xmlTemplateResolver() {
    var resolver = config.xmlTemplateResolver();
    assertNotNull(resolver);
    assertEquals("/templates/", resolver.getPrefix());
    assertEquals(".xml", resolver.getSuffix());
    assertEquals(TemplateMode.XML, resolver.getTemplateMode());
    assertEquals("UTF-8", resolver.getCharacterEncoding());
    assertEquals(2, resolver.getOrder());
  }
}
