package com.cwan.privatefund.comment;

import static com.cwan.privatefund.TestUtil.getComment;
import static com.cwan.privatefund.TestUtil.getCommentEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentEntity;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

public class CommentServiceTest {

  @Mock private CommentRepository commentRepository;
  @Mock private CommentEntityTransformer commentEntityTransformer;
  @Mock private CommentTransformer commentTransformer;
  private static final Long COMMENT_ID = 9L;
  private static final CommentEntity COMMENT_ENTITY = getCommentEntity();
  private static final Comment COMMENT = getComment();
  private static final List<Comment> COMMENTS = List.of(COMMENT);
  private CommentService instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(commentEntityTransformer.apply(eq(COMMENT))).thenReturn(COMMENT_ENTITY);
    when(commentTransformer.apply(eq(COMMENT_ENTITY))).thenReturn(COMMENT);
    instance = new CommentService(commentRepository, commentEntityTransformer, commentTransformer);
  }

  @Test
  void should_get_comments_by_id() {
    var documentId = 1L;
    when(commentRepository.findAllByDocumentId(eq(documentId))).thenReturn(List.of(COMMENT_ENTITY));
    var actual = instance.getCommentsByDocumentId(documentId).collectList().block();
    assertEquals(COMMENTS, actual);
  }

  @Test
  void should_delete_comments_by_id() {
    var commentIds = Set.of(COMMENT_ID);
    instance.deleteCommentsById(commentIds);
    verify(commentRepository).deleteAllById(commentIds);
  }

  @Test
  void should_add_comments() {
    var newEntity = CommentEntity.builder().id(COMMENT_ID).build();
    var newComment = Comment.builder().id(COMMENT_ID).build();
    when(commentRepository.saveAndFlush(eq(COMMENT_ENTITY))).thenReturn(newEntity);
    when(commentTransformer.apply(eq(newEntity))).thenReturn(newComment);
    var actual = instance.addComments(COMMENTS).collectList().block();
    assertEquals(List.of(newComment), actual);
  }

  @Test
  void should_not_add_comments_with_id() {
    var comment = Comment.builder().id(COMMENT_ID).build();
    var actual = instance.addComments(Set.of(comment)).collectList().block();
    assertTrue(Objects.requireNonNull(actual).isEmpty());
  }
}
