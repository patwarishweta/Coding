package com.cwan.privatefund.fxrate;

import static com.cwan.privatefund.fxrate.FxRateJobRunner.AVERAGE_FX_RATE_START_DATE;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Currency;
import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.fxrate.api.FXRates;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.privatefund.accountconfig.AccountConfigServiceCache;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import com.cwan.privatefund.fxrate.source.AccountFxSourceService;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.security.currency.SecurityCurrencyService;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

class FxRateJobRunnerTest {

  @Mock private AccountConfigServiceCache accountConfigServiceCache;
  @Mock private AverageFxRateCalculator averageFxRateCalculator;
  @Mock private Transactions transactions;
  @Mock private BusinessWSCache businessWSCache;
  @Mock private SecurityService securityService;
  @Mock private LpxFxRateService lpxFxRateService;
  @Mock private FXRates fxRates;
  @Mock private LpxFundMasterService lpxFundMasterService;
  @Mock private SecurityCurrencyService securityCurrencyService;
  @Mock private FxServiceApacheClient fxServiceApacheClient;
  @Mock private AccountFxSourceService accountFxSourceService;
  private FxRateJobRunner fxRateJobRunner;
  private static final Long ACCOUNT_ID_1 = 1L;
  private static final Long ACCOUNT_ID_2 = 2L;
  private static final LocalDate FEATURE_START_DATE = LocalDate.now().plusMonths(1).minusDays(2);
  private static final AccountConfig ACCOUNT_CONFIG_1 = createAccountConfig(ACCOUNT_ID_1);
  private static final AccountConfig ACCOUNT_CONFIG_2 = createAccountConfig(ACCOUNT_ID_2);
  private static final Long SECURITY_ID_1 = 10L;
  private static final Long SECURITY_ID_2 = 11L;
  private static final Transaction TRANSACTION_1 = createTransaction(ACCOUNT_ID_1, SECURITY_ID_1);
  private static final Transaction TRANSACTION_2 = createTransaction(ACCOUNT_ID_1, SECURITY_ID_2);
  private static final Transaction TRANSACTION_3 = createTransaction(ACCOUNT_ID_2, SECURITY_ID_1);
  private static final Long BASE_CURRENCY_ID_1 = 20L;
  private static final Long BASE_CURRENCY_ID_2 = 21L;
  private static final Long LOCAL_CURRENCY_ID_1 = 30L;
  private static final Long LOCAL_CURRENCY_ID_2 = 31L;
  private static final Long SOURCE_ID = 40L;
  private static final BusinessAccount BUSINESS_ACCOUNT_1 =
      createBusinessAccount(ACCOUNT_ID_1, BASE_CURRENCY_ID_1);
  private static final BusinessAccount BUSINESS_ACCOUNT_2 =
      createBusinessAccount(ACCOUNT_ID_2, BASE_CURRENCY_ID_2);
  private static final Security SECURITY_1 = createSecurity(SECURITY_ID_1, LOCAL_CURRENCY_ID_1);
  private static final Security SECURITY_2 = createSecurity(SECURITY_ID_2, LOCAL_CURRENCY_ID_2);
  private static final Map<Long, ReportingFrequency> REPORTING_FREQUENCY_MAP =
      Map.of(
          SECURITY_ID_1, ReportingFrequency.QUARTERLY, SECURITY_ID_2, ReportingFrequency.QUARTERLY);
  private static final AverageFxRateMap AVERAGE_FX_RATE_MAP_1 = createAverageFxRateMap();
  private static final AverageFxRateMap AVERAGE_FX_RATE_MAP_2 = new AverageFxRateMap(Map.of());
  private static final FXRate FX_RATE_1 =
      createFxRate(BASE_CURRENCY_ID_1, LOCAL_CURRENCY_ID_1, FEATURE_START_DATE.plusDays(2));
  private static final FXRate FX_RATE_2 =
      createFxRate(BASE_CURRENCY_ID_1, LOCAL_CURRENCY_ID_2, FEATURE_START_DATE.plusDays(1));
  private static final FXRate FX_RATE_3 =
      createFxRate(BASE_CURRENCY_ID_1, LOCAL_CURRENCY_ID_2, FEATURE_START_DATE.plusDays(2));
  private static final FXRate FX_RATE_4 =
      createFxRate(BASE_CURRENCY_ID_2, LOCAL_CURRENCY_ID_1, FEATURE_START_DATE);
  private static final FXRate FX_RATE_5 =
      createFxRate(BASE_CURRENCY_ID_2, LOCAL_CURRENCY_ID_1, FEATURE_START_DATE.plusDays(1));
  private static final FXRate FX_RATE_6 =
      createFxRate(BASE_CURRENCY_ID_2, LOCAL_CURRENCY_ID_1, FEATURE_START_DATE.plusDays(2));
  private static final FXRate FX_RATE_7 =
      createFxRate(BASE_CURRENCY_ID_1, LOCAL_CURRENCY_ID_1, FEATURE_START_DATE);
  private static final FXRate FX_RATE_8 =
      createFxRate(BASE_CURRENCY_ID_1, LOCAL_CURRENCY_ID_1, FEATURE_START_DATE.plusDays(1));
  private static final FXRate FX_RATE_9 =
      createFxRate(BASE_CURRENCY_ID_1, LOCAL_CURRENCY_ID_2, FEATURE_START_DATE);

  private static final AccountFxSource ACCOUNT_FX_SOURCE_1 = createAccountFxSource(ACCOUNT_ID_1);
  private static final AccountFxSource ACCOUNT_FX_SOURCE_2 = createAccountFxSource(ACCOUNT_ID_2);

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    mockFxRates();
    mockSecurityData();
    mockAccountData();

    this.fxRateJobRunner =
        new FxRateJobRunner(
            accountConfigServiceCache,
            averageFxRateCalculator,
            transactions,
            businessWSCache,
            securityService,
            lpxFxRateService,
            fxRates,
            lpxFundMasterService,
            securityCurrencyService,
            fxServiceApacheClient,
            accountFxSourceService);
  }

  @Test
  void test_run_daily_fx_rate_job() {
    fxRateJobRunner.runDailyFxRateJob();
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_1, FX_RATE_7, FX_RATE_8));
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_2, FX_RATE_3, FX_RATE_9));
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_4, FX_RATE_5, FX_RATE_6));
  }

  @Test
  void test_run_recalculation_fx_rate_job_with_securities_provided() {
    fxRateJobRunner.runRecalculationFxRateJob(ACCOUNT_ID_1, Set.of(SECURITY_ID_1, SECURITY_ID_2));
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_1, FX_RATE_7, FX_RATE_8));
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_2, FX_RATE_3, FX_RATE_9));
  }

  @Test
  void test_run_recalculation_fx_rate_job_with_securities_not_provided() {
    fxRateJobRunner.runRecalculationFxRateJob(ACCOUNT_ID_1, Set.of());
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_1, FX_RATE_7, FX_RATE_8));
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_2, FX_RATE_3, FX_RATE_9));
  }

  @Test
  void test_error_on_local_currency_is_handled() {
    when(fxRates.addFXRates(Set.of(FX_RATE_1, FX_RATE_7, FX_RATE_8)))
        .thenThrow(new RuntimeException());
    try {
      fxRateJobRunner.runDailyFxRateJob();
    } catch (Exception e) {
      fail("Exception should be handled within method");
    }
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_2, FX_RATE_3, FX_RATE_9));
    verify(fxRates, times(1)).addFXRates(Set.of(FX_RATE_4, FX_RATE_5, FX_RATE_6));
  }

  private void mockFxRates() {
    // FX rates that are not already in the database
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_1,
            LOCAL_CURRENCY_ID_1,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE.plusDays(2)))
        .thenReturn(FX_RATE_1);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_1,
            LOCAL_CURRENCY_ID_2,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE.plusDays(1)))
        .thenReturn(FX_RATE_2);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_1,
            LOCAL_CURRENCY_ID_2,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE.plusDays(2)))
        .thenReturn(FX_RATE_3);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_2,
            LOCAL_CURRENCY_ID_1,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE))
        .thenReturn(FX_RATE_4);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_2,
            LOCAL_CURRENCY_ID_1,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE.plusDays(1)))
        .thenReturn(FX_RATE_5);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_2,
            LOCAL_CURRENCY_ID_1,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE.plusDays(2)))
        .thenReturn(FX_RATE_6);

    // FX rates that are already in the database
    when(lpxFxRateService.getAverageFxRates(BASE_CURRENCY_ID_1, SOURCE_ID))
        .thenReturn(AVERAGE_FX_RATE_MAP_1);
    when(lpxFxRateService.getAverageFxRates(BASE_CURRENCY_ID_2, SOURCE_ID))
        .thenReturn(AVERAGE_FX_RATE_MAP_2);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_1,
            LOCAL_CURRENCY_ID_1,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE))
        .thenReturn(FX_RATE_7);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_1,
            LOCAL_CURRENCY_ID_1,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE.plusDays(1)))
        .thenReturn(FX_RATE_8);
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID,
            BASE_CURRENCY_ID_1,
            LOCAL_CURRENCY_ID_2,
            ReportingFrequency.QUARTERLY,
            FEATURE_START_DATE))
        .thenReturn(FX_RATE_9);
  }

  private void mockSecurityData() {
    when(securityService.getSecurities(null, null, List.of(SECURITY_ID_1, SECURITY_ID_2)))
        .thenReturn(Mono.just(List.of(SECURITY_1, SECURITY_2)));
    when(securityService.getSecurities(null, null, List.of(SECURITY_ID_2, SECURITY_ID_1)))
        .thenReturn(Mono.just(List.of(SECURITY_1, SECURITY_2)));
    when(lpxFundMasterService.getReportingFrequencies(Set.of(SECURITY_ID_1, SECURITY_ID_2)))
        .thenReturn(REPORTING_FREQUENCY_MAP);
  }

  private void mockAccountData() {
    // account configs
    when(accountConfigServiceCache.getByAccountId(ACCOUNT_ID_1))
        .thenReturn(Mono.just(ACCOUNT_CONFIG_1));
    when(accountConfigServiceCache.getAllAccountConfigs())
        .thenReturn(Mono.just(List.of(ACCOUNT_CONFIG_1, ACCOUNT_CONFIG_2)));

    // business accounts
    when(businessWSCache.getAccountsData(Set.of(ACCOUNT_ID_1)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT_1)));
    when(businessWSCache.getAccountsData(Set.of(ACCOUNT_ID_1, ACCOUNT_ID_2)))
        .thenReturn(Mono.just(List.of(BUSINESS_ACCOUNT_1, BUSINESS_ACCOUNT_2)));

    // account fx sources
    when(fxServiceApacheClient.getAccountFxSources(ACCOUNT_ID_1))
        .thenReturn(Set.of(ACCOUNT_FX_SOURCE_1));
    when(fxServiceApacheClient.getAccountFxSources(ACCOUNT_ID_2))
        .thenReturn(Set.of(ACCOUNT_FX_SOURCE_2));

    // transactions
    when(transactions.getTransactionsByAccountIdsNonReactive(Set.of(ACCOUNT_ID_1, ACCOUNT_ID_2)))
        .thenReturn(Set.of(TRANSACTION_1, TRANSACTION_2, TRANSACTION_3));
    when(transactions.getTransactionsByAccountIdsNonReactive(Set.of(ACCOUNT_ID_1)))
        .thenReturn(Set.of(TRANSACTION_1, TRANSACTION_2));
  }

  private static AccountConfig createAccountConfig(Long accountId) {
    return AccountConfig.builder()
        .account(Account.builder().id(accountId).build())
        .attributes(
            Map.of(AVERAGE_FX_RATE_START_DATE, FxRateJobRunnerTest.FEATURE_START_DATE.toString()))
        .build();
  }

  private static Transaction createTransaction(Long accountId, Long securityId) {
    return Transaction.builder()
        .account(Account.builder().id(accountId).build())
        .security(Security.builder().securityId(securityId).build())
        .build();
  }

  private static BusinessAccount createBusinessAccount(Long accountId, Long currencyId) {
    return BusinessAccount.builder()
        .id(accountId)
        .functionalCurrencyId(currencyId)
        .currencyFxRateSourceId(FxRateJobRunnerTest.SOURCE_ID)
        .build();
  }

  private static Security createSecurity(Long securityId, Long currencyId) {
    return Security.builder()
        .securityId(securityId)
        .currency(Currency.builder().currencyId(currencyId).build())
        .build();
  }

  private static AverageFxRateMap createAverageFxRateMap() {
    Map<ReportingFrequency, Map<LocalDate, Double>> ratesForLocalCurrency1 =
        Map.of(
            ReportingFrequency.QUARTERLY,
            Map.of(FEATURE_START_DATE, 1.0, FEATURE_START_DATE.plusDays(1), 1.0));
    Map<ReportingFrequency, Map<LocalDate, Double>> ratesForLocalCurrency2 =
        Map.of(ReportingFrequency.QUARTERLY, Map.of(FEATURE_START_DATE, 1.0));
    return new AverageFxRateMap(
        Map.of(
            LOCAL_CURRENCY_ID_1,
            ratesForLocalCurrency1,
            LOCAL_CURRENCY_ID_2,
            ratesForLocalCurrency2));
  }

  private static FXRate createFxRate(Long baseCurrencyId, Long localCurrencyId, LocalDate date) {
    return FXRate.builder()
        .reportingFrequency(ReportingFrequency.QUARTERLY)
        .baseCurrencyId(baseCurrencyId)
        .localCurrencyId(localCurrencyId)
        .fxRateSourceId(SOURCE_ID)
        .date(date)
        .fxRate(1.0)
        .averageFxRate(1.0)
        .build();
  }

  private static AccountFxSource createAccountFxSource(Long accountId) {
    return AccountFxSource.builder()
        .accountId(accountId)
        .date(LocalDate.MIN)
        .basisId(AccountFxSource.NOT_BASIS_SPECIFIC_ID)
        .fxRateSourceId(SOURCE_ID)
        .build();
  }
}
