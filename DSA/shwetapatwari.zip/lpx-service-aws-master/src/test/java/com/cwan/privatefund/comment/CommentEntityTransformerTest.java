package com.cwan.privatefund.comment;

import static com.cwan.privatefund.TestUtil.getComment;
import static com.cwan.privatefund.TestUtil.getCommentEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CommentEntityTransformerTest {

  @Test
  void should_convert_comment_to_comment_entity() {
    var transformer = new CommentEntityTransformer();
    var actual = transformer.apply(getComment());
    assertEquals(getCommentEntity(), actual);
  }
}
