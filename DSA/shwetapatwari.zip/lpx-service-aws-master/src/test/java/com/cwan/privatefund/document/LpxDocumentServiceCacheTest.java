package com.cwan.privatefund.document;

import static com.cwan.privatefund.constant.RedisConstants.DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.document.model.DocumentTypeData;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

class LpxDocumentServiceCacheTest {

  @Mock private LpxDocumentServiceClient lpxDocumentServiceClient;
  @Mock private RedisTemplate redisTemplate;
  @Mock private HashOperations hashOperations;
  private LpxDocumentServiceCache lpxDocumentServiceCache;
  private final String DOCUMENT_TYPE = "some_doc_type";
  private final DocumentTypeData DOCUMENT_TYPE_DATA = buildDocumentTypeData();
  private final Map<String, DocumentTypeData> DOCUMENT_TYPE_DATA_MAP =
      Map.of(DOCUMENT_TYPE, DOCUMENT_TYPE_DATA);

  @BeforeEach
  void setUp() {
    openMocks(this);
    lpxDocumentServiceCache = new LpxDocumentServiceCache(lpxDocumentServiceClient, redisTemplate);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
  }

  @Test
  void testGetDocumentTypeData_shouldGetDocumentTypeData() {
    when(redisTemplate.opsForHash().get(DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE, DOCUMENT_TYPE))
        .thenReturn(null);
    when(lpxDocumentServiceClient.getAllDocumentTypeData())
        .thenReturn(Mono.just(DOCUMENT_TYPE_DATA_MAP));
    var actual = lpxDocumentServiceCache.getDocumentTypeData(DOCUMENT_TYPE).block();
    assertEquals(DOCUMENT_TYPE_DATA, actual);
  }

  @Test
  void testGetDocumentTypeData_shouldGetDocumentTypeData_FromCache() {
    when(redisTemplate.opsForHash().get(DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE, DOCUMENT_TYPE))
        .thenReturn(DOCUMENT_TYPE_DATA);
    var actual = lpxDocumentServiceCache.getDocumentTypeData(DOCUMENT_TYPE).block();
    assertEquals(DOCUMENT_TYPE_DATA, actual);
  }

  @Test
  void testGetDocumentTypeData_invalidDocumentType() {
    when(redisTemplate.opsForHash().get(DOCUMENT_SERVICE_DOCUMENT_TYPES_CACHE, DOCUMENT_TYPE))
        .thenReturn(null);
    when(lpxDocumentServiceClient.getAllDocumentTypeData()).thenReturn(Mono.just(Map.of()));
    ResponseStatusException ex =
        assertThrows(
            ResponseStatusException.class,
            () -> lpxDocumentServiceCache.getDocumentTypeData(DOCUMENT_TYPE).block());
    assertEquals("Invalid document type.", ex.getReason());
    assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
  }

  private DocumentTypeData buildDocumentTypeData() {
    return DocumentTypeData.builder()
        .documentType(DOCUMENT_TYPE)
        .id(123)
        .category("Capital Call")
        .needsCustomAllocation(Boolean.TRUE)
        .build();
  }
}
