package com.cwan.privatefund.balance;

import static com.cwan.privatefund.TestUtil.getAccount;
import static com.cwan.privatefund.TestUtil.getBalance;
import static com.cwan.privatefund.TestUtil.getDocument;
import static com.cwan.privatefund.TestUtil.getSecurity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.balance.api.Balances;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class LpxBalanceEntityServiceTest {

  @Mock private AccountService accountService;
  @Mock private Balances balances;
  @Mock private SecurityService securityService;
  @Mock private Documents documents;
  private LpxBalanceEntityService lpxBalanceEntityService;
  private static final Account ACCOUNT = getAccount();
  private static final Security SECURITY = getSecurity();
  private static final Document DOCUMENT = getDocument();
  private static final Long ACCOUNT_ID = 9L;
  private static final Balance BALANCE = getBalance(ACCOUNT_ID);
  private static final Set<Balance> BALANCE_SET = Set.of(BALANCE);
  private static final Set<Long> BALANCE_IDS = Set.of(1L);
  private static final Mono<Account> ACCOUNT_MONO = Mono.just(ACCOUNT);
  private static final Mono<Security> SECURITY_MONO = Mono.just(SECURITY);

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(documents.getDocumentById(anyLong())).thenReturn(Mono.just(DOCUMENT));
    lpxBalanceEntityService =
        new LpxBalanceEntityService(accountService, balances, securityService, documents);
  }

  @Test
  void should_add_balances() {
    when(balances.addBalance(eq(BALANCE_SET))).thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxBalanceEntityService.addBalance(BALANCE_SET).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_get_balances_by_id() {
    when(balances.getBalancesByIds(eq(BALANCE_IDS))).thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxBalanceEntityService.getBalancesByIds(BALANCE_IDS).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_delete_balances_by_id() {
    when(balances.deleteBalanceById(eq(BALANCE_IDS))).thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxBalanceEntityService.deleteBalanceById(BALANCE_IDS).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_update_balance_info() {
    when(balances.updateBalanceInfo(eq(BALANCE_SET))).thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxBalanceEntityService.updateBalanceInfo(BALANCE_SET).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_get_balances_by_account_and_date() {
    Set<Long> accountIds = Set.of(ACCOUNT_ID);
    var date = LocalDate.now();
    when(balances.getBalancesByAccountAndDate(eq(accountIds), eq(date)))
        .thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxBalanceEntityService.getBalancesByAccountAndDate(accountIds, date).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_get_balances_by_document_ids() {
    Set<Long> documentIds = Set.of(42L);
    when(balances.getBalancesByDocumentIds(eq(documentIds))).thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual = lpxBalanceEntityService.getBalancesByDocumentIds(documentIds).blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_get_balances_by_account_and_security_id_and_type() {
    Long securityId = 2L;
    var type = "Type";
    when(balances.getBalanceByAccountAndSecurityIdAndType(eq(ACCOUNT_ID), eq(securityId), eq(type)))
        .thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual =
        lpxBalanceEntityService
            .getBalanceByAccountAndSecurityIdAndType(ACCOUNT_ID, securityId, type)
            .blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  void should_get_balances_by_account_and_balance_date_and_knowledge_start_date() {
    var balanceDate = LocalDate.of(2022, 1, 1);
    var knowledgeStartDate = LocalDateTime.of(2022, 2, 2, 12, 0);
    when(balances.getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
            eq(ACCOUNT_ID), eq(balanceDate), eq(knowledgeStartDate)))
        .thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual =
        lpxBalanceEntityService
            .getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
                ACCOUNT_ID, balanceDate, knowledgeStartDate)
            .blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  public void test_getBalancesOnBalanceDate() {
    var balanceDate = LocalDate.of(2022, 1, 1);
    var knowledgeStartDate = LocalDateTime.of(2022, 2, 2, 12, 0);
    when(balances.getBalancesOnBalanceDate(eq(balanceDate), eq(knowledgeStartDate)))
        .thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual =
        lpxBalanceEntityService
            .getBalancesOnBalanceDate(balanceDate, knowledgeStartDate)
            .blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }

  @Test
  public void test_getBalancesOnBalanceDateForAccounts() {
    var balanceDate = LocalDate.of(2022, 1, 1);
    var knowledgeStartDate = LocalDateTime.of(2022, 2, 2, 12, 0);
    Set<Long> accountIds = Set.of(ACCOUNT_ID);
    when(balances.getBalancesOnBalanceDateForAccounts(
            eq(accountIds), eq(balanceDate), eq(knowledgeStartDate)))
        .thenReturn(Flux.just(BALANCE));
    when(accountService.getAccountData(eq(BALANCE.getAccount().getId()))).thenReturn(ACCOUNT_MONO);
    when(securityService.getSecurity(
            eq(ACCOUNT.getClientId()),
            eq(ACCOUNT.getId()),
            eq(BALANCE.getSecurity().getSecurityId())))
        .thenReturn(SECURITY_MONO);
    var actual =
        lpxBalanceEntityService
            .getBalancesOnBalanceDateForAccounts(accountIds, balanceDate, knowledgeStartDate)
            .blockFirst();
    assertEquals(ACCOUNT, Objects.requireNonNull(actual).getAccount());
    assertEquals(SECURITY, actual.getSecurity());
  }
}
