package com.cwan.privatefund.capital.call.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import com.cwan.privatefund.business.ws.model.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallStatusUpdaterServiceTest {

  @Mock private CapitalCalls capitalCalls;
  @Mock private CapitalCallEnrichmentService capitalCallEnrichmentService;
  @Mock private CapitalCallBankAccountVerifierService capitalCallBankAccountVerifierService;
  @InjectMocks @Spy private CapitalCallStatusUpdaterService service;
  private static final Long DOCUMENT_ID = 1L;

  @Test
  void updateStatusAndTransform_ShouldReturnUpdatedDocument_WhenUpdateAndEnrichmentAreSuccessful() {
    var user = createUser();
    var document = createCapitalCallDocument();
    var enrichedDocument = createCapitalCallDocument();
    when(capitalCalls.updateCapitalCallStatus(any(), any())).thenReturn(Mono.just(document));
    when(capitalCallEnrichmentService.enrichCapitalCallWithData(document, user.getEmail()))
        .thenReturn(Mono.just(enrichedDocument));
    StepVerifier.create(
            service.updateStatusAndTransform(
                user,
                DOCUMENT_ID,
                CapitalCallStatus.NEW_CAPITAL_CALL,
                CapitalCallAction.APPROVE,
                "Comment"))
        .expectNext(enrichedDocument)
        .verifyComplete();
  }

  @Test
  void updateStatusAndTransform_ShouldLogError_WhenUpdateFails() {
    var user = createUser();
    var exception = new RuntimeException("Update failed");
    when(capitalCalls.updateCapitalCallStatus(any(), any())).thenReturn(Mono.error(exception));
    StepVerifier.create(
            service.updateStatusAndTransform(
                user,
                DOCUMENT_ID,
                CapitalCallStatus.NEW_CAPITAL_CALL,
                CapitalCallAction.APPROVE,
                "Comment"))
        .verifyErrorMatches(e -> e == exception);
  }

  @Test
  void updateStatusAndTransform_ShouldLogError_WhenEnrichmentFails() {
    var user = createUser();
    var document = createCapitalCallDocument();
    var exception = new RuntimeException("Enrichment failed");
    when(capitalCalls.updateCapitalCallStatus(any(), any())).thenReturn(Mono.just(document));
    when(capitalCallEnrichmentService.enrichCapitalCallWithData(document, user.getEmail()))
        .thenReturn(Mono.error(exception));
    StepVerifier.create(
            service.updateStatusAndTransform(
                user,
                DOCUMENT_ID,
                CapitalCallStatus.NEW_CAPITAL_CALL,
                CapitalCallAction.APPROVE,
                "Comment"))
        .verifyErrorMatches(e -> e == exception);
  }

  @Test
  void updateStatusAndHandleNewBankAccount_ShouldReturnUpdatedDocument_WhenBankAccountIsNew() {
    var document = createCapitalCallDocument();
    var systemUser = createUser();
    when(capitalCallBankAccountVerifierService.isNewBankAccount(document))
        .thenReturn(Mono.just(true));
    StepVerifier.create(service.handleNewBankAccount(document, systemUser))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void updateStatusAndHandleNewBankAccount_ShouldReturnUpdatedDocument_WhenBankAccountIsExisting() {
    var document = createCapitalCallDocument();
    var systemUser = createUser();
    when(capitalCallBankAccountVerifierService.isNewBankAccount(document))
        .thenReturn(Mono.just(false));
    when(service.handleExistingBankAccount(document, systemUser)).thenReturn(Mono.just(document));
    StepVerifier.create(service.handleNewBankAccount(document, systemUser))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void handleExistingBankAccount_ShouldReturnUpdatedDocument_WithCorrectComment() {
    var document = createCapitalCallDocument();
    var systemUser = createUser();
    doReturn(Mono.just(document))
        .when(service)
        .updateStatusAndTransform(any(), any(), any(), any(), any());
    StepVerifier.create(service.handleExistingBankAccount(document, systemUser))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void handleExistingBankAccount_ShouldLogWarning_WhenBankAccountInfoIsMissing() {
    var document = createCapitalCallDocument();
    var systemUser = createUser();
    document = document.toBuilder().bankDetail(null).build();
    doReturn(Mono.just(document))
        .when(service)
        .updateStatusAndTransform(any(), any(), any(), any(), any());
    StepVerifier.create(service.handleExistingBankAccount(document, systemUser))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void buildBankAccountInfo_ShouldReturnCorrectInfo_WhenAccountNumberAndIbanArePresent() {
    var document = createCapitalCallDocument();
    var bankDetail =
        CapitalCallBankDetail.builder().accountNumber("123").accountIban("IBAN123").build();
    document = document.toBuilder().bankDetail(bankDetail).build();
    StepVerifier.create(service.buildBankAccountInfo(document))
        .expectNext("Account Number '123' and IBAN 'IBAN123'")
        .verifyComplete();
  }

  @Test
  void buildBankAccountInfo_ShouldReturnCorrectInfo_WhenOnlyAccountNumberIsPresent() {
    var document = createCapitalCallDocument();
    var bankDetail = CapitalCallBankDetail.builder().accountNumber("123").build();
    document = document.toBuilder().bankDetail(bankDetail).build();
    StepVerifier.create(service.buildBankAccountInfo(document))
        .expectNext("Account Number '123'")
        .verifyComplete();
  }

  @Test
  void buildBankAccountInfo_ShouldReturnCorrectInfo_WhenOnlyIbanIsPresent() {
    var document = createCapitalCallDocument();
    var bankDetail = CapitalCallBankDetail.builder().accountIban("IBAN123").build();
    document = document.toBuilder().bankDetail(bankDetail).build();
    StepVerifier.create(service.buildBankAccountInfo(document))
        .expectNext("IBAN 'IBAN123'")
        .verifyComplete();
  }

  @Test
  void buildBankAccountInfo_ShouldLogWarningAndReturnEmpty_WhenAccountInfoIsMissing() {
    var document = createCapitalCallDocument();
    document = document.toBuilder().bankDetail(null).build();
    StepVerifier.create(service.buildBankAccountInfo(document)).verifyComplete();
  }

  static User createUser() {
    return User.builder()
        .id(SystemUserConstants.ID)
        .fullname(SystemUserConstants.FULL_NAME)
        .email(SystemUserConstants.EMAIL)
        .build();
  }

  static CapitalCallDocument createCapitalCallDocument() {
    var bankDetail =
        CapitalCallBankDetail.builder()
            .accountNumber("123456789")
            .accountIban("DE89 3704 0044 0532 0130 00")
            .build();
    return CapitalCallDocument.builder()
        .documentId(CapitalCallStatusUpdaterServiceTest.DOCUMENT_ID)
        .status(CapitalCallStatus.NEW_CAPITAL_CALL)
        .bankDetail(bankDetail)
        .build();
  }
}
