package com.cwan.privatefund.issuestore;

import static com.cwan.privatefund.TestUtil.getIssue;
import static com.cwan.privatefund.constant.Constants.IssueTypes.MISSING_DOCUMENT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.CustomMinimalForTestResponseSpec;
import com.cwan.privatefund.issuestore.model.Issue;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

class IssueStoreClientTest {

  @Mock private WebClient webClient;
  @Mock private WebClient.RequestHeadersSpec requestHeadersMock;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
  @Mock private WebClient.RequestBodyUriSpec requestBodyUriSpec;
  @Mock private WebClient.RequestBodySpec requestBodySpec;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  @Mock private AuthTokenCore authTokenCore;
  private IssueStoreClient issueStoreClient;
  private static final String DOCUMENT_ID_TAG = UUID.randomUUID().toString();
  private static final String SOURCE_NAME = "LPXSERVICE";
  private static final Issue ISSUE = getIssue();
  private static final Flux<Issue> ISSUE_FLUX = Flux.just(ISSUE);

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    // GET requests
    when(webClient.get()).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.uri(any(Function.class))).thenReturn(requestHeadersMock);
    when(requestHeadersMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersMock);
    when(requestHeadersMock.exchangeToMono(any())).thenReturn(Mono.just(new Issue[] {ISSUE}));
    when(requestHeadersMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToFlux(Issue.class)).thenReturn(ISSUE_FLUX);
    // PUT requests
    when(webClient.put()).thenReturn(requestBodyUriSpec);
    when(requestBodyUriSpec.uri(any(Function.class))).thenReturn(requestBodySpec);
    when(requestBodySpec.headers((any(Consumer.class)))).thenReturn(requestBodySpec);
    when(requestBodySpec.contentType(any(MediaType.class))).thenReturn(requestBodySpec);
    when(requestBodySpec.body(any(Mono.class), eq(Issue.class))).thenReturn(requestHeadersMock);
    when(requestHeadersMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToMono(eq(Issue.class))).thenReturn(Mono.just(ISSUE));
    issueStoreClient = new IssueStoreClient(webClient, SOURCE_NAME, authTokenCore);
  }

  @Test
  void should_return_issue_from_tag() {
    var actual = issueStoreClient.getIssuesByTag(DOCUMENT_ID_TAG).share().blockFirst();
    assertEquals(ISSUE, actual);
  }

  @Test
  void should_return_issue_from_type() {
    var actual = issueStoreClient.getIssuesByTypeName(MISSING_DOCUMENT).share().blockFirst();
    assertEquals(ISSUE, actual);
  }

  @Test
  void should_update_issue() {
    var actual = issueStoreClient.updateIssue(ISSUE).block();
    assertEquals(ISSUE, actual);
  }
}
