package com.cwan.privatefund.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.auth.LPxAMPTPermissions;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.server.ServerWebExchange;

public class AuthorityServiceTest {

  @Mock private AuthTokenCore authTokenCore = mock(AuthTokenCore.class);
  @Mock private ServerWebExchange swe = mock(ServerWebExchange.class);
  @Mock private ServerHttpRequest request = mock(ServerHttpRequest.class);
  @Mock private HttpHeaders headers = mock(HttpHeaders.class);

  private static final String TOKEN = "Bearer supercalafragalisticexpialadocious";

  private AuthorityService instance = new AuthorityService(authTokenCore);

  @BeforeEach
  public void beforeEach() {
    when(swe.getRequest()).thenReturn(request);
    when(request.getHeaders()).thenReturn(headers);
    when(headers.getFirst(HttpHeaders.AUTHORIZATION)).thenReturn(TOKEN);
    when(authTokenCore.isValidToken(anyString())).thenReturn(true);
  }

  @Test
  public void test_getAuthorities_returns_empty_set_if_auth_header_is_null() {
    when(headers.getFirst(eq(HttpHeaders.AUTHORIZATION))).thenReturn(null);
    assertTrue(instance.getAuthorities(swe).isEmpty());
  }

  @Test
  public void test_getAuthorities_returns_empty_set_if_token_invalid() {
    when(authTokenCore.isValidToken(eq(TOKEN))).thenReturn(false);
    assertTrue(instance.getAuthorities(swe).isEmpty());
  }

  @Test
  public void test_getAuthorities_returns_minimum_permissions_for_app_tokens() {
    when(authTokenCore.decodeToken(anyString()))
        .thenReturn(Map.of("appName", "lpx-domain-service-ws"));
    assertEquals(
        Set.of(new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE)),
        instance.getAuthorities(swe));
  }

  @Test
  public void test_getAuthorities_returns_ampt_permissions() {
    when(authTokenCore.decodeToken(anyString()))
        .thenReturn(
            Map.of("ampt", List.of(Integer.parseInt(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE))));
    assertEquals(
        Set.of(new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE)),
        instance.getAuthorities(swe));
  }
}
