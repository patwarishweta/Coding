package com.cwan.privatefund.documentcashflow;

import static com.cwan.privatefund.TestUtil.CASHFLOW_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getDocumentCashflowRequest;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.pbor.cashflow.documentcashflow.api.DocumentCashflows;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.publisher.MessagePublisher;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class DocumentCashflowControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean DocumentCashflows documentCashflows;

  @MockBean DocumentCashflowHydrationService hydrationService;
  private static final DocumentCashflowRequest REQUEST = getDocumentCashflowRequest();
  private static final DocumentCashFlow DOCUMENT_CASH_FLOW =
      REQUEST.getDocumentCashFlows().stream().findFirst().get();

  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;
  @MockBean MessagePublisher<DocumentCashFlow> documentCashFlowMessagePublisher;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_update_cashflow_successfully() {
    var request = Mono.just(DOCUMENT_CASH_FLOW);
    exchangeForEntity(format("%s%s%s", CASHFLOW_URI, "?ids=", 1), PUT, request)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Void.class)
        .getResponseBody()
        .blockFirst();
    verify(documentCashFlowMessagePublisher, atLeast(1))
        .publishMessage(any(DocumentCashFlow.class), anyMap(), anyBoolean());
  }

  @Test
  void should_add_cashflow_successfully() {
    Mono<DocumentCashFlow> request = Mono.just(DOCUMENT_CASH_FLOW);
    getPostForEntity(request);
    verify(documentCashFlowMessagePublisher, atLeast(1))
        .publishMessage(any(DocumentCashFlow.class), anyMap(), anyBoolean());
  }

  @Test
  void should_get_cashflow_by_document_id_successfully() {
    var documentId = 15203;
    when(documentCashflows.getCashflowsByDocumentId(any()))
        .thenReturn(Flux.just(DOCUMENT_CASH_FLOW));
    when(hydrationService.hydrate(any(), any())).thenReturn(Mono.just(List.of(DOCUMENT_CASH_FLOW)));
    var actual = exchangeForEntity(CASHFLOW_URI + "/document/" + documentId).blockLast();

    assertEquals(DOCUMENT_CASH_FLOW, actual);
  }

  private Flux<DocumentCashFlow> exchangeForEntity(final String uri) {
    return webClient
        .method(HttpMethod.GET)
        .uri(uri)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(DocumentCashFlow.class)
        .getResponseBody();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final HttpMethod httpMethod, final Mono<DocumentCashFlow> request) {
    return webClient
        .method(httpMethod)
        .uri(uri)
        .body(request, DocumentCashflowRequest.class)
        .exchange();
  }

  private void getPostForEntity(final Mono<DocumentCashFlow> request) {
    exchangeForEntity(CASHFLOW_URI, POST, request)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(String.class)
        .getResponseBody()
        .blockFirst();
  }
}
