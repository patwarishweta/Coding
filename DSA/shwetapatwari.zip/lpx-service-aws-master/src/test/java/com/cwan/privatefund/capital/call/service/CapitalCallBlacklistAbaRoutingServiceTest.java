package com.cwan.privatefund.capital.call.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CapitalCallBlacklistAbaRoutingServiceTest {

  @InjectMocks CapitalCallBlacklistAbaRoutingService service;

  @Test
  void testIsAbaRoutingNumberBlacklisted_WithNullAccount() {
    var document = mock(CapitalCallDocument.class);
    when(document.account()).thenReturn(null);
    when(document.bankDetail()).thenReturn(CapitalCallBankDetail.builder().build());
    var result = service.isAbaRoutingNumberBlacklisted(document);
    Assertions.assertFalse(Optional.ofNullable(result.block()).orElse(false));
  }

  @Test
  void testIsAbaRoutingNumberBlacklisted_WithNullClientId() {
    var document = mock(CapitalCallDocument.class);
    when(document.account()).thenReturn(mock(Account.class));
    when(document.account().getClientId()).thenReturn(null);
    when(document.bankDetail()).thenReturn(CapitalCallBankDetail.builder().build());
    var result = service.isAbaRoutingNumberBlacklisted(document);
    Assertions.assertFalse(Optional.ofNullable(result.block()).orElse(false));
  }

  @Test
  void testIsAbaRoutingNumberBlacklisted_WithNullBankDetail() {
    var document = mock(CapitalCallDocument.class);
    when(document.account()).thenReturn(mock(Account.class));
    when(document.account().getClientId()).thenReturn(123L);
    when(document.bankDetail()).thenReturn(null);
    when(document.bankDetail()).thenReturn(CapitalCallBankDetail.builder().build());
    var result = service.isAbaRoutingNumberBlacklisted(document);
    Assertions.assertFalse(Optional.ofNullable(result.block()).orElse(false));
  }
}
