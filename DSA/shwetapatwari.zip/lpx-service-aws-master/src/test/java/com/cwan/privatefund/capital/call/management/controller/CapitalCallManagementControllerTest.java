package com.cwan.privatefund.capital.call.management.controller;

import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.BASE_URL;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.ID;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.UUID_BANK;
import static com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper.UUID_NOT_FOUND;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.capital.call.management.helper.CapitalCallManagementTestHelper;
import com.cwan.privatefund.capital.call.management.model.BankAccountResponse;
import com.cwan.privatefund.capital.call.management.model.BankBlacklistResponse;
import com.cwan.privatefund.capital.call.management.model.BankResponse;
import com.cwan.privatefund.capital.call.management.service.LpxCapitalCallManagementService;
import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CapitalCallManagementControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webTestClient;
  @MockBean private LpxCapitalCallManagementService lpxCapitalCallManagementService;

  @BeforeEach
  void beforeEach() {
    webTestClient = webTestClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void testCreateBank() {
    var bankRequest = CapitalCallManagementTestHelper.getSampleBankRequest();
    var bankResponse = CapitalCallManagementTestHelper.getSampleBankResponse();
    Mockito.when(lpxCapitalCallManagementService.createBank(bankRequest))
        .thenReturn(Mono.just(bankResponse));
    webTestClient
        .post()
        .uri(BASE_URL + "banks")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(bankRequest)
        .exchange()
        .expectStatus()
        .isCreated()
        .expectBody(BankResponse.class)
        .isEqualTo(bankResponse);
  }

  @Test
  void testFetchBanksByClient() {
    var bankResponseList = List.of(CapitalCallManagementTestHelper.getSampleBankResponse());
    Mockito.when(lpxCapitalCallManagementService.fetchBanksByClient(ID))
        .thenReturn(Flux.fromIterable(bankResponseList));
    webTestClient
        .get()
        .uri(BASE_URL + "clients/" + ID + "/banks")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(BankResponse.class)
        .isEqualTo(bankResponseList);
  }

  @Test
  void testFetchBank() {
    var bankResponse = CapitalCallManagementTestHelper.getSampleBankResponse();
    Mockito.when(lpxCapitalCallManagementService.fetchBank(UUID_BANK))
        .thenReturn(Mono.just(bankResponse));
    webTestClient
        .get()
        .uri(BASE_URL + "banks/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BankResponse.class)
        .isEqualTo(bankResponse);
  }

  @Test
  void testFetchBankNotFound() {
    Mockito.when(lpxCapitalCallManagementService.fetchBank(UUID_NOT_FOUND))
        .thenReturn(Mono.empty());
    webTestClient
        .get()
        .uri(BASE_URL + "banks/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  void testDeleteBank() {
    Mockito.when(lpxCapitalCallManagementService.deleteBank(UUID_BANK)).thenReturn(Mono.empty());
    webTestClient
        .delete()
        .uri(BASE_URL + "banks/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void testDeleteBankNotFound() {
    Mockito.when(lpxCapitalCallManagementService.deleteBank(UUID_NOT_FOUND))
        .thenThrow(new NoSuchElementException());
    webTestClient
        .delete()
        .uri(BASE_URL + "banks/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  void testCreateBankAccount() {
    var bankAccountRequest = CapitalCallManagementTestHelper.getSampleBankAccountRequest();
    var bankAccountResponse = CapitalCallManagementTestHelper.getSampleBankAccountResponse();
    Mockito.when(lpxCapitalCallManagementService.createBankAccount(bankAccountRequest))
        .thenReturn(Mono.just(bankAccountResponse));
    webTestClient
        .post()
        .uri(BASE_URL + "bankAccounts")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(bankAccountRequest)
        .exchange()
        .expectStatus()
        .isCreated()
        .expectBody(BankAccountResponse.class)
        .isEqualTo(bankAccountResponse);
  }

  @Test
  void testFetchBankAccountsByAccount() {
    var bankAccountResponseList =
        List.of(CapitalCallManagementTestHelper.getSampleBankAccountResponse());
    Mockito.when(lpxCapitalCallManagementService.fetchBankAccountsByAccount(ID))
        .thenReturn(Flux.fromIterable(bankAccountResponseList));
    webTestClient
        .get()
        .uri(BASE_URL + "accounts/" + ID + "/bankAccounts")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(BankAccountResponse.class)
        .isEqualTo(bankAccountResponseList);
  }

  @Test
  void testFetchBankAccountsByClient() {
    var bankAccountResponseList =
        List.of(CapitalCallManagementTestHelper.getSampleBankAccountResponse());
    Mockito.when(lpxCapitalCallManagementService.fetchBankAccountsByClient(ID))
        .thenReturn(Flux.fromIterable(bankAccountResponseList));
    webTestClient
        .get()
        .uri(BASE_URL + "clients/" + ID + "/bankAccounts")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(BankAccountResponse.class)
        .isEqualTo(bankAccountResponseList);
  }

  @Test
  void testFetchBankAccount() {
    var bankAccountResponse = CapitalCallManagementTestHelper.getSampleBankAccountResponse();
    Mockito.when(lpxCapitalCallManagementService.fetchBankAccount(UUID_BANK))
        .thenReturn(Mono.just(bankAccountResponse));
    webTestClient
        .get()
        .uri(BASE_URL + "bankAccounts/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BankAccountResponse.class)
        .isEqualTo(bankAccountResponse);
  }

  @Test
  void testFetchBankAccountNotFound() {
    Mockito.when(lpxCapitalCallManagementService.fetchBankAccount(UUID_NOT_FOUND))
        .thenReturn(Mono.empty());
    webTestClient
        .get()
        .uri(BASE_URL + "bankAccounts/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  void testDeleteBankAccount() {
    Mockito.when(lpxCapitalCallManagementService.deleteBankAccount(UUID_BANK))
        .thenReturn(Mono.empty());
    webTestClient
        .delete()
        .uri(BASE_URL + "bankAccounts/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void testDeleteBankAccountNotFound() {
    Mockito.when(lpxCapitalCallManagementService.deleteBankAccount(UUID_NOT_FOUND))
        .thenThrow(new NoSuchElementException());
    webTestClient
        .delete()
        .uri(BASE_URL + "bankAccounts/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  void testAddBankToBlacklist() {
    var bankBlacklistResponse = CapitalCallManagementTestHelper.getSampleBankBlacklistResponse();
    Mockito.when(lpxCapitalCallManagementService.addBankToBlacklist(UUID_BANK))
        .thenReturn(Mono.just(bankBlacklistResponse));
    webTestClient
        .post()
        .uri(BASE_URL + "banks/" + UUID_BANK + "/bankBlacklists")
        .exchange()
        .expectStatus()
        .isCreated()
        .expectBody(BankBlacklistResponse.class)
        .isEqualTo(bankBlacklistResponse);
  }

  @Test
  void testAddBankToBlacklistInvalidUuid() {
    webTestClient
        .post()
        .uri(BASE_URL + "banks/" + "invalid-uuid" + "/bankBlacklists")
        .exchange()
        .expectStatus()
        .isBadRequest();
  }

  @Test
  void testFetchBankBlacklistsByClient() {
    var bankBlacklistResponseList =
        List.of(CapitalCallManagementTestHelper.getSampleBankBlacklistResponse());
    Mockito.when(lpxCapitalCallManagementService.fetchBlacklistedBanksByClient(ID))
        .thenReturn(Flux.fromIterable(bankBlacklistResponseList));
    webTestClient
        .get()
        .uri(BASE_URL + "clients/" + ID + "/bankBlacklists")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(BankBlacklistResponse.class)
        .isEqualTo(bankBlacklistResponseList);
  }

  @Test
  void testFetchBankBlacklistsByInvalidClient() {
    webTestClient
        .get()
        .uri(BASE_URL + "clients/" + -ID + "/bankBlacklists")
        .exchange()
        .expectStatus()
        .isBadRequest();
  }

  @Test
  void testFetchBankBlacklist() {
    var bankBlacklistResponse = CapitalCallManagementTestHelper.getSampleBankBlacklistResponse();
    Mockito.when(lpxCapitalCallManagementService.fetchBlacklistedBank(UUID_BANK))
        .thenReturn(Mono.just(bankBlacklistResponse));
    webTestClient
        .get()
        .uri(BASE_URL + "bankBlacklists/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(BankBlacklistResponse.class)
        .isEqualTo(bankBlacklistResponse);
  }

  @Test
  void testFetchBankBlacklistNotFound() {
    Mockito.when(lpxCapitalCallManagementService.fetchBlacklistedBank(UUID_NOT_FOUND))
        .thenReturn(Mono.empty());
    webTestClient
        .get()
        .uri(BASE_URL + "bankBlacklists/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  void testFetchBankBlacklistInvalidUuid() {
    webTestClient
        .get()
        .uri(BASE_URL + "bankBlacklists/" + "invalid-uuid")
        .exchange()
        .expectStatus()
        .isBadRequest();
  }

  @Test
  void testRemoveBankFromBlacklist() {
    Mockito.when(lpxCapitalCallManagementService.removeBankFromBlacklist(UUID_BANK))
        .thenReturn(Mono.empty());
    webTestClient
        .delete()
        .uri(BASE_URL + "bankBlacklists/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void testRemoveBankFromBlacklistNotFound() {
    Mockito.when(lpxCapitalCallManagementService.removeBankFromBlacklist(UUID_NOT_FOUND))
        .thenThrow(new NoSuchElementException());
    webTestClient
        .delete()
        .uri(BASE_URL + "bankBlacklists/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  void testRemoveBankFromBlacklistInvalidUuid() {
    webTestClient
        .delete()
        .uri(BASE_URL + "bankBlacklists/" + "invalid-uuid")
        .exchange()
        .expectStatus()
        .isBadRequest();
  }

  @Test
  void testHandleAccessDeniedException() {
    Mockito.when(lpxCapitalCallManagementService.fetchBank(UUID_BANK))
        .thenThrow(new AccessDeniedException("Access Denied"));
    webTestClient
        .get()
        .uri(BASE_URL + "banks/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(String.class)
        .isEqualTo("Access Denied");
  }

  @Test
  void testHandleNoSuchElementException() {
    Mockito.when(lpxCapitalCallManagementService.fetchBank(UUID_NOT_FOUND))
        .thenThrow(new NoSuchElementException("Bank Not Found"));
    webTestClient
        .get()
        .uri(BASE_URL + "banks/" + UUID_NOT_FOUND)
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectBody(String.class)
        .isEqualTo("Bank Not Found");
  }

  @Test
  void testHandleRuntimeException() {
    Mockito.when(lpxCapitalCallManagementService.fetchBank(UUID_BANK))
        .thenThrow(new RuntimeException("Internal Server Error"));
    webTestClient
        .get()
        .uri(BASE_URL + "banks/" + UUID_BANK)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(String.class);
  }
}
