package com.cwan.privatefund.config.properties;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CpdConfigPropertiesTest {

  private CpdConfigProperties properties;

  @BeforeEach
  public void setUp() {
    properties = new CpdConfigProperties();
  }

  @Test
  void testWebServiceProperties() {
    var webService = new CpdConfigProperties.WebService();
    webService.setBaseUrl("https://test.com");
    webService.setMaxMemorySize(2048);
    properties.setWebService(webService);
    assertEquals("https://test.com", properties.getWebService().getBaseUrl());
    assertEquals(2048, properties.getWebService().getMaxMemorySize());
  }

  @Test
  void testCacheProperties() {
    var cache = new CpdConfigProperties.Cache();
    cache.setMaxSize(1000);
    cache.setTimeoutInHours(24);
    properties.setCache(cache);
    assertEquals(1000, properties.getCache().getMaxSize());
    assertEquals(24, properties.getCache().getTimeoutInHours());
  }

  @Test
  void testFieldIdsProperties() {
    var reviewers = new HashMap<String, Integer>();
    reviewers.put("Test", 1);
    reviewers.put("User", 2);
    var abaRoutingNumbers = new HashMap<String, Integer>();
    abaRoutingNumbers.put("123456", 100);
    abaRoutingNumbers.put("654321", 200);
    var fieldIds = new CpdConfigProperties.FieldIds();
    fieldIds.setReviewers(reviewers);
    fieldIds.setAbaRoutingNumbers(abaRoutingNumbers);
    properties.setFieldIds(fieldIds);
    assertEquals(1, properties.getFieldIds().getReviewers().get("Test"));
    assertEquals(2, properties.getFieldIds().getReviewers().get("User"));
  }
}
