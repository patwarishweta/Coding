package com.cwan.privatefund.chronos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ca.authtoken.core.AuthTokenCore;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.cwan.privatefund.chronos.ChronosWSApacheClient.LockdownAccountDetails;
import java.time.LocalDate;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.MockitoAnnotations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ChronosWSApacheClientTest {
  private static final TestHttpClient testClient = new TestHttpClient();
  private static final String JSON =
      """
          {"SIMPLE_ACCOUNT:1":{"accountIdentifier":{"id":1,"type":"SIMPLE_ACCOUNT"},"accountStartDate":"02/23/2023","currentLockdownData":{"lockdownDate":"09/30/2024","periodType":"QUARTER","lockdownDelay":1,"reportDueDate":"10/01/2024"},"dataAfterCurrentLockdown":{"lockdownDate":"10/31/2024","periodType":"MONTH","lockdownDelay":1,"reportDueDate":"11/01/2024"},"narrative":"","transitioned":false}}
      """;
  private static final FakeWsResponse fakeResponse =
      new FakeWsResponse()
          .setRequestUrl("dates/lockdowns/v3.5/next")
          .setStatusCode(200)
          .setBody(JSON);
  private final AuthTokenCore authTokenCore = mock(AuthTokenCore.class);

  private final ChronosWSApacheClient INSTANCE =
      new ChronosWSApacheClient(
          testClient,
          new ServerConfiguration("chronos-ws", 8084, "chronos-ws", Scheme.HTTPS),
          authTokenCore);

  @BeforeAll
  void setup() {
    MockitoAnnotations.openMocks(this);
    when(authTokenCore.createApplicationToken()).thenReturn("token");
    testClient.setResponses(fakeResponse);
  }

  @Test
  void getLockdownStatusForAccounts() {
    Map<String, LockdownAccountDetails> lockdownAccountDetailsMap =
        INSTANCE.getLatestLockdownDateForAccounts(Set.of(1L));
    LockdownAccountDetails lockdownAccountDetails =
        lockdownAccountDetailsMap.get("SIMPLE_ACCOUNT:1");
    assertNotNull(lockdownAccountDetails);
    assertEquals(
        LocalDate.of(2024, 9, 30), lockdownAccountDetails.currentLockdownData().lockdownDate());
  }
}
