package com.cwan.privatefund.portfolio;

import static com.cwan.privatefund.TestUtil.PORTFOLIO_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getPortfolioSummaryResponse;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import com.cwan.lpx.domain.Performance;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.portfolio.model.PortfolioSummaryResponse;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class PortfolioControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private PortfolioService portfolioService;
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @BeforeAll
  static void beforeAll() {
    System.setProperty("env", "ci");
  }

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_get_portfolio_balance_by_accountIds() {
    PortfolioSummaryResponse portfolioSummaryResponse = getPortfolioSummaryResponse();
    LocalDate calculationDate = LocalDate.of(2023, 1, 1);

    Mockito.when(portfolioService.getPortfolioBalances(eq(Set.of(1L)), eq(calculationDate)))
        .thenReturn(Mono.just(portfolioSummaryResponse));

    Mono<PortfolioSummaryResponse> actual =
        getPortfolioBalanceSummaryEntity(
            String.format(
                "%s/performance/metrics/accounts?accountIds=%d&calculationDate=%s",
                PORTFOLIO_URI, 1, calculationDate));

    StepVerifier.create(actual)
        .expectNextMatches(
            actualVal -> {
              if (actualVal.getData().isEmpty()) return false;

              PortfolioBalance actualBalance = actualVal.getData().get(0);
              PortfolioBalance expectedBalance = portfolioSummaryResponse.getData().get(0);

              return actualBalance.getAccount().getId().equals(expectedBalance.getAccount().getId())
                  && actualBalance
                      .getSecurity()
                      .getSecurityId()
                      .equals(expectedBalance.getSecurity().getSecurityId())
                  && actualBalance
                      .getPerformance()
                      .getId()
                      .equals(expectedBalance.getPerformance().getId());
            })
        .verifyComplete();
  }

  @Test
  void should_trigger_portfolio_balance_reload() {
    Mockito.doNothing().when(portfolioService).reloadPerformanceTillCurrentDate();
    var actual = publishCalculationTask(PORTFOLIO_URI + "/modified/transactions");
    StepVerifier.create(actual).expectNextCount(1).verifyComplete();
  }

  @Test
  void get_performance_calculations_for_dates() {
    Performance performance = new Performance();
    List<LocalDateTime> calculationDates =
        List.of(LocalDate.of(2021, 1, 1).atStartOfDay(), LocalDate.of(2021, 1, 2).atStartOfDay());
    Mockito.when(portfolioService.getPerformancesForDates(any(), any(), any()))
        .thenReturn(Flux.just(performance));

    var actual =
        getPerformanceEntities(
            format(
                "%s%s%s%s%s%s%s",
                PORTFOLIO_URI,
                "/performance/account/1/dates",
                "?frequency=QTD",
                "&calculationDates=",
                calculationDates.get(0).format(DateTimeFormatter.ISO_DATE),
                "&calculationDates=",
                calculationDates.get(1).format(DateTimeFormatter.ISO_DATE)));

    assertNotNull(actual);
  }

  @Test
  void get_earliest_active_performances_for_account() {
    var actual =
        getPerformanceEntities(
            format(
                "%s%s%s",
                PORTFOLIO_URI, "/performance/account/1/securities/earliest", "?frequency=ITD"));

    assertNotNull(actual);
  }

  private Flux<PortfolioBalance> getPortfolioBalanceEntity(final String uri) {
    return exchangeForEntity(uri, HttpMethod.GET)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(PortfolioBalance.class)
        .getResponseBody();
  }

  private Mono<PortfolioSummaryResponse> getPortfolioBalanceSummaryEntity(final String uri) {
    return exchangeForEntity(uri, HttpMethod.GET)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(PortfolioSummaryResponse.class)
        .getResponseBody()
        .single();
  }

  private Flux<Performance> getPerformanceEntities(final String uri) {
    return exchangeForEntity(uri, HttpMethod.GET)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Performance.class)
        .getResponseBody();
  }

  private Flux<String> publishCalculationTask(final String uri) {
    return exchangeForEntity(uri, HttpMethod.GET)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(String.class)
        .getResponseBody();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(
      final String uri, final HttpMethod httpMethod) {
    return webClient.method(httpMethod).uri(uri).exchange();
  }
}
