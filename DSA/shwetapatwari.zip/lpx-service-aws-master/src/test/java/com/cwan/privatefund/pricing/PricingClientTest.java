package com.cwan.privatefund.pricing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.cwan.privatefund.pricing.model.PricingData;
import com.cwan.privatefund.pricing.model.PricingRequest;
import com.cwan.privatefund.pricing.model.PricingResponse;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PricingClientTest {

  private PricingClient instance;
  private static final LocalDate DATE = LocalDate.of(2022, 1, 2);
  private static final String STRING_DATE = "01/02/2022";
  private static final long ACCOUNT_ID = 1L;
  private static final long SECURITY_ID = 2L;
  private static final Double PRICE = 10D;
  private static final PricingRequest REQUEST =
      new PricingRequest(ACCOUNT_ID, List.of(SECURITY_ID), DATE);
  private static final TestHttpClient testClient = new TestHttpClient();
  private static final FakeWsResponse fakeResponse =
      new FakeWsResponse()
          .setRequestUrl("readonly/v4/securitypricing/getfulldailypricing")
          .setStatusCode(200)
          .setBody(
              JsonUtils2.objToJson(
                  Map.of(STRING_DATE, Map.of(SECURITY_ID, new PricingData("source", PRICE)))));

  @BeforeEach
  void beforeEach() {
    testClient.setResponse(fakeResponse);
    instance =
        new PricingClient(
            testClient, new ServerConfiguration("pricing-data-ws", "pricing-data-ws"));
  }

  @Test
  public void should_get_price() {
    PricingResponse expectedResponse =
        new PricingResponse(
            Map.of(STRING_DATE, Map.of(SECURITY_ID, new PricingData("source", (PRICE)))));
    PricingResponse actual = instance.getPricingData(REQUEST);
    assertEquals(expectedResponse.getRawData(), actual.getRawData());
  }

  @Test
  public void should_handle_empty_response() {
    testClient.setResponse(
        new FakeWsResponse()
            .setStatusCode(200)
            .setRequestUrl("readonly/v4/securitypricing/getfulldailypricing")
            .setBody("{}"));
    PricingResponse expectedResponse = new PricingResponse();
    PricingResponse actual = instance.getPricingData(REQUEST);
    assertEquals(expectedResponse.getRawData(), actual.getRawData());
  }

  @Test
  void pricingClient_api_call_4xx_with_error_response_test() {
    testClient.setResponse(
        new FakeWsResponse()
            .setStatusCode(400)
            .setRequestUrl("readonly/v4/securitypricing/getfulldailypricing"));
    assertThrows(RuntimeException.class, () -> instance.getPricingData(REQUEST));
  }

  @Test
  void pricingClient_api_call_5xx_with_error_response_test() {
    testClient.setResponse(
        new FakeWsResponse()
            .setStatusCode(500)
            .setRequestUrl("readonly/v4/securitypricing/getfulldailypricing"));
    assertThrows(RuntimeException.class, () -> instance.getPricingData(REQUEST));
  }
}
