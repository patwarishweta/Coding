package com.cwan.privatefund.cpd.ws.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.ca.authtoken.core.AuthTokenCore;
import com.cwan.privatefund.cpd.ws.model.CpdField;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import java.net.UnknownHostException;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SuppressWarnings({"rawtypes", "unchecked"})
class CpdWSClientTest {

  @Mock private WebClient cpdWebClient;
  @Mock private AuthTokenCore authTokenCore;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
  @Mock private WebClient.ResponseSpec responseSpecMock;
  private CpdWSClient cpdWSClient;
  private static final Set<Integer> FIDS = Set.of(1, 2, 3);
  private static final Flux<TagEntry> TAG_ENTRIES_FLUX = Flux.just(TagEntry.builder().build());
  private static final Flux<CpdField> CPD_FIELD_FLUX = Flux.just(CpdField.builder().build());
  private final ListAppender<ILoggingEvent> listAppender = new ListAppender<>();

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    cpdWSClient = new CpdWSClient(cpdWebClient, authTokenCore);
    setupWebClientResponses();
  }

  @AfterEach
  void afterEach() {
    var logger = (Logger) LoggerFactory.getLogger(CpdWSClient.class);
    logger.detachAppender(listAppender);
  }

  void setupWebClientResponses() {
    when(cpdWebClient.get()).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.uri(any(Function.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.accept(any(MediaType.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.headers(any(Consumer.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
    when(authTokenCore.createApplicationToken()).thenReturn("dummy_token");
  }

  @Test
  void should_fetch_tag_entries_for_given_fids() {
    when(responseSpecMock.bodyToFlux(TagEntry.class)).thenReturn(TAG_ENTRIES_FLUX);
    var result = cpdWSClient.getTagEntries(FIDS, 123L, 456L).collectList().block();
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  void should_fetch_tag_entries_for_given_fids_and_no_accountId() {
    when(responseSpecMock.bodyToFlux(TagEntry.class)).thenReturn(TAG_ENTRIES_FLUX);
    var result = cpdWSClient.getTagEntries(FIDS, 123L, null).collectList().block();
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  void should_handle_4xx_client_errors() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.BAD_REQUEST;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                return invocation.getArgument(1);
              }
              return responseSpecMock;
            });
    assertThrows(
        Exception.class, () -> cpdWSClient.getTagEntries(FIDS, 123L, 456L).collectList().block());
  }

  @Test
  void should_handle_5xx_server_errors() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.INTERNAL_SERVER_ERROR;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                return invocation.getArgument(1);
              }
              return responseSpecMock;
            });
    assertThrows(
        Exception.class, () -> cpdWSClient.getTagEntries(FIDS, 123L, 456L).collectList().block());
  }

  @Test
  void should_handle_UnknownHostException() {
    when(responseSpecMock.bodyToFlux(TagEntry.class))
        .thenThrow(new RuntimeException(new UnknownHostException("Unknown host")));
    assertThrows(
        RuntimeException.class,
        () -> cpdWSClient.getTagEntries(FIDS, 123L, 456L).collectList().block());
  }

  @Test
  void should_set_bearer_auth() {
    when(requestHeadersUriMock.headers(any(Consumer.class)))
        .thenAnswer(
            invocation -> {
              Consumer<HttpHeaders> consumer = invocation.getArgument(0);
              var headers = new HttpHeaders();
              consumer.accept(headers);
              assertEquals(
                  "Bearer dummy_token",
                  headers.getFirst(org.springframework.http.HttpHeaders.AUTHORIZATION));
              return requestHeadersUriMock;
            });
    when(responseSpecMock.bodyToFlux(TagEntry.class)).thenReturn(TAG_ENTRIES_FLUX);
    cpdWSClient.getTagEntries(FIDS, 123L, 456L).collectList().block();
  }

  @Test
  void fetchUserDetails_UnknownHostException() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToFlux(TagEntry.class))
        .thenReturn(Flux.error(new UnknownHostException()));
    StepVerifier.create(cpdWSClient.getTagEntries(FIDS, 123L, 456L)).verifyComplete();
  }

  @Test
  void fetchUserDetails_4xx() {
    var clientResponseMock = mock(ClientResponse.class);
    when(clientResponseMock.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.BAD_REQUEST;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                ((Function<ClientResponse, Mono<? extends Throwable>>) invocation.getArgument(1))
                    .apply(clientResponseMock);
              }
              return responseSpecMock;
            });
    when(clientResponseMock.bodyToMono(any(Class.class))).thenReturn(Mono.empty());
    when(responseSpecMock.bodyToFlux(TagEntry.class))
        .thenReturn(
            Flux.error(
                new WebClientResponseException(
                    "4xx Client Error", 400, "Bad Request", null, null, null)));
    StepVerifier.create(cpdWSClient.getTagEntries(FIDS, 123L, 456L)).verifyComplete();
  }

  @Test
  void fetchUserDetails_5xx() {
    var clientResponseMock = mock(ClientResponse.class);
    when(clientResponseMock.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.INTERNAL_SERVER_ERROR;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                ((Function<ClientResponse, Mono<? extends Throwable>>) invocation.getArgument(1))
                    .apply(clientResponseMock);
              }
              return responseSpecMock;
            });
    when(clientResponseMock.bodyToMono(any(Class.class))).thenReturn(Mono.empty());
    when(responseSpecMock.bodyToFlux(TagEntry.class))
        .thenReturn(
            Flux.error(
                new WebClientResponseException(
                    "5xx Server Error", 500, "Internal Server Error", null, null, null)));
    StepVerifier.create(cpdWSClient.getTagEntries(FIDS, 123L, 456L)).verifyComplete();
  }

  @Test
  void should_fetch_field_entries_for_given_clientIds() {
    when(responseSpecMock.bodyToFlux(CpdField.class)).thenReturn(CPD_FIELD_FLUX);
    var result = cpdWSClient.getCpdFields(123L).collectList().block();
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  void should_handle_4xx_client_errors_for_field_entries() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.BAD_REQUEST;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                return invocation.getArgument(1);
              }
              return responseSpecMock;
            });
    assertThrows(Exception.class, () -> cpdWSClient.getCpdFields(123L).collectList().block());
  }

  @Test
  void should_handle_5xx_server_errors_for_field_entries() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.INTERNAL_SERVER_ERROR;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                return invocation.getArgument(1);
              }
              return responseSpecMock;
            });
    assertThrows(Exception.class, () -> cpdWSClient.getCpdFields(123L).collectList().block());
  }

  @Test
  void should_set_bearer_auth_for_field_entries() {
    when(requestHeadersUriMock.headers(any(Consumer.class)))
        .thenAnswer(
            invocation -> {
              Consumer<HttpHeaders> consumer = invocation.getArgument(0);
              var headers = new HttpHeaders();
              consumer.accept(headers);
              assertEquals(
                  "Bearer dummy_token",
                  headers.getFirst(org.springframework.http.HttpHeaders.AUTHORIZATION));
              return requestHeadersUriMock;
            });
    when(responseSpecMock.bodyToFlux(CpdField.class)).thenReturn(CPD_FIELD_FLUX);
    cpdWSClient.getCpdFields(123L).collectList().block();
  }

  @Test
  void fetchUserDetails_UnknownHostException_for_field_entries() {
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToFlux(CpdField.class))
        .thenReturn(Flux.error(new UnknownHostException()));
    StepVerifier.create(cpdWSClient.getCpdFields(123L)).verifyComplete();
  }

  @Test
  void fetchUserDetails_4xx_for_field_entries() {
    var clientResponseMock = mock(ClientResponse.class);
    when(clientResponseMock.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.BAD_REQUEST;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                ((Function<ClientResponse, Mono<? extends Throwable>>) invocation.getArgument(1))
                    .apply(clientResponseMock);
              }
              return responseSpecMock;
            });
    when(clientResponseMock.bodyToMono(any(Class.class))).thenReturn(Mono.empty());
    when(responseSpecMock.bodyToFlux(CpdField.class))
        .thenReturn(
            Flux.error(
                new WebClientResponseException(
                    "4xx Client Error", 400, "Bad Request", null, null, null)));
    StepVerifier.create(cpdWSClient.getCpdFields(123L)).verifyComplete();
  }

  @Test
  void fetchUserDetails_5xx_for_field_entries() {
    var clientResponseMock = mock(ClientResponse.class);
    when(clientResponseMock.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class)))
        .thenAnswer(
            invocation -> {
              var status = HttpStatus.INTERNAL_SERVER_ERROR;
              if (((Predicate<HttpStatus>) invocation.getArgument(0)).test(status)) {
                ((Function<ClientResponse, Mono<? extends Throwable>>) invocation.getArgument(1))
                    .apply(clientResponseMock);
              }
              return responseSpecMock;
            });
    when(clientResponseMock.bodyToMono(any(Class.class))).thenReturn(Mono.empty());
    when(responseSpecMock.bodyToFlux(CpdField.class))
        .thenReturn(
            Flux.error(
                new WebClientResponseException(
                    "5xx Server Error", 500, "Internal Server Error", null, null, null)));
    StepVerifier.create(cpdWSClient.getCpdFields(123L)).verifyComplete();
  }
}
