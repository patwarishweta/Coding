package com.cwan.privatefund.capital.call.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.util.JsonNormalizationUtils;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallEnrichmentServiceTest {

  @Mock private AccountService accountService;
  @Mock private SecurityService securityService;
  @Mock private CapitalCallPermissionService capitalCallPermissionService;
  @Mock private JsonNormalizationUtils jsonNormalizationUtils;
  private CapitalCallEnrichmentService capitalCallEnrichmentService;

  @BeforeEach
  void setUp() {
    capitalCallEnrichmentService =
        new CapitalCallEnrichmentService(
            accountService, securityService, capitalCallPermissionService, jsonNormalizationUtils);
  }

  @Test
  void enrichCapitalCallWithData_WithSecurityAndAccount() {
    var capitalCallDocument =
        CapitalCallDocument.builder()
            .account(Account.builder().id(1L).clientId(2L).build())
            .security(Security.builder().securityId(3L).build())
            .build();
    var enrichedAccount = Account.builder().id(1L).clientId(2L).name("account").build();
    var enrichedSecurity = Security.builder().securityId(3L).build();
    when(accountService.getAccountWithClientData(1L)).thenReturn(Mono.just(enrichedAccount));
    when(securityService.getSecurity(2L, 1L, 3L)).thenReturn(Mono.just(enrichedSecurity));
    var expectedCapitalCallDocument =
        capitalCallDocument.toBuilder().account(enrichedAccount).security(enrichedSecurity).build();
    when(capitalCallPermissionService.updatePermissionBasedOnUserEmail(any(), anyString()))
        .thenReturn(Mono.just(expectedCapitalCallDocument));
    when(jsonNormalizationUtils.normalizeData(any(Account.class), eq(Account.class)))
        .thenReturn(Mono.just(enrichedAccount));
    when(jsonNormalizationUtils.normalizeData(any(Security.class), eq(Security.class)))
        .thenReturn(Mono.just(enrichedSecurity));
    StepVerifier.create(
            capitalCallEnrichmentService.enrichCapitalCallWithData(
                capitalCallDocument, anyString()))
        .expectNext(expectedCapitalCallDocument)
        .verifyComplete();
  }

  @Test
  void enrichCapitalCallWithData_WithoutAccount() {
    var capitalCallDocument =
        CapitalCallDocument.builder().security(Security.builder().securityId(3L).build()).build();
    when(capitalCallPermissionService.updatePermissionBasedOnUserEmail(any(), anyString()))
        .thenReturn(Mono.just(capitalCallDocument));
    StepVerifier.create(
            capitalCallEnrichmentService.enrichCapitalCallWithData(
                capitalCallDocument, "test@example.com"))
        .expectNext(capitalCallDocument)
        .verifyComplete();
  }

  @Test
  void enrichCapitalCallWithData_WithoutSecurity() {
    var capitalCallDocument =
        CapitalCallDocument.builder()
            .account(Account.builder().id(1L).clientId(2L).build())
            .build();
    var enrichedAccount = Account.builder().id(1L).clientId(2L).name("account").build();
    when(accountService.getAccountWithClientData(1L)).thenReturn(Mono.just(enrichedAccount));
    var expectedCapitalCallDocument =
        capitalCallDocument.toBuilder().account(enrichedAccount).build();
    when(capitalCallPermissionService.updatePermissionBasedOnUserEmail(any(), anyString()))
        .thenReturn(Mono.just(expectedCapitalCallDocument));
    when(jsonNormalizationUtils.normalizeData(any(Account.class), eq(Account.class)))
        .thenReturn(Mono.just(enrichedAccount));
    StepVerifier.create(
            capitalCallEnrichmentService.enrichCapitalCallWithData(
                capitalCallDocument, anyString()))
        .expectNext(expectedCapitalCallDocument)
        .verifyComplete();
  }

  @Test
  void testEnrichAndProcessBatchOfCapitalCalls_Success() {
    var userEmail = "test@example.com";
    when(capitalCallPermissionService.updatePermissionBasedOnUserEmail(any(), eq(userEmail)))
        .thenReturn(Mono.just(CapitalCallDocument.builder().build()));
    when(accountService.getAccountWithClientData(1L))
        .thenReturn(Mono.just(Account.builder().id(1L).clientId(2L).name("account").build()));
    when(accountService.getAccountWithClientData(3L))
        .thenReturn(
            Mono.just(Account.builder().id(3L).clientId(4L).name("another account").build()));
    StepVerifier.create(
            capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(
                Arrays.asList(
                    CapitalCallDocument.builder()
                        .account(Account.builder().id(1L).clientId(2L).build())
                        .build(),
                    CapitalCallDocument.builder()
                        .account(Account.builder().id(3L).clientId(4L).build())
                        .build()),
                userEmail))
        .expectNextCount(2)
        .verifyComplete();
  }

  @Test
  void testEnrichAndProcessBatchOfCapitalCalls_Error() {
    var userEmail = "error@example.com";
    when(capitalCallPermissionService.updatePermissionBasedOnUserEmail(any(), eq(userEmail)))
        .thenThrow(new RuntimeException("Sample Exception"));
    when(accountService.getAccountWithClientData(1L))
        .thenReturn(Mono.just(Account.builder().id(1L).clientId(2L).name("account").build()));
    StepVerifier.create(
            capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(
                Collections.singletonList(
                    CapitalCallDocument.builder()
                        .account(Account.builder().id(1L).clientId(2L).build())
                        .build()),
                userEmail))
        .expectError()
        .verify();
  }
}
