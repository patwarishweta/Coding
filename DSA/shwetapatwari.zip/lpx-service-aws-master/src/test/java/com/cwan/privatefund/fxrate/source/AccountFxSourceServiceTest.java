package com.cwan.privatefund.fxrate.source;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

public class AccountFxSourceServiceTest {

  @Mock private AccountFxSourceRepository accountFxSourceRepository;
  private final AccountFxSourceEntityTransformer accountFxSourceEntityTransformer =
      new AccountFxSourceEntityTransformer();
  private static final Long ACCOUNT_ID = 200L;
  private static final LocalDate DATE_1 = LocalDate.of(2024, 1, 1);
  private static final LocalDate DATE_2 = LocalDate.of(2024, 1, 2);
  private static final int BASIS_ID_1 = -1;
  private static final int BASIS_ID_2 = 1;
  private static final Long SOURCE_ID_1 = 300L;
  private static final Long SOURCE_ID_2 = 301L;
  private static final Long SOURCE_ID_3 = 302L;
  private static final int RANK_1 = 1;
  private static final int RANK_2 = 2;
  private static final AccountFxSourceEntity ACCOUNT_FX_SOURCE_ENTITY_1 =
      createAccountFxSourceEntity(BASIS_ID_1, DATE_1, SOURCE_ID_1, RANK_1);
  private static final AccountFxSourceEntity ACCOUNT_FX_SOURCE_ENTITY_2 =
      createAccountFxSourceEntity(BASIS_ID_1, DATE_2, SOURCE_ID_2, RANK_1);
  private static final AccountFxSourceEntity ACCOUNT_FX_SOURCE_ENTITY_3 =
      createAccountFxSourceEntity(BASIS_ID_2, DATE_1, SOURCE_ID_2, RANK_1);
  private static final AccountFxSourceEntity ACCOUNT_FX_SOURCE_ENTITY_4 =
      createAccountFxSourceEntity(BASIS_ID_1, DATE_1, SOURCE_ID_2, RANK_2);
  private AccountFxSourceService accountFxSourceService;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(accountFxSourceRepository.findAllByAccountIdIn(Set.of(ACCOUNT_ID)))
        .thenReturn(
            Set.of(
                ACCOUNT_FX_SOURCE_ENTITY_1,
                ACCOUNT_FX_SOURCE_ENTITY_2,
                ACCOUNT_FX_SOURCE_ENTITY_3,
                ACCOUNT_FX_SOURCE_ENTITY_4));
    this.accountFxSourceService =
        new AccountFxSourceService(
            accountFxSourceRepository,
            accountFxSourceEntityTransformer,
            new AccountFxSourceTransformer());
  }

  @Test
  void test_get_fx_source_schedule() {
    NavigableMap<LocalDate, List<Long>> schedule1 = new TreeMap<>();
    schedule1.put(DATE_1, List.of(SOURCE_ID_1, SOURCE_ID_2));
    schedule1.put(DATE_2, List.of(SOURCE_ID_2));
    NavigableMap<LocalDate, List<Long>> schedule2 = new TreeMap<>();
    schedule2.put(DATE_1, List.of(SOURCE_ID_2));
    FxSourceSchedule expected =
        new FxSourceSchedule(Map.of(BASIS_ID_1, schedule1, BASIS_ID_2, schedule2));

    FxSourceSchedule actual = accountFxSourceService.getFxSourceSchedule(ACCOUNT_ID);
    assertEquals(expected, actual);
  }

  @Test
  void test_update_fx_sources() {
    AccountFxSource accountFxSource1 =
        createAccountFxSource(BASIS_ID_1, DATE_1, SOURCE_ID_1, RANK_1);
    AccountFxSource accountFxSource2 =
        createAccountFxSource(BASIS_ID_1, DATE_2, SOURCE_ID_3, RANK_1);
    AccountFxSource accountFxSource3 =
        createAccountFxSource(BASIS_ID_2, DATE_2, SOURCE_ID_2, RANK_1);
    AccountFxSourceEntity newFxSourceEntity1 =
        accountFxSourceEntityTransformer.apply(accountFxSource1);
    AccountFxSourceEntity newFxSourceEntity2 =
        accountFxSourceEntityTransformer.apply(accountFxSource2);
    AccountFxSourceEntity newFxSourceEntity3 =
        accountFxSourceEntityTransformer.apply(accountFxSource3);
    when(accountFxSourceRepository.saveAndFlush(newFxSourceEntity2)).thenReturn(newFxSourceEntity2);
    when(accountFxSourceRepository.saveAndFlush(newFxSourceEntity3)).thenReturn(newFxSourceEntity3);

    accountFxSourceService.updateFxSources(
        Set.of(accountFxSource1, accountFxSource2, accountFxSource3));
    verify(accountFxSourceRepository)
        .deleteAllById(
            Set.of(
                ACCOUNT_FX_SOURCE_ENTITY_2.toKey(),
                ACCOUNT_FX_SOURCE_ENTITY_3.toKey(),
                ACCOUNT_FX_SOURCE_ENTITY_4.toKey()));
    verify(accountFxSourceRepository, never()).saveAndFlush(newFxSourceEntity1);
    verify(accountFxSourceRepository).saveAndFlush(newFxSourceEntity2);
    verify(accountFxSourceRepository).saveAndFlush(newFxSourceEntity3);
  }

  private static AccountFxSource createAccountFxSource(
      int basisId, LocalDate date, Long sourceId, int rank) {
    return AccountFxSource.builder()
        .accountId(ACCOUNT_ID)
        .date(date)
        .basisId(basisId)
        .fxRateSourceId(sourceId)
        .rankId(rank)
        .modifiedOn(LocalDateTime.now())
        .build();
  }

  private static AccountFxSourceEntity createAccountFxSourceEntity(
      int basisId, LocalDate date, Long sourceId, int rank) {
    return AccountFxSourceEntity.builder()
        .accountId(ACCOUNT_ID)
        .date(date)
        .basisId(basisId)
        .fxRateSourceId(sourceId)
        .rankId(rank)
        .modifiedOn(LocalDateTime.now())
        .build();
  }
}
