package com.cwan.privatefund.document.validation;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.document.dto.DocumentFilterCriteria;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.ConstraintValidatorContext.ConstraintViolationBuilder;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DateRangeValidatorTest {

  private DateRangeValidator validator;
  @Mock private ConstraintValidatorContext context;
  @Mock private ConstraintViolationBuilder builder;

  @Test
  void isValid_WhenBothDatesNull_ReturnsTrue() {
    DocumentFilterCriteria criteria =
        DocumentFilterCriteria.builder().beginDate(null).endDate(null).build();
    boolean result = validator.isValid(criteria, context);
    assertTrue(result);
    verifyNoInteractions(context);
  }

  @Test
  void isValid_WhenEndDateAfterBeginDate_ReturnsTrue() {
    LocalDate beginDate = LocalDate.of(2024, 1, 1);
    LocalDate endDate = LocalDate.of(2024, 12, 31);
    DocumentFilterCriteria criteria =
        DocumentFilterCriteria.builder().beginDate(beginDate).endDate(endDate).build();
    boolean result = validator.isValid(criteria, context);
    assertTrue(result);
    verifyNoInteractions(context);
  }

  @Test
  void isValid_WhenEndDateBeforeBeginDate_ReturnsFalse() {
    LocalDate beginDate = LocalDate.of(2024, 12, 31);
    LocalDate endDate = LocalDate.of(2024, 1, 1);
    DocumentFilterCriteria criteria =
        DocumentFilterCriteria.builder().beginDate(beginDate).endDate(endDate).build();
    when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(builder);
    boolean result = validator.isValid(criteria, context);
    assertFalse(result);
    verify(context).disableDefaultConstraintViolation();
    verify(context)
        .buildConstraintViolationWithTemplate(
            "End date " + endDate + " cannot be before begin date " + beginDate);
    verify(builder).addConstraintViolation();
  }

  @Test
  void isValid_WhenEndDateEqualsBeginDate_ReturnsTrue() {
    LocalDate date = LocalDate.of(2024, 1, 1);
    DocumentFilterCriteria criteria =
        DocumentFilterCriteria.builder().beginDate(date).endDate(date).build();
    boolean result = validator.isValid(criteria, context);
    assertTrue(result);
    verifyNoInteractions(context);
  }

  @Test
  void isValid_WhenOnlyBeginDateNull_ReturnsTrue() {
    DocumentFilterCriteria criteria =
        DocumentFilterCriteria.builder().beginDate(null).endDate(LocalDate.now()).build();
    boolean result = validator.isValid(criteria, context);
    assertTrue(result);
    verifyNoInteractions(context);
  }

  @Test
  void isValid_WhenOnlyEndDateNull_ReturnsTrue() {
    DocumentFilterCriteria criteria =
        DocumentFilterCriteria.builder().beginDate(LocalDate.now()).endDate(null).build();
    boolean result = validator.isValid(criteria, context);
    assertTrue(result);
    verifyNoInteractions(context);
  }

  @BeforeEach
  void setUp() {
    validator = new DateRangeValidator();
  }
}
