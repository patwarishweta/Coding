package com.cwan.privatefund.documentcashflow;

import static com.cwan.privatefund.TestUtil.getDocument;
import static com.cwan.privatefund.TestUtil.getDocumentCashFlow;
import static com.cwan.privatefund.TestUtil.getSecurity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.api.Documents;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.security.SecurityService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

public class DocumentCashflowHydrationServiceTest {

  private static final Long DCF_ID = 1L;
  private static final Document DOCUMENT = getDocument();
  private static final Account ACCOUNT = getAccountData();
  private static final Security SECURITY = getSecurity();
  private static final DocumentCashFlow DOCUMENT_CASH_FLOW = getDocumentCashFlow(DCF_ID);
  @Mock private AccountService accountService;
  @Mock private Documents documents;
  @Mock private SecurityService securityService;
  private DocumentCashflowHydrationService instance;

  public static Account getAccountData() {
    return Account.builder().id(42L).clientId(2L).build();
  }

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(accountService.getAccountsData(any())).thenReturn(Mono.just(List.of(ACCOUNT)));
    when(securityService.getSecurity(any(), any(), any())).thenReturn(Mono.just(SECURITY));
    when(documents.getDocumentById(any())).thenReturn(Mono.just(DOCUMENT));
    instance = new DocumentCashflowHydrationService(accountService, documents, securityService);
  }

  @Test
  void should_hydrate_account_security_and_document_data() {
    var hydratedDocument =
        new Document()
            .toBuilder()
                .id(23L)
                .account(Account.builder().id(42L).clientId(2L).build())
                .security(SECURITY)
                .fileName("file_name")
                .type("capital account")
                .isAudited(Boolean.TRUE)
                .source("canoe")
                .receivedDate(LocalDate.of(2022, 4, 14))
                .documentDate(LocalDate.of(2022, 3, 31))
                .cashMovementDate(LocalDate.of(2022, 4, 1))
                .frequency("quarterly")
                .periodStartDate(LocalDate.of(2022, 1, 1))
                .periodEndDate(LocalDate.of(2022, 3, 31))
                .checked(Boolean.FALSE)
                .canoeId("892994fa-b33c-11eb-ba61-d50ed001af0a")
                .errorStatus("none")
                .directoryId(25L)
                .createdBy("user1")
                .isCreatedByInternalUser(Boolean.TRUE)
                .modifiedBy("user2")
                .isModifiedByInternalUser(Boolean.FALSE)
                .createdOn(LocalDateTime.of(2022, 4, 14, 12, 43, 23))
                .modifiedOn(LocalDateTime.of(2022, 4, 15, 3, 23, 12))
                .build();
    var expectedDocumentCashflow =
        DOCUMENT_CASH_FLOW.toBuilder().document(hydratedDocument).build();
    var actual = instance.hydrate(List.of(DOCUMENT_CASH_FLOW), 23L).block();
    assertEquals(List.of(expectedDocumentCashflow), actual);
  }
}
