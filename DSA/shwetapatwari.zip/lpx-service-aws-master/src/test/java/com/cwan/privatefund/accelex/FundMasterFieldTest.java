package com.cwan.privatefund.accelex;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.ca.tabular.WebService;
import com.ca.tabular.field.DataType;
import com.ca.tabular.field.FieldLink;
import com.ca.tabular.field.FieldType;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.privatefund.accelex.AccelexService.FundMasterKey;
import com.cwan.privatefund.accelex.AccelexService.LpIdentifier;
import java.util.Map;
import org.junit.jupiter.api.Test;

class FundMasterFieldTest {

  @Test
  void testEnumValues() {
    // Verify that the enum contains the correct number of values
    FundMasterField[] values = FundMasterField.values();
    assertEquals(81, values.length); // Update if the number changes

    // Check that all the enum names are as expected
    assertEquals("id", FundMasterField.ID.getName());
    assertEquals("name", FundMasterField.NAME.getName());
    assertEquals("cik", FundMasterField.CIK.getName());
    // Add assertions for other fields as necessary
  }

  @Test
  void testFieldExtraction() {
    // Create a mock FundMasterEntity
    FundMasterEntity entity = new FundMasterEntity();
    entity.setId(123L);
    entity.setName("Test Fund");
    entity.setCik("123456789");
    entity.setEin("987654321");
    // Set additional fields as needed...

    FundMasterField fieldId = FundMasterField.ID;
    FundMasterField fieldName = FundMasterField.NAME;

    // Create a mock FundMasterKey (use any values as needed)
    FundMasterKey key = new FundMasterKey(new LpIdentifier(1L, 1000L), null, null);
    Map.Entry<FundMasterKey, FundMasterEntity> entry = Map.entry(key, entity);

    // Test ID field extraction
    assertEquals(123L, fieldId.apply(entry));
    // Test NAME field extraction
    assertEquals("Test Fund", fieldName.apply(entry));
  }

  @Test
  void testFieldAttributes() {
    // Test attributes for a specific field (e.g., ID)
    FundMasterField fieldId = FundMasterField.ID;

    assertEquals(1, fieldId.getId());
    assertEquals("id", fieldId.getName());
    assertEquals(DataType.LONG, fieldId.getDataType());
    assertNull(fieldId.getEnumReference());
    assertEquals(FieldLink.NONE, fieldId.getFieldLink());
    assertEquals(FieldType.DESCRIPTIVE, fieldId.getFieldType());
    assertEquals(WebService.LPX_SERVICE_BALANCE, fieldId.getWebService());
  }
}
