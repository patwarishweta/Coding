package com.cwan.privatefund;

import java.util.function.Function;
import java.util.function.Predicate;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

public abstract class CustomMinimalForTestResponseSpec implements WebClient.ResponseSpec {

  public abstract HttpStatus getStatus();

  @Override
  public WebClient.@NotNull ResponseSpec onStatus(
      Predicate<HttpStatusCode> statusPredicate,
      @NotNull Function<ClientResponse, Mono<? extends Throwable>> exceptionFunction) {
    if (statusPredicate.test(this.getStatus())) {
      exceptionFunction.apply(ClientResponse.create(HttpStatus.OK).build()).block();
    }
    return this;
  }
}
