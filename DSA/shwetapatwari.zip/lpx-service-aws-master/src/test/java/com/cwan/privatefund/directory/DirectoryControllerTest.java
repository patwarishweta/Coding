package com.cwan.privatefund.directory;

import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getDirectory;
import static com.cwan.privatefund.TestUtil.getDirectoryRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryRequest;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class DirectoryControllerTest extends AuthenticatedControllerTest {

  private static final Long ID = 1L;
  private static final Directory DIRECTORY = getDirectory(ID);
  private static final Set<Directory> DIRECTORY_SET = Set.of(DIRECTORY);
  private static final Flux<Directory> DIRECTORY_FLUX = Flux.fromIterable(DIRECTORY_SET);
  private static final DirectoryRequest DIRECTORY_REQUEST = getDirectoryRequest(ID);
  private static final Mono<DirectoryRequest> REQUEST = Mono.just(DIRECTORY_REQUEST);
  @Autowired private WebTestClient webClient;
  @MockBean private DirectoryService directoryService;
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  private Set<Directory> putForDirectoryEntity() {
    return exchangeForEntity(DirectoryControllerTest.REQUEST)
        .expectStatus()
        .is2xxSuccessful()
        .returnResult(Directory.class)
        .getResponseBody()
        .collect(Collectors.toSet())
        .share()
        .block();
  }

  private WebTestClient.ResponseSpec exchangeForEntity(final Mono<DirectoryRequest> request) {
    return webClient
        .method(HttpMethod.PUT)
        .uri(com.cwan.privatefund.TestUtil.DIRECTORY_URI)
        .body(request, DirectoryRequest.class)
        .exchange();
  }

  @Test
  void should_add_directories_test() {
    Mockito.when(directoryService.addDirectories(any()))
        .thenReturn(Flux.fromIterable(DIRECTORY_SET));
    webClient
        .post()
        .uri("/v1/directory")
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(DIRECTORY_REQUEST)
        .exchange()
        .expectStatus()
        .is2xxSuccessful()
        .expectBodyList(Directory.class)
        .isEqualTo(List.of(DIRECTORY));
  }

  @Test
  void should_get_all_directories_by_accountId_Test() {
    Mockito.when(directoryService.getAllDirectoriesByAccountId(any()))
        .thenReturn(Flux.fromIterable(DIRECTORY_SET));
    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder.path("/v1/directory/account").queryParam("accountId", "1").build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(Directory.class)
        .isEqualTo(List.of(DIRECTORY));
  }

  @Test
  void should_get_all_By_Id_test() {
    Mockito.when(directoryService.getById(any())).thenReturn(Mono.just(DIRECTORY));
    webClient
        .get()
        .uri(uriBuilder -> uriBuilder.path("/v1/directory").queryParam("directoryId", 1L).build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(Directory.class)
        .isEqualTo(DIRECTORY);
  }

  @Test
  void should_update_directory_successfully() {
    Mockito.when(directoryService.updateDirectoryInfo(DIRECTORY_SET)).thenReturn(DIRECTORY_FLUX);
    var actual = putForDirectoryEntity();
    assertEquals(DIRECTORY_SET, actual);
  }
}
