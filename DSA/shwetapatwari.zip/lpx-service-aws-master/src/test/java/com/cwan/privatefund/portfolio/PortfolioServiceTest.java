package com.cwan.privatefund.portfolio;

import static com.cwan.privatefund.TestUtil.getPerformance;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_ACCOUNT_DATA_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.BUSINESS_EXPANDED_ACCOUNTS_CACHE;
import static com.cwan.privatefund.constant.RedisConstants.PORTFOLIO_ACCOUNT_SECURITY_CACHE;
import static org.hibernate.validator.internal.util.Contracts.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Client;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Performance;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.performance.api.Performances;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.business.ws.BusinessWSClient;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.constant.RedisConstants;
import com.cwan.privatefund.portfolio.model.CalculationTask;
import com.cwan.privatefund.portfolio.model.PortfolioData;
import com.cwan.privatefund.portfolio.model.PortfolioData.Ranges;
import com.cwan.privatefund.portfolio.model.PortfolioSummaryResponse;
import com.cwan.privatefund.publisher.MessagePublisher;
import com.cwan.privatefund.security.SecurityService;
import com.cwan.privatefund.transaction.LpxTransactionService;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@SpringBootTest
class PortfolioServiceTest {

  @MockBean private Documents documents;
  @MockBean private Performances performances;
  @MockBean private SecurityService securityService;
  @MockBean private PortfolioWsClient portfolioWsClient;
  @Autowired private PortfolioUtilsService portfolioUtilsService;
  @MockBean private BusinessWSClient businessWSClient;
  @Autowired private PortfolioService portfolioService;
  @MockBean private RedisTemplate<String, Object> redisTemplate;
  @Mock private HashOperations<String, Object, Object> hashOperations;

  private static final Performance PERFORMANCE = getPerformance();
  private static final LocalDate DATE = LocalDate.now();
  private static final Security SECURITY_ONE = Security.builder().securityId(123L).build();
  private static final Security SECURITY_TWO = Security.builder().securityId(321L).build();
  private static final Account ACCOUNT = Account.builder().id(1L).build();
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;
  @MockBean LpxTransactionService lpxTransactionService;
  @MockBean MessagePublisher<CalculationTask> calculationTaskMessagePublisher;

  static {
    System.setProperty("DEVELOPER_WORKSTATION", "true");
    System.setProperty("app/common/jwt_secret", "secret");
    System.setProperty("env", "ci");
  }

  private static final List<Document> DOCUMENTS =
      List.of(
          Document.builder()
              .account(ACCOUNT)
              .security(Security.builder().securityId(123L).build())
              .documentDate(DATE)
              .type("Capital Call Notice")
              .build(),
          Document.builder()
              .account(ACCOUNT)
              .security(Security.builder().securityId(123L).build())
              .documentDate(DATE)
              .type("Capital Distribution Notice")
              .build(),
          Document.builder()
              .account(ACCOUNT)
              .security(Security.builder().securityId(123L).build())
              .documentDate(DATE)
              .type("Capital Account Statement")
              .build());
  private static final Set<PortfolioData> PORTFOLIO_DATA_LIST =
      Set.of(
          PortfolioData.builder()
              .accountId(ACCOUNT.getId())
              .securityId(SECURITY_ONE.getSecurityId())
              .build(),
          PortfolioData.builder()
              .accountId(ACCOUNT.getId())
              .securityId(SECURITY_TWO.getSecurityId())
              .build());

  @BeforeAll
  static void beforeAll() {
    System.setProperty("env", "ci");
  }

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(redisTemplate.opsForHash()).thenReturn(hashOperations);
    when(hashOperations.get(eq(BUSINESS_EXPANDED_ACCOUNTS_CACHE), any())).thenReturn(null);
    when(hashOperations.get(eq(BUSINESS_ACCOUNT_DATA_CACHE), any())).thenReturn(null);
    when(hashOperations.get(eq(PORTFOLIO_ACCOUNT_SECURITY_CACHE), any())).thenReturn(null);
    when(hashOperations.get(eq(RedisConstants.ACCOUNT), any()))
        .thenReturn(List.of(TestUtil.getAccountConfig()));
    when(portfolioWsClient.getPortfolioDataWithCacheCheck(any()))
        .thenReturn(Mono.just(PORTFOLIO_DATA_LIST));
    when(businessWSClient.getAccountsInformation(any()))
        .thenReturn(
            Mono.just(
                List.of(BusinessAccount.builder().id(1L).aggregate(false).clientId(1L).build())));
    when(businessWSClient.getExpandedAccountIds(eq(1L))).thenReturn(Mono.just(List.of(1L)));
    when(businessWSClient.getUserAccountAccess(eq(123), eq(List.of(1L))))
        .thenReturn(Mono.just(Map.of(1L, true)));
    when(businessWSClient.getAccountInformation(any()))
        .thenReturn(
            Mono.just(
                List.of(BusinessAccount.builder().id(1L).aggregate(false).clientId(1L).build())));
    when(portfolioWsClient.getPortfolioDataWithCacheCheck(eq(List.of(ACCOUNT.getId()))))
        .thenReturn(Mono.just(PORTFOLIO_DATA_LIST));
    when(securityService.getSecurity(null, ACCOUNT.getId(), SECURITY_ONE.getSecurityId()))
        .thenReturn(Mono.just(SECURITY_ONE));
    when(securityService.getSecurity(null, ACCOUNT.getId(), SECURITY_TWO.getSecurityId()))
        .thenReturn(Mono.just(SECURITY_TWO));
    when(documents.getDocumentsByAccountId(any())).thenReturn(Flux.fromIterable(DOCUMENTS));
    when(performances
            .getPerformanceByAccountIdSecurityIdFreqAndCalculationDateOrderByModifiedOnDesc(
                any(), any(), eq("ITD"), any()))
        .thenReturn(Mono.just(PERFORMANCE));
    when(businessWSClient.getUltimateParentMapFromAccounts(any()))
        .thenReturn(Mono.just(Map.of(1L, new TreeMap<>(Map.of(1, 1L)))));
    when(businessWSClient.getClientInfo(eq(List.of(1L))))
        .thenReturn(Mono.just(Map.of(1L, Client.builder().name("20026 Client").build())));
  }

  @Test
  void should_get_portfolio_balances() {
    //    var actualFlux = portfolioService.getPortfolioBalances(Set.of(1L), LocalDate.of(2022, 1,
    // 1));
    PortfolioBalance.builder()
        .security(SECURITY_ONE)
        .account(ACCOUNT)
        .callNoticeDate(DATE)
        .distributionNoticeDate(DATE)
        .accountStatementDate(DATE)
        .performance(PERFORMANCE)
        .build();
    verify(performances, times(0))
        .getPerformanceByAccountIdSecurityIdFreqAndCalculationDateOrderByModifiedOnDesc(
            any(), anyLong(), anyString(), any());
  }

  @Test
  void getPortfolioBalancesForDates() {
    Performance expected = new Performance();
    when(performances.getPerformanceByAccountIdSecurityIdFreqAndCalculationDateIn(
            any(), any(), any(), any()))
        .thenReturn(Flux.just(expected));
    Flux<Performance> actual =
        portfolioService.getPerformancesForDates(
            1L, "ITD", Set.of(LocalDate.of(2022, 1, 1).atStartOfDay()));
    StepVerifier.create(actual).thenConsumeWhile(x -> x == expected).expectComplete().verify();
  }

  @Test
  void getEarliestActivePerformancesForAccount() {
    Performance expected = new Performance();
    when(portfolioWsClient.getPortfolioDataWithCacheCheck(any()))
        .thenReturn(Mono.just(PORTFOLIO_DATA_LIST));
    when(performances.getEarliestActivePerformanceByAccountIdSecurityIdAndFreq(any(), any(), any()))
        .thenReturn(Mono.just(expected));
    Flux<Performance> actual = portfolioService.getEarliestActivePerformancesForAccount(1L, "ITD");
    StepVerifier.create(actual).thenConsumeWhile(x -> x == expected).expectComplete().verify();
  }

  @Test
  void fetchAllSecuritiesByAccountId() {
    Security acct3Security = Security.builder().securityId(300L).build();
    Security acct4Security = Security.builder().securityId(400L).build();
    PortfolioData acct3Portfolio =
        PortfolioData.builder().accountId(3L).securityId(acct3Security.getSecurityId()).build();
    PortfolioData acct4Portfolio =
        PortfolioData.builder().accountId(4L).securityId(acct4Security.getSecurityId()).build();

    when(businessWSClient.getExpandedAccountIds(eq(2L))).thenReturn(Mono.just(List.of(3L, 4L)));
    when(portfolioWsClient.getPortfolioDataWithCacheCheck(eq(List.of(3L, 4L))))
        .thenReturn(Mono.just(Set.of(acct3Portfolio, acct4Portfolio)));

    when(securityService.getSecurities(
            isNull(), eq(3L), eq(List.of(acct3Security.getSecurityId()))))
        .thenReturn(Mono.just(List.of(acct3Security)));
    when(securityService.getSecurities(
            isNull(), eq(4L), eq(List.of(acct4Security.getSecurityId()))))
        .thenReturn(Mono.just(List.of(acct4Security)));

    Map<Long, Collection<Security>> expected =
        Map.of(
            3L, List.of(acct3Security),
            4L, List.of(acct4Security));
    StepVerifier.create(portfolioService.fetchAllSecuritiesByAccountId(2L))
        .expectNextMatches(x -> x.keySet().containsAll(expected.keySet()))
        .verifyComplete();
  }

  @Test
  void getAllSecuritiesByAccountId() {
    Security acct3Security = Security.builder().securityId(300L).build();
    Security acct4Security = Security.builder().securityId(400L).build();
    PortfolioData acct3Portfolio =
        PortfolioData.builder().accountId(3L).securityId(acct3Security.getSecurityId()).build();
    PortfolioData acct4Portfolio =
        PortfolioData.builder().accountId(4L).securityId(acct4Security.getSecurityId()).build();

    when(businessWSClient.getExpandedAccountIds(eq(2L))).thenReturn(Mono.just(List.of(3L, 4L)));
    when(portfolioWsClient.getPortfolioDataWithCacheCheck(eq(List.of(3L, 4L))))
        .thenReturn(Mono.just(Set.of(acct3Portfolio, acct4Portfolio)));

    when(securityService.getSecurities(
            isNull(), eq(3L), eq(List.of(acct3Security.getSecurityId()))))
        .thenReturn(Mono.just(List.of(acct3Security)));
    when(securityService.getSecurities(
            isNull(), eq(4L), eq(List.of(acct4Security.getSecurityId()))))
        .thenReturn(Mono.just(List.of(acct4Security)));

    Map<Long, Collection<Security>> expected =
        Map.of(
            3L, List.of(acct3Security),
            4L, List.of(acct4Security));
    StepVerifier.create(portfolioUtilsService.getAllSecuritiesByAccountId(2L))
        .expectNextMatches(x -> x.keySet().containsAll(expected.keySet()))
        .verifyComplete();
  }

  @Test
  void jobRuns() {
    Flux<Map.Entry<String, Transaction>> result =
        Flux.fromIterable(TestUtil.getTransactionRequest().getTransactions())
            .filter(transaction -> !("TRN".equals(transaction.getType())))
            .groupBy(
                transaction ->
                    transaction.getAccount().getId()
                        + ":"
                        + transaction.getSecurity().getSecurityId(),
                2048)
            .flatMap(
                groupedFlux ->
                    groupedFlux
                        .collectList()
                        .map(
                            transactionsList -> {
                              transactionsList.sort(
                                  Comparator.comparing(Transaction::getModifiedOn));
                              return Map.entry(groupedFlux.key(), transactionsList.get(0));
                            }));
    when(lpxTransactionService.getAllAccountsAndMinimumSettleDateTransactionModifiedToday())
        .thenReturn(result);
    portfolioService.reloadPerformanceTillCurrentDate();
    Awaitility.await()
        .atMost(Duration.ofSeconds(5000))
        .untilAsserted(
            () ->
                verify(calculationTaskMessagePublisher, times(1))
                    .publishMessage(any(), any(), anyBoolean()));
  }

  // test irrvaliditycheck method to ensure it nulls out xirr over 500
  @Test
  void irrValidityCheck() {
    PortfolioSummaryResponse portfolioSummary =
        PortfolioSummaryResponse.builder()
            .data(
                List.of(
                    PortfolioBalance.builder()
                        .performance(Performance.builder().netXirr(5.1).build())
                        .build()))
            .build();

    PortfolioSummaryResponse actual = PortfolioService.irrValidityCheck(portfolioSummary);
    assertNull(actual.getData().get(0).getPerformance().getNetXirr());
  }

  @Test
  void testFilterOutClosedLots_noFiltering() {
    LocalDate calculationDate = LocalDate.of(2023, 10, 1);
    boolean filterClosedLots = false;

    PortfolioData portfolioData = createPortfolioData();

    boolean result = PortfolioService.filterOutClosedLots(calculationDate, filterClosedLots, portfolioData);

    assertTrue(result, "Should return true when filterClosedLots is false");
  }

  @Test
  void testFilterOutClosedLots_withActiveRange() {
    LocalDate calculationDate = LocalDate.of(2023, 10, 1);
    boolean filterClosedLots = true;

    PortfolioData portfolioData = createPortfolioData(
        List.of(new Ranges(LocalDate.of(2023, 9, 1), LocalDate.of(2023, 10, 10)))
    );

    boolean result = PortfolioService.filterOutClosedLots(calculationDate, filterClosedLots, portfolioData);

    assertTrue(result, "Should return true when calculationDate is within an active range");
  }

  @Test
  void testFilterOutClosedLots_noActiveRange() {
    LocalDate calculationDate = LocalDate.of(2023, 10, 1);
    boolean filterClosedLots = true;

    PortfolioData portfolioData = createPortfolioData(
        List.of(new Ranges(LocalDate.of(2023, 9, 1), LocalDate.of(2023, 9, 30)))
    );

    boolean result = PortfolioService.filterOutClosedLots(calculationDate, filterClosedLots, portfolioData);

    assertFalse(result, "Should return false when calculationDate is not within any active range");
  }

  @Test
  void testFilterOutClosedLots_emptyRanges() {
    LocalDate calculationDate = LocalDate.of(2023, 10, 1);
    boolean filterClosedLots = true;

    PortfolioData portfolioData = createPortfolioData(List.of());

    boolean result = PortfolioService.filterOutClosedLots(calculationDate, filterClosedLots, portfolioData);

    assertFalse(result, "Should return false when there are no ranges");
  }

  private PortfolioData createPortfolioData(List<Ranges> ranges) {
    PortfolioData portfolioData = new PortfolioData();
    portfolioData.setRanges(ranges);
    return portfolioData;
  }

  // Overloaded createPortfolioData for tests that do not need ranges
  private PortfolioData createPortfolioData() {
    return createPortfolioData(List.of());
  }
}
