package com.cwan.privatefund.portfolio;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.portfolio.PortfolioWsApacheClient.PortfolioLot;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.MockitoAnnotations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class PortfolioWsApacheClientTest {
  private static TestHttpClient testClient = new TestHttpClient();
  private static final FakeWsResponse fakeResponse =
      new FakeWsResponse()
          .setRequestUrl("specialized/holdingAccounts/v1/securities")
          .setStatusCode(200)
          .setBody("[1,2,3]");

  private Cache<Long, List<PortfolioLot>> accountToPortfolioLotsCache;

  private static final String fakeResponseForLotBySecurity2 =
      """
      [
        {
          "lotId": "0a753a38-bb01-11ee-a136-1d4345302f24",
          "parentLotId": null,
          "accountId": 358400,
          "securityId": 1,
          "entryOrigTranId": 1186612316,
          "entryTranUnitChangeId": 1,
          "inventoryType": "LONG",
          "lotUnitChanges": [
            {
              "entryDate": "2023-12-31",
              "settlePostDate": "2023-12-31",
              "origTranId": 1186612316,
              "units": 1,
              "tranUnitChangeId": 1,
              "position": 0
            }
          ]
        },
        {
          "lotId": "3bfa6916-1411-11ee-8036-954450650724",
          "parentLotId": null,
          "accountId": 358400,
          "securityId": 1,
          "entryOrigTranId": 1056869367,
          "entryTranUnitChangeId": 1,
          "inventoryType": "LONG",
          "lotUnitChanges": [
            {
              "entryDate": "2023-03-31",
              "settlePostDate": "2023-03-31",
              "origTranId": 1056869367,
              "units": 1,
              "tranUnitChangeId": 1,
              "position": 0
            },
            {
              "entryDate": "2023-12-30",
              "settlePostDate": "2023-12-30",
              "origTranId": 1185952440,
              "units": -1,
              "tranUnitChangeId": 1,
              "position": 1
            }
          ]
        }
      ]""";

  private static final FakeWsResponse fakeResponseForLotBySecurity =
      new FakeWsResponse()
          .setRequestUrl("lots/v2/accounts/1/securities")
          .setStatusCode(200)
          .setBody(fakeResponseForLotBySecurity2);

  private static final FakeWsResponse badResponse =
      new FakeWsResponse()
          .setRequestUrl("lots/v2/accounts/1/securities")
          .setStatusCode(500)
          .setBody("lol");

  private PortfolioWsApacheClient INSTANCE;

  @BeforeEach
  void setup() {
    accountToPortfolioLotsCache =
        CacheBuilder.newBuilder().maximumSize(50000).expireAfterWrite(4, TimeUnit.HOURS).build();
    testClient = new TestHttpClient();
    INSTANCE =
        new PortfolioWsApacheClient(
            testClient,
            new ServerConfiguration("portfolio-ws", 8084, "portfolio-ws", Scheme.HTTPS),
            accountToPortfolioLotsCache);
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testGetAccountIdsBySecurityId() {
    testClient.setResponses(fakeResponse);

    Set<Long> accountIdsBySecurityId =
        INSTANCE.getAccountIdsBySecurityId(1L, LocalDate.of(2023, 8, 1));
    assertTrue(accountIdsBySecurityId.contains(1L));
    assertTrue(accountIdsBySecurityId.contains(2L));
    assertTrue(accountIdsBySecurityId.contains(3L));
  }

  @Test
  void testGetPortfolioLots_exception() {
    testClient.setResponses(badResponse);

    assertThrows(RuntimeException.class, () -> INSTANCE.getPortfolioLots(1L, Set.of(1L, 2L, 3L)));
  }

  @Test
  void testGetPortfolioLots_IOexception() {
    testClient.setResponses();

    assertThrows(RuntimeException.class, () -> INSTANCE.getPortfolioLots(1L, Set.of(1L, 2L, 3L)));
  }

  @Test
  void serializeLotUnitChange() throws JsonProcessingException {
    PortfolioWsApacheClient.LotUnitChange lotUnitChange =
        new PortfolioWsApacheClient.LotUnitChange(
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 1, 5), 123L, 100);
    String json = TestUtil.getObjectMapper().writeValueAsString(lotUnitChange);
    PortfolioWsApacheClient.LotUnitChange deserialized =
        TestUtil.getObjectMapper().readValue(json, PortfolioWsApacheClient.LotUnitChange.class);
    assertTrue(lotUnitChange.equals(deserialized));
  }

  @Test
  void serializePortfolioLot() throws JsonProcessingException {
    PortfolioWsApacheClient.LotUnitChange lotUnitChange1 =
        new PortfolioWsApacheClient.LotUnitChange(
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 1, 5), 123L, 100);
    PortfolioWsApacheClient.LotUnitChange lotUnitChange2 =
        new PortfolioWsApacheClient.LotUnitChange(
            LocalDate.of(2022, 2, 1), LocalDate.of(2022, 2, 5), 456L, 200);
    PortfolioWsApacheClient.LotUnitChange lotUnitChange3 =
        new PortfolioWsApacheClient.LotUnitChange(
            LocalDate.of(2022, 3, 1), LocalDate.of(2022, 3, 5), 789L, 300);
    PortfolioWsApacheClient.PortfolioLot portfolioLot =
        new PortfolioWsApacheClient.PortfolioLot(
            123456789, 987654321, List.of(lotUnitChange1, lotUnitChange2, lotUnitChange3));
    String json = TestUtil.getObjectMapper().writeValueAsString(portfolioLot);
    PortfolioWsApacheClient.PortfolioLot deserialized =
        TestUtil.getObjectMapper().readValue(json, PortfolioWsApacheClient.PortfolioLot.class);
    assertTrue(portfolioLot.equals(deserialized));
  }

  @Test
  void testGetLotEffectiveRangeMap() {
    testClient.setResponses(fakeResponseForLotBySecurity);

    Set<Long> securityIds = Set.of(1L);
    Long accountId = 1L;
    Map<Long, List<LocalDateRange>> lotEffectiveRangeMap =
        INSTANCE.getLotEffectiveRangeMap(accountId, securityIds);
    List<LocalDateRange> localDateRanges = lotEffectiveRangeMap.get(1L);
    assertTrue(localDateRanges.get(0).contains(LocalDate.of(2023, 12, 31)));
  }
}
