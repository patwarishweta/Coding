package com.cwan.privatefund.issuestore;

import static com.cwan.privatefund.TestUtil.getDeletedIssue;
import static com.cwan.privatefund.TestUtil.getIssue;
import static com.cwan.privatefund.constant.Constants.IssueTypes.MISSING_DOCUMENT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.issuestore.model.Issue;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class IssueServiceTest {

  @Mock private IssueStoreClient issueStoreClient;
  @Mock private AccountService accountService;
  private static final Long DOCUMENT_ID = 42L;
  private static final Long ACCOUNT_ID = 1337L;
  private static final Integer USER_ID = 9;
  private static final LocalDate END_DATE = LocalDate.of(2022, 10, 31);
  private static final Issue ISSUE = getIssue();
  private static final Issue ISSUE_WITH_DELETED_STATUS = getDeletedIssue();
  private IssueService instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(accountService.retrieveUserAccessibleAccountIds(eq(USER_ID)))
        .thenReturn(Mono.just(Set.of(ACCOUNT_ID)));
    when(issueStoreClient.getIssuesByTypeName(eq(MISSING_DOCUMENT)))
        .thenReturn(Flux.just(ISSUE, ISSUE_WITH_DELETED_STATUS));
    instance = new IssueService(issueStoreClient, accountService);
  }

  @Test
  void should_get_document_errors() {
    when(issueStoreClient.getIssuesByTag(eq(DOCUMENT_ID.toString()))).thenReturn(Flux.just(ISSUE));
    var actual = instance.getDocumentErrors(DOCUMENT_ID).blockFirst();
    assertEquals(ISSUE, actual);
  }

  @Test
  void should_filter_deleted_document_errors() {
    when(issueStoreClient.getIssuesByTag(eq(DOCUMENT_ID.toString())))
        .thenReturn(Flux.just(ISSUE, ISSUE_WITH_DELETED_STATUS));
    var issueList = instance.getDocumentErrors(DOCUMENT_ID).collectList().block();
    assertTrue(Objects.requireNonNull(issueList).contains(ISSUE));
    assertFalse(issueList.contains(ISSUE_WITH_DELETED_STATUS));
  }

  @Test
  void should_get_missing_documents() {
    var beginDate = LocalDate.of(2022, 10, 1);
    var actual = instance.getMissingDocumentsByUserId(USER_ID, beginDate, END_DATE).blockFirst();
    assertEquals(ISSUE, actual);
  }

  @Test
  void should_filter_deleted_missing_documents_error() {
    var beginDate = LocalDate.of(2022, 10, 1);
    var issueList =
        instance.getMissingDocumentsByUserId(USER_ID, beginDate, END_DATE).collectList().block();
    assertTrue(Objects.requireNonNull(issueList).contains(ISSUE));
    assertFalse(issueList.contains(ISSUE_WITH_DELETED_STATUS));
  }

  @Test
  void should_filter_by_date_in_range() {
    var beginDate = LocalDate.of(2022, 10, 15);
    var actual =
        instance.getMissingDocumentsByUserId(USER_ID, beginDate, END_DATE).collectList().block();
    assertTrue(Objects.requireNonNull(actual).isEmpty());
  }

  @Test
  void should_update_issue_service() {
    Set<Issue> issues = new HashSet<>();
    issues.add(ISSUE);
    System.out.println(ISSUE);
    when(issueStoreClient.updateIssue(ISSUE)).thenReturn(Mono.just(ISSUE));
    var result = instance.updateIssues(issues);
    StepVerifier.create(result).expectNext(ISSUE).verifyComplete();
  }
}
