package com.cwan.privatefund.capital.call.service;

import static com.cwan.lpx.domain.CapitalCallStatus.BLACKLISTED;
import static com.cwan.lpx.domain.CapitalCallStatus.COMPLETED;
import static com.cwan.lpx.domain.CapitalCallStatus.FINAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.INITIAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK_REJECTED;
import static com.cwan.privatefund.TestUtil.getUser;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DateConstants;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.auth.SecurityContextService;
import com.cwan.privatefund.auth.SecurityContextUserService;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.constant.CapitalCallAccessType;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class LpxCapitalCallServiceTest {

  @Mock private CapitalCalls capitalCalls;
  @Mock private AccountService accountService;
  @Mock private CapitalCallEnrichmentService capitalCallEnrichmentService;
  @Mock private CapitalCallAuditService capitalCallAuditService;
  @Mock private CapitalCallAccessService capitalCallAccessService;
  @Mock private SecurityContextUserService securityContextUserService;
  @Mock private SecurityContextService securityContextService;
  @Mock private SecurityContext securityContext;
  @Mock private CapitalCallEmailNotificationService capitalCallEmailNotificationService;
  @Mock private CapitalCallBankAccountVerifierService capitalCallBankAccountVerifierService;
  @Mock private CapitalCallStatusUpdaterService capitalCallStatusUpdaterService;
  @Mock private CapitalCallPaymentInitiationService capitalCallPaymentInitiationService;
  @InjectMocks private LpxCapitalCallService service;

  @BeforeEach
  void setUp() {
    when(securityContextService.getContext()).thenReturn(Mono.just(securityContext));
    doNothing()
        .when(capitalCallEmailNotificationService)
        .enqueueDocumentForEmail(any(CapitalCallDocument.class));
    var logger = (Logger) LoggerFactory.getLogger(LpxCapitalCallService.class);
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    logger.addAppender(listAppender);
  }

  @Test
  void getCapitalCallsByAccounts_errorFetchingUserAccountIds() {
    var userId = 1;
    when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(User.builder().id(userId).email("testuser@example.com").build()));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.error(new RuntimeException()));
    StepVerifier.create(service.fetchAllCapitalCallsByAccounts(null))
        .verifyError(RuntimeException.class);
  }

  @Test
  void updateCapitalCallStatus_errorCheckingUserAccess() {
    var documentId = 1L;
    var action = CapitalCallAction.APPROVE;
    var comment = "Comment";
    var user = getUser();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .thenReturn(Mono.error(new RuntimeException()));
    StepVerifier.create(
            service.updateCapitalCallStatus(
                documentId, CapitalCallStatus.WIRE_CHECK, action, comment))
        .verifyError(RuntimeException.class);
  }

  @Test
  void getCapitalCallAuditByDocument_errorCheckingUserAccess() {
    var documentId = 1L;
    var user = getUser();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.READ))
        .thenReturn(Mono.error(new RuntimeException()));
    StepVerifier.create(service.getCapitalCallAuditByDocument(documentId))
        .verifyError(RuntimeException.class);
  }

  @Test
  void getCapitalCallsByAccounts() {
    var userId = 1;
    var accountId = 1L;
    var accountIds = Collections.singleton(accountId);
    var document = CapitalCallDocument.builder().build();
    when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(getUser()));
    when(accountService.retrieveUserAccessibleAccountIds(userId)).thenReturn(Mono.just(accountIds));
    when(capitalCalls.getCapitalCallsByAccounts(
            CapitalCallDateFilterType.RECEIVED_DATE,
            DateConstants.MIN_START_DATE,
            DateConstants.MAX_END_DATE,
            accountIds,
            Set.of(
                WIRE_CHECK,
                INITIAL_REVIEW,
                FINAL_REVIEW,
                COMPLETED,
                BLACKLISTED,
                WIRE_CHECK_REJECTED)))
        .thenReturn(Flux.just(document));
    when(capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(any(), any()))
        .thenReturn(Flux.just(document));
    when(capitalCallBankAccountVerifierService.verifyAndSetBufferedNewBankAccountFlag(any()))
        .thenReturn(Flux.just(document));
    StepVerifier.create(service.fetchAllCapitalCallsByAccounts(null))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void updateCapitalCallStatus() {
    var documentId = 1L;
    var action = CapitalCallAction.APPROVE;
    var comment = "Comment";
    var user = User.builder().build();
    var document = CapitalCallDocument.builder().build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .thenReturn(Mono.just(document));
    when(capitalCallStatusUpdaterService.updateStatusAndTransform(
            any(), any(), any(), any(), any()))
        .thenReturn(Mono.just(document));
    StepVerifier.create(
            service.updateCapitalCallStatus(
                documentId, CapitalCallStatus.WIRE_CHECK, action, comment))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void getCapitalCallAuditByDocument() {
    var documentId = 1L;
    var user = User.builder().build();
    var log = CapitalCallAuditLog.builder().build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.READ))
        .thenReturn(Mono.just(CapitalCallDocument.builder().build()));
    when(capitalCallAuditService.getAuditLog(documentId)).thenReturn(Mono.just(log));
    StepVerifier.create(service.getCapitalCallAuditByDocument(documentId))
        .expectNext(log)
        .verifyComplete();
  }

  @Test
  void getCapitalCallsByAccounts_errorInEnrichment() {
    var userId = 1;
    var accountId = 1L;
    var accountIds = Collections.singleton(accountId);
    var document = CapitalCallDocument.builder().build();
    when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.just(User.builder().id(userId).email("testuser@example.com").build()));
    when(accountService.retrieveUserAccessibleAccountIds(userId)).thenReturn(Mono.just(accountIds));
    when(capitalCalls.getCapitalCallsByAccounts(
            CapitalCallDateFilterType.RECEIVED_DATE,
            DateConstants.MIN_START_DATE,
            DateConstants.MAX_END_DATE,
            accountIds,
            Set.of(
                WIRE_CHECK,
                INITIAL_REVIEW,
                FINAL_REVIEW,
                COMPLETED,
                BLACKLISTED,
                WIRE_CHECK_REJECTED)))
        .thenReturn(Flux.just(document));
    when(capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(any(), eq(null)))
        .thenReturn(Flux.error(new RuntimeException()));
    when(capitalCallBankAccountVerifierService.verifyAndSetBufferedNewBankAccountFlag(any()))
        .thenReturn(Flux.just(document));
    StepVerifier.create(service.fetchAllCapitalCallsByAccounts(null))
        .verifyError(RuntimeException.class);
  }

  @Test
  void updateCapitalCallStatus_errorInEnrichment() {
    var documentId = 1L;
    var action = CapitalCallAction.APPROVE;
    var comment = "Comment";
    var user = getUser();
    var document = CapitalCallDocument.builder().build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .thenReturn(Mono.just(document));
    StepVerifier.create(
            service.updateCapitalCallStatus(
                documentId, CapitalCallStatus.WIRE_CHECK, action, comment))
        .verifyError(RuntimeException.class);
  }

  @Test
  void getCapitalCallAuditByDocument_errorInAuditLog() {
    var documentId = 1L;
    var user = getUser();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.READ))
        .thenReturn(Mono.just(CapitalCallDocument.builder().build()));
    when(capitalCallAuditService.getAuditLog(documentId))
        .thenReturn(Mono.error(new RuntimeException()));
    StepVerifier.create(service.getCapitalCallAuditByDocument(documentId))
        .verifyError(RuntimeException.class);
  }

  @Test
  void updateCapitalCallStatus_success() {
    var documentId = 1L;
    var action = CapitalCallAction.APPROVE;
    var comment = "Comment";
    var user = getUser();
    var document = CapitalCallDocument.builder().status(CapitalCallStatus.NOT_SPECIFIED).build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .thenReturn(Mono.just(document));
    when(capitalCallStatusUpdaterService.updateStatusAndTransform(
            any(), any(), any(), any(), any()))
        .thenReturn(Mono.just(document));
    var logger = (Logger) LoggerFactory.getLogger(LpxCapitalCallService.class);
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    logger.addAppender(listAppender);
    StepVerifier.create(
            service.updateCapitalCallStatus(
                documentId, CapitalCallStatus.WIRE_CHECK, action, comment))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void updateCapitalCallStatus_errorInCapitalCallsUpdate() {
    var documentId = 1L;
    var action = CapitalCallAction.APPROVE;
    var comment = "Comment";
    var user = getUser();
    var document = CapitalCallDocument.builder().build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .thenReturn(Mono.just(document));
    var logger = (Logger) LoggerFactory.getLogger(LpxCapitalCallService.class);
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    logger.addAppender(listAppender);
    StepVerifier.create(
            service.updateCapitalCallStatus(
                documentId, CapitalCallStatus.WIRE_CHECK, action, comment))
        .verifyError(RuntimeException.class);
  }

  @Test
  void getCapitalCallsByStatuses_success() {
    Set<CapitalCallStatus> statuses =
        new HashSet<>(Arrays.asList(CapitalCallStatus.WIRE_CHECK, CapitalCallStatus.FINAL_REVIEW));
    var document = CapitalCallDocument.builder().build();
    when(capitalCalls.getCapitalCallsByStatuses(statuses)).thenReturn(Flux.just(document));
    when(capitalCallEnrichmentService.enrichCapitalCallWithData(any(), anyString()))
        .thenReturn(Mono.just(document));
    when(capitalCallBankAccountVerifierService.verifyAndSetBufferedNewBankAccountFlag(any()))
        .thenReturn(Flux.just(document));
    StepVerifier.create(service.getCapitalCallsByStatuses(statuses))
        .expectNext(document)
        .verifyComplete();
  }

  @Test
  void getCapitalCallsByStatuses_error() {
    Set<CapitalCallStatus> statuses =
        new HashSet<>(Arrays.asList(CapitalCallStatus.WIRE_CHECK, CapitalCallStatus.FINAL_REVIEW));
    when(capitalCalls.getCapitalCallsByStatuses(statuses))
        .thenReturn(Flux.error(new RuntimeException()));
    StepVerifier.create(service.getCapitalCallsByStatuses(statuses))
        .verifyError(RuntimeException.class);
  }

  @Test
  void insertMissedCapitalCalls_success() {
    when(capitalCalls.insertMissedCapitalCalls()).thenReturn(Mono.empty());
    StepVerifier.create(service.insertMissedCapitalCalls()).verifyComplete();
  }

  @Test
  void insertMissedCapitalCalls_error() {
    when(capitalCalls.insertMissedCapitalCalls()).thenReturn(Mono.error(new RuntimeException()));
    StepVerifier.create(service.insertMissedCapitalCalls()).expectNext(false).verifyComplete();
  }

  @Test
  void processPaymentInitiation_Success() {
    Long documentId = 1L;
    var user = User.builder().id(1).build();
    var capitalCallDocument = CapitalCallDocument.builder().documentId(documentId).build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.READ))
        .thenReturn(Mono.just(capitalCallDocument));
    when(capitalCallPaymentInitiationService.processPaymentInitiation(capitalCallDocument))
        .thenReturn(Mono.just("Success"));
    StepVerifier.create(service.processPaymentInitiation(documentId))
        .expectNext("Success")
        .verifyComplete();
  }

  @Test
  void processPaymentInitiation_Failure_SecurityContext() {
    Long documentId = 1L;
    when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.error(new RuntimeException("Security Context Error")));
    StepVerifier.create(service.processPaymentInitiation(documentId))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof RuntimeException)
                    && "Security Context Error".equals(throwable.getMessage()))
        .verify();
  }

  @Test
  void processPaymentInitiation_Failure_UserValidation() {
    Long documentId = 1L;
    when(securityContextUserService.validateAndRetrieveUserDetails())
        .thenReturn(Mono.error(new RuntimeException("User Validation Error")));
    StepVerifier.create(service.processPaymentInitiation(documentId))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof RuntimeException)
                    && "User Validation Error".equals(throwable.getMessage()))
        .verify();
  }

  @Test
  void processPaymentInitiation_Failure_UserAccessCheck() {
    Long documentId = 1L;
    var user = User.builder().id(1).build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.READ))
        .thenReturn(Mono.error(new RuntimeException("Access Denied")));
    StepVerifier.create(service.processPaymentInitiation(documentId))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof RuntimeException)
                    && "Access Denied".equals(throwable.getMessage()))
        .verify();
  }

  @Test
  void processPaymentInitiation_Failure_PaymentProcess() {
    Long documentId = 1L;
    var user = User.builder().id(1).build();
    var capitalCallDocument = CapitalCallDocument.builder().documentId(documentId).build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.READ))
        .thenReturn(Mono.just(capitalCallDocument));
    when(capitalCallPaymentInitiationService.processPaymentInitiation(capitalCallDocument))
        .thenReturn(Mono.error(new RuntimeException("Payment Processing Error")));
    StepVerifier.create(service.processPaymentInitiation(documentId))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof RuntimeException)
                    && "Payment Processing Error".equals(throwable.getMessage()))
        .verify();
  }

  @Test
  void fetchCapitalCallsWithinDateRange_withUltimateParentClientId_success() {
    var userId = 123;
    var ultimateParentClientId = 456;
    var start = LocalDate.now().minusDays(10);
    var end = LocalDate.now();
    var user = User.builder().id(userId).email("testuser@example.com").build();
    var mockDocument = CapitalCallDocument.builder().documentId(1L).build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(accountService.retrieveAccountMapByUltimateParent(userId))
        .thenReturn(Mono.just(Map.of(ultimateParentClientId, Set.of(10L, 20L))));
    when(capitalCalls.getCapitalCallsByAccounts(
            CapitalCallDateFilterType.RECEIVED_DATE,
            start,
            end,
            Set.of(10L, 20L),
            Set.of(
                WIRE_CHECK,
                INITIAL_REVIEW,
                FINAL_REVIEW,
                COMPLETED,
                BLACKLISTED,
                WIRE_CHECK_REJECTED)))
        .thenReturn(Flux.just(mockDocument));
    when(capitalCallBankAccountVerifierService.verifyAndSetBufferedNewBankAccountFlag(any()))
        .thenReturn(Flux.just(mockDocument));
    when(capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(any(), anyString()))
        .thenReturn(Flux.just(mockDocument));
    StepVerifier.create(
            service.fetchCapitalCallsWithinDateRange(
                CapitalCallDateFilterType.RECEIVED_DATE, start, end, ultimateParentClientId))
        .expectNextMatches(doc -> doc.documentId().equals(1L))
        .verifyComplete();
  }

  @Test
  void fetchCapitalCallsWithinDateRange_withUltimateParentClientId_errorNotAssociated() {
    var userId = 123;
    var ultimateParentClientId = 999;
    var start = LocalDate.now().minusDays(10);
    var end = LocalDate.now();
    var user = User.builder().id(userId).email("testuser@example.com").build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(accountService.retrieveAccountMapByUltimateParent(userId))
        .thenReturn(Mono.just(Map.of(456, Set.of(10L, 20L))));
    StepVerifier.create(
            service.fetchCapitalCallsWithinDateRange(
                CapitalCallDateFilterType.RECEIVED_DATE, start, end, ultimateParentClientId))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof ResponseStatusException)
                    && throwable
                        .getMessage()
                        .contains("Unauthorized: Ultimate Parent Client ID not associated"))
        .verify();
  }

  @Test
  void fetchDetailedAuditForCapitalCalls_success() {
    var start = LocalDate.now().minusDays(5);
    var end = LocalDate.now();
    var user = getUser();
    var document =
        CapitalCallDocument.builder()
            .documentId(1L)
            .audit(
                Collections.singletonList(
                    CapitalCallAudit.builder()
                        .previousStatus(CapitalCallStatus.NEW_CAPITAL_CALL)
                        .nextStatus(CapitalCallStatus.WIRE_CHECK)
                        .build()))
            .build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(accountService.retrieveUserAccessibleAccountIds(user.getId()))
        .thenReturn(Mono.just(Set.of(1L, 2L)));
    when(capitalCalls.getCapitalCallsByAccounts(
            CapitalCallDateFilterType.RECEIVED_DATE,
            start,
            end,
            Set.of(1L, 2L),
            Set.of(
                WIRE_CHECK,
                INITIAL_REVIEW,
                FINAL_REVIEW,
                COMPLETED,
                BLACKLISTED,
                WIRE_CHECK_REJECTED)))
        .thenReturn(Flux.just(document));
    when(capitalCallBankAccountVerifierService.verifyAndSetBufferedNewBankAccountFlag(any()))
        .thenReturn(Flux.just(document));
    when(capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(any(), anyString()))
        .thenReturn(Flux.just(document));
    when(capitalCallAuditService.getAuditLog(any())).thenReturn(Mono.empty());
    StepVerifier.create(
            service.fetchDetailedAuditForCapitalCalls(
                CapitalCallDateFilterType.RECEIVED_DATE, start, end, null))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void fetchDetailedAuditForCapitalCalls_error() {
    var start = LocalDate.now().minusDays(5);
    var end = LocalDate.now();
    var user = getUser();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(accountService.retrieveUserAccessibleAccountIds(user.getId()))
        .thenReturn(Mono.just(Set.of(1L, 2L)));
    when(capitalCalls.getCapitalCallsByAccounts(
            CapitalCallDateFilterType.RECEIVED_DATE,
            start,
            end,
            Set.of(1L, 2L),
            Set.of(
                WIRE_CHECK,
                INITIAL_REVIEW,
                FINAL_REVIEW,
                COMPLETED,
                BLACKLISTED,
                WIRE_CHECK_REJECTED)))
        .thenReturn(Flux.error(new RuntimeException("Test Error")));
    StepVerifier.create(
            service.fetchDetailedAuditForCapitalCalls(
                CapitalCallDateFilterType.RECEIVED_DATE, start, end, null))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof RuntimeException)
                    && "Test Error".equals(throwable.getMessage()))
        .verify();
  }

  @Test
  void insertMissedCapitalCalls_rowsInsertedGreaterThanZero() {
    when(capitalCalls.insertMissedCapitalCalls()).thenReturn(Mono.just(5));
    StepVerifier.create(service.insertMissedCapitalCalls()).expectNext(true).verifyComplete();
  }

  @Test
  void retrieveCapitalCallsForUser_userHasNoAccounts() {
    var userId = 111;
    var user = User.builder().id(userId).email("testuser@example.com").build();
    var start = LocalDate.now().minusDays(5);
    var end = LocalDate.now();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(Collections.emptySet()));
    StepVerifier.create(
            service.fetchCapitalCallsWithinDateRange(
                CapitalCallDateFilterType.RECEIVED_DATE, start, end, null))
        .verifyComplete();
  }

  @Test
  void processAccountIds_handlesMultipleBuffers() {
    var userId = 555;
    var user = User.builder().id(userId).email("testuser@example.com").build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    Set<Long> allAccounts = new HashSet<>();
    for (var i = 1L; i <= 501; i++) {
      allAccounts.add(i);
    }
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(allAccounts));
    var mockDocument = CapitalCallDocument.builder().documentId(999L).build();
    when(capitalCalls.getCapitalCallsByAccounts(
            any(),
            any(),
            any(),
            anySet(),
            eq(
                Set.of(
                    WIRE_CHECK,
                    INITIAL_REVIEW,
                    FINAL_REVIEW,
                    COMPLETED,
                    BLACKLISTED,
                    WIRE_CHECK_REJECTED))))
        .thenReturn(Flux.just(mockDocument));
    when(capitalCallBankAccountVerifierService.verifyAndSetBufferedNewBankAccountFlag(any()))
        .thenReturn(Flux.just(mockDocument));
    when(capitalCallEnrichmentService.enrichAndProcessBatchOfCapitalCalls(any(), anyString()))
        .thenReturn(Flux.just(mockDocument));
    StepVerifier.create(
            service.fetchCapitalCallsWithinDateRange(
                CapitalCallDateFilterType.RECEIVED_DATE,
                LocalDate.now().minusDays(3),
                LocalDate.now(),
                null))
        .expectNextCount(2)
        .verifyComplete();
  }

  @Test
  void fetchBufferedCapitalCalls_emptyFluxFromCapitalCalls() {
    var userId = 777;
    var user = User.builder().id(userId).email("testuser@example.com").build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(accountService.retrieveUserAccessibleAccountIds(userId))
        .thenReturn(Mono.just(Set.of(100L)));
    when(capitalCalls.getCapitalCallsByAccounts(
            any(),
            any(),
            any(),
            eq(Set.of(100L)),
            eq(
                Set.of(
                    WIRE_CHECK,
                    INITIAL_REVIEW,
                    FINAL_REVIEW,
                    COMPLETED,
                    BLACKLISTED,
                    WIRE_CHECK_REJECTED))))
        .thenReturn(Flux.empty());
    StepVerifier.create(
            service.fetchCapitalCallsWithinDateRange(
                CapitalCallDateFilterType.RECEIVED_DATE,
                LocalDate.now().minusDays(2),
                LocalDate.now(),
                null))
        .verifyComplete();
  }

  @Test
  void updateCapitalCallStatus_doOnNextEmailNotification() {
    var documentId = 1L;
    var action = CapitalCallAction.APPROVE;
    var comment = "Some comment";
    var user = getUser();
    var document = CapitalCallDocument.builder().documentId(documentId).build();
    when(securityContextUserService.validateAndRetrieveUserDetails()).thenReturn(Mono.just(user));
    when(capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .thenReturn(Mono.just(document));
    when(capitalCallStatusUpdaterService.updateStatusAndTransform(
            any(), any(), any(), any(), any()))
        .thenReturn(Mono.just(document));
    StepVerifier.create(service.updateCapitalCallStatus(documentId, WIRE_CHECK, action, comment))
        .expectNextMatches(doc -> doc.documentId().equals(documentId))
        .verifyComplete();
  }
}
