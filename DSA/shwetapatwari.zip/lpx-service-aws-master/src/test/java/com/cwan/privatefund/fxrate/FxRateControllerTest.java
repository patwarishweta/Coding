package com.cwan.privatefund.fxrate;

import static com.cwan.privatefund.TestUtil.FX_RATES_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class FxRateControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private LpxFxRateService lpxFxRateService;
  @MockBean private FxRateJobRunner fxRateJobRunner;

  private static final Long BASE_CURRENCY_ID = 1L;
  private static final Long ACCOUNT_ID = 2L;
  private static final Long SECURITY_ID_1 = 3L;
  private static final Long SECURITY_ID_2 = 4L;
  private static final Long LOCAL_CURRENCY_ID = 4L;
  private static final LocalDate DATE = LocalDate.of(2024, 1, 1);
  private static final Map<Long, Map<LocalDate, Double>> AVG_RATE_MAP =
      Map.of(
          2L, Map.of(DATE, 1.0),
          3L, Map.of(DATE.plusDays(1), 2.0));
  private static final Map<Integer, Map<Long, Map<LocalDate, Double>>> AVG_RATE_MAP_BY_BASIS =
      Map.of(AccountFxSource.NOT_BASIS_SPECIFIC_ID, AVG_RATE_MAP);

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_get_average_fx_rates_by_account() {
    when(lpxFxRateService.getSecurityAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID))
        .thenReturn(AVG_RATE_MAP_BY_BASIS);
    ParameterizedTypeReference<Map<Long, Map<LocalDate, Double>>> returnType =
        new ParameterizedTypeReference<>() {};
    var actual =
        getResponse(
            HttpMethod.GET,
            format(
                "%s%s%d%s%d",
                FX_RATES_URI,
                "/average/base-currency/",
                BASE_CURRENCY_ID,
                "?accountId=",
                ACCOUNT_ID),
            returnType);
    assertEquals(AVG_RATE_MAP, actual);
  }

  @Test
  void get_average_fx_rates() {
    when(lpxFxRateService.getSecurityAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID))
        .thenReturn(AVG_RATE_MAP_BY_BASIS);
    FxRateController fxRateController =
        new FxRateController(lpxFxRateService, fxRateJobRunner, TestUtil.getObjectMapper());
    ResponseEntity averageFxRates =
        fxRateController.getAverageFxRates(BASE_CURRENCY_ID, ACCOUNT_ID, true);
    assertEquals(HttpStatus.OK, averageFxRates.getStatusCode());
  }

  @Test
  void get_average_fx_rates_by_basis() {
    when(lpxFxRateService.getSecurityAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID))
        .thenReturn(AVG_RATE_MAP_BY_BASIS);
    FxRateController fxRateController =
        new FxRateController(lpxFxRateService, fxRateJobRunner, TestUtil.getObjectMapper());
    ResponseEntity averageFxRates =
        fxRateController.getAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID, true);
    assertEquals(HttpStatus.OK, averageFxRates.getStatusCode());
  }

  @Test
  void should_get_average_fx_rate() {
    double averageFxRate = 0.23;
    when(lpxFxRateService.getAverageFxRate(ACCOUNT_ID, SECURITY_ID_1, LOCAL_CURRENCY_ID, DATE))
        .thenReturn(Mono.just(averageFxRate));
    var actual =
        getResponse(
            HttpMethod.GET,
            format(
                "%s%s%d%s%d%s%d%s%s",
                FX_RATES_URI,
                "/average?accountId=",
                ACCOUNT_ID,
                "&securityId=",
                SECURITY_ID_1,
                "&localCurrencyId=",
                LOCAL_CURRENCY_ID,
                "&date=",
                DATE.format(DateTimeFormatter.ISO_DATE)),
            Double.class);
    assertEquals(averageFxRate, actual);
  }

  @Test
  void should_get_average_fx_rates_by_account_and_basis() {
    when(lpxFxRateService.getSecurityAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID))
        .thenReturn(AVG_RATE_MAP_BY_BASIS);
    ParameterizedTypeReference<Map<Integer, Map<Long, Map<LocalDate, Double>>>> returnType =
        new ParameterizedTypeReference<>() {};
    var actual =
        getResponse(
            HttpMethod.GET,
            format(
                "%s%s%d%s%d",
                FX_RATES_URI,
                "/average/base-currency/",
                BASE_CURRENCY_ID,
                "/basis?accountId=",
                ACCOUNT_ID),
            returnType);
    assertEquals(AVG_RATE_MAP_BY_BASIS, actual);
  }

  @Test
  void should_start_recalculation_job() {
    var actual =
        getResponse(
            HttpMethod.POST,
            format(
                "%s%s%d%s%d%s%d",
                FX_RATES_URI,
                "/job/recalculate/account/",
                ACCOUNT_ID,
                "/start?securityIds=",
                SECURITY_ID_1,
                "&securityIds=",
                SECURITY_ID_2),
            String.class);
    assertNotNull(actual);
    verify(fxRateJobRunner, times(1))
        .runRecalculationFxRateJob(ACCOUNT_ID, Set.of(SECURITY_ID_1, SECURITY_ID_2));
  }

  private <T> T getResponse(
      final HttpMethod httpMethod, final String uri, ParameterizedTypeReference<T> returnType) {
    return Objects.requireNonNull(
        exchangeForEntity(httpMethod, uri)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(returnType)
            .getResponseBody()
            .blockFirst());
  }

  private <T> T getResponse(final HttpMethod httpMethod, final String uri, Class<T> returnType) {
    return Objects.requireNonNull(
        exchangeForEntity(httpMethod, uri)
            .expectStatus()
            .is2xxSuccessful()
            .returnResult(returnType)
            .getResponseBody()
            .blockFirst());
  }

  private WebTestClient.ResponseSpec exchangeForEntity(final HttpMethod method, final String uri) {
    return webClient.method(method).uri(uri).exchange();
  }
}
