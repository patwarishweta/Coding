package com.cwan.privatefund.canoeFundMapping;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingAccountResponse;
import com.cwan.privatefund.canoeFundMapping.model.CanoeFundMappingClientResponse;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CanoeFundMappingControllerTest {

  @Mock private CanoeFundMappingService canoeFundMappingService;
  @InjectMocks private CanoeFundMappingController canoeFundMappingController;

  @Test
  void testGetAllClientDetails() {
    Set<CanoeFundMappingClientResponse> expectedClientDetails =
        new HashSet<>(
            Arrays.asList(
                new CanoeFundMappingClientResponse(), new CanoeFundMappingClientResponse()));
    when(canoeFundMappingService.getClientDetails()).thenReturn(expectedClientDetails);
    Set<CanoeFundMappingClientResponse> actualClientDetails =
        canoeFundMappingController.getAllClientDetails();
    assertEquals(expectedClientDetails, actualClientDetails);
  }

  @Test
  void testGetAllById() {
    long clientId = 1L;
    List<CanoeFundMappingAccountResponse> expectedAccountDetails =
        Arrays.asList(new CanoeFundMappingAccountResponse(), new CanoeFundMappingAccountResponse());
    when(canoeFundMappingService.getAccountDetails(clientId)).thenReturn(expectedAccountDetails);
    List<CanoeFundMappingAccountResponse> actualAccountDetails =
        canoeFundMappingController.getAllById(clientId);
    assertEquals(expectedAccountDetails, actualAccountDetails);
  }
}
