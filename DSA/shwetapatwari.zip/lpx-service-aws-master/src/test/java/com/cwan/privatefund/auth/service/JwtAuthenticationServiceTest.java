package com.cwan.privatefund.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.ca.authtoken.core.AuthTokenCore;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public class JwtAuthenticationServiceTest {

  @Mock private AuthTokenCore authTokenCore;
  @Mock private AuthorityService authorityService;
  @Mock private ServerWebExchange swe;
  @Mock private ServerHttpRequest request;
  @Mock private HttpHeaders headers;

  private static final String TOKEN = "supercalafragalisticexpialadocious";
  private static final String BEARER_TOKEN = String.format("Bearer %s", TOKEN);
  private static final Map<String, Object> DECODED_TOKEN = Map.of("userId", "1337");

  private JwtAuthenticationService instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(swe.getRequest()).thenReturn(request);
    when(request.getHeaders()).thenReturn(headers);
    when(headers.getFirst(eq(HttpHeaders.AUTHORIZATION))).thenReturn(BEARER_TOKEN);
    when(authorityService.getAuthorities(any(ServerWebExchange.class)))
        .thenReturn(Collections.emptySet());

    instance = new JwtAuthenticationService(authTokenCore, authorityService);
  }

  @Test
  public void should_get_valid_authentication() {
    when(authTokenCore.isValidToken(eq(TOKEN))).thenReturn(true);
    when(authTokenCore.decodeToken(eq(TOKEN))).thenReturn(DECODED_TOKEN);
    var actual = instance.getAuthentication(swe).block();
    assertTrue(Objects.requireNonNull(actual).isAuthenticated());
  }

  @Test
  public void should_get_invalid_authentication() {
    when(authTokenCore.isValidToken(eq(TOKEN))).thenReturn(false);
    var actual = instance.getAuthentication(swe).block();
    assertFalse(Objects.requireNonNull(actual).isAuthenticated());
  }

  @Test
  public void should_return_empty_mono_if_null() {
    when(headers.getFirst(eq(HttpHeaders.AUTHORIZATION))).thenReturn(null);
    var actual = instance.getAuthentication(swe);
    assertEquals(Mono.empty(), actual);
  }
}
