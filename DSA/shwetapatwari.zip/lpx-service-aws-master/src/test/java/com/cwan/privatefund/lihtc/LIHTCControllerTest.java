package com.cwan.privatefund.lihtc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.pbor.clientspecific.LPxClientSpecificData;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.CacheLoadOnStartUp;
import com.cwan.privatefund.TestUtil;
import com.cwan.privatefund.lihtc.LIHTCController.ManualAmortSegmentRequest;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class LIHTCControllerTest extends AuthenticatedControllerTest {
  @MockBean LPxLIHTCService lpxLihtcService;
  @MockBean LPxClientSpecificData lpxClientSpecificData;
  @MockBean CacheLoadOnStartUp cacheLoadOnStartUp;

  @Autowired WebTestClient webClient;

  private static final LIHTCBenefitSchedule LIHTC_BENEFIT_SCHEDULE =
      TestUtil.getLihtcBenefitSchedule();

  private static final ManualAmortSegment MANUAL_AMORT_SEGMENT = TestUtil.getManualAmortSegment();
  private static final LIHTCTaxRate LIHTC_TAX_RATE = TestUtil.getLihtcTaxRate();

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TestUtil.TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_add_lihtc_benefit_schedules() {
    Set<LIHTCBenefitSchedule> benefitSchedules = Set.of(LIHTC_BENEFIT_SCHEDULE);
    when(lpxLihtcService.addBenefitSchedules(any())).thenReturn(Flux.just(LIHTC_BENEFIT_SCHEDULE));
    webClient
        .post()
        .uri(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(benefitSchedules)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCBenefitSchedule.class)
        .hasSize(1)
        .contains(LIHTC_BENEFIT_SCHEDULE)
        .returnResult();
  }

  @Test
  void fail_to_add_lihtc_benefit_schedules_bad_format() {
    // Entity is not in a collection as it should be
    webClient
        .post()
        .uri(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(LIHTC_BENEFIT_SCHEDULE)
        .exchange()
        .expectStatus()
        .is4xxClientError();
  }

  @Test
  void should_get_lihtc_benefit_schedules_account_security() {
    Map<LocalDate, Collection<LIHTCBenefitSchedule>> benefitSchedules =
        Map.of(LIHTC_BENEFIT_SCHEDULE.reportingDate(), Set.of(LIHTC_BENEFIT_SCHEDULE));
    when(lpxLihtcService.getBenefitSchedulesForAccountSecurityPair(any(), any()))
        .thenReturn(Mono.just(benefitSchedules));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                        .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                        .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<
                    Map<LocalDate, Collection<LIHTCBenefitSchedule>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate reportingDate = LIHTC_BENEFIT_SCHEDULE.reportingDate();
    assertEquals(1, actual.get(reportingDate).size());

    LIHTCBenefitSchedule expectedBenefitSchedule =
        benefitSchedules.get(reportingDate).iterator().next();
    LIHTCBenefitSchedule actualBenefitSchedule = actual.get(reportingDate).iterator().next();
    assertEquals(expectedBenefitSchedule, actualBenefitSchedule);
  }

  @Test
  void fail_to_get_lihtc_benefit_schedules_nonexistent_account_security() {
    when(lpxLihtcService.getBenefitSchedulesForAccountSecurityPair(any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                    .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                    .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCBenefitSchedule.class)
        .hasSize(0);
  }

  @Test
  void should_get_lihtc_benefit_schedules_account_security_reportingDate() {
    Map<LocalDate, Collection<LIHTCBenefitSchedule>> benefitSchedules =
        Map.of(LIHTC_BENEFIT_SCHEDULE.reportingDate(), Set.of(LIHTC_BENEFIT_SCHEDULE));
    when(lpxLihtcService.getBenefitSchedulesForAccountSecurityReportingDate(any(), any(), any()))
        .thenReturn(Mono.just(benefitSchedules));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                        .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                        .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                        .queryParam("reportDate", LIHTC_BENEFIT_SCHEDULE.reportingDate())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<
                    Map<LocalDate, Collection<LIHTCBenefitSchedule>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate reportingDate = LIHTC_BENEFIT_SCHEDULE.reportingDate();
    assertEquals(1, actual.get(reportingDate).size());

    LIHTCBenefitSchedule expectedBenefitSchedule =
        benefitSchedules.get(reportingDate).iterator().next();
    LIHTCBenefitSchedule actualBenefitSchedule = actual.get(reportingDate).iterator().next();
    assertEquals(expectedBenefitSchedule, actualBenefitSchedule);
  }

  @Test
  void fail_to_get_lihtc_benefit_schedules_nonexistent_account_security_reportingDate() {
    when(lpxLihtcService.getBenefitSchedulesForAccountSecurityReportingDate(any(), any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                    .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                    .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                    .queryParam("reportDate", LIHTC_BENEFIT_SCHEDULE.reportingDate())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCBenefitSchedule.class)
        .hasSize(0);
  }

  @Test
  void delete_lihtc_benefit_schedules_account_security_taxType() {
    Map<LocalDate, Collection<LIHTCBenefitSchedule>> benefitSchedules =
        Map.of(LIHTC_BENEFIT_SCHEDULE.reportingDate(), Set.of(LIHTC_BENEFIT_SCHEDULE));
    when(lpxLihtcService.deleteBenefitSchedulesForAccountSecurityTaxType(
            any(), any(), any(), any()))
        .thenReturn(Mono.just(benefitSchedules));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> actual =
        webClient
            .delete()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                        .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                        .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                        .queryParam("reportDate", LIHTC_BENEFIT_SCHEDULE.reportingDate())
                        .queryParam("taxType", LIHTC_BENEFIT_SCHEDULE.taxType())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<
                    Map<LocalDate, Collection<LIHTCBenefitSchedule>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate reportingDate = LIHTC_BENEFIT_SCHEDULE.reportingDate();
    assertEquals(1, actual.get(reportingDate).size());

    LIHTCBenefitSchedule expectedBenefitSchedule =
        benefitSchedules.get(reportingDate).iterator().next();
    LIHTCBenefitSchedule actualBenefitSchedule = actual.get(reportingDate).iterator().next();
    assertEquals(expectedBenefitSchedule, actualBenefitSchedule);
  }

  @Test
  void fail_to_delete_lihtc_benefit_schedules_nonexistent_account_security_taxType() {
    when(lpxLihtcService.deleteBenefitSchedulesForAccountSecurityTaxType(
            any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                    .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                    .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                    .queryParam("reportDate", LIHTC_BENEFIT_SCHEDULE.reportingDate())
                    .queryParam("taxType", LIHTC_BENEFIT_SCHEDULE.taxType())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCBenefitSchedule.class)
        .hasSize(0);
  }

  @Test
  void delete_lihtc_benefit_schedules_account_security_taxType_reportingDate() {
    Map<LocalDate, Collection<LIHTCBenefitSchedule>> benefitSchedules =
        Map.of(LIHTC_BENEFIT_SCHEDULE.reportingDate(), Set.of(LIHTC_BENEFIT_SCHEDULE));
    when(lpxLihtcService.deleteBenefitSchedulesForAccountSecurityTaxTypeReportingDateScheduleDate(
            any(), any(), any(), any(), any()))
        .thenReturn(Mono.just(benefitSchedules));

    Map<LocalDate, Collection<LIHTCBenefitSchedule>> actual =
        webClient
            .delete()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                        .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                        .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                        .queryParam("reportDate", LIHTC_BENEFIT_SCHEDULE.reportingDate())
                        .queryParam("taxType", LIHTC_BENEFIT_SCHEDULE.taxType())
                        .queryParam("scheduleDate", LIHTC_BENEFIT_SCHEDULE.scheduleDate())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<
                    Map<LocalDate, Collection<LIHTCBenefitSchedule>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate reportingDate = LIHTC_BENEFIT_SCHEDULE.reportingDate();
    assertEquals(1, actual.get(reportingDate).size());

    LIHTCBenefitSchedule expectedBenefitSchedule =
        benefitSchedules.get(reportingDate).iterator().next();
    LIHTCBenefitSchedule actualBenefitSchedule = actual.get(reportingDate).iterator().next();
    assertEquals(expectedBenefitSchedule, actualBenefitSchedule);
  }

  @Test
  void fail_to_delete_lihtc_benefit_schedules_nonexistent_account_security_taxType_reportingDate() {
    when(lpxLihtcService.deleteBenefitSchedulesForAccountSecurityTaxTypeReportingDateScheduleDate(
            any(), any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_BENEFIT_SCHEDULE_URI)
                    .queryParam("accountId", LIHTC_BENEFIT_SCHEDULE.account().getId())
                    .queryParam("securityId", LIHTC_BENEFIT_SCHEDULE.security().getSecurityId())
                    .queryParam("reportDate", LIHTC_BENEFIT_SCHEDULE.reportingDate())
                    .queryParam("taxType", LIHTC_BENEFIT_SCHEDULE.taxType())
                    .queryParam("scheduleDate", LIHTC_BENEFIT_SCHEDULE.scheduleDate())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCBenefitSchedule.class)
        .hasSize(0);
  }

  @Test
  void should_add_lihtc_tax_rates() {
    Set<LIHTCTaxRate> taxRates = Set.of(LIHTC_TAX_RATE);
    when(lpxLihtcService.addTaxRates(any())).thenReturn(Flux.just(LIHTC_TAX_RATE));
    webClient
        .post()
        .uri(TestUtil.LIHTC_TAX_RATE_URI)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(taxRates)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCTaxRate.class)
        .hasSize(1)
        .contains(LIHTC_TAX_RATE)
        .returnResult();
  }

  @Test
  void fail_to_add_tax_rate_bad_format() {
    // Entity is not in a collection as it should be
    when(lpxLihtcService.addTaxRates(any())).thenReturn(Flux.just(LIHTC_TAX_RATE));
    webClient
        .post()
        .uri(TestUtil.LIHTC_TAX_RATE_URI)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(LIHTC_TAX_RATE)
        .exchange()
        .expectStatus()
        .is4xxClientError();
  }

  @Test
  void should_get_lihtc_tax_rates_account_security() {
    Map<LocalDate, Collection<LIHTCTaxRate>> taxRates =
        Map.of(LIHTC_TAX_RATE.taxRateStartDate(), Set.of(LIHTC_TAX_RATE));
    when(lpxLihtcService.getTaxRatesForAccountSecurityPair(any(), any()))
        .thenReturn(Mono.just(taxRates));

    Map<LocalDate, Collection<LIHTCTaxRate>> actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_TAX_RATE_URI)
                        .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                        .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<Map<LocalDate, Collection<LIHTCTaxRate>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate taxRateStartDate = LIHTC_TAX_RATE.taxRateStartDate();
    assertEquals(1, actual.get(taxRateStartDate).size());

    LIHTCTaxRate expectedTaxRate = taxRates.get(taxRateStartDate).iterator().next();
    LIHTCTaxRate actualTaxRate = actual.get(taxRateStartDate).iterator().next();
    assertEquals(expectedTaxRate, actualTaxRate);
  }

  @Test
  void fail_to_get_lihtc_tax_rates_nonexistent_account_security() {
    when(lpxLihtcService.getTaxRatesForAccountSecurityPair(any(), any())).thenReturn(Mono.empty());

    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_TAX_RATE_URI)
                    .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                    .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCTaxRate.class)
        .hasSize(0);
  }

  @Test
  void should_get_lihtc_tax_rates_account_security_taxType() {
    Map<LocalDate, Collection<LIHTCTaxRate>> taxRates =
        Map.of(LIHTC_TAX_RATE.taxRateStartDate(), Set.of(LIHTC_TAX_RATE));
    when(lpxLihtcService.getTaxRatesForAccountSecurityForTaxType(any(), any(), any()))
        .thenReturn(Mono.just(taxRates));

    Map<LocalDate, Collection<LIHTCTaxRate>> actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_TAX_RATE_URI)
                        .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                        .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                        .queryParam("taxType", LIHTC_TAX_RATE.taxType())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<Map<LocalDate, Collection<LIHTCTaxRate>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate taxRateStartDate = LIHTC_TAX_RATE.taxRateStartDate();
    assertEquals(1, actual.get(taxRateStartDate).size());

    LIHTCTaxRate expectedTaxRate = taxRates.get(taxRateStartDate).iterator().next();
    LIHTCTaxRate actualTaxRate = actual.get(taxRateStartDate).iterator().next();
    assertEquals(expectedTaxRate, actualTaxRate);
  }

  @Test
  void fail_to_get_lihtc_tax_rates_nonexistent_account_security_taxType() {
    when(lpxLihtcService.getTaxRatesForAccountSecurityForTaxType(any(), any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_TAX_RATE_URI)
                    .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                    .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                    .queryParam("taxType", LIHTC_TAX_RATE.taxType())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCTaxRate.class)
        .hasSize(0);
  }

  @Test
  void delete_lihtc_tax_rates_account_security() {
    Map<LocalDate, Collection<LIHTCTaxRate>> taxRates =
        Map.of(LIHTC_TAX_RATE.taxRateStartDate(), Set.of(LIHTC_TAX_RATE));
    when(lpxLihtcService.deleteTaxRatesForAccountSecurity(any(), any()))
        .thenReturn(Mono.just(taxRates));

    Map<LocalDate, Collection<LIHTCTaxRate>> actual =
        webClient
            .delete()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_TAX_RATE_URI)
                        .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                        .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<Map<LocalDate, Collection<LIHTCTaxRate>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate taxRateStartDate = LIHTC_TAX_RATE.taxRateStartDate();
    assertEquals(1, actual.get(taxRateStartDate).size());

    LIHTCTaxRate expectedTaxRate = taxRates.get(taxRateStartDate).iterator().next();
    LIHTCTaxRate actualTaxRate = actual.get(taxRateStartDate).iterator().next();
    assertEquals(expectedTaxRate, actualTaxRate);
  }

  @Test
  void fail_to_delete_lihtc_tax_rates_nonexistent_account_security() {
    when(lpxLihtcService.deleteTaxRatesForAccountSecurity(any(), any())).thenReturn(Mono.empty());

    webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_TAX_RATE_URI)
                    .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                    .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCTaxRate.class)
        .hasSize(0);
  }

  @Test
  void delete_lihtc_tax_rates_account_security_taxType() {
    Map<LocalDate, Collection<LIHTCTaxRate>> taxRates =
        Map.of(LIHTC_TAX_RATE.taxRateStartDate(), Set.of(LIHTC_TAX_RATE));
    when(lpxLihtcService.deleteTaxRatesForAccountSecurityTaxType(any(), any(), any()))
        .thenReturn(Mono.just(taxRates));

    Map<LocalDate, Collection<LIHTCTaxRate>> actual =
        webClient
            .delete()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_TAX_RATE_URI)
                        .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                        .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                        .queryParam("taxType", LIHTC_TAX_RATE.taxType())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<Map<LocalDate, Collection<LIHTCTaxRate>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate taxRateStartDate = LIHTC_TAX_RATE.taxRateStartDate();
    assertEquals(1, actual.get(taxRateStartDate).size());

    LIHTCTaxRate expectedTaxRate = taxRates.get(taxRateStartDate).iterator().next();
    LIHTCTaxRate actualTaxRate = actual.get(taxRateStartDate).iterator().next();
    assertEquals(expectedTaxRate, actualTaxRate);
  }

  @Test
  void fail_to_delete_lihtc_tax_rates_nonexistent_account_security_taxType() {
    when(lpxLihtcService.deleteTaxRatesForAccountSecurityTaxType(any(), any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_TAX_RATE_URI)
                    .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                    .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                    .queryParam("taxType", LIHTC_TAX_RATE.taxType())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCTaxRate.class)
        .hasSize(0);
  }

  @Test
  void delete_lihtc_tax_rates_account_security_taxType_taxRateStartDate() {
    Map<LocalDate, Collection<LIHTCTaxRate>> taxRates =
        Map.of(LIHTC_TAX_RATE.taxRateStartDate(), Set.of(LIHTC_TAX_RATE));
    when(lpxLihtcService.deleteTaxRatesForAccountSecurityTaxTypeTaxRateStartDate(
            any(), any(), any(), any()))
        .thenReturn(Mono.just(taxRates));

    Map<LocalDate, Collection<LIHTCTaxRate>> actual =
        webClient
            .delete()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_TAX_RATE_URI)
                        .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                        .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                        .queryParam("taxType", LIHTC_TAX_RATE.taxType())
                        .queryParam("taxRateStartDate", LIHTC_TAX_RATE.taxRateStartDate())
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(
                new ParameterizedTypeReference<Map<LocalDate, Collection<LIHTCTaxRate>>>() {})
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);

    LocalDate taxRateStartDate = LIHTC_TAX_RATE.taxRateStartDate();
    assertEquals(1, actual.get(taxRateStartDate).size());

    LIHTCTaxRate expectedTaxRate = taxRates.get(taxRateStartDate).iterator().next();
    LIHTCTaxRate actualTaxRate = actual.get(taxRateStartDate).iterator().next();
    assertEquals(expectedTaxRate, actualTaxRate);
  }

  @Test
  void fail_to_delete_lihtc_tax_rates_nonexistent_account_security_taxType_taxRateStartDate() {
    when(lpxLihtcService.deleteTaxRatesForAccountSecurityTaxTypeTaxRateStartDate(
            any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    webClient
        .delete()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path(TestUtil.LIHTC_TAX_RATE_URI)
                    .queryParam("accountId", LIHTC_TAX_RATE.account().getId())
                    .queryParam("securityId", LIHTC_TAX_RATE.security().getSecurityId())
                    .queryParam("taxType", LIHTC_TAX_RATE.taxType())
                    .queryParam("taxRateStartDate", LIHTC_TAX_RATE.taxRateStartDate())
                    .build())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(LIHTCTaxRate.class)
        .hasSize(0);
  }

  @Test
  void get_amort_start_date_value_exists() {
    when(lpxClientSpecificData.getAmortizationStartDate(any(), any()))
        .thenReturn(LocalDate.of(2018, 1, 2));

    LocalDate actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_AMORT_START_DATE)
                        .queryParam("accountId", 1)
                        .queryParam("securityId", 2)
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(LocalDate.class)
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);
    LocalDate expected = LocalDate.of(2018, 1, 2);
    assertEquals(expected, actual);
  }

  @Test
  void get_manual_amort_segment_exists() {
    when(lpxLihtcService.getManualAmortSegments(anyLong(), anyLong(), anyInt()))
        .thenReturn(Set.of(MANUAL_AMORT_SEGMENT));

    List<ManualAmortSegment> actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.MANUAL_AMORT_SEGMENT)
                        .queryParam("accountId", 1)
                        .queryParam("securityId", 2)
                        .queryParam("basisId", 3)
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBodyList(ManualAmortSegment.class)
            .returnResult()
            .getResponseBody();

    assertNotNull(actual);
    assertEquals(List.of(MANUAL_AMORT_SEGMENT), actual);
  }

  @Test
  void post_manual_amort_segment() {
    when(lpxLihtcService.getManualAmortSegments(anyLong(), anyLong(), anyInt()))
        .thenReturn(Set.of(MANUAL_AMORT_SEGMENT));

    webClient
        .post()
        .uri(TestUtil.MANUAL_AMORT_SEGMENT)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(new ManualAmortSegmentRequest(Set.of(MANUAL_AMORT_SEGMENT), false))
        .exchange()
        .expectStatus()
        .isOk();

    verify(lpxLihtcService, Mockito.times(1)).updateManualAmortSegments(any(), anyBoolean());
  }

  @Test
  void post_manual_amort_segment_invalid_negative_basis() {
    when(lpxLihtcService.getManualAmortSegments(anyLong(), anyLong(), anyInt()))
        .thenReturn(Set.of(MANUAL_AMORT_SEGMENT));

    webClient
        .post()
        .uri(TestUtil.MANUAL_AMORT_SEGMENT)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(
            new ManualAmortSegmentRequest(
                Set.of(MANUAL_AMORT_SEGMENT.toBuilder().basisId(-1).build()), false))
        .exchange()
        .expectStatus()
        .is4xxClientError();

    verify(lpxLihtcService, Mockito.times(0)).updateManualAmortSegments(any(), anyBoolean());
  }

  @Test
  void post_manual_amort_segment_invalid_basis() {
    when(lpxLihtcService.getManualAmortSegments(anyLong(), anyLong(), anyInt()))
        .thenReturn(Set.of(MANUAL_AMORT_SEGMENT));

    webClient
        .post()
        .uri(TestUtil.MANUAL_AMORT_SEGMENT)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(
            new ManualAmortSegmentRequest(
                Set.of(MANUAL_AMORT_SEGMENT.toBuilder().basisId(4).build()), false))
        .exchange()
        .expectStatus()
        .is4xxClientError();

    verify(lpxLihtcService, Mockito.times(0)).updateManualAmortSegments(any(), anyBoolean());
  }

  @Test
  void get_amort_start_date_value_missing() {
    when(lpxClientSpecificData.getAmortizationStartDate(any(), any())).thenReturn(null);

    LocalDate actual =
        webClient
            .get()
            .uri(
                uriBuilder ->
                    uriBuilder
                        .path(TestUtil.LIHTC_AMORT_START_DATE)
                        .queryParam("accountId", 1)
                        .queryParam("securityId", 2)
                        .build())
            .exchange()
            .expectStatus()
            .isOk()
            .expectHeader()
            .contentType(MediaType.APPLICATION_JSON)
            .expectBody(LocalDate.class)
            .returnResult()
            .getResponseBody();

    assertNull(actual);
  }
}
