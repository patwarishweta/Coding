package com.cwan.privatefund.cpd.ws.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.config.properties.CpdConfigProperties;
import com.cwan.privatefund.cpd.ws.model.CpdField;
import com.cwan.privatefund.cpd.ws.model.CpdFieldAndData;
import com.cwan.privatefund.cpd.ws.model.TagEntry;
import com.google.common.cache.Cache;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class CpdWSCacheTest {

  private CpdWSCache cpdWSCache;
  @Mock private CpdWSClient cpdWSClient;

  @Mock
  private Cache<Long, ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>>
      tagEntriesCache;

  @Mock private CpdConfigProperties cpdConfigProperties;
  @Mock private CpdConfigProperties.FieldIds fieldIdProperties;
  private static final Long CLIENT_ID = 123L;
  private static final Long ACCOUNT_ID = 456L;
  private static final Integer TAG_ID = 789;
  private static final Set<Integer> FIELD_IDS = Set.of(1, 2, 3);
  private static final Set<String> PROPERTIES = Set.of("prop1", "ENABLED_IN_LMC");
  private static final CpdField CPD_FIELD =
      CpdField.builder().id(101).clientId(CLIENT_ID).properties(PROPERTIES).build();
  private static final Flux<CpdField> CPD_FIELD_FLUX = Flux.just(CPD_FIELD);
  private static final TagEntry TAG_ENTRY =
      TagEntry.builder()
          .fieldId(101)
          .clientId(CLIENT_ID)
          .accountId(ACCOUNT_ID)
          .reportDate(123)
          .tagId(TAG_ID)
          .endDate(456)
          .cpdValue("Data 1")
          .build();

  private static final TagEntry TAG_ENTRY2 =
      TagEntry.builder()
          .fieldId(101)
          .clientId(CLIENT_ID)
          .accountId(ACCOUNT_ID)
          .reportDate(null)
          .tagId(TAG_ID)
          .endDate(456)
          .cpdValue("Data 2")
          .build();

  private static final TagEntry TAG_ENTRY3 =
      TagEntry.builder()
          .fieldId(101)
          .clientId(CLIENT_ID)
          .accountId(ACCOUNT_ID)
          .reportDate(123)
          .tagId(TAG_ID)
          .endDate(null)
          .cpdValue("Data 3")
          .build();
  private static final CpdFieldAndData CPD_FIELD_AND_DATA =
      CpdFieldAndData.builder()
          .id(101)
          .clientId(CLIENT_ID)
          .properties(PROPERTIES)
          .data(Map.of(TAG_ID, "Data 3"))
          .build();

  private static final CpdFieldAndData CPD_FIELD_AND_NO_DATA =
      CpdFieldAndData.builder()
          .id(101)
          .clientId(CLIENT_ID)
          .properties(PROPERTIES)
          .data(Map.of())
          .build();

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    when(cpdConfigProperties.getFieldIds()).thenReturn(fieldIdProperties);
    when(fieldIdProperties.getReviewers()).thenReturn(Map.of("reviewer1", 101, "reviewer2", 102));
    cpdWSCache = new CpdWSCache(cpdWSClient, tagEntriesCache, cpdConfigProperties);
  }

  @Test
  void testGetTagEntriesForClientFromCache() {
    var mockedCacheMap = new ConcurrentHashMap<String, TagEntry>();
    mockedCacheMap.put("test", TagEntry.builder().build());
    var mockedClientCacheMap =
        new ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>();
    mockedClientCacheMap.put(CLIENT_ID, Mono.just(mockedCacheMap));
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(mockedClientCacheMap);
    when(tagEntriesCache.asMap()).thenReturn(new ConcurrentHashMap<>());
    when(cpdWSClient.getTagEntries(any(), any(), any())).thenReturn(Flux.empty());
    StepVerifier.create(cpdWSCache.getTagEntriesForClient(CLIENT_ID, ACCOUNT_ID, FIELD_IDS))
        .expectSubscription()
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void testGetTagEntriesForClientNotFromCache() {
    var tagEntry =
        TagEntry.builder().fieldId(101).clientId(CLIENT_ID).accountId(ACCOUNT_ID).build();
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(null);
    when(cpdWSClient.getTagEntries(any(), any(), any())).thenReturn(Flux.just(tagEntry));
    StepVerifier.create(cpdWSCache.getTagEntriesForClient(CLIENT_ID, ACCOUNT_ID, FIELD_IDS))
        .expectSubscription()
        .expectNextMatches(map -> map.containsKey("reviewer1"))
        .verifyComplete();
  }

  @Test
  void testGetTagEntriesForClientWithError() {
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(null);
    when(cpdWSClient.getTagEntries(any(), any(), any()))
        .thenReturn(Flux.error(new RuntimeException("Error")));
    StepVerifier.create(cpdWSCache.getTagEntriesForClient(CLIENT_ID, ACCOUNT_ID, FIELD_IDS))
        .expectSubscription()
        .expectErrorMessage("Error")
        .verify();
  }

  @Test
  void testClearCacheForClient() {
    StepVerifier.create(cpdWSCache.clearCacheForClient(CLIENT_ID))
        .expectSubscription()
        .verifyComplete();
    verify(tagEntriesCache).invalidate(CLIENT_ID);
  }

  @Test
  void testClearCache() {
    StepVerifier.create(cpdWSCache.clearCache()).expectSubscription().verifyComplete();
    verify(tagEntriesCache).invalidateAll();
  }

  @Test
  void testGetReviewers() {
    var tagEntry =
        TagEntry.builder().fieldId(101).clientId(CLIENT_ID).accountId(ACCOUNT_ID).build();
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(null);
    when(cpdWSClient.getTagEntries(any(), any(), any())).thenReturn(Flux.just(tagEntry));
    StepVerifier.create(cpdWSCache.getReviewers(CLIENT_ID, ACCOUNT_ID))
        .expectSubscription()
        .expectNextMatches(map -> map.containsKey("reviewer1"))
        .verifyComplete();
  }

  @Test
  void testInvalidClientId() {
    StepVerifier.create(cpdWSCache.getTagEntriesForClient(-1L, ACCOUNT_ID, FIELD_IDS))
        .expectSubscription()
        .expectErrorMessage("Invalid client ID provided")
        .verify();
  }

  @Test
  void testGetTagEntriesForClientInvalidFieldId() {
    var tagEntry =
        TagEntry.builder().fieldId(999).clientId(CLIENT_ID).accountId(ACCOUNT_ID).build();
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(null);
    when(cpdWSClient.getTagEntries(any(), any(), any())).thenReturn(Flux.just(tagEntry));
    StepVerifier.create(cpdWSCache.getTagEntriesForClient(CLIENT_ID, ACCOUNT_ID, FIELD_IDS))
        .expectSubscription()
        .expectNextMatches(ConcurrentHashMap::isEmpty)
        .verifyComplete();
  }

  @Test
  void testGetFieldEntriesForClient() {
    var mockedCacheMap = new ConcurrentHashMap<String, TagEntry>();
    mockedCacheMap.put("test", TagEntry.builder().build());
    var mockedClientCacheMap =
        new ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>();
    mockedClientCacheMap.put(CLIENT_ID, Mono.just(mockedCacheMap));
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(mockedClientCacheMap);
    when(tagEntriesCache.asMap()).thenReturn(new ConcurrentHashMap<>());
    when(cpdWSClient.getCpdFields(any())).thenReturn(CPD_FIELD_FLUX);
    when(cpdWSClient.getTagEntries(any(), any(), any()))
        .thenReturn(Flux.just(TAG_ENTRY, TAG_ENTRY2, TAG_ENTRY3));
    List<CpdFieldAndData> actual = cpdWSCache.getCpdFieldAndDataForClient(CLIENT_ID).block();
    assertEquals(List.of(CPD_FIELD_AND_DATA), actual);
  }

  @Test
  void testGetFieldEntriesForClient_noData() {
    var mockedCacheMap = new ConcurrentHashMap<String, TagEntry>();
    mockedCacheMap.put("test", TagEntry.builder().build());
    var mockedClientCacheMap =
        new ConcurrentHashMap<Long, Mono<ConcurrentHashMap<String, TagEntry>>>();
    mockedClientCacheMap.put(CLIENT_ID, Mono.just(mockedCacheMap));
    when(tagEntriesCache.getIfPresent(CLIENT_ID)).thenReturn(mockedClientCacheMap);
    when(tagEntriesCache.asMap()).thenReturn(new ConcurrentHashMap<>());
    when(cpdWSClient.getCpdFields(any())).thenReturn(CPD_FIELD_FLUX);
    when(cpdWSClient.getTagEntries(any(), any(), any())).thenReturn(Flux.just());
    List<CpdFieldAndData> actual = cpdWSCache.getCpdFieldAndDataForClient(CLIENT_ID).block();
    assertEquals(List.of(CPD_FIELD_AND_NO_DATA), actual);
  }

  @Test
  void testGetFieldAndDataEntriesForClientWithError() {
    when(cpdWSClient.getCpdFields(any())).thenReturn(Flux.error(new RuntimeException("Error")));
    StepVerifier.create(cpdWSCache.getCpdFieldAndDataForClient(CLIENT_ID))
        .expectSubscription()
        .expectErrorMessage("Error")
        .verify();
  }
}
