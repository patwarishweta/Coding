package com.cwan.privatefund.capital.call.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.pbor.document.capital.call.management.api.CapitalCallManagement;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallBankAccountVerifierServiceTest {

  @Mock private CapitalCallManagement capitalCallManagement;
  @InjectMocks private CapitalCallBankAccountVerifierService service;
  private static final Long DOCUMENT_ID = 1L;
  private static final Long ACCOUNT_ID = 2L;

  @Test
  void isNewBankAccount_BankDetailIsNull_ReturnTrue() {
    var document = CapitalCallDocument.builder().documentId(DOCUMENT_ID).build();
    var result = service.isNewBankAccount(document);
    StepVerifier.create(result).expectNext(true).verifyComplete();
  }

  @Test
  void isNewBankAccount_AccountIsNull_ReturnTrue() {
    var document =
        CapitalCallDocument.builder()
            .documentId(DOCUMENT_ID)
            .bankDetail(CapitalCallBankDetail.builder().build())
            .build();
    var result = service.isNewBankAccount(document);
    StepVerifier.create(result).expectNext(true).verifyComplete();
  }

  @Test
  void isNewBankAccount_AbaRoutingNumberAndSwiftChipsCodeAreNull_ReturnTrue() {
    var document = createDocumentWithBankDetail(null, null, "123", "IBAN123");
    var result = service.isNewBankAccount(document);
    StepVerifier.create(result).expectNext(true).verifyComplete();
  }

  @Test
  void isNewBankAccount_AccountNumberAndIbanAreNull_ReturnTrue() {
    var document = createDocumentWithBankDetail("ABA123", "SWIFT123", null, null);
    var result = service.isNewBankAccount(document);
    StepVerifier.create(result).expectNext(true).verifyComplete();
  }

  @Test
  void isNewBankAccount_AllDetailsPresentAndBankAccountIsNew_ShouldReturnTrue() {
    var document = createDocumentWithBankDetail("ABA123", "SWIFT123", "123", "IBAN123");
    var mockBankAccount = createMockBankAccount("ABA124", "SWIFT124", "124", "IBAN124");
    when(capitalCallManagement.findAllBankAccounts()).thenReturn(List.of(mockBankAccount));
    var result = service.isNewBankAccount(document);
    StepVerifier.create(result).expectNext(true).verifyComplete();
  }

  @Test
  void isNewBankAccount_AllDetailsPresentAndBankAccountIsNotNew_ShouldReturnFalse() {
    var document = createDocumentWithBankDetail("ABA123", "SWIFT123", "123", "IBAN123");
    var mockBankAccount = createMockBankAccount("ABA123", "SWIFT123", "123", "IBAN123");
    when(capitalCallManagement.findAllBankAccounts()).thenReturn(List.of(mockBankAccount));
    var result = service.isNewBankAccount(document);
    StepVerifier.create(result).expectNext(false).verifyComplete();
  }

  @Test
  void verifyAndSetNewBankAccountFlag_BankAccountIsNew_ShouldUpdateFlag() {
    var document = createDocumentWithBankDetail("ABA123", "SWIFT123", "123", "IBAN123");
    var mockBankAccount = createMockBankAccount("ABA124", "SWIFT124", "124", "IBAN124");
    when(capitalCallManagement.findAllBankAccounts()).thenReturn(List.of(mockBankAccount));
    var result = service.verifyAndSetBufferedNewBankAccountFlag(List.of(document));
    StepVerifier.create(result)
        .assertNext(updatedDocument -> assertTrue(updatedDocument.bankDetail().newAccount()))
        .verifyComplete();
  }

  @Test
  void verifyAndSetNewBankAccountFlag_BankAccountIsNotNew_ShouldUpdateFlag() {
    var document = createDocumentWithBankDetail("ABA123", "SWIFT123", "123", "IBAN123");
    var mockBankAccount = createMockBankAccount("ABA123", "SWIFT123", "123", "IBAN123");
    when(capitalCallManagement.findAllBankAccounts()).thenReturn(List.of(mockBankAccount));
    var result = service.verifyAndSetBufferedNewBankAccountFlag(List.of(document));
    StepVerifier.create(result)
        .assertNext(updatedDocument -> assertFalse(updatedDocument.bankDetail().newAccount()))
        .verifyComplete();
  }

  private CapitalCallDocument createDocumentWithBankDetail(
      String abaRoutingNumber, String swiftChipsCode, String accountNumber, String iban) {
    var bankDetail =
        CapitalCallBankDetail.builder()
            .abaRoutingNumber(abaRoutingNumber)
            .swiftOrChips(swiftChipsCode)
            .accountNumber(accountNumber)
            .accountIban(iban)
            .newAccount(true)
            .build();
    return CapitalCallDocument.builder()
        .documentId(DOCUMENT_ID)
        .account(Account.builder().id(ACCOUNT_ID).build())
        .bankDetail(bankDetail)
        .build();
  }

  private BankAccount createMockBankAccount(
      String abaRoutingNumber, String swiftChipsCode, String accountNumber, String iban) {
    var bank =
        Bank.builder().abaRoutingNumber(abaRoutingNumber).swiftChipsCode(swiftChipsCode).build();
    return BankAccount.builder()
        .bank(bank)
        .accountNumber(accountNumber)
        .iban(iban)
        .accountId(ACCOUNT_ID)
        .build();
  }
}
