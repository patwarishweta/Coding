package com.cwan.privatefund.fxrate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.fxrate.api.FXRates;
import com.cwan.pbor.trans.api.Transactions;
import com.cwan.privatefund.business.ws.BusinessWSCache;
import com.cwan.privatefund.business.ws.model.BusinessAccount;
import com.cwan.privatefund.fundmaster.LpxFundMasterService;
import com.cwan.privatefund.fxrate.source.AccountFxSource;
import com.cwan.privatefund.fxrate.source.AccountFxSourceService;
import com.cwan.privatefund.fxrate.source.FxSourceSchedule;
import com.cwan.privatefund.security.currency.SecurityCurrencyService;
import com.cwan.privatefund.security.model.SecurityCurrency;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

class LpxFxRateServiceTest {

  @Mock private FXRates fxRates;
  @Mock private LpxFundMasterService lpxFundMasterService;
  @Mock private SecurityCurrencyService securityCurrencyService;
  @Mock private Transactions transactions;
  @Mock private BusinessWSCache businessWSCache;
  @Mock private AverageFxRateCalculator averageFxRateCalculator;
  @Mock private FxServiceApacheClient fxServiceApacheClient;
  @Mock private AccountFxSourceService accountFxSourceService;
  private static final Long BASE_CURRENCY_ID = 1L;
  private static final Long LOCAL_CURRENCY_ID_1 = 11L;
  private static final Long LOCAL_CURRENCY_ID_2 = 12L;
  private static final Long SECURITY_ID_1 = 100L;
  private static final Long SECURITY_ID_2 = 101L;
  private static final Long SECURITY_ID_3 = 102L;
  private static final Long ACCOUNT_ID = 200L;
  private static final Long SOURCE_ID = 300L;
  private static final Integer BASIS_ID = 2;
  private static final BusinessAccount ACCOUNT =
      BusinessAccount.builder()
          .functionalCurrencyId(BASE_CURRENCY_ID)
          .currencyFxRateSourceId(SOURCE_ID)
          .build();
  private static final ReportingFrequency REPORTING_FREQUENCY = ReportingFrequency.QUARTERLY;
  private static final LocalDate DATE_1 = LocalDate.of(2024, 1, 1);
  private static final LocalDate DATE_2 = LocalDate.of(2024, 1, 2);
  private static final double AVG_RATE_1 = 0.1;
  private static final double AVG_RATE_2 = 0.2;
  private static final double AVG_RATE_3 = 0.3;

  private LpxFxRateService lpxFxRateService;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    this.lpxFxRateService =
        new LpxFxRateService(
            fxRates,
            lpxFundMasterService,
            securityCurrencyService,
            transactions,
            businessWSCache,
            averageFxRateCalculator,
            fxServiceApacheClient,
            accountFxSourceService);
  }

  @Test
  void should_return_avg_fx_rate_map() {
    mockFxRates();
    mockAccountFxSource(BASIS_ID);
    AverageFxRateMap actual = lpxFxRateService.getAverageFxRates(BASE_CURRENCY_ID, SOURCE_ID);
    AverageFxRateMap expected =
        new AverageFxRateMap(
            Map.of(
                LOCAL_CURRENCY_ID_1,
                Map.of(REPORTING_FREQUENCY, Map.of(DATE_1, AVG_RATE_1)),
                LOCAL_CURRENCY_ID_2,
                Map.of(REPORTING_FREQUENCY, Map.of(DATE_1, AVG_RATE_2, DATE_2, AVG_RATE_3))));
    assertEquals(expected, actual);
  }

  @Test
  void should_return_security_avg_fx_rates() {
    mockFxRates();
    mockAccountFxSource(BASIS_ID);
    mockSecurityCurrencies();
    Transaction transaction1 =
        Transaction.builder()
            .security(Security.builder().securityId(SECURITY_ID_1).build())
            .build();
    Transaction transaction2 =
        Transaction.builder()
            .security(Security.builder().securityId(SECURITY_ID_2).build())
            .build();
    when(transactions.getTransactionsByAccountIdsNonReactive(Set.of(ACCOUNT_ID)))
        .thenReturn(Set.of(transaction1, transaction2));
    when(lpxFundMasterService.getReportingFrequencies(Set.of(SECURITY_ID_1, SECURITY_ID_2)))
        .thenReturn(
            Map.of(SECURITY_ID_1, REPORTING_FREQUENCY, SECURITY_ID_2, ReportingFrequency.YEARLY));
    Map<Integer, Map<Long, Map<LocalDate, Double>>> actual =
        lpxFxRateService.getSecurityAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID);
    Map<Integer, Map<Long, Map<LocalDate, Double>>> expected =
        Map.of(BASIS_ID, Map.of(SECURITY_ID_1, Map.of(DATE_1, 1 / AVG_RATE_1)));
    assertEquals(expected, actual);
  }

  @Test
  void should_return_zero_avg_fx_rates() {
    mockAccountFxSource(BASIS_ID);
    FXRate fxRate1 =
        FXRate.builder()
            .localCurrencyId(LOCAL_CURRENCY_ID_1)
            .reportingFrequency(REPORTING_FREQUENCY)
            .date(DATE_1)
            .averageFxRate(0.0)
            .fxRateSourceId(SOURCE_ID)
            .build();
    when(fxRates.getFxRatesForBaseCurrencyAndSourceId(BASE_CURRENCY_ID, Set.of(SOURCE_ID)))
        .thenReturn(Set.of(fxRate1));
    SecurityCurrency securityCurrency1 =
        SecurityCurrency.builder()
            .securityId(SECURITY_ID_1)
            .currencyId(LOCAL_CURRENCY_ID_1)
            .build();
    when(securityCurrencyService.findAllByCurrencyIdIn(Set.of(LOCAL_CURRENCY_ID_1)))
        .thenReturn(Set.of(securityCurrency1));
    Transaction transaction1 =
        Transaction.builder()
            .security(Security.builder().securityId(SECURITY_ID_1).build())
            .build();
    when(transactions.getTransactionsByAccountIdsNonReactive(Set.of(ACCOUNT_ID)))
        .thenReturn(Set.of(transaction1));
    when(lpxFundMasterService.getReportingFrequencies(Set.of(SECURITY_ID_1)))
        .thenReturn(Map.of(SECURITY_ID_1, REPORTING_FREQUENCY));

    Map<Integer, Map<Long, Map<LocalDate, Double>>> actual =
        lpxFxRateService.getSecurityAverageFxRatesByBasis(BASE_CURRENCY_ID, ACCOUNT_ID);
    Map<Integer, Map<Long, Map<LocalDate, Double>>> expected =
        Map.of(BASIS_ID, Map.of(SECURITY_ID_1, Map.of(DATE_1, 0.0)));
    assertEquals(expected, actual);
  }

  @Test
  void should_return_already_stored_avg_fx_rate() {
    mockAccountFxSource(AccountFxSource.NOT_BASIS_SPECIFIC_ID);
    when(businessWSCache.getAccountData(ACCOUNT_ID)).thenReturn(Mono.just(ACCOUNT));
    when(lpxFundMasterService.getReportingFrequency(SECURITY_ID_1)).thenReturn(REPORTING_FREQUENCY);
    mockFxRates();
    Mono<Double> actual =
        lpxFxRateService.getAverageFxRate(ACCOUNT_ID, SECURITY_ID_1, LOCAL_CURRENCY_ID_1, DATE_1);
    assertEquals(AVG_RATE_1, actual.block());
  }

  @Test
  void should_return_calculated_avg_fx_rate() {
    mockAccountFxSource(AccountFxSource.NOT_BASIS_SPECIFIC_ID);
    when(businessWSCache.getAccountData(ACCOUNT_ID)).thenReturn(Mono.just(ACCOUNT));
    when(lpxFundMasterService.getReportingFrequency(SECURITY_ID_1)).thenReturn(REPORTING_FREQUENCY);
    when(fxRates.getFxRatesForBaseCurrencyAndSourceId(BASE_CURRENCY_ID, Set.of(SOURCE_ID)))
        .thenReturn(Set.of());
    FXRate calculatedFxRate = FXRate.builder().averageFxRate(0.01).build();
    when(averageFxRateCalculator.calculateAverageFxRate(
            SOURCE_ID, BASE_CURRENCY_ID, LOCAL_CURRENCY_ID_1, REPORTING_FREQUENCY, DATE_1))
        .thenReturn(calculatedFxRate);
    Mono<Double> actual =
        lpxFxRateService.getAverageFxRate(ACCOUNT_ID, SECURITY_ID_1, LOCAL_CURRENCY_ID_1, DATE_1);
    assertEquals(calculatedFxRate.getAverageFxRate(), actual.block());
    verify(fxRates, times(1)).addFXRates(Set.of(calculatedFxRate));
  }

  @Test
  void should_return_null_if_no_source_id() {
    when(businessWSCache.getAccountData(ACCOUNT_ID)).thenReturn(Mono.just(ACCOUNT));
    when(accountFxSourceService.getFxSourceSchedule(ACCOUNT_ID))
        .thenReturn(new FxSourceSchedule(new HashMap<>()));
    when(fxServiceApacheClient.getAccountFxSources(ACCOUNT_ID)).thenReturn(Set.of());
    Mono<Double> actual =
        lpxFxRateService.getAverageFxRate(ACCOUNT_ID, SECURITY_ID_1, LOCAL_CURRENCY_ID_1, DATE_1);
    assertNull(actual.block());
  }

  private void mockFxRates() {
    FXRate fxRate1 =
        FXRate.builder()
            .localCurrencyId(LOCAL_CURRENCY_ID_1)
            .reportingFrequency(REPORTING_FREQUENCY)
            .date(DATE_1)
            .averageFxRate(AVG_RATE_1)
            .fxRateSourceId(SOURCE_ID)
            .build();
    FXRate fxRate2 =
        FXRate.builder()
            .localCurrencyId(LOCAL_CURRENCY_ID_2)
            .reportingFrequency(REPORTING_FREQUENCY)
            .date(DATE_1)
            .averageFxRate(AVG_RATE_2)
            .fxRateSourceId(SOURCE_ID)
            .build();
    FXRate fxRate3 =
        FXRate.builder()
            .localCurrencyId(LOCAL_CURRENCY_ID_2)
            .reportingFrequency(REPORTING_FREQUENCY)
            .date(DATE_2)
            .averageFxRate(AVG_RATE_3)
            .fxRateSourceId(SOURCE_ID)
            .build();
    when(fxRates.getFxRatesForBaseCurrencyAndSourceId(BASE_CURRENCY_ID, Set.of(SOURCE_ID)))
        .thenReturn(Set.of(fxRate1, fxRate2, fxRate3));
  }

  private void mockSecurityCurrencies() {
    SecurityCurrency securityCurrency1 =
        SecurityCurrency.builder()
            .securityId(SECURITY_ID_1)
            .currencyId(LOCAL_CURRENCY_ID_1)
            .build();
    SecurityCurrency securityCurrency2 =
        SecurityCurrency.builder()
            .securityId(SECURITY_ID_2)
            .currencyId(LOCAL_CURRENCY_ID_1)
            .build();
    SecurityCurrency securityCurrency3 =
        SecurityCurrency.builder()
            .securityId(SECURITY_ID_3)
            .currencyId(LOCAL_CURRENCY_ID_2)
            .build();
    when(securityCurrencyService.findAllByCurrencyIdIn(
            Set.of(LOCAL_CURRENCY_ID_1, LOCAL_CURRENCY_ID_2)))
        .thenReturn(Set.of(securityCurrency1, securityCurrency2, securityCurrency3));
  }

  private void mockAccountFxSource(int basisId) {
    NavigableMap<LocalDate, List<Long>> scheduleForBasis = new TreeMap<>();
    scheduleForBasis.put(LocalDate.MIN, List.of(SOURCE_ID));
    FxSourceSchedule sourceSchedule = new FxSourceSchedule(Map.of(basisId, scheduleForBasis));
    when(accountFxSourceService.getFxSourceSchedule(ACCOUNT_ID)).thenReturn(sourceSchedule);
  }
}
