package com.cwan.privatefund;

import static com.cwan.privatefund.util.DateUtils.atEndOfDay;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.BankDetail;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.lpx.domain.FinancialStatement;
import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.LoadTransactionDetail;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.Performance;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Service;
import com.cwan.lpx.domain.Tag;
import com.cwan.lpx.domain.TaxType;
import com.cwan.lpx.domain.Transaction;
import com.cwan.lpx.domain.TransactionIdentifier;
import com.cwan.lpx.domain.TransactionSubType;
import com.cwan.lpx.domain.TransactionType;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.k1.K1Entity;
import com.cwan.pbor.tag.TagEntity;
import com.cwan.privatefund.accountconfig.AccountSubscriptionRules;
import com.cwan.privatefund.aum.model.AumRequest;
import com.cwan.privatefund.auth.LPxAMPTPermissions;
import com.cwan.privatefund.balance.model.BalanceRequest;
import com.cwan.privatefund.basis.ws.model.Basis;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.calculated.model.AccountingCalculatedBalance;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import com.cwan.privatefund.comment.model.Comment;
import com.cwan.privatefund.comment.model.CommentEntity;
import com.cwan.privatefund.comment.model.CommentRequest;
import com.cwan.privatefund.directory.model.Directory;
import com.cwan.privatefund.directory.model.DirectoryEntity;
import com.cwan.privatefund.directory.model.DirectoryRequest;
import com.cwan.privatefund.document.CwanGptDocument;
import com.cwan.privatefund.document.CwanGptDocumentRequest;
import com.cwan.privatefund.document.DocumentRequest;
import com.cwan.privatefund.document.UserDetails;
import com.cwan.privatefund.documentcashflow.DocumentCashflowRequest;
import com.cwan.privatefund.documentmanager.DocumentManagerData;
import com.cwan.privatefund.issuestore.model.Issue;
import com.cwan.privatefund.issuestore.model.IssueExpiration;
import com.cwan.privatefund.issuestore.model.IssueStatus;
import com.cwan.privatefund.issuestore.model.IssueStatusName;
import com.cwan.privatefund.portfolio.PortfolioBalance;
import com.cwan.privatefund.portfolio.model.AggregatePortfolioData;
import com.cwan.privatefund.portfolio.model.PortfolioSummaryResponse;
import com.cwan.privatefund.security.model.SecurityMasterData;
import com.cwan.privatefund.security.model.SecurityResponse;
import com.cwan.privatefund.transaction.model.AwsTransaction;
import com.cwan.privatefund.transaction.model.TransactionRequest;
import com.cwan.privatefund.watchlist.model.Watchlist;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import com.cwan.privatefund.watchlist.model.WatchlistRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import lombok.SneakyThrows;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class TestUtil {

  public static final String BALANCE_URI = "/v1/balances";
  public static final String K1_URI = "/v1/k1s";
  public static final String TRANSACTION_URI = "/v1/transactions";
  public static final String FINANCIAL_STATEMENT_URI = "/v1/financialstatements";
  public static final String DOCUMENT_URI = "/v1/documents";
  public static final String FILE_UPLOAD_URI = "/v1/documents/files";
  public static final String GET_DOCUMENT_SIGNED_URL_URI = "/v1/documents/signedUrl/";
  public static final String CASHFLOW_URI = "/v1/cash-flows";
  public static final String ACCOUNT_URI = "/v1/accounts";
  public static final String COMMENT_URI = "/v1/comments";
  public static final String WATCHLIST_URI = "/v1/watchlist";
  public static final String ISSUE_URI = "/v1/issues";
  public static final String CALCULATED_URI = "/v1/calculated/balance";
  public static final String BACKEND_CALCULATED_URI = "/v2/backend/calculated/balance";
  public static final String DIRECTORY_URI = "/v1/directory";
  public static final String DOCUMENT_MANAGER_URI = "/v1/document-manager";
  public static final String TAGS_FOR_DOCUMENT_URI = "/v1/tags/document";
  public static final String PORTFOLIO_URI = "/v1/portfolio";
  public static final String RESET_CONFIG_CACHE_URI = "/v1/account-config";
  public static final String CWAN_GPT_DOCUMENT_URI = "/v1/documents/cwan-gpt/upload";
  public static final String LIHTC_BENEFIT_SCHEDULE_URI = "/v1/lihtc/benefit-schedules";
  public static final String LIHTC_TAX_RATE_URI = "/v1/lihtc/tax-rates";
  public static final String LIHTC_AMORT_START_DATE = "/v1/lihtc/amortization-start-date";
  public static final String MANUAL_AMORT_SEGMENT = "/v1/lihtc/manual-amort-segments";
  public static final String FX_RATES_URI = "/v1/fx-rates";
  public static final String AUM_URI = "/v1/aum";
  public static final int TIME_OUT = 30;

  @SneakyThrows
  public static BalanceRequest getBalanceRequest() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/balance_1.json")), BalanceRequest.class);
  }

  @SneakyThrows
  public static List<Map<String, Object>> getCanoeData() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/canoe_data.json")),
            new TypeReference<>() {});
  }

  @SneakyThrows
  public static List<UserDetails> getAssigneeData() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/user_detail.json")),
            new TypeReference<>() {});
  }

  @SneakyThrows
  public static List<LoadTransactionDetail> getInitialLoadTransactionDetails() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/load_transaction_details.json")),
            new TypeReference<>() {});
  }

  @SneakyThrows
  public static List<AwsTransaction> getAwsTransactions() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/aws_transaction.json")),
            new TypeReference<>() {});
  }

  @SneakyThrows
  public static K1Entity getK1(Long id) {
    var k1 =
        getObjectMapper()
            .readValue(Files.readString(Path.of("src/test/resources/k1.json")), K1Entity.class);
    k1.setId(id);
    return k1;
  }

  @SneakyThrows
  public static List<Transaction> getTransactions() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/transactionlist.json")),
            new TypeReference<>() {});
  }

  @SneakyThrows
  public static DocumentCashflowRequest getDocumentCashflowRequest() {
    Set<DocumentCashFlow> documentCashFlows =
        Set.of(
            DocumentCashFlow.builder()
                .id(1L)
                .document(
                    Document.builder()
                        .id(15203L)
                        .fileName("Document name")
                        .account(Account.builder().id(1L).build())
                        .security(Security.builder().securityId(1L).build())
                        .build())
                .limitedPartnerId("489419121")
                .limitedPartnerPercentOfFund(1.2D)
                .limitedPartnerPercentOfNAV(0.57D)
                .netAmount(198198549D)
                .totalContribution(9.7D)
                .beneficiaryBankDetail(BankDetail.builder().id(74235L).build())
                .intermediaryBankDetail(BankDetail.builder().id(548L).build())
                .correspondentBankDetail(BankDetail.builder().id(659L).build())
                .totalRecallableDistribution(2.7D)
                .totalNonRecallableDistribution(7.0D)
                .recallableDistributionITD(0D)
                .returnOfCapitalDistributionITD(6.2D)
                .currency("USD")
                .fxCurrency("INR")
                .action("Update")
                .ffcName("The Investment Bank")
                .ffcNumber("1561961")
                .knowledgeStartDate(null)
                .knowledgeEndDate(LocalDateTime.of(2022, Month.JUNE, 8, 2, 2, 48))
                .createdBy("document-cashflow-lib")
                .isCreatedByInternalUser(true)
                .createdOn(LocalDateTime.of(2022, Month.JUNE, 8, 2, 2, 48))
                .modifiedBy("document-cashflow-lib")
                .build());
    return new DocumentCashflowRequest(documentCashFlows);
  }

  @SneakyThrows
  public static AumRequest getAumRequest() {
    return getObjectMapper()
        .readValue(Files.readString(Path.of("src/test/resources/aum_data.json")), AumRequest.class);
  }

  public static AccountSubscriptionRules getAccountSubscriptionRules() {
    return AccountSubscriptionRules.builder().ruleId(1L).build();
  }

  public static BalanceRequest getBalanceRequest(long id) {
    var request = getBalanceRequest();
    request.getBalances().iterator().next().setId(id);
    return request;
  }

  private static final AtomicLong tranId = new AtomicLong(50);

  private static Long getTransactionId() {
    return tranId.getAndIncrement();
  }

  public static Transaction getTransaction() {
    return Transaction.builder()
        .id(getTransactionId())
        .account(
            Account.builder()
                .id(42L)
                .clientId(2L)
                .functionalCurrencyCode("USD")
                .currencyFxRateSourceId(1L)
                .functionalCurrencyId(1L)
                .build())
        .security(Security.builder().securityId(3L).securityName("Name").cusip("Cusip").build())
        .document(Document.builder().id(23L).build())
        .source("trans_source")
        .tradeDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .entryDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .settleDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .knowledgeStartDate(LocalDateTime.now())
        .knowledgeEndDate(LocalDateTime.now())
        .type("BUY")
        .subType("transaction_subtype")
        .currency("USD")
        .grossAmount(112233.01)
        .netAmount(555222.23)
        .cashImpact(89.89)
        .navImpact(64.29)
        .unfundedCommitmentImpact(1222.67)
        .fundedCommitmentImpact(-1222.67)
        .recallableImpact(67.21)
        .investmentCompany("blackbuck")
        .createdBy("lpx-service")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.now())
        .modifiedBy("lpx-service")
        .isModifiedByInternalUser(true)
        .modifiedOn(LocalDateTime.now())
        .action("Create")
        .isCurrent(Boolean.TRUE)
        .isHistoric(Boolean.FALSE)
        .build();
  }

  public static Transaction getNavTransaction() {
    return Transaction.builder()
        .id(getTransactionId())
        .account(Account.builder().id(42L).clientId(2L).build())
        .security(Security.builder().securityId(3L).securityName("Name").cusip("Cusip").build())
        .document(Document.builder().id(23L).build())
        .source("trans_source")
        .tradeDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .entryDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .settleDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .knowledgeStartDate(LocalDateTime.of(2022, 2, 15, 12, 0, 0))
        .knowledgeEndDate(LocalDateTime.of(2029, 2, 15, 12, 0, 0))
        .type("NAV")
        .subType("transaction_subtype")
        .currency("USD")
        .grossAmount(101.01)
        .netAmount(202.02)
        .cashImpact(303.03)
        .navImpact(404.04)
        .unfundedCommitmentImpact(505.05)
        .fundedCommitmentImpact(-505.05)
        .recallableImpact(606.06)
        .investmentCompany("blackbuck")
        .createdBy("lpx-service")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.now())
        .modifiedBy("lpx-service")
        .isModifiedByInternalUser(true)
        .modifiedOn(LocalDateTime.now())
        .action("Create")
        .isCurrent(Boolean.TRUE)
        .build();
  }

  public static DocumentCashFlow getDocumentCashFlow(Long id) {
    return DocumentCashFlow.builder()
        .id(id)
        .document(
            Document.builder()
                .id(23L)
                .account(Account.builder().id(2L).clientId(3L).build())
                .security(Security.builder().securityId(4L).build())
                .fileName("Document name")
                .build())
        .version(1)
        .limitedPartnerId("489419121")
        .limitedPartnerPercentOfFund(1.2D)
        .limitedPartnerPercentOfNAV(0.57D)
        .netAmount(198198549D)
        .totalContribution(9.7D)
        .beneficiaryBankDetail(BankDetail.builder().id(74235L).build())
        .intermediaryBankDetail(BankDetail.builder().id(548L).build())
        .correspondentBankDetail(BankDetail.builder().id(659L).build())
        .totalRecallableDistribution(2.7D)
        .totalNonRecallableDistribution(7.0D)
        .recallableDistributionITD(0D)
        .returnOfCapitalDistributionITD(6.2D)
        .currency("USD")
        .fxCurrency("INR")
        .ffcName("The Investment Bank")
        .ffcNumber("1561961")
        .isCurrent(true)
        .action("create")
        .knowledgeStartDate(null)
        .knowledgeEndDate(LocalDateTime.of(2022, Month.JUNE, 8, 2, 2, 48))
        .createdBy("document-cashflow-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("document-cashflow-lib")
        .build();
  }

  public static TransactionRequest getTransactionRequest() {
    return TransactionRequest.builder().transactions(Set.of(getTransaction())).build();
  }

  public static List<TransactionIdentifier> getTransactionIdentifierRequest() {
    TransactionIdentifier t1 =
        TransactionIdentifier.builder()
            .transactionId(1L)
            .transVersion(1)
            .attributeName("PrometheusId")
            .attributeValue(12345L)
            .createdOn(LocalDateTime.now())
            .build();
    TransactionIdentifier t2 =
        TransactionIdentifier.builder()
            .transactionId(1L)
            .transVersion(1)
            .attributeName("LiteServiceTransactionId")
            .attributeValue(12346L)
            .createdOn(LocalDateTime.now().minusMinutes(10))
            .build();
    return List.of(t1, t2);
  }

  public static TransactionRequest getTransactionRequest(long id) {
    var request = getTransactionRequest();
    request.getTransactions().iterator().next().setId(id);
    return request;
  }

  public static DocumentRequest getDocumentRequest() {
    return DocumentRequest.builder().documents(Set.of(getDocument())).build();
  }

  public static DocumentRequest getDocumentRequest(long id) {
    var document = getDocument();
    document.setId(id);
    return DocumentRequest.builder().documents(Set.of(document)).build();
  }

  public static Comment getComment() {
    return Comment.builder().createdBy("Internal User").documentId(1L).message("message").build();
  }

  public static CommentEntity getCommentEntity() {
    return CommentEntity.builder()
        .createdBy("Internal User")
        .documentId(1L)
        .message("message")
        .build();
  }

  public static CommentRequest getCommentRequest() {
    return CommentRequest.builder().comments(Set.of(getComment())).build();
  }

  public static Watchlist getWatchlist() {
    return Watchlist.builder()
        .createdBy("Internal User")
        .securityId(1L)
        .accountId(9L)
        .startDate(LocalDate.of(2022, 9, 22))
        .endDate(LocalDate.of(2023, 9, 22))
        .build();
  }

  public static WatchlistEntity getWatchlistEntity() {
    return WatchlistEntity.builder()
        .createdBy("Internal User")
        .securityId(1L)
        .accountId(9L)
        .startDate(LocalDate.of(2022, 9, 22))
        .endDate(LocalDate.of(2023, 9, 22))
        .build();
  }

  public static WatchlistRequest getWatchlistRequest() {
    return WatchlistRequest.builder().watchlistInfo(Set.of(getWatchlist())).build();
  }

  public static CwanGptDocumentRequest getClearwaterDocumentRequest() {
    return CwanGptDocumentRequest.builder()
        .documents(List.of(createCwanGptDocumentRequest()))
        .build();
  }

  public static TransactionType getTransactionType() {
    return TransactionType.builder()
        .code("BUY")
        .name("BUY")
        .description("Buying of units Txn")
        .createdBy("pbor-transaction-lib")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2022, 9, 22, 0, 0))
        .modifiedBy("pbor-transaction-lib")
        .isModifiedByInternalUser(true)
        .modifiedOn(LocalDateTime.of(2022, 9, 22, 0, 0))
        .accountingCommitmentChangeTypeId(-6)
        .accountingNavChangeTypeId(12)
        .build();
  }

  public static TransactionSubType getTransactionSubType() {
    return TransactionSubType.builder()
        .code("CAPC_CARRIED_INTEREST")
        .name("CARRIED_INTEREST")
        .description("Buying of units Txn")
        .transactionType(getTransactionType())
        .bookImpactMultiplier(1)
        .cashImpactMultiplier(-1)
        .navImpactMultiplier(1)
        .unfundedCommitmentMultiplier(1)
        .createdBy("liquibase")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2022, 9, 22, 0, 0))
        .modifiedBy("pbor-transaction-lib")
        .isModifiedByInternalUser(true)
        .modifiedOn(LocalDateTime.of(2022, 9, 22, 0, 0))
        .build();
  }

  public static Account getAccount() {
    return Account.builder()
        .id(42L)
        .clientId(2L)
        .functionalCurrencyCode("USD")
        .currencyFxRateSourceId(1L)
        .functionalCurrencyId(1L)
        .build();
  }

  public static Service getService() {
    return Service.builder().name("unit-test").build();
  }

  public static AccountConfig getAccountConfig() {
    return AccountConfig.builder()
        .id(9L)
        .account(getAccount())
        .clientId(24601L)
        .attributes(Map.of())
        .service(getService())
        .createdBy("liquibase")
        .isCreatedByInternalUser(true)
        .subscriptionStartDate(LocalDate.of(2022, 1, 1))
        .subscriptionEndDate(LocalDate.of(9999, 12, 31))
        .build();
  }

  public static Issue getIssue() {
    return Issue.builder()
        .typeName("DOCUMENT_VALIDATION")
        .attributes(Map.of())
        .sourceName("LPXSERVICE")
        .metaData("1337")
        .startDate(LocalDate.of(2022, 10, 1))
        .endDate(LocalDate.of(2022, 10, 15))
        .createdDateTime(atEndOfDay(LocalDate.of(2022, 10, 1)))
        .note("michaelhansen generated this")
        .status(getIssueStatus())
        .build();
  }

  public static Issue getDeletedIssue() {
    return Issue.builder()
        .typeName("DOCUMENT_VALIDATION")
        .attributes(Map.of())
        .sourceName("LPXSERVICE")
        .metaData("1337")
        .startDate(LocalDate.of(2022, 10, 1))
        .endDate(LocalDate.of(2022, 10, 15))
        .createdDateTime(atEndOfDay(LocalDate.of(2022, 10, 1)))
        .note("michaelhansen generated this")
        .status(getDeletedIssueStatus())
        .build();
  }

  public static IssueStatus getIssueStatus() {
    return IssueStatus.builder()
        .userId(31231)
        .metaData("metadata")
        .statusName(IssueStatusName.FOUND)
        .toolName("lpx-service")
        .researchNote("will look at document")
        .expiration(getIssueExpiration())
        .note("testing")
        .build();
  }

  public static IssueStatus getDeletedIssueStatus() {
    return IssueStatus.builder()
        .userId(31231)
        .metaData("metadata")
        .statusName(IssueStatusName.DELETED)
        .toolName("lpx-service")
        .researchNote("will look at document")
        .expiration(getIssueExpiration())
        .note("testing")
        .build();
  }

  public static IssueExpiration getIssueExpiration() {
    return IssueExpiration.builder()
        .date(LocalDate.of(2022, 12, 31))
        .statusName(IssueStatusName.FOUND)
        .build();
  }

  public static CalculatedBalance getCalculatedBalance() {
    return CalculatedBalance.builder()
        .source("source")
        .security(Security.builder().securityId(2L).build())
        .account(Account.builder().id(1L).build())
        .currency("USD")
        .navImpact(0.0)
        .watchlistNavImpact(0.0)
        .fundedCommitmentImpact(1.0)
        .unfundedCommitmentImpact(2.0)
        .recallableImpact(3.0)
        .build();
  }

  public static AccountingCalculatedBalance getAccountingCalculatedBalance() {
    return AccountingCalculatedBalance.builder()
        .source("source")
        .security(Security.builder().securityId(2L).build())
        .account(Account.builder().id(1L).build())
        .currency("USD")
        .navImpact(0.0)
        .fundedCommitmentImpact(1.0)
        .unfundedCommitmentImpact(2.0)
        .recallableImpact(3.0)
        .build();
  }

  public static Balance getBalance(Long accountId) {
    return Balance.builder()
        .account(Account.builder().id(accountId).build())
        .security(Security.builder().securityId(4L).build())
        .document(Document.builder().id(5L).fileName("Document name").build())
        .source("source")
        .entryDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .balanceDate(LocalDate.of(2022, 1, 1))
        .knowledgeStartDate(LocalDateTime.of(2022, Month.JULY, 1, 1, 1, 48))
        .knowledgeEndDate(LocalDateTime.of(2022, Month.JULY, 2, 2, 2, 48))
        .type("TOTAL_COMMITMENT")
        .currency("USD")
        .fxCurrency("INR")
        .amount(1.0)
        .amountMTD(2.0)
        .amountQTD(3.0)
        .amountYTD(4.0)
        .amountITD(5.0)
        .createdBy("pbor-balance-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("pbor-balance-lib")
        .isModifiedByInternalUser(true)
        .build();
  }

  public static Security getSecurity() {
    return Security.builder().securityId(3L).securityName("Name").cusip("Cusip").build();
  }

  public static Document getDocument() {
    return Document.builder()
        .id(23L)
        .account(
            Account.builder()
                .id(42L)
                .clientId(2L)
                .functionalCurrencyCode("USD")
                .currencyFxRateSourceId(1L)
                .functionalCurrencyId(1L)
                .build())
        .security(Security.builder().securityId(3L).securityName("Name").cusip("Cusip").build())
        .fileName("file_name")
        .type("capital account")
        .isAudited(true)
        .source("canoe")
        .canoeId("892994fa-b33c-11eb-ba61-d50ed001af0a")
        .receivedDate(LocalDate.of(2022, 4, 14))
        .documentDate(LocalDate.of(2022, 3, 31))
        .cashMovementDate(LocalDate.of(2022, 4, 1))
        .frequency("quarterly")
        .periodStartDate(LocalDate.of(2022, 1, 1))
        .periodEndDate(LocalDate.of(2022, 3, 31))
        .directoryId(25L)
        .checked(false)
        .errorStatus("none")
        .createdBy("user1")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2022, 4, 14, 12, 43, 23))
        .modifiedBy("user2")
        .isModifiedByInternalUser(false)
        .modifiedOn(LocalDateTime.of(2022, 4, 15, 3, 23, 12))
        .build();
  }

  public static ObjectMapper getObjectMapper() {
    return new ObjectMapper().registerModule(new JavaTimeModule());
  }

  @SneakyThrows
  public static ClassPathResource getFile() {
    return new ClassPathResource("file.pdf");
  }

  public static Authentication getAuthentication() {
    return new UsernamePasswordAuthenticationToken(
        "username",
        "password",
        List.of(
            new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE),
            new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_READ),
            new SimpleGrantedAuthority(
                LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_WRITE),
            new SimpleGrantedAuthority(
                LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_VIEW_ACCESS),
            new SimpleGrantedAuthority(
                LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_EDIT_ACCESS),
            new SimpleGrantedAuthority(
                LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_MANAGER_VIEW),
            new SimpleGrantedAuthority(
                LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_DOCUMENT_MANAGER_EDIT),
            new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_K1_READ),
            new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_K1_WRITE),
            new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_WATCHLIST_READ),
            new SimpleGrantedAuthority(LPxAMPTPermissions.LPX_MANAGEMENT_CONSOLE_WATCHLIST_WRITE)));
  }

  public static SecurityContext getSecurityContext() {
    return new SecurityContextImpl(getAuthentication());
  }

  public static SecurityMasterData getSecurityMasterData() {
    return SecurityMasterData.builder()
        .id(1L)
        .cusip("cusip")
        .name("important-security")
        .currencyCode("BTC")
        .build();
  }

  public static SecurityResponse getSecurityResponse() {
    return SecurityResponse.builder()
        .securityId(1L)
        .securityMasterData(getSecurityMasterData())
        .build();
  }

  public static Tag getTag(Long id) {
    return Tag.builder().id(id).documentId(1234L).tag("Comments").build();
  }

  public static TagEntity getTagEntity(Long id) {
    return TagEntity.builder().id(id).documentId(1234L).tag("Comments").build();
  }

  public static Directory getDirectory(Long id) {
    return Directory.builder()
        .id(id)
        .accountId(123L)
        .parentDirectoryId(3L)
        .name("Wayne Enterprises, Inc")
        .isDisabled(false)
        .build();
  }

  public static DirectoryEntity getDirectoryEntity(Long id) {
    return DirectoryEntity.builder()
        .id(id)
        .accountId(123L)
        .parentDirectoryId(3L)
        .name("Wayne Enterprises, Inc")
        .isDisabled(false)
        .build();
  }

  public static DocumentEntity getDocumentEntity() {
    return DocumentEntity.builder()
        .id(23L)
        .accountId(2L)
        .securityId(3L)
        .fileName("file_name")
        .type("capital account")
        .isAudited(true)
        .source("canoe")
        .receivedDate(LocalDate.of(2022, 4, 14))
        .docDate(LocalDate.of(2022, 3, 31))
        .cashMvmtDate(LocalDate.of(2022, 4, 1))
        .frequency("quarterly")
        .periodStartDate(LocalDate.of(2022, 1, 1))
        .periodEndDate(LocalDate.of(2022, 3, 31))
        .checked(false)
        .errorStatus("none")
        .createdBy("user1")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2022, 4, 14, 12, 43, 23))
        .modifiedBy("user2")
        .isModifiedByInternalUser(false)
        .modifiedOn(LocalDateTime.of(2022, 4, 15, 3, 23, 12))
        .build();
  }

  public static DocumentManagerData getDocumentManagerData() {
    return DocumentManagerData.builder().document(getDocument()).tags(Set.of("tag1")).build();
  }

  public static DirectoryRequest getDirectoryRequest(Long id) {
    return DirectoryRequest.builder().directories(Set.of(getDirectory(id))).build();
  }

  public static PortfolioBalance getPortfolioBalance() {
    return PortfolioBalance.builder()
        .account(getAccount())
        .security(getSecurity())
        .performance(Performance.builder().id(1L).build())
        .build();
  }

  public static PortfolioSummaryResponse getPortfolioSummaryResponse() {
    return PortfolioSummaryResponse.builder()
        .data(List.of(getPortfolioBalance()))
        .agg(
            AggregatePortfolioData.builder()
                .irr(0.05)
                .pme(1.02)
                .rvpi(1.10)
                .dpi(0.80)
                .tvpi(1.90)
                .build())
        .build();
  }

  public static Performance getPerformance() {
    return Performance.builder()
        .accountId(1L)
        .securityId(123L)
        .dpi(2D)
        .grossXirr(3D)
        .dc(4D)
        .rvpi(5D)
        .frequency("ITD")
        .calculationDate(LocalDateTime.of(2023, 1, 1, 1, 1, 1))
        .build();
  }

  public static Set<FinancialStatement> getFinancialStatements() {
    return Set.of(
        FinancialStatement.builder()
            .id(1L)
            .account(getAccount())
            .document(getDocument())
            .security(getSecurity())
            .currency("USD")
            .build());
  }

  public static FinancialStatement getFinancialStatement() {
    return FinancialStatement.builder()
        .id(1L)
        .account(Account.builder().id(42L).clientId(2L).build())
        .security(Security.builder().securityId(3L).securityName("Name").cusip("Cusip").build())
        .document(Document.builder().id(23L).build())
        .currency("USD")
        .build();
  }

  public static Transaction createHistoricTransaction(Transaction transaction) {
    return Transaction.builder()
        .id(getTransactionId())
        .account(transaction.getAccount())
        .security(transaction.getSecurity())
        // Set any other fields required for the test
        .build();
  }

  public static LIHTCBenefitSchedule getLihtcBenefitSchedule() {
    return LIHTCBenefitSchedule.builder()
        .account(getAccount())
        .security(getSecurity())
        .taxType(TaxType.FEDERAL)
        .reportingDate(LocalDate.of(2022, 1, 1))
        .scheduleDate(LocalDate.of(2025, 1, 1))
        .contributions(1000.0)
        .distributions(0.0)
        .federalCredits(0.0)
        .stateCredits(0.0)
        .otherCredits(0.0)
        .taxDeductions(0.0)
        .sale(0.0)
        .build();
  }

  public static ManualAmortSegment getManualAmortSegment() {
    return ManualAmortSegment.builder()
        .accountId(getAccount().getId())
        .securityId(getSecurity().getSecurityId())
        .basisId(1)
        .effectiveDate(LocalDate.of(2025, 1, 20))
        .modifiedBy("tyler")
        .build();
  }

  public static LIHTCTaxRate getLihtcTaxRate() {
    return LIHTCTaxRate.builder()
        .account(getAccount())
        .security(getSecurity())
        .taxType(TaxType.FEDERAL)
        .taxRate(0.50)
        .taxRateStartDate(LocalDate.of(2022, 1, 1))
        .build();
  }

  public static CwanGptDocument createCwanGptDocumentRequest() {
    return CwanGptDocument.builder().id(1L).cloudStorageId("storageId").build();
  }

  public static MissingDocumentExpectationsConfig getMissingDocumentExpectationsConfig() {
    return MissingDocumentExpectationsConfig.builder()
        .securityId(1L)
        .fundId(425L)
        .documentType("test")
        .frequency("M")
        .threshold(1)
        .isActive(true)
        .build();
  }

  public static MissingDocumentAlertConfig getMissingDocumentAlertConfig() {
    return MissingDocumentAlertConfig.builder()
        .clientId(1L)
        .username(List.of())
        .isActive(true)
        .build();
  }

  public static Basis getBasis() {
    return new Basis(3, "TAX", "Tax Accounting", "TAX");
  }

  public static User getUser() {
    return User.builder()
        .id(1)
        .username("tuser")
        .phone("123-456-7890")
        .privateLabel("CWAN")
        .firstName("Test")
        .lastName("User")
        .fullname("Test User")
        .email("testuser@example.com")
        .build();
  }

  public static FilePart getFilePart() {
    return new FilePart() {
      @Override
      public String filename() {
        return "filename.pdf";
      }

      @Override
      public Mono<Void> transferTo(Path dest) {
        return null;
      }

      @Override
      public String name() {
        return "filename";
      }

      @Override
      public HttpHeaders headers() {
        return null;
      }

      @Override
      public Flux<DataBuffer> content() {
        return null;
      }
    };
  }
}
