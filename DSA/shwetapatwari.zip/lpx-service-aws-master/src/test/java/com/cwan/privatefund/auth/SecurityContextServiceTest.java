package com.cwan.privatefund.auth;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;

/** Test class for SecurityContextService. */
@ExtendWith(MockitoExtension.class)
class SecurityContextServiceTest {

  @InjectMocks private SecurityContextService securityContextService;
  @Mock private ISecurityContextProvider securityContextProvider;

  /** Test for getContext method. Should return SecurityContext when called. */
  @Test
  void getContext_ShouldReturnSecurityContext() {
    // arrange
    var expectedContext = Mono.just(Mockito.mock(SecurityContext.class));
    when(securityContextProvider.provideContext()).thenReturn(expectedContext);
    // act
    var actualContext = securityContextService.getContext();
    // assert
    assertEquals(expectedContext, actualContext);
    verify(securityContextProvider).provideContext();
  }
}
