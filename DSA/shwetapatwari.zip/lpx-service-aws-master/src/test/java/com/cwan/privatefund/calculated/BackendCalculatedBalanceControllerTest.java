package com.cwan.privatefund.calculated;

import static com.cwan.privatefund.TestUtil.BACKEND_CALCULATED_URI;
import static com.cwan.privatefund.TestUtil.TIME_OUT;
import static com.cwan.privatefund.TestUtil.getCalculatedBalance;
import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import lombok.val;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class BackendCalculatedBalanceControllerTest extends AuthenticatedControllerTest {

  @Autowired private WebTestClient webClient;
  @MockBean private CalculatedBalanceService calculatedBalanceService;
  @MockBean private AccountService accountService;

  @BeforeAll
  static void beforeAll() {
    System.setProperty("env", "ci");
  }

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(Duration.ofSeconds(TIME_OUT)).build();
    mockSecurityContext();
  }

  @Test
  void should_get_calculated_balances_by_account_id() {
    var calculatedBalance = getCalculatedBalance();
    val accountId = calculatedBalance.getAccount().getId();
    var asOfDate = LocalDate.of(2022, 1, 1);
    var knowledgeDate = LocalDate.of(2022, 1, 2);
    when(calculatedBalanceService.calculateBalances(accountId, asOfDate, knowledgeDate, false))
        .thenReturn(Flux.fromIterable(List.of(calculatedBalance)));
    when(accountService.expandAccountId(accountId)).thenReturn(Flux.just(accountId));
    var actual =
        getCalculatedBalancesEntity(
            format(
                "%s%s%d%s%s%s%s",
                BACKEND_CALCULATED_URI,
                "/account?accountId=",
                accountId,
                "&asOfDate=",
                asOfDate,
                "&knowledgeDate=",
                knowledgeDate));
    assertEquals(List.of(calculatedBalance), actual);
  }

  private List<CalculatedBalance> getCalculatedBalancesEntity(String uri) {
    return List.copyOf(
        Objects.requireNonNull(
            exchangeForEntity(uri)
                .expectStatus()
                .is2xxSuccessful()
                .returnResult(CalculatedBalance.class)
                .getResponseBody()
                .collectList()
                .block()));
  }

  private WebTestClient.ResponseSpec exchangeForEntity(String uri) {
    return webClient.method(HttpMethod.GET).uri(uri).exchange();
  }
}
