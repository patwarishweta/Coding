package com.cwan.privatefund.notification.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.privatefund.salesforce.common.SalesforceProperties;
import com.cwan.privatefund.salesforce.service.SalesforceAuthorizationService;
import com.cwan.privatefund.salesforce.service.SalesforceCaseQueryService;
import com.cwan.privatefund.salesforce.service.SoapEnvelopeService;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class EmailViaSalesforceServiceTest {

  private static final String AUTH_TOKEN = "token";
  private static final String SUBJECT = "subject";
  private static final String HTML_MESSAGE = "message";
  private static final String SOAP_ENVELOPE = "soapEnvelope";
  private static final String ACCOUNT_ID = "accountId";
  private static final String CASE_ID = "caseId";
  private static final List<String> EMAIL_LIST = Arrays.asList("email1", "email2", "email3");

  @Mock private SalesforceAuthorizationService authService;

  @Mock private SalesforceCaseQueryService caseService;

  @Mock private SoapEnvelopeService envelopeService;

  @Mock private SalesforceProperties salesforceProperties;

  @Mock private RestTemplate restTemplate;

  @InjectMocks private EmailViaSalesforceService service;

  @Test
  void shouldSendEmailWhenAllArgumentsAreValid() throws IOException {
    when(authService.getSalesforceAuthToken()).thenReturn(AUTH_TOKEN);
    when(caseService.querySalesforceCaseIdOnAccountId(anyString(), anyString()))
        .thenReturn(CASE_ID);
    when(envelopeService.generateSoapEnvelope(
            anyString(), anyString(), anyString(), anyString(), anyString()))
        .thenReturn(SOAP_ENVELOPE);
    when(restTemplate.exchange(
            anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(String.class)))
        .thenReturn(new ResponseEntity<>("Response", HttpStatus.OK));
    when(salesforceProperties.getSfInstanceHost())
        .thenReturn("clearwaterTest--full.sandbox.my.salesforce.com");

    service.sendEmailNotification(SUBJECT, HTML_MESSAGE, EMAIL_LIST, ACCOUNT_ID);

    verify(authService, times(1)).getSalesforceAuthToken();
    verify(caseService, times(1)).querySalesforceCaseIdOnAccountId(AUTH_TOKEN, ACCOUNT_ID);
    verify(envelopeService, times(1))
        .generateSoapEnvelope(
            AUTH_TOKEN, String.join(",", EMAIL_LIST), SUBJECT, HTML_MESSAGE, CASE_ID);
    verify(restTemplate, times(1))
        .exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(String.class));
  }
}
