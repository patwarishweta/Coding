package com.cwan.privatefund.balance;

import static com.cwan.privatefund.TestUtil.getBalance;
import static com.cwan.privatefund.constant.Constants.EntityActions.CANCEL;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Balance;
import com.cwan.privatefund.account.AccountService;
import com.cwan.privatefund.balance.model.BalanceRequest;
import com.cwan.privatefund.publisher.MessagePublisher;
import com.cwan.privatefund.util.DateUtils;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

class LpxBalanceServiceTest {

  @Mock private MessagePublisher<Balance> balanceMessagePublisher;
  @Mock private LpxBalanceEntityService lpxBalanceEntityService;
  @Mock private AccountService accountService;
  private LpxBalanceService lpxBalanceService;
  private static final Set<Long> BALANCE_IDS = Set.of(1L);
  private static final Long ACCOUNT_ID_1 = 9L;
  private static final Long ACCOUNT_ID_2 = 10L;
  private static final Balance BALANCE_1 = getBalance(ACCOUNT_ID_1);
  private static final Balance BALANCE_2 = getBalance(ACCOUNT_ID_2);

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    lpxBalanceService =
        new LpxBalanceService(lpxBalanceEntityService, balanceMessagePublisher, accountService);
  }

  @Test
  void should_get_balances_by_account_and_balance_date_and_knowledge_start_date() {
    var balanceDate = LocalDate.of(2022, 1, 1);
    var knowledgeDate = LocalDate.of(2022, 2, 12);
    when(accountService.expandAccountId(ACCOUNT_ID_1))
        .thenReturn(Flux.fromIterable(List.of(ACCOUNT_ID_1, ACCOUNT_ID_2)));
    when(lpxBalanceEntityService.getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
            ACCOUNT_ID_1, balanceDate, DateUtils.atEndOfDay(knowledgeDate)))
        .thenReturn(Flux.just(BALANCE_1));
    when(lpxBalanceEntityService.getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
            ACCOUNT_ID_2, balanceDate, DateUtils.atEndOfDay(knowledgeDate)))
        .thenReturn(Flux.just(BALANCE_2));
    var actual =
        lpxBalanceService
            .getAccountBalances(ACCOUNT_ID_1, balanceDate, knowledgeDate)
            .collectList()
            .block();
    assertEquals(List.of(BALANCE_1, BALANCE_2), actual);
  }

  @Test
  void whenAccountIdsIsNull_thenReturnEmpty() {
    LocalDate balanceDate = LocalDate.now();
    LocalDate knowledgeDate = LocalDate.now();
    Flux<Balance> result = lpxBalanceService.getAccountsBalances(null, balanceDate, knowledgeDate);
    assertNull(result);
    verify(lpxBalanceEntityService)
        .getBalancesOnBalanceDate(balanceDate, DateUtils.atEndOfDay(knowledgeDate));
    verifyNoInteractions(accountService);
  }

  @Test
  void should_add_balances() {
    BalanceRequest balanceRequest = new BalanceRequest();
    balanceRequest.setBalances(Set.of(BALANCE_1, BALANCE_2));
    lpxBalanceService.addBalance(balanceRequest, "true");
    verify(balanceMessagePublisher, times(2))
        .publishMessage(any(Balance.class), anyMap(), eq(true));
  }

  @Test
  void should_get_balances_by_ids() {
    when(lpxBalanceEntityService.getBalancesByIds(BALANCE_IDS)).thenReturn(Flux.just(BALANCE_1));
    StepVerifier.create(lpxBalanceService.getBalanceByBalanceId(BALANCE_IDS))
        .expectNext(BALANCE_1)
        .verifyComplete();
  }

  @Test
  void should_update_balances() {
    BalanceRequest balanceRequest = new BalanceRequest();
    balanceRequest.setBalances(Set.of(BALANCE_1, BALANCE_2));
    lpxBalanceService.updateBalances(balanceRequest).block();
    verify(balanceMessagePublisher, times(2))
        .publishMessage(any(Balance.class), anyMap(), eq(true));
  }

  @Test
  void should_get_balances_by_document_id() {
    Long documentId = 123L;
    when(lpxBalanceEntityService.getBalancesByDocumentIds(Set.of(documentId)))
        .thenReturn(Flux.just(BALANCE_1));
    StepVerifier.create(lpxBalanceService.getBalancesByDocumentId(documentId))
        .expectNext(BALANCE_1)
        .verifyComplete();
  }

  @Test
  void should_get_balances_on_balance_date_when_account_ids_empty() {
    LocalDate balanceDate = LocalDate.now();
    LocalDate knowledgeDate = LocalDate.now();
    when(lpxBalanceEntityService.getBalancesOnBalanceDate(
            balanceDate, DateUtils.atEndOfDay(knowledgeDate)))
        .thenReturn(Flux.just(BALANCE_1, BALANCE_2));
    StepVerifier.create(
            lpxBalanceService.getAccountsBalances(
                Collections.emptySet(), balanceDate, knowledgeDate))
        .expectNext(BALANCE_1, BALANCE_2)
        .verifyComplete();
  }

  @Test
  void should_get_balances_on_balance_date_for_accounts() {
    LocalDate balanceDate = LocalDate.now();
    LocalDate knowledgeDate = LocalDate.now();
    Set<Long> accountIds = Set.of(ACCOUNT_ID_1, ACCOUNT_ID_2);
    when(accountService.expandAccountId(ACCOUNT_ID_1)).thenReturn(Flux.just(ACCOUNT_ID_1));
    when(accountService.expandAccountId(ACCOUNT_ID_2)).thenReturn(Flux.just(ACCOUNT_ID_2));
    when(lpxBalanceEntityService.getBalancesOnBalanceDateForAccounts(
            accountIds, balanceDate, DateUtils.atEndOfDay(knowledgeDate)))
        .thenReturn(Flux.just(BALANCE_1, BALANCE_2));
    StepVerifier.create(
            lpxBalanceService.getAccountsBalances(accountIds, balanceDate, knowledgeDate))
        .expectNext(BALANCE_1, BALANCE_2)
        .verifyComplete();
  }

  @Test
  void should_delete_balances_by_id() {
    when(lpxBalanceEntityService.getBalancesByIds(BALANCE_IDS)).thenReturn(Flux.just(BALANCE_1));
    StepVerifier.create(lpxBalanceService.deleteBalanceByBalanceId(BALANCE_IDS)).verifyComplete();
    verify(lpxBalanceEntityService).getBalancesByIds(BALANCE_IDS);
    ArgumentCaptor<Balance> balanceCaptor = ArgumentCaptor.forClass(Balance.class);
    verify(balanceMessagePublisher).publishMessage(balanceCaptor.capture(), anyMap(), eq(true));
    Balance capturedBalance = balanceCaptor.getValue();
    assertNotNull(capturedBalance.getKnowledgeEndDate());
    assertEquals(CANCEL, capturedBalance.getAction());
  }
}
