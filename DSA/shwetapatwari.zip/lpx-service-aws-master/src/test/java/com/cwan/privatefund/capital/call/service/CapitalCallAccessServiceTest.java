package com.cwan.privatefund.capital.call.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.privatefund.auth.accesscontrolfiltering.AccessControlFilteringService;
import com.cwan.privatefund.business.ws.model.User;
import com.cwan.privatefund.capital.call.constant.CapitalCallAccessType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallAccessServiceTest {

  @InjectMocks private CapitalCallAccessService capitalCallAccessService;
  @Mock private CapitalCalls capitalCalls;
  @Mock private AccessControlFilteringService accessControlFilteringService;
  @Mock private CapitalCallPermissionService capitalCallPermissionService;
  @Mock private CapitalCallEnrichmentService capitalCallEnrichmentService;

  @Test
  void testCheckUserAccess() {
    var userId = 1;
    var documentId = 100L;
    var accountId = 20L;
    var clientId = 30L;
    var userEmail = "test@example.com";
    var user = User.builder().id(userId).fullname("Capital Call").email(userEmail).build();
    var account = Account.builder().id(accountId).clientId(clientId).build();
    var capitalCallDocument =
        CapitalCallDocument.builder()
            .account(account)
            .documentId(documentId)
            .status(CapitalCallStatus.INITIAL_REVIEW)
            .build();
    when(capitalCalls.getCapitalCallByDocument(documentId))
        .thenReturn(Mono.just(capitalCallDocument));
    when(capitalCallEnrichmentService.enrichCapitalCallWithData(any(), anyString()))
        .thenReturn(Mono.just(capitalCallDocument));
    when(accessControlFilteringService.checkResourceAccessByAccount(user, accountId))
        .thenReturn(Mono.just(Boolean.TRUE));
    when(capitalCallPermissionService.fetchAndDeterminePermissionByUserEmail(
            any(), any(), any(), any()))
        .thenReturn(Mono.just(true));
    StepVerifier.create(
            capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .expectNext(capitalCallDocument)
        .verifyComplete();
    verify(accessControlFilteringService, times(1)).checkResourceAccessByAccount(user, accountId);
    verify(capitalCalls, times(1)).getCapitalCallByDocument(documentId);
  }

  @Test
  void testCheckUserAccess_noAccess() {
    var userId = 1;
    var documentId = 100L;
    var accountId = 20L;
    var clientId = 30L;
    var account = Account.builder().id(accountId).clientId(clientId).build();
    var user =
        User.builder().id(userId).fullname("Capital Call").email("someemail@somemail.com").build();
    var capitalCallDocument =
        CapitalCallDocument.builder()
            .account(account)
            .documentId(documentId)
            .status(CapitalCallStatus.INITIAL_REVIEW)
            .build();
    when(capitalCalls.getCapitalCallByDocument(anyLong()))
        .thenReturn(Mono.just(capitalCallDocument));
    when(capitalCallEnrichmentService.enrichCapitalCallWithData(any(), any()))
        .thenReturn(Mono.just(capitalCallDocument));
    when(accessControlFilteringService.checkResourceAccessByAccount(user, accountId))
        .thenReturn(Mono.just(Boolean.FALSE));
    StepVerifier.create(
            capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .expectError(AccessDeniedException.class)
        .verify();
    verify(accessControlFilteringService, times(1)).checkResourceAccessByAccount(user, accountId);
    verify(capitalCalls, times(1)).getCapitalCallByDocument(documentId);
  }

  @Test
  void testCheckUserAccess_runtimeException() {
    var userId = 1;
    var documentId = 100L;
    var user = User.builder().id(userId).fullname("Capital Call").build();
    when(capitalCalls.getCapitalCallByDocument(anyLong()))
        .thenReturn(Mono.error(new RuntimeException("Unexpected error")));
    StepVerifier.create(
            capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .expectError(RuntimeException.class)
        .verify();
    verify(capitalCalls, times(1)).getCapitalCallByDocument(anyLong());
  }

  @Test
  void testCheckUserAccess_noPermission() {
    var userId = 1;
    var documentId = 100L;
    var accountId = 20L;
    var clientId = 30L;
    var userEmail = "test@example.com";
    var user = User.builder().id(userId).fullname("Capital Call").email(userEmail).build();
    var account = Account.builder().id(accountId).clientId(clientId).build();
    var capitalCallDocument =
        CapitalCallDocument.builder()
            .account(account)
            .documentId(documentId)
            .status(CapitalCallStatus.INITIAL_REVIEW)
            .build();
    when(capitalCalls.getCapitalCallByDocument(documentId))
        .thenReturn(Mono.just(capitalCallDocument));
    when(accessControlFilteringService.checkResourceAccessByAccount(user, accountId))
        .thenReturn(Mono.just(Boolean.TRUE));
    when(capitalCallPermissionService.fetchAndDeterminePermissionByUserEmail(
            any(), any(), any(), any()))
        .thenReturn(Mono.just(false));
    when(capitalCallEnrichmentService.enrichCapitalCallWithData(any(), anyString()))
        .thenReturn(Mono.just(capitalCallDocument));
    StepVerifier.create(
            capitalCallAccessService.checkUserAccess(user, documentId, CapitalCallAccessType.WRITE))
        .expectError(AccessDeniedException.class)
        .verify();
    verify(accessControlFilteringService, times(1)).checkResourceAccessByAccount(user, accountId);
    verify(capitalCalls, times(1)).getCapitalCallByDocument(documentId);
  }
}
