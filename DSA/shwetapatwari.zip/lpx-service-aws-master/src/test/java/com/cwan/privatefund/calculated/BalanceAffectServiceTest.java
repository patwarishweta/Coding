package com.cwan.privatefund.calculated;

import static com.cwan.pbor.trans.Constants.TransactionTypes.GENERAL_ADJUSTMENT;
import static com.cwan.privatefund.constant.Constants.MISCELLANEOUS;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.ca.util.date.localdate.LocalDateRange;
import com.ca.util.date.localdate.LocalDateRanges;
import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import com.cwan.privatefund.calculated.model.BalanceAffect;
import com.cwan.privatefund.constant.Constants;
import com.cwan.privatefund.watchlist.model.WatchlistEntity;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;

class BalanceAffectServiceTest {

  private static final LocalDate END_DATE = LocalDate.of(2022, 1, 31);
  private static final WatchlistEntity WATCHLIST_ENTITY =
      WatchlistEntity.builder()
          .accountId(1L)
          .securityId(123L)
          .startDate(END_DATE.minusDays(1))
          .endDate(END_DATE.plusDays(1))
          .build();
  private static final Map<Long, Set<WatchlistEntity>> WATCHLIST_PERIOD =
      Map.of(1L, Set.of(WATCHLIST_ENTITY));
  private static final Account ACCOUNT = Account.builder().id(1L).build();
  private static final Security SECURITY = Security.builder().securityId(123L).build();
  private static final BalanceAffectService INSTANCE = new BalanceAffectService();

  @Test
  public void getZeroedBalanceAffectsTest() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));
    List<BalanceAffect> actual = INSTANCE.getZeroedBalanceAffects(date, WATCHLIST_PERIOD);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffectsTest() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction transaction =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(Constants.COMMITMENT_ADJUSTMENT_TRANSACTION_TYPE)
            .subType(Constants.TOTAL_COMMITMENT_SUBTYPE)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(null)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 2.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 3.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, transaction, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffectsTest_historicCAPC() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction transaction =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type("CAPC")
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .isHistoric(true)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(null)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, transaction, WATCHLIST_PERIOD, false);
    assertEquals(
        4.0,
        actual.stream()
            .filter(c -> c.getBalanceType() == BalanceType.CUM_CONTRIBUTION)
            .findFirst()
            .get()
            .getAmount());
  }

  @Test
  public void getBalanceAffectsTest_generalAdjustments_excludeHistoric() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction transaction =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(GENERAL_ADJUSTMENT)
            .subType(MISCELLANEOUS)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(0.0)
            .fundedCommitmentImpact(3.0)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, transaction, WATCHLIST_PERIOD, true);
    assertEquals(
        3.0,
        actual.stream()
            .filter(c -> c.getBalanceType() == BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION)
            .findFirst()
            .get()
            .getAmount());
  }

  @Test
  public void getBalanceAffectsTest_generalAdjustments_includeHistoric() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction transaction =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(GENERAL_ADJUSTMENT)
            .subType(MISCELLANEOUS)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(0.0)
            .fundedCommitmentImpact(3.0)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, transaction, WATCHLIST_PERIOD, false);
    assertEquals(
        0.0,
        actual.stream()
            .filter(c -> c.getBalanceType() == BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION)
            .findFirst()
            .get()
            .getAmount());
  }

  @Test
  public void misc_transaction_test() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction transaction =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(GENERAL_ADJUSTMENT)
            .subType(MISCELLANEOUS)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(4.0)
            .cashImpact(null)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 2.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 3.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 4.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 4.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, transaction, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffects_magicFilterTest_no_filter() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction commitmentAdjustment =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(Constants.COMMITMENT_ADJUSTMENT_TRANSACTION_TYPE)
            .subType(Constants.TOTAL_COMMITMENT_SUBTYPE)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(null)
            .cashImpact(4.0)
            .build();
    Transaction capc =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type("CAPC")
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .build();
    Transaction capd =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type("CAPD")
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 2.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 3.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));
    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, commitmentAdjustment, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);

    expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 2.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, -3.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 4.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));
    actual = INSTANCE.getBalanceAffects(filterRange, capc, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);

    expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 2.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, -3.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 4.0));
    actual = INSTANCE.getBalanceAffects(filterRange, capd, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffects_magicFilterRangeTest_filter() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = LocalDate.of(2023, 10, 1);
    ;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction commitmentAdjustment =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(Constants.COMMITMENT_ADJUSTMENT_TRANSACTION_TYPE)
            .subType(Constants.TOTAL_COMMITMENT_SUBTYPE)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(3.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(null)
            .cashImpact(4.0)
            .build();
    Transaction capc =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type("CAPC")
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .build();
    Transaction capd =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type("CAPD")
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 3.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));
    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, commitmentAdjustment, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);

    expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 4.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));
    actual = INSTANCE.getBalanceAffects(filterRange, capc, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);

    expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 4.0));
    actual = INSTANCE.getBalanceAffects(filterRange, capd, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffectsFor_COMMITMENT_ADJUSTMENT_OTHER_COMMITMENT() {
    LocalDate date = LocalDate.of(2023, 9, 15);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction transaction =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(Constants.COMMITMENT_ADJUSTMENT_TRANSACTION_TYPE)
            .subType(Constants.OTHER_COMMITMENT_SUBTYPE)
            .settleDate(date)
            .navImpact(1.0)
            .recallableImpact(2.0)
            .totalCommitmentImpact(null)
            .unfundedCommitmentImpact(3.0)
            .fundedCommitmentImpact(-3.0)
            .cashImpact(4.0)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, date, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, date, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, date, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, date, 2.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, date, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, date, -3.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, date, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, date, 0.0));

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, transaction, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffect_watchlist_dontIncludeNonWatchListNav() {
    LocalDate date = END_DATE.minusDays(1);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction filtered =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(Constants.NAV_TRANSACTION_TYPE)
            .subType("NAV")
            .settleDate(END_DATE)
            .navImpact(1.0)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, END_DATE, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, END_DATE, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, END_DATE, 0.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, END_DATE, 0.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, END_DATE, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, END_DATE, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, END_DATE, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, END_DATE, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, END_DATE, 0.0));

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, filtered, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }

  @Test
  public void getBalanceAffect_watchlist_includeWatchlistTransaction() {
    LocalDate date = END_DATE.minusDays(1);
    LocalDate subscriptionStartDate = date;
    LocalDateRange filterRange = LocalDateRanges.create(subscriptionStartDate, LocalDate.MAX);
    Transaction filtered =
        Transaction.builder()
            .account(ACCOUNT)
            .security(SECURITY)
            .type(Constants.NAV_TRANSACTION_TYPE)
            .subType("WATCHLIST")
            .settleDate(END_DATE)
            .navImpact(1.0)
            .build();

    List<BalanceAffect> expected =
        List.of(
            new BalanceAffect(BalanceType.REPORTED_ENDING_NAV, END_DATE, 0.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV, END_DATE, 1.0),
            new BalanceAffect(BalanceType.WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT, END_DATE, 1.0),
            new BalanceAffect(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION, END_DATE, 0.0),
            new BalanceAffect(BalanceType.REPORTED_TOTAL_COMMITMENT, END_DATE, 0.0),
            new BalanceAffect(BalanceType.FUNDED_COMMITMENT, END_DATE, 0.0),
            new BalanceAffect(BalanceType.CUM_CONTRIBUTION, END_DATE, 0.0),
            new BalanceAffect(BalanceType.GENERAL_ADJUSTMENT_CUM_CONTRIBUTION, END_DATE, 0.0),
            new BalanceAffect(BalanceType.CUM_DISTRIBUTION, END_DATE, 0.0));

    List<BalanceAffect> actual =
        INSTANCE.getBalanceAffects(filterRange, filtered, WATCHLIST_PERIOD, true);
    assertEquals(expected, actual);
  }
}
