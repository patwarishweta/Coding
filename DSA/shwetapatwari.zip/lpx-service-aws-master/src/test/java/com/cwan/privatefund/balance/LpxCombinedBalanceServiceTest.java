package com.cwan.privatefund.balance;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.client.tabular.BalanceType;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.privatefund.balance.model.LmcBalance;
import com.cwan.privatefund.calculated.CalculatedBalanceService;
import com.cwan.privatefund.calculated.model.CalculatedBalance;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;

class LpxCombinedBalanceServiceTest {

  @Mock private CalculatedBalanceService calculatedBalanceService;

  @Mock private LpxBalanceService balanceService;

  @InjectMocks private LpxCombinedBalanceService lpxCombinedBalanceService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testGetAccountBalances() {
    // Arrange
    Long accountId = 1L;
    LocalDate balanceDate = LocalDate.now();
    LocalDate knowledgeDate = LocalDate.now().minusDays(1);

    // Mocking CalculatedBalance
    CalculatedBalance mockCalculatedBalance = mock(CalculatedBalance.class);
    LmcBalance lmcBalanceFromCalculated = LmcBalance.builder().build(); // Populate as needed
    when(calculatedBalanceService.calculateBalances(accountId, balanceDate, knowledgeDate, false))
        .thenReturn(Flux.just(mockCalculatedBalance));
    Security security =
        Security.builder().securityId(1L).securityName("HelloWorld").cusip("ABC").build();
    Document document = Document.builder().id(1L).build();
    Account account = Account.builder().id(accountId).build();

    when(mockCalculatedBalance.getAccount()).thenReturn(account);
    when(mockCalculatedBalance.getSecurity()).thenReturn(security);

    // Mocking Document Balances
    Balance lmcBalanceFromDocument1 =
        Balance.builder()
            .account(account)
            .security(security)
            .document(document)
            .type(BalanceType.REPORTED_RECALLABLE_DISTRIBUTION.getCode())
            .amount(1000.0)
            .build();

    Balance lmcBalanceFromDocument2 =
        Balance.builder()
            .account(account)
            .security(security)
            .document(document)
            .type(BalanceType.REPORTED_ENDING_UNFUNDED_COMMITMENT.getCode())
            .amount(1000.0)
            .build();
    Flux<Balance> fluxBalance = Flux.just(lmcBalanceFromDocument1, lmcBalanceFromDocument2);
    when(balanceService.getAccountBalances(accountId, balanceDate, knowledgeDate))
        .thenReturn(fluxBalance);

    // Act
    Flux<LmcBalance> result =
        lpxCombinedBalanceService.getAccountBalances(accountId, balanceDate, knowledgeDate);

    // Collect results for assertion
    List<LmcBalance> resultList = result.collectList().block();

    // Assert
    assertNotNull(resultList);
    assertEquals(2, resultList.size()); // One from document and one from calculated
    assertNotNull(resultList); // Check if calculated balance is present
  }

  @Test
  void testGetAccountBalances_emptyFlux() {
    // Arrange
    Long accountId = 1L;
    LocalDate balanceDate = LocalDate.now();
    LocalDate knowledgeDate = LocalDate.now().minusDays(1);

    when(calculatedBalanceService.calculateBalances(accountId, balanceDate, knowledgeDate, false))
        .thenReturn(Flux.just());

    when(balanceService.getAccountBalances(accountId, balanceDate, knowledgeDate))
        .thenReturn(Flux.just());

    // Act
    Flux<LmcBalance> result =
        lpxCombinedBalanceService.getAccountBalances(accountId, balanceDate, knowledgeDate);

    // Collect results for assertion
    List<LmcBalance> resultList = result.collectList().block();

    // Assert
    assertNotNull(resultList);
    assertTrue(resultList.isEmpty()); // Should be empty
  }
}
