package com.cwan.privatefund.leadership.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.cwan.privatefund.AuthenticatedControllerTest;
import com.cwan.privatefund.leadership.service.LpxLeadershipManager;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.integration.leader.Context;
import org.springframework.integration.leader.event.OnGrantedEvent;
import org.springframework.integration.leader.event.OnRevokedEvent;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class LpxLeadershipControllerTest extends AuthenticatedControllerTest {

  private static final Duration TIME_OUT = Duration.ofSeconds(5);
  private static final String TEXT_PLAIN_UTF8 = "text/plain;charset=UTF-8";
  private static String MOCKED_HOST_NAME;
  private static final String MOCKED_ROLE = "lpx-service-leader-role";
  @Autowired private WebTestClient webClient;
  @MockBean private LpxLeadershipManager lpxLeadershipManager;
  @MockBean private Context leadershipContext;
  @Autowired private LpxLeadershipController lpxLeadershipController;
  private ListAppender<ILoggingEvent> listAppender;

  @BeforeAll
  static void beforeAll() {
    try {
      MOCKED_HOST_NAME = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException e) {
      throw new RuntimeException(e);
    }
  }

  @BeforeEach
  void beforeEach() {
    webClient = webClient.mutate().responseTimeout(TIME_OUT).build();
    var logger = (Logger) LoggerFactory.getLogger(LpxLeadershipController.class);
    listAppender = new ListAppender<>();
    listAppender.start();
    logger.addAppender(listAppender);
    mockSecurityContext();
  }

  @Test
  void getLeadershipStatus_HostIsNotLeader() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(null);
    webClient
        .get()
        .uri("/leader")
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(TEXT_PLAIN_UTF8)
        .expectBody(String.class)
        .isEqualTo("Host '" + MOCKED_HOST_NAME + "' is not the leader for '" + MOCKED_ROLE + "'.");
  }

  @Test
  void getLeadershipStatus_HostIsLeader() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(leadershipContext);
    webClient
        .get()
        .uri("/leader")
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(TEXT_PLAIN_UTF8)
        .expectBody(String.class)
        .isEqualTo("Host '" + MOCKED_HOST_NAME + "' is the leader for '" + MOCKED_ROLE + "'.");
  }

  @Test
  void relinquishLeadership_HostIsNotLeader() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(null);
    webClient
        .put()
        .uri("/leader")
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentType(TEXT_PLAIN_UTF8)
        .expectBody(String.class)
        .isEqualTo("Host '" + MOCKED_HOST_NAME + "' is not a leader. Can't relinquish leadership.");
  }

  @Test
  void relinquishLeadership_HostIsLeader() {
    when(lpxLeadershipManager.getLpxLeadershipContext()).thenReturn(leadershipContext);
    webClient
        .put()
        .uri("/leader")
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(TEXT_PLAIN_UTF8)
        .expectBody(String.class)
        .isEqualTo("Leadership for '" + MOCKED_HOST_NAME + "' has been relinquished.");
  }

  @Test
  void handleLeadershipGranted_logsCorrectlyAndSetsContext() {
    var mockEvent = new OnGrantedEvent(new Object(), leadershipContext, MOCKED_ROLE);
    lpxLeadershipController.handleLeadershipGranted(mockEvent);
    var lastLogEntry = listAppender.list.get(listAppender.list.size() - 1);
    assertEquals(Level.INFO, lastLogEntry.getLevel());
    assertTrue(lastLogEntry.getFormattedMessage().contains("Leadership granted for role"));
    assertTrue(lastLogEntry.getFormattedMessage().contains(MOCKED_ROLE));
    assertTrue(lastLogEntry.getFormattedMessage().contains(MOCKED_HOST_NAME));
    verify(lpxLeadershipManager).setLpxLeadershipContext(leadershipContext);
  }

  @Test
  void handleLeadershipRevoked_logsCorrectlyAndResetsContext() {
    var mockEvent = new OnRevokedEvent(new Object(), leadershipContext, MOCKED_ROLE);
    lpxLeadershipController.handleLeadershipRevoked(mockEvent);
    var lastLogEntry = listAppender.list.get(listAppender.list.size() - 1);
    assertEquals(Level.INFO, lastLogEntry.getLevel());
    assertTrue(lastLogEntry.getFormattedMessage().contains("Leadership for role"));
    assertTrue(lastLogEntry.getFormattedMessage().contains(MOCKED_ROLE));
    assertTrue(lastLogEntry.getFormattedMessage().contains(MOCKED_HOST_NAME));
    verify(lpxLeadershipManager).setLpxLeadershipContext(null);
  }
}
