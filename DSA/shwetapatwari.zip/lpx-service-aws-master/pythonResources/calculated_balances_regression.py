import requests
import json
import time

def get_response(url, headers):
    start_time = time.time()
    response = requests.get(url, headers=headers)
    end_time = time.time()
    print("response code: ", response.status_code)

    print(f"GET request to {url} took {end_time - start_time:.3f} seconds")
    if(response.status_code != 200):
        print(f"Error fetching data: {response.status_code}, for request url: {url}")
        return None
    return response.json()

def find_matching_balance(balances, security_id):
    for balance in balances:
        if balance.get('security', {}).get('securityId') == security_id:
            return balance
    return None

def compare_balances(beta_balances, local_balances):
    differences = []
    for beta_balance in beta_balances:
        security_id = beta_balance.get('security', {}).get('securityId')
        if security_id is not None:  # Ensure securityId is present
            local_balance = find_matching_balance(local_balances, security_id)
            if local_balance:
                for key, beta_value in beta_balance.items():
                    local_value = local_balance.get(key)
                    if key == 'security' and isinstance(beta_value, dict) and isinstance(local_value, dict):
                        # Compare nested 'security' dictionaries
                        for nested_key in beta_value:
                            if beta_value[nested_key] != local_value.get(nested_key):
                                differences.append({
                                    'securityId': security_id,
                                    'field': f"security.{nested_key}",
                                    'beta': beta_value[nested_key],
                                    'local': local_value.get(nested_key)
                                })
                    elif key != 'security' and beta_value != local_value:
                        differences.append({
                            'securityId': security_id,
                            'field': key,
                            'beta': beta_value,
                            'local': local_value
                        })
            else:
                print(f"No matching balance found in localhost for securityId: {security_id}")
        else:
            print(f"Missing securityId in beta balance: {beta_balance}")
    return differences

def diff_results(accountIds, asOfDate, knowledgeDate, betaToken):
    betaDomain = "https://lpx-service.uswe2.beta.aws.cwan.io/lpx-service/"
    localhostDomain = "http://localhost:8084/lpx-service/"

    betaHeaders = {'Authorization': f'Bearer {betaToken}'}

    for accountId in accountIds:
        betaUrl = f"{betaDomain}v1/calculated/balance/account/accounting?accountId={accountId}&asOfDate={asOfDate}&knowledgeDate={knowledgeDate}"
        localhostUrl = f"{localhostDomain}v1/calculated/balance/account/accounting?accountId={accountId}&asOfDate={asOfDate}&knowledgeDate={knowledgeDate}"

        print(f"\nRequesting data for accountId: {accountId}")

        betaResponse = get_response(betaUrl, betaHeaders)
        localhostResponse = get_response(localhostUrl, betaHeaders)
        print(betaResponse)
        print(localhostResponse)

        if betaResponse and localhostResponse:
            diff_count = 0
            differences = compare_balances(betaResponse, localhostResponse)
            for diff in differences:
                diff_count += 1
                print(f"Difference found for securityId: {diff['securityId']} in field '{diff['field']}'")
                print(f"Beta value: {diff['beta']}")
                print(f"Localhost value: {diff['local']}")

            if diff_count > 0:
                print(f"\nDifferences found for accountId: {accountId}: {diff_count}\n")
            else:
                print(f"No differences found for accountId: {accountId}")
        else:
            print(f"Error fetching data for accountId: {accountId}")

# Prompt user for input
accountIds = input("Enter a comma-separated list of accountIds: ").split(",")
accountIds = [int(accountId.strip()) for accountId in accountIds]

asOfDate = input("Enter the begin date (YYYY-MM-DD): ")
knowledgeDate = input("Enter the end date (YYYY-MM-DD): ")

betaToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsaWIiOiJBdXRoVG9rZW5DcmVhdG9yIiwiaGVpbWRhbGwiOlsxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNiwzNywzOCwzOSw0MCw0NCw0NSw0OCw1Myw1NCw1NSw1Niw1Nyw1OCw1OSw2MCw2MSw2Miw2Myw2NCw2Niw2Nyw2OCw2OSw3MCw3MSw3Miw3Myw3NCw3NSw3Niw3Nyw3OCw3OSw4MCw4MSw4Miw4Myw4NCw4NSw4Niw4Nyw4OCw4OSw5MCw5MSw5Miw5Myw5NCw5NSw5Niw5Nyw5OCw5OSwxMDAsMTAxLDEwMiwxMDMsMTA0LDEwNSwxMDYsMTA3LDEwOCwxMDksMTEwLDExMSwxMTIsMTEzLDExNCwxMTUsMTE2LDExNywxMTgsMTE5LDEyMCwxMjEsMTIyLDEyMywxMjQsMTI1LDEyNiwxMjcsMTI4LDEyOSwxMzAsMTMxLDEzMiwxMzMsMTM0LDEzNSwxMzYsMTM3LDEzOCwxMzksMTQwLDE0MSwxNDIsMTQzLDE0NCwxNDUsMTQ2LDE0NywxNDgsMTQ5LDE1MCwxNTEsMTUyLDE1MywxNTQsMTU1LDE1NiwxNTcsMTU4LDE1OSwxNjAsMTYxLDE2MiwxNjMsMTY0LDE2NSwxNjYsMTY3LDE2OCwxNjksMTcwLDE3MSwxNzIsMTczLDE3NCwxNzUsMTc2LDE3NywxNzgsMTc5LDE4MCwxODEsMTgyLDE4MywxODQsMTg1LDE4NiwxODcsMTg4LDE4OSwxOTAsMTkxLDE5MiwxOTMsMTk0LDE5NSwxOTYsMTk3LDE5OCwxOTksMjAwLDIwMSwyMDIsMjAzLDIwNCwyMDUsMjA2LDIwNywyMDgsMjA5LDIxMCwyMTEsMjEyLDIxMywyMTQsMjE1LDIxNiwyMTcsMjE4LDIxOSwyMjAsMjIxLDIyMiwyMjMsMjI0LDIyNSwyMjYsMjI3LDIyOCwyMjksMjMwLDIzMSwyMzIsMjMzLDIzNCwyMzUsMjM2LDIzNywyMzgsMjM5LDI0MCwyNDEsMjQyLDI0MywyNDQsMjQ1LDI0NiwyNDcsMjQ4LDI0OSwyNTAsMjUxLDI1MiwyNTMsMjU0LDI1NSwyNTYsMjU3LDI1OCwyNTksMjYwLDI2MSwyNjIsMjYzLDI2NCwyNjUsMjY2LDI2NywyNjgsMjY5LDI3MCwyNzEsMjcyLDI3MywyNzQsMjc1LDI3NiwyNzcsMjc4LDI3OSwyODAsMjgxLDI4MiwyODMsMjg0LDI4NSwyODYsMjg3LDI4OCwyODksMjkwLDI5MSwyOTIsMjkzLDI5NCwyOTUsMjk2LDI5NywyOTgsMjk5LDMwMCwzMDEsMzAyLDMwMywzMDQsMzA1LDMwNiwzMDcsMzEwLDMxMSwzMTIsMzEzLDMxNCwzMTUsMzE2LDMxNywzMTgsMzE5LDMyMCwzMjEsMzIyLDMyMywzMjQsMzI1LDMyNiwzMjcsMzI4LDMyOSwzMzAsMzMxLDMzMiwzMzMsMzM0LDMzNSwzMzYsMzM3LDMzOCwzMzksMzQwLDM0MSwzNDIsMzQzLDM0NCwzNDUsMzQ2LDM0NywzNDgsMzQ5LDM1MCwzNTEsMzUyLDM1MywzNTQsMzU1LDM1NiwzNTcsMzU4LDM1OSwzNjAsMzYxLDM2MiwzNjMsMzY0LDM2NSwzNjYsMzY3LDM2OCwzNjksMzcwLDM3MSwzNzIsMzczLDM3NCwzNzUsMzc2LDM3NywzNzgsMzc5LDM4MCwzODEsMzgyLDM4MywzODQsMzg1LDM4NiwzODcsMzg4LDM4OSwzOTAsMzkxLDM5NywzOTgsMzk5LDQwMCw0MDEsNDAyLDQwMyw0MDQsNDA1LDQwNiw0MDcsNDA4LDQwOSw0MTAsNDExLDQxMiw0MTMsNDE0LDQxNSw0MTYsNDE3LDQxOCw0MTksNDIwLDQyMSw0MjIsNDIzLDQyNCw0MjUsNDI2LDQyNyw0MjgsNDI5LDQzMCw0MzEsNDMyLDQzMyw0MzQsNDM1LDQzNiw0MzcsNDM4LDQzOSw0NDAsNDQxLDQ0Miw0NDMsNDQ0LDQ0NSw0NDYsNDQ3LDQ0OCw0NDksNDUwLDQ1MSw0NTIsNDUzLDQ1NCw0NTUsNDU2LDQ1Nyw0NTgsNDU5LDQ2MCw0NjEsNDYyLDQ2Myw0NjQsNDY1LDQ2Niw0NjcsNDY4LDQ2OSw0NzAsNDcxLDQ3Miw0NzMsNDc0LDQ3NSw0NzYsNDc3LDQ3OCw0NzksNDgwLDQ4MSw0ODIsNDgzLDQ4NCw0ODUsNDg2LDQ4Nyw0ODgsNDg5LDQ5MCw0OTEsNDkyLDQ5Myw0OTQsNDk1LDQ5Niw0OTcsNDk4LDQ5OSw1MDAsNTAxLDUwMiw1MDMsNTA0LDUwNSw1MDYsNTA3LDUwOCw1MDksNTEwLDUxMSw1MTIsNTEzLDUxNCw1MTUsNTE2LDUxNyw1MTgsNTE5LDUyMCw1MjEsNTIyLDUyMyw1MjQsNTI1LDUyNiw1MjcsNTI4LDUyOSw1MzAsNTMxLDUzMiw1MzMsNTM0LDUzNSw1MzYsNTM3LDUzOCw1MzksNTQwLDU0MSw1NDIsNTQzLDU0NCw1NDUsNTQ2LDU0Nyw1NDgsNTQ5LDU1MCw1NTEsNTUyLDU1Myw1NTQsNTU1LDU1Niw1NTcsNTU4LDU1OSw1NjAsNTYxLDU2Miw1NjMsNTY0LDU2NSw1NjYsNTY3LDU2OCw1NjksNTcwLDU3MSw1NzIsNTczLDU3NCw1NzUsNTc2LDU3Nyw1NzgsNTc5LDU4MCw1ODEsNTgyLDU4Myw1ODQsNTg1LDU4Niw1ODcsNTg4LDU4OSw1OTAsNTkxLDU5Miw1OTMsNTk0LDU5NSw1OTYsNTk3LDU5OCw1OTksNjAwLDYwMSw2MDIsNjAzLDYwNCw2MDUsNjA2LDYwNyw2MDgsNjA5LDYxMCw2MTEsNjEyLDYxMyw2MTQsNjE1LDYxNiw2MTcsNjE4LDYxOSw2MjAsNjIxLDYyMiw2MjMsNjI0LDYyNSw2MjYsNjI3LDYyOCw2MjksNjMwLDYzMSw2MzIsNjMzLDYzNCw2MzUsNjM2LDYzNyw2MzgsNjM5LDY0MCw2NDEsNjQyLDY0Myw2NDQsNjQ1LDY0Niw2NDcsNjQ4LDY0OSw2NTAsNjUxLDY1Miw2NTMsNjU0LDY1NSw2NTYsNjU3LDY1OCw2NTksNjYwLDY2MSw2NjIsNjYzLDY2NCw2NjUsNjY2LDY2Nyw2NjgsNjY5LDY3MCw2NzEsNjcyLDY3Myw2NzQsNjc1LDY3Niw2NzcsNjc4LDY3OSw2ODAsNjgxLDY4Miw2ODMsNjg0LDY4NSw2ODYsNjg3LDY4OCw2ODksNjkwLDY5MSw2OTIsNjkzLDY5NCw2OTUsNjk2LDY5Nyw2OTgsNjk5LDcwMCw3MDEsNzAyLDcwM10sImlzcyI6IkF1dGhfV1MiLCJsaWJfdmVyc2lvbiI6IjEuNzciLCJleHAiOjE3MzEwNTE2OTAsInVzZXJJZCI6NTQ5MTEsImFtcHQiOlsyLDMsNCw2LDksMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjEsMjIsMjMsMjUsMjYsMjcsMjgsMzAsMzEsMzMsMzQsMzUsNTAsNTEsNTIsNTMsNTQsNTUsNTYsNTcsNTgsNTksNjAsNjEsNjUsNjYsNjcsNjgsNjksNzAsNzEsNzIsNzMsNzQsNzUsNzYsNzcsNzgsNzksODAsODEsODIsODMsODQsODUsODcsODgsODksOTAsOTEsOTIsOTQsOTUsOTYsOTcsOTgsOTksMTAwLDEwMSwxMDIsMTAzLDEwNCwxMDUsMTA2LDEwNywxMDgsMTA5LDExMCwxMTYsMTE3LDExOCwxMTksMTIwLDEyMSwxMjIsMTI0LDEyNSwxMjYsMTI3LDEyOCwxMjksMTMwLDEzMSwxMzIsMTMzLDEzNCwxMzUsMTM2LDEzNywxMzgsMTM5LDE0MCwxNDEsMTQyLDE0MywxNDQsMTQ1LDE0NiwxNDcsMTQ4LDE0OSwxNTAsMTUxLDE1MiwxNTMsMTU0LDE1NSwxNTYsMTU3LDE1OCwxNTksMTYwLDE2MSwxNjIsMTYzLDE2NCwxNjUsMTY2LDE2NywxNjgsMTcwLDE3MSwxNzIsMTczLDE3NCwxNzUsMTc2LDE3NywxNzgsMTc5LDE4MCwxODEsMTgyLDE4MywxODQsMTg1XX0.Te_SqVUt_-puLnswK4dUA730eSzsPc7zxCiH-TUEalo'

diff_results(accountIds, asOfDate, knowledgeDate, betaToken)
