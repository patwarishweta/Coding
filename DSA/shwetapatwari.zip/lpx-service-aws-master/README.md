# LPx Service

## Local Set-up

### AWS

Ensure the following environment variables are set:

```AWS_ACCESS_KEY_ID=test;AWS_SECRET_ACCESS_KEY=test;AWS_SESSION_TOKEN=

Active profiles: local,aws

```

In order to run pointing at a local pabor instance, see the following confluence page
to setup: https://cwan.atlassian.net/wiki/spaces/~kaltree/pages/413926224/LPx+Running+and+Debugging+Locally#tab-2002629dfa3b03e91e3eec896b269956

### Running Against Beta Db
Use the supplied LPxBetaApplication profile, this will run the application-local configuration.
In this is database is set to the beta database, if you wish to change it to another
environment find the details here:
https://cwan.atlassian.net/wiki/spaces/DEV/pages/903282752/LPx+Important+Links

After selecting an environment go to AWS SSO find the database credentials assigned cwan-database-beta
CwanDatabaseAccess|Access keys

Click the access keys and fill out the fill out the following variables:
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_SESSION_TOKEN

### Swagger URL

http://localhost:8084/lpx-service/webjars/swagger-ui/index.html
