import com.cwan.pbor.k1.K1ServiceImpl;
import com.cwan.pbor.k1.api.K1Service;

module pbor.k1.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;
  requires com.fasterxml.jackson.databind;
  requires com.fasterxml.jackson.datatype.jsr310;

  opens com.cwan.pbor.k1 to
      com.fasterxml.jackson.databind;

  exports com.cwan.pbor.k1.api;
  exports com.cwan.pbor.k1;

  provides K1Service with
      K1ServiceImpl;
}
