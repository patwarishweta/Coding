package com.cwan.pbor.k1;

import static java.util.stream.Collectors.toSet;

import com.cwan.pbor.k1.api.K1Service;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

@Service
@Slf4j
@NoArgsConstructor
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class K1ServiceImpl implements K1Service {

  private K1Repository k1Repository;

  @Transactional
  public Flux<K1Entity> addK1s(Set<K1Entity> newK1s) {

    if (newK1s.stream().anyMatch(k1 -> k1.getId() != null)) {
      String idError =
          "K1s with IDs "
              + newK1s.stream()
                  .filter(k1 -> k1.getId() != null)
                  .map(K1Entity::getId)
                  .collect(toSet())
              + " can't be added. ID should be null for inserts.";
      log.error(idError);
      throw new K1Exception(idError);
    }

    try {
      return createK1s(Flux.fromIterable(newK1s));
    } catch (RuntimeException e) {
      // Throw unchecked exception
      throw e;
    } catch (Exception e) {
      // Handle checked exception
      throw new K1Exception(
          "Error saving K1s:" + newK1s.stream().map(K1Entity::getId).collect(toSet()), e);
    }
  }

  @Override
  @Transactional
  public Flux<K1Entity> getCurrentK1s(Set<Long> documentIds) {
    String documentIdsString =
        documentIds.stream().sorted().map(String::valueOf).collect(Collectors.joining(","));

    try {
      return Flux.fromIterable(k1Repository.findCurrentK1s(documentIdsString));
    } catch (RuntimeException e) {
      // Throw unchecked exception
      throw e;
    } catch (Exception e) {
      // Handle checked exception
      throw new K1Exception("Error finding K1s with document ids " + documentIds, e);
    }
  }

  private Flux<K1Entity> createK1s(Flux<K1Entity> k1EntityFlux) {
    return k1EntityFlux.map(k1 -> k1Repository.saveAndFlush(k1));
  }
}
