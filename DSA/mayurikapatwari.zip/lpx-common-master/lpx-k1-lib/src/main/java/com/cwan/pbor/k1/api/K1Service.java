package com.cwan.pbor.k1.api;

import com.cwan.pbor.k1.K1Entity;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface K1Service {

  Flux<K1Entity> addK1s(Set<K1Entity> k1);

  Flux<K1Entity> getCurrentK1s(Set<Long> documentIds);
}
