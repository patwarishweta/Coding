package com.cwan.pbor.k1;

import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface K1Repository extends JpaRepository<K1Entity, Long> {

  @Query(
      value =
          """
            SELECT *
                FROM k1_form_data
                WHERE id IN (
                    SELECT MAX(id)
                    FROM k1_form_data
                    WHERE document_id IN (:documentIdsString )
                    GROUP BY document_id
                );
          """,
      nativeQuery = true)
  Collection<K1Entity> findCurrentK1s(String documentIdsString);
}
