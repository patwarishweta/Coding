package com.cwan.pbor.k1;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class K1Exception extends ResponseStatusException {

  @Serial private static final long serialVersionUID = 9184866158822963179L;

  public K1Exception(String msg, Throwable e) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, msg, e);
  }

  public K1Exception(String msg) {
    super(HttpStatus.BAD_REQUEST, msg);
  }
}
