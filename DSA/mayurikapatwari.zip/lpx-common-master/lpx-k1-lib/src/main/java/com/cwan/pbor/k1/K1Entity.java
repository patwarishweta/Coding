package com.cwan.pbor.k1;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.Hibernate;

@Entity
@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "k1_form_data", catalog = "pabor")
public class K1Entity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long documentId;

  private String content;

  // audit fields
  private String createdBy;
  private Boolean isCreatedByInternalUser;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;

  @Override
  public int hashCode() {
    return Objects.hash(
        id,
        documentId,
        content,
        createdBy,
        isCreatedByInternalUser,
        createdOn,
        modifiedBy,
        isModifiedByInternalUser,
        modifiedOn);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (K1Entity) o;
    return (id.equals(that.id)
        && documentId.equals(that.documentId)
        && content.equals(that.content)
        && createdBy.equals(that.createdBy)
        && isCreatedByInternalUser.equals(that.isCreatedByInternalUser)
        && createdOn.equals(that.createdOn)
        && modifiedBy.equals(that.modifiedBy)
        && isModifiedByInternalUser.equals(that.isModifiedByInternalUser)
        && modifiedOn.equals(that.modifiedOn));
  }
}
