package com.cwan.pbor.k1;

import static com.cwan.pbor.k1.TestUtil.getK1Entity;
import static com.cwan.pbor.k1.TestUtil.getK1EntityFromJson;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class K1ServiceImplTest {

  private static final Long K1_ID = 1L;
  @Mock private K1Repository mockK1Repository;
  private K1ServiceImpl k1ServiceImpl;

  @BeforeEach
  void before_each() {
    openMocks(this);
    k1ServiceImpl = new K1ServiceImpl(mockK1Repository);
    when(mockK1Repository.saveAndFlush(any(K1Entity.class))).thenReturn(getK1Entity(K1_ID));
  }

  @Test
  void should_add_k1_successfully() {
    K1Entity k1 = getK1EntityFromJson(null);

    when(mockK1Repository.saveAndFlush(any(K1Entity.class))).thenReturn(k1);

    assertEquals(List.of(k1), k1ServiceImpl.addK1s(Set.of(k1)).collectList().block());
  }

  @Test
  void should_add_k1_error_on_ids() {
    K1Entity k1WithId = getK1EntityFromJson(K1_ID);

    when(mockK1Repository.saveAndFlush(any(K1Entity.class))).thenReturn(k1WithId);

    assertThrows(K1Exception.class, () -> k1ServiceImpl.addK1s(Set.of(k1WithId)));
  }

  @Test
  void should_return_k1s() {
    K1Entity k1Entity1 = getK1Entity(1L);
    K1Entity k1Entity2 = getK1Entity(2L);

    when(mockK1Repository.findCurrentK1s("1,2")).thenReturn(Set.of(k1Entity1, k1Entity2));

    List<K1Entity> expectedResult = new ArrayList<>(List.of(k1Entity1, k1Entity2));
    expectedResult.sort(Comparator.comparing(K1Entity::getId));
    List<K1Entity> actualResult = k1ServiceImpl.getCurrentK1s(Set.of(1L, 2L)).collectList().block();
    actualResult.sort(Comparator.comparing(K1Entity::getId));

    assertEquals(expectedResult, actualResult);
  }
}
