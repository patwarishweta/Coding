package com.cwan.pbor.k1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.Month;
import lombok.SneakyThrows;

public class TestUtil {

  @SneakyThrows
  public static K1Entity getK1EntityFromJson(Long id) {
    var k1 =
        getObjectMapper()
            .readValue(Files.readString(Path.of("src/test/resources/k1.json")), K1Entity.class);
    k1.setId(id);
    return k1;
  }

  public static K1Entity getK1Entity(Long id) {
    return K1Entity.builder()
        .id(id)
        .documentId(5L)
        .content("test-content")
        .createdBy("pbor-k1-lib")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2022, Month.JULY, 1, 1, 1, 48))
        .modifiedBy("pbor-k1-lib")
        .modifiedOn(LocalDateTime.of(2022, Month.JULY, 1, 1, 1, 48))
        .isModifiedByInternalUser(true)
        .build();
  }

  public static ObjectMapper getObjectMapper() {
    return new ObjectMapper().registerModule(new JavaTimeModule());
  }
}
