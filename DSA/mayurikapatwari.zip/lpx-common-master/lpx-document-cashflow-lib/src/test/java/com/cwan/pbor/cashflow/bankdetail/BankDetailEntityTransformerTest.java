package com.cwan.pbor.cashflow.bankdetail;

import static com.cwan.pbor.cashflow.TestUtil.getBankDetail;
import static com.cwan.pbor.cashflow.TestUtil.getBankDetailEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BankDetailEntityTransformerTest {

  private static final Long BANK_DETAIL_ID = 1L;

  @Test
  void should_convert_BankDetail_to_BankDetailEntity() {
    var bankDetail = getBankDetail(BANK_DETAIL_ID);
    var transformer = new BankDetailEntityTransformer();
    var actual = transformer.apply(bankDetail);
    var expected = getBankDetailEntity(BANK_DETAIL_ID);
    assertEquals(expected, actual);
  }
}
