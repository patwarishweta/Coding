package com.cwan.pbor.cashflow.documentcashflow;

import static com.cwan.pbor.cashflow.TestUtil.getDocumentCashFlow;
import static com.cwan.pbor.cashflow.TestUtil.getDocumentCashFlowEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DocumentCashFlowTransformerTest {

  private DocumentCashFlowTransformer transformer;

  @BeforeEach
  void setUp() {
    transformer = new DocumentCashFlowTransformer();
  }

  @Test
  void test_converts_DocumentCashFlowEntity_to_DocumentCashFlow() {
    var cashFlowEntity = getDocumentCashFlowEntity(1L);
    var actual = transformer.apply(cashFlowEntity);
    var expected = getDocumentCashFlow(1L, "ALL");
    assertEquals(expected, actual);
  }

  @Test
  void test_converts_DocumentCashFlowEntity_with_null_bank_details() {
    var cashFlowEntity = getDocumentCashFlowEntity(2L);
    cashFlowEntity.setBeneficiaryBankDetail(null);
    cashFlowEntity.setCorrespondentBankDetail(null);
    cashFlowEntity.setIntermediaryBankDetail(null);
    var actual = transformer.apply(cashFlowEntity);
    assertNull(actual.getBeneficiaryBankDetail());
    assertNull(actual.getCorrespondentBankDetail());
    assertNull(actual.getIntermediaryBankDetail());
  }
}
