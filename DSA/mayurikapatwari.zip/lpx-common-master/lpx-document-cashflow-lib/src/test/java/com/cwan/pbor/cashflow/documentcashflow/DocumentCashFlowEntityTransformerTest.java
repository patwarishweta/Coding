package com.cwan.pbor.cashflow.documentcashflow;

import static com.cwan.pbor.cashflow.TestUtil.getDocumentCashFlow;
import static com.cwan.pbor.cashflow.TestUtil.getDocumentCashFlowEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class DocumentCashFlowEntityTransformerTest {

  private static final Long DCF_ID = 1L;

  @Test
  void test_converts_DocumentCashFlow_to_DocumentCashFlowEntity() {
    var cashFlow = getDocumentCashFlow(DCF_ID, "ALL");
    var transformer = new DocumentCashFlowEntityTransformer();
    var actual = transformer.apply(cashFlow);
    var expected = getDocumentCashFlowEntity(DCF_ID);
    assertEquals(expected, actual);
  }

  @Test
  void test_converts_DocumentCashFlow_to_DocumentCashFlowEntity_with_BeneficiaryBankDetail() {
    var cashFlow = getDocumentCashFlow(DCF_ID, "BENEFICIARY");
    var transformer = new DocumentCashFlowEntityTransformer();
    var actual = transformer.apply(cashFlow);
    var expected = getDocumentCashFlowEntity(DCF_ID);
    assertEquals(expected, actual);
  }

  @Test
  void test_converts_DocumentCashFlow_to_DocumentCashFlowEntity_with_IntermediaryBankDetail() {
    var cashFlow = getDocumentCashFlow(DCF_ID, "INTERMEDIARY");
    var transformer = new DocumentCashFlowEntityTransformer();
    var actual = transformer.apply(cashFlow);
    var expected = getDocumentCashFlowEntity(DCF_ID);
    assertEquals(expected, actual);
  }

  @Test
  void test_converts_DocumentCashFlow_to_DocumentCashFlowEntity_with_CorrespondentBankDetail() {
    var cashFlow = getDocumentCashFlow(DCF_ID, "CORRESPONDENT");
    var transformer = new DocumentCashFlowEntityTransformer();
    var actual = transformer.apply(cashFlow);
    var expected = getDocumentCashFlowEntity(DCF_ID);
    assertEquals(expected, actual);
  }
}
