package com.cwan.pbor.cashflow.documentcashflow;

import static com.cwan.pbor.cashflow.TestUtil.getDocumentCashFlow;
import static com.cwan.pbor.cashflow.TestUtil.getDocumentCashFlowEntity;
import static com.cwan.pbor.cashflow.documentcashflow.Constants.CANCEL;
import static com.cwan.pbor.cashflow.documentcashflow.Constants.IS_CURRENT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.pbor.cashflow.bankdetail.BankDetailEntity;
import com.cwan.pbor.cashflow.bankdetail.BankDetailRepository;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.lang3.SerializationUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.ThrowingSupplier;
import org.mockito.Mockito;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class DocumentCashFlowServiceTest {

  private final DocumentCashFlowRepository mockDocumentCashflowRepository =
      Mockito.mock(DocumentCashFlowRepository.class);
  private final BankDetailRepository mockBankDetailRepository =
      Mockito.mock(BankDetailRepository.class);
  DocumentCashFlowEntityTransformer documentCashflowEntityTransformer;
  DocumentCashFlowTransformer documentCashFlowTransformer;
  private DocumentCashFlowService documentCashflowsService;
  private static final Long DOCUMENT_ID = 1L;
  private static final DocumentCashFlowEntity DOCUMENT_CASH_FLOW_ENTITY =
      getDocumentCashFlowEntity(DOCUMENT_ID);
  private static final Set<DocumentCashFlowEntity> DOCUMENT_CASH_FLOW_ENTITIES =
      Set.of(DOCUMENT_CASH_FLOW_ENTITY);
  private static final Set<Long> DOCUMENT_IDS = Set.of(DOCUMENT_ID);
  private static final DocumentCashFlow DOCUMENT_CASH_FLOW =
      getDocumentCashFlow(DOCUMENT_ID, "ALL");
  private static final Set<DocumentCashFlow> DOCUMENT_CASH_FLOW_SET = Set.of(DOCUMENT_CASH_FLOW);
  private static final List<DocumentCashFlowEntity> DOCUMENT_CASH_FLOW_ENTITY_LIST =
      List.of(DOCUMENT_CASH_FLOW_ENTITY);

  @BeforeEach
  void before_each() {
    when(mockDocumentCashflowRepository.insertDocumentCashFlow(
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(),
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(),
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
        .thenReturn(1);
    documentCashflowEntityTransformer = new DocumentCashFlowEntityTransformer();
    documentCashFlowTransformer = new DocumentCashFlowTransformer();
    documentCashflowsService =
        new DocumentCashFlowService(
            mockDocumentCashflowRepository,
            documentCashflowEntityTransformer,
            documentCashFlowTransformer,
            mockBankDetailRepository);
  }

  @Test
  void should_initiate_default_constructor() {
    Assertions.assertDoesNotThrow(
        (ThrowingSupplier<DocumentCashFlowService>) DocumentCashFlowService::new);
  }

  @Test
  void should_add_document_cashflow_successfully() {
    BankDetailEntity beneficiaryBankDetail = DOCUMENT_CASH_FLOW_ENTITY.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    BankDetailEntity correspondentBankDetail =
        DOCUMENT_CASH_FLOW_ENTITY.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    BankDetailEntity intermediaryBankDetail = DOCUMENT_CASH_FLOW_ENTITY.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    Set<DocumentCashFlow> documentCashFlows = Set.of(getDocumentCashFlow(null, "ALL"));
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(DOCUMENT_CASH_FLOW_ENTITY);
    when(mockBankDetailRepository.saveAndFlush(
            eq(DOCUMENT_CASH_FLOW_ENTITY.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(
            eq(DOCUMENT_CASH_FLOW_ENTITY.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(
            eq(DOCUMENT_CASH_FLOW_ENTITY.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    documentCashflowsService
        .addCashflow(documentCashFlows)
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_beneficiary_bank_detail() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    localEntity.setBeneficiaryBankDetail(null);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    // No call is expected for the beneficiaryBankDetail
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    documentCashFlow.setBeneficiaryBankDetail(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_beneficiary_bank_detail_name() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    var bankDetail = localEntity.getBeneficiaryBankDetail();
    bankDetail.setName(null);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    // No call is expected for the beneficiaryBankDetail with a null name
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    var documentCashFlowBankDetail = documentCashFlow.getBeneficiaryBankDetail();
    documentCashFlowBankDetail.setName(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_modified_on() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    localEntity.setModifiedOn(null);
    var beneficiaryBankDetail = localEntity.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    documentCashFlow.setModifiedOn(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_modified_on_and_version_not_one() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    localEntity.setModifiedOn(null);
    localEntity.setVersion(2);
    var beneficiaryBankDetail = localEntity.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    documentCashFlow.setModifiedOn(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_correspondent_bank_detail() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    localEntity.setCorrespondentBankDetail(null);
    var beneficiaryBankDetail = localEntity.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    documentCashFlow.setCorrespondentBankDetail(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_correspondent_bank_detail_name() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    var bankDetail = localEntity.getCorrespondentBankDetail();
    bankDetail.setName(null);
    var beneficiaryBankDetail = localEntity.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    var documentCashFlowBankDetail = documentCashFlow.getCorrespondentBankDetail();
    documentCashFlowBankDetail.setName(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_intermediary_bank_detail() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    localEntity.setIntermediaryBankDetail(null);
    var beneficiaryBankDetail = localEntity.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    documentCashFlow.setIntermediaryBankDetail(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_handle_null_intermediary_bank_detail_name() {
    var localEntity = SerializationUtils.clone(DOCUMENT_CASH_FLOW_ENTITY);
    var bankDetail = localEntity.getIntermediaryBankDetail();
    bankDetail.setName(null);
    var beneficiaryBankDetail = localEntity.getBeneficiaryBankDetail();
    beneficiaryBankDetail.setId(1L);
    var correspondentBankDetail = localEntity.getCorrespondentBankDetail();
    correspondentBankDetail.setId(2L);
    var intermediaryBankDetail = localEntity.getIntermediaryBankDetail();
    intermediaryBankDetail.setId(3L);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(localEntity);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getBeneficiaryBankDetail())))
        .thenReturn(beneficiaryBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getCorrespondentBankDetail())))
        .thenReturn(correspondentBankDetail);
    when(mockBankDetailRepository.saveAndFlush(eq(localEntity.getIntermediaryBankDetail())))
        .thenReturn(intermediaryBankDetail);
    var documentCashFlow = SerializationUtils.clone(getDocumentCashFlow(null, "ALL"));
    var documentCashFlowBankDetail = documentCashFlow.getIntermediaryBankDetail();
    documentCashFlowBankDetail.setName(null);
    documentCashflowsService
        .addCashflow(Collections.singleton(documentCashFlow))
        .subscribe(res -> assertEquals(DOCUMENT_CASH_FLOW_ENTITIES, res));
  }

  @Test
  void should_not_add_new_document_cashflow_if_id_is_given_and_action_not_create() {
    when(mockDocumentCashflowRepository.findByIdAndVersion(eq(1L), any()))
        .thenReturn(Optional.of(DOCUMENT_CASH_FLOW_ENTITY));
    StepVerifier.create(documentCashflowsService.addCashflow(Set.of(DOCUMENT_CASH_FLOW)))
        .verifyError();
  }

  @Test
  void should_successfully_get_document_cashflow_by_document_cashflow_ids() {
    when(mockDocumentCashflowRepository.findAllByIdInAndIsCurrentTrue(eq(DOCUMENT_IDS)))
        .thenReturn(DOCUMENT_CASH_FLOW_ENTITY_LIST);
    var actualResponse =
        documentCashflowsService.getCashflowByIds(DOCUMENT_IDS).collect(Collectors.toSet()).block();
    assertEquals(DOCUMENT_CASH_FLOW_SET, actualResponse);
  }

  @Test
  void should_successfully_get_document_cashflow_by_document_id() {
    when(mockDocumentCashflowRepository.findByDocumentIdAndIsCurrentTrue(DOCUMENT_ID))
        .thenReturn(DOCUMENT_CASH_FLOW_ENTITY);
    var actualResponse = documentCashflowsService.findByDocumentId(DOCUMENT_ID).block();
    assertEquals(DOCUMENT_CASH_FLOW, actualResponse);
  }

  @Test
  void should_delete_document_cashflow_using_document_cashflow_Id() {
    when(mockDocumentCashflowRepository.findAllByIdInAndIsCurrentTrue(eq(DOCUMENT_IDS)))
        .thenReturn(DOCUMENT_CASH_FLOW_ENTITY_LIST);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(DOCUMENT_CASH_FLOW_ENTITY);
    var actualResponse =
        documentCashflowsService
            .deleteCashflowById(DOCUMENT_IDS)
            .collect(Collectors.toSet())
            .block();
    assertEquals(DOCUMENT_CASH_FLOW_SET, actualResponse);
  }

  @Test
  void
      should_update_Document_CashFlows_with_updated_documentCashFlowEntity_passed_in_updateCashflowInfo() {
    var limitedPartnerPercentOfFund = 0.8;
    var documentCashFlowEntity = getDocumentCashFlowEntity(DOCUMENT_ID);
    documentCashFlowEntity.setLimitedPartnerPercentOfFund(limitedPartnerPercentOfFund);
    var documentCashFlow = getDocumentCashFlow(DOCUMENT_ID, "ALL");
    documentCashFlow.setLimitedPartnerPercentOfFund(limitedPartnerPercentOfFund);
    when(mockDocumentCashflowRepository.saveAndFlush(any(DocumentCashFlowEntity.class)))
        .thenReturn(documentCashFlowEntity);
    when(mockDocumentCashflowRepository.findAllByIdInAndIsCurrentTrue(eq(DOCUMENT_IDS)))
        .thenReturn(DOCUMENT_CASH_FLOW_ENTITY_LIST);
    Set<DocumentCashFlow> expected = Set.of(documentCashFlow);
    var actualResponse =
        documentCashflowsService
            .updateCashflowInfo(DOCUMENT_IDS, expected)
            .collect(Collectors.toSet())
            .block();
    assertEquals(expected, actualResponse);
  }

  @Test
  void getCashflowByIds_should_convert_exception_to_document_cashflow_exception() {
    when(mockDocumentCashflowRepository.findAllByIdInAndIsCurrentTrue(any()))
        .thenThrow(new RuntimeException());
    StepVerifier.create(documentCashflowsService.getCashflowByIds(DOCUMENT_IDS))
        .verifyError(DocumentCashFlowException.class);
  }

  @Test
  void addCashflow_should_convert_exception_to_null_pointer_exception() {
    when(mockDocumentCashflowRepository.saveAndFlush(any())).thenThrow(new RuntimeException());
    StepVerifier.create(documentCashflowsService.addCashflow(DOCUMENT_CASH_FLOW_SET))
        .verifyError(NullPointerException.class);
  }

  @Test
  void deleteCashflowById_should_convert_exception_to_document_cashflow_exception() {
    when(mockDocumentCashflowRepository.findAllByIdInAndIsCurrentTrue(any()))
        .thenThrow(new RuntimeException());
    StepVerifier.create(documentCashflowsService.deleteCashflowById(DOCUMENT_IDS))
        .verifyError(DocumentCashFlowException.class);
  }

  @Test
  void findAllByDocumentId_should_convert_exception_to_document_cashflow_exception() {
    when(mockDocumentCashflowRepository.findByDocumentIdAndIsCurrentTrue(anyLong()))
        .thenThrow(new RuntimeException());
    StepVerifier.create(documentCashflowsService.findByDocumentId(DOCUMENT_ID))
        .verifyError(DocumentCashFlowException.class);
  }

  @Test
  void getCashflowsByDocumentId_shouldReturnDocumentCashFlows() {
    Long documentId = 1L;
    List<DocumentCashFlowEntity> documentCashFlows =
        Arrays.asList(
            DocumentCashFlowEntity.builder().build(), DocumentCashFlowEntity.builder().build());
    when(mockDocumentCashflowRepository.findAllByDocumentIdAndIsCurrentAndActionNot(
            eq(documentId), eq(IS_CURRENT), eq(CANCEL)))
        .thenReturn(documentCashFlows);
    Flux<DocumentCashFlow> result = documentCashflowsService.getCashflowsByDocumentId(documentId);
    StepVerifier.create(result).expectNextCount(2).verifyComplete();
  }
}
