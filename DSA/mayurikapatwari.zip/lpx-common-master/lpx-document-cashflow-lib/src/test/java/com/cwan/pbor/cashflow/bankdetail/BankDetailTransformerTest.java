package com.cwan.pbor.cashflow.bankdetail;

import static com.cwan.pbor.cashflow.TestUtil.getBankDetail;
import static com.cwan.pbor.cashflow.TestUtil.getBankDetailEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BankDetailTransformerTest {

  private static final Long BANK_DETAIL_ID = 1L;

  @Test
  void should_convert_BankDetail_to_BankDetailEntity() {
    var bankDetailEntity = getBankDetailEntity(BANK_DETAIL_ID);
    var transformer = new BankDetailTransformer();
    var actual = transformer.apply(bankDetailEntity);
    var expected = getBankDetail(BANK_DETAIL_ID);
    assertEquals(expected, actual);
  }
}
