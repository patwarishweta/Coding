package com.cwan.pbor.cashflow.documentcashflow;

import org.hibernate.Hibernate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CashFlowKeyTest {

  @Test
  void testHashCode() {
    var cashFlowKey1 = CashFlowKey.builder().id(1L).version(1).build();
    var cashFlowKey2 = CashFlowKey.builder().id(1L).version(1).build();
    Assertions.assertEquals(cashFlowKey1.hashCode(), cashFlowKey2.hashCode());
  }

  @Test
  void testEqualsSameInstance() {
    var cashFlowKey = CashFlowKey.builder().id(1L).version(1).build();
    Assertions.assertEquals(cashFlowKey, cashFlowKey);
  }

  @Test
  void testEqualsWithNull() {
    var cashFlowKey = CashFlowKey.builder().id(1L).version(1).build();
    Assertions.assertNotEquals(null, cashFlowKey);
  }

  @Test
  void testEqualsWithProxiedInstance() {
    var cashFlowKey = CashFlowKey.builder().id(1L).version(1).build();
    var cashFlowKeyProxied = Hibernate.unproxy(cashFlowKey);
    Assertions.assertEquals(cashFlowKey, cashFlowKeyProxied);
  }

  @Test
  void testEqualsWithDifferentVersion() {
    var cashFlowKey1 = CashFlowKey.builder().id(1L).version(1).build();
    var cashFlowKey2 = CashFlowKey.builder().id(1L).version(2).build();
    Assertions.assertNotEquals(cashFlowKey1, cashFlowKey2);
  }

  @Test
  void testEqualsWithDifferentId() {
    var cashFlowKey1 = CashFlowKey.builder().id(1L).version(1).build();
    var cashFlowKey2 = CashFlowKey.builder().id(2L).version(1).build();
    Assertions.assertNotEquals(cashFlowKey1, cashFlowKey2);
  }

  @Test
  void testEqualsWithSameVersionAndId() {
    var cashFlowKey1 = CashFlowKey.builder().id(1L).version(1).build();
    var cashFlowKey2 = CashFlowKey.builder().id(1L).version(1).build();
    Assertions.assertEquals(cashFlowKey1, cashFlowKey2);
  }
}
