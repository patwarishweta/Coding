package com.cwan.pbor.cashflow.bankdetail;

import static com.cwan.pbor.cashflow.TestUtil.getBankDetail;
import static com.cwan.pbor.cashflow.TestUtil.getBankDetailEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import com.cwan.lpx.domain.BankDetail;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class BankDetailServiceTest {

  private final BankDetailRepository mockBankDetailRepository =
      Mockito.mock(BankDetailRepository.class);
  private final BankDetailTransformer bankDetailTransformer =
      Mockito.mock(BankDetailTransformer.class);
  private final BankDetailEntityTransformer bankDetailEntityTransformer =
      Mockito.mock(BankDetailEntityTransformer.class);
  private BankDetailService bankDetailService;
  private static final Long BANK_DETAIL_ID = 1L;
  private static final BankDetailEntity BANK_DETAIL_ENTITY = getBankDetailEntity(BANK_DETAIL_ID);
  private static final Set<BankDetailEntity> BANK_DETAIL_ENTITIES = Set.of(BANK_DETAIL_ENTITY);
  private static final Set<Long> BANK_DETAIL_IDS = Set.of(BANK_DETAIL_ID);
  private static final BankDetail BANK_DETAIL = getBankDetail(BANK_DETAIL_ID);
  private static final Set<BankDetail> BANK_DETAIL_SET = Set.of(BANK_DETAIL);
  private static final List<BankDetailEntity> BANK_DETAIL_ENTITY_LIST = List.of(BANK_DETAIL_ENTITY);

  @BeforeEach
  void before_each() {
    Mockito.when(bankDetailTransformer.apply(eq(BANK_DETAIL_ENTITY))).thenReturn(BANK_DETAIL);
    Mockito.when(bankDetailEntityTransformer.apply(eq(BANK_DETAIL))).thenReturn(BANK_DETAIL_ENTITY);
    bankDetailService =
        new BankDetailService(
            mockBankDetailRepository, bankDetailEntityTransformer, bankDetailTransformer);
  }

  @Test
  void should_add_bank_detail_successfully() {
    Set<BankDetail> bankDetails = Set.of(getBankDetail(null));
    Mockito.when(mockBankDetailRepository.saveAndFlush(any(BankDetailEntity.class)))
        .thenReturn(BANK_DETAIL_ENTITY);
    bankDetailService
        .addBankDetail(bankDetails)
        .subscribe(res -> assertEquals(BANK_DETAIL_ENTITIES, res));
  }

  @Test
  void should_not_add_bank_detail_if_id_is_given() {
    StepVerifier.create(bankDetailService.addBankDetail(Set.of(BANK_DETAIL)))
        .expectNextCount(0)
        .expectComplete()
        .verify();
  }

  @Test
  void should_successfully_get_bank_detail_by_bank_detail_ids() {
    Mockito.when(mockBankDetailRepository.findAllById(eq(BANK_DETAIL_IDS)))
        .thenReturn(BANK_DETAIL_ENTITY_LIST);
    var actualResponse =
        bankDetailService.getBankDetailByIds(BANK_DETAIL_IDS).collect(Collectors.toSet()).block();
    assertEquals(BANK_DETAIL_SET, actualResponse);
  }

  @Test
  void should_delete_bank_detail_using_bank_detail_Id() {
    Mockito.when(mockBankDetailRepository.findAllById(eq(BANK_DETAIL_IDS)))
        .thenReturn(BANK_DETAIL_ENTITY_LIST);
    Mockito.when(mockBankDetailRepository.saveAndFlush(any(BankDetailEntity.class)))
        .thenReturn(BANK_DETAIL_ENTITY);
    var actualResponse =
        bankDetailService.deleteBankDetailById(BANK_DETAIL_IDS).collect(Collectors.toSet()).block();
    assertEquals(BANK_DETAIL_SET, actualResponse);
  }

  @Test
  void should_update_Bank_Detail_with_updated_bankDetailEntity_passed_in_updateBankInfo() {
    var accountName = "New Account Name";
    var bankDetailEntity = getBankDetailEntity(BANK_DETAIL_ID);
    bankDetailEntity.setAccountName(accountName);
    var bankDetail = getBankDetail(BANK_DETAIL_ID);
    bankDetail.setAccountName(accountName);
    Mockito.when(bankDetailTransformer.apply(eq(bankDetailEntity))).thenReturn(bankDetail);
    Mockito.when(bankDetailEntityTransformer.apply(eq(bankDetail))).thenReturn(bankDetailEntity);
    Mockito.when(mockBankDetailRepository.saveAndFlush(any(BankDetailEntity.class)))
        .thenReturn(bankDetailEntity);
    Mockito.when(mockBankDetailRepository.findAllById(eq(BANK_DETAIL_IDS)))
        .thenReturn(BANK_DETAIL_ENTITY_LIST);
    Set<BankDetail> expected = Set.of(bankDetail);
    var actualResponse =
        bankDetailService
            .updateBankInfo(BANK_DETAIL_IDS, expected)
            .collect(Collectors.toSet())
            .block();
    assertEquals(expected, actualResponse);
  }

  @Test
  void should_convert_to_bank_detail_exception() {
    Mockito.when(mockBankDetailRepository.findAllById(any())).thenThrow(new RuntimeException());
    Assertions.assertThrows(
        BankDetailException.class, () -> bankDetailService.getBankDetailByIds(BANK_DETAIL_IDS));
  }
}
