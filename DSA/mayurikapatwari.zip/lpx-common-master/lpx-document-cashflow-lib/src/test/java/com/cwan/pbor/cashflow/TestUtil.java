package com.cwan.pbor.cashflow;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.BankDetail;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.cashflow.bankdetail.BankDetailEntity;
import com.cwan.pbor.cashflow.documentcashflow.DocumentCashFlowEntity;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestUtil {

  public static DocumentCashFlowEntity getDocumentCashFlowEntity(Long id) {
    return DocumentCashFlowEntity.builder()
        .id(id)
        .accountId(2L)
        .securityId(4L)
        .documentId(15203L)
        .version(1)
        .documentName("Document name")
        .limitedPartnerId("489419121")
        .limitedPartnerPercentOfFund(1.2D)
        .limitedPartnerPercentOfNav(0.57D)
        .netAmount(198198549D)
        .totalContribution(9.7D)
        .beneficiaryBankDetail(
            BankDetailEntity.builder().id(74235L).name("beneficiaryBankDetail").build())
        .intermediaryBankDetail(
            BankDetailEntity.builder().id(548L).name("intermediaryBankDetail").build())
        .correspondentBankDetail(
            BankDetailEntity.builder().id(659L).name("correspondentBankDetail").build())
        .totalRecallableDistribution(2.7D)
        .totalNonRecallableDistribution(7.0D)
        .recallableDistributionItd(0D)
        .returnOfCapitalDistributionItd(6.2D)
        .currency("USD")
        .fxCurrency("INR")
        .ffcName("The Investment Bank")
        .ffcNumber("1561961")
        .isCurrent(true)
        .action("create")
        .knowledgeStartDate(null)
        .knowledgeEndDate(LocalDateTime.of(2022, Month.JUNE, 8, 2, 2, 48))
        .createdBy("document-cashflow-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("document-cashflow-lib")
        .build();
  }

  public static DocumentCashFlow getDocumentCashFlow(Long id, String bankType) {
    log.info("getDocumentCashFlow");
    return DocumentCashFlow.builder()
        .id(id)
        .document(
            Document.builder()
                .id(15203L)
                .account(Account.builder().id(2L).build())
                .security(Security.builder().securityId(4L).build())
                .fileName("Document name")
                .build())
        .version(1)
        .limitedPartnerId("489419121")
        .limitedPartnerPercentOfFund(1.2D)
        .limitedPartnerPercentOfNAV(0.57D)
        .netAmount(198198549D)
        .totalContribution(9.7D)
        .beneficiaryBankDetail(
            (Objects.equals(bankType, "BENEFICIARY")) || (Objects.equals(bankType, "ALL"))
                ? BankDetail.builder().id(74235L).name("beneficiaryBankDetail").build()
                : null)
        .intermediaryBankDetail(
            (Objects.equals(bankType, "INTERMEDIARY")) || (Objects.equals(bankType, "ALL"))
                ? BankDetail.builder().id(548L).name("intermediaryBankDetail").build()
                : null)
        .correspondentBankDetail(
            (Objects.equals(bankType, "CORRESPONDENT")) || (Objects.equals(bankType, "ALL"))
                ? BankDetail.builder().id(659L).name("correspondentBankDetail").build()
                : null)
        .totalRecallableDistribution(2.7D)
        .totalNonRecallableDistribution(7.0D)
        .recallableDistributionITD(0D)
        .returnOfCapitalDistributionITD(6.2D)
        .currency("USD")
        .fxCurrency("INR")
        .ffcName("The Investment Bank")
        .ffcNumber("1561961")
        .isCurrent(true)
        .action("create")
        .knowledgeStartDate(null)
        .knowledgeEndDate(LocalDateTime.of(2022, Month.JUNE, 8, 2, 2, 48))
        .createdBy("document-cashflow-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("document-cashflow-lib")
        .build();
  }

  public static BankDetailEntity getBankDetailEntity(Long id) {
    return BankDetailEntity.builder()
        .id(id)
        .name("Chase")
        .address("970 W Main St, Boise")
        .abaRoutingNumber("159494164515")
        .swiftOrChips("swift")
        .accountIBAN("GB14WXYZ20532325648977")
        .accountName("Avaition")
        .accountNumber("98765432")
        .accountAddress("1 Cherry Hill Dr, Boise")
        .reference("None")
        .createdBy("document-cashflow-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("document-cashflow-lib")
        .isModifiedByInternalUser(true)
        .build();
  }

  public static BankDetail getBankDetail(Long id) {
    return BankDetail.builder()
        .id(id)
        .name("Chase")
        .address("970 W Main St, Boise")
        .abaRoutingNumber("159494164515")
        .swiftOrChip("swift")
        .accountIBAN("GB14WXYZ20532325648977")
        .accountName("Avaition")
        .accountNumber("98765432")
        .accountAddress("1 Cherry Hill Dr, Boise")
        .reference("None")
        .createdBy("document-cashflow-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("document-cashflow-lib")
        .isModifiedByInternalUser(true)
        .build();
  }
}
