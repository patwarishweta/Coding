import com.cwan.pbor.cashflow.bankdetail.BankDetailService;
import com.cwan.pbor.cashflow.bankdetail.api.BankDetails;
import com.cwan.pbor.cashflow.documentcashflow.DocumentCashFlowService;
import com.cwan.pbor.cashflow.documentcashflow.api.DocumentCashflows;

module document.cashflow.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;
  requires org.apache.commons.lang3;

  exports com.cwan.pbor.cashflow.documentcashflow.api;
  exports com.cwan.pbor.cashflow.bankdetail.api;

  provides DocumentCashflows with
      DocumentCashFlowService;
  provides BankDetails with
      BankDetailService;
}
