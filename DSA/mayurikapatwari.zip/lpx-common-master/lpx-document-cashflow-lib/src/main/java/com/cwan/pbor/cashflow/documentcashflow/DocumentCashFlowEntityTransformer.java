package com.cwan.pbor.cashflow.documentcashflow;

import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.pbor.cashflow.bankdetail.BankDetailEntityTransformer;
import java.util.Objects;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class DocumentCashFlowEntityTransformer
    implements Function<DocumentCashFlow, DocumentCashFlowEntity> {

  @Override
  public DocumentCashFlowEntity apply(DocumentCashFlow documentCashFlow) {
    var bankDetailEntityTransformer = new BankDetailEntityTransformer();
    return DocumentCashFlowEntity.builder()
        .id(documentCashFlow.getId())
        .accountId(documentCashFlow.getDocument().getAccount().getId())
        .securityId(documentCashFlow.getDocument().getSecurity().getSecurityId())
        .version(documentCashFlow.getVersion())
        .documentId(
            Objects.nonNull(documentCashFlow.getDocument())
                ? documentCashFlow.getDocument().getId()
                : null)
        .documentName(
            Objects.nonNull(documentCashFlow.getDocument())
                ? documentCashFlow.getDocument().getFileName()
                : null)
        .limitedPartnerId(documentCashFlow.getLimitedPartnerId())
        .limitedPartnerPercentOfFund(documentCashFlow.getLimitedPartnerPercentOfFund())
        .limitedPartnerPercentOfNav(documentCashFlow.getLimitedPartnerPercentOfNAV())
        .netAmount(documentCashFlow.getNetAmount())
        .beneficiaryBankDetail(
            Objects.nonNull(documentCashFlow.getBeneficiaryBankDetail())
                ? bankDetailEntityTransformer.apply(documentCashFlow.getBeneficiaryBankDetail())
                : null)
        .correspondentBankDetail(
            Objects.nonNull(documentCashFlow.getCorrespondentBankDetail())
                ? bankDetailEntityTransformer.apply(documentCashFlow.getCorrespondentBankDetail())
                : null)
        .intermediaryBankDetail(
            Objects.nonNull(documentCashFlow.getIntermediaryBankDetail())
                ? bankDetailEntityTransformer.apply(documentCashFlow.getIntermediaryBankDetail())
                : null)
        .action(documentCashFlow.getAction())
        .totalContribution(documentCashFlow.getTotalContribution())
        .totalRecallableDistribution(documentCashFlow.getTotalRecallableDistribution())
        .totalNonRecallableDistribution(documentCashFlow.getTotalNonRecallableDistribution())
        .recallableDistributionItd(documentCashFlow.getRecallableDistributionITD())
        .returnOfCapitalDistributionItd(documentCashFlow.getReturnOfCapitalDistributionITD())
        .knowledgeEndDate(documentCashFlow.getKnowledgeEndDate())
        .knowledgeStartDate(documentCashFlow.getKnowledgeStartDate())
        .currency(documentCashFlow.getCurrency())
        .fxCurrency(documentCashFlow.getFxCurrency())
        .fxRate(documentCashFlow.getFxRate())
        .ffcName(documentCashFlow.getFfcName())
        .ffcNumber(documentCashFlow.getFfcNumber())
        .source(documentCashFlow.getSource())
        .isCurrent(documentCashFlow.getIsCurrent())
        .createdBy(documentCashFlow.getCreatedBy())
        .isCreatedByInternalUser(documentCashFlow.getIsCreatedByInternalUser())
        .isModifiedByInternalUser(documentCashFlow.getIsModifiedByInternalUser())
        .modifiedBy(documentCashFlow.getModifiedBy())
        .createdOn(documentCashFlow.getCreatedOn())
        .modifiedOn(documentCashFlow.getModifiedOn())
        .build();
  }
}
