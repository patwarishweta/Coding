package com.cwan.pbor.cashflow.bankdetail;

import static java.util.stream.Collectors.toMap;

import com.cwan.lpx.domain.BankDetail;
import com.cwan.pbor.cashflow.bankdetail.api.BankDetails;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class BankDetailService implements BankDetails {

  private final BankDetailRepository bankDetailRepository;
  private final BankDetailEntityTransformer bankDetailEntityTransformer;
  private final BankDetailTransformer bankDetailTransformer;

  public BankDetailService() {
    bankDetailRepository = null;
    bankDetailTransformer = null;
    bankDetailEntityTransformer = null;
  } // Empty constructor is required as dependency in module-info.java

  @Autowired
  BankDetailService(
      BankDetailRepository bankDetailRepository,
      BankDetailEntityTransformer bankDetailEntityTransformer,
      BankDetailTransformer bankDetailTransformer) {
    this.bankDetailRepository = bankDetailRepository;
    this.bankDetailEntityTransformer = bankDetailEntityTransformer;
    this.bankDetailTransformer = bankDetailTransformer;
  }

  @Override
  public Flux<BankDetail> addBankDetail(final Set<BankDetail> bankDetails) {
    bankDetails.stream()
        .filter(bd -> bd.getId() != null)
        .forEach(
            bal ->
                log.warn("Bank Detail with Id {} can't be added Id should be null.", bal.getId()));
    return Flux.fromIterable(bankDetails)
        .filter(bal -> bal.getId() == null)
        .filter(Objects::nonNull)
        .map(Objects.requireNonNull(bankDetailEntityTransformer))
        .map(this::saveBankDetail)
        .map(Objects.requireNonNull(bankDetailTransformer));
  }

  @Override
  @Transactional
  public Flux<BankDetail> getBankDetailByIds(final Set<Long> bankDetailIds) {
    try {
      Stream<BankDetail> bankDetails =
          Objects.requireNonNull(bankDetailRepository).findAllById(bankDetailIds).stream()
              .map(Objects.requireNonNull(bankDetailTransformer));
      return Flux.fromStream(bankDetails);
    } catch (Exception e) {
      throw new BankDetailException(
          HttpStatus.INTERNAL_SERVER_ERROR, "Unable to find Bank Details", e);
    }
  }

  @Override
  @Transactional
  public Flux<BankDetail> deleteBankDetailById(final Set<Long> bankDetailIds) {
    try {
      Flux<BankDetailEntity> bankDetails =
          findAllByIds(bankDetailIds).log("deleteByBankDetailId").map(bankDetail -> bankDetail);
      return saveBankDetails(bankDetails);
    } catch (Exception e) {
      throw new BankDetailException(
          HttpStatus.INTERNAL_SERVER_ERROR,
          String.format("Error while deleting Bank Details : %s", bankDetailIds),
          e);
    }
  }

  @Override
  @Transactional
  public Flux<BankDetail> updateBankInfo(Set<Long> ids, final Set<BankDetail> bankDetailEntitySet) {
    Map<Long, BankDetailEntity> bankDetailEntityMap =
        bankDetailEntitySet.stream()
            .collect(toMap(BankDetail::getId, Objects.requireNonNull(bankDetailEntityTransformer)));
    return findAllByIds(ids)
        .log("updateBankDetail")
        .filter(
            bankDetail -> {
              if (!bankDetailEntityMap.containsKey(bankDetail.getId())) {
                log.warn("Id should be provided to update Bank Detail: {}", bankDetail.getId());
              }
              return bankDetailEntityMap.containsKey(bankDetail.getId());
            })
        .map(bd -> bankDetailEntityMap.get(bd.getId()))
        .mapNotNull(this::saveBankDetail)
        .mapNotNull(Objects.requireNonNull(bankDetailTransformer));
  }

  private Flux<BankDetailEntity> findAllByIds(Set<Long> bankDetails) {
    return Flux.fromStream(
        Objects.requireNonNull(bankDetailRepository).findAllById(bankDetails).stream());
  }

  private BankDetailEntity saveBankDetail(BankDetailEntity bankDetailEntity) {
    return Objects.requireNonNull(bankDetailRepository).saveAndFlush(bankDetailEntity);
  }

  private Flux<BankDetail> saveBankDetails(Flux<BankDetailEntity> configs) {
    return configs
        .log("Save Bank Detail")
        .map(
            entity -> {
              log.info("Creating or updating Bank Detail Id: {}", entity.getId());
              return saveBankDetail(entity);
            })
        .doOnError(ex -> log.error("Unable to create or update bank details", ex))
        .map(Objects.requireNonNull(bankDetailTransformer));
  }
}
