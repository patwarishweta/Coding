package com.cwan.pbor.cashflow.documentcashflow;

import static com.cwan.pbor.cashflow.documentcashflow.Constants.CANCEL;
import static com.cwan.pbor.cashflow.documentcashflow.Constants.IS_CURRENT;
import static java.util.stream.Collectors.toMap;

import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.pbor.cashflow.bankdetail.BankDetailEntity;
import com.cwan.pbor.cashflow.bankdetail.BankDetailRepository;
import com.cwan.pbor.cashflow.documentcashflow.api.DocumentCashflows;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class DocumentCashFlowService implements DocumentCashflows {

  private DocumentCashFlowRepository documentCashflowRepository;
  private DocumentCashFlowEntityTransformer documentCashflowEntityTransformer;
  private DocumentCashFlowTransformer documentCashFlowTransformer;
  private BankDetailRepository bankDetailRepository;

  public DocumentCashFlowService() {}

  @Autowired
  DocumentCashFlowService(
      final DocumentCashFlowRepository documentCashflowRepository,
      final DocumentCashFlowEntityTransformer documentCashflowEntityTransformer,
      final DocumentCashFlowTransformer documentCashFlowTransformer,
      final BankDetailRepository bankDetailRepository) {
    this.documentCashflowRepository = documentCashflowRepository;
    this.documentCashflowEntityTransformer = documentCashflowEntityTransformer;
    this.documentCashFlowTransformer = documentCashFlowTransformer;
    this.bankDetailRepository = bankDetailRepository;
  }

  @Override
  public Flux<DocumentCashFlow> addCashflow(final Set<DocumentCashFlow> cashflows) {
    var cashFlowMap =
        cashflows.stream()
            .collect(
                Collectors.partitioningBy(
                    cashFlow ->
                        documentCashflowRepository
                            .findByIdAndVersion(cashFlow.getId(), cashFlow.getVersion())
                            .isPresent()));
    cashFlowMap
        .get(true)
        .forEach(
            cashFlow ->
                log.info(
                    "Document CashFlows with Id {} version {} can't be added.",
                    cashFlow.getId(),
                    cashFlow.getVersion()));
    var newCashFlows =
        cashFlowMap.get(false).stream()
            .map(documentCashflowEntityTransformer)
            .collect(Collectors.toSet());
    if (newCashFlows.isEmpty()) {
      return Flux.error(
          new DocumentCashFlowException(
              HttpStatus.BAD_REQUEST,
              "Document CashFlow Id for given "
                  + "values already exists. Please try updating existing CashFlow if required"));
    }
    try {
      return createDocumentCashFlows(Flux.fromIterable(newCashFlows));
    } catch (Exception e) {
      return Flux.error(
          new DocumentCashFlowException(
              HttpStatus.BAD_REQUEST,
              "Error saving DocumentCashFlow:"
                  + cashflows.stream().map(DocumentCashFlow::getId).collect(Collectors.toSet()),
              e));
    }
  }

  @Override
  @Transactional
  public Flux<DocumentCashFlow> getCashflowByIds(final Set<Long> cashflowIds) {
    try {
      Stream<DocumentCashFlow> cashflows =
          documentCashflowRepository.findAllByIdInAndIsCurrentTrue(cashflowIds).stream()
              .map(documentCashFlowTransformer);
      return Flux.fromStream(cashflows);
    } catch (Exception e) {
      return Flux.error(
          new DocumentCashFlowException(
              HttpStatus.INTERNAL_SERVER_ERROR, "Unable to find Document Cashflow", e));
    }
  }

  @Override
  @Transactional
  public Flux<DocumentCashFlow> deleteCashflowById(final Set<Long> cashflowIds) {
    try {
      Flux<DocumentCashFlowEntity> cashflows =
          findAllByIds(cashflowIds)
              .log("deleteByCashflowId")
              .map(
                  cashflow -> {
                    cashflow.setKnowledgeEndDate(LocalDateTime.now());
                    return cashflow;
                  });
      return saveCashflows(cashflows);
    } catch (Exception e) {
      return Flux.error(
          new DocumentCashFlowException(
              HttpStatus.INTERNAL_SERVER_ERROR,
              String.format("Error while deleting Cashflow : %s", cashflowIds),
              e));
    }
  }

  @Override
  @Transactional
  public Flux<DocumentCashFlow> updateCashflowInfo(
      Set<Long> ids, final Set<DocumentCashFlow> documentCashFlows) {
    var idToCashFlowMap =
        documentCashFlows.stream()
            .collect(toMap(DocumentCashFlow::getId, documentCashflowEntityTransformer));
    var requestedCashFlowIds = new HashSet<>(idToCashFlowMap.keySet());
    return findAllByIds(requestedCashFlowIds)
        .log("updateDocumentCashFlowInfo")
        .filter(documentCashFlow -> requestedCashFlowIds.remove(documentCashFlow.getId()))
        .mapNotNull(documentCashFlow -> idToCashFlowMap.get(documentCashFlow.getId()))
        .mapNotNull(this::saveDocumentCashflow)
        .mapNotNull(documentCashFlowTransformer)
        .doOnComplete(
            () -> {
              for (var cashFlowId : requestedCashFlowIds) {
                log.info(
                    "Could not update CashFlowId id: {} because it does not exist.", cashFlowId);
              }
            });
  }

  private Flux<DocumentCashFlowEntity> findAllByIds(Set<Long> cashflowIds) {
    return Flux.fromStream(
        documentCashflowRepository.findAllByIdInAndIsCurrentTrue(cashflowIds).stream());
  }

  @Override
  @Transactional
  public Mono<DocumentCashFlow> findByDocumentId(final Long documentId) {
    try {
      return Mono.justOrEmpty(
              documentCashflowRepository.findByDocumentIdAndIsCurrentTrue(documentId))
          .mapNotNull(documentCashFlowTransformer);
    } catch (Exception e) {
      return Mono.error(
          new DocumentCashFlowException(
              HttpStatus.INTERNAL_SERVER_ERROR,
              "Unable to find Document Cashflow by Document ID",
              e));
    }
  }

  private DocumentCashFlowEntity saveDocumentCashflow(
      DocumentCashFlowEntity documentCashFlowEntity) {
    return documentCashflowRepository.saveAndFlush(documentCashFlowEntity);
  }

  private Flux<DocumentCashFlow> saveCashflows(Flux<DocumentCashFlowEntity> configs) {
    return configs
        .log("Save Cashflow")
        .map(
            entity -> {
              log.info("Creating or updating Cashflow cashflowId: {}", entity.getId());
              return saveDocumentCashflow(entity);
            })
        .map(documentCashFlowTransformer);
  }

  private Flux<DocumentCashFlow> createDocumentCashFlows(
      Flux<DocumentCashFlowEntity> documentCashFlowEntityFlux) {
    var id = new AtomicReference<Long>();
    AtomicReference<BankDetailEntity> beneficiaryBankDetailEntity = new AtomicReference<>();
    AtomicReference<BankDetailEntity> correspondentBankDetailEntity = new AtomicReference<>();
    AtomicReference<BankDetailEntity> intermediaryBankDetailEntity = new AtomicReference<>();
    return documentCashFlowEntityFlux
        .log("Create Document CashFlow")
        .map(
            cashFlow -> {
              id.set(cashFlow.getId());
              if (cashFlow.getBeneficiaryBankDetail() != null) {
                beneficiaryBankDetailEntity.set(cashFlow.getBeneficiaryBankDetail());
                if (beneficiaryBankDetailEntity.get() != null
                    && beneficiaryBankDetailEntity.get().getName() != null) {
                  BankDetailEntity savedBeneficiaryBankDetailEntity =
                      bankDetailRepository.saveAndFlush(beneficiaryBankDetailEntity.get());
                  cashFlow.setBeneficiaryBankDetail(savedBeneficiaryBankDetailEntity);
                }
              }
              if (cashFlow.getCorrespondentBankDetail() != null) {
                correspondentBankDetailEntity.set(cashFlow.getCorrespondentBankDetail());
                if (correspondentBankDetailEntity.get() != null
                    && correspondentBankDetailEntity.get().getName() != null) {
                  BankDetailEntity savedCorrespondentBankDetailEntity =
                      bankDetailRepository.saveAndFlush(correspondentBankDetailEntity.get());
                  cashFlow.setCorrespondentBankDetail(savedCorrespondentBankDetailEntity);
                }
              }
              if (cashFlow.getIntermediaryBankDetail() != null) {
                intermediaryBankDetailEntity.set(cashFlow.getIntermediaryBankDetail());
                if (intermediaryBankDetailEntity.get() != null
                    && intermediaryBankDetailEntity.get().getName() != null) {
                  BankDetailEntity savedIntermediaryBankDetailEntity =
                      bankDetailRepository.saveAndFlush(intermediaryBankDetailEntity.get());
                  cashFlow.setIntermediaryBankDetail(savedIntermediaryBankDetailEntity);
                }
              }
              log.info(
                  "Create Document CashFlow {}_{} for accountId: {} securityId {}",
                  cashFlow.getId(),
                  cashFlow.getVersion(),
                  cashFlow.getAccountId(),
                  cashFlow.getSecurityId());
              return documentCashflowRepository.insertDocumentCashFlow(
                  cashFlow.getId(),
                  cashFlow.getVersion(),
                  cashFlow.getAccountId(),
                  cashFlow.getSecurityId(),
                  cashFlow.getDocumentId(),
                  cashFlow.getLimitedPartnerId(),
                  cashFlow.getNetAmount(),
                  cashFlow.getTotalContribution(),
                  cashFlow.getTotalRecallableDistribution(),
                  cashFlow.getTotalNonRecallableDistribution(),
                  cashFlow.getRecallableDistributionItd(),
                  cashFlow.getReturnOfCapitalDistributionItd(),
                  cashFlow.getFfcName(),
                  cashFlow.getFfcNumber(),
                  (cashFlow.getBeneficiaryBankDetail() != null)
                      ? cashFlow.getBeneficiaryBankDetail().getId()
                      : null,
                  (cashFlow.getCorrespondentBankDetail() != null)
                      ? cashFlow.getCorrespondentBankDetail().getId()
                      : null,
                  (cashFlow.getIntermediaryBankDetail() != null)
                      ? cashFlow.getIntermediaryBankDetail().getId()
                      : null,
                  cashFlow.getAction(),
                  cashFlow.getKnowledgeStartDate(),
                  cashFlow.getKnowledgeEndDate(),
                  cashFlow.getIsCurrent(),
                  cashFlow.getSource(),
                  cashFlow.getCreatedBy(),
                  cashFlow.getIsCreatedByInternalUser(),
                  (cashFlow.getCreatedOn() != null) && (cashFlow.getVersion() == 1)
                      ? cashFlow.getCreatedOn()
                      : LocalDateTime.now(ZoneOffset.UTC),
                  cashFlow.getModifiedBy(),
                  cashFlow.getIsModifiedByInternalUser(),
                  cashFlow.getModifiedOn() != null
                      ? cashFlow.getModifiedOn()
                      : LocalDateTime.now(ZoneOffset.UTC),
                  cashFlow.getDocumentName(),
                  cashFlow.getLimitedPartnerPercentOfFund(),
                  cashFlow.getLimitedPartnerPercentOfNav(),
                  cashFlow.getCurrency(),
                  cashFlow.getFxCurrency(),
                  cashFlow.getFxRate());
            })
        .map(x -> id.get() == null ? documentCashflowRepository.getId() : id.get())
        .map(cashFlowId -> documentCashflowRepository.findByIdAndIsCurrentTrue(cashFlowId))
        .mapNotNull(documentCashFlowTransformer);
  }

  @Override
  @Transactional
  public Flux<DocumentCashFlow> getCashflowsByDocumentId(Long documentId) {
    return Flux.fromIterable(
            documentCashflowRepository.findAllByDocumentIdAndIsCurrentAndActionNot(
                documentId, IS_CURRENT, CANCEL))
        .map(documentCashFlowTransformer);
  }
}
