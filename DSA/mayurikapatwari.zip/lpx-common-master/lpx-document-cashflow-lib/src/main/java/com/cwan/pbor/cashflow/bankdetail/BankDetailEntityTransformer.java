package com.cwan.pbor.cashflow.bankdetail;

import com.cwan.lpx.domain.BankDetail;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankDetailEntityTransformer implements Function<BankDetail, BankDetailEntity> {

  @Override
  public BankDetailEntity apply(BankDetail bankDetail) {
    return Optional.ofNullable(bankDetail)
        .map(
            details ->
                BankDetailEntity.builder()
                    .id(bankDetail.getId())
                    .name(bankDetail.getName())
                    .address(bankDetail.getAddress())
                    .abaRoutingNumber(bankDetail.getAbaRoutingNumber())
                    .swiftOrChips(bankDetail.getSwiftOrChip())
                    .accountIBAN(bankDetail.getAccountIBAN())
                    .accountName(bankDetail.getAccountName())
                    .accountNumber(bankDetail.getAccountNumber())
                    .accountAddress(bankDetail.getAccountAddress())
                    .reference(bankDetail.getReference())
                    .createdBy(bankDetail.getCreatedBy())
                    .isCreatedByInternalUser(bankDetail.getIsCreatedByInternalUser())
                    .modifiedBy(bankDetail.getModifiedBy())
                    .isModifiedByInternalUser(bankDetail.getIsModifiedByInternalUser())
                    .build())
        .orElse(BankDetailEntity.builder().build());
  }
}
