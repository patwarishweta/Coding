package com.cwan.pbor.cashflow.bankdetail;

import com.cwan.lpx.domain.BankDetail;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankDetailTransformer implements Function<BankDetailEntity, BankDetail> {

  @Override
  public BankDetail apply(BankDetailEntity bankDetailEntity) {
    return BankDetail.builder()
        .id(bankDetailEntity.getId())
        .name(bankDetailEntity.getName())
        .address(bankDetailEntity.getAddress())
        .abaRoutingNumber(bankDetailEntity.getAbaRoutingNumber())
        .swiftOrChip(bankDetailEntity.getSwiftOrChips())
        .accountIBAN(bankDetailEntity.getAccountIBAN())
        .accountName(bankDetailEntity.getAccountName())
        .accountNumber(bankDetailEntity.getAccountNumber())
        .accountAddress(bankDetailEntity.getAccountAddress())
        .reference(bankDetailEntity.getReference())
        .createdBy(bankDetailEntity.getCreatedBy())
        .isCreatedByInternalUser(bankDetailEntity.getIsCreatedByInternalUser())
        .createdOn(bankDetailEntity.getCreatedOn())
        .modifiedBy(bankDetailEntity.getModifiedBy())
        .isModifiedByInternalUser(bankDetailEntity.getIsModifiedByInternalUser())
        .modifiedOn(bankDetailEntity.getModifiedOn())
        .build();
  }
}
