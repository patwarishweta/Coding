package com.cwan.pbor.cashflow.documentcashflow;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface DocumentCashFlowRepository
    extends JpaRepository<DocumentCashFlowEntity, CashFlowKey> {

  Optional<DocumentCashFlowEntity> findByIdAndVersion(Long id, Integer version);

  DocumentCashFlowEntity findByDocumentIdAndIsCurrentTrue(Long documentId);

  Collection<DocumentCashFlowEntity> findAllByIdInAndIsCurrentTrue(Set<Long> cashFlowIds);

  DocumentCashFlowEntity findByIdAndIsCurrentTrue(Long id);

  @Modifying
  @Query(
      value =
          "insert into pabor.document_cash_flow (id, version, account_id, security_id, document_id, limited_partner_id,"
              + "net_amount, total_contribution, total_recallable_distribution, total_non_recallable_distribution,"
              + "recallable_distribution_itd, return_of_capital_distribution_itd, ffc_name, ffc_number, beneficiary_bank_detail_id,"
              + "correspondent_bank_detail_id, intermediary_bank_detail_id, action, knowledge_start_date, knowledge_end_date,"
              + "is_current, source, created_by, is_created_by_internal_user, "
              + "created_on, modified_by, is_modified_by_internal_user, modified_on, document_name,"
              + "limited_partner_percent_of_fund, limited_partner_percent_of_nav, currency, fx_currency, fx_rate)"
              + "select :id, :version, :accountId, :securityId, :documentId, "
              + ":limitedPartnerId, :netAmount, :totalContribution, :totalRecallableDistribution,"
              + ":totalNonRecallableDistribution, :recallableDistributionItd, "
              + ":returnOfCapitalDistributionItd, :ffcName, :ffcNumber, "
              + ":beneficiaryBankDetailId, :correspondentBankDetailId, :intermediaryBankDetailId, :action, "
              + ":knowledgeStartDate, :knowledgeEndDate, :isCurrent,"
              + ":source, :createdBy, :isCreatedByInternalUser, "
              + ":createdOn, :modifiedBy, :isModifiedByInternalUser, :modifiedOn, :documentName,"
              + ":limitedPartnerPercentOfNav, :limitedPartnerPercentOfFund,"
              + ":currency, :fxCurrency, :fxRate "
              + "from dual",
      nativeQuery = true)
  @Transactional
  Integer insertDocumentCashFlow(
      Long id,
      Integer version,
      Long accountId,
      Long securityId,
      Long documentId,
      String limitedPartnerId,
      Double netAmount,
      Double totalContribution,
      Double totalRecallableDistribution,
      Double totalNonRecallableDistribution,
      Double recallableDistributionItd,
      Double returnOfCapitalDistributionItd,
      String ffcName,
      String ffcNumber,
      Long beneficiaryBankDetailId,
      Long correspondentBankDetailId,
      Long intermediaryBankDetailId,
      String action,
      LocalDateTime knowledgeStartDate,
      LocalDateTime knowledgeEndDate,
      Boolean isCurrent,
      String source,
      String createdBy,
      Boolean isCreatedByInternalUser,
      LocalDateTime createdOn,
      String modifiedBy,
      Boolean isModifiedByInternalUser,
      LocalDateTime modifiedOn,
      String documentName,
      Double limitedPartnerPercentOfNav,
      Double limitedPartnerPercentOfFund,
      String currency,
      String fxCurrency,
      Double fxRate);

  @Query(value = "select last_insert_id() ", nativeQuery = true)
  Long getId();

  List<DocumentCashFlowEntity> findAllByDocumentIdInAndIsCurrentTrue(List<Long> documentIds);

  Collection<DocumentCashFlowEntity> findAllByDocumentIdAndIsCurrentAndActionNot(
      Long documentId, boolean isCurrent, String action);
}
