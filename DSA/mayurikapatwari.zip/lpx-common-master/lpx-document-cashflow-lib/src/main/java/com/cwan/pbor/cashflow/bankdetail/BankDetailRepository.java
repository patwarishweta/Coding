package com.cwan.pbor.cashflow.bankdetail;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BankDetailRepository extends JpaRepository<BankDetailEntity, Long> {}
