package com.cwan.pbor.cashflow.bankdetail.api;

import com.cwan.lpx.domain.BankDetail;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface BankDetails {

  Flux<BankDetail> addBankDetail(Set<BankDetail> bankDetail);

  Flux<BankDetail> getBankDetailByIds(Set<Long> bankDetailIds);

  Flux<BankDetail> deleteBankDetailById(Set<Long> bankDetailIds);

  Flux<BankDetail> updateBankInfo(Set<Long> ids, Set<BankDetail> bankDetail);
}
