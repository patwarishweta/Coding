package com.cwan.pbor.cashflow.documentcashflow.api;

import com.cwan.lpx.domain.DocumentCashFlow;
import java.util.Set;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface DocumentCashflows {

  Flux<DocumentCashFlow> addCashflow(Set<DocumentCashFlow> cashflow);

  Flux<DocumentCashFlow> getCashflowByIds(Set<Long> cashflowIds);

  Flux<DocumentCashFlow> deleteCashflowById(Set<Long> cashflowIds);

  Flux<DocumentCashFlow> updateCashflowInfo(Set<Long> ids, Set<DocumentCashFlow> cashflow);

  Mono<DocumentCashFlow> findByDocumentId(Long documentId);

  Flux<DocumentCashFlow> getCashflowsByDocumentId(Long documentId);
}
