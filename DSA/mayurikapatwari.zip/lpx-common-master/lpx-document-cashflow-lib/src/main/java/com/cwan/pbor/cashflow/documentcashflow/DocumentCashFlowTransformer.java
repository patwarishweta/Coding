package com.cwan.pbor.cashflow.documentcashflow;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.DocumentCashFlow;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.cashflow.bankdetail.BankDetailTransformer;
import java.util.Objects;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class DocumentCashFlowTransformer
    implements Function<DocumentCashFlowEntity, DocumentCashFlow> {

  @Override
  public DocumentCashFlow apply(DocumentCashFlowEntity documentCashFlowEntity) {
    var bankDetailTransformer = new BankDetailTransformer();
    return DocumentCashFlow.builder()
        .id(documentCashFlowEntity.getId())
        .version(documentCashFlowEntity.getVersion())
        .document(getDocument(documentCashFlowEntity))
        .limitedPartnerId(documentCashFlowEntity.getLimitedPartnerId())
        .limitedPartnerPercentOfFund(documentCashFlowEntity.getLimitedPartnerPercentOfFund())
        .limitedPartnerPercentOfNAV(documentCashFlowEntity.getLimitedPartnerPercentOfNav())
        .beneficiaryBankDetail(
            Objects.nonNull(documentCashFlowEntity.getBeneficiaryBankDetail())
                ? bankDetailTransformer.apply(documentCashFlowEntity.getBeneficiaryBankDetail())
                : null)
        .correspondentBankDetail(
            Objects.nonNull(documentCashFlowEntity.getCorrespondentBankDetail())
                ? bankDetailTransformer.apply(documentCashFlowEntity.getCorrespondentBankDetail())
                : null)
        .intermediaryBankDetail(
            Objects.nonNull(documentCashFlowEntity.getIntermediaryBankDetail())
                ? bankDetailTransformer.apply(documentCashFlowEntity.getIntermediaryBankDetail())
                : null)
        .netAmount(documentCashFlowEntity.getNetAmount())
        .totalContribution(documentCashFlowEntity.getTotalContribution())
        .totalRecallableDistribution(documentCashFlowEntity.getTotalRecallableDistribution())
        .totalNonRecallableDistribution(documentCashFlowEntity.getTotalNonRecallableDistribution())
        .recallableDistributionITD(documentCashFlowEntity.getRecallableDistributionItd())
        .returnOfCapitalDistributionITD(documentCashFlowEntity.getReturnOfCapitalDistributionItd())
        .currency(documentCashFlowEntity.getCurrency())
        .fxCurrency(documentCashFlowEntity.getFxCurrency())
        .fxRate(documentCashFlowEntity.getFxRate())
        .ffcName(documentCashFlowEntity.getFfcName())
        .ffcNumber(documentCashFlowEntity.getFfcNumber())
        .source(documentCashFlowEntity.getSource())
        .isCurrent(documentCashFlowEntity.getIsCurrent())
        .action(documentCashFlowEntity.getAction())
        .knowledgeStartDate(documentCashFlowEntity.getKnowledgeStartDate())
        .knowledgeEndDate(documentCashFlowEntity.getKnowledgeEndDate())
        .createdBy(documentCashFlowEntity.getCreatedBy())
        .isCreatedByInternalUser(documentCashFlowEntity.getIsCreatedByInternalUser())
        .createdOn(documentCashFlowEntity.getCreatedOn())
        .modifiedOn(documentCashFlowEntity.getModifiedOn())
        .modifiedBy(documentCashFlowEntity.getModifiedBy())
        .build();
  }

  private Document getDocument(DocumentCashFlowEntity entity) {
    return Document.builder()
        .id(entity.getDocumentId())
        .fileName(entity.getDocumentName())
        .account(Account.builder().id(entity.getAccountId()).build())
        .security(Security.builder().securityId(entity.getSecurityId()).build())
        .build();
  }
}
