package com.cwan.pbor.cashflow.documentcashflow;

import static jakarta.persistence.CascadeType.DETACH;
import static jakarta.persistence.CascadeType.MERGE;
import static jakarta.persistence.CascadeType.PERSIST;
import static jakarta.persistence.CascadeType.REFRESH;

import com.cwan.pbor.cashflow.bankdetail.BankDetailEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

@Entity
@Table(name = "document_cash_flow", catalog = "pabor")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@IdClass(CashFlowKey.class)
public class DocumentCashFlowEntity implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Id private Integer version;
  private Long accountId;
  private Long securityId;
  private Long documentId;
  private String documentName;
  private String limitedPartnerId;
  private Double limitedPartnerPercentOfFund;
  private Double limitedPartnerPercentOfNav;
  private Double netAmount;
  private Double totalContribution;
  private Double totalRecallableDistribution;
  private Double totalNonRecallableDistribution;
  private Double recallableDistributionItd;
  private Double returnOfCapitalDistributionItd;
  private String currency;
  private String fxCurrency;
  private Double fxRate;
  private String ffcName;
  private String ffcNumber;
  private Boolean isCurrent;

  @ManyToOne(cascade = {PERSIST, MERGE, REFRESH, DETACH})
  @JoinColumn(name = "beneficiary_bank_detail_id")
  private BankDetailEntity beneficiaryBankDetail;

  @ManyToOne(cascade = {PERSIST, MERGE, REFRESH, DETACH})
  @JoinColumn(name = "correspondent_bank_detail_id")
  private BankDetailEntity correspondentBankDetail;

  @ManyToOne(cascade = {PERSIST, MERGE, REFRESH, DETACH})
  @JoinColumn(name = "intermediary_bank_detail_id")
  private BankDetailEntity intermediaryBankDetail;

  private String action;
  private LocalDateTime knowledgeStartDate;
  private LocalDateTime knowledgeEndDate;
  private String source;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  private Boolean isModifiedByInternalUser;
  private LocalDateTime createdOn;
  private LocalDateTime modifiedOn;
  private String modifiedBy;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (DocumentCashFlowEntity) o;
    return (id != null) && Objects.equals(id, that.id);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
