package com.cwan.pbor.cashflow.documentcashflow;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.Hibernate;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
public class CashFlowKey implements Serializable {

  @Serial private static final long serialVersionUID = 7351223847506724113L;
  private Long id;
  private Integer version;

  @Override
  public int hashCode() {
    return Objects.hash(version, id);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (CashFlowKey) o;
    return (version != null)
        && Objects.equals(version, that.version)
        && (id != null)
        && Objects.equals(id, that.id);
  }
}
