package com.cwan.pbor.cashflow.bankdetail;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class BankDetailException extends ResponseStatusException {

  public BankDetailException(HttpStatus status, String msg, Throwable e) {
    super(status, msg, e);
  }

  public BankDetailException(HttpStatus status, String msg) {
    super(status, msg);
  }
}
