package com.cwan.pbor.cashflow.documentcashflow;

public class Constants {

  private Constants() {}

  public static final boolean IS_CURRENT = true;
  public static final String CANCEL = "Cancel";
}
