package com.cwan.pbor.cash.recon.api;

import com.cwan.lpx.domain.CashReconConfig;
import java.util.List;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CashReconConfigService {

  Mono<CashReconConfig> getCashReconConfigForAccIdAndSecId(long accountId, long securityId);

  Mono<CashReconConfig> getCashReconConfigForAccIdAndSecIdAndCurrency(
      long accountId, long securityId, String currency);

  Flux<CashReconConfig> getAllCashReconConfigForContributionCustodyFeedConfigId(
      long contributionCustodyFeedConfigId);

  Flux<CashReconConfig> getAllCashReconConfigForAccIdListAndSecIdList(
      List<Long> accountIds, List<Long> securityIds);
}
