package com.cwan.pbor.cash.recon.repository;

import com.cwan.lpx.domain.ReconciliationStatus;
import com.cwan.pbor.cash.recon.entity.CustodyTransactionEntity;
import java.time.LocalDate;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustodyTransactionRepository
    extends JpaRepository<CustodyTransactionEntity, Long> {
  Collection<CustodyTransactionEntity>
      findAllBySecurityIdAndCashAccountNumberAndCustodyAccountIdAndReconciliationStatusAndTransactionDateBetween(
          Long securityId,
          String cashAccountNumber,
          Long custodyAccountId,
          ReconciliationStatus reconciliationStatus,
          LocalDate startDate,
          LocalDate endDate);
}
