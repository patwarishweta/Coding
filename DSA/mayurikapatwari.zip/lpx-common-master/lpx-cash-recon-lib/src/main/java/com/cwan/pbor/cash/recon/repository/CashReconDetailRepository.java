package com.cwan.pbor.cash.recon.repository;

import com.cwan.pbor.cash.recon.entity.CashReconDetailEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CashReconDetailRepository extends JpaRepository<CashReconDetailEntity, Long> {

  List<CashReconDetailEntity> findByDocumentId(Long documentId);

  List<CashReconDetailEntity> findByDocumentIdAndCustodyTransactionId(
      Long documentId, Long custodyTransactionId);

  List<CashReconDetailEntity> findByCustodyTransactionId(Long custodyTransactionId);

  List<CashReconDetailEntity> findByDocumentIdIn(List<Long> documentIds);

  List<CashReconDetailEntity> findByCustodyTransactionIdIn(List<Long> custodyTransactionIds);
}
