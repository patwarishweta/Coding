package com.cwan.pbor.cash.recon.repository;

import com.cwan.pbor.cash.recon.entity.CashReconConfigEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CashReconConfigRepository extends JpaRepository<CashReconConfigEntity, Long> {

  CashReconConfigEntity findByAccountIdAndSecurityId(long accountId, long securityId);

  CashReconConfigEntity findByAccountIdAndSecurityIdAndCurrencyIgnoreCase(
      long accountId, long securityId, String currency);

  List<CashReconConfigEntity> findAllByContributionCustodyFeedConfigEntity_Id(
      long contributionCustodyFeedConfigId);

  List<CashReconConfigEntity> findAllByAccountIdInAndSecurityIdIn(
      List<Long> accountIds, List<Long> securityIds);
}
