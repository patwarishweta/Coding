package com.cwan.pbor.cash.recon.api.impl;

import com.cwan.lpx.domain.CashReconConfig;
import com.cwan.pbor.cash.recon.api.CashReconConfigService;
import com.cwan.pbor.cash.recon.repository.CashReconConfigRepository;
import com.cwan.pbor.cash.recon.transformer.CashReconConfigTransformer;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class CashReconConfigServiceImpl implements CashReconConfigService {

  private CashReconConfigRepository cashReconConfigRepository;
  private CashReconConfigTransformer cashReconConfigTransformer;

  @Override
  public Mono<CashReconConfig> getCashReconConfigForAccIdAndSecId(long accountId, long securityId) {
    return Mono.just(
        cashReconConfigTransformer.apply(
            cashReconConfigRepository.findByAccountIdAndSecurityId(accountId, securityId)));
  }

  @Override
  public Mono<CashReconConfig> getCashReconConfigForAccIdAndSecIdAndCurrency(
      long accountId, long securityId, String currency) {
    return Mono.just(
        cashReconConfigTransformer.apply(
            cashReconConfigRepository.findByAccountIdAndSecurityIdAndCurrencyIgnoreCase(
                accountId, securityId, currency)));
  }

  @Override
  public Flux<CashReconConfig> getAllCashReconConfigForContributionCustodyFeedConfigId(
      long contributionCustodyFeedConfigId) {
    return Flux.fromIterable(
        cashReconConfigRepository
            .findAllByContributionCustodyFeedConfigEntity_Id(contributionCustodyFeedConfigId)
            .stream()
            .map(cashReconConfigTransformer)
            .collect(Collectors.toList()));
  }

  @Override
  public Flux<CashReconConfig> getAllCashReconConfigForAccIdListAndSecIdList(
      List<Long> accountIds, List<Long> securityIds) {
    return Flux.fromIterable(
        cashReconConfigRepository
            .findAllByAccountIdInAndSecurityIdIn(accountIds, securityIds)
            .stream()
            .map(cashReconConfigTransformer)
            .collect(Collectors.toList()));
  }
}
