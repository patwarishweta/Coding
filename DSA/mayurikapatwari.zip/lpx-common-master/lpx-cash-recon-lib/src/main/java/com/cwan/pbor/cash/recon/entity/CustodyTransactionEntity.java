package com.cwan.pbor.cash.recon.entity;

import com.cwan.lpx.domain.ReconciliationStatus;
import com.cwan.pbor.cash.recon.model.Type;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "custody_transaction")
@Getter
@Setter
@AllArgsConstructor
@Builder(toBuilder = true)
@RequiredArgsConstructor
public class CustodyTransactionEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Double transactionAmountLocal;
  private Double transactionAmountReporting;
  private String localCurrencyCode;
  private String reportingCurrencyCode;
  private String transactionType;
  private String transactionSubType;
  private Long fileId;
  private String comment;
  private LocalDate transactionDate;
  private LocalDate reconciliationDate;

  @Enumerated(EnumType.STRING)
  private ReconciliationStatus reconciliationStatus;

  private String transactionDetail;
  private Long securityId;
  private Long custodyAccountId;
  private String cashAccountNumber;
  private String dataSource;
  private Boolean isCreatedByInternalUser;
  private Boolean isModifiedByInternalUser;
  private String createdBy;
  private String modifiedBy;
  private String reason;
  private String uploadedDocCanoeId;
  private String docUploadedBy;

  @Enumerated(EnumType.STRING)
  @Default
  private Type type = Type.SIMPLE;

  private Long parentId;
  private String referenceNumber;
  private Long executionId;
  private Long prometheusId;
  private Long externalIdentifier;
  @Default private Boolean isDisabled = false;
}
