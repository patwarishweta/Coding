package com.cwan.pbor.cash.recon.transformer;

import com.cwan.lpx.domain.CashReconConfig;
import com.cwan.pbor.cash.recon.entity.CashReconConfigEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class CashReconConfigTransformer
    implements Function<CashReconConfigEntity, CashReconConfig> {

  private CustodyFeedConfigTransformer custodyFeedConfigTransformer;

  @Override
  public CashReconConfig apply(CashReconConfigEntity cashReconConfigEntity) {
    return CashReconConfig.builder()
        .id(cashReconConfigEntity.getId())
        .accountId(cashReconConfigEntity.getAccountId())
        .securityId(cashReconConfigEntity.getSecurityId())
        .currency(cashReconConfigEntity.getCurrency())
        .distributionCustodyFeedConfig(
            cashReconConfigEntity.getDistributionCustodyFeedConfigEntity() != null
                ? custodyFeedConfigTransformer.apply(
                    cashReconConfigEntity.getDistributionCustodyFeedConfigEntity())
                : null)
        .contributionCustodyFeedConfig(
            cashReconConfigEntity.getContributionCustodyFeedConfigEntity() != null
                ? custodyFeedConfigTransformer.apply(
                    cashReconConfigEntity.getContributionCustodyFeedConfigEntity())
                : null)
        .createdBy(cashReconConfigEntity.getCreatedBy())
        .modifiedBy(cashReconConfigEntity.getModifiedBy())
        .build();
  }
}
