package com.cwan.pbor.cash.recon.api;

import com.cwan.lpx.domain.CustodyTransaction;
import com.cwan.lpx.domain.ReconciliationStatus;
import java.time.LocalDate;
import reactor.core.publisher.Flux;

public interface CustodyTransactionService {

  Flux<CustodyTransaction>
      getAllCustodyTransactionUsingSecIdAndCashAccNoAndCusAccIdAndReconStatusAndTransDateBetween(
          Long securityId,
          String cashAccountNumber,
          Long custodyAccountId,
          ReconciliationStatus reconciliationStatus,
          LocalDate startDate,
          LocalDate endDate);
}
