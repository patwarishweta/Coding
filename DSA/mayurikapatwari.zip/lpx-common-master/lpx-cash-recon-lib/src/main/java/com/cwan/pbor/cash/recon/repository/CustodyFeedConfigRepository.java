package com.cwan.pbor.cash.recon.repository;

import com.cwan.pbor.cash.recon.entity.CustodyFeedConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustodyFeedConfigRepository extends JpaRepository<CustodyFeedConfigEntity, Long> {
  CustodyFeedConfigEntity findByCustodyAccountIdAndCashAccountNumber(
      Long custodyAccountID, String cashAccNumber);
}
