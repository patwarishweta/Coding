package com.cwan.pbor.cash.recon.api.impl;

import com.cwan.lpx.domain.CustodyFeedConfig;
import com.cwan.pbor.cash.recon.api.CustodyFeedConfigService;
import com.cwan.pbor.cash.recon.repository.CustodyFeedConfigRepository;
import com.cwan.pbor.cash.recon.transformer.CustodyFeedConfigTransformer;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class CustodyFeedConfigServiceImpl implements CustodyFeedConfigService {

  private CustodyFeedConfigRepository custodyFeedConfigRepository;
  private CustodyFeedConfigTransformer custodyFeedConfigTransformer;

  @Override
  public Mono<CustodyFeedConfig> getCustodyFeedConfigUsingCusAccIdAndCashAccNo(
      Long custodyAccountID, String cashAccNumber) {
    return Mono.just(
        custodyFeedConfigTransformer.apply(
            custodyFeedConfigRepository.findByCustodyAccountIdAndCashAccountNumber(
                custodyAccountID, cashAccNumber)));
  }
}
