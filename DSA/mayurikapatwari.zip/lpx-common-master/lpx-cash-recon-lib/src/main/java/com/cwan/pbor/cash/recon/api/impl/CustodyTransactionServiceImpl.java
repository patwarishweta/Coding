package com.cwan.pbor.cash.recon.api.impl;

import com.cwan.lpx.domain.CustodyTransaction;
import com.cwan.lpx.domain.ReconciliationStatus;
import com.cwan.pbor.cash.recon.api.CustodyTransactionService;
import com.cwan.pbor.cash.recon.repository.CustodyTransactionRepository;
import com.cwan.pbor.cash.recon.transformer.CustodyTransactionTransformer;
import java.time.LocalDate;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class CustodyTransactionServiceImpl implements CustodyTransactionService {

  private CustodyTransactionRepository custodyTransactionRepository;
  private CustodyTransactionTransformer custodyTransactionTransformer;

  @Override
  public Flux<CustodyTransaction>
      getAllCustodyTransactionUsingSecIdAndCashAccNoAndCusAccIdAndReconStatusAndTransDateBetween(
          Long securityId,
          String cashAccountNumber,
          Long custodyAccountId,
          ReconciliationStatus reconciliationStatus,
          LocalDate startDate,
          LocalDate endDate) {
    return Flux.fromIterable(
        custodyTransactionRepository
            .findAllBySecurityIdAndCashAccountNumberAndCustodyAccountIdAndReconciliationStatusAndTransactionDateBetween(
                securityId,
                cashAccountNumber,
                custodyAccountId,
                reconciliationStatus,
                startDate,
                endDate)
            .stream()
            .map(custodyTransactionTransformer)
            .collect(Collectors.toList()));
  }
}
