package com.cwan.pbor.cash.recon.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "document_custody_transaction_link", catalog = "pabor")
@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class DocumentCustodyTxnLinkEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long documentId;
  private Long custodyTransactionId;
  private Boolean hasLinkedDocs = false;
  private String linkIdentifier;
}
