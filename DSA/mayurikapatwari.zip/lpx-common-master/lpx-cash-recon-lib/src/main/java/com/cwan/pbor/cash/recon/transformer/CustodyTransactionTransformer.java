package com.cwan.pbor.cash.recon.transformer;

import com.cwan.lpx.domain.CustodyTransaction;
import com.cwan.pbor.cash.recon.entity.CustodyTransactionEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class CustodyTransactionTransformer
    implements Function<CustodyTransactionEntity, CustodyTransaction> {

  @Override
  public CustodyTransaction apply(CustodyTransactionEntity custodyTransactionEntity) {
    return CustodyTransaction.builder()
        .id(custodyTransactionEntity.getId())
        .dataSource(custodyTransactionEntity.getDataSource())
        .amountInLocalCurrency(custodyTransactionEntity.getTransactionAmountLocal())
        .amountInReportingCurrency(custodyTransactionEntity.getTransactionAmountLocal())
        .localCurrencyCode(custodyTransactionEntity.getLocalCurrencyCode())
        .reportingCurrencyCode(custodyTransactionEntity.getReportingCurrencyCode())
        .transactionType(custodyTransactionEntity.getTransactionType())
        .transactionSubType(custodyTransactionEntity.getTransactionSubType())
        .transactionDescription(custodyTransactionEntity.getTransactionDetail())
        .cashAccountNumber(custodyTransactionEntity.getCashAccountNumber())
        .isCreatedByInternalUser(custodyTransactionEntity.getIsCreatedByInternalUser())
        .fileId(custodyTransactionEntity.getFileId())
        .comment(custodyTransactionEntity.getComment())
        .custodyAccountId(custodyTransactionEntity.getCustodyAccountId())
        .securityId(custodyTransactionEntity.getSecurityId())
        .transactionDate(custodyTransactionEntity.getTransactionDate())
        .reconcileDate(custodyTransactionEntity.getReconciliationDate())
        .reconciliationStatus(custodyTransactionEntity.getReconciliationStatus())
        .createdBy(custodyTransactionEntity.getCreatedBy())
        .modifiedBy(custodyTransactionEntity.getModifiedBy())
        .reason(custodyTransactionEntity.getReason())
        .uploadedDocCanoeId(custodyTransactionEntity.getUploadedDocCanoeId())
        .docUploadedBy(custodyTransactionEntity.getDocUploadedBy())
        .build();
  }
}
