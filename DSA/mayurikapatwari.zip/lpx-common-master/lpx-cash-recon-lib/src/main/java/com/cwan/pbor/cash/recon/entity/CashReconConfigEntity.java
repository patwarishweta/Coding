package com.cwan.pbor.cash.recon.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "cash_recon_config", catalog = "pabor")
@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class CashReconConfigEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long accountId;
  private Long securityId;
  private String currency;
  private String createdBy;
  private String modifiedBy;

  @ManyToOne
  @JoinColumn(name = "contribution_custody_feed_config_id")
  private CustodyFeedConfigEntity contributionCustodyFeedConfigEntity;

  @ManyToOne
  @JoinColumn(name = "distribution_custody_feed_config_id")
  private CustodyFeedConfigEntity distributionCustodyFeedConfigEntity;
}
