package com.cwan.pbor.cash.recon.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "custody_feed_config", catalog = "pabor")
@EqualsAndHashCode
@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class CustodyFeedConfigEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String name;
  private Long custodyAccountId;
  private String cashAccountNumber;
  private String createdBy;
  private String modifiedBy;
}
