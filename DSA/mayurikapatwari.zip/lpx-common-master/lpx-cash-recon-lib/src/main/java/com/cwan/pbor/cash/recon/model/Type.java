package com.cwan.pbor.cash.recon.model;

public enum Type {
  SIMPLE,
  AGGREGATE_PARENT,
  AGGREGATE_CHILD
}
