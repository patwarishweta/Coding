package com.cwan.pbor.cash.recon.repository;

import com.cwan.pbor.cash.recon.entity.CashReconAuditEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CashReconAuditRepository extends JpaRepository<CashReconAuditEntity, Long> {
  List<CashReconAuditEntity> findByDocumentIdIn(List<Long> documentIds);

  List<CashReconAuditEntity> findByDocumentId(Long documentId);

  List<CashReconAuditEntity> findByDocumentIdAndCustodyTransactionId(
      Long documentId, Long custodyTransactionId);

  List<CashReconAuditEntity> findByCustodyTransactionId(Long custodyTransactionId);

  List<CashReconAuditEntity> findByCustodyTransactionIdIn(List<Long> custodyTransactionIds);
}
