package com.cwan.pbor.cash.recon.transformer;

import com.cwan.lpx.domain.CustodyFeedConfig;
import com.cwan.pbor.cash.recon.entity.CustodyFeedConfigEntity;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class CustodyFeedConfigTransformer
    implements Function<CustodyFeedConfigEntity, CustodyFeedConfig> {

  @Override
  public CustodyFeedConfig apply(CustodyFeedConfigEntity custodyFeedConfigEntity) {
    return CustodyFeedConfig.builder()
        .id(custodyFeedConfigEntity.getId())
        .custodyAccountId(custodyFeedConfigEntity.getCustodyAccountId())
        .name(custodyFeedConfigEntity.getName())
        .cashAccountNumber(custodyFeedConfigEntity.getCashAccountNumber())
        .createdBy(custodyFeedConfigEntity.getCreatedBy())
        .modifiedBy(custodyFeedConfigEntity.getModifiedBy())
        .build();
  }
}
