package com.cwan.pbor.cash.recon.api;

import com.cwan.lpx.domain.CustodyFeedConfig;
import reactor.core.publisher.Mono;

public interface CustodyFeedConfigService {

  Mono<CustodyFeedConfig> getCustodyFeedConfigUsingCusAccIdAndCashAccNo(
      Long custodyAccountID, String cashAccNumber);
}
