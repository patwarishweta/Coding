import com.cwan.pbor.cash.recon.api.CashReconConfigService;
import com.cwan.pbor.cash.recon.api.CustodyFeedConfigService;
import com.cwan.pbor.cash.recon.api.CustodyTransactionService;
import com.cwan.pbor.cash.recon.api.impl.CashReconConfigServiceImpl;
import com.cwan.pbor.cash.recon.api.impl.CustodyFeedConfigServiceImpl;
import com.cwan.pbor.cash.recon.api.impl.CustodyTransactionServiceImpl;

module pbor.cash.recon.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;

  exports com.cwan.pbor.cash.recon.api;

  provides CashReconConfigService with
      CashReconConfigServiceImpl;
  provides CustodyFeedConfigService with
      CustodyFeedConfigServiceImpl;
  provides CustodyTransactionService with
      CustodyTransactionServiceImpl;
}
