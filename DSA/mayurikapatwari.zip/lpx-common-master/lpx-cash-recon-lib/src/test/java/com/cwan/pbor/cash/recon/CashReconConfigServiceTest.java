package com.cwan.pbor.cash.recon;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CashReconConfig;
import com.cwan.pbor.cash.recon.api.CashReconConfigService;
import com.cwan.pbor.cash.recon.api.impl.CashReconConfigServiceImpl;
import com.cwan.pbor.cash.recon.entity.CashReconConfigEntity;
import com.cwan.pbor.cash.recon.repository.CashReconConfigRepository;
import com.cwan.pbor.cash.recon.transformer.CashReconConfigTransformer;
import com.cwan.pbor.cash.recon.transformer.CustodyFeedConfigTransformer;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Mono;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class CashReconConfigServiceTest {

  public static final List<CashReconConfigEntity> CASHRECONCONFIGENTITY_LIST =
      List.of(TestUtil.getCashReconConfigEntityByAccIdAndSecId(1L, 1L));
  public static final List<CashReconConfig> EXPECTED_CASHRECONCONFIG_LIST =
      List.of(TestUtil.getCashReconConfigByAccIdAndSecId(1L, 1L));
  @Mock private CashReconConfigRepository cashReconConfigRepository;

  private CashReconConfigService cashReconConfigService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    CashReconConfigTransformer cashReconConfigTransformer =
        new CashReconConfigTransformer(new CustodyFeedConfigTransformer());
    cashReconConfigService =
        new CashReconConfigServiceImpl(cashReconConfigRepository, cashReconConfigTransformer);
  }

  @Test
  void test_should_successfully_get_empty_cash_recon_config_for_accId_and_secId() {
    when(cashReconConfigRepository.findByAccountIdAndSecurityId(1, 1))
        .thenReturn(TestUtil.getEmptyCashReconConfigEntityByAccIdAndSecId(1L, 1L));
    Mono<CashReconConfig> cashReconConfigForAccIdAndSecIdMono =
        cashReconConfigService.getCashReconConfigForAccIdAndSecId(1, 1);
    CashReconConfig actualCashReconConfig = cashReconConfigForAccIdAndSecIdMono.block();
    Assertions.assertEquals(
        TestUtil.getEmptyCashReconConfigByAccIdAndSecId(1L, 1L), actualCashReconConfig);
  }

  @Test
  void test_should_successfully_get_empty_cash_recon_config_for_accId_and_secId_and_currency() {
    when(cashReconConfigRepository.findByAccountIdAndSecurityIdAndCurrencyIgnoreCase(1, 1, "USD"))
        .thenReturn(
            TestUtil.getEmptyCashReconConfigEntityByAccIdAndSecIdAndCurrency(1L, 1L, "USD"));
    Mono<CashReconConfig> cashReconConfigMono =
        cashReconConfigService.getCashReconConfigForAccIdAndSecIdAndCurrency(1, 1, "USD");
    CashReconConfig actualCashReconConfig = cashReconConfigMono.block();
    Assertions.assertEquals(
        TestUtil.getEmptyCashReconConfigByAccIdAndSecIdAndCurrency(1L, 1L, "USD"),
        actualCashReconConfig);
  }

  @Test
  void test_should_successfully_get_cash_recon_config_for_accId_and_secId() {
    when(cashReconConfigRepository.findByAccountIdAndSecurityId(1, 1))
        .thenReturn(TestUtil.getCashReconConfigEntityByAccIdAndSecId(1L, 1L));
    Mono<CashReconConfig> cashReconConfigForAccIdAndSecIdMono =
        cashReconConfigService.getCashReconConfigForAccIdAndSecId(1, 1);
    CashReconConfig actualCashReconConfig = cashReconConfigForAccIdAndSecIdMono.block();
    Assertions.assertEquals(
        TestUtil.getCashReconConfigByAccIdAndSecId(1L, 1L), actualCashReconConfig);
  }

  @Test
  void test_should_successfully_get_cash_recon_config_for_accId_and_secId_and_currency() {
    when(cashReconConfigRepository.findByAccountIdAndSecurityIdAndCurrencyIgnoreCase(1, 1, "USD"))
        .thenReturn(TestUtil.getCashReconConfigEntityByAccIdAndSecIdAndCurrency(1L, 1L, "USD"));
    Mono<CashReconConfig> cashReconConfigMono =
        cashReconConfigService.getCashReconConfigForAccIdAndSecIdAndCurrency(1, 1, "USD");
    CashReconConfig actualCashReconConfig = cashReconConfigMono.block();
    Assertions.assertEquals(
        TestUtil.getCashReconConfigByAccIdAndSecIdAndCurrency(1L, 1L, "USD"),
        actualCashReconConfig);
  }

  @Test
  void
      test_should_successfully_get_all_cash_recon_config_for_contribution_custody_feed_config_id() {
    when(cashReconConfigRepository.findAllByContributionCustodyFeedConfigEntity_Id(2))
        .thenReturn(CASHRECONCONFIGENTITY_LIST);
    List<CashReconConfig> actualCashReconConfigList =
        cashReconConfigService
            .getAllCashReconConfigForContributionCustodyFeedConfigId(2L)
            .collectList()
            .block();
    Assertions.assertEquals(EXPECTED_CASHRECONCONFIG_LIST, actualCashReconConfigList);
  }

  @Test
  void test_should_successfully_get_all_cash_recon_config_for_accIds_and_secIds() {
    when(cashReconConfigRepository.findAllByAccountIdInAndSecurityIdIn(any(), any()))
        .thenReturn(CASHRECONCONFIGENTITY_LIST);
    List<CashReconConfig> actualCashReconConfigList =
        cashReconConfigService
            .getAllCashReconConfigForAccIdListAndSecIdList(List.of(1L), List.of(2L))
            .collectList()
            .block();
    Assertions.assertEquals(EXPECTED_CASHRECONCONFIG_LIST, actualCashReconConfigList);
  }
}
