package com.cwan.pbor.cash.recon;

import com.cwan.lpx.domain.CashReconConfig;
import com.cwan.lpx.domain.CustodyFeedConfig;
import com.cwan.lpx.domain.CustodyTransaction;
import com.cwan.lpx.domain.ReconciliationStatus;
import com.cwan.pbor.cash.recon.entity.CashReconConfigEntity;
import com.cwan.pbor.cash.recon.entity.CustodyFeedConfigEntity;
import com.cwan.pbor.cash.recon.entity.CustodyTransactionEntity;
import java.time.LocalDate;

public class TestUtil {

  public static CashReconConfigEntity getEmptyCashReconConfigEntityByAccIdAndSecId(
      Long accountId, Long securityId) {
    return CashReconConfigEntity.builder()
        .id(1L)
        .accountId(accountId)
        .securityId(securityId)
        .createdBy("TEST")
        .distributionCustodyFeedConfigEntity(null)
        .contributionCustodyFeedConfigEntity(null)
        .build();
  }

  public static CashReconConfigEntity getEmptyCashReconConfigEntityByAccIdAndSecIdAndCurrency(
      Long accountId, Long securityId, String currency) {
    CashReconConfigEntity cashReconConfigEntity =
        getEmptyCashReconConfigEntityByAccIdAndSecId(accountId, securityId);
    cashReconConfigEntity.setCurrency(currency);
    return cashReconConfigEntity;
  }

  public static CashReconConfigEntity getCashReconConfigEntityByAccIdAndSecId(
      Long accountId, Long securityId) {
    return CashReconConfigEntity.builder()
        .id(2L)
        .accountId(accountId)
        .securityId(securityId)
        .createdBy("TEST")
        .distributionCustodyFeedConfigEntity(
            CustodyFeedConfigEntity.builder()
                .name("Test Distribution Custody Feed Config")
                .id(2L)
                .cashAccountNumber("123")
                .custodyAccountId(1L)
                .createdBy("SYSTEM")
                .build())
        .contributionCustodyFeedConfigEntity(
            CustodyFeedConfigEntity.builder()
                .name("Test Contribution Custody Feed Config")
                .id(1L)
                .cashAccountNumber("456")
                .custodyAccountId(2L)
                .createdBy("SYSTEM")
                .build())
        .build();
  }

  public static CashReconConfigEntity getCashReconConfigEntityByAccIdAndSecIdAndCurrency(
      Long accountId, Long securityId, String currency) {
    CashReconConfigEntity cashReconConfigEntity =
        getCashReconConfigEntityByAccIdAndSecId(accountId, securityId);
    cashReconConfigEntity.setCurrency(currency);
    return cashReconConfigEntity;
  }

  public static CashReconConfig getEmptyCashReconConfigByAccIdAndSecId(
      Long accountId, Long securityId) {
    return CashReconConfig.builder()
        .id(1L)
        .accountId(accountId)
        .securityId(securityId)
        .createdBy("TEST")
        .distributionCustodyFeedConfig(null)
        .contributionCustodyFeedConfig(null)
        .build();
  }

  public static CashReconConfig getEmptyCashReconConfigByAccIdAndSecIdAndCurrency(
      Long accountId, Long securityId, String currency) {
    CashReconConfig cashReconConfig = getEmptyCashReconConfigByAccIdAndSecId(accountId, securityId);
    cashReconConfig.setCurrency(currency);
    return cashReconConfig;
  }

  public static CashReconConfig getCashReconConfigByAccIdAndSecId(Long accountId, Long securityId) {
    return CashReconConfig.builder()
        .id(2L)
        .accountId(accountId)
        .securityId(securityId)
        .createdBy("TEST")
        .distributionCustodyFeedConfig(
            CustodyFeedConfig.builder()
                .name("Test Distribution Custody Feed Config")
                .id(2L)
                .cashAccountNumber("123")
                .custodyAccountId(1L)
                .createdBy("SYSTEM")
                .build())
        .contributionCustodyFeedConfig(
            CustodyFeedConfig.builder()
                .name("Test Contribution Custody Feed Config")
                .id(1L)
                .cashAccountNumber("456")
                .custodyAccountId(2L)
                .createdBy("SYSTEM")
                .build())
        .build();
  }

  public static CashReconConfig getCashReconConfigByAccIdAndSecIdAndCurrency(
      Long accountId, Long securityId, String currency) {
    CashReconConfig cashReconConfig = getCashReconConfigByAccIdAndSecId(accountId, securityId);
    cashReconConfig.setCurrency(currency);
    return cashReconConfig;
  }

  public static CustodyFeedConfigEntity getCustodyFeedConfigEntity() {
    return CustodyFeedConfigEntity.builder()
        .id(1L)
        .name("TEST CUSTODY FEED CONFIG")
        .custodyAccountId(1L)
        .cashAccountNumber("0034158400")
        .createdBy("SYSTEM")
        .build();
  }

  public static CustodyFeedConfig getCustodyFeedConfig() {
    return CustodyFeedConfig.builder()
        .id(1L)
        .name("TEST CUSTODY FEED CONFIG")
        .custodyAccountId(1L)
        .cashAccountNumber("0034158400")
        .createdBy("SYSTEM")
        .build();
  }

  public static CustodyTransactionEntity getCustodyTransactionEntity() {
    return CustodyTransactionEntity.builder()
        .id(1L)
        .transactionAmountLocal(-10000.01)
        .transactionAmountReporting(-10000.01)
        .localCurrencyCode("USD")
        .reportingCurrencyCode("USD")
        .transactionType("CAPC")
        .transactionSubType("CASH_WITHDRAW")
        .fileId(1L)
        .comment("Dummy Comment")
        .transactionDate(LocalDate.now())
        .reconciliationDate(LocalDate.now())
        .transactionDetail("DEMO BANK TRANSACTION DESCRIPTION")
        .reconciliationStatus(ReconciliationStatus.MISMATCH)
        .securityId(123L)
        .custodyAccountId(335314L)
        .cashAccountNumber("00834000457")
        .dataSource("PROMETHEUS")
        .isCreatedByInternalUser(false)
        .isModifiedByInternalUser(null)
        .createdBy("SYSTEM")
        .modifiedBy(null)
        .reason("ADDITIONAL TRANSACTION")
        .uploadedDocCanoeId("648ca7ae-1508-4cea-832a-c50824ff4221")
        .docUploadedBy("ptiwari@clearwateranalytics.com")
        .build();
  }

  public static CustodyTransaction getCustodyTransaction() {
    return CustodyTransaction.builder()
        .id(1L)
        .amountInLocalCurrency(-10000.01)
        .amountInReportingCurrency(-10000.01)
        .localCurrencyCode("USD")
        .reportingCurrencyCode("USD")
        .transactionType("CAPC")
        .transactionSubType("CASH_WITHDRAW")
        .fileId(1L)
        .comment("Dummy Comment")
        .transactionDate(LocalDate.now())
        .reconcileDate(LocalDate.now())
        .reconciliationStatus(ReconciliationStatus.MISMATCH)
        .securityId(123L)
        .custodyAccountId(335314L)
        .cashAccountNumber("00834000457")
        .dataSource("PROMETHEUS")
        .isCreatedByInternalUser(false)
        .isModifiedByInternalUser(null)
        .createdBy("SYSTEM")
        .modifiedBy(null)
        .transactionDescription("DEMO BANK TRANSACTION DESCRIPTION")
        .reason("ADDITIONAL TRANSACTION")
        .uploadedDocCanoeId("648ca7ae-1508-4cea-832a-c50824ff4221")
        .docUploadedBy("ptiwari@clearwateranalytics.com")
        .build();
  }
}
