package com.cwan.pbor.cash.recon;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.cwan.lpx.domain.ReconciliationType;
import org.junit.jupiter.api.Test;

class ReconciliationTypeTest {

  @Test
  void test_reconciliation_type_values() {
    assertEquals("Capital Call Notice", ReconciliationType.CONTRIBUTION.getDocType());
    assertEquals("CAPC", ReconciliationType.CONTRIBUTION.getTransactionCode());
    assertEquals("CW", ReconciliationType.CONTRIBUTION.getCustodyTransactionCode());
    assertEquals("Capital Distribution Notice", ReconciliationType.DISTRIBUTION.getDocType());
    assertEquals("CAPD", ReconciliationType.DISTRIBUTION.getTransactionCode());
    assertEquals("CD", ReconciliationType.DISTRIBUTION.getCustodyTransactionCode());
  }

  @Test
  void test_from_transaction_code() {
    assertNull(ReconciliationType.fromTransactionCode("TEST"));
    assertEquals(ReconciliationType.CONTRIBUTION, ReconciliationType.fromTransactionCode("CAPC"));
    assertEquals(ReconciliationType.DISTRIBUTION, ReconciliationType.fromTransactionCode("CAPD"));
  }
}
