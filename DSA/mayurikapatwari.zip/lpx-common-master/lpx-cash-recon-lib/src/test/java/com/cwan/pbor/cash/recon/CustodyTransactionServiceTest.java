package com.cwan.pbor.cash.recon;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CustodyTransaction;
import com.cwan.lpx.domain.ReconciliationStatus;
import com.cwan.pbor.cash.recon.api.CustodyTransactionService;
import com.cwan.pbor.cash.recon.api.impl.CustodyTransactionServiceImpl;
import com.cwan.pbor.cash.recon.repository.CustodyTransactionRepository;
import com.cwan.pbor.cash.recon.transformer.CustodyTransactionTransformer;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class CustodyTransactionServiceTest {

  @Mock private CustodyTransactionRepository custodyTransactionRepository;

  private CustodyTransactionService custodyTransactionService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    custodyTransactionService =
        new CustodyTransactionServiceImpl(
            custodyTransactionRepository, new CustodyTransactionTransformer());
  }

  @Test
  void
      test_should_get_all_custody_transaction_using_securityId_cash_account_number_custody_accountId_recon_status_and_transaction_date_between() {
    when(custodyTransactionRepository
            .findAllBySecurityIdAndCashAccountNumberAndCustodyAccountIdAndReconciliationStatusAndTransactionDateBetween(
                any(), any(), any(), any(), any(), any()))
        .thenReturn(List.of(TestUtil.getCustodyTransactionEntity()));
    List<CustodyTransaction> actualCustodyTransactions =
        custodyTransactionService
            .getAllCustodyTransactionUsingSecIdAndCashAccNoAndCusAccIdAndReconStatusAndTransDateBetween(
                123L,
                "00834000457",
                335314L,
                ReconciliationStatus.MISMATCH,
                LocalDate.now().minusDays(3),
                LocalDate.now())
            .collectList()
            .block();
    Assertions.assertEquals(List.of(TestUtil.getCustodyTransaction()), actualCustodyTransactions);
  }
}
