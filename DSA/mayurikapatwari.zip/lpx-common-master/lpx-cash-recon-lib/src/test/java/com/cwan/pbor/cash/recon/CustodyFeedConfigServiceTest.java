package com.cwan.pbor.cash.recon;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.CustodyFeedConfig;
import com.cwan.pbor.cash.recon.api.CustodyFeedConfigService;
import com.cwan.pbor.cash.recon.api.impl.CustodyFeedConfigServiceImpl;
import com.cwan.pbor.cash.recon.repository.CustodyFeedConfigRepository;
import com.cwan.pbor.cash.recon.transformer.CustodyFeedConfigTransformer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class CustodyFeedConfigServiceTest {

  @Mock private CustodyFeedConfigRepository custodyFeedConfigRepository;

  private CustodyFeedConfigService custodyFeedConfigService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    custodyFeedConfigService =
        new CustodyFeedConfigServiceImpl(
            custodyFeedConfigRepository, new CustodyFeedConfigTransformer());
  }

  @Test
  void test_should_get_custody_feed_config_by_cash_account_number_and_custody_account_id() {
    when(custodyFeedConfigRepository.findByCustodyAccountIdAndCashAccountNumber(any(), any()))
        .thenReturn(TestUtil.getCustodyFeedConfigEntity());
    CustodyFeedConfig actualCustodyFeedConfig =
        custodyFeedConfigService
            .getCustodyFeedConfigUsingCusAccIdAndCashAccNo(1L, "0038400")
            .block();
    Assertions.assertEquals(TestUtil.getCustodyFeedConfig(), actualCustodyFeedConfig);
  }
}
