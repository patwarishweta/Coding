package com.cwan.pbor.accountconfig.client.rules;

import java.util.Objects;
import java.util.stream.Stream;
import lombok.Data;

@Data
public class RatesRuleResults {

  private String navImpactMultiplier;
  private String cashImpactMultiplier;
  private String unfundedCommitmentImpactMultiplier;
  private String recallableImpactMultiplier;
  private String transactionType;
  private String transactionSubType;
  private String entryDate;
  private String settleDate;
  private String tradeDate;

  public boolean isRatesRuleResultsNonEmpty() {
    return Stream.of(
            navImpactMultiplier,
            cashImpactMultiplier,
            transactionType,
            unfundedCommitmentImpactMultiplier,
            recallableImpactMultiplier,
            transactionSubType,
            entryDate,
            settleDate,
            tradeDate)
        .anyMatch(Objects::nonNull);
  }
}
