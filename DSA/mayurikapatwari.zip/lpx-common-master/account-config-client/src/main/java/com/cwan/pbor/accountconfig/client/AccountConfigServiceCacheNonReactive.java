package com.cwan.pbor.accountconfig.client;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.google.common.cache.Cache;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccountConfigServiceCacheNonReactive {

  private final AccountConfigServiceApacheClient accountConfigServiceApacheClient;
  private final Cache<Long, AccountConfig> accountIdToAccountConfigCacheNonReactive;
  private final Cache<Long, Set<AccountSubscriptionRule>> accountIdToAccountRulesCacheNonReactive;

  public AccountConfigServiceCacheNonReactive(
      AccountConfigServiceApacheClient accountConfigServiceApacheClient,
      Cache<Long, AccountConfig> accountIdToAccountConfigCacheNonReactive,
      Cache<Long, Set<AccountSubscriptionRule>> accountIdToAccountRulesCacheNonReactive) {
    this.accountConfigServiceApacheClient = accountConfigServiceApacheClient;
    this.accountIdToAccountConfigCacheNonReactive = accountIdToAccountConfigCacheNonReactive;
    this.accountIdToAccountRulesCacheNonReactive = accountIdToAccountRulesCacheNonReactive;
  }

  public AccountConfig getByAccountId(Long accountId) {
    try {
      return accountIdToAccountConfigCacheNonReactive.get(
          accountId, () -> accountConfigServiceApacheClient.getByAccountId(accountId));
    } catch (ExecutionException e) {
      throw new AccountConfigServiceException(
          accountId + " Exception during getByAccountId::\n " + e);
    }
  }

  public Set<AccountSubscriptionRule> getAccountRulesByAccountConfigId(Long accountConfigId) {
    try {
      return accountIdToAccountRulesCacheNonReactive.get(
          accountConfigId,
          () ->
              accountConfigServiceApacheClient.getAccountSubscriptionRules(
                  Set.of(accountConfigId)));
    } catch (ExecutionException e) {
      throw new AccountConfigServiceException(
          accountConfigId + " Exception during getAccountRulesByAccountConfigId::\n " + e);
    }
  }

  public Set<AccountSubscriptionRule> getAccountRulesByAccountId(Long accountId) {
    AccountConfig config = getByAccountId(accountId);
    return getAccountRulesByAccountConfigId(config.getId());
  }
}
