package com.cwan.pbor.accountconfig.client.rules;

import com.cwan.pbor.accountconfig.client.AccountConfigUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

public interface Rules {

  Boolean isRuleMatched(RuleKeyAndResults ruleKeyAndResults);

  Object fetchRule(RuleKeyAndResults ruleKeyAndResults);

  static ObjectMapper getObjectMapper() {
    return AccountConfigUtils.objectMapper();
  }
}
