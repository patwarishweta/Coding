package com.cwan.pbor.accountconfig.client.rules;

public class Constants {

  public static final String MANUAL = "MANUAL";
  public static final String TRANSACTION_TYPE = "transactionType";
  public static final String TRANSACTION_SUB_TYPE = "transactionSubType";
  public static final String CASH_IMPACT = "cashImpact";
  public static final String DATA_SOURCE = "dataSource";
  public static final String EQUAL_OPERATOR = "=";
  public static final String NOT_EQUAL_OPERATOR = "!=";
  public static final String IN_OPERATOR = "in";
  public static final String NOT_IN_OPERATOR = "notIn";
  public static final String LESS_THAN_OPERATOR = "<";
  public static final String LESS_THAN_EQUAL_OPERATOR = "<=";
  public static final String GREATER_THAN_OPERATOR = ">";
  public static final String GREATER_THAN_EQUAL_OPERATOR = ">=";
  public static final String NULL_CHECK_OPERATOR = "null";
  public static final String NOT_NULL_CHECK_OPERATOR = "notNull";

  public static final String LIKE_OPERATOR = "like";
}
