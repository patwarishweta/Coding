package com.cwan.pbor.accountconfig.client;

import com.ca.json2.utils.JsonUtils2;
import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.http.MimeType;
import com.ca.wsclient3.request.GetRequest;
import com.ca.wsclient3.request.RequestPostcondition;
import com.ca.wsclient3.request.RetryCountAttemptHandler;
import com.ca.wsclient3.request.WsHttpClient;
import com.ca.wsclient3.resource.Resource;
import com.ca.wsclient3.resource.ResourceBuilder;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.InputStream;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountConfigServiceApacheClient {

  private final WsHttpClient wsHttpClient;
  private final Resource accountSubscriptionResource;
  private final Resource accountRulesResource;

  public AccountConfigServiceApacheClient(
      WsHttpClient wsHttpClient, ServerConfiguration serverConfiguration) {
    this.wsHttpClient = wsHttpClient;
    this.accountSubscriptionResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("account/subscription")
            .withAcceptType(MimeType.JSON)
            .toResource();
    this.accountRulesResource =
        new ResourceBuilder()
            .forService(serverConfiguration)
            .forResource("account/rules")
            .withAcceptType(MimeType.JSON)
            .toResource();
  }

  public AccountConfig getByAccountId(Long accountId) {
    GetRequest request =
        accountSubscriptionResource
            .doGET(wsHttpClient)
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addQueryParam("accountIds", accountId)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      List<AccountConfig> accountConfigList = JsonUtils2.parseJson(is, new TypeReference<>() {});
      return accountConfigList == null || accountConfigList.isEmpty()
          ? null
          : accountConfigList.get(0);
    } catch (Exception e) {
      log.error("AccountConfigServiceApacheClient getByAccountId for accountId: {}", accountId, e);
      throw new RuntimeException(e);
    }
  }

  public Set<AccountSubscriptionRule> getAccountSubscriptionRules(Set<Long> subscriptionIds) {
    GetRequest request =
        accountRulesResource
            .doGET(wsHttpClient)
            .withHeader("Content-Type", "application/x-www-form-urlencoded")
            .addQueryParam("subscriptionIds", subscriptionIds)
            .withRequestPostconditions(RequestPostcondition.STATUS_SUCCESSFUL)
            .withAttemptHandler(new RetryCountAttemptHandler(3));

    try (InputStream is = request.executeRequestAsHttpStream()) {
      return JsonUtils2.parseJson(is, new TypeReference<>() {});
    } catch (Exception e) {
      log.error(
          "AccountConfigServiceApacheClient getAccountSubscriptionRule for subscriptionIds: {}",
          subscriptionIds,
          e);
      throw new RuntimeException(e);
    }
  }
}
