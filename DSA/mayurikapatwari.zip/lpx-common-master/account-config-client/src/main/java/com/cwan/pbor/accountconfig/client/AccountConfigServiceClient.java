package com.cwan.pbor.accountconfig.client;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import java.net.UnknownHostException;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class AccountConfigServiceClient {

  private final WebClient accountConfigServiceWebClient;

  public AccountConfigServiceClient(WebClient accountConfigServiceWebClient) {
    this.accountConfigServiceWebClient = accountConfigServiceWebClient;
  }

  public Flux<AccountConfig> getByAccountId(Long accountId) {
    return accountConfigServiceWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/account/subscription")
                    .queryParam("accountIds", accountId)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToFlux(AccountConfig.class);
  }

  public Flux<AccountSubscriptionRule> getAccountSubscriptionRule(Set<Long> subscriptionIds) {
    return accountConfigServiceWebClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder
                    .path("/account/rules")
                    .queryParam("subscriptionIds", subscriptionIds)
                    .build())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                Mono.error(
                    new AccountConfigServiceException("is4xxClientError Exception " + response)))
        .onStatus(
            HttpStatusCode::is5xxServerError,
            response ->
                Mono.error(
                    new AccountConfigServiceException("is5xxServerError Exception " + response)))
        .bodyToFlux(AccountSubscriptionRule.class)
        .onErrorResume(
            e -> {
              if (e instanceof UnknownHostException) {
                log.error(
                    "Failed to get response, desired service not present :: UnknownHostException \n",
                    e);
              } else {
                log.error("Failed to received response due to ", e);
              }
              log.error(
                  "Exception occured during accountRules Loading {} \n {}", subscriptionIds, e);
              return Flux.empty();
            });
  }
}
