package com.cwan.pbor.accountconfig.client.rules;

import java.util.List;
import lombok.Data;

@Data
public class RuleKey {

  private String fieldName;
  private String operator;
  private List<String> fieldValue;
}
