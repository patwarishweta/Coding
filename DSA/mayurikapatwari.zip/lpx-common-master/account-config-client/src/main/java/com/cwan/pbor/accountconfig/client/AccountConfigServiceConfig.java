package com.cwan.pbor.accountconfig.client;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.WsHttpClientBuilder;
import com.ca.wsclient3.resource.Resource;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Configuration
public class AccountConfigServiceConfig {

  @Value("${account-config-service.base.url}")
  private String accountConfigServiceBaseUrl;

  @Value("${account-config-service.base.server}")
  private String accountConfigServiceBaseServer;

  @Value("${account-config-service.cache.maxsize}")
  private Integer maxCacheSize;

  @Value("${account-config-service.cache.timeout.hours}")
  private Integer cacheDurationHrs;

  @Bean(value = "accountConfigServiceWebClient")
  WebClient accountConfigServiceWebClient() {
    return WebClient.builder().baseUrl(accountConfigServiceBaseUrl).build();
  }

  @Bean(value = "accountConfigServiceApacheClient")
  AccountConfigServiceApacheClient accountConfigServiceApacheClient() {
    ServerConfiguration serverConfiguration =
        new ServerConfiguration(
            accountConfigServiceBaseServer, 443, "account-config-service", Resource.Scheme.HTTPS);
    return new AccountConfigServiceApacheClient(
        WsHttpClientBuilder.getSharedDefault(), serverConfiguration);
  }

  @Bean(value = "accountIdToAccountConfigCache")
  Cache<Long, Flux<AccountConfig>> accountIdToAccountConfigCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "accountIdToAccountRulesCache")
  Cache<Long, Flux<AccountSubscriptionRule>> accountIdToAccountRulesCache() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "accountIdToAccountConfigCacheNonReactive")
  Cache<Long, AccountConfig> accountIdToAccountConfigCacheNonReactive() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }

  @Bean(value = "accountIdToAccountRulesCacheNonReactive")
  Cache<Long, Set<AccountSubscriptionRule>> accountIdToAccountRulesCacheNonReactive() {
    return CacheBuilder.newBuilder()
        .maximumSize(maxCacheSize)
        .expireAfterWrite(cacheDurationHrs, TimeUnit.HOURS)
        .build();
  }
}
