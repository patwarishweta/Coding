package com.cwan.pbor.accountconfig.client.rules;

import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class RuleKeyAndResults {

  private List<RuleKey> ruleKeys;
  private Map<String, String> ruleResults;
}
