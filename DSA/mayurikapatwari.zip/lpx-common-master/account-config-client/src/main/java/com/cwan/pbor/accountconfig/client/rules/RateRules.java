package com.cwan.pbor.accountconfig.client.rules;

import java.util.List;
import org.apache.commons.lang3.tuple.ImmutablePair;

public interface RateRules<E> extends Rules {

  default Boolean isRuleMatched(RuleKeyAndResults ruleKeyAndResults) {
    if (ruleKeyAndResults == null) {
      return Boolean.FALSE;
    }
    List<RuleKey> ratesRuleKeys = ruleKeyAndResults.getRuleKeys();
    RatesRuleResults ratesRuleResults =
        Rules.getObjectMapper()
            .convertValue(ruleKeyAndResults.getRuleResults(), RatesRuleResults.class);
    if (ratesRuleKeys == null || ratesRuleResults == null) {
      return Boolean.FALSE;
    }
    if (!ratesRuleKeys.isEmpty() && ratesRuleResults.isRatesRuleResultsNonEmpty()) {
      return Boolean.TRUE;
    }
    return Boolean.FALSE;
  }

  @Override
  default ImmutablePair<List<RuleKey>, RatesRuleResults> fetchRule(
      RuleKeyAndResults ruleKeyAndResults) {
    Boolean ruleMatched = isRuleMatched(ruleKeyAndResults);
    if (Boolean.TRUE.equals(ruleMatched)) {
      List<RuleKey> ratesRuleKeys = ruleKeyAndResults.getRuleKeys();
      RatesRuleResults ratesRuleResults =
          Rules.getObjectMapper()
              .convertValue(ruleKeyAndResults.getRuleResults(), RatesRuleResults.class);
      return new ImmutablePair<>(ratesRuleKeys, ratesRuleResults);
    }
    return null;
  }

  void applyRule(E e, AccountSubscriptionRule accountSubscriptionRule);
}
