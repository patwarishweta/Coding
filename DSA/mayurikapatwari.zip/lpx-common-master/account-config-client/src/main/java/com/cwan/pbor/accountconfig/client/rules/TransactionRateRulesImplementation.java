package com.cwan.pbor.accountconfig.client.rules;

import static com.cwan.pbor.accountconfig.client.rules.Constants.CASH_IMPACT;
import static com.cwan.pbor.accountconfig.client.rules.Constants.DATA_SOURCE;
import static com.cwan.pbor.accountconfig.client.rules.Constants.EQUAL_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.GREATER_THAN_EQUAL_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.GREATER_THAN_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.IN_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.LESS_THAN_EQUAL_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.LESS_THAN_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.LIKE_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.MANUAL;
import static com.cwan.pbor.accountconfig.client.rules.Constants.NOT_EQUAL_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.NOT_IN_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.NOT_NULL_CHECK_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.NULL_CHECK_OPERATOR;
import static com.cwan.pbor.accountconfig.client.rules.Constants.TRANSACTION_SUB_TYPE;
import static com.cwan.pbor.accountconfig.client.rules.Constants.TRANSACTION_TYPE;

import com.cwan.lpx.domain.Transaction;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TransactionRateRulesImplementation implements RateRules<Transaction> {

  @Override
  public void applyRule(Transaction transaction, AccountSubscriptionRule accountSubscriptionRule) {
    try {
      if (Objects.equals(
              transaction.getSecurity().getSecurityId(), accountSubscriptionRule.getSecurityId())
          || accountSubscriptionRule.getSecurityId() == null) {

        ImmutablePair<List<RuleKey>, RatesRuleResults> pair =
            fetchRule(accountSubscriptionRule.getRuleKeyAndResults());
        log.info("Rule Pair {}", pair);
        if (pair == null) {
          log.info(
              "RatesRuleDefinition not found for Account:{} accountSubscriptionRule:{}",
              transaction.getAccount().getId(),
              accountSubscriptionRule);
        } else {
          ruleParser(pair.left, pair.right, transaction);
        }
      } else {
        log.info(
            "Skipping rule application as securityId doesn't match for Account:{}, securityId:{}",
            transaction.getAccount().getId(),
            accountSubscriptionRule.getSecurityId());
      }
    } catch (ClassCastException ex) {
      log.error("Unable to parse rules", ex);
    }
  }

  private void ruleParser(
      List<RuleKey> ruleKeys, RatesRuleResults ratesRuleResults, Transaction transaction) {
    if ((!(MANUAL.equals(transaction.getDataSource()))) && ruleInputParser(ruleKeys, transaction)) {
      log.info(
          "Rules Input Matched for accountId:{} txnType:{} txnSubType:{} Rule:{}-{}",
          transaction.getAccount().getId(),
          transaction.getType(),
          transaction.getSubType(),
          ruleKeys,
          ratesRuleResults);
      ruleResultParser(ratesRuleResults, transaction);
      log.info("After Rule Apply: Result:{} \n {}", ratesRuleResults, transaction);
    }
  }

  boolean ruleInputParser(List<RuleKey> ruleKeys, Transaction transaction) {
    if (ruleKeys.isEmpty()) {
      return false;
    }
    final boolean[] isRuleKeysMatched = {true};
    Long accountId = transaction.getAccount().getId();
    Long securityId = transaction.getSecurity().getSecurityId();
    Long txnId = transaction.getId();
    return ruleKeys.stream()
        .map(
            ruleKey -> {
              switch (ruleKey.getFieldName().trim()) {
                case TRANSACTION_TYPE -> {
                  isRuleKeysMatched[0] =
                      operatorHandling(
                          ruleKey, transaction.getType(), accountId, securityId, txnId);
                  log.info(
                      "TRANSACTION_TYPE input APPLIED:{} accId:{} txnType:{} txnSubType:{} Rule:{}",
                      isRuleKeysMatched[0],
                      accountId,
                      transaction.getType(),
                      transaction.getSubType(),
                      ruleKey);
                  return isRuleKeysMatched[0];
                }
                case TRANSACTION_SUB_TYPE -> {
                  isRuleKeysMatched[0] =
                      operatorHandling(
                          ruleKey, transaction.getSubType(), accountId, securityId, txnId);
                  log.info(
                      "TRANSACTION_SUB_TYPE input APPLIED:{} accId:{} txnType:{} txnSubType:{} Rule:{}",
                      isRuleKeysMatched[0],
                      accountId,
                      transaction.getType(),
                      transaction.getSubType(),
                      ruleKey);
                  return isRuleKeysMatched[0];
                }
                case CASH_IMPACT -> {
                  if (transaction.getCashImpact() == null) {
                    log.info(
                        "cash impact is null for accountId: {}", transaction.getAccount().getId());
                    return false;
                  }
                  isRuleKeysMatched[0] =
                      operatorHandling(
                          ruleKey,
                          transaction.getCashImpact().toString(),
                          accountId,
                          securityId,
                          txnId);
                  log.info(
                      "CASH_IMPACT input APPLIED:{} accId:{} cashImpact:{} txnType:{} txnSubType:{} Rule:{}",
                      isRuleKeysMatched[0],
                      accountId,
                      transaction.getCashImpact(),
                      transaction.getType(),
                      transaction.getSubType(),
                      ruleKey);
                  return isRuleKeysMatched[0];
                }
                case DATA_SOURCE -> {
                  isRuleKeysMatched[0] =
                      operatorHandling(
                          ruleKey, transaction.getDataSource(), accountId, securityId, txnId);
                  log.info(
                      "DATA_SOURCE input APPLIED:{} accId:{} dataSource:{} txnType:{} txnSubType:{} Rule:{}",
                      isRuleKeysMatched[0],
                      accountId,
                      transaction.getDataSource(),
                      transaction.getType(),
                      transaction.getSubType(),
                      ruleKey);
                  return isRuleKeysMatched[0];
                }
                default -> {
                  return false;
                }
              }
            })
        .reduce(Boolean::logicalAnd)
        .orElse(Boolean.FALSE);
  }

  boolean operatorHandling(
      RuleKey rulekey, String inputTxnValue, Long accountId, Long securityId, Long txnId) {
    if (rulekey.getOperator() == null) {
      return false;
    }
    try {
      return switch (rulekey.getOperator().trim()) {
        case EQUAL_OPERATOR -> rulekey.getFieldValue().get(0).trim().equals(inputTxnValue);
        case NOT_EQUAL_OPERATOR -> !rulekey.getFieldValue().get(0).trim().equals(inputTxnValue);
        case IN_OPERATOR -> inOperator(rulekey.getFieldValue(), inputTxnValue);
        case NOT_IN_OPERATOR -> !inOperator(rulekey.getFieldValue(), inputTxnValue);
        case LESS_THAN_OPERATOR ->
            Double.parseDouble(inputTxnValue)
                < Double.parseDouble(rulekey.getFieldValue().get(0).trim());
        case GREATER_THAN_OPERATOR ->
            Double.parseDouble(inputTxnValue)
                > Double.parseDouble(rulekey.getFieldValue().get(0).trim());
        case LESS_THAN_EQUAL_OPERATOR ->
            Double.parseDouble(inputTxnValue)
                <= Double.parseDouble(rulekey.getFieldValue().get(0).trim());
        case GREATER_THAN_EQUAL_OPERATOR ->
            Double.parseDouble(inputTxnValue)
                >= Double.parseDouble(rulekey.getFieldValue().get(0).trim());
        case NULL_CHECK_OPERATOR -> inputTxnValue == null;
        case NOT_NULL_CHECK_OPERATOR -> inputTxnValue != null;
        case LIKE_OPERATOR ->
            Optional.ofNullable(inputTxnValue)
                .map(
                    val ->
                        rulekey.getFieldValue().stream()
                            .anyMatch(oper -> val.contains(oper.trim().toUpperCase())))
                .orElse(false);
        default ->
            throw new RuntimeException(
                MessageFormat.format(
                    "Operator not found during operator handling for "
                        + "accountId:{0} rulekey:{1} inputTxnValue:{2} txnId:{3}",
                    accountId, rulekey, inputTxnValue, txnId));
      };
    } catch (Exception e) {
      log.error(
          "Exception during applying rule for accountId {}, securityId {} txnId:{} with ruleKey{} \n {}",
          accountId,
          securityId,
          txnId,
          rulekey,
          Arrays.toString(e.getStackTrace()));
      return false;
    }
  }

  void ruleResultParser(RatesRuleResults ratesRuleResults, Transaction transaction) {
    if (ratesRuleResults.getTransactionType() != null) {
      log.info("UPDATING TxnType:{} -> {}", transaction, ratesRuleResults);
      transaction.setType(ratesRuleResults.getTransactionType());
    }
    if (ratesRuleResults.getTransactionSubType() != null) {
      log.info("UPDATING TxnSubType:{} -> {}", transaction, ratesRuleResults);
      transaction.setSubType(ratesRuleResults.getTransactionSubType());
    }
    if (ratesRuleResults.getEntryDate() != null) {
      log.info("UPDATING EntryDate:{} -> {}", transaction, ratesRuleResults);
      transaction.setEntryDate(LocalDate.parse(ratesRuleResults.getEntryDate()));
    }
    if (ratesRuleResults.getSettleDate() != null) {
      log.info("UPDATING SettleDate:{} -> {}", transaction, ratesRuleResults);
      transaction.setSettleDate(LocalDate.parse(ratesRuleResults.getSettleDate()));
    }
    if (ratesRuleResults.getTradeDate() != null) {
      log.info("UPDATING TradeDate:{} -> {}", transaction, ratesRuleResults);
      transaction.setTradeDate(LocalDate.parse(ratesRuleResults.getTradeDate()));
    }
    if (ratesRuleResults.getNavImpactMultiplier() != null) {
      log.info("UPDATING navImpactMultiplier:{} -> {}", transaction, ratesRuleResults);
      transaction.setNavImpact(
          transaction.getNetAmount()
              * Integer.parseInt(ratesRuleResults.getNavImpactMultiplier().trim()));
    }
    if (ratesRuleResults.getCashImpactMultiplier() != null) {
      log.info("UPDATING cashImpactMultiplier:{} -> {}", transaction, ratesRuleResults);
      transaction.setCashImpact(
          transaction.getNetAmount()
              * Integer.parseInt(ratesRuleResults.getCashImpactMultiplier().trim()));
    }
    if (ratesRuleResults.getRecallableImpactMultiplier() != null) {
      log.info("UPDATING recallableImpactMultiplier:{} -> {}", transaction, ratesRuleResults);
      transaction.setRecallableImpact(
          transaction.getRecallableImpact()
              * Integer.parseInt(ratesRuleResults.getRecallableImpactMultiplier().trim()));
    }
    if (ratesRuleResults.getUnfundedCommitmentImpactMultiplier() != null) {
      log.info(
          "UPDATING unfundedCommitmentImpactMultiplier:{} -> {}", transaction, ratesRuleResults);
      transaction.setUnfundedCommitmentImpact(
          transaction.getNetAmount()
              * Integer.parseInt(ratesRuleResults.getUnfundedCommitmentImpactMultiplier().trim()));
    }
  }

  private Boolean inOperator(List<String> ruleValues, String transactionValue) {
    return ruleValues.stream()
        .map(String::trim)
        .collect(Collectors.toList())
        .contains(transactionValue);
  }
}
