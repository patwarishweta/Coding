package com.cwan.pbor.accountconfig.client;

import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.cwan.pbor.accountconfig.client.rules.RateRules;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class AccountRulesExecutorService<E> {

  private final List<RateRules> rateRules;
  private final AccountConfigServiceCache accountConfigServiceCache;

  public AccountRulesExecutorService(
      List<RateRules> rateRules, AccountConfigServiceCache accountConfigServiceCache) {
    this.rateRules = rateRules;
    this.accountConfigServiceCache = accountConfigServiceCache;
  }

  public Flux<E> execute(Long accountId, E e) {
    return accountConfigServiceCache
        .getAccountRulesByAccountId(accountId)
        .filter(AccountSubscriptionRule::isActive)
        .sort(Comparator.comparing(AccountSubscriptionRule::getModifiedOn))
        .flatMap(
            accountSubscriptionRules -> {
              log.info("AccountSubscriptionRule Rule:{}", accountSubscriptionRules);
              rateRules.forEach(
                  rateRulesImpl -> rateRulesImpl.applyRule(e, accountSubscriptionRules));
              return Mono.empty();
            })
        .map(Function.identity())
        .thenMany(Flux.just(e));
  }
}
