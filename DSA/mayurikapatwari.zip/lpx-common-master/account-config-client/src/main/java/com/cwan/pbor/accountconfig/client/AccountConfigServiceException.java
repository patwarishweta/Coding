package com.cwan.pbor.accountconfig.client;

public class AccountConfigServiceException extends RuntimeException {

  public AccountConfigServiceException(String msg) {
    super(msg);
  }
}
