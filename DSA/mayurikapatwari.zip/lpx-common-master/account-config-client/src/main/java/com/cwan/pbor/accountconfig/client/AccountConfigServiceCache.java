package com.cwan.pbor.accountconfig.client;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.google.common.cache.Cache;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class AccountConfigServiceCache {

  private final AccountConfigServiceClient accountConfigServiceClient;
  private final Cache<Long, Flux<AccountConfig>> accountIdToAccountConfigCache;
  private final Cache<Long, Flux<AccountSubscriptionRule>> accountIdToAccountRulesCache;

  public AccountConfigServiceCache(
      AccountConfigServiceClient accountConfigServiceClient,
      Cache<Long, Flux<AccountConfig>> accountIdToAccountConfigCache,
      Cache<Long, Flux<AccountSubscriptionRule>> accountIdToAccountRulesCache) {
    this.accountConfigServiceClient = accountConfigServiceClient;
    this.accountIdToAccountConfigCache = accountIdToAccountConfigCache;
    this.accountIdToAccountRulesCache = accountIdToAccountRulesCache;
  }

  public Flux<AccountConfig> getByAccountId(Long accountId) {
    try {
      return accountIdToAccountConfigCache.get(
          accountId, () -> accountConfigServiceClient.getByAccountId(accountId));
    } catch (ExecutionException e) {
      throw new AccountConfigServiceException(
          accountId + " Exception during getByAccountId::\n " + e);
    }
  }

  public Flux<AccountSubscriptionRule> getAccountRulesByAccountConfigId(Long accountConfigId) {
    try {
      return accountIdToAccountRulesCache.get(
          accountConfigId,
          () -> accountConfigServiceClient.getAccountSubscriptionRule(Set.of(accountConfigId)));
    } catch (ExecutionException e) {
      throw new AccountConfigServiceException(
          accountConfigId + " Exception during getAccountRulesByAccountConfigId::\n " + e);
    }
  }

  public Flux<AccountSubscriptionRule> getAccountRulesByAccountId(Long accountId) {
    return getByAccountId(accountId)
        .map(AccountConfig::getId)
        .flatMap(this::getAccountRulesByAccountConfigId);
  }
}
