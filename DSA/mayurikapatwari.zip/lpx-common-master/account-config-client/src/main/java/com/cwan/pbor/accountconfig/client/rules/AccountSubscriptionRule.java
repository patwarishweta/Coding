package com.cwan.pbor.accountconfig.client.rules;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class AccountSubscriptionRule {

  private Long id;
  private Long accountConfigId;
  private Long ruleId;
  private RuleKeyAndResults ruleKeyAndResults;
  private LocalDateTime createdOn;
  private LocalDateTime modifiedOn;
  private boolean active;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  private String modifiedBy;
  private Boolean isModifiedByInternalUser;
  private Long securityId;
}
