package com.cwan.pbor.accountconfig.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.google.common.cache.Cache;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@SpringBootTest
@ContextConfiguration(
    classes = AccountConfigServiceConfig.class,
    initializers = AccountConfigServiceConfigTest.Initializer.class)
class AccountConfigServiceConfigTest {

  @MockBean private WebClient webClient;
  @Autowired private Cache<Long, Flux<AccountConfig>> accountConfigCache;
  @Autowired private Cache<Long, Flux<AccountSubscriptionRule>> accountRulesCache;

  @Test
  void accountConfigServiceWebClient() {
    assertNotNull(webClient);
  }

  @Test
  void accountIdToAccountConfigCache() {
    assertNotNull(accountConfigCache);
    assertEquals(0, accountConfigCache.size());
  }

  @Test
  void accountIdToAccountRulesCache() {
    assertNotNull(accountRulesCache);
    assertEquals(0, accountRulesCache.size());
  }

  static class Initializer
      implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
      TestPropertyValues.of(
              "account-config-service.base.url=http://localhost",
              "account-config-service.cache.maxsize=100",
              "account-config-service.cache.timeout.hours=24")
          .applyTo(configurableApplicationContext.getEnvironment());
    }
  }
}
