package com.cwan.pbor.accountconfig.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.google.common.cache.Cache;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class AccountConfigServiceCacheNonReactiveTest {
  @Mock AccountConfigServiceApacheClient accountConfigServiceClient;
  @Mock Cache<Long, AccountConfig> accountIdToAccountConfigCache;
  @Mock Cache<Long, Set<AccountSubscriptionRule>> accountIdToAccountRulesCache;
  private static final AccountConfig ACCOUNT_CONFIG = TestUtil.getAccountConfig();
  private static final Long ACCOUNT_ID = 42L;
  private AccountConfigServiceCacheNonReactive instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    this.instance =
        new AccountConfigServiceCacheNonReactive(
            accountConfigServiceClient,
            accountIdToAccountConfigCache,
            accountIdToAccountRulesCache);
  }

  @Test
  void should_get_account_config_by_account_id() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenReturn(ACCOUNT_CONFIG);
    AccountConfig actual = instance.getByAccountId(ACCOUNT_ID);
    assertEquals(ACCOUNT_CONFIG, actual);
  }

  @Test
  void get_account_config_by_account_id_should_throw_exception() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenThrow(new ExecutionException("oh no!", new Throwable()));
    assertThrows(AccountConfigServiceException.class, () -> instance.getByAccountId(ACCOUNT_ID));
  }

  @Test
  void should_get_account_rules_by_account_id() throws ExecutionException {
    Set<AccountSubscriptionRule> ruleSet = Set.copyOf(TestUtil.getAccountSubscriptionRulesList());
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenReturn(ACCOUNT_CONFIG);
    when(accountIdToAccountRulesCache.get(anyLong(), any(Callable.class))).thenReturn(ruleSet);
    Set<AccountSubscriptionRule> actual = instance.getAccountRulesByAccountId(ACCOUNT_ID);
    assertEquals(ruleSet, actual);
  }

  @Test
  void get_account_rules_by_account_id_should_throw_exception() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenReturn(ACCOUNT_CONFIG);
    when(accountIdToAccountRulesCache.get(anyLong(), any(Callable.class)))
        .thenThrow(new ExecutionException("oh no!", new Throwable()));
    assertThrows(
        AccountConfigServiceException.class,
        () -> instance.getAccountRulesByAccountConfigId(ACCOUNT_CONFIG.getId()));
  }
}
