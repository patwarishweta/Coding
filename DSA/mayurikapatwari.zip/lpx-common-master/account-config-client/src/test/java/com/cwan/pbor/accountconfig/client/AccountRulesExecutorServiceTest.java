package com.cwan.pbor.accountconfig.client;

import static org.mockito.ArgumentMatchers.any;

import com.cwan.pbor.accountconfig.client.rules.RateRules;
import com.cwan.pbor.accountconfig.client.rules.TransactionRateRulesImplementation;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

class AccountRulesExecutorServiceTest {

  private AccountRulesExecutorService accountRulesExecutorService;

  @BeforeEach
  void beforeEach() {
    AccountConfigServiceCache accountConfigServiceCacheMock =
        Mockito.mock(AccountConfigServiceCache.class);
    TransactionRateRulesImplementation transactionRateRulesImplementation =
        new TransactionRateRulesImplementation();
    List<RateRules> rateRulesList = List.of(transactionRateRulesImplementation);
    accountRulesExecutorService =
        new AccountRulesExecutorService(rateRulesList, accountConfigServiceCacheMock);
    Mockito.when(accountConfigServiceCacheMock.getByAccountId(any()))
        .thenReturn(Flux.just(TestUtil.getAccountConfig()));
    Mockito.when(accountConfigServiceCacheMock.getAccountRulesByAccountId(any()))
        .thenReturn(Flux.fromIterable(TestUtil.getAccountSubscriptionRulesList()));
  }

  @Test
  void test() {
    StepVerifier.create(accountRulesExecutorService.execute(1L, TestUtil.getTransactionOne()))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void test_datasource_MANUAL() {
    StepVerifier.create(accountRulesExecutorService.execute(1L, TestUtil.getTransactionTwo()))
        .expectNextCount(1)
        .verifyComplete();
  }
}
