package com.cwan.pbor.accountconfig.client;

import static com.cwan.pbor.accountconfig.client.TestUtil.getAccountConfigJson;
import static com.cwan.pbor.accountconfig.client.TestUtil.getAccountSubscriptionRulesList;
import static com.cwan.pbor.accountconfig.client.TestUtil.getAccountSubscriptionRulesListJson;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.ca.wsclient3.ServerConfiguration;
import com.ca.wsclient3.request.FakeWsResponse;
import com.ca.wsclient3.request.TestHttpClient;
import com.ca.wsclient3.resource.Resource.Scheme;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Service;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import java.time.LocalDate;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.MockitoAnnotations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class AccountConfigServiceApacheClientTest {
  private static final TestHttpClient testClient = new TestHttpClient();
  private static final String SUBSCRIPTION_JSON = getAccountConfigJson();
  private static final String RULE_JSON = getAccountSubscriptionRulesListJson();
  private static final FakeWsResponse subscriptionResponse =
      new FakeWsResponse()
          .setRequestUrl("account/subscription")
          .setStatusCode(200)
          .setBody(SUBSCRIPTION_JSON);
  private static final FakeWsResponse ruleResponse =
      new FakeWsResponse().setRequestUrl("account/rules").setStatusCode(200).setBody(RULE_JSON);

  private static final Long CONFIG_ID = 10L;
  private static final Long ACCOUNT_ID = 20L;

  private AccountConfigServiceApacheClient INSTANCE =
      new AccountConfigServiceApacheClient(
          testClient,
          new ServerConfiguration(
              "account-config-service", 8084, "account-config-service", Scheme.HTTPS));

  @BeforeAll
  void setup() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void test_get_by_account_id() {
    testClient.setResponse(subscriptionResponse);
    AccountConfig actual = INSTANCE.getByAccountId(ACCOUNT_ID);
    assertEquals(getTestAccountConfig(), actual);
  }

  @Test
  void test_get_account_subscription_rules() {
    testClient.setResponse(ruleResponse);
    Set<AccountSubscriptionRule> actual = INSTANCE.getAccountSubscriptionRules(Set.of(CONFIG_ID));
    assertEquals(Set.copyOf(getAccountSubscriptionRulesList()), actual);
  }

  private AccountConfig getTestAccountConfig() {
    return AccountConfig.builder()
        .id(CONFIG_ID)
        .account(Account.builder().id(ACCOUNT_ID).build())
        .service(Service.builder().name("LPxSelfService").build())
        .subscriptionStartDate(LocalDate.of(2023, 6, 30))
        .subscriptionEndDate(LocalDate.of(9999, 12, 31))
        .createdBy("test@clearwateranalytics.com")
        .modifiedBy("test@clearwateranalytics.com")
        .isCreatedByInternalUser(true)
        .isModifiedByInternalUser(true)
        .ultimateParentId(30L)
        .ultimateParentName("Test Company")
        .clientId(30L)
        .clientName("Test Company")
        .attributes(Map.of())
        .build();
  }
}
