package com.cwan.pbor.accountconfig.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class AccountConfigServiceClientTest {

  @Mock private WebClient webClient;
  @Mock private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
  @Mock private CustomMinimalForTestResponseSpec responseSpecMock;
  private static final AccountConfig ACCOUNT_CONFIG = TestUtil.getAccountConfig();
  private AccountConfigServiceClient instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    when(webClient.get()).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.uri(any(Function.class))).thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.accept(MediaType.APPLICATION_JSON))
        .thenReturn(requestHeadersUriMock);
    when(requestHeadersUriMock.retrieve()).thenReturn(responseSpecMock);
    when(responseSpecMock.bodyToFlux(eq(AccountConfig.class)))
        .thenReturn(Flux.just(ACCOUNT_CONFIG));
    when(responseSpecMock.onStatus(any(), any())).thenReturn(responseSpecMock);
    instance = new AccountConfigServiceClient(webClient);
  }

  @Test
  void should_return_account_config_by_account() {
    var actual = instance.getByAccountId(42L).share().blockFirst();
    assertEquals(ACCOUNT_CONFIG, actual);
  }

  @Test
  void test_account_config_service_ws_client() {
    Set<Long> accountRuleId = Set.of(1L);
    when(responseSpecMock.bodyToFlux(eq(AccountSubscriptionRule.class)))
        .thenReturn(Flux.fromIterable(TestUtil.getAccountSubscriptionRulesList()));
    StepVerifier.create(instance.getAccountSubscriptionRule(accountRuleId))
        .expectNextSequence(TestUtil.getAccountSubscriptionRulesList())
        .verifyComplete();
  }

  @Test
  void test_5xx_error_account_config_service_ws_client() {
    Set<Long> accountRuleId = Set.of(1L);
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        AccountConfigServiceException.class,
        () -> instance.getAccountSubscriptionRule(accountRuleId).collectList().block());
  }

  @Test
  void test_4xx_error_account_config_service_ws_client() {
    Set<Long> accountRuleId = Set.of(1L);
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.BAD_REQUEST);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    assertThrows(
        AccountConfigServiceException.class,
        () -> instance.getAccountSubscriptionRule(accountRuleId).collectList().block());
  }

  @Test
  void test_onErrorResume_account_config_service_ws_client() {
    Set<Long> accountRuleId = Set.of(1L);
    when(responseSpecMock.getStatus()).thenReturn(HttpStatus.OK);
    when(responseSpecMock.onStatus(any(Predicate.class), any(Function.class))).thenCallRealMethod();
    when(responseSpecMock.bodyToFlux(AccountSubscriptionRule.class))
        .thenReturn(
            Flux.error(
                new AccountConfigServiceException(
                    "Exception occurred during AccountRules Loading ")));
    StepVerifier.create(instance.getAccountSubscriptionRule(accountRuleId))
        .expectNextCount(0)
        .verifyComplete();
  }

  abstract static class CustomMinimalForTestResponseSpec implements WebClient.ResponseSpec {

    public abstract HttpStatus getStatus();

    @Override
    public WebClient.ResponseSpec onStatus(
        Predicate<HttpStatusCode> statusPredicate,
        Function<ClientResponse, Mono<? extends Throwable>> exceptionFunction) {
      if (statusPredicate.test(this.getStatus())) {
        exceptionFunction.apply(ClientResponse.create(HttpStatus.OK).build()).block();
      }
      return this;
    }
  }
}
