package com.cwan.pbor.accountconfig.client;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.AccountConfig;
import com.cwan.lpx.domain.Service;
import com.cwan.lpx.domain.Transaction;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;

public class TestUtil {

  @SneakyThrows
  public static Transaction getTransactionOne() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/transaction.json")), Transaction.class);
  }

  @SneakyThrows
  public static Transaction getTransactionTwo() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/transaction2.json")), Transaction.class);
  }

  @SneakyThrows
  public static List<AccountSubscriptionRule> getAccountSubscriptionRulesList() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/account_subscription_rules_list.json")),
            new TypeReference<>() {});
  }

  @SneakyThrows
  public static String getAccountSubscriptionRulesListJson() {
    return Files.readString(Path.of("src/test/resources/account_subscription_rules_list.json"));
  }

  @SneakyThrows
  public static String getAccountConfigJson() {
    return Files.readString(Path.of("src/test/resources/account_config.json"));
  }

  public static AccountConfig getAccountConfig() {
    return AccountConfig.builder()
        .id(1L)
        .account(Account.builder().id(42L).active(true).build())
        .attributes(Map.of())
        .service(Service.builder().name("unit-test").build())
        .createdBy("liquibase")
        .isCreatedByInternalUser(true)
        .subscriptionStartDate(LocalDate.of(2022, 1, 1))
        .subscriptionEndDate(LocalDate.of(2022, 1, 31))
        .build();
  }

  public static ObjectMapper getObjectMapper() {
    return new ObjectMapper().registerModule(new JavaTimeModule());
  }
}
