package com.cwan.pbor.accountconfig.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.AccountConfig;
import com.cwan.pbor.accountconfig.client.rules.AccountSubscriptionRule;
import com.google.common.cache.Cache;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;

class AccountConfigServiceCacheTest {

  @Mock AccountConfigServiceClient accountConfigServiceClient;
  @Mock Cache<Long, Flux<AccountConfig>> accountIdToAccountConfigCache;
  @Mock Cache<Long, Flux<AccountSubscriptionRule>> accountIdToAccountRulesCache;
  private static final AccountConfig ACCOUNT_CONFIG = TestUtil.getAccountConfig();
  private static final Long ACCOUNT_ID = 42L;
  private AccountConfigServiceCache instance;

  @BeforeEach
  void beforeEach() {
    openMocks(this);
    this.instance =
        new AccountConfigServiceCache(
            accountConfigServiceClient,
            accountIdToAccountConfigCache,
            accountIdToAccountRulesCache);
  }

  @Test
  void should_get_account_config_by_account_id() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenReturn(Flux.just(ACCOUNT_CONFIG));
    var actual = instance.getByAccountId(ACCOUNT_ID).share().blockFirst();
    assertEquals(ACCOUNT_CONFIG, actual);
  }

  @Test
  void get_account_config_by_account_id_should_throw_exception() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenThrow(new ExecutionException("oh no!", new Throwable()));
    assertThrows(AccountConfigServiceException.class, () -> instance.getByAccountId(ACCOUNT_ID));
  }

  @Test
  void should_get_account_rules_by_account_id() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenReturn(Flux.just(ACCOUNT_CONFIG));
    when(accountIdToAccountRulesCache.get(anyLong(), any(Callable.class)))
        .thenReturn(Flux.fromIterable(TestUtil.getAccountSubscriptionRulesList()));
    var actual = instance.getAccountRulesByAccountId(ACCOUNT_ID).collectList().block();
    assertEquals(TestUtil.getAccountSubscriptionRulesList(), actual);
  }

  @Test
  void get_account_rules_by_account_id_should_throw_exception() throws ExecutionException {
    when(accountIdToAccountConfigCache.get(anyLong(), any(Callable.class)))
        .thenReturn(Flux.just(ACCOUNT_CONFIG));
    when(accountIdToAccountRulesCache.get(anyLong(), any(Callable.class)))
        .thenThrow(new ExecutionException("oh no!", new Throwable()));
    assertThrows(
        AccountConfigServiceException.class, () -> instance.getAccountRulesByAccountConfigId(1L));
  }
}
