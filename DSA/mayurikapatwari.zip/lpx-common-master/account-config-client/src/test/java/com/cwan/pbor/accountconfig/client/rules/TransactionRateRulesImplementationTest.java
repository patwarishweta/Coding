package com.cwan.pbor.accountconfig.client.rules;

import static com.cwan.pbor.accountconfig.client.rules.Constants.CASH_IMPACT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.Transaction;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.LoggerFactory;

class TransactionRateRulesImplementationTest {

  private ListAppender<ILoggingEvent> listAppender;
  @Mock AccountSubscriptionRule accountSubscriptionRule;
  @Mock RuleKeyAndResults ruleKeyAndResults;
  @Mock RuleKey ruleKey;
  @Mock RatesRuleResults ratesRuleResults;
  @Mock Transaction transaction;
  @Mock Account account;
  @Mock Security security;
  TransactionRateRulesImplementation rulesImplementation;

  @BeforeEach
  void setUp() {
    Logger logger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
    listAppender = new ListAppender<>();
    listAppender.start();
    logger.addAppender(listAppender);
    MockitoAnnotations.openMocks(this);
    rulesImplementation = Mockito.spy(new TransactionRateRulesImplementation());
    when(accountSubscriptionRule.getRuleKeyAndResults()).thenReturn(ruleKeyAndResults);
    when(ruleKeyAndResults.getRuleKeys()).thenReturn(Collections.singletonList(ruleKey));
    when(transaction.getAccount()).thenReturn(account);
    when(transaction.getSecurity()).thenReturn(security);
  }

  @Test
  void applyRule_whenNoRatesRuleDefinition_thenLogsInfo() {
    when(rulesImplementation.fetchRule(any())).thenReturn(null);
    rulesImplementation.applyRule(transaction, accountSubscriptionRule);
    verify(rulesImplementation, times(1)).applyRule(transaction, accountSubscriptionRule);
  }

  @Test
  void applyRule_whenClassCastException_thenLogsError() {
    when(rulesImplementation.fetchRule(any())).thenThrow(ClassCastException.class);
    rulesImplementation.applyRule(transaction, accountSubscriptionRule);
    verify(rulesImplementation, times(1)).applyRule(transaction, accountSubscriptionRule);
  }

  @Test
  void ruleInputParser_whenRuleKeysAreEmpty_thenReturnsFalse() {
    assertFalse(rulesImplementation.ruleInputParser(new ArrayList<>(), transaction));
  }

  @Test
  void operatorHandling_whenOperatorIsNull_thenReturnsFalse() {
    when(ruleKey.getOperator()).thenReturn(null);
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void ruleResultParser_updatesTransactionFields() {
    when(ratesRuleResults.getTransactionType()).thenReturn("newType");
    when(ratesRuleResults.getTransactionSubType()).thenReturn("newSubType");
    when(ratesRuleResults.getNavImpactMultiplier()).thenReturn("2");
    when(ratesRuleResults.getCashImpactMultiplier()).thenReturn("2");
    when(ratesRuleResults.getUnfundedCommitmentImpactMultiplier()).thenReturn("2");
    when(transaction.getNetAmount()).thenReturn(100.0);
    rulesImplementation.ruleResultParser(ratesRuleResults, transaction);
    verify(transaction).setType("newType");
    verify(transaction).setSubType("newSubType");
    verify(transaction).setNavImpact(200D);
    verify(transaction).setCashImpact(200D);
    verify(transaction).setUnfundedCommitmentImpact(200D);
  }

  @Test
  void operatorHandling_whenEqualOperatorAndMatchingValues_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn("=");
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("input"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenEqualOperatorAndDifferentValues_thenReturnsFalse() {
    when(ruleKey.getOperator()).thenReturn("=");
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("other"));
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenNotEqualOperatorAndDifferentValues_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn("!=");
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("other"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenNotEqualOperatorAndMatchingValues_thenReturnsFalse() {
    when(ruleKey.getOperator()).thenReturn("!=");
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("input"));
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenInOperatorAndValueInList_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn("in");
    when(ruleKey.getFieldValue()).thenReturn(Arrays.asList("other", "input"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenInOperatorAndValueNotInList_thenReturnsFalse() {
    when(ruleKey.getOperator()).thenReturn("in");
    when(ruleKey.getFieldValue()).thenReturn(Arrays.asList("other", "value"));
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenLessThanOperatorAndSmallerValue_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn("<");
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("5"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "3", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenLessThanOperatorAndBiggerValue_thenReturnsFalse() {
    when(ruleKey.getOperator()).thenReturn("<");
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("3"));
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "5", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenNotInOperatorAndValueInList_thenReturnsFalse() {
    when(ruleKey.getOperator()).thenReturn(Constants.NOT_IN_OPERATOR);
    when(ruleKey.getFieldValue()).thenReturn(Arrays.asList("other", "input"));
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenGreaterThanOperatorAndBiggerValue_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn(Constants.GREATER_THAN_OPERATOR);
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("3"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "5", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenLessThanEqualOperatorAndEqualValue_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn(Constants.LESS_THAN_EQUAL_OPERATOR);
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("3"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "3", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenGreaterThanEqualOperatorAndEqualValue_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn(Constants.GREATER_THAN_EQUAL_OPERATOR);
    when(ruleKey.getFieldValue()).thenReturn(Collections.singletonList("3"));
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "3", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenNullCheckOperatorAndNullValue_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn(Constants.NULL_CHECK_OPERATOR);
    assertTrue(rulesImplementation.operatorHandling(ruleKey, null, 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenNotNullCheckOperatorAndNotNullValue_thenReturnsTrue() {
    when(ruleKey.getOperator()).thenReturn(Constants.NOT_NULL_CHECK_OPERATOR);
    assertTrue(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void operatorHandling_whenOperatorNotFound_thenThrowsException() {
    when(ruleKey.getOperator()).thenReturn("invalid_operator");
    assertFalse(rulesImplementation.operatorHandling(ruleKey, "input", 1L, 2L, 3L));
  }

  @Test
  void applyRule_whenSecurityIdMatches_thenRuleApplied() {
    when(transaction.getSecurity().getSecurityId()).thenReturn(123L);
    when(accountSubscriptionRule.getSecurityId()).thenReturn(123L);
    rulesImplementation.applyRule(transaction, accountSubscriptionRule);
    verify(rulesImplementation, times(1)).fetchRule(any());
  }

  @Test
  void applyRule_whenSecurityIdIsNull_thenRuleApplied() {
    when(transaction.getSecurity().getSecurityId()).thenReturn(123L);
    when(accountSubscriptionRule.getSecurityId()).thenReturn(null);
    rulesImplementation.applyRule(transaction, accountSubscriptionRule);
    verify(rulesImplementation, times(1)).fetchRule(any());
  }

  @Test
  void ruleInputParser_whenUnsupportedRuleField_thenReturnsFalse() {
    when(ruleKey.getFieldName()).thenReturn("INVALID_FIELD");
    assertFalse(
        rulesImplementation.ruleInputParser(Collections.singletonList(ruleKey), transaction));
  }

  @Test
  void ruleInputParser_whenCashImpactIsNull_thenReturnsFalse() {
    when(ruleKey.getFieldName()).thenReturn(CASH_IMPACT);
    assertFalse(
        rulesImplementation.ruleInputParser(Collections.singletonList(ruleKey), transaction));
  }

  @Test
  void ruleResultParser_updateTransactionField() {
    when(ratesRuleResults.getTransactionType()).thenReturn("newType");
    when(ratesRuleResults.getTransactionSubType()).thenReturn("newSubType");
    when(ratesRuleResults.getNavImpactMultiplier()).thenReturn("2");
    when(ratesRuleResults.getCashImpactMultiplier()).thenReturn("2");
    when(ratesRuleResults.getUnfundedCommitmentImpactMultiplier()).thenReturn("2");
    when(transaction.getNetAmount()).thenReturn(100.0);
    rulesImplementation.ruleResultParser(ratesRuleResults, transaction);
    verify(transaction).setType("newType");
    verify(transaction).setSubType("newSubType");
    verify(transaction).setNavImpact(200.0);
    verify(transaction).setCashImpact(200.0);
    verify(transaction).setUnfundedCommitmentImpact(200.0);
  }

  @Test
  void applyRule_whenSecurityIdDoesNotMatch_thenLogsInfo() {
    when(transaction.getSecurity().getSecurityId()).thenReturn(123L);
    when(accountSubscriptionRule.getSecurityId()).thenReturn(456L);
    rulesImplementation.applyRule(transaction, accountSubscriptionRule);
    List<ILoggingEvent> logEvents = listAppender.list;
    assertEquals(1, logEvents.size());
    assertEquals(
        "Skipping rule application as securityId doesn't match for Account:0, securityId:456",
        logEvents.get(0).getFormattedMessage());
  }

  @Test
  void ruleInputParser_whenCashImpactIsNull_thenLogsInfoAndReturnsFalse() {
    when(ruleKey.getFieldName()).thenReturn(CASH_IMPACT);
    when(transaction.getCashImpact()).thenReturn(null);
    when(account.getId()).thenReturn(1L);
    boolean result =
        rulesImplementation.ruleInputParser(Collections.singletonList(ruleKey), transaction);
    List<ILoggingEvent> logEvents = listAppender.list;
    assertEquals(1, logEvents.size());
    assertEquals("cash impact is null for accountId: 1", logEvents.get(0).getFormattedMessage());
    assertFalse(result);
  }

  @Test
  void applyRule_whenSecurityIdNotMatches_thenRuleNotApplied() {
    when(transaction.getSecurity().getSecurityId()).thenReturn(123L);
    when(accountSubscriptionRule.getSecurityId()).thenReturn(456L);
    rulesImplementation.applyRule(transaction, accountSubscriptionRule);
    verify(rulesImplementation, times(0)).fetchRule(any());
  }

  @Test
  void ruleInputParser_returnsFalseWhenCashImpactIsNull() {
    when(transaction.getAccount().getId()).thenReturn(1L);
    when(transaction.getCashImpact()).thenReturn(null);
    List<RuleKey> ruleKeys = new ArrayList<>();
    RuleKey ruleKey = new RuleKey();
    ruleKey.setFieldName("cashImpact");
    ruleKeys.add(ruleKey);
    boolean result = rulesImplementation.ruleInputParser(ruleKeys, transaction);
    assertFalse(result, "Expected ruleInputParser to return false when cash impact is null");
  }
}
