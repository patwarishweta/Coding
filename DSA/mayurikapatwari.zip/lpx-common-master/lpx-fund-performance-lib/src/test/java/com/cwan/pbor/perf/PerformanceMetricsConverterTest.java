package com.cwan.pbor.perf;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.cwan.lpx.domain.PerformanceMetrics;
import java.nio.file.Files;
import java.nio.file.Path;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

public class PerformanceMetricsConverterTest {
  @Test
  void convertToJson() {
    PerformanceMetricsConverter converter =
        new PerformanceMetricsConverter(TestUtil.getObjectMapper());
    PerformanceMetrics metrics = TestUtil.getPerformanceMetrics(1L);
    String json = converter.convertToDatabaseColumn(metrics);

    assertNotNull(json);
  }

  @Test
  @SneakyThrows
  void convertToEntity_validJson() {
    PerformanceMetricsConverter converter =
        new PerformanceMetricsConverter(TestUtil.getObjectMapper());
    String json = Files.readString(Path.of("src/test/resources/fund_performance_1.json"));
    PerformanceMetrics performanceMetric = converter.convertToEntityAttribute(json);

    assertNotNull(performanceMetric);
    assertNotNull(performanceMetric.getAccount());
  }

  @Test
  void convertToEntity_invalidJson() {
    PerformanceMetricsConverter converter =
        new PerformanceMetricsConverter(TestUtil.getObjectMapper());
    String json = "{\"not_a_performance_metrics_json_object\": 123}";
    PerformanceMetrics performanceMetric = converter.convertToEntityAttribute(json);

    assertNull(performanceMetric);
  }
}
