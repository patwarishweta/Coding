package com.cwan.pbor.clientspecific;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.ClientSpecificData;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

public class ClientSpecificEntityTransformerTest {

  @Test
  void shouldConvertClientSpecificDataToClientSpecificEntity() {

    ClientSpecificData clientSpecificData =
        ClientSpecificData.builder()
            .id(1L)
            .accountId(2L)
            .securityId(1L)
            .fundName("Fund A")
            .vintageYear(2020)
            .capitalCommitment(100000.00)
            .sector1("Technology")
            .ownershipPercentage(2.0)
            .amortStartDate(LocalDate.of(2023, 12, 20))
            .build();

    ClientSpecificEntityTransformer transformer = new ClientSpecificEntityTransformer();

    ClientSpecificEntity actual = transformer.apply(clientSpecificData);

    assertEquals(clientSpecificData.getId(), actual.getId());
    assertEquals(clientSpecificData.getAccountId(), actual.getAccountId());
    assertEquals(clientSpecificData.getSecurityId(), actual.getSecurityId());
    assertEquals(clientSpecificData.getFundName(), actual.getFundName());
    assertEquals(clientSpecificData.getVintageYear(), actual.getVintageYear());
    assertEquals(clientSpecificData.getCapitalCommitment(), actual.getCapitalCommitment());
    assertEquals(clientSpecificData.getSector1(), actual.getSector1());
    assertEquals(clientSpecificData.getOwnershipPercentage(), actual.getOwnershipPercentage());
    assertEquals(clientSpecificData.getAmortStartDate(), actual.getAmortStartDate());
  }
}
