package com.cwan.pbor.perf;

import static com.cwan.pbor.perf.TestUtil.getPerformanceMetrics;
import static com.cwan.pbor.perf.TestUtil.getPerformanceMetricsEntities;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.PerformanceMetrics;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class PerformanceMetricsServiceTest {

  private static final Long PerformanceMetrics_ID = 1L;
  private static final Set<Long> PerformanceMetrics_IDS = Set.of(PerformanceMetrics_ID);
  private static final PerformanceMetrics PerformanceMetrics =
      getPerformanceMetrics(PerformanceMetrics_ID);
  @Mock private PerformanceMetricsRepository mockPerformanceMetricsRepository;
  private final PerformanceMetricsEntityTransformer performanceMetricsEntityTransformer =
      new PerformanceMetricsEntityTransformer();
  private final PerformanceMetricsTransformer performanceMetricsTransformer =
      new PerformanceMetricsTransformer();
  private PerformanceMetricsService performanceMetricsService;

  @BeforeEach
  void before_each() {
    openMocks(this);
    performanceMetricsService =
        new PerformanceMetricsService(
            mockPerformanceMetricsRepository,
            performanceMetricsEntityTransformer,
            performanceMetricsTransformer);
  }

  @Test
  void should_add_PerformanceMetrics_successfully() {
    var txnEntity = getPerformanceMetricsEntities();
    Mockito.when(mockPerformanceMetricsRepository.save(any())).thenReturn(txnEntity[0]);
    StepVerifier.create(
            performanceMetricsService.addPerformanceMetrics(Set.of(getPerformanceMetrics(null))))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void should_throw_PerformanceMetricsException_in_addPerformanceMetrics() {
    Mockito.when(mockPerformanceMetricsRepository.save(any()))
        .thenThrow(LPxPerformanceMetricsException.class);
    StepVerifier.create(
            performanceMetricsService.addPerformanceMetrics(Set.of(getPerformanceMetrics(null))))
        .expectError(LPxPerformanceMetricsException.class)
        .verify();
  }

  @Test
  void should_throw_Error_in_fetching_PerformanceMetricss() {
    Mockito.when(mockPerformanceMetricsRepository.findAllById(any()))
        .thenThrow(LPxPerformanceMetricsException.class);
    Assertions.assertThrows(
        LPxPerformanceMetricsException.class,
        () -> performanceMetricsService.getPerformanceMetricsByIds(PerformanceMetrics_IDS));
  }

  @Test
  void should_successfully_get_PerformanceMetrics_by_PerformanceMetrics_ids() {
    Mockito.when(mockPerformanceMetricsRepository.findAllById(any()))
        .thenReturn(List.of(getPerformanceMetricsEntities()[0]));
    StepVerifier.create(
            performanceMetricsService.getPerformanceMetricsByIds(PerformanceMetrics_IDS))
        .expectNextCount(1)
        .verifyComplete();
  }
}
