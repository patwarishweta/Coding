package com.cwan.pbor.perf;

import static com.cwan.pbor.perf.TestUtil.getPerformanceMetrics;
import static com.cwan.pbor.perf.TestUtil.getPerformanceMetricsEntities;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class PerformanceMetricsEntityTransformerTest {

  private static final Long PERFORMANCE_METRICS_ID = 1L;

  @Test
  void should_convert_PerformanceMetrics_to_PerformanceMetrics_entity() {
    var expected = getPerformanceMetricsEntities()[0];
    var actual =
        new PerformanceMetricsEntityTransformer()
            .apply(getPerformanceMetrics(PERFORMANCE_METRICS_ID));
    assertEquals(expected, actual);
  }
}
