package com.cwan.pbor.clientspecific;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ClientSpecificTransformerTest {

  @Test
  void should_convert_ClientSpecific_entity_to_ClientSpecificData() {
    var expected = TestUtil.getClientSpecificData();
    var actual = new ClientSpecificTransformer().apply(TestUtil.getClientSpecificEntity());
    assertEquals(expected, actual);
  }
}
