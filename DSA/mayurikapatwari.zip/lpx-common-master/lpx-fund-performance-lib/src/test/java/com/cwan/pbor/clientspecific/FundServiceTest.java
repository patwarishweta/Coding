package com.cwan.pbor.clientspecific;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.ClientSpecificData;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class FundServiceTest {

  private static final ClientSpecificEntity clientSpecificEntity =
      TestUtil.getClientSpecificEntity();
  private FundService fundService;
  @Mock private ClientSpecificEntityTransformer clientSpecificEntityTransformer;
  @Mock private ClientSpecificTransformer clientSpecificTransformer;
  @Mock private ClientSpecificRepository clientSpecificRepository;

  @BeforeEach
  void before_each() {
    openMocks(this);
    FundService fundService1 = new FundService();
    fundService =
        new FundService(
            clientSpecificRepository, clientSpecificTransformer, clientSpecificEntityTransformer);
  }

  @Test
  void should_successfully_get_client_data_by_account_ids_sec_ids() {
    when(clientSpecificRepository.findAllByAccountIdInAndSecurityIdIn(any(), any()))
        .thenReturn(List.of(TestUtil.getClientSpecificEntity()));

    when(clientSpecificTransformer.apply(any(ClientSpecificEntity.class)))
        .thenAnswer(
            invocation -> {
              ClientSpecificEntity entity = invocation.getArgument(0);
              ClientSpecificData data = new ClientSpecificData();
              data.setOwnershipPercentage(entity.getOwnershipPercentage());
              return data;
            });

    List<ClientSpecificData> result =
        fundService.fetchClientSpecificDataByAccIdAndSecId(Set.of(2L), Set.of(1L));

    // assertEquals(List.of(2.0), result);
    Assertions.assertTrue(result.size() > 0);
  }

  @Test
  void should_successfully_get_client_data_by_account_id_sec_id() {
    when(clientSpecificRepository.findByAccountIdAndSecurityId(any(), any()))
        .thenReturn(List.of(TestUtil.getClientSpecificEntity()));

    when(clientSpecificTransformer.apply(any(ClientSpecificEntity.class)))
        .thenAnswer(
            invocation -> {
              ClientSpecificEntity entity = invocation.getArgument(0);
              ClientSpecificData data = new ClientSpecificData();
              data.setOwnershipPercentage(entity.getOwnershipPercentage());
              return data;
            });

    List<ClientSpecificData> result = fundService.getClientSpecificDataByAccountAndSecurity(2L, 1L);

    // assertEquals(List.of(2.0), result);
    Assertions.assertTrue(result.size() > 0);
  }

  @Test
  void should_successfully_get_client_data() {
    when(clientSpecificRepository.findBySecurityId(any()))
        .thenReturn(List.of(TestUtil.getClientSpecificEntity()));

    when(clientSpecificTransformer.apply(any(ClientSpecificEntity.class)))
        .thenAnswer(
            invocation -> {
              ClientSpecificEntity entity = invocation.getArgument(0);
              ClientSpecificData data = new ClientSpecificData();
              data.setOwnershipPercentage(entity.getOwnershipPercentage());
              return data;
            });

    List<Double> result = fundService.getClientData(Set.of(1L));

    assertEquals(List.of(2.0), result);
  }

  @Test
  void should_successfully_get_client_data_for_securityIds() {
    List<Long> securityIds = List.of(1L);
    ClientSpecificEntity clientSpecificEntity = TestUtil.getClientSpecificEntity();
    when(clientSpecificRepository.findBySecurityIdIn(any(List.class)))
        .thenReturn(List.of(clientSpecificEntity));

    ClientSpecificData expectedData = new ClientSpecificData();
    expectedData.setSecurityId(clientSpecificEntity.getSecurityId());
    expectedData.setOwnershipPercentage(clientSpecificEntity.getOwnershipPercentage());
    expectedData.setAmortStartDate(clientSpecificEntity.getAmortStartDate());

    when(clientSpecificTransformer.apply(any(ClientSpecificEntity.class))).thenReturn(expectedData);

    List<ClientSpecificData> result = fundService.getClientSpecificDataBySecurityIds(securityIds);

    assertEquals(List.of(expectedData), result);
  }

  @Test
  void should_successfully_get_ownership_percentage() {
    when(clientSpecificRepository.findByAccountIdAndSecurityId(any(), any()))
        .thenReturn(List.of(clientSpecificEntity));
    assertEquals(List.of(2.0), fundService.getOwnershipPercentage(1L, 2L));
  }

  @Test
  void should_successfully_get_amortization_start_dates_by_id() {
    when(clientSpecificRepository.findByAccountIdAndSecurityId(any(), any()))
        .thenReturn(List.of(clientSpecificEntity));

    assertEquals(
        clientSpecificEntity.getAmortStartDate(), fundService.getAmortizationStartDate(1L, 2L));
  }

  @Test
  void verify_missing_amort_start_date() {
    List<ClientSpecificEntity> resultsWithNull = new ArrayList<>();
    resultsWithNull.add(null);

    when(clientSpecificRepository.findByAccountIdAndSecurityId(any(), any()))
        .thenReturn(resultsWithNull);

    Assertions.assertNull(fundService.getAmortizationStartDate(1L, 2L));
  }

  @Test
  void test_getAllSecurities() {
    when(clientSpecificRepository.findAllSecurities()).thenReturn(List.of(123L));
    assertEquals(List.of(123L), fundService.getAllSecurities());
  }

  @Test
  void addClientSpecificData_filtersOutDataWithNonNullId() {
    Set<ClientSpecificData> inputData = new HashSet<>();
    ClientSpecificData dataWithNonNullId = new ClientSpecificData();
    dataWithNonNullId.setId(1L);
    inputData.add(dataWithNonNullId);

    ClientSpecificData dataWithNullId = new ClientSpecificData();
    inputData.add(dataWithNullId);

    when(clientSpecificEntityTransformer.apply(any(ClientSpecificData.class)))
        .thenAnswer(invocation -> new ClientSpecificEntity());
    when(clientSpecificRepository.saveAndFlush(any(ClientSpecificEntity.class)))
        .thenAnswer(invocation -> invocation.getArgument(0));
    when(clientSpecificTransformer.apply(any(ClientSpecificEntity.class)))
        .thenAnswer(invocation -> new ClientSpecificData());

    List<ClientSpecificData> result = fundService.addClientSpecificData(inputData);

    assertEquals(1, result.size());

    verify(clientSpecificRepository, times(1)).saveAndFlush(any(ClientSpecificEntity.class));
  }
}
