package com.cwan.pbor.perf;

import static com.cwan.pbor.perf.TestUtil.getPerformanceMetrics;
import static com.cwan.pbor.perf.TestUtil.getPerformanceMetricsEntities;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class PerformanceMetricsTransformerTest {

  @Test
  void should_convert_PerformanceMetrics_entity_to_PerformanceMetrics() {
    var expected = getPerformanceMetrics(1L);
    var actual = new PerformanceMetricsTransformer().apply(getPerformanceMetricsEntities()[0]);
    assertEquals(expected, actual);
  }
}
