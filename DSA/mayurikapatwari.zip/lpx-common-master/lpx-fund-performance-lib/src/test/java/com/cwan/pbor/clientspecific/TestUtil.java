package com.cwan.pbor.clientspecific;

import com.cwan.lpx.domain.ClientSpecificData;
import java.time.LocalDate;

public class TestUtil {

  public static ClientSpecificEntity getClientSpecificEntity() {
    return ClientSpecificEntity.builder()
        .accountId(2L)
        .securityId(1L)
        .ownershipPercentage(2.0)
        .amortStartDate(LocalDate.of(2023, 12, 20))
        .build();
  }

  public static ClientSpecificData getClientSpecificData() {
    return ClientSpecificData.builder()
        .accountId(2L)
        .securityId(1L)
        .ownershipPercentage(2.0)
        .amortStartDate(LocalDate.of(2023, 12, 20))
        .build();
  }
}
