package com.cwan.pbor.perf;

import com.cwan.lpx.domain.PerformanceMetrics;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.nio.file.Files;
import java.nio.file.Path;
import lombok.SneakyThrows;

public class TestUtil {

  @SneakyThrows
  public static PerformanceMetrics getPerformanceMetrics(Long id) {
    var txn =
        getObjectMapper()
            .readValue(
                Files.readString(Path.of("src/test/resources/fund_performance_1.json")),
                PerformanceMetrics.class);
    txn.setId(id);
    return txn;
  }

  public static ObjectMapper getObjectMapper() {
    return new ObjectMapper().registerModule(new JavaTimeModule());
  }

  @SneakyThrows
  public static PerformanceMetricsEntity[] getPerformanceMetricsEntities() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/fund_performance_entity.json")),
            PerformanceMetricsEntity[].class);
  }
}
