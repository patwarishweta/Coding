create schema if not exists pabor;
create table if not exists pabor.performancemetrics
(
  id                           bigint not null auto_increment,
  account_id                   bigint not null,
  document_id                  bigint,
  source                       varchar(30),
  knowledge_start_date         datetime,
  knowledge_end_date           datetime,
  created_by                   varchar(256),
  is_created_by_internal_user  bit,
  created_on                   datetime,
  modified_by                  varchar(256),
  is_modified_by_internal_user bit,
  modified_on                  datetime,
  primary key (id)
);
