import com.cwan.pbor.perf.PerformanceMetricsService;
import com.cwan.pbor.perf.api.LPxPerformanceMetrics;

module pbor.performance.metrics.reader {
  requires reactor.core;
  requires lombok;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;
  requires jakarta.persistence;
  requires com.fasterxml.jackson.databind;
  requires com.fasterxml.jackson.datatype.jsr310;

  exports com.cwan.pbor.perf.api;
  exports com.cwan.pbor.perf;
  exports com.cwan.pbor.clientspecific;

  provides LPxPerformanceMetrics with
      PerformanceMetricsService;
}
