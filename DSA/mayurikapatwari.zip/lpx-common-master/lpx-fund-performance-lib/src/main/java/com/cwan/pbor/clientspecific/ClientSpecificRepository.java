package com.cwan.pbor.clientspecific;

import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ClientSpecificRepository extends JpaRepository<ClientSpecificEntity, Long> {

  List<ClientSpecificEntity> findBySecurityId(Long securityId);

  List<ClientSpecificEntity> findBySecurityIdIn(List<Long> securityId);

  List<ClientSpecificEntity> findByAccountIdAndSecurityId(Long accountId, Long securityId);

  @Query("select DISTINCT cs.securityId from ClientSpecificEntity cs")
  List<Long> findAllSecurities();

  List<ClientSpecificEntity> findAllByAccountIdInAndSecurityIdIn(
      Set<Long> accountId, Set<Long> securityId);
}
