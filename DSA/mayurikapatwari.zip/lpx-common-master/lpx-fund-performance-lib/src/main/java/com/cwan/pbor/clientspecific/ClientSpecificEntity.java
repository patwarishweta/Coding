package com.cwan.pbor.clientspecific;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.Hibernate;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "client_specific_data", catalog = "pabor")
public class ClientSpecificEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long accountId;
  private Long securityId;
  private String fundName;
  private Boolean isCanoeConnected;
  private Integer vintageYear;
  private Double capitalCommitment;

  @Column(name = "sector_1")
  private String sector1;

  @Column(name = "sector_2")
  private String sector2;

  @Column(name = "sector_3")
  private String sector3;

  private String countryOfRisk;
  private String stateOfRisk;
  private String regionOfInvestment;
  private Boolean affiliateTransferRight;
  private String mostFavourableNationClause;
  private Double issueConcentrationRestriction;
  private Double ownershipPercentage;
  private String naicTypeAndStrategy;
  private String naicCategory;
  private String secondaryMarket;
  private LocalDate amortStartDate;
  private boolean forceIrrCalc;

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (ClientSpecificEntity) o;
    return (id != null) && Objects.equals(id, that.id);
  }
}
