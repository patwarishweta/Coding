package com.cwan.pbor.perf;

import com.cwan.lpx.domain.PerformanceMetrics;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PerformanceMetricsConverter implements AttributeConverter<PerformanceMetrics, String> {
  private final ObjectMapper objectMapper;

  public PerformanceMetricsConverter(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  @Override
  public String convertToDatabaseColumn(PerformanceMetrics performanceMetrics) {

    String json = null;
    try {
      json = this.objectMapper.writeValueAsString(performanceMetrics);
    } catch (final JsonProcessingException e) {
      log.error("JSON writing error - cannot convert PerformanceMetrics to JSON", e);
    }

    return json;
  }

  @Override
  public PerformanceMetrics convertToEntityAttribute(String performanceMetricsJson) {

    PerformanceMetrics metrics = null;
    try {
      metrics = this.objectMapper.readValue(performanceMetricsJson, new TypeReference<>() {});
    } catch (final IOException e) {
      log.error("JSON reading error - cannot convert JSON to PerformanceMetrics", e);
    }

    return metrics;
  }
}
