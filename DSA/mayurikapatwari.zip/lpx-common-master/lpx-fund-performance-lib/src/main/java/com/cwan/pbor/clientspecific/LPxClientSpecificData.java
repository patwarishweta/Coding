package com.cwan.pbor.clientspecific;

import com.cwan.lpx.domain.ClientSpecificData;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface LPxClientSpecificData {

  List<Double> getClientData(Set<Long> ids);

  LocalDate getAmortizationStartDate(Long accountId, Long securityId);

  List<ClientSpecificData> getClientSpecificDataByAccountAndSecurity(
      Long accountId, Long securityId);

  List<ClientSpecificData> getClientSpecificDataBySecurityIds(List<Long> securityId);

  List<Long> getAllSecurities();

  List<ClientSpecificData> addClientSpecificData(Set<ClientSpecificData> clientSpecificDataSet);

  List<ClientSpecificData> upsertClientSpecificData(Set<ClientSpecificData> clientSpecificDataSet);

  List<ClientSpecificData> fetchClientSpecificDataByAccIdAndSecId(
      Set<Long> accountIds, Set<Long> securityids);

  List<Double> getOwnershipPercentage(Long accountId, Long securityId);
}
