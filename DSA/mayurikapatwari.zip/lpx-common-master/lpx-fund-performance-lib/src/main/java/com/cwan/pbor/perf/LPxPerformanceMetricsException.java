package com.cwan.pbor.perf;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class LPxPerformanceMetricsException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = -6471654464111761910L;

  public LPxPerformanceMetricsException(String msg, Throwable e) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, msg, e);
  }

  public LPxPerformanceMetricsException(String msg) {
    super(HttpStatus.BAD_REQUEST, msg);
  }
}
