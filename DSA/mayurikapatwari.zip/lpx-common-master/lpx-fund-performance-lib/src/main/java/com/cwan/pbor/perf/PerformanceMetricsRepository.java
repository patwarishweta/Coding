package com.cwan.pbor.perf;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PerformanceMetricsRepository
    extends JpaRepository<PerformanceMetricsEntity, Long> {}
