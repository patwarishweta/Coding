package com.cwan.pbor.perf;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.PerformanceMetrics;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class PerformanceMetricsTransformer
    implements Function<PerformanceMetricsEntity, PerformanceMetrics> {

  @Override
  public PerformanceMetrics apply(PerformanceMetricsEntity performanceMetricsEntity) {
    return PerformanceMetrics.builder()
        .id(performanceMetricsEntity.getId())
        .account(Account.builder().id(performanceMetricsEntity.getAccountId()).build())
        .document(getDocument(performanceMetricsEntity))
        .source(performanceMetricsEntity.getSource())
        .dataSource(performanceMetricsEntity.getDataSource())
        .knowledgeStartDate(performanceMetricsEntity.getKnowledgeStartDate())
        .knowledgeEndDate(performanceMetricsEntity.getKnowledgeEndDate())
        .isCreatedByInternalUser(performanceMetricsEntity.getIsCreatedByInternalUser())
        .isModifiedByInternalUser(performanceMetricsEntity.getIsModifiedByInternalUser())
        .createdOn(performanceMetricsEntity.getCreatedOn())
        .modifiedOn(performanceMetricsEntity.getModifiedOn())
        .createdBy(performanceMetricsEntity.getCreatedBy())
        .modifiedBy(performanceMetricsEntity.getModifiedBy())
        .build();
  }

  private Document getDocument(PerformanceMetricsEntity performanceMetricsEntity) {
    return Document.builder().id(performanceMetricsEntity.getDocumentId()).build();
  }
}
