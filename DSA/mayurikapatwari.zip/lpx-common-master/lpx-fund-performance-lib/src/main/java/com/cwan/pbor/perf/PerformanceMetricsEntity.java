package com.cwan.pbor.perf;

import com.cwan.lpx.domain.PerformanceMetrics;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Fund_Performance_Metrics", catalog = "pabor")
public class PerformanceMetricsEntity {

  @Id private Long id;
  private Long accountId;
  private Long securityId;
  private Long documentId;
  private String source;
  private String dataSource;
  private LocalDate reportDate;

  @Convert(converter = PerformanceMetricsConverter.class)
  @Column(name = "performance_metrics_json", columnDefinition = "json")
  private PerformanceMetrics performanceMetricsJson;

  private LocalDateTime knowledgeStartDate;
  private LocalDateTime knowledgeEndDate;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  @CreationTimestamp private LocalDateTime createdOn;
  private String modifiedBy;
  private Boolean isModifiedByInternalUser;
  @UpdateTimestamp private LocalDateTime modifiedOn;

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (PerformanceMetricsEntity) o;
    return (id != null) && Objects.equals(id, that.id);
  }
}
