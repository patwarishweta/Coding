package com.cwan.pbor.clientspecific;

import com.cwan.lpx.domain.ClientSpecificData;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class FundService implements LPxClientSpecificData {

  private ClientSpecificRepository clientSpecificRepository;
  private ClientSpecificTransformer clientSpecificTransformer;
  private ClientSpecificEntityTransformer clientSpecificEntityTransformer;

  public FundService() {}

  @Autowired
  public FundService(
      final ClientSpecificRepository clientSpecificRepository,
      final ClientSpecificTransformer clientSpecificTransformer,
      final ClientSpecificEntityTransformer clientSpecificEntityTransformer) {
    this.clientSpecificRepository = clientSpecificRepository;
    this.clientSpecificTransformer = clientSpecificTransformer;
    this.clientSpecificEntityTransformer = clientSpecificEntityTransformer;
  }

  @Override
  public List<ClientSpecificData> addClientSpecificData(
      final Set<ClientSpecificData> clientSpecificDataSet) {
    clientSpecificDataSet.stream()
        .filter(clientSpecificData -> clientSpecificData.getId() != null)
        .forEach(
            doc ->
                log.warn(
                    "clientSpecificData with Id {} can't be added Id should be null.",
                    doc.getId()));
    return clientSpecificDataSet.stream()
        .filter(clientSpecificData -> clientSpecificData.getId() == null)
        .filter(Objects::nonNull)
        .map(clientSpecificEntityTransformer)
        .map(clientSpecificEntity -> clientSpecificRepository.saveAndFlush(clientSpecificEntity))
        .map(
            clientSpecificEntity -> {
              log.info(
                  "clientSpecificEntity saved in pabor db with id " + clientSpecificEntity.getId());
              return clientSpecificTransformer.apply(clientSpecificEntity);
            })
        .collect(Collectors.toList());
  }

  @Override
  public List<ClientSpecificData> upsertClientSpecificData(
      final Set<ClientSpecificData> clientSpecificDataSet) {
    return clientSpecificDataSet.stream()
        .map(clientSpecificEntityTransformer)
        .map(clientSpecificEntity -> clientSpecificRepository.saveAndFlush(clientSpecificEntity))
        .map(clientSpecificEntity -> clientSpecificTransformer.apply(clientSpecificEntity))
        .collect(Collectors.toList());
  }

  @Override
  public List<ClientSpecificData> fetchClientSpecificDataByAccIdAndSecId(
      Set<Long> accountIds, Set<Long> securityids) {
    return clientSpecificRepository
        .findAllByAccountIdInAndSecurityIdIn(accountIds, securityids)
        .stream()
        .map(clientSpecificEntity -> clientSpecificTransformer.apply(clientSpecificEntity))
        .collect(Collectors.toList());
  }

  @Override
  public List<Double> getClientData(final Set<Long> securityIds) {
    return securityIds.stream()
        .map(secId -> clientSpecificRepository.findBySecurityId(secId))
        .filter(Objects::nonNull)
        .filter(clientSpecificEntities -> !clientSpecificEntities.isEmpty())
        .map(clientSpecificEntity -> clientSpecificTransformer.apply(clientSpecificEntity.get(0)))
        .map(
            clientSpecificData -> {
              if (null == clientSpecificData) {
                log.info("Client specific data not present for fund {}", securityIds);
              }
              if (null == clientSpecificData.getOwnershipPercentage()) {
                log.info("Percent multiplier not present for fund {}", securityIds);
              }
              return clientSpecificData.getOwnershipPercentage();
            })
        .collect(Collectors.toList());
  }

  @Override
  public List<Double> getOwnershipPercentage(Long accountId, Long securityId) {
    return clientSpecificRepository.findByAccountIdAndSecurityId(accountId, securityId).stream()
        .map(clientSpecificEntity -> clientSpecificEntity.getOwnershipPercentage())
        .collect(Collectors.toList());
  }

  @Override
  public LocalDate getAmortizationStartDate(Long accountId, Long securityId) {
    return clientSpecificRepository.findByAccountIdAndSecurityId(accountId, securityId).stream()
        .filter(Objects::nonNull)
        .map(ClientSpecificEntity::getAmortStartDate)
        .findFirst()
        .orElse(null);
  }

  @Override
  public List<ClientSpecificData> getClientSpecificDataByAccountAndSecurity(
      Long accountId, Long securityId) {
    return clientSpecificRepository.findByAccountIdAndSecurityId(accountId, securityId).stream()
        .map(clientSpecificEntity -> clientSpecificTransformer.apply(clientSpecificEntity))
        .collect(Collectors.toList());
  }

  @Override
  public List<ClientSpecificData> getClientSpecificDataBySecurityIds(List<Long> securityIds) {
    return clientSpecificRepository.findBySecurityIdIn(securityIds).stream()
        .map(clientSpecificEntity -> clientSpecificTransformer.apply(clientSpecificEntity))
        .collect(Collectors.toList());
  }

  @Override
  public List<Long> getAllSecurities() {
    return clientSpecificRepository.findAllSecurities();
  }
}
