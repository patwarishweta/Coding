package com.cwan.pbor.perf;

import com.cwan.lpx.domain.PerformanceMetrics;
import com.cwan.pbor.perf.api.LPxPerformanceMetrics;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class PerformanceMetricsService implements LPxPerformanceMetrics {

  private PerformanceMetricsRepository performanceMetricsRepository;
  private PerformanceMetricsEntityTransformer performanceMetricsEntityTransformer;
  private PerformanceMetricsTransformer performanceMetricsTransformer;

  public PerformanceMetricsService() {}

  @Autowired
  public PerformanceMetricsService(
      final PerformanceMetricsRepository performanceMetricsRepository,
      final PerformanceMetricsEntityTransformer performanceMetricsEntityTransformer,
      final PerformanceMetricsTransformer performanceMetricsTransformer) {
    this.performanceMetricsRepository = performanceMetricsRepository;
    this.performanceMetricsEntityTransformer = performanceMetricsEntityTransformer;
    this.performanceMetricsTransformer = performanceMetricsTransformer;
  }

  @Override
  public Flux<PerformanceMetrics> addPerformanceMetrics(
      final Set<PerformanceMetrics> performancceMetricsSet) {
    return Flux.fromIterable(performancceMetricsSet)
        .map(performanceMetrics -> performanceMetricsEntityTransformer.apply(performanceMetrics))
        .map(peformanceMetricsEntity -> performanceMetricsRepository.save(peformanceMetricsEntity))
        .map(performanceMetricsTransformer);
  }

  @Override
  public Flux<PerformanceMetrics> getPerformanceMetricsByIds(Set<Long> ids) {
    return Flux.fromIterable(performanceMetricsRepository.findAllById(ids))
        .map(performanceMetricsTransformer);
  }
}
