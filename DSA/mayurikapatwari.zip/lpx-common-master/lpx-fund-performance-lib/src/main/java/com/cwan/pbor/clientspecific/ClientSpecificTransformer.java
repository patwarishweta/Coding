package com.cwan.pbor.clientspecific;

import com.cwan.lpx.domain.ClientSpecificData;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class ClientSpecificTransformer
    implements Function<ClientSpecificEntity, ClientSpecificData> {

  @Override
  public ClientSpecificData apply(ClientSpecificEntity clientSpecificEntity) {
    return ClientSpecificData.builder()
        .id(clientSpecificEntity.getId())
        .accountId(clientSpecificEntity.getAccountId())
        .securityId(clientSpecificEntity.getSecurityId())
        .fundName(clientSpecificEntity.getFundName())
        .isCanoeConnected(clientSpecificEntity.getIsCanoeConnected())
        .vintageYear(clientSpecificEntity.getVintageYear())
        .capitalCommitment(clientSpecificEntity.getCapitalCommitment())
        .sector1(clientSpecificEntity.getSector1())
        .sector2(clientSpecificEntity.getSector2())
        .sector3(clientSpecificEntity.getSector3())
        .countryOfRisk(clientSpecificEntity.getCountryOfRisk())
        .stateOfRisk(clientSpecificEntity.getStateOfRisk())
        .regionOfInvestment(clientSpecificEntity.getRegionOfInvestment())
        .affiliateTransferRight(clientSpecificEntity.getAffiliateTransferRight())
        .mostFavourableNationClause(clientSpecificEntity.getMostFavourableNationClause())
        .issueConcentrationRestriction(clientSpecificEntity.getIssueConcentrationRestriction())
        .ownershipPercentage(clientSpecificEntity.getOwnershipPercentage())
        .naicCategory(clientSpecificEntity.getNaicCategory())
        .naicTypeAndStrategy(clientSpecificEntity.getNaicTypeAndStrategy())
        .secondaryMarket(clientSpecificEntity.getSecondaryMarket())
        .amortStartDate(clientSpecificEntity.getAmortStartDate())
        .forceIrrCalc(clientSpecificEntity.isForceIrrCalc())
        .build();
  }
}
