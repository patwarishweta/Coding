package com.cwan.pbor.clientspecific;

import com.cwan.lpx.domain.ClientSpecificData;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class ClientSpecificEntityTransformer
    implements Function<ClientSpecificData, ClientSpecificEntity> {

  @Override
  public ClientSpecificEntity apply(ClientSpecificData clientSpecificData) {
    return ClientSpecificEntity.builder()
        .id(clientSpecificData.getId())
        .accountId(clientSpecificData.getAccountId())
        .securityId(clientSpecificData.getSecurityId())
        .fundName(clientSpecificData.getFundName())
        .isCanoeConnected(clientSpecificData.getIsCanoeConnected())
        .vintageYear(clientSpecificData.getVintageYear())
        .capitalCommitment(clientSpecificData.getCapitalCommitment())
        .sector1(clientSpecificData.getSector1())
        .sector2(clientSpecificData.getSector2())
        .sector3(clientSpecificData.getSector3())
        .countryOfRisk(clientSpecificData.getCountryOfRisk())
        .stateOfRisk(clientSpecificData.getStateOfRisk())
        .regionOfInvestment(clientSpecificData.getRegionOfInvestment())
        .affiliateTransferRight(clientSpecificData.getAffiliateTransferRight())
        .mostFavourableNationClause(clientSpecificData.getMostFavourableNationClause())
        .issueConcentrationRestriction(clientSpecificData.getIssueConcentrationRestriction())
        .ownershipPercentage(clientSpecificData.getOwnershipPercentage())
        .naicCategory(clientSpecificData.getNaicCategory())
        .naicTypeAndStrategy(clientSpecificData.getNaicTypeAndStrategy())
        .secondaryMarket(clientSpecificData.getSecondaryMarket())
        .amortStartDate(clientSpecificData.getAmortStartDate())
        .forceIrrCalc(clientSpecificData.isForceIrrCalc())
        .build();
  }
}
