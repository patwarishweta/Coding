package com.cwan.pbor.perf;

import com.cwan.lpx.domain.PerformanceMetrics;
import java.util.Objects;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class PerformanceMetricsEntityTransformer
    implements Function<PerformanceMetrics, PerformanceMetricsEntity> {

  @Override
  public PerformanceMetricsEntity apply(PerformanceMetrics performanceMetrics) {
    return PerformanceMetricsEntity.builder()
        .accountId(performanceMetrics.getAccount().getId())
        .documentId(
            Objects.nonNull(performanceMetrics.getDocument())
                ? performanceMetrics.getDocument().getId()
                : null)
        .reportDate(performanceMetrics.getReportDate())
        .source(performanceMetrics.getSource())
        .dataSource(performanceMetrics.getDataSource())
        .knowledgeStartDate(performanceMetrics.getKnowledgeStartDate())
        .knowledgeEndDate(performanceMetrics.getKnowledgeEndDate())
        .isCreatedByInternalUser(performanceMetrics.getIsCreatedByInternalUser())
        .isModifiedByInternalUser(performanceMetrics.getIsModifiedByInternalUser())
        .createdBy(performanceMetrics.getCreatedBy())
        .modifiedBy(performanceMetrics.getModifiedBy())
        .id(performanceMetrics.getId())
        .build();
  }
}
