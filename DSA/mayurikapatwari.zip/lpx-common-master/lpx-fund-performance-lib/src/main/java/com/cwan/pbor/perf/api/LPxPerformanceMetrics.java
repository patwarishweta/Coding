package com.cwan.pbor.perf.api;

import com.cwan.lpx.domain.PerformanceMetrics;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface LPxPerformanceMetrics {

  Flux<PerformanceMetrics> addPerformanceMetrics(Set<PerformanceMetrics> performanceMetrics);

  Flux<PerformanceMetrics> getPerformanceMetricsByIds(Set<Long> ids);
}
