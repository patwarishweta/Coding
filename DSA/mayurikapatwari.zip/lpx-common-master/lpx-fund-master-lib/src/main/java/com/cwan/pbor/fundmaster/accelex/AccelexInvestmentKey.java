package com.cwan.pbor.fundmaster.accelex;

import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.Hibernate;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Embeddable
public class AccelexInvestmentKey implements Serializable {

  private Long securityId;
  private String vehicleName;

  private String documentName;
  private LocalDate reportDate;
  private String assetName;
  private String periodType;
  private LocalDate date;
  private String type;

  @Override
  public int hashCode() {
    return Objects.hash(
        securityId, vehicleName, documentName, reportDate, assetName, periodType, date, type);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (AccelexInvestmentKey) o;
    return Objects.equals(securityId, that.securityId)
        && Objects.equals(vehicleName, that.vehicleName)
        && Objects.equals(documentName, that.documentName)
        && Objects.equals(reportDate, that.reportDate)
        && Objects.equals(assetName, that.assetName)
        && Objects.equals(periodType, that.periodType)
        && Objects.equals(date, that.date)
        && Objects.equals(type, that.type);
  }
}
