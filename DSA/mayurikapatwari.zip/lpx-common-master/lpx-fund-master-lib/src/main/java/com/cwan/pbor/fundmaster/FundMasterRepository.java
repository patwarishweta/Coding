package com.cwan.pbor.fundmaster;

import com.cwan.lpx.domain.FundIdNameResponseProjection;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FundMasterRepository extends JpaRepository<FundMasterEntity, Long> {

  Collection<FundMasterEntity> findAllByIdIn(Collection<Long> fundIds);

  Collection<FundMasterEntity> findAllByEinIn(Collection<String> eins);

  @Query(
      "SELECT f from FundMasterEntity f where f.id in (SELECT fi.id.fundId from FundInternalMappingEntity fi)")
  Collection<FundMasterEntity> findAllInternalFunds();

  @Query(
      "SELECT f.id as id,f.name as name from FundMasterEntity f where f.id in (SELECT fi.id.fundId from FundInternalMappingEntity fi)")
  Collection<FundIdNameResponseProjection> findAllInternalFundsNameAndIds();

  @Query(
      "SELECT NEW com.cwan.pbor.fundmaster.FundMasterEntityPreqinCompositeKey(f.id, f.preqinFundId) FROM FundMasterEntity f WHERE f.preqinFundId IS NOT NULL")
  Collection<FundMasterEntityPreqinCompositeKey> getExistingPreqinFundIds();

  @Query("SELECT f.id FROM FundMasterEntity f WHERE f.preqinFundId = :preqinFundId")
  Long findIdByPreqinFundId(String preqinFundId);
}
