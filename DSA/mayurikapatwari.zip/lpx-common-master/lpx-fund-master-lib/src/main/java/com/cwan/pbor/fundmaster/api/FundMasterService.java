package com.cwan.pbor.fundmaster.api;

import com.cwan.pbor.fundmaster.Fund;
import com.cwan.pbor.fundmaster.FundAliasKey;
import com.cwan.pbor.fundmaster.FundIdentifier;
import com.cwan.pbor.fundmaster.FundInternalMappingEntity;
import com.cwan.pbor.fundmaster.FundMasterEntity;
import com.cwan.pbor.fundmaster.FundMasterOverrideEntity;
import com.cwan.pbor.fundmaster.ManagementFeesEntity;
import com.cwan.pbor.fundmaster.PortfolioCompanyEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

public interface FundMasterService {

  Collection<Fund> getFundInfoFromSecurities(Collection<Long> securityIds);

  @JsonIgnoreProperties
  Map<Long, FundMasterEntity> getFundMasterEntitiesWithOverrides(
      Collection<Long> securityIds, Long clientId);

  Map<Long, Set<Long>> getFundIdsForSecurities(Collection<Long> securityIds);

  Collection<Fund> getFundInfoFromSecuritiesWithOverrides(
      Collection<Long> securityIds, Long clientId);

  Map<String, FundMasterEntity> getFundMasterEntityAndOverride(Long securityId, Long clientId);

  Collection<Fund> getFundInfoFromEins(Collection<String> eins);

  Collection<FundInternalMappingEntity> getFundInternalMappingsForFunds(
      Collection<Long> fundSecurityIds);

  Collection<FundInternalMappingEntity> getFundInternalMappingsForSecurityIds(
      Collection<Long> securityIds);

  List<FundMasterEntity> saveFundMasterData(Collection<FundMasterEntity> fundMasterEntities);

  List<FundMasterEntity> savePreqinFundMasterData(Collection<FundMasterEntity> fundMasterEntities);

  FundMasterEntity savePreqinFundMasterData(FundMasterEntity fundMasterEntity);

  List<PortfolioCompanyEntity> savePortfolioCompanyData(
      Collection<PortfolioCompanyEntity> portfolioCompanyEntities);

  List<ManagementFeesEntity> saveManagementFeesData(
      Collection<ManagementFeesEntity> fundMasterEntities);

  List<FundInternalMappingEntity> saveFundInternalMappings(
      Collection<FundInternalMappingEntity> fundInternalMappingEntities);

  List<FundMasterOverrideEntity> saveFundMasterOverrides(
      Collection<FundMasterOverrideEntity> fundMasterOverrideEntities);

  FundAliasKey saveFundAlias(Long fundId, String fundAlias);

  FundMasterOverrideEntity convertFundMasterToOverride(
      FundMasterEntity fundMasterEntity, Long clientId, Long securityId)
      throws JsonProcessingException;

  Collection<FundMasterOverrideEntity> getFundMasterOverrides(
      Long clientId, Collection<Long> securityIds);

  Collection<FundIdentifier> getFundIdentifiers();

  void deleteFundMasterOverride(Long clientId, Long securityId);

  Map<Long, Set<Long>> identifyClientWithOverride(
      Set<Long> securityIds, SortedMap<Integer, Long> clientHierarchy);
}
