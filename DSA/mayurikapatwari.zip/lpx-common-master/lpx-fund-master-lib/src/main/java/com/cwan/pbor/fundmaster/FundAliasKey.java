package com.cwan.pbor.fundmaster;

import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.Hibernate;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Embeddable
public class FundAliasKey implements Serializable {
  private Long fundId;
  private String alias;

  @Override
  public int hashCode() {
    return Objects.hash(fundId, alias);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (FundAliasKey) o;
    return (fundId != null)
        && Objects.equals(fundId, that.fundId)
        && (alias != null)
        && Objects.equals(alias, that.alias);
  }
}
