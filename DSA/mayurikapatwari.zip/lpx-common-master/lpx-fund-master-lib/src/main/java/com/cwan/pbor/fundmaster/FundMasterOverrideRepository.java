package com.cwan.pbor.fundmaster;

import java.util.Collection;
import java.util.Map;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FundMasterOverrideRepository
    extends JpaRepository<FundMasterOverrideEntity, FundMasterOverrideKey> {

  Collection<FundMasterOverrideEntity> findAllByClientIdAndSecurityIdIn(
      Long clientId, Collection<Long> securityIds);

  @Query(
      "select f.clientId, f.securityId from FundMasterOverrideEntity f where f.securityId in ?2 and f.clientId = ?1")
  Map<Long, Long> findKeysByClientIdAndSecurityIdIn(Long clientId, Collection<Long> securityIds);
}
