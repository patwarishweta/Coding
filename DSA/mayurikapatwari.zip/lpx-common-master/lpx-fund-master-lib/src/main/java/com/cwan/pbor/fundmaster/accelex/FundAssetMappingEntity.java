package com.cwan.pbor.fundmaster.accelex;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
@Table(name = "fund_asset_mapping", catalog = "pabor")
public class FundAssetMappingEntity {

  @EmbeddedId private FundAssetMappingKey id;
  private LocalDate entryDate;
  private LocalDate exitDate;
}
