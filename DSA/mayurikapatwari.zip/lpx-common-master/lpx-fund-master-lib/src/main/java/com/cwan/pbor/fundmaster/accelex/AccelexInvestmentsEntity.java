package com.cwan.pbor.fundmaster.accelex;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
@Table(name = "accelex_investments", catalog = "pabor")
public class AccelexInvestmentsEntity {

  @EmbeddedId private AccelexInvestmentKey accelexInvestmentKey;
  private String dealType;
  private String dealStatus;
  private LocalDate entryDate;
  private LocalDate exitDate;
  private Double totalCapitalInvested;
  private Double remainingCapitalInvested;
  private Double totalDistributions;
  private Double otherDistributions;
  private Double residualValue;
  private Double totalValue;
  private Double fundOwnerPercent;
  private Double multipleOnInvestedCapital;
  private Double assetLtv;
  private Double assetIrr;
  private Double evEbitda;
  private Double netDebtEbitda;
  private Double totalEnterpriseValue;
  private String generalPartner;
  private Integer vehicleAccountId;
  private Long vehicleSecurityId;

  @Override
  public int hashCode() {
    return Objects.hash(
        accelexInvestmentKey,
        dealType,
        dealStatus,
        entryDate,
        exitDate,
        totalCapitalInvested,
        remainingCapitalInvested,
        totalDistributions,
        otherDistributions,
        residualValue,
        totalValue,
        fundOwnerPercent,
        multipleOnInvestedCapital,
        assetLtv,
        assetIrr,
        evEbitda,
        netDebtEbitda,
        totalEnterpriseValue,
        generalPartner);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (AccelexInvestmentsEntity) o;
    return (accelexInvestmentKey != null)
        && Objects.equals(accelexInvestmentKey, that.accelexInvestmentKey)
        && Objects.equals(dealType, that.dealType)
        && Objects.equals(dealStatus, that.dealStatus)
        && Objects.equals(entryDate, that.entryDate)
        && Objects.equals(exitDate, that.exitDate)
        && Objects.equals(totalCapitalInvested, that.totalCapitalInvested)
        && Objects.equals(remainingCapitalInvested, that.remainingCapitalInvested)
        && Objects.equals(totalDistributions, that.totalDistributions)
        && Objects.equals(otherDistributions, that.otherDistributions)
        && Objects.equals(residualValue, that.residualValue)
        && Objects.equals(totalValue, that.totalValue)
        && Objects.equals(fundOwnerPercent, that.fundOwnerPercent)
        && Objects.equals(multipleOnInvestedCapital, that.multipleOnInvestedCapital)
        && Objects.equals(assetLtv, that.assetLtv)
        && Objects.equals(assetIrr, that.assetIrr)
        && Objects.equals(evEbitda, that.evEbitda)
        && Objects.equals(netDebtEbitda, that.netDebtEbitda)
        && Objects.equals(totalEnterpriseValue, that.totalEnterpriseValue)
        && Objects.equals(generalPartner, that.generalPartner);
  }
}
