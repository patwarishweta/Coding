package com.cwan.pbor.fundmaster;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Collectors.toSet;

import com.cwan.pbor.fundmaster.api.FundMasterService;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class FundMasterServiceImpl implements FundMasterService {

  // We cannot use LocalDate.MIN due to a known issue.
  // https://bugs.openjdk.org/browse/JDK-8068959
  private static final LocalDate MIN_DATE = LocalDate.parse("1800-01-01"); // ISO_LOCAL_DATE format
  private final FundMasterRepository fundMasterRepository;
  private final ManagementFeesRepository managementFeesRepository;
  private final PortfolioCompanyRepository portfolioCompanyRepository;
  private final FundInternalMappingRepository fundInternalMappingRepository;
  private final FundMasterOverrideRepository fundMasterOverrideRepository;
  private final FundAliasRepository fundAliasRepository;

  @Autowired
  FundMasterServiceImpl(
      FundMasterRepository fundMasterRepository,
      ManagementFeesRepository managementFeesRepository,
      PortfolioCompanyRepository portfolioCompanyRepository,
      FundInternalMappingRepository fundInternalMappingRepository,
      FundMasterOverrideRepository fundMasterOverrideRepository,
      FundAliasRepository fundAliasRepository) {
    this.fundMasterRepository = fundMasterRepository;
    this.managementFeesRepository = managementFeesRepository;
    this.portfolioCompanyRepository = portfolioCompanyRepository;
    this.fundInternalMappingRepository = fundInternalMappingRepository;
    this.fundMasterOverrideRepository = fundMasterOverrideRepository;
    this.fundAliasRepository = fundAliasRepository;
  }

  @Override
  public Map<Long, Set<Long>> getFundIdsForSecurities(Collection<Long> securityIds) {
    Collection<FundInternalMappingEntity> allBySecurityIds =
        fundInternalMappingRepository.findAllByIdSecurityIdIn(securityIds);
    return allBySecurityIds.stream()
        .map(FundInternalMappingEntity::getId)
        .collect(groupingBy(FundInternalMappingKey::getFundId))
        .entrySet()
        .stream()
        .collect(
            toMap(
                Entry::getKey,
                entry ->
                    entry.getValue().stream()
                        .map(FundInternalMappingKey::getSecurityId)
                        .collect(toSet())));
  }

  @Override
  public Collection<Fund> getFundInfoFromSecurities(Collection<Long> securityIds) {
    Map<Long, Set<Long>> fundIds = getFundIdsForSecurities(securityIds);

    if (fundIds.isEmpty()) { // return early in the case there are no mappings
      return Collections.EMPTY_LIST;
    }

    List<Fund> retVal = new ArrayList<>();
    Collection<FundMasterEntity> fundMasterEntities =
        fundMasterRepository.findAllByIdIn(fundIds.keySet());

    Collection<ManagementFeesEntity> managementFeesEntities =
        managementFeesRepository.findAllByFundIdIn(fundIds.keySet());
    Collection<PortfolioCompanyEntity> portfolioCompanyEntities =
        portfolioCompanyRepository.findAllByFundIdIn(fundIds.keySet());

    for (FundMasterEntity fundMasterEntity : fundMasterEntities) {
      Set<ManagementFeesEntity> fundSpecificManagementFees =
          managementFeesEntities.stream()
              .filter(c -> Objects.equals(c.getFundId(), fundMasterEntity.getId()))
              .collect(toSet());
      Set<PortfolioCompanyEntity> fundSpecificPortfolioCompanies =
          portfolioCompanyEntities.stream()
              .filter(c -> Objects.equals(c.getFundId(), fundMasterEntity.getId()))
              .collect(toSet());

      for (Long securityId : fundIds.get(fundMasterEntity.getId())) {
        Fund fund =
            new Fund(
                securityId,
                fundMasterEntity,
                fundSpecificManagementFees,
                fundSpecificPortfolioCompanies);
        retVal.add(fund);
      }
    }
    return retVal;
  }

  @Override
  @JsonIgnoreProperties
  public Map<Long, FundMasterEntity> getFundMasterEntitiesWithOverrides(
      Collection<Long> securityIds, Long clientId) {
    Map<Long, Set<Long>> fundIds = getFundIdsForSecurities(securityIds);
    Collection<FundMasterEntity> fundMasterEntities =
        fundMasterRepository.findAllByIdIn(fundIds.keySet());
    Collection<FundMasterOverrideEntity> fundMasterOverrideEntities =
        fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(clientId, securityIds);
    Collection<Long> usedFundMasterOverrideSecurities = new ArrayList<>();

    if (fundMasterEntities.isEmpty() && fundMasterOverrideEntities.isEmpty()) {
      return Collections.emptyMap();
    }

    Map<Long, FundMasterEntity> retVal = new HashMap<>();
    for (Long fund : fundIds.keySet()) {
      FundMasterEntity matchingFundMasterEntity =
          fundMasterEntities.stream()
              .filter(c -> Objects.equals(c.getId(), fund))
              .findFirst()
              .orElse(null);
      for (Long security : fundIds.get(fund)) {
        FundMasterOverrideEntity matchingFundMasterOverrideEntity =
            fundMasterOverrideEntities.stream()
                .filter(c -> c.getSecurityId().equals(security) && c.getClientId().equals(clientId))
                .findFirst()
                .orElse(null);
        if (matchingFundMasterEntity != null && matchingFundMasterOverrideEntity != null) {
          retVal.put(
              security,
              matchingFundMasterEntity.applyOverride(
                  matchingFundMasterOverrideEntity.getOverrideObject()));
          usedFundMasterOverrideSecurities.add(matchingFundMasterOverrideEntity.getSecurityId());
        } else if (matchingFundMasterEntity != null) {
          retVal.put(security, matchingFundMasterEntity);
        } else if (matchingFundMasterOverrideEntity != null) {
          retVal.put(security, matchingFundMasterOverrideEntity.getOverrideObject());
          usedFundMasterOverrideSecurities.add(matchingFundMasterOverrideEntity.getSecurityId());
        }
      }
    }
    // Step through the fundMasterOverrides to check if any have not been added to the retVal then
    // adds them
    fundMasterOverrideEntities.stream()
        .filter(c -> !usedFundMasterOverrideSecurities.contains(c.getSecurityId()))
        .forEach(c -> retVal.put(c.getSecurityId(), c.getOverrideObject()));
    return retVal;
  }

  @Override
  @JsonIgnoreProperties(ignoreUnknown = true)
  public Collection<Fund> getFundInfoFromSecuritiesWithOverrides(
      Collection<Long> securityIds, Long clientId) {
    // Get Funds and FundMasterOverrides from database that match the provided securityIds and
    // clientId
    Collection<Fund> funds = getFundInfoFromSecurities(securityIds);
    Collection<FundMasterOverrideEntity> fundMasterOverrides =
        fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(clientId, securityIds);
    // Return if there are no funds or fundMasterOverrides
    if (funds.isEmpty() && fundMasterOverrides.isEmpty()) {
      return Collections.EMPTY_LIST;
    }
    List<Fund> retVal = new ArrayList<>();
    if (!funds.isEmpty()) {
      for (Fund fund : funds) {
        // Find matching overrides
        FundMasterOverrideEntity matchingOverride =
            fundMasterOverrides.stream()
                .filter(c -> Objects.equals(c.getSecurityId(), fund.securityId()))
                .findFirst()
                .orElse(null);
        // If there is no matching override, return the fund
        if (matchingOverride == null || matchingOverride.getOverrideObject() == null) {
          retVal.add(fund);
          continue;
        }
        // Apply the override to the fund
        FundMasterEntity extractedOverride = matchingOverride.getOverrideObject();
        Fund retFund =
            new Fund(
                fund.securityId(),
                fund.fundMasterEntity().applyOverride(extractedOverride),
                fund.managementFeesEntity(),
                fund.portfolioCompanyEntity());
        retVal.add(retFund);
      }
    }
    // Return the remaining fund overrides to ensure that any without a mapping are applied
    if (!fundMasterOverrides.isEmpty()) {
      for (FundMasterOverrideEntity fundMasterOverrideEntity : fundMasterOverrides) {
        // If the security of an override is already applied, skip it
        if (retVal.stream()
            .anyMatch(
                c -> Objects.equals(c.securityId(), fundMasterOverrideEntity.getSecurityId()))) {
          continue;
        }
        // Apply the override to the fund
        retVal.add(
            new Fund(
                fundMasterOverrideEntity.getSecurityId(),
                fundMasterOverrideEntity.getOverrideObject(),
                null,
                null));
      }
    }
    // Return the funds
    return retVal;
  }

  /**
   * Retrieves the fund master entity and override entity based on the provided security ID and
   * client ID.
   *
   * @param securityId The security ID used to identify the fundmaster entity and override entity.
   * @param clientId The client ID used to retrieve the override entity.
   * @return A map containing the fund master entity and override entity, with the keys
   *     "fundMasterEntity" and "overrideEntity" respectively.
   */
  @Override
  @JsonIgnoreProperties(ignoreUnknown = true)
  public Map<String, FundMasterEntity> getFundMasterEntityAndOverride(
      Long securityId, Long clientId) {
    FundMasterEntity fundMasterEntity = null;
    FundMasterEntity overrideEntity = null;
    // Retrieve Fund Mappings, if no mapping exists, leave fundMasterEntity as null
    Collection<FundInternalMappingEntity> fundMapping =
        fundInternalMappingRepository.findAllByIdSecurityIdIn(List.of(securityId));
    if (!fundMapping.isEmpty()) {
      Long fundId = fundMapping.stream().findFirst().orElseThrow().getId().getFundId();
      Collection<FundMasterEntity> fundMasterEntities =
          fundMasterRepository.findAllById(List.of(fundId));
      if (!fundMasterEntities.isEmpty()) {
        fundMasterEntity = fundMasterEntities.stream().findFirst().orElseThrow();
      }
    }
    // Retrieve override entity, if no override exists, leave overrideEntity as null
    Collection<FundMasterOverrideEntity> fundMasterOverride =
        fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(
            clientId, Collections.singleton(securityId));
    if (!fundMasterOverride.isEmpty()) {
      overrideEntity = fundMasterOverride.stream().findFirst().orElseThrow().getOverrideObject();
    }
    Map<String, FundMasterEntity> retVal = new HashMap<>();
    retVal.put("fundMasterEntity", fundMasterEntity);
    retVal.put("overrideEntity", overrideEntity);
    return retVal;
  }

  @Override
  public Collection<Fund> getFundInfoFromEins(Collection<String> eins) {
    Collection<FundMasterEntity> fundMasterEntities = fundMasterRepository.findAllByEinIn(eins);
    Set<Long> fundIds = fundMasterEntities.stream().map(FundMasterEntity::getId).collect(toSet());

    Collection<ManagementFeesEntity> managementFeesEntities =
        managementFeesRepository.findAllByFundIdIn(fundIds);
    Collection<PortfolioCompanyEntity> portfolioCompanyEntities =
        portfolioCompanyRepository.findAllByFundIdIn(fundIds);

    List<Fund> retVal = new ArrayList<>();
    for (FundMasterEntity fundMasterEntity : fundMasterEntities) {
      Set<ManagementFeesEntity> fundSpecificManagementFees =
          managementFeesEntities.stream()
              .filter(c -> Objects.equals(c.getFundId(), fundMasterEntity.getId()))
              .collect(toSet());
      Set<PortfolioCompanyEntity> fundSpecificPortfolioCompanies =
          portfolioCompanyEntities.stream()
              .filter(c -> Objects.equals(c.getFundId(), fundMasterEntity.getId()))
              .collect(toSet());
      Fund fund =
          new Fund(
              null, fundMasterEntity, fundSpecificManagementFees, fundSpecificPortfolioCompanies);
      retVal.add(fund);
    }
    return retVal;
  }

  @Override
  public Collection<FundInternalMappingEntity> getFundInternalMappingsForFunds(
      Collection<Long> fundSecurityIds) {
    return fundInternalMappingRepository.findAllByIdFundIdIn(fundSecurityIds);
  }

  @Override
  public Collection<FundInternalMappingEntity> getFundInternalMappingsForSecurityIds(
      Collection<Long> securityIds) {
    return fundInternalMappingRepository.findAllByIdSecurityIdIn(securityIds);
  }

  @Override
  public List<FundMasterEntity> saveFundMasterData(
      Collection<FundMasterEntity> fundMasterEntities) {
    return fundMasterRepository.saveAllAndFlush(fundMasterEntities);
  }

  @Override
  public List<FundMasterEntity> savePreqinFundMasterData(
      Collection<FundMasterEntity> fundMasterEntities) {
    // Get all existing ids and respective preqinFundIds (if set).
    Collection<FundMasterEntityPreqinCompositeKey> existingPreqinFundIds =
        fundMasterRepository.getExistingPreqinFundIds();

    Map<String, Long> preqinFundIdsToIds =
        existingPreqinFundIds.stream()
            .collect(
                toMap(
                    FundMasterEntityPreqinCompositeKey::getPreqinFundId,
                    FundMasterEntityPreqinCompositeKey::getId));

    // Attach the 'id' if the preqinFundId already exists in the
    // database so the other attributes can be updated.
    List<FundMasterEntity> entitiesToSave =
        fundMasterEntities.stream()
            .peek(
                f -> {
                  // Assumes that the preqin_fund_id column is unique
                  // and has a 1:1 map to the 'id' column.
                  f.setId(preqinFundIdsToIds.get(f.getPreqinFundId()));
                })
            .toList();
    return fundMasterRepository.saveAllAndFlush(entitiesToSave);
  }

  @Override
  public FundMasterEntity savePreqinFundMasterData(FundMasterEntity fundMasterEntity) {
    // Lookup the 'id' from the new FundMasterEntity. If the preqinFundId returns an existing id,
    // add that id to the entity.
    Long existingId = fundMasterRepository.findIdByPreqinFundId(fundMasterEntity.getPreqinFundId());
    if (existingId != null) {
      // Add the existing id to the new FundMasterEntity
      fundMasterEntity.setId(existingId);
    }

    return fundMasterRepository.saveAndFlush(fundMasterEntity);
  }

  @Override
  public List<PortfolioCompanyEntity> savePortfolioCompanyData(
      Collection<PortfolioCompanyEntity> portfolioCompanyEntities) {
    return portfolioCompanyRepository.saveAllAndFlush(portfolioCompanyEntities);
  }

  @Override
  public List<ManagementFeesEntity> saveManagementFeesData(
      Collection<ManagementFeesEntity> managementFeesEntities) {
    return managementFeesRepository.saveAllAndFlush(managementFeesEntities);
  }

  @Override
  public List<FundInternalMappingEntity> saveFundInternalMappings(
      Collection<FundInternalMappingEntity> fundInternalMappingEntities) {
    return fundInternalMappingRepository.saveAllAndFlush(fundInternalMappingEntities);
  }

  @Override
  public List<FundMasterOverrideEntity> saveFundMasterOverrides(
      Collection<FundMasterOverrideEntity> fundMasterOverrideEntities) {
    return fundMasterOverrideRepository.saveAllAndFlush(fundMasterOverrideEntities);
  }

  @Override
  public FundAliasKey saveFundAlias(Long fundId, String fundAlias) {
    return fundAliasRepository
        .saveAndFlush(new FundAliasEntity(new FundAliasKey(fundId, fundAlias)))
        .getFundAliasKey();
  }

  @Override
  public FundMasterOverrideEntity convertFundMasterToOverride(
      FundMasterEntity fundMasterEntity, Long clientId, Long securityId) {
    return FundMasterOverrideEntity.builder()
        .clientId(clientId)
        .securityId(securityId)
        .overrideObject(fundMasterEntity)
        .build();
  }

  @Override
  public Collection<FundMasterOverrideEntity> getFundMasterOverrides(
      Long clientId, Collection<Long> securityIds) {
    return fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(clientId, securityIds);
  }

  @Override
  public Collection<FundIdentifier> getFundIdentifiers() {
    List<FundMasterEntity> funds = fundMasterRepository.findAll();

    Map<Long, List<FundInternalMappingKey>> fundToSecurityId =
        fundInternalMappingRepository.findAll().stream()
            .map(FundInternalMappingEntity::getId)
            .collect(Collectors.groupingBy(FundInternalMappingKey::getFundId));

    Map<Long, List<FundAliasEntity>> fundIdKeyedAliases =
        fundAliasRepository.findAll().stream()
            .collect(groupingBy(aliasEntity -> aliasEntity.getFundAliasKey().getFundId()));

    Set<FundIdentifier> retVal = new HashSet<>();
    for (FundMasterEntity fundMasterEntity : funds) {
      Long fundId = fundMasterEntity.getId();
      Set<String> aliases = new HashSet<>();
      Set<Long> securityIds = new HashSet<>();
      if (fundIdKeyedAliases.get(fundId) != null) {
        aliases =
            fundIdKeyedAliases.get(fundId).stream()
                .map(aliasEntity -> aliasEntity.getFundAliasKey().getAlias())
                .collect(toSet());
      }
      if (fundToSecurityId.get(fundId) != null) {
        securityIds =
            fundToSecurityId.get(fundId).stream()
                .map(FundInternalMappingKey::getSecurityId)
                .collect(toSet());
      }

      FundIdentifier fundIdentifier =
          new FundIdentifier(fundId, fundMasterEntity.getName(), securityIds, aliases);

      retVal.add(fundIdentifier);
    }
    return retVal;
  }

  @Override
  @Transactional
  public void deleteFundMasterOverride(Long clientId, Long securityId) {
    FundMasterOverrideKey overrideToDelete = new FundMasterOverrideKey(clientId, securityId);
    fundMasterOverrideRepository.deleteById(overrideToDelete);
  }

  /**
   * Helper method to take in a set of securityIds and a client hierarchy and return a map of
   * ClientId to where the security first appears in the hierarchy Defaulting to the original client
   * if not found. Expected clientHierarchy format
   * {"1":1234,"2":1452,"3":19375,"4":3349,"5":13350,"6":20561}
   *
   * @param securityIds The set of securityIds.
   * @param clientHierarchy The client hierarchy map.
   * @return A map of ClientId to the set of securityIds.
   */
  @Override
  public Map<Long, Set<Long>> identifyClientWithOverride(
      Set<Long> securityIds, SortedMap<Integer, Long> clientHierarchy) {
    // Set up the map to return
    Map<Long, Set<Long>> retMap = new HashMap<>();
    Set<Long> mutableSecuritySet = new HashSet<>(securityIds);
    // Step through the client hierarchy
    for (Map.Entry<Integer, Long> entry : clientHierarchy.entrySet()) {
      // Check if any securityIds remain
      if (mutableSecuritySet.isEmpty()) {
        break;
      }
      // Return a list of overrides that match the selected client
      Map<Long, Long> overrides =
          fundMasterOverrideRepository.findKeysByClientIdAndSecurityIdIn(
              entry.getValue(), mutableSecuritySet);
      if (!overrides.isEmpty()) {
        // Add the securities that have overrides at this level to the return map against current
        // client
        Set<Long> foundSecIds = new HashSet<>(overrides.values());
        retMap.put(entry.getValue(), foundSecIds);
        // Remove the securities that have overrides at this level from the securityIds
        mutableSecuritySet.removeAll(foundSecIds);
      }
    }
    // Add the remaining securityIds to the return map
    if (!mutableSecuritySet.isEmpty()) {
      retMap.put(clientHierarchy.get(clientHierarchy.firstKey()), mutableSecuritySet);
    }
    return retMap;
  }
}
