package com.cwan.pbor.fundmaster;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FundAliasRepository extends JpaRepository<FundAliasEntity, Long> {}
