package com.cwan.pbor.fundmaster;

import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PortfolioCompanyRepository extends JpaRepository<PortfolioCompanyEntity, Long> {

  Collection<PortfolioCompanyEntity> findAllByFundIdIn(Collection<Long> fundIds);
}
