package com.cwan.pbor.fundmaster;

import com.cwan.lpx.domain.SecurityFundResponseProjection;
import java.util.Collection;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FundInternalMappingRepository
    extends JpaRepository<FundInternalMappingEntity, Long> {
  Collection<FundInternalMappingEntity> findAllByIdSecurityIdIn(Collection<Long> securityId);

  Collection<FundInternalMappingEntity> findAllByIdFundIdIn(Collection<Long> fundId);

  @Query(
      "select fi.id.securityId as securityId, fi.id.fundId as fundId, fm.name as name "
          + "from FundInternalMappingEntity fi join FundMasterEntity fm on "
          + "fi.id.fundId = fm.id where fi.id.fundId in "
          + "(select fime.id.fundId from FundInternalMappingEntity fime where fime.id.securityId in :securityIds)")
  Collection<SecurityFundResponseProjection> findAllBySecurityIds(Set<Long> securityIds);
}
