package com.cwan.pbor.fundmaster.accelex.api;

import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsRepository;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyRepository;
import com.cwan.pbor.fundmaster.accelex.FundAssetMappingEntity;
import com.cwan.pbor.fundmaster.accelex.FundAssetMappingRepository;
import com.cwan.pbor.fundmaster.accelex.FundMetricEntity;
import com.cwan.pbor.fundmaster.accelex.FundMetricsRepository;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AccelexCommonServiceImpl implements AccelexCommonService {

  private final AccelexInvestmentsRepository accelexInvestmentsRepository;
  private final AccelexPortfolioCompanyRepository accelexPortfolioCompanyRepository;
  private final FundAssetMappingRepository fundAssetMappingRepository;
  private final FundMetricsRepository fundMetricsRepository;

  @Autowired
  AccelexCommonServiceImpl(
      AccelexInvestmentsRepository accelexInvestmentsRepository,
      AccelexPortfolioCompanyRepository accelexPortfolioCompanyRepository,
      FundAssetMappingRepository fundAssetMappingRepository,
      FundMetricsRepository fundMetricsRepository) {
    this.accelexPortfolioCompanyRepository = accelexPortfolioCompanyRepository;
    this.accelexInvestmentsRepository = accelexInvestmentsRepository;
    this.fundAssetMappingRepository = fundAssetMappingRepository;
    this.fundMetricsRepository = fundMetricsRepository;
  }

  @Override
  public Collection<AccelexInvestmentsEntity> getAccelexInvestments() {
    return accelexInvestmentsRepository.findAll();
  }

  @Override
  public Collection<AccelexInvestmentsEntity> getAccelexInvestmentsBySecurityIds(
      Collection<Long> securityIds, LocalDate asOfDate) {
    return accelexInvestmentsRepository
        .findAllByAccelexInvestmentKeySecurityIdInAndAccelexInvestmentKeyReportDateIs(
            securityIds, asOfDate);
  }

  @Override
  public Collection<AccelexInvestmentsEntity> getRecentAccelexInvestmentsBySecurityIdAndDate(
      Collection<Long> securityIds, LocalDate asOfDate) {
    return accelexInvestmentsRepository.getRecentAccelexInvestmentsBySecurityIdAndDate(
        securityIds, asOfDate);
  }

  @Override
  public Collection<AccelexPortfolioCompanyEntity> getAccelexPortfolioCompanies() {

    return accelexPortfolioCompanyRepository.findAll();
  }

  @Override
  public Collection<AccelexPortfolioCompanyEntity>
      getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
          Collection<Long> securityIds, LocalDate asOfDate) {
    return accelexPortfolioCompanyRepository.getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
        securityIds, asOfDate);
  }

  @Override
  public Collection<FundAssetMappingEntity> getFundAssetMappingsForFunds(Collection<Long> fundIds) {
    return fundAssetMappingRepository.findAllByIdFundIdIn(fundIds);
  }

  @Override
  public Collection<FundAssetMappingEntity> getFundAssetMappingsForSecurityIds(
      Collection<Long> assetSecurityIds) {
    return fundAssetMappingRepository.findAllByIdAssetSecurityIdIn(assetSecurityIds);
  }

  @Override
  public List<FundAssetMappingEntity> saveFundAssetMappings(
      Collection<FundAssetMappingEntity> fundAssetMappingEntities) {
    return fundAssetMappingRepository.saveAllAndFlush(fundAssetMappingEntities);
  }

  @Override
  public Collection<AccelexPortfolioCompanyEntity> saveAccelexPortfolioCompanies(
      Collection<AccelexPortfolioCompanyEntity> accelexPortfolioCompanyEntities) {
    return accelexPortfolioCompanyRepository.saveAllAndFlush(accelexPortfolioCompanyEntities);
  }

  @Override
  public Collection<AccelexInvestmentsEntity> saveAccelexInvestments(
      Collection<AccelexInvestmentsEntity> accelexInvestmentsEntities) {
    return accelexInvestmentsRepository.saveAllAndFlush(accelexInvestmentsEntities);
  }

  @Override
  public Collection<FundMetricEntity> getRecentFundMetricsByFundIdAndDate(
      Collection<Long> fundIds, LocalDate asOfDate) {
    return fundMetricsRepository.getRecentFundMetricsByFundIdAndDate(fundIds, asOfDate);
  }
}
