package com.cwan.pbor.fundmaster.accelex;

import java.time.LocalDate;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FundMetricsRepository extends JpaRepository<FundMetricEntity, Long> {

  @Query(
      nativeQuery = true,
      value =
          """
          select
              fs.id,
              fs.fund_id,
              vehicle_name,
              currency,
              date,
              fund_nav
          from
              financial_statement fs
              join
              (
                  select
                      fund_id, max(date)  as max
                  from
                      financial_statement
                  where
                      date <= :asOfDate
                      and fund_id in (:fundIds)
                      and type != 'Forecast'
                  group by fund_id
              ) maxDate on maxDate.fund_id = fs.fund_id and maxDate.max = fs.date
          where
              fs.fund_id in (:fundIds)
              and fs.type != 'Forecast'
              and fs.fund_nav is not null
              """)
  Collection<FundMetricEntity> getRecentFundMetricsByFundIdAndDate(
      Collection<Long> fundIds, LocalDate asOfDate);
}
