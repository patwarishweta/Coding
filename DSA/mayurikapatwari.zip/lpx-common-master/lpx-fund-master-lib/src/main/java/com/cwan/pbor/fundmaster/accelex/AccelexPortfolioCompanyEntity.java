package com.cwan.pbor.fundmaster.accelex;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
@Table(name = "accelex_portfolio_company", catalog = "pabor")
public class AccelexPortfolioCompanyEntity {

  @EmbeddedId private AccelexPortfolioCompanyKey accelexPortfolioCompanyKey;
  private Integer vehicleAccountId;
  private Long vehicleSecurityId;
  private String assetCurrency;
  private String sector;
  private String gicsIndustry;
  private String country;
  private String city;
  private String geographicRegion;
  private String propertyArea;
  private String propertyType;
  private Boolean publiclyListed;
  private String website;
  private Double ebit;
  private Double ebitda;
  private Double netRevenue;
  private Double netIncome;
  private Double netDebt;
  private Integer headcount;
  private Double capEx;
  private Double operatingCashFlow;
  private Double freeCashFlow;
  private Double netSeniorDebt;
  private String generalPartner;

  @Override
  public int hashCode() {
    return Objects.hash(
        accelexPortfolioCompanyKey,
        assetCurrency,
        sector,
        gicsIndustry,
        country,
        city,
        geographicRegion,
        propertyArea,
        propertyType,
        publiclyListed,
        website,
        ebit,
        ebitda,
        netRevenue,
        netIncome,
        netDebt,
        headcount,
        capEx,
        operatingCashFlow,
        freeCashFlow,
        netSeniorDebt,
        generalPartner);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (AccelexPortfolioCompanyEntity) o;
    return (accelexPortfolioCompanyKey != null)
        && Objects.equals(accelexPortfolioCompanyKey, that.accelexPortfolioCompanyKey)
        && Objects.equals(assetCurrency, that.assetCurrency)
        && Objects.equals(sector, that.sector)
        && Objects.equals(gicsIndustry, that.gicsIndustry)
        && Objects.equals(country, that.country)
        && Objects.equals(city, that.city)
        && Objects.equals(geographicRegion, that.geographicRegion)
        && Objects.equals(propertyArea, that.propertyArea)
        && Objects.equals(propertyType, that.propertyType)
        && Objects.equals(publiclyListed, that.publiclyListed)
        && Objects.equals(website, that.website)
        && Objects.equals(ebit, that.ebit)
        && Objects.equals(ebitda, that.ebitda)
        && Objects.equals(netRevenue, that.netRevenue)
        && Objects.equals(netIncome, that.netIncome)
        && Objects.equals(netDebt, that.netDebt)
        && Objects.equals(headcount, that.headcount)
        && Objects.equals(capEx, that.capEx)
        && Objects.equals(operatingCashFlow, that.operatingCashFlow)
        && Objects.equals(freeCashFlow, that.freeCashFlow)
        && Objects.equals(netSeniorDebt, that.netSeniorDebt)
        && Objects.equals(generalPartner, that.generalPartner);
  }
}
