package com.cwan.pbor.fundmaster.accelex;

import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FundAssetMappingRepository extends JpaRepository<FundAssetMappingEntity, Long> {
  Collection<FundAssetMappingEntity> findAllByIdFundIdIn(Collection<Long> fundId);

  Collection<FundAssetMappingEntity> findAllByIdAssetSecurityIdIn(Collection<Long> assetSecurityId);
}
