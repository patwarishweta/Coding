package com.cwan.pbor.fundmaster;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "portfolio_company", catalog = "pabor")
public class PortfolioCompanyEntity {

  @Id private Long fundId;
  private Integer companyId;
  private String company;
  private String sector1;
  private String sector2;
  private String sector3;
  private String countryOfRisk;
  private String countryOfIncorporation;
  private LocalDate investmentDate;
  private Double totalInvestment;
  private Double percentageOfOwnership;
  private Long securityId;
  private String assetName;
  private Integer investmentType;
  private Integer statusOfListing;
  private String assetInitialInvestmentStage;
  private String assetDealType;
  private String companyType;
  private String geography;

  @Override
  public int hashCode() {
    return Objects.hash(fundId);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (PortfolioCompanyEntity) o;
    return (fundId != null) && Objects.equals(fundId, that.fundId);
  }
}
