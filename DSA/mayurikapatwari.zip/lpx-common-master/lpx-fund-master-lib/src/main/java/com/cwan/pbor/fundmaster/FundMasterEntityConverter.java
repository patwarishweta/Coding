package com.cwan.pbor.fundmaster;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Converter(autoApply = true)
public class FundMasterEntityConverter implements AttributeConverter<FundMasterEntity, String> {

  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  static {
    OBJECT_MAPPER.registerModule(new JavaTimeModule());
    OBJECT_MAPPER.setSerializationInclusion(Include.NON_NULL);
  }

  @Override
  public String convertToDatabaseColumn(FundMasterEntity fundMasterEntity) {
    try {
      return OBJECT_MAPPER.writeValueAsString(fundMasterEntity);
    } catch (JsonProcessingException ex) {
      log.error("Error while converting fundMasterEntity to db column", ex);
      return null;
    }
  }

  @Override
  public FundMasterEntity convertToEntityAttribute(String dbData) {
    try {
      return OBJECT_MAPPER.readValue(dbData, FundMasterEntity.class);
    } catch (JsonProcessingException ex) {
      log.error("Error while converting db column to fundMasterEntity", ex);
      return null;
    }
  }
}
