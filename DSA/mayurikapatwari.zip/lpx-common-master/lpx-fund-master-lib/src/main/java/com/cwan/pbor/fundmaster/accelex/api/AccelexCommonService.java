package com.cwan.pbor.fundmaster.accelex.api;

import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.accelex.FundAssetMappingEntity;
import com.cwan.pbor.fundmaster.accelex.FundMetricEntity;
import java.time.LocalDate;
import java.util.Collection;

public interface AccelexCommonService {

  Collection<AccelexInvestmentsEntity> getAccelexInvestments();

  Collection<AccelexInvestmentsEntity> getAccelexInvestmentsBySecurityIds(
      Collection<Long> securityIds, LocalDate asOfDate);

  Collection<AccelexInvestmentsEntity> getRecentAccelexInvestmentsBySecurityIdAndDate(
      Collection<Long> securityIds, LocalDate asOfDate);

  Collection<AccelexPortfolioCompanyEntity> getAccelexPortfolioCompanies();

  Collection<AccelexPortfolioCompanyEntity> getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
      Collection<Long> securityIds, LocalDate asOfDate);

  Collection<FundAssetMappingEntity> getFundAssetMappingsForFunds(Collection<Long> fundIds);

  Collection<FundAssetMappingEntity> getFundAssetMappingsForSecurityIds(
      Collection<Long> assetSecurityIds);

  Collection<AccelexPortfolioCompanyEntity> saveAccelexPortfolioCompanies(
      Collection<AccelexPortfolioCompanyEntity> accelexPortfolioCompanyEntities);

  Collection<AccelexInvestmentsEntity> saveAccelexInvestments(
      Collection<AccelexInvestmentsEntity> accelexInvestmentsEntities);

  Collection<FundAssetMappingEntity> saveFundAssetMappings(
      Collection<FundAssetMappingEntity> fundAssetMappingEntities);

  Collection<FundMetricEntity> getRecentFundMetricsByFundIdAndDate(
      Collection<Long> fundIds, LocalDate asOfDate);
}
