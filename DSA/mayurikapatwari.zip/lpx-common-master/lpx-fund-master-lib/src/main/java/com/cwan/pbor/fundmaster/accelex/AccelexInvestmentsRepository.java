package com.cwan.pbor.fundmaster.accelex;

import java.time.LocalDate;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AccelexInvestmentsRepository
    extends JpaRepository<AccelexInvestmentsEntity, Long> {
  Collection<AccelexInvestmentsEntity>
      findAllByAccelexInvestmentKeySecurityIdInAndAccelexInvestmentKeyReportDateIs(
          Collection<Long> securityId, LocalDate asOfDate);

  @Query(
      nativeQuery = true,
      value =
          """
                  select
                      coalesce(ffy.security_id, ltm.security_id, inc.security_id, base.security_id, base2.security_id) as security_id,
                      coalesce(ffy.vehicle_name, ltm.vehicle_name, inc.vehicle_name, base.vehicle_name, base2.vehicle_name) as vehicle_name,
                      coalesce(ffy.general_partner, ltm.general_partner, inc.general_partner, base.general_partner, base2.general_partner) as general_partner,
                      coalesce(ffy.document_name, ltm.document_name, inc.document_name, base.document_name, base2.document_name) as document_name,
                      coalesce(ffy.report_date, ltm.report_date, inc.report_date, base.report_date, base2.report_date) as report_date,
                      coalesce(ffy.asset_name, ltm.asset_name, inc.asset_name, base.asset_name, base2.asset_name) as asset_name,
                      coalesce(ffy.period_type, ltm.period_type, inc.period_type, base.period_type, base2.period_type, '') as period_type,
                      coalesce(ffy.date, ltm.date, inc.date, base.date, base2.date, '1900-01-01') as date,
                      coalesce(ffy.type, ltm.type, inc.type, base.type, base2.type, '') as type,
                      coalesce(ffy.deal_type, ltm.deal_type, inc.deal_type, base.deal_type, base2.deal_type) as deal_type,
                      coalesce(ffy.deal_status, ltm.deal_status, inc.deal_status, base.deal_status, base2.deal_status) as deal_status,
                      coalesce(ffy.entry_date, ltm.entry_date, inc.entry_date, base.entry_date, base2.entry_date) as entry_date,
                      coalesce(ffy.exit_date, ltm.exit_date, inc.exit_date, base.exit_date, base2.exit_date) as exit_date,
                      coalesce(ffy.total_capital_invested, ltm.total_capital_invested, inc.total_capital_invested,
                                base.total_capital_invested, base2.total_capital_invested) as total_capital_invested,
                      coalesce(ffy.remaining_capital_invested, ltm.remaining_capital_invested, inc.remaining_capital_invested,
                                base.remaining_capital_invested, base2.remaining_capital_invested) as remaining_capital_invested,
                      coalesce(ffy.total_distributions, ltm.total_distributions, inc.total_distributions, base.total_distributions, base2.total_distributions) as total_distributions,
                      coalesce(ffy.other_distributions, ltm.other_distributions, inc.other_distributions, base.other_distributions, base2.other_distributions) as other_distributions,
                      coalesce(ffy.residual_value, ltm.residual_value, inc.residual_value, base.residual_value, base2.residual_value) as residual_value,
                      coalesce(ffy.total_value, ltm.total_value, inc.total_value, base.total_value, base2.total_value) as total_value,
                      coalesce(ffy.fund_owner_percent, ltm.fund_owner_percent, inc.fund_owner_percent, base.fund_owner_percent, base2.fund_owner_percent) as fund_owner_percent,
                      coalesce(ffy.multiple_on_invested_capital, ltm.multiple_on_invested_capital, inc.multiple_on_invested_capital,
                                base.multiple_on_invested_capital, base2.multiple_on_invested_capital) as multiple_on_invested_capital,
                      coalesce(ffy.asset_ltv, ltm.asset_ltv, inc.asset_ltv, base.asset_ltv, base2.asset_ltv) as asset_ltv,
                      coalesce(ffy.asset_irr, ltm.asset_irr, inc.asset_irr, base.asset_irr, base2.asset_irr) as asset_irr,
                      coalesce(ffy.ev_ebitda, ltm.ev_ebitda, inc.ev_ebitda, base.ev_ebitda, base2.ev_ebitda) as ev_ebitda,
                      coalesce(ffy.net_debt_ebitda, ltm.net_debt_ebitda, inc.net_debt_ebitda,
                                base.net_debt_ebitda, base2.net_debt_ebitda) as net_debt_ebitda,
                      coalesce(ffy.total_enterprise_value, ltm.total_enterprise_value, inc.total_enterprise_value,
                                base.total_enterprise_value, base2.total_enterprise_value) as total_enterprise_value,
                      coalesce(ffy.vehicle_account_id, ltm.vehicle_account_id, inc.vehicle_account_id, base.vehicle_account_id, base2.vehicle_account_id) as vehicle_account_id,
                      coalesce(ffy.vehicle_security_id, ltm.vehicle_security_id, inc.vehicle_security_id, base.vehicle_security_id, base2.vehicle_security_id) as vehicle_security_id
                  from
                      (
                          select
                              max(inv.date) as maxDate, inv.security_id, inv.report_date
                          from
                              accelex_investments inv
                                  join fund_asset_mapping fam on inv.security_id = fam.asset_security_id
                          where inv.security_id in  (:securityIds) and inv.date is not null  and inv.date <= :asOfDate and (fam.exit_date is null or :asOfDate <= fam.exit_date)
                          group by inv.security_id
                      ) ceilingDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_investments
                          where
                              date is null and period_type is null
                            and security_id in  (:securityIds)
                      ) base on base.security_id = ceilingDate.security_id and base.report_date = ceilingDate.report_date
                      left join
                      (
                          select
                              *
                          from
                              accelex_investments
                          where
                              date is not null and (period_type is null or period_type = '')
                            and type != 'Forecast'
                            and security_id in  (:securityIds)
                      ) base2 on base2.security_id = ceilingDate.security_id and base2.report_date = ceilingDate.report_date and base2.date = ceilingDate.maxDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_investments
                          where
                              security_id in  (:securityIds)
                            and date is not null and period_type = 'LTM'
                      ) ltm on ltm.security_id = base.security_id and ltm.report_date = base.report_date and ltm.date = ceilingDate.maxDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_investments
                          where
                              period_type = 'FFY'
                            and security_id in  (:securityIds)
                      ) ffy on ffy.security_id = base.security_id and ffy.report_date = base.report_date and ffy.date = ceilingDate.maxDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_investments
                          where
                              period_type = 'Inception'
                            and security_id in (:securityIds)
                      ) inc on inc.security_id = base.security_id and inc.report_date = base.report_date and inc.date = ceilingDate.maxDate
                  group by security_id, vehicle_name, general_partner, document_name, report_date, asset_name, date""")
  Collection<AccelexInvestmentsEntity> getRecentAccelexInvestmentsBySecurityIdAndDate(
      Collection<Long> securityIds, LocalDate asOfDate);
}
