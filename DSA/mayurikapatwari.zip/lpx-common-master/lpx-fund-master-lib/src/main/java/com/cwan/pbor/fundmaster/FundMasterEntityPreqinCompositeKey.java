package com.cwan.pbor.fundmaster;

import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.Hibernate;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Embeddable
public class FundMasterEntityPreqinCompositeKey implements Serializable {
  private Long id;
  private String preqinFundId;

  @Override
  public int hashCode() {
    return Objects.hash(id, preqinFundId);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (FundMasterEntityPreqinCompositeKey) o;
    return (id != null)
        && Objects.equals(id, that.id)
        && (preqinFundId != null)
        && Objects.equals(preqinFundId, that.preqinFundId);
  }
}
