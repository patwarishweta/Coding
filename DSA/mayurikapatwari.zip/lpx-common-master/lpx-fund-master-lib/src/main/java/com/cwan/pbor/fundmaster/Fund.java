package com.cwan.pbor.fundmaster;

import java.util.Collection;

public record Fund(
    Long securityId,
    FundMasterEntity fundMasterEntity,
    Collection<ManagementFeesEntity> managementFeesEntity,
    Collection<PortfolioCompanyEntity> portfolioCompanyEntity) {}
