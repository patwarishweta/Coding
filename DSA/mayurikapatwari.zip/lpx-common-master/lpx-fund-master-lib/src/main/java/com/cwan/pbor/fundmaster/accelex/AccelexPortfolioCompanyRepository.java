package com.cwan.pbor.fundmaster.accelex;

import java.time.LocalDate;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AccelexPortfolioCompanyRepository
    extends JpaRepository<AccelexPortfolioCompanyEntity, Long> {
  @Query(
      nativeQuery = true,
      value =
          """
                  select
                      coalesce(ytd.security_id, ltm.security_id, inc.security_id, base.security_id) as security_id,
                      coalesce(ytd.vehicle_account_id, ltm.vehicle_account_id, inc.vehicle_account_id, base.vehicle_account_id) as vehicle_account_id,
                      coalesce(ytd.vehicle_security_id, ltm.vehicle_security_id, inc.vehicle_security_id, base.vehicle_security_id) as vehicle_security_id,
                      coalesce(ytd.vehicle_name, ltm.vehicle_name, inc.vehicle_name, base.vehicle_name) as vehicle_name,
                      coalesce(ytd.general_partner, ltm.general_partner, inc.general_partner, base.general_partner) as general_partner,
                      coalesce(ytd.document_name, ltm.document_name, inc.document_name, base.document_name) as document_name,
                      coalesce(ytd.report_date, ltm.report_date, inc.report_date, base.report_date) as report_date,
                      coalesce(ytd.asset_name, ltm.asset_name, inc.asset_name, base.asset_name) as asset_name,
                      coalesce(ytd.period_type, ltm.period_type, inc.period_type, base.period_type, '') as period_type,
                      coalesce(ytd.date, ltm.date, inc.date, base.date, '1900-01-01') as date,
                      coalesce(ytd.asset_currency, ltm.asset_currency, inc.asset_currency, base.asset_currency) as asset_currency,
                      coalesce(ytd.sector, ltm.sector, inc.sector, base.sector) as sector,
                      coalesce(ytd.gics_industry, ltm.gics_industry, inc.gics_industry, base.gics_industry) as gics_industry,
                      coalesce(ytd.country, ltm.country, inc.country, base.country) as country,
                      coalesce(ytd.city, ltm.city, inc.city, base.city) as city,
                      coalesce(ytd.geographic_region, ltm.geographic_region, inc.geographic_region, base.geographic_region) as geographic_region,
                      coalesce(ytd.property_area, ltm.property_area, inc.property_area, base.property_area) as property_area,
                      coalesce(ytd.property_type, ltm.property_type, inc.property_type, base.property_area) as property_type,
                      coalesce(ytd.publicly_listed, ltm.publicly_listed, inc.publicly_listed, base.publicly_listed) as publicly_listed,
                      coalesce(ytd.website, ltm.website, inc.website, base.website) as website,
                      coalesce(ytd.ebit, ltm.ebit, inc.ebit, base.ebit) as ebit,
                      coalesce(ytd.ebitda, ltm.ebitda, inc.ebitda, base.ebitda) as ebitda,
                      coalesce(ytd.net_revenue, ltm.net_revenue, inc.net_revenue, base.net_revenue) as net_revenue,
                      coalesce(ytd.net_income, ltm.net_income, inc.net_income, base.net_income) as net_income,
                      coalesce(ytd.net_debt, ltm.net_debt, inc.net_debt, base.net_debt) as net_debt,
                      coalesce(ytd.headcount, ltm.headcount, inc.headcount, base.headcount) as headcount,
                      coalesce(ytd.cap_ex, ltm.cap_ex, inc.cap_ex, base.cap_ex) as cap_ex,
                      coalesce(ytd.operating_cash_flow, ltm.operating_cash_flow, inc.operating_cash_flow, base.operating_cash_flow) as operating_cash_flow,
                      coalesce(ytd.free_cash_flow, ltm.free_cash_flow, inc.free_cash_flow, base.free_cash_flow) as free_cash_flow,
                      coalesce(ytd.net_senior_debt, ltm.net_senior_debt, inc.net_senior_debt, base.net_senior_debt) as net_senior_debt
                  from
                      (
                          select
                              max(port.date) as maxDate, port.security_id, port.report_date
                          from accelex_portfolio_company port
                                   join fund_asset_mapping fam on port.security_id = fam.asset_security_id
                          where port.security_id in  (:securityIds) and port.date is not null and port.date <= :asOfDate and (fam.exit_date is null or :asOfDate <= fam.exit_date)
                          group by port.security_id
                      ) ceilingDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_portfolio_company
                          where
                              date is null and period_type is null
                            and security_id in  (:securityIds)
                      ) base on base.security_id = ceilingDate.security_id and base.report_date = ceilingDate.report_date
                          left join
                      (
                          select
                              *
                          from
                              accelex_portfolio_company
                          where
                              security_id in  (:securityIds)
                            and period_type = 'LTM'
                      ) ltm on ltm.security_id = ceilingDate.security_id and ltm.report_date = ceilingDate.report_date and ltm.date = ceilingDate.maxDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_portfolio_company
                          where
                              period_type = 'YTD'
                            and security_id in  (:securityIds)
                      ) ytd on ytd.security_id = ceilingDate.security_id and ytd.report_date = ceilingDate.report_date and ytd.date = ceilingDate.maxDate
                          left join
                      (
                          select
                              *
                          from
                              accelex_portfolio_company
                          where
                              period_type = 'Inception'
                            and security_id in (:securityIds)
                      ) inc on inc.security_id = ceilingDate.security_id and inc.report_date = ceilingDate.report_date and inc.date = ceilingDate.maxDate
                  group by security_id, vehicle_name, general_partner, document_name, report_date, asset_name, date""")
  Collection<AccelexPortfolioCompanyEntity> getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
      Collection<Long> securityIds, LocalDate asOfDate);
}
