package com.cwan.pbor.fundmaster;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

/**
 * BE AWARE: This class is stored in the database, any new columns should be added to the
 * FundMasterEntityConverterTest "confirmNoExceptionsShouldBeThrown" test Any changes to datatypes
 * etc. will throw an error there, review the existing stored entities before continuing.
 */
@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode
@DynamicInsert
@DynamicUpdate
@Table(name = "Fund_Master", catalog = "pabor")
public class FundMasterEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String name;
  private String cik;
  private String ein;
  private String secIdentifier;
  private String partnershipType;
  private String type;
  private String subType;
  private String status;

  @JsonFormat(pattern = "yyyyMMdd")
  private LocalDate initialClosingDate;

  @JsonFormat(pattern = "yyyyMMdd")
  private LocalDate finalClosingDate;

  private Double subsequentClosingRate;

  @JsonFormat(pattern = "yyyyMMdd")
  private LocalDate initialInvestmentDate;

  private String sector1;
  private String sector2;
  private String sector3;
  private String gpName;
  private String gpLei;
  private String gpManager;
  private Integer fundNumberSeries;
  private String fundSeriesId;
  private String fundSeriesName;
  private Long capitalCommitment;
  private Integer commitmentPeriod;
  private String waterfallType;
  private Double carriedInterest;
  private Double hurdleRate;
  private Integer investmentPeriod;
  private Integer investmentPeriodFollowOn;
  private Integer termOfFund;
  private String termExtensions;
  private Integer maxNumberOfTermExtensions;
  private Double gpCatchUp;
  private Double gpEquityContribution;
  private String propertyDetail;

  @JsonFormat(pattern = "yyyyMMdd")
  private LocalDate terminationDate;

  @JsonFormat(pattern = "yyyyMMdd")
  private LocalDate finalExitDate;

  private String reportingFrequency;
  private Integer asc810;
  private Long totalFundSize;
  private Integer reinvestmentPeriod;
  private Boolean lpGiveback;
  private Double managementFees;
  private Double managementFeesDuringCommitmentPeriod;
  private String managementFeesAfterCommitmentPeriod;
  private Boolean clawback;
  private String geography;
  private Long minInvestmentOfFund;
  private String investmentTypes;
  private Double sectorConcentrationRestrictions;
  private Double preferredReturn;
  private Double dryPowderMn;

  @JsonFormat(pattern = "yyyyMMdd")
  private LocalDate dryPowderAsAtDate;

  private Double finalCloseSize;
  private Double hardCapUsdMn;
  private Double initialTargetUsdMn;
  private Integer numLpsMax;
  private Integer numLpsMin;
  private Double targetIrrGrossMax;
  private Double targetIrrGrossMin;
  private Double targetIrrNetMax;
  private Double targetIrrNetMin;
  private Double targetSizeCurrMn;
  private Double targetSizeEurMn;
  private Double targetSizeUsdMn;
  private Double unrealisedValueMn;
  private String carriedInterestBasis;
  private String auditor;
  private String administrator;
  private String custodian;
  private String overview;
  private String preqinFundId;
  private Integer vintageYear;
  private String gpPortalUrl;
  private String documentFrequency;
  private String countryOfDomicile;
  private String fundCurrency;

  /**
   * Applies the provided override entity to the current FundMasterEntity, updating its fields with
   * non-null values from the override entity.
   *
   * @param overrideEntity The override entity containing the updated values.
   * @return A new FundMasterEntity with updated fields.
   */
  public FundMasterEntity applyOverride(FundMasterEntity overrideEntity) {
    FundMasterEntity retFundMaster = new FundMasterEntity();
    retFundMaster.setId(this.getId());
    retFundMaster.setName(
        overrideEntity.getName() != null ? overrideEntity.getName() : this.getName());
    retFundMaster.setCik(overrideEntity.getCik() != null ? overrideEntity.getCik() : this.getCik());
    retFundMaster.setEin(overrideEntity.getEin() != null ? overrideEntity.getEin() : this.getEin());
    retFundMaster.setSecIdentifier(
        overrideEntity.getSecIdentifier() != null
            ? overrideEntity.getSecIdentifier()
            : this.getSecIdentifier());
    retFundMaster.setPartnershipType(
        overrideEntity.getPartnershipType() != null
            ? overrideEntity.getPartnershipType()
            : this.getPartnershipType());
    retFundMaster.setType(
        overrideEntity.getType() != null ? overrideEntity.getType() : this.getType());
    retFundMaster.setSubType(
        overrideEntity.getSubType() != null ? overrideEntity.getSubType() : this.getSubType());
    retFundMaster.setStatus(
        overrideEntity.getStatus() != null ? overrideEntity.getStatus() : this.getStatus());
    retFundMaster.setInitialClosingDate(
        overrideEntity.getInitialClosingDate() != null
            ? overrideEntity.getInitialClosingDate()
            : this.getInitialClosingDate());
    retFundMaster.setFinalClosingDate(
        overrideEntity.getFinalClosingDate() != null
            ? overrideEntity.getFinalClosingDate()
            : this.getFinalClosingDate());
    retFundMaster.setSubsequentClosingRate(
        overrideEntity.getSubsequentClosingRate() != null
            ? overrideEntity.getSubsequentClosingRate()
            : this.getSubsequentClosingRate());
    retFundMaster.setInitialInvestmentDate(
        overrideEntity.getInitialInvestmentDate() != null
            ? overrideEntity.getInitialInvestmentDate()
            : this.getInitialInvestmentDate());
    retFundMaster.setSector1(
        overrideEntity.getSector1() != null ? overrideEntity.getSector1() : this.getSector1());
    retFundMaster.setSector2(
        overrideEntity.getSector2() != null ? overrideEntity.getSector2() : this.getSector2());
    retFundMaster.setSector3(
        overrideEntity.getSector3() != null ? overrideEntity.getSector3() : this.getSector3());
    retFundMaster.setGpName(
        overrideEntity.getGpName() != null ? overrideEntity.getGpName() : this.getGpName());
    retFundMaster.setGpLei(
        overrideEntity.getGpLei() != null ? overrideEntity.getGpLei() : this.getGpLei());
    retFundMaster.setGpManager(
        overrideEntity.getGpManager() != null
            ? overrideEntity.getGpManager()
            : this.getGpManager());
    retFundMaster.setFundNumberSeries(
        overrideEntity.getFundNumberSeries() != null
            ? overrideEntity.getFundNumberSeries()
            : this.getFundNumberSeries());
    retFundMaster.setFundSeriesId(
        overrideEntity.getFundSeriesId() != null
            ? overrideEntity.getFundSeriesId()
            : this.getFundSeriesId());
    retFundMaster.setFundSeriesName(
        overrideEntity.getFundSeriesName() != null
            ? overrideEntity.getFundSeriesName()
            : this.getFundSeriesName());
    retFundMaster.setCapitalCommitment(
        overrideEntity.getCapitalCommitment() != null
            ? overrideEntity.getCapitalCommitment()
            : this.getCapitalCommitment());
    retFundMaster.setCommitmentPeriod(
        overrideEntity.getCommitmentPeriod() != null
            ? overrideEntity.getCommitmentPeriod()
            : this.getCommitmentPeriod());
    retFundMaster.setWaterfallType(
        overrideEntity.getWaterfallType() != null
            ? overrideEntity.getWaterfallType()
            : this.getWaterfallType());
    retFundMaster.setCarriedInterest(
        overrideEntity.getCarriedInterest() != null
            ? overrideEntity.getCarriedInterest()
            : this.getCarriedInterest());
    retFundMaster.setHurdleRate(
        overrideEntity.getHurdleRate() != null
            ? overrideEntity.getHurdleRate()
            : this.getHurdleRate());
    retFundMaster.setInvestmentPeriod(
        overrideEntity.getInvestmentPeriod() != null
            ? overrideEntity.getInvestmentPeriod()
            : this.getInvestmentPeriod());
    retFundMaster.setInvestmentPeriodFollowOn(
        overrideEntity.getInvestmentPeriodFollowOn() != null
            ? overrideEntity.getInvestmentPeriodFollowOn()
            : this.getInvestmentPeriodFollowOn());
    retFundMaster.setTermOfFund(
        overrideEntity.getTermOfFund() != null
            ? overrideEntity.getTermOfFund()
            : this.getTermOfFund());
    retFundMaster.setTermExtensions(
        overrideEntity.getTermExtensions() != null
            ? overrideEntity.getTermExtensions()
            : this.getTermExtensions());
    retFundMaster.setMaxNumberOfTermExtensions(
        overrideEntity.getMaxNumberOfTermExtensions() != null
            ? overrideEntity.getMaxNumberOfTermExtensions()
            : this.getMaxNumberOfTermExtensions());
    retFundMaster.setGpCatchUp(
        overrideEntity.getGpCatchUp() != null
            ? overrideEntity.getGpCatchUp()
            : this.getGpCatchUp());
    retFundMaster.setGpEquityContribution(
        overrideEntity.getGpEquityContribution() != null
            ? overrideEntity.getGpEquityContribution()
            : this.getGpEquityContribution());
    retFundMaster.setPropertyDetail(
        overrideEntity.getPropertyDetail() != null
            ? overrideEntity.getPropertyDetail()
            : this.getPropertyDetail());
    retFundMaster.setTerminationDate(
        overrideEntity.getTerminationDate() != null
            ? overrideEntity.getTerminationDate()
            : this.getTerminationDate());
    retFundMaster.setFinalExitDate(
        overrideEntity.getFinalExitDate() != null
            ? overrideEntity.getFinalExitDate()
            : this.getFinalExitDate());
    retFundMaster.setReportingFrequency(
        overrideEntity.getReportingFrequency() != null
            ? overrideEntity.getReportingFrequency()
            : this.getReportingFrequency());
    retFundMaster.setAsc810(
        overrideEntity.getAsc810() != null ? overrideEntity.getAsc810() : this.getAsc810());
    retFundMaster.setTotalFundSize(
        overrideEntity.getTotalFundSize() != null
            ? overrideEntity.getTotalFundSize()
            : this.getTotalFundSize());
    retFundMaster.setReinvestmentPeriod(
        overrideEntity.getReinvestmentPeriod() != null
            ? overrideEntity.getReinvestmentPeriod()
            : this.getReinvestmentPeriod());
    retFundMaster.setLpGiveback(
        overrideEntity.getLpGiveback() != null
            ? overrideEntity.getLpGiveback()
            : this.getLpGiveback());
    retFundMaster.setManagementFees(
        overrideEntity.getManagementFees() != null
            ? overrideEntity.getManagementFees()
            : this.getManagementFees());
    retFundMaster.setManagementFeesDuringCommitmentPeriod(
        overrideEntity.getManagementFeesDuringCommitmentPeriod() != null
            ? overrideEntity.getManagementFeesDuringCommitmentPeriod()
            : this.getManagementFeesDuringCommitmentPeriod());
    retFundMaster.setManagementFeesAfterCommitmentPeriod(
        overrideEntity.getManagementFeesAfterCommitmentPeriod() != null
            ? overrideEntity.getManagementFeesAfterCommitmentPeriod()
            : this.getManagementFeesAfterCommitmentPeriod());
    retFundMaster.setClawback(
        overrideEntity.getClawback() != null ? overrideEntity.getClawback() : this.getClawback());
    retFundMaster.setGeography(
        overrideEntity.getGeography() != null
            ? overrideEntity.getGeography()
            : this.getGeography());
    retFundMaster.setMinInvestmentOfFund(
        overrideEntity.getMinInvestmentOfFund() != null
            ? overrideEntity.getMinInvestmentOfFund()
            : this.getMinInvestmentOfFund());
    retFundMaster.setInvestmentTypes(
        overrideEntity.getInvestmentTypes() != null
            ? overrideEntity.getInvestmentTypes()
            : this.getInvestmentTypes());
    retFundMaster.setSectorConcentrationRestrictions(
        overrideEntity.getSectorConcentrationRestrictions() != null
            ? overrideEntity.getSectorConcentrationRestrictions()
            : this.getSectorConcentrationRestrictions());
    retFundMaster.setPreferredReturn(
        overrideEntity.getPreferredReturn() != null
            ? overrideEntity.getPreferredReturn()
            : this.getPreferredReturn());
    retFundMaster.setDryPowderMn(
        overrideEntity.getDryPowderMn() != null
            ? overrideEntity.getDryPowderMn()
            : this.getDryPowderMn());
    retFundMaster.setDryPowderAsAtDate(
        overrideEntity.getDryPowderAsAtDate() != null
            ? overrideEntity.getDryPowderAsAtDate()
            : this.getDryPowderAsAtDate());
    retFundMaster.setFinalCloseSize(
        overrideEntity.getFinalCloseSize() != null
            ? overrideEntity.getFinalCloseSize()
            : this.getFinalCloseSize());
    retFundMaster.setHardCapUsdMn(
        overrideEntity.getHardCapUsdMn() != null
            ? overrideEntity.getHardCapUsdMn()
            : this.getHardCapUsdMn());
    retFundMaster.setInitialTargetUsdMn(
        overrideEntity.getInitialTargetUsdMn() != null
            ? overrideEntity.getInitialTargetUsdMn()
            : this.getInitialTargetUsdMn());
    retFundMaster.setNumLpsMax(
        overrideEntity.getNumLpsMax() != null
            ? overrideEntity.getNumLpsMax()
            : this.getNumLpsMax());
    retFundMaster.setNumLpsMin(
        overrideEntity.getNumLpsMin() != null
            ? overrideEntity.getNumLpsMin()
            : this.getNumLpsMin());
    retFundMaster.setTargetIrrGrossMax(
        overrideEntity.getTargetIrrGrossMax() != null
            ? overrideEntity.getTargetIrrGrossMax()
            : this.getTargetIrrGrossMax());
    retFundMaster.setTargetIrrGrossMin(
        overrideEntity.getTargetIrrGrossMin() != null
            ? overrideEntity.getTargetIrrGrossMin()
            : this.getTargetIrrGrossMin());
    retFundMaster.setTargetIrrNetMax(
        overrideEntity.getTargetIrrNetMax() != null
            ? overrideEntity.getTargetIrrNetMax()
            : this.getTargetIrrNetMax());
    retFundMaster.setTargetIrrNetMin(
        overrideEntity.getTargetIrrNetMin() != null
            ? overrideEntity.getTargetIrrNetMin()
            : this.getTargetIrrNetMin());
    retFundMaster.setTargetSizeCurrMn(
        overrideEntity.getTargetSizeCurrMn() != null
            ? overrideEntity.getTargetSizeCurrMn()
            : this.getTargetSizeCurrMn());
    retFundMaster.setTargetSizeEurMn(
        overrideEntity.getTargetSizeEurMn() != null
            ? overrideEntity.getTargetSizeEurMn()
            : this.getTargetSizeEurMn());
    retFundMaster.setTargetSizeUsdMn(
        overrideEntity.getTargetSizeUsdMn() != null
            ? overrideEntity.getTargetSizeUsdMn()
            : this.getTargetSizeUsdMn());
    retFundMaster.setUnrealisedValueMn(
        overrideEntity.getUnrealisedValueMn() != null
            ? overrideEntity.getUnrealisedValueMn()
            : this.getUnrealisedValueMn());
    retFundMaster.setCarriedInterestBasis(
        overrideEntity.getCarriedInterestBasis() != null
            ? overrideEntity.getCarriedInterestBasis()
            : this.getCarriedInterestBasis());
    retFundMaster.setAuditor(
        overrideEntity.getAuditor() != null ? overrideEntity.getAuditor() : this.getAuditor());
    retFundMaster.setAdministrator(
        overrideEntity.getAdministrator() != null
            ? overrideEntity.getAdministrator()
            : this.getAdministrator());
    retFundMaster.setCustodian(
        overrideEntity.getCustodian() != null
            ? overrideEntity.getCustodian()
            : this.getCustodian());
    retFundMaster.setPreqinFundId(
        overrideEntity.getPreqinFundId() != null
            ? overrideEntity.getPreqinFundId()
            : this.getPreqinFundId());
    retFundMaster.setOverview(
        overrideEntity.getOverview() != null ? overrideEntity.getOverview() : this.getOverview());
    retFundMaster.setVintageYear(
        overrideEntity.getVintageYear() != null
            ? overrideEntity.getVintageYear()
            : this.getVintageYear());
    retFundMaster.setGpPortalUrl(
        overrideEntity.getGpPortalUrl() != null
            ? overrideEntity.getGpPortalUrl()
            : this.gpPortalUrl);
    retFundMaster.setDocumentFrequency(
        overrideEntity.getDocumentFrequency() != null
            ? overrideEntity.getDocumentFrequency()
            : this.getDocumentFrequency());
    retFundMaster.setCountryOfDomicile(
        overrideEntity.getCountryOfDomicile() != null
            ? overrideEntity.getCountryOfDomicile()
            : this.getCountryOfDomicile());
    retFundMaster.setFundCurrency(
        overrideEntity.getFundCurrency() != null
            ? overrideEntity.getFundCurrency()
            : this.getFundCurrency());
    return retFundMaster;
  }
}
