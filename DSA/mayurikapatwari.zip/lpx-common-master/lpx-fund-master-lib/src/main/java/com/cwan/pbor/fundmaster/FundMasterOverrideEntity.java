package com.cwan.pbor.fundmaster;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@IdClass(FundMasterOverrideKey.class)
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
@Table(name = "Fund_Master_Override", catalog = "pabor")
public class FundMasterOverrideEntity {

  @Id private Long securityId;
  @Id private Long clientId;

  @Column(columnDefinition = "json")
  @Convert(converter = FundMasterEntityConverter.class)
  private FundMasterEntity overrideObject;
}
