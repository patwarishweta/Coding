package com.cwan.pbor.fundmaster.accelex;

import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.Hibernate;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Embeddable
public class FundAssetMappingKey implements Serializable {
  private Long fundId;
  private Long assetSecurityId;
  private LocalDateTime createdDate;

  @Override
  public int hashCode() {
    return Objects.hash(fundId, assetSecurityId, createdDate);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (FundAssetMappingKey) o;
    return (fundId != null)
        && Objects.equals(fundId, that.fundId)
        && (assetSecurityId != null)
        && Objects.equals(assetSecurityId, that.assetSecurityId)
        && Objects.equals(createdDate, that.createdDate);
  }
}
