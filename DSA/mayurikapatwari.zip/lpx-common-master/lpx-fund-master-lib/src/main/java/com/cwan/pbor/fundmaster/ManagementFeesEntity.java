package com.cwan.pbor.fundmaster;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Builder
@Table(name = "management_fees", catalog = "pabor")
public class ManagementFeesEntity {

  @Id private Long fundId;
  private LocalDate effectiveDate;
  private Double amount;
}
