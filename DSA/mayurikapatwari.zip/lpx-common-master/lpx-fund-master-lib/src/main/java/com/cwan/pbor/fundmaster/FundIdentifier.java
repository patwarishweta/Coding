package com.cwan.pbor.fundmaster;

import java.util.Set;

public record FundIdentifier(
    Long fundId, String fundName, Set<Long> securityIds, Set<String> aliases) {}
