package com.cwan.pbor.fundmaster.accelex.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexInvestmentsRepository;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyEntity;
import com.cwan.pbor.fundmaster.accelex.AccelexPortfolioCompanyRepository;
import com.cwan.pbor.fundmaster.accelex.FundAssetMappingEntity;
import com.cwan.pbor.fundmaster.accelex.FundAssetMappingRepository;
import com.cwan.pbor.fundmaster.accelex.FundMetricEntity;
import com.cwan.pbor.fundmaster.accelex.FundMetricsRepository;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AccelexCommonServiceImplTest {

  private static AccelexInvestmentsRepository accelexInvestmentsRepository =
      mock(AccelexInvestmentsRepository.class);
  private static AccelexPortfolioCompanyRepository accelexPortfolioCompanyRepository =
      mock(AccelexPortfolioCompanyRepository.class);
  private static FundAssetMappingRepository fundAssetMappingRepository =
      mock(FundAssetMappingRepository.class);
  private static AccelexInvestmentsEntity accelexInvestmentsEntity =
      AccelexInvestmentsEntity.builder().build();
  private static AccelexPortfolioCompanyEntity accelexPortfolioCompanyEntity =
      AccelexPortfolioCompanyEntity.builder().build();
  private static FundMetricsRepository fundMetricsRepository = mock(FundMetricsRepository.class);
  private static AccelexCommonServiceImpl accelexCommonService =
      new AccelexCommonServiceImpl(
          accelexInvestmentsRepository,
          accelexPortfolioCompanyRepository,
          fundAssetMappingRepository,
          fundMetricsRepository);

  @BeforeAll
  static void setUp() {
    when(accelexInvestmentsRepository.findAll()).thenReturn(List.of(accelexInvestmentsEntity));
    when(accelexPortfolioCompanyRepository.findAll())
        .thenReturn(List.of(accelexPortfolioCompanyEntity));
    when(accelexInvestmentsRepository
            .findAllByAccelexInvestmentKeySecurityIdInAndAccelexInvestmentKeyReportDateIs(
                any(), any()))
        .thenReturn(List.of(accelexInvestmentsEntity));
    when(accelexPortfolioCompanyRepository.getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
            any(), any()))
        .thenReturn(List.of(accelexPortfolioCompanyEntity));
    when(accelexPortfolioCompanyRepository.saveAllAndFlush(any()))
        .thenReturn(List.of(accelexPortfolioCompanyEntity));
    when(accelexInvestmentsRepository.saveAllAndFlush(any()))
        .thenReturn(List.of(accelexInvestmentsEntity));
  }

  @Test
  void getAccelexInvestments() {
    assertEquals(accelexCommonService.getAccelexInvestments(), List.of(accelexInvestmentsEntity));
  }

  @Test
  void getAccelexInvestmentsBySecurityIds() {
    assertEquals(
        accelexCommonService.getAccelexInvestmentsBySecurityIds(List.of(1L), null),
        List.of(accelexInvestmentsEntity));
  }

  @Test
  void getAccelexPortfolioCompanies() {
    assertEquals(
        accelexCommonService.getAccelexPortfolioCompanies(),
        List.of(accelexPortfolioCompanyEntity));
  }

  @Test
  void saveAccelexPortfolioCompanies() {
    Collection<AccelexPortfolioCompanyEntity> accelexPortfolioCompanyEntities =
        accelexCommonService.saveAccelexPortfolioCompanies(List.of(accelexPortfolioCompanyEntity));
    assertEquals(accelexPortfolioCompanyEntities, List.of(accelexPortfolioCompanyEntity));
  }

  @Test
  void saveAccelexInvestments() {
    Collection<AccelexInvestmentsEntity> accelexInvestmentsEntities =
        accelexCommonService.saveAccelexInvestments(List.of(accelexInvestmentsEntity));
    assertEquals(accelexInvestmentsEntities, List.of(accelexInvestmentsEntity));
  }

  @Test
  void getRecentAccelexInvestmentsBySecurityIdAndDate() {
    Collection<Long> securityIds = Set.of(1L, 2L);
    LocalDate asOfDate = LocalDate.now();
    Collection<AccelexInvestmentsEntity> expectedInvestments =
        List.of(new AccelexInvestmentsEntity());

    when(accelexInvestmentsRepository.getRecentAccelexInvestmentsBySecurityIdAndDate(
            securityIds, asOfDate))
        .thenReturn(expectedInvestments);

    Collection<AccelexInvestmentsEntity> actualInvestments =
        accelexCommonService.getRecentAccelexInvestmentsBySecurityIdAndDate(securityIds, asOfDate);

    assertEquals(expectedInvestments, actualInvestments);
    verify(accelexInvestmentsRepository)
        .getRecentAccelexInvestmentsBySecurityIdAndDate(securityIds, asOfDate);
  }

  @Test
  void getRecentAccelexPortfolioCompaniesBySecurityIdAndDate() {
    Collection<Long> securityIds = Set.of(1L, 2L);
    LocalDate asOfDate = LocalDate.now();
    Collection<AccelexPortfolioCompanyEntity> expectedCompanies =
        List.of(new AccelexPortfolioCompanyEntity());

    when(accelexPortfolioCompanyRepository.getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
            securityIds, asOfDate))
        .thenReturn(expectedCompanies);

    Collection<AccelexPortfolioCompanyEntity> actualCompanies =
        accelexCommonService.getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(
            securityIds, asOfDate);

    assertEquals(expectedCompanies, actualCompanies);
    verify(accelexPortfolioCompanyRepository)
        .getRecentAccelexPortfolioCompaniesBySecurityIdAndDate(securityIds, asOfDate);
  }

  @Test
  void getFundAssetMappingsForFunds() {
    Collection<Long> fundIds = Set.of(1L, 2L);
    Collection<FundAssetMappingEntity> expectedMappings = List.of(new FundAssetMappingEntity());

    when(fundAssetMappingRepository.findAllByIdFundIdIn(fundIds)).thenReturn(expectedMappings);

    Collection<FundAssetMappingEntity> actualMappings =
        accelexCommonService.getFundAssetMappingsForFunds(fundIds);

    assertEquals(expectedMappings, actualMappings);
    verify(fundAssetMappingRepository).findAllByIdFundIdIn(fundIds);
  }

  @Test
  void getFundAssetMappingsForSecurityIds() {
    Collection<Long> assetSecurityIds = Set.of(1L, 2L);
    Collection<FundAssetMappingEntity> expectedMappings = List.of(new FundAssetMappingEntity());

    when(fundAssetMappingRepository.findAllByIdAssetSecurityIdIn(assetSecurityIds))
        .thenReturn(expectedMappings);

    Collection<FundAssetMappingEntity> actualMappings =
        accelexCommonService.getFundAssetMappingsForSecurityIds(assetSecurityIds);

    assertEquals(expectedMappings, actualMappings);
    verify(fundAssetMappingRepository).findAllByIdAssetSecurityIdIn(assetSecurityIds);
  }

  @Test
  void saveFundAssetMappings() {
    List<FundAssetMappingEntity> fundAssetMappingEntities = List.of(new FundAssetMappingEntity());

    when(fundAssetMappingRepository.saveAllAndFlush(fundAssetMappingEntities))
        .thenReturn((List<FundAssetMappingEntity>) fundAssetMappingEntities);

    List<FundAssetMappingEntity> actualResults =
        accelexCommonService.saveFundAssetMappings(fundAssetMappingEntities);

    assertEquals(fundAssetMappingEntities, actualResults);
    verify(fundAssetMappingRepository).saveAllAndFlush(fundAssetMappingEntities);
  }

  @Test
  void getRecentFundMetricsByFundIdAndDate() {
    Collection<Long> fundIds = Set.of(1L, 2L);
    LocalDate asOfDate = LocalDate.now();
    Collection<FundMetricEntity> expectedMetrics = List.of(new FundMetricEntity());

    when(fundMetricsRepository.getRecentFundMetricsByFundIdAndDate(fundIds, asOfDate))
        .thenReturn(expectedMetrics);

    Collection<FundMetricEntity> actualMetrics =
        accelexCommonService.getRecentFundMetricsByFundIdAndDate(fundIds, asOfDate);

    assertEquals(expectedMetrics, actualMetrics);
    verify(fundMetricsRepository).getRecentFundMetricsByFundIdAndDate(fundIds, asOfDate);
  }
}
