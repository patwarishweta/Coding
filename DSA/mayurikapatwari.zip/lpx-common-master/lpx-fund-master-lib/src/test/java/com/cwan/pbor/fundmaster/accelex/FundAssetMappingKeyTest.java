package com.cwan.pbor.fundmaster.accelex;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class FundAssetMappingKeyTest {

  @Test
  void testHashCode() {
    LocalDateTime now = LocalDateTime.now();

    FundAssetMappingKey FundAssetMappingKey1 = new FundAssetMappingKey(1L, 10L, now);
    FundAssetMappingKey FundAssetMappingKey2 = new FundAssetMappingKey(1L, 10L, now);
    FundAssetMappingKey FundAssetMappingKey3 = new FundAssetMappingKey(1L, 20L, now);

    Set<FundAssetMappingKey> keys =
        new HashSet<>(List.of(FundAssetMappingKey1, FundAssetMappingKey2, FundAssetMappingKey3));
    assertEquals(2, keys.size());
  }

  @Test
  void testEquals() {
    LocalDateTime now = LocalDateTime.now();
    FundAssetMappingKey FundAssetMappingKey1 = new FundAssetMappingKey(1L, 10L, now);
    FundAssetMappingKey FundAssetMappingKey2 = new FundAssetMappingKey(1L, 10L, now);
    FundAssetMappingKey FundAssetMappingKey3 = new FundAssetMappingKey(1L, 20L, now);

    assertEquals(FundAssetMappingKey1, FundAssetMappingKey2);
    assertNotEquals(FundAssetMappingKey3, FundAssetMappingKey2);
  }
}
