package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class FundInternalMappingKeyTest {

  @Test
  void testHashCode() {
    FundInternalMappingKey fundInternalMappingKey1 = new FundInternalMappingKey(1L, 10L);
    FundInternalMappingKey fundInternalMappingKey2 = new FundInternalMappingKey(1L, 10L);
    FundInternalMappingKey fundInternalMappingKey3 = new FundInternalMappingKey(1L, 20L);

    Set<FundInternalMappingKey> keys =
        new HashSet<>(
            List.of(fundInternalMappingKey1, fundInternalMappingKey2, fundInternalMappingKey3));
    assertEquals(2, keys.size());
  }

  @Test
  void testEquals() {
    FundInternalMappingKey fundInternalMappingKey1 = new FundInternalMappingKey(1L, 10L);
    FundInternalMappingKey fundInternalMappingKey2 = new FundInternalMappingKey(1L, 10L);
    FundInternalMappingKey fundInternalMappingKey3 = new FundInternalMappingKey(1L, 20L);

    assertEquals(fundInternalMappingKey1, fundInternalMappingKey2);
    assertNotEquals(fundInternalMappingKey3, fundInternalMappingKey2);
  }
}
