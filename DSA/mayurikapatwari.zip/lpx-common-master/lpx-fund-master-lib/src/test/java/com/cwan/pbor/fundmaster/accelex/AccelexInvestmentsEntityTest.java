package com.cwan.pbor.fundmaster.accelex;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class AccelexInvestmentsEntityTest {

  @Test
  void testHashCode() {
    AccelexInvestmentKey AccelexInvestmentKey1 =
        AccelexInvestmentKey.builder().securityId(1l).build();
    AccelexInvestmentKey AccelexInvestmentKey2 =
        AccelexInvestmentKey.builder().securityId(1l).build();
    AccelexInvestmentKey AccelexInvestmentKey3 =
        AccelexInvestmentKey.builder().securityId(1l).build();

    AccelexInvestmentsEntity accelexInvestments1 =
        AccelexInvestmentsEntity.builder()
            .accelexInvestmentKey(AccelexInvestmentKey1)
            .dealType("test1")
            .build();
    AccelexInvestmentsEntity accelexInvestments2 =
        AccelexInvestmentsEntity.builder()
            .accelexInvestmentKey(AccelexInvestmentKey2)
            .dealType("test2")
            .build();
    AccelexInvestmentsEntity accelexInvestments3 =
        AccelexInvestmentsEntity.builder()
            .accelexInvestmentKey(AccelexInvestmentKey3)
            .dealType("test1")
            .build();

    assertEquals(AccelexInvestmentKey1.hashCode(), AccelexInvestmentKey2.hashCode());
    assertEquals(accelexInvestments1.hashCode(), accelexInvestments3.hashCode());
    assertNotEquals(accelexInvestments3.hashCode(), accelexInvestments2.hashCode());
  }

  @Test
  void testEquals() {
    AccelexInvestmentKey AccelexInvestmentKey1 =
        AccelexInvestmentKey.builder().securityId(1l).build();
    AccelexInvestmentKey AccelexInvestmentKey2 =
        AccelexInvestmentKey.builder().securityId(1l).build();
    AccelexInvestmentKey AccelexInvestmentKey3 =
        AccelexInvestmentKey.builder().securityId(1l).build();

    AccelexInvestmentsEntity accelexInvestments1 =
        AccelexInvestmentsEntity.builder()
            .accelexInvestmentKey(AccelexInvestmentKey1)
            .dealType("test1")
            .build();
    AccelexInvestmentsEntity accelexInvestments2 =
        AccelexInvestmentsEntity.builder()
            .accelexInvestmentKey(AccelexInvestmentKey2)
            .dealType("test2")
            .build();
    AccelexInvestmentsEntity accelexInvestments3 =
        AccelexInvestmentsEntity.builder()
            .accelexInvestmentKey(AccelexInvestmentKey3)
            .dealType("test1")
            .build();

    assertEquals(AccelexInvestmentKey1, AccelexInvestmentKey2);
    assertEquals(accelexInvestments1, accelexInvestments3);
    assertNotEquals(accelexInvestments3, accelexInvestments2);
  }
}
