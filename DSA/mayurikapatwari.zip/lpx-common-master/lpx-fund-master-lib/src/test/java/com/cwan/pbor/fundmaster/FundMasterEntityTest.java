package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FundMasterEntityTest {
  @Test
  void applyOverride() {
    String gpPortalUrl = "tyler.com";
    String documentFrequency = "daily";
    FundMasterEntity override =
        FundMasterEntity.builder()
            .id(1L)
            .vintageYear(2024)
            .gpPortalUrl(gpPortalUrl)
            .documentFrequency(documentFrequency)
            .build();
    FundMasterEntity base = FundMasterEntity.builder().id(1L).build();
    FundMasterEntity fundMasterEntity = base.applyOverride(override);
    assertEquals(2024, fundMasterEntity.getVintageYear());
    assertEquals(gpPortalUrl, fundMasterEntity.getGpPortalUrl());
    assertEquals(documentFrequency, fundMasterEntity.getDocumentFrequency());
  }

  @Test
  void applyOverride_defaults() {
    String gpPortalUrl = "tyler.com";
    String documentFrequency = "daily";
    String countryOfDomicile = "JorahsHouse";
    String fundCurrency = "frank";
    FundMasterEntity override =
        FundMasterEntity.builder()
            .id(1L)
            .countryOfDomicile(countryOfDomicile)
            .fundCurrency(fundCurrency)
            .build();
    FundMasterEntity base =
        FundMasterEntity.builder()
            .id(1L)
            .vintageYear(2025)
            .gpPortalUrl(gpPortalUrl)
            .documentFrequency(documentFrequency)
            .build();
    FundMasterEntity fundMasterEntity = base.applyOverride(override);
    assertEquals(2025, fundMasterEntity.getVintageYear());
    assertEquals(gpPortalUrl, fundMasterEntity.getGpPortalUrl());
    assertEquals(documentFrequency, fundMasterEntity.getDocumentFrequency());
    assertEquals(countryOfDomicile, fundMasterEntity.getCountryOfDomicile());
    assertEquals(fundCurrency, fundMasterEntity.getFundCurrency());
  }
}
