package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

class FundMasterEntityPreqinCompositeKeyTest {

  @Test
  void testHashCode() {
    FundMasterEntityPreqinCompositeKey key1 =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("1234").build();
    FundMasterEntityPreqinCompositeKey key2 =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("1234").build();
    assertEquals(key1.hashCode(), key2.hashCode(), "Hash codes should be equal");
  }

  @Test
  void testEquals() {
    FundMasterEntityPreqinCompositeKey key1 =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("1234").build();
    FundMasterEntityPreqinCompositeKey key2 =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("1234").build();
    FundMasterEntityPreqinCompositeKey key3 =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("99999").build();

    assertNotNull(key1);
    assertNotNull(key2);
    assertNotNull(key3);
    assertEquals(key1, key1);
    assertEquals(key1, key2);
    assertNotEquals(key1, key3);
  }
}
