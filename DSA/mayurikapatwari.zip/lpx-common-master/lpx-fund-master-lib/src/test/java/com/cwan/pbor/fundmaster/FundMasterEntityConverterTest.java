package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class FundMasterEntityConverterTest {

  private static final FundMasterEntityConverter fundMasterEntityConverter =
      new FundMasterEntityConverter();
  private static final FundMasterEntity fundMasterEntity =
      FundMasterEntity.builder().id(1L).ein("EINSTRING").sector1("TESTING").build();
  private static final String dbData = "{\"id\":1,\"ein\":\"EINSTRING\",\"sector1\":\"TESTING\"}";

  @Test
  void convertToDatabaseColumn() {
    String result = fundMasterEntityConverter.convertToDatabaseColumn(fundMasterEntity);
    assertEquals(dbData, result);
  }

  @Test
  void convertToEntityAttribute() {
    FundMasterEntity result = fundMasterEntityConverter.convertToEntityAttribute(dbData);
    assertEquals(fundMasterEntity, result);
  }

  @Test
  void convertToEntityAttributeSadPath() {
    String dbData = "{\"id\":1,\"oink\":\"EINSTRING\",\"sector1\":\"TESTING\"}";
    FundMasterEntity result = fundMasterEntityConverter.convertToEntityAttribute(dbData);
    assertNull(result);
  }

  /**
   * THIS TEST IS DESIGNED TO ENSURE THAT NO FIELDS ARE ADDED/REMOVED/MODIFIED IN THE
   * FUNDMASTERENTITY WITHOUT APPROPRIATE CAUTION AND CHECKS BEING DONE ON EXISTING OVERRIDES IF ANY
   * PART OF THIS TEST HAS AN ISSUE IT'S VITAL THAT YOU REVIEW THE EXISTING OVERRIDES BEFORE
   * CONTINUING IF YOU'RE JUST ADDING NEW FIELDS YOU'RE FINE BUT IF YOU'RE MODIFYING/DELETING BE
   * AWARE THESE NEED TO BE ADJUSTED IN THE DB
   */
  @Test
  void confirmNoExceptionsShouldBeThrown() {
    FundMasterEntity currentFundMasterEntity =
        FundMasterEntity.builder()
            .id(1L)
            .name("NAMESTRING")
            .cik("CIKSTRING")
            .ein("EINSTRING")
            .secIdentifier("SECIDENTIFIERSTRING")
            .partnershipType("PARTNSHIPTYPESTRING")
            .type("TYPESTRING")
            .subType("SUBTYPESTRING")
            .status("STATUSSTRING")
            .initialClosingDate(LocalDate.parse("1991-02-28"))
            .finalClosingDate(LocalDate.parse("2024-02-28"))
            .subsequentClosingRate(0.5)
            .initialInvestmentDate(LocalDate.parse("2022-06-14"))
            .sector1("SECTOR1STRING")
            .sector2("SECTOR2STRING")
            .sector3("SECTOR3STRING")
            .gpName("GPNAMESTRING")
            .gpLei("GPLEISTRING")
            .gpManager("GPMANAGERSTRING")
            .fundNumberSeries(1)
            .fundSeriesId("FUNDSERIESIDSTRING")
            .fundSeriesName("FUNDSERIESNAMESTRING")
            .capitalCommitment(100L)
            .commitmentPeriod(1)
            .waterfallType("WATERFALLTYPESTRING")
            .carriedInterest(1.5)
            .hurdleRate(1.5)
            .investmentPeriod(1)
            .investmentPeriodFollowOn(1)
            .termOfFund(1)
            .termExtensions("TERMEXTENSIONSTRING")
            .maxNumberOfTermExtensions(1)
            .gpCatchUp(1.5)
            .gpEquityContribution(1.5)
            .propertyDetail("PROPERTYDETAILSTRING")
            .terminationDate(LocalDate.parse("2024-03-31"))
            .finalExitDate(LocalDate.parse("2024-04-30"))
            .reportingFrequency("REPORTINGFREQUENCYSTRING")
            .asc810(1)
            .totalFundSize(1L)
            .reinvestmentPeriod(1)
            .lpGiveback(true)
            .managementFees(1.5)
            .managementFeesDuringCommitmentPeriod(1.5)
            .managementFeesAfterCommitmentPeriod("MANAGEMENTFEESAFTERCOMMITMENTPERIODSTRING")
            .clawback(true)
            .geography("GEOGRAPHYSTRING")
            .minInvestmentOfFund(1L)
            .investmentTypes("INVESTMENTTYPESSTRING")
            .sectorConcentrationRestrictions(1.5)
            .preferredReturn(1.5)
            .dryPowderMn(1.5)
            .dryPowderAsAtDate(LocalDate.parse("2024-02-28"))
            .finalCloseSize(1.5)
            .hardCapUsdMn(1.5)
            .initialTargetUsdMn(1.5)
            .numLpsMax(1)
            .numLpsMin(1)
            .targetIrrGrossMax(1.5)
            .targetIrrGrossMin(1.5)
            .targetIrrNetMax(1.5)
            .targetIrrNetMin(1.5)
            .targetSizeCurrMn(1.5)
            .targetSizeEurMn(1.5)
            .targetSizeUsdMn(1.5)
            .unrealisedValueMn(1.5)
            .carriedInterestBasis("CARRIEDINTERESTBASISSTRING")
            .auditor("AUDITORSTRING")
            .administrator("ADMINISTRATORSTRING")
            .custodian("CUSTODIANSTRING")
            .preqinFundId("1234567890")
            .overview("OVERVIEWSTRING")
            .vintageYear(2024)
            .gpPortalUrl("GPPORTALURLSTRING")
            .documentFrequency("DOCUMENTFREQUENCYSTRING")
            .build();
    String convertedFundMasterEntity =
        fundMasterEntityConverter.convertToDatabaseColumn(currentFundMasterEntity);

    String entityConvertedToString =
        "{\"id\":1,\"name\":\"NAMESTRING\",\"cik\":\"CIKSTRING\",\"ein\":\"EINSTRING\",\"secIdentifier\":\"SECIDENTIFIERSTRING\",\"partnershipType\":\"PARTNSHIPTYPESTRING\",\"type\":\"TYPESTRING\",\"subType\":\"SUBTYPESTRING\",\"status\":\"STATUSSTRING\",\"initialClosingDate\":\"19910228\",\"finalClosingDate\":\"20240228\",\"subsequentClosingRate\":0.5,\"initialInvestmentDate\":\"20220614\",\"sector1\":\"SECTOR1STRING\",\"sector2\":\"SECTOR2STRING\",\"sector3\":\"SECTOR3STRING\",\"gpName\":\"GPNAMESTRING\",\"gpLei\":\"GPLEISTRING\",\"gpManager\":\"GPMANAGERSTRING\",\"fundNumberSeries\":1,\"fundSeriesId\":\"FUNDSERIESIDSTRING\",\"fundSeriesName\":\"FUNDSERIESNAMESTRING\",\"capitalCommitment\":100,\"commitmentPeriod\":1,\"waterfallType\":\"WATERFALLTYPESTRING\",\"carriedInterest\":1.5,\"hurdleRate\":1.5,\"investmentPeriod\":1,\"investmentPeriodFollowOn\":1,\"termOfFund\":1,\"termExtensions\":\"TERMEXTENSIONSTRING\",\"maxNumberOfTermExtensions\":1,\"gpCatchUp\":1.5,\"gpEquityContribution\":1.5,\"propertyDetail\":\"PROPERTYDETAILSTRING\",\"terminationDate\":\"20240331\",\"finalExitDate\":\"20240430\",\"reportingFrequency\":\"REPORTINGFREQUENCYSTRING\",\"asc810\":1,\"totalFundSize\":1,\"reinvestmentPeriod\":1,\"lpGiveback\":true,\"managementFees\":1.5,\"managementFeesDuringCommitmentPeriod\":1.5,\"managementFeesAfterCommitmentPeriod\":\"MANAGEMENTFEESAFTERCOMMITMENTPERIODSTRING\",\"clawback\":true,\"geography\":\"GEOGRAPHYSTRING\",\"minInvestmentOfFund\":1,\"investmentTypes\":\"INVESTMENTTYPESSTRING\",\"sectorConcentrationRestrictions\":1.5,\"preferredReturn\":1.5,\"dryPowderMn\":1.5,\"dryPowderAsAtDate\":\"20240228\",\"finalCloseSize\":1.5,\"hardCapUsdMn\":1.5,\"initialTargetUsdMn\":1.5,\"numLpsMax\":1,\"numLpsMin\":1,\"targetIrrGrossMax\":1.5,\"targetIrrGrossMin\":1.5,\"targetIrrNetMax\":1.5,\"targetIrrNetMin\":1.5,\"targetSizeCurrMn\":1.5,\"targetSizeEurMn\":1.5,\"targetSizeUsdMn\":1.5,\"unrealisedValueMn\":1.5,\"carriedInterestBasis\":\"CARRIEDINTERESTBASISSTRING\",\"auditor\":\"AUDITORSTRING\",\"administrator\":\"ADMINISTRATORSTRING\",\"custodian\":\"CUSTODIANSTRING\",\"overview\":\"OVERVIEWSTRING\",\"preqinFundId\":\"1234567890\",\"vintageYear\":2024,\"gpPortalUrl\":\"GPPORTALURLSTRING\",\"documentFrequency\":\"DOCUMENTFREQUENCYSTRING\"}";
    // TO UPDATE THE ABOVE STRING RUN IN DEBUG AND COPY THE VALUE, ENSURE THIS IS DONE AS THE LAST
    // STEP
    FundMasterEntity entityConvertedFromString =
        fundMasterEntityConverter.convertToEntityAttribute(entityConvertedToString);

    // If this isn't equal a field has been added or removed from the class
    assertEquals(convertedFundMasterEntity, entityConvertedToString);
    // If this is null an existing field has been changed in a way which will cause saved data to no
    // longer apply
    assertNotNull(entityConvertedFromString);
  }
}
