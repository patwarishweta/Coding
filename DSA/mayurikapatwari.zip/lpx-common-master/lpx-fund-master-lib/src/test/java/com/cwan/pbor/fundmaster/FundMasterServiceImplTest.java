package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.pbor.fundmaster.accelex.FundAssetMappingRepository;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;

class FundMasterServiceImplTest {

  private FundMasterServiceImpl INSTANCE;
  private final FundMasterRepository fundMasterRepository = mock(FundMasterRepository.class);
  private final ManagementFeesRepository managementFeesRepository =
      mock(ManagementFeesRepository.class);
  private final PortfolioCompanyRepository portfolioCompanyRepository =
      mock(PortfolioCompanyRepository.class);
  private final FundInternalMappingRepository fundInternalMappingRepository =
      mock(FundInternalMappingRepository.class);
  private final FundMasterOverrideRepository fundMasterOverrideRepository =
      mock(FundMasterOverrideRepository.class);
  private final FundAssetMappingRepository fundAssetMappingRepository =
      mock(FundAssetMappingRepository.class);

  private final FundAliasRepository fundAliasRepository = mock(FundAliasRepository.class);
  private static final Long SECURITY_ID = 100L;
  private static final String ALIAS_1 = "hello";
  private static final String ALIAS_2 = "goodbye";
  private static final Long FUND_ID = 1L;
  private static final String EIN = "string";
  private static final Long CLIENT_ID = 24601L;
  private static final Long ASSET_SECURITY_ID = 1000L;
  private static final FundMasterEntity OVERRIDE_OBJECT =
      FundMasterEntity.builder()
          .sector1("SECTOR1OVERRIDDEN")
          .sector2("SECTOR2OVERRIDDEN")
          .sector3("SECTOR3OVERRIDDEN")
          .initialClosingDate(LocalDate.parse("1991-02-28"))
          .build();
  private static final FundInternalMappingEntity fundInternalMappingEntity =
      new FundInternalMappingEntity(new FundInternalMappingKey(FUND_ID, SECURITY_ID));

  private static final FundAliasEntity fundAliasEntity1 =
      new FundAliasEntity(new FundAliasKey(FUND_ID, ALIAS_1));

  private static final FundAliasEntity fundAliasEntity2 =
      new FundAliasEntity(new FundAliasKey(FUND_ID, ALIAS_2));
  private static final FundMasterEntity fundMasterEntity =
      FundMasterEntity.builder().id(FUND_ID).ein(EIN).sector1("TESTING").build();
  private static final ManagementFeesEntity managementFeesEntity =
      ManagementFeesEntity.builder().fundId(FUND_ID).build();
  private static final PortfolioCompanyEntity portfolioCompanyEntity =
      PortfolioCompanyEntity.builder().fundId(FUND_ID).build();
  private static final FundMasterOverrideEntity fundMasterOverrideEntity =
      FundMasterOverrideEntity.builder()
          .securityId(SECURITY_ID)
          .clientId(CLIENT_ID)
          .overrideObject(OVERRIDE_OBJECT)
          .build();

  @BeforeEach
  void setup() {
    when(fundInternalMappingRepository.findAllByIdSecurityIdIn(any()))
        .thenReturn(Set.of(fundInternalMappingEntity));
    when(fundMasterRepository.findAllByIdIn(any())).thenReturn(Set.of(fundMasterEntity));
    when(fundMasterRepository.findAllByEinIn(any())).thenReturn(Set.of(fundMasterEntity));
    when(managementFeesRepository.findAllByFundIdIn(any()))
        .thenReturn(Set.of(managementFeesEntity));
    when(portfolioCompanyRepository.findAllByFundIdIn(any()))
        .thenReturn(Set.of(portfolioCompanyEntity));
    when(portfolioCompanyRepository.saveAllAndFlush(any()))
        .thenReturn(List.of(portfolioCompanyEntity));
    when(managementFeesRepository.saveAllAndFlush(any())).thenReturn(List.of(managementFeesEntity));
    when(fundMasterRepository.saveAllAndFlush(any())).thenReturn(List.of(fundMasterEntity));
    when(fundInternalMappingRepository.saveAllAndFlush(any()))
        .thenReturn(List.of(fundInternalMappingEntity));
    when(fundMasterOverrideRepository.saveAllAndFlush(any()))
        .thenReturn(List.of(fundMasterOverrideEntity));
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(
            CLIENT_ID, Set.of(SECURITY_ID)))
        .thenReturn(List.of(fundMasterOverrideEntity));
    INSTANCE =
        new FundMasterServiceImpl(
            fundMasterRepository,
            managementFeesRepository,
            portfolioCompanyRepository,
            fundInternalMappingRepository,
            fundMasterOverrideRepository,
            fundAliasRepository);
  }

  @Test
  void getFundInfoFromSecurities() {
    Collection<Fund> fundInfoFromSecurities =
        INSTANCE.getFundInfoFromSecurities(Set.of(SECURITY_ID));
    Fund fund = fundInfoFromSecurities.stream().findAny().get();
    assertEquals(FUND_ID, fund.fundMasterEntity().getId());
    assertEquals(fundMasterEntity, fund.fundMasterEntity());
  }

  @Test
  void getFundInfoFromEins() {
    Collection<Fund> fundInfoFromEin = INSTANCE.getFundInfoFromEins(Set.of(EIN));
    Fund fund = fundInfoFromEin.stream().findAny().get();
    assertEquals(FUND_ID, fund.fundMasterEntity().getId());
    assertEquals(fundMasterEntity, fund.fundMasterEntity());
  }

  @Test
  void saveFundMasterData() {
    List<FundMasterEntity> fundMasterEntities =
        INSTANCE.saveFundMasterData(Set.of(fundMasterEntity));
    assertEquals(fundMasterEntity, fundMasterEntities.get(0));
  }

  @Test
  void preqinSaveDuplicateFundMasterEntity() {
    FundMasterEntity fund = FundMasterEntity.builder().name("Fund 1").preqinFundId("1234").build();
    FundMasterEntity fund_duplicate =
        FundMasterEntity.builder().name("Fund 1").preqinFundId("1234").build();

    FundMasterEntityPreqinCompositeKey fundMasterEntityFlexibleKey =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("1234").build();
    when(fundMasterRepository.getExistingPreqinFundIds())
        .thenReturn(List.of(fundMasterEntityFlexibleKey));
    when(fundMasterRepository.saveAllAndFlush(any())).thenReturn(List.of(fund));

    List<FundMasterEntity> fundMasterEntities =
        INSTANCE.savePreqinFundMasterData(List.of(fund, fund_duplicate));
    assertEquals(1, fundMasterEntities.size());
    assertEquals(1L, fundMasterEntities.get(0).getId());
    assertEquals("1234", fundMasterEntities.get(0).getPreqinFundId());
    assertEquals("Fund 1", fundMasterEntities.get(0).getName());
  }

  @Test
  void preqinUpsertFundMasterEntity() {
    FundMasterEntity fund =
        FundMasterEntity.builder()
            .name("Fund 1")
            .id(1L)
            .preqinFundId("1234")
            .auditor("Fred Flintstone")
            .build();
    FundMasterEntity fund_updated =
        FundMasterEntity.builder()
            .name("Fund 1")
            .preqinFundId("1234")
            .auditor("Wilma Flintstone")
            .build();

    FundMasterEntityPreqinCompositeKey fundMasterEntityFlexibleKey =
        FundMasterEntityPreqinCompositeKey.builder().id(1L).preqinFundId("1234").build();
    when(fundMasterRepository.getExistingPreqinFundIds())
        .thenReturn(List.of(fundMasterEntityFlexibleKey));
    when(fundMasterRepository.saveAllAndFlush(any())).thenReturn(List.of(fund_updated));

    List<FundMasterEntity> fundMasterEntities =
        INSTANCE.savePreqinFundMasterData(List.of(fund, fund_updated));
    assertEquals(1, fundMasterEntities.size());
    assertEquals(1L, fundMasterEntities.get(0).getId());
    assertEquals("1234", fundMasterEntities.get(0).getPreqinFundId());
    assertEquals("Wilma Flintstone", fundMasterEntities.get(0).getAuditor());
  }

  @Test
  void saveFundEntitySingle() {
    FundMasterEntity fund =
        FundMasterEntity.builder()
            .name("Fund 1")
            .id(1L)
            .preqinFundId("1234")
            .auditor("Fred Flintstone")
            .build();

    when(fundMasterRepository.findIdByPreqinFundId("1234")).thenReturn(1L);
    when(fundMasterRepository.saveAndFlush(any())).thenReturn(fund);

    FundMasterEntity savedEntity = INSTANCE.savePreqinFundMasterData(fund);
    assertEquals(1L, savedEntity.getId());
    assertEquals("1234", savedEntity.getPreqinFundId());
    assertEquals("Fred Flintstone", savedEntity.getAuditor());
  }

  @Test
  void savePortfolioCompanyData() {
    List<PortfolioCompanyEntity> portfolioCompanyEntities =
        INSTANCE.savePortfolioCompanyData(Set.of(portfolioCompanyEntity));
    assertEquals(portfolioCompanyEntity, portfolioCompanyEntities.get(0));
  }

  @Test
  void saveManagementFeesData() {
    List<ManagementFeesEntity> managementFeesEntities =
        INSTANCE.saveManagementFeesData(Set.of(managementFeesEntity));
    assertEquals(managementFeesEntity, managementFeesEntities.get(0));
  }

  @Test
  void saveFundInternalMappings() {
    List<FundInternalMappingEntity> fundInternalMappingEntities =
        INSTANCE.saveFundInternalMappings(Set.of(fundInternalMappingEntity));
    assertEquals(fundInternalMappingEntity, fundInternalMappingEntities.get(0));
  }

  @Test
  void saveFundMasterOverride() {
    List<FundMasterOverrideEntity> fundMasterOverrideEntities =
        INSTANCE.saveFundMasterOverrides(Set.of(fundMasterOverrideEntity));
    assertEquals(fundMasterOverrideEntity, fundMasterOverrideEntities.get(0));
  }

  @Test
  void applySavedOverride() {
    FundMasterEntity expectedFundMasterEntity =
        OVERRIDE_OBJECT.toBuilder().id(1L).ein("string").build();
    Collection<Fund> fund =
        INSTANCE.getFundInfoFromSecuritiesWithOverrides(Set.of(SECURITY_ID), CLIENT_ID);
    assertEquals(expectedFundMasterEntity, fund.stream().findFirst().get().fundMasterEntity());
  }

  @Test
  void applySavedOverrideWhenNoFundPresent() {
    when(fundMasterRepository.findAllByIdIn(any())).thenReturn(Set.of());
    Collection<Fund> fund =
        INSTANCE.getFundInfoFromSecuritiesWithOverrides(Set.of(SECURITY_ID), CLIENT_ID);
    assertEquals(OVERRIDE_OBJECT, fund.stream().findFirst().get().fundMasterEntity());
  }

  @Test
  void doNotProduceFundWhenNoOverrideOrFundPresent() {
    when(fundMasterRepository.findAllByIdIn(any())).thenReturn(Set.of());
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(any(), any()))
        .thenReturn(List.of());
    Collection<Fund> fund =
        INSTANCE.getFundInfoFromSecuritiesWithOverrides(Set.of(SECURITY_ID), CLIENT_ID);
    assertTrue(CollectionUtils.isEmpty(fund));
  }

  @Test
  void convertFundMasterToOverride() {
    FundMasterOverrideEntity expectedFundMasterOverrideEntity =
        FundMasterOverrideEntity.builder()
            .clientId(CLIENT_ID)
            .securityId(SECURITY_ID)
            .overrideObject(
                FundMasterEntity.builder().id(FUND_ID).ein(EIN).sector1("TESTING").build())
            .build();
    FundMasterOverrideEntity fundMasterOverrideEntity =
        INSTANCE.convertFundMasterToOverride(fundMasterEntity, CLIENT_ID, SECURITY_ID);
    assertEquals(expectedFundMasterOverrideEntity, fundMasterOverrideEntity);
  }

  @Test
  void getFundMasterOverrides() {
    FundMasterOverrideEntity fundMasterOverrideEntity =
        FundMasterOverrideEntity.builder()
            .clientId(CLIENT_ID)
            .securityId(SECURITY_ID)
            .overrideObject(OVERRIDE_OBJECT)
            .build();
    Collection<FundMasterOverrideEntity> fundMasterOverrides =
        INSTANCE.getFundMasterOverrides(CLIENT_ID, Set.of(SECURITY_ID));
    assertEquals(fundMasterOverrideEntity, fundMasterOverrides.stream().findFirst().get());
  }

  @Test
  void getFundIdentifiers() {
    when(fundMasterRepository.findAll()).thenReturn(List.of(fundMasterEntity));
    when(fundInternalMappingRepository.findAll()).thenReturn(List.of(fundInternalMappingEntity));
    when(fundAliasRepository.findAll()).thenReturn(List.of(fundAliasEntity1, fundAliasEntity2));
    Collection<FundIdentifier> actual = INSTANCE.getFundIdentifiers();

    FundIdentifier expected =
        new FundIdentifier(
            FUND_ID,
            fundMasterEntity.getName(),
            Set.of(fundInternalMappingEntity.getId().getSecurityId()),
            Set.of(
                fundAliasEntity1.getFundAliasKey().getAlias(),
                fundAliasEntity2.getFundAliasKey().getAlias()));

    assertEquals(expected, actual.stream().findFirst().get());
  }

  @Test
  void getFundMasterEntityAndOverrideBothPopulated() {
    when(fundInternalMappingRepository.findAllByIdSecurityIdIn(any()))
        .thenReturn(Set.of(fundInternalMappingEntity));
    when(fundMasterRepository.findAllById(any())).thenReturn(List.of(fundMasterEntity));
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(any(), any()))
        .thenReturn(List.of(fundMasterOverrideEntity));
    Map<String, FundMasterEntity> actual =
        INSTANCE.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID);
    assertEquals(fundMasterEntity, actual.get("fundMasterEntity"));
    assertEquals(fundMasterOverrideEntity.getOverrideObject(), actual.get("overrideEntity"));
  }

  @Test
  void getFundMasterEntityAndOverrideMissingEntity() {
    when(fundInternalMappingRepository.findAllByIdSecurityIdIn(any())).thenReturn(List.of());
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(any(), any()))
        .thenReturn(List.of(fundMasterOverrideEntity));
    Map<String, FundMasterEntity> actual =
        INSTANCE.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID);
    assertNull(actual.get("fundMasterEntity"));
    assertEquals(fundMasterOverrideEntity.getOverrideObject(), actual.get("overrideEntity"));
  }

  @Test
  void getFundMasterEntityAndOverrideMissingOverrideEntity() {
    when(fundInternalMappingRepository.findAllByIdSecurityIdIn(any()))
        .thenReturn(Set.of(fundInternalMappingEntity));
    when(fundMasterRepository.findAllById(any())).thenReturn(List.of(fundMasterEntity));
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(any(), any()))
        .thenReturn(List.of());
    Map<String, FundMasterEntity> actual =
        INSTANCE.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID);
    assertEquals(fundMasterEntity, actual.get("fundMasterEntity"));
    assertNull(actual.get("overrideEntity"));
  }

  @Test
  void getFundMasterEntityAndOverrideMissingBoth() {
    when(fundInternalMappingRepository.findAllByIdSecurityIdIn(any())).thenReturn(List.of());
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(any(), any()))
        .thenReturn(List.of());
    Map<String, FundMasterEntity> actual =
        INSTANCE.getFundMasterEntityAndOverride(SECURITY_ID, CLIENT_ID);
    assertNull(actual.get("fundMasterEntity"));
    assertNull(actual.get("overrideEntity"));
  }

  @Test
  void identifyClientWithFundMasterOverride() {
    SortedMap<Integer, Long> clientHierarchy =
        new TreeMap<>(Map.of(1, 1234L, 2, 1452L, 3, 19375L, 4, 3349L, 5, 13350L, 6, 20561L));
    FundMasterOverrideKey fundMasterOverrideKeyButDifferent =
        FundMasterOverrideKey.builder().securityId(42342342L).clientId(3349L).build();
    when(fundMasterOverrideRepository.findKeysByClientIdAndSecurityIdIn(
            19375L, Set.of(SECURITY_ID, 42342342L, 2802L)))
        .thenReturn(Map.of(CLIENT_ID, SECURITY_ID));
    when(fundMasterOverrideRepository.findKeysByClientIdAndSecurityIdIn(
            3349L, Set.of(42342342L, 2802L)))
        .thenReturn(Map.of(3349L, 42342342L));
    Map<Long, Set<Long>> actual =
        INSTANCE.identifyClientWithOverride(Set.of(SECURITY_ID, 42342342L, 2802L), clientHierarchy);
    assertEquals(Set.of(SECURITY_ID), actual.get(19375L));
    assertEquals(Set.of(42342342L), actual.get(3349L));
    assertEquals(Set.of(2802L), actual.get(1234L));
    assertEquals(3, actual.size());
  }

  @Test
  void getFundIdsForSecurities() {
    Map<Long, Set<Long>> result = INSTANCE.getFundIdsForSecurities(Set.of(SECURITY_ID));
    assertNotNull(result);
    assertTrue(result.containsKey(1L));
    assertEquals(Set.of(SECURITY_ID), result.get(1L));
  }

  @Test
  void getFundMasterEntitiesWithOverrides() {
    when(fundMasterOverrideRepository.findAllByClientIdAndSecurityIdIn(
            CLIENT_ID, List.of(SECURITY_ID)))
        .thenReturn(List.of(fundMasterOverrideEntity));
    Map<Long, FundMasterEntity> result =
        INSTANCE.getFundMasterEntitiesWithOverrides(List.of(SECURITY_ID), CLIENT_ID);
    assertNotNull(result);
    assertTrue(result.containsKey(SECURITY_ID));
    assertEquals(fundMasterEntity.applyOverride(OVERRIDE_OBJECT), result.get(SECURITY_ID));
  }

  @Test
  void getFundMasterEntitiesWithOverridesJustOriginal() {
    Map<Long, FundMasterEntity> result =
        INSTANCE.getFundMasterEntitiesWithOverrides(List.of(SECURITY_ID), CLIENT_ID);
    assertNotNull(result);
    assertTrue(result.containsKey(SECURITY_ID));
    assertEquals(fundMasterEntity, result.get(SECURITY_ID));
  }

  @Test
  void getFundMasterEntitiesWithOverridesJustOverride() {
    when(fundMasterRepository.findAllByIdIn(any())).thenReturn(List.of());
    Map<Long, FundMasterEntity> result =
        INSTANCE.getFundMasterEntitiesWithOverrides(Set.of(SECURITY_ID), CLIENT_ID);
    assertNotNull(result);
    assertTrue(result.containsKey(SECURITY_ID));
    assertEquals(OVERRIDE_OBJECT, result.get(SECURITY_ID));
  }

  @Test
  void getFundInternalMappingsForFunds_ShouldReturnFundInternalMappings() {
    // Arrange
    Collection<Long> fundSecurityIds = List.of(1L, 2L, 3L);
    FundInternalMappingEntity mappingEntity1 =
        new FundInternalMappingEntity(); // Setup your entity as needed
    FundInternalMappingEntity mappingEntity2 =
        new FundInternalMappingEntity(); // Setup your entity as needed

    // Stub the repository method
    when(fundInternalMappingRepository.findAllByIdFundIdIn(fundSecurityIds))
        .thenReturn(List.of(mappingEntity1, mappingEntity2));

    // Act
    Collection<FundInternalMappingEntity> result =
        INSTANCE.getFundInternalMappingsForFunds(fundSecurityIds);

    // Assert
    assertEquals(2, result.size());
    assertEquals(List.of(mappingEntity1, mappingEntity2), result);
    verify(fundInternalMappingRepository).findAllByIdFundIdIn(fundSecurityIds);
  }

  @Test
  void getFundInternalMappingsForSecurityIds_ShouldReturnFundInternalMappings() {
    // Arrange
    Collection<Long> securityIds = List.of(1L, 2L, 3L);
    FundInternalMappingEntity mappingEntity1 =
        new FundInternalMappingEntity(); // Setup your entity as needed
    FundInternalMappingEntity mappingEntity2 =
        new FundInternalMappingEntity(); // Setup your entity as needed

    // Stub the repository method
    when(fundInternalMappingRepository.findAllByIdSecurityIdIn(securityIds))
        .thenReturn(List.of(mappingEntity1, mappingEntity2));

    // Act
    Collection<FundInternalMappingEntity> result =
        INSTANCE.getFundInternalMappingsForSecurityIds(securityIds);

    // Assert
    assertEquals(2, result.size());
    assertEquals(List.of(mappingEntity1, mappingEntity2), result);
    verify(fundInternalMappingRepository).findAllByIdSecurityIdIn(securityIds);
  }
}
