package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class FundAliasKeyTest {

  @Test
  void testHashCode() {
    FundAliasKey FundAliasKey1 = new FundAliasKey(1L, "hello");
    FundAliasKey FundAliasKey2 = new FundAliasKey(1L, "hello");
    FundAliasKey FundAliasKey3 = new FundAliasKey(1L, "goodbye");

    Set<FundAliasKey> keys = new HashSet<>(List.of(FundAliasKey1, FundAliasKey2, FundAliasKey3));
    assertEquals(2, keys.size());
  }

  @Test
  void testEquals() {
    FundAliasKey FundAliasKey1 = new FundAliasKey(1L, "hello");
    FundAliasKey FundAliasKey2 = new FundAliasKey(1L, "hello");
    FundAliasKey FundAliasKey3 = new FundAliasKey(1L, "goodbye");

    assertEquals(FundAliasKey1, FundAliasKey2);
    assertNotEquals(FundAliasKey3, FundAliasKey2);
  }
}
