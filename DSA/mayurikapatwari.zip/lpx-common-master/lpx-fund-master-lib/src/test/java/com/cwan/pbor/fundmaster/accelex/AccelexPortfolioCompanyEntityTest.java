package com.cwan.pbor.fundmaster.accelex;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class AccelexPortfolioCompanyEntityTest {

  @Test
  void testHashCode() {
    AccelexPortfolioCompanyKey AccelexPortfolioCompanyKey1 =
        AccelexPortfolioCompanyKey.builder().securityId(1l).build();
    AccelexPortfolioCompanyKey AccelexPortfolioCompanyKey2 =
        AccelexPortfolioCompanyKey.builder().securityId(1l).build();
    AccelexPortfolioCompanyKey AccelexPortfolioCompanyKey3 =
        AccelexPortfolioCompanyKey.builder().securityId(1l).build();

    AccelexPortfolioCompanyEntity accelexInvestments1 =
        AccelexPortfolioCompanyEntity.builder()
            .accelexPortfolioCompanyKey(AccelexPortfolioCompanyKey1)
            .geographicRegion("test1")
            .build();
    AccelexPortfolioCompanyEntity accelexInvestments2 =
        AccelexPortfolioCompanyEntity.builder()
            .accelexPortfolioCompanyKey(AccelexPortfolioCompanyKey2)
            .geographicRegion("test2")
            .build();
    AccelexPortfolioCompanyEntity accelexInvestments3 =
        AccelexPortfolioCompanyEntity.builder()
            .accelexPortfolioCompanyKey(AccelexPortfolioCompanyKey3)
            .geographicRegion("test1")
            .build();

    assertEquals(AccelexPortfolioCompanyKey1.hashCode(), AccelexPortfolioCompanyKey2.hashCode());
    assertEquals(accelexInvestments1.hashCode(), accelexInvestments3.hashCode());
    assertNotEquals(accelexInvestments3.hashCode(), accelexInvestments2.hashCode());
  }

  @Test
  void testEquals() {
    AccelexPortfolioCompanyKey accelexPortfolioCompanyKey1 =
        AccelexPortfolioCompanyKey.builder().securityId(1l).build();
    AccelexPortfolioCompanyKey accelexPortfolioCompanyKey2 =
        AccelexPortfolioCompanyKey.builder().securityId(1l).build();
    AccelexPortfolioCompanyKey accelexPortfolioCompanyKey3 =
        AccelexPortfolioCompanyKey.builder().securityId(1l).build();

    AccelexPortfolioCompanyEntity accelexInvestments1 =
        AccelexPortfolioCompanyEntity.builder()
            .accelexPortfolioCompanyKey(accelexPortfolioCompanyKey1)
            .geographicRegion("test1")
            .build();
    AccelexPortfolioCompanyEntity accelexInvestments2 =
        AccelexPortfolioCompanyEntity.builder()
            .accelexPortfolioCompanyKey(accelexPortfolioCompanyKey2)
            .geographicRegion("test2")
            .build();
    AccelexPortfolioCompanyEntity accelexInvestments3 =
        AccelexPortfolioCompanyEntity.builder()
            .accelexPortfolioCompanyKey(accelexPortfolioCompanyKey3)
            .geographicRegion("test1")
            .build();

    assertEquals(accelexPortfolioCompanyKey1, accelexPortfolioCompanyKey2);
    assertEquals(accelexInvestments1, accelexInvestments3);
    assertNotEquals(accelexInvestments3, accelexInvestments2);
  }
}
