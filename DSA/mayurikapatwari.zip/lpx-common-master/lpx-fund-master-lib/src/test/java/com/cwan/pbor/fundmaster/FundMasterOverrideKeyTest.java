package com.cwan.pbor.fundmaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class FundMasterOverrideKeyTest {

  @Test
  void testEquals_sameObject() {
    FundMasterOverrideKey key = new FundMasterOverrideKey(1L, 2L);
    assertEquals(key, key);
  }

  @Test
  void testEquals_nullObject() {
    FundMasterOverrideKey key = new FundMasterOverrideKey(1L, 2L);
    assertNotEquals(null, key);
  }

  @Test
  void testEquals_differentClass() {
    FundMasterOverrideKey key = new FundMasterOverrideKey(1L, 2L);
    assertNotEquals(key, new Object());
  }

  @Test
  void testEquals_equalObject() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(1L, 2L);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(1L, 2L);
    assertEquals(key1, key2);
  }

  @Test
  void testEquals_differentSecurityId() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(1L, 2L);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(3L, 2L);
    assertNotEquals(key1, key2);
  }

  @Test
  void testEquals_differentClientId() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(1L, 2L);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(1L, 3L);
    assertNotEquals(key1, key2);
  }

  @Test
  void testEquals_nullSecurityId() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(null, 2L);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(1L, 2L);
    assertNotEquals(key1, key2);
  }

  @Test
  void testEquals_nullClientId() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(1L, null);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(1L, 2L);
    assertNotEquals(key1, key2);
  }

  @Test
  void testHashCode_equalObjects() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(1L, 2L);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(1L, 2L);
    assertEquals(key1.hashCode(), key2.hashCode());
  }

  @Test
  void testHashCode_differentObjects() {
    FundMasterOverrideKey key1 = new FundMasterOverrideKey(1L, 2L);
    FundMasterOverrideKey key2 = new FundMasterOverrideKey(3L, 4L);
    assertNotEquals(key1.hashCode(), key2.hashCode());
  }
}
