create schema if not exists pabor;

create table if not exists pabor.document
(
  id                           bigint       not null auto_increment primary key,
  cloud_storage_id             bigint       null,
  canoe_id                     varchar(256) null,
  file_name                    varchar(256) null,
  original_file_name           varchar(256) null,
  account_id                   bigint       null,
  security_id                  bigint       null,
  type                         varchar(50)  null,
  is_audited                   bit          null,
  source                       varchar(30)  null,
  data_source                  varchar(30)  null,
  received_date                date         null,
  doc_date                     date         null,
  cash_mvmt_date               date         null,
  frequency                    varchar(30)  null,
  period_start_date            date         null,
  period_end_date              date         null,
  checked                      bit          null,
  error_status                 varchar(10)  null,
  created_by                   varchar(256) null,
  is_created_by_internal_user  bit          null,
  created_on                   timestamp    null,
  modified_by                  varchar(256) null,
  is_modified_by_internal_user bit          null,
  modified_on                  timestamp    null
);

create table if not exists pabor.capital_call
(
  id          bigint auto_increment primary key,
  document_id bigint                                                  not null,
  status      varchar(50)                                             not null,
  comment     varchar(200)                                            not null,
  timestamp   datetime     default current_timestamp                  not null,
  user_id     bigint       default -1                                 not null,
  user_name   varchar(100) default 'SYSTEM'                           not null,
  user_email  varchar(100) default 'no-reply@clearwateranalytics.com' not null,
  constraint fk_capital_call_document_id foreign key (document_id) references pabor.document (id)
);
