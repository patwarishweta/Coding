import com.cwan.pbor.document.DocumentService;
import com.cwan.pbor.document.api.Documents;

module pbor.document.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;
  requires java.sql;
  requires org.apache.commons.lang3;
  requires com.fasterxml.jackson.core;
  requires com.fasterxml.jackson.databind;
  requires ch.qos.logback.core;
  requires ch.qos.logback.classic;
  requires com.fasterxml.jackson.datatype.jsr310;

  exports com.cwan.pbor.document.api;
  exports com.cwan.pbor.document.duplicate.api;
  exports com.cwan.pbor.document.capital.call.api;
  exports com.cwan.pbor.document.capital.call.management.api;

  provides Documents with
      DocumentService;
}
