package com.cwan.pbor.document.missing.document.api.impl;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.missing.document.api.MissingDocumentsService;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentsEntity;
import com.cwan.pbor.document.missing.document.repository.MissingDocumentsRepository;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentsEntityTransformer;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentsTransformer;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class MissingDocumentsServiceImpl implements MissingDocumentsService {

  private MissingDocumentsRepository missingDocumentsRepository;
  private MissingDocumentsTransformer missingDocumentsTransformer;
  private MissingDocumentsEntityTransformer missingDocumentsEntityTransformer;

  @Override
  public List<MissingDocuments> getAllMissingDocumentsUsingAccountIdInAndSecurityIdIn(
      List<Long> accountIds, List<Long> securityIds) {
    return missingDocumentsRepository
        .findAllByAccountIdInAndSecurityIdIn(accountIds, securityIds)
        .stream()
        .map(missingDocumentsTransformer)
        .toList();
  }

  @Override
  public List<MissingDocuments> getAllMissingDocumentsUsingAccountIdIn(List<Long> accountIds) {
    return missingDocumentsRepository.findAllByAccountIdIn(accountIds).stream()
        .map(missingDocumentsTransformer)
        .toList();
  }

  @Override
  public List<MissingDocuments> getAllMissingDocumentsByCategory(
      MissingDocumentStatus documentMissingCategory) {
    return missingDocumentsRepository
        .retrieveAllMissingDocumentsByCategory(documentMissingCategory)
        .stream()
        .map(missingDocumentsTransformer)
        .toList();
  }

  @Override
  public List<MissingDocuments> addMissingDocuments(Set<MissingDocuments> missingDocuments) {
    missingDocuments.stream()
        .filter(doc -> doc.getId() != null)
        .forEach(
            doc ->
                log.warn(
                    "missing document with Id {} can't be added Id should be null.", doc.getId()));
    return missingDocuments.stream()
        .filter(doc -> doc.getId() == null)
        .filter(Objects::nonNull)
        .map(missingDocumentsEntityTransformer)
        .map(this::saveMissingDocuments)
        .map(missingDocumentsTransformer)
        .toList();
  }

  private MissingDocumentsEntity saveMissingDocuments(
      MissingDocumentsEntity missingDocumentsEntity) {
    return missingDocumentsRepository.saveAndFlush(missingDocumentsEntity);
  }
}
