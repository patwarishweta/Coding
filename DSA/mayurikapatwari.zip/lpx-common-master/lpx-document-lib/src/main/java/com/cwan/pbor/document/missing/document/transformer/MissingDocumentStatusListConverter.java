package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.pbor.document.missing.document.MissingDocumentException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Converter
@Component
@AllArgsConstructor
public class MissingDocumentStatusListConverter
    implements AttributeConverter<List<MissingDocumentStatus>, String> {
  private ObjectMapper objectMapper;

  @Override
  public String convertToDatabaseColumn(List<MissingDocumentStatus> attribute) {
    try {
      return objectMapper.writeValueAsString(attribute);
    } catch (Exception e) {
      throw new MissingDocumentException(
          HttpStatus.BAD_REQUEST,
          "Error converting List<MissingDocumentStatus> to JSON string: " + e.getMessage());
    }
  }

  @Override
  public List<MissingDocumentStatus> convertToEntityAttribute(String dbData) {
    try {
      return objectMapper.readValue(dbData, new TypeReference<List<MissingDocumentStatus>>() {});
    } catch (Exception e) {
      throw new MissingDocumentException(
          HttpStatus.INTERNAL_SERVER_ERROR,
          "Error converting JSON string to List<MissingDocumentStatus>: " + e.getMessage());
    }
  }
}
