package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentAlertConfigEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class MissingDocumentAlertConfigEntityTransformer
    implements Function<MissingDocumentAlertConfig, MissingDocumentAlertConfigEntity> {

  @Override
  public MissingDocumentAlertConfigEntity apply(
      MissingDocumentAlertConfig missingDocumentAlertConfig) {
    return MissingDocumentAlertConfigEntity.builder()
        .id(missingDocumentAlertConfig.getId())
        .clientId(missingDocumentAlertConfig.getClientId())
        .accountIds(missingDocumentAlertConfig.getAccountIds())
        .securityIds(missingDocumentAlertConfig.getSecurityIds())
        .documentMissingCategories(missingDocumentAlertConfig.getDocumentMissingCategories())
        .documentTypes(missingDocumentAlertConfig.getDocumentTypes())
        .startDate(missingDocumentAlertConfig.getStartDate())
        .expiry(missingDocumentAlertConfig.getExpiry())
        .username(missingDocumentAlertConfig.getUsername())
        .isActive(missingDocumentAlertConfig.getIsActive())
        .build();
  }
}
