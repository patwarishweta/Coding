package com.cwan.pbor.document.missing.document.entity;

public interface MissingDocumentExpectationGroupedConfig {

  Long getFundId();

  String getFundName();

  String getDocumentType();

  String getFrequency();

  Integer getThreshold();

  Boolean getIsActive();
}
