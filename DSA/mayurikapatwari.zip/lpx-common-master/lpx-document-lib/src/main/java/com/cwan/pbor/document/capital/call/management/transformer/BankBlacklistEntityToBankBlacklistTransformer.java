package com.cwan.pbor.document.capital.call.management.transformer;

import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.pbor.document.capital.call.management.entity.BankBlacklistEntity;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankBlacklistEntityToBankBlacklistTransformer
    implements Function<BankBlacklistEntity, BankBlacklist> {

  private final BankEntityToBankTransformer bankEntityToBankTransformer;

  public BankBlacklistEntityToBankBlacklistTransformer(
      BankEntityToBankTransformer bankEntityToBankTransformer) {
    this.bankEntityToBankTransformer = bankEntityToBankTransformer;
  }

  @Override
  public BankBlacklist apply(BankBlacklistEntity bankBlacklistEntity) {
    return Optional.ofNullable(bankBlacklistEntity)
        .map(
            entity ->
                BankBlacklist.builder()
                    .bankBlacklistUuid(entity.getBankBlacklistUuid())
                    .bank(bankEntityToBankTransformer.apply(entity.getBank()))
                    .createdAt(entity.getCreatedAt())
                    .createdBy(entity.getCreatedBy())
                    .build())
        .orElse(null);
  }
}
