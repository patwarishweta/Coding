package com.cwan.pbor.document.duplicate.api;

import com.cwan.lpx.domain.DocumentDuplicateGroupKey;
import com.cwan.lpx.domain.DuplicateCanoe;
import java.util.Collection;
import java.util.Map;
import java.util.SortedSet;
import org.springframework.transaction.annotation.Transactional;

public interface DocumentDuplicates {

  /**
   * Retrieves grouped document duplicates for the provided documentIds. Steps: 1. Find non-disabled
   * DocumentDuplicate rows for the given documentIds. 2. Find their corresponding (non-disabled)
   * Documents. 3. Find all DocumentDuplicateExt rows (non-disabled) for those duplicates. 4.
   * Identify the single "current" row vs. the "non-current" rows. 5. Build the result map grouped
   * by DocumentDuplicateGroupKey, with non-current duplicates as a SortedSet of DuplicateCanoe.
   *
   * @param documentIds The collection of document IDs to process.
   * @return A map keyed by DocumentDuplicateGroupKey, with a SortedSet of DuplicateCanoe as values.
   */
  @Transactional
  Map<DocumentDuplicateGroupKey, SortedSet<DuplicateCanoe>> getGroupedDocumentDuplicates(
      Collection<Long> documentIds);
}
