package com.cwan.pbor.document.capital.call.management.transformer;

import com.cwan.lpx.domain.BankAccount;
import com.cwan.pbor.document.capital.call.management.entity.BankAccountEntity;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import com.cwan.pbor.document.capital.call.management.repository.BankRepository;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankAccountToBankAccountEntityTransformer
    implements Function<BankAccount, BankAccountEntity> {

  private final BankRepository bankRepository;

  public BankAccountToBankAccountEntityTransformer(BankRepository bankRepository) {
    this.bankRepository = bankRepository;
  }

  @Override
  public BankAccountEntity apply(BankAccount bankAccount) {
    return Optional.ofNullable(bankAccount)
        .map(
            ba -> {
              var bankId =
                  bankRepository
                      .findByBankUuid(ba.bank().bankUuid())
                      .map(BankEntity::getBankId)
                      .orElseThrow(
                          () ->
                              new NoSuchElementException(
                                  "No bank found with UUID: " + ba.bank().bankUuid()));
              return BankAccountEntity.builder()
                  .bankId(bankId)
                  .accountId(ba.accountId())
                  .accountName(ba.accountName())
                  .accountNumber(ba.accountNumber())
                  .iban(ba.iban())
                  .createdBy(ba.createdBy())
                  .build();
            })
        .orElse(null);
  }
}
