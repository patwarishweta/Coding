package com.cwan.pbor.document.missing.document;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class MissingDocumentException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = -5056246273159120534L;

  public MissingDocumentException(HttpStatus status, String msg, Throwable e) {
    super(status, msg, e);
  }

  public MissingDocumentException(HttpStatus status, String msg) {
    super(status, msg);
  }
}
