package com.cwan.pbor.document.capital.call.management.transformer;

import com.cwan.lpx.domain.Bank;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankToBankEntityTransformer implements Function<Bank, BankEntity> {

  @Override
  public BankEntity apply(Bank bank) {
    return Optional.ofNullable(bank)
        .map(
            b ->
                BankEntity.builder()
                    .clientId(b.clientId())
                    .bankName(b.bankName())
                    .abaRoutingNumber(b.abaRoutingNumber())
                    .swiftChipsCode(b.swiftChipsCode())
                    .createdBy(b.createdBy())
                    .build())
        .orElse(null);
  }
}
