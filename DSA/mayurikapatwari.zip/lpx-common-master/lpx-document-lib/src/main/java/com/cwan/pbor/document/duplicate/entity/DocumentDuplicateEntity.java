package com.cwan.pbor.document.duplicate.entity;

import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.duplicate.constant.DuplicateStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@DynamicInsert
@DynamicUpdate
@Table(
    name = "document_duplicate",
    catalog = "pabor",
    uniqueConstraints = {
      @UniqueConstraint(
          name = "uk_document_duplicate_document_id",
          columnNames = {"document_id"})
    })
@SQLDelete(sql = "UPDATE pabor.document_duplicate SET is_disabled = true WHERE id = ?")
@SQLRestriction("is_disabled = false")
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(builderClassName = "DocumentDuplicateEntityBuilder", toBuilder = true)
public class DocumentDuplicateEntity {

  @SuppressWarnings("unused")
  public static class DocumentDuplicateEntityBuilder {

    public DocumentDuplicateEntityBuilder assigneeEmail(String assigneeEmail) {
      this.assigneeEmail = StringUtils.trimToNull(assigneeEmail);
      return this;
    }

    public DocumentDuplicateEntityBuilder assigneeFullName(String assigneeFullName) {
      this.assigneeFullName = StringUtils.trimToNull(assigneeFullName);
      return this;
    }

    public DocumentDuplicateEntityBuilder clientName(String clientName) {
      this.clientName = StringUtils.trimToNull(clientName);
      return this;
    }

    public DocumentDuplicateEntityBuilder comment(String comment) {
      this.comment = StringUtils.trimToNull(comment);
      return this;
    }

    public DocumentDuplicateEntityBuilder entity(String entity) {
      this.entity = StringUtils.trimToNull(entity);
      return this;
    }

    public DocumentDuplicateEntityBuilder investment(String investment) {
      this.investment = StringUtils.trimToNull(investment);
      return this;
    }

    public DocumentDuplicateEntityBuilder modifierEmail(String modifierEmail) {
      this.modifierEmail = StringUtils.trimToNull(modifierEmail);
      return this;
    }

    public DocumentDuplicateEntityBuilder modifierFullName(String modifierFullName) {
      this.modifierFullName = StringUtils.trimToNull(modifierFullName);
      return this;
    }

    public DocumentDuplicateEntityBuilder note(String note) {
      this.note = StringUtils.trimToNull(note);
      return this;
    }

    public DocumentDuplicateEntityBuilder ultimateParentName(String ultimateParentName) {
      this.ultimateParentName = StringUtils.trimToNull(ultimateParentName);
      return this;
    }
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "document_id", nullable = false, unique = true)
  private Long documentId;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(
      name = "document_id",
      referencedColumnName = "id",
      insertable = false,
      updatable = false)
  private DocumentEntity document;

  @Column(name = "entity", length = 510)
  private String entity;

  @Column(name = "investment", length = 510)
  private String investment;

  @Column(name = "client_id", nullable = false)
  private Long clientId;

  @Column(name = "client_name", length = 510)
  private String clientName;

  @Column(name = "ultimate_parent_id", nullable = false)
  private Long ultimateParentId;

  @Column(name = "ultimate_parent_name", length = 510)
  private String ultimateParentName;

  @Column(name = "is_disabled", nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
  @Builder.Default
  private boolean isDisabled = false;

  @Column(name = "assignee_id")
  private Long assigneeId;

  @Column(name = "assignee_full_name", length = 510)
  private String assigneeFullName;

  @Column(name = "assignee_email", length = 510)
  private String assigneeEmail;

  @Column(name = "modifier_id")
  private Long modifierId;

  @Column(name = "modifier_full_name", length = 510)
  private String modifierFullName;

  @Column(name = "modifier_email", length = 510)
  private String modifierEmail;

  @Enumerated(EnumType.STRING)
  @Column(name = "duplicate_status", length = 170, nullable = false)
  private DuplicateStatus duplicateStatus;

  @Column(name = "comment", length = 510)
  private String comment;

  @Column(name = "note", length = 510)
  private String note;

  @Column(name = "ts_created", nullable = false, updatable = false)
  private LocalDateTime tsCreated;

  @UpdateTimestamp
  @Column(name = "ts_modified", nullable = false)
  private LocalDateTime tsModified;
}
