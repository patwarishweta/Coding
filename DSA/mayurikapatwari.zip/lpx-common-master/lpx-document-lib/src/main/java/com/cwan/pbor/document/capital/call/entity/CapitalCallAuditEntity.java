package com.cwan.pbor.document.capital.call.entity;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.Setter;
import lombok.ToString;

@Entity
@Data
@ToString
@Table(name = "capital_call", catalog = "pabor")
public class CapitalCallAuditEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Setter(lombok.AccessLevel.NONE)
  private Long id;

  @Column(name = "document_id")
  private Long documentId;

  @Enumerated(EnumType.STRING)
  @Column(name = "action")
  private CapitalCallAction action;

  @Enumerated(EnumType.STRING)
  @Column(name = "status")
  private CapitalCallStatus status;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "timestamp", updatable = false, insertable = false)
  private LocalDateTime timestamp;

  @Column(name = "comment")
  private String comment;

  @Column(name = "user_id")
  private Integer userId;

  @Column(name = "user_full_name")
  private String userFullName;

  @Column(name = "user_email")
  private String userEmail;

  @Builder
  public static CapitalCallAuditEntity create(
      Long documentId,
      CapitalCallAction action,
      CapitalCallStatus status,
      String comment,
      Integer userId,
      String userFullName,
      String userEmail) {
    var capitalCallAuditEntity = new CapitalCallAuditEntity();
    capitalCallAuditEntity.documentId = documentId;
    capitalCallAuditEntity.action = action;
    capitalCallAuditEntity.status = status;
    capitalCallAuditEntity.comment = comment;
    capitalCallAuditEntity.userId = userId;
    capitalCallAuditEntity.userFullName = userFullName;
    capitalCallAuditEntity.userEmail = userEmail;
    return capitalCallAuditEntity;
  }

  public CapitalCallAuditEntity() {
    // Manually create a no-args constructor as JPA requires it
  }
}
