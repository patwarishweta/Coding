package com.cwan.pbor.document.capital.call.management.api;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.BankBlacklist;
import java.util.List;
import java.util.Optional;

public interface CapitalCallManagement {

  // ----------------- BANK ------------------
  Bank createBank(Bank bank);

  List<Bank> fetchBanksByClient(Long clientId);

  Optional<Bank> fetchBank(String bankUuid);

  boolean deleteBank(String bankUuid, Long deletedBy);

  // ----------------- BANK ACCOUNT ------------------
  List<BankAccount> findAllBankAccounts();

  BankAccount createBankAccount(BankAccount bankAccount);

  List<BankAccount> fetchBankAccountsByAccount(Long accountId);

  List<BankAccount> fetchBankAccountsByClient(Long clientId);

  Optional<BankAccount> fetchBankAccount(String bankAccountUuid);

  boolean deleteBankAccount(String bankAccountUuid, Long deletedBy);

  // ----------------- BANK BLACKLIST ------------------
  BankBlacklist createBankBlacklist(BankBlacklist bankBlacklist);

  List<BankBlacklist> fetchBankBlacklistsByClient(Long clientId);

  Optional<BankBlacklist> fetchBankBlacklist(String bankBlacklistUuid);

  boolean deleteBankBlacklist(String bankBlacklistUuid, Long deletedBy);
}
