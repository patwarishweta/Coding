package com.cwan.pbor.document.duplicate.entity;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Composite primary key for the document_duplicate_view: (document_id, duplicate_canoe_id). */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DocumentDuplicateViewEntityPK implements Serializable {

  @Serial private static final long serialVersionUID = -2946906513928709455L;
  private Long documentId;
  private String duplicateCanoeId;
}
