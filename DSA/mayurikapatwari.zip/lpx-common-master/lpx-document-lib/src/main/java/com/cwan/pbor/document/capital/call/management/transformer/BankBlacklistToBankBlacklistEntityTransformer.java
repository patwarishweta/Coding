package com.cwan.pbor.document.capital.call.management.transformer;

import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.pbor.document.capital.call.management.entity.BankBlacklistEntity;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import com.cwan.pbor.document.capital.call.management.repository.BankRepository;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankBlacklistToBankBlacklistEntityTransformer
    implements Function<BankBlacklist, BankBlacklistEntity> {

  private final BankRepository bankRepository;

  public BankBlacklistToBankBlacklistEntityTransformer(BankRepository bankRepository) {
    this.bankRepository = bankRepository;
  }

  @Override
  public BankBlacklistEntity apply(BankBlacklist bankBlacklist) {
    return Optional.ofNullable(bankBlacklist)
        .map(
            bb -> {
              var bankId =
                  bankRepository
                      .findByBankUuid(bb.bank().bankUuid())
                      .map(BankEntity::getBankId)
                      .orElseThrow(
                          () ->
                              new NoSuchElementException(
                                  "No bank found with UUID: " + bb.bank().bankUuid()));
              return BankBlacklistEntity.builder().bankId(bankId).createdBy(bb.createdBy()).build();
            })
        .orElse(null);
  }
}
