package com.cwan.pbor.document.missing.document.repository;

import com.cwan.pbor.document.missing.document.entity.MissingDocumentAlertConfigEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MissingDocumentAlertConfigRepository
    extends JpaRepository<MissingDocumentAlertConfigEntity, Long> {
  List<MissingDocumentAlertConfigEntity> findAllByClientIdIn(List<Long> clientIds);
}
