package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationsConfigEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class MissingDocumentExpectationsConfigEntityTransformer
    implements Function<
        MissingDocumentExpectationsConfig, MissingDocumentExpectationsConfigEntity> {

  @Override
  public MissingDocumentExpectationsConfigEntity apply(
      MissingDocumentExpectationsConfig missingDocumentExpectationsConfig) {
    return MissingDocumentExpectationsConfigEntity.builder()
        .id(missingDocumentExpectationsConfig.getId())
        .securityId(missingDocumentExpectationsConfig.getSecurityId())
        .fundId(missingDocumentExpectationsConfig.getFundId())
        .fundName(missingDocumentExpectationsConfig.getFundName())
        .documentType(missingDocumentExpectationsConfig.getDocumentType())
        .frequency(missingDocumentExpectationsConfig.getFrequency())
        .threshold(missingDocumentExpectationsConfig.getThreshold())
        .isActive(missingDocumentExpectationsConfig.getIsActive())
        .build();
  }
}
