package com.cwan.pbor.document.suspense.queue.api.impl;

import com.cwan.lpx.domain.SuspenseQueue;
import com.cwan.pbor.document.suspense.queue.SuspenseQueueEntity;
import com.cwan.pbor.document.suspense.queue.SuspenseQueueRepository;
import com.cwan.pbor.document.suspense.queue.api.SuspenseQueueService;
import com.cwan.pbor.document.suspense.queue.transformer.SuspenseQueueEntityTransformer;
import com.cwan.pbor.document.suspense.queue.transformer.SuspenseQueueTransformer;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class SuspenseQueueServiceImpl implements SuspenseQueueService {

  private SuspenseQueueRepository suspenseQueueRepository;
  private SuspenseQueueEntityTransformer suspenseQueueEntityTransformer;
  private SuspenseQueueTransformer suspenseQueueTransformer;

  @Override
  public List<SuspenseQueue> getAllSuspenseQueueDocumentCreatedOnInBetweenAndDocumentTypesIn(
      LocalDateTime beginDate, LocalDateTime endDate, List<String> documentTypes) {
    return suspenseQueueRepository
        .findByCreatedOnBetweenAndDocumentTypeInOrDocumentTypeIsNull(
            beginDate, endDate, documentTypes)
        .stream()
        .filter(Objects::nonNull)
        .map(suspenseQueueEntityTransformer)
        .toList();
  }

  @Override
  public List<SuspenseQueue> getAllSuspenseQueueDocumentCreatedOnInBetweenAndDocumentTypesNotIn(
      LocalDateTime beginDate, LocalDateTime endDate, List<String> documentTypes) {
    return suspenseQueueRepository
        .findByCreatedOnBetweenAndDocumentTypeNotIn(beginDate, endDate, documentTypes)
        .stream()
        .filter(Objects::nonNull)
        .map(suspenseQueueEntityTransformer)
        .toList();
  }

  @Override
  public List<SuspenseQueue> getAllSuspenseQueueDocumentsByCreatedOnInBetweenAndUltimateParentIdsIn(
      LocalDateTime beginDate, LocalDateTime endDate, List<Long> ultimateParentIds) {
    return suspenseQueueRepository
        .findAllByCreatedOnBetweenAndUltimateParentIdsIn(beginDate, endDate, ultimateParentIds)
        .stream()
        .filter(Objects::nonNull)
        .map(suspenseQueueEntityTransformer)
        .toList();
  }

  @Override
  public SuspenseQueue getSuspenseQueueDocumentByIdAndIsCurrent(Long id, Boolean isCurrent) {
    Optional<SuspenseQueueEntity> documentEntity =
        Optional.ofNullable(suspenseQueueRepository.findByDocumentIdAndIsCurrent(id, isCurrent));
    if (documentEntity.isPresent()) {
      SuspenseQueueEntity entity = documentEntity.get();
      return suspenseQueueEntityTransformer.apply(entity);
    } else {
      log.info("No entries find in db for document id: {}", id);
      return null;
    }
  }

  @Override
  public List<SuspenseQueue> getAllSuspenseQueueDocumentByIdsAndIsCurrent(Set<Long> ids) {
    Optional<List<SuspenseQueueEntity>> documentEntities =
        Optional.ofNullable(suspenseQueueRepository.findAllByDocumentIdInAndIsCurrent(ids));
    if (documentEntities.isPresent()) {
      return documentEntities.get().stream()
          .map(suspenseQueueEntityTransformer)
          .toList();
    } else {
      log.info("No entries find in db for document ids: {}", ids);
      return null;
    }
  }

  @Override
  public void updateSuspenseQueueDocuments(
      List<Long> ids, String modifiedBy, LocalDateTime modifiedOn) {
    suspenseQueueRepository.updateSuspenseQueueEntities(ids, modifiedBy, modifiedOn);
  }

  @Override
  public void insertSuspenseQueueDocuments(List<SuspenseQueue> documents) {
    List<SuspenseQueueEntity> docs =
        documents.stream().filter(Objects::nonNull).map(suspenseQueueTransformer).toList();
    suspenseQueueRepository.saveAllAndFlush(docs);
  }
}
