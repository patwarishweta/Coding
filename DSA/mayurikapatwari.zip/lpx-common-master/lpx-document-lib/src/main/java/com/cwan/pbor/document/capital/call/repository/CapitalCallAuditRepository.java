package com.cwan.pbor.document.capital.call.repository;

import com.cwan.pbor.document.capital.call.entity.CapitalCallAuditEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface CapitalCallAuditRepository extends JpaRepository<CapitalCallAuditEntity, Long> {

  Optional<CapitalCallAuditEntity> findFirstByDocumentIdOrderByTimestampDesc(Long documentId);

  List<CapitalCallAuditEntity> findByDocumentIdInOrderByTimestamp(List<Long> documentIds);

  @Transactional
  void deleteByDocumentId(Long documentId);

  @Modifying
  @Transactional
  @Query(
      value =
          """
              insert into capital_call (document_id, action, status, comment)
              select ccd.document_id,
                     'APPROVE',
                     'NEW_CAPITAL_CALL',
                     concat('Capital Call record for Document ID: ', ccd.document_id, ' created.')
              from capital_call_document ccd
              where not exists (select 1
                                from capital_call cc
                                where cc.document_id = ccd.document_id)
              """,
      nativeQuery = true)
  int insertMissedCapitalCalls();
}
