package com.cwan.pbor.document;

import jakarta.persistence.QueryHint;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.hibernate.jpa.HibernateHints;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

public interface DocumentRepository extends JpaRepository<DocumentEntity, Long> {

  Collection<DocumentEntity> findAllByAccountIdInAndDocDateEqualsAndIsDisabledFalse(
      Collection<Long> accountIds, LocalDate documentDate);

  Collection<DocumentEntity> findAllByAccountIdIn(Collection<Long> accountIds);

  Collection<DocumentEntity> findAllByAccountIdInAndReceivedDateIsBetweenAndIsDisabledFalse(
      Collection<Long> accountIds, LocalDate receivedDateBegin, LocalDate receivedDateEnd);

  Collection<DocumentEntity>
      findAllByAccountIdInAndReceivedDateIsBetweenAndTypeInAndIsDisabledFalse(
          Collection<Long> accountIds,
          LocalDate receivedDateBegin,
          LocalDate receivedDateEnd,
          Collection<String> type);

  Collection<DocumentEntity> findAllByAccountIdInAndDocDateIsBetweenAndIsDisabledFalse(
      Collection<Long> accountIds, LocalDate docDateBegin, LocalDate docDateEnd);

  @Query(
      "SELECT d "
          + "FROM DocumentEntity d "
          + "WHERE d.isDisabled is false "
          + "  AND d.accountId IN :accountIds "
          + "  AND d.docDate BETWEEN :beginDate AND :endDate "
          + "ORDER BY d.docDate DESC")
  @QueryHints({
    @QueryHint(name = HibernateHints.HINT_FETCH_SIZE, value = "500"),
    @QueryHint(name = HibernateHints.HINT_READ_ONLY, value = "true")
  })
  Collection<DocumentEntity> findActiveDocumentsByAccountsAndDateRange(
      @Param("accountIds") Collection<Long> accountIds,
      @Param("beginDate") LocalDate beginDate,
      @Param("endDate") LocalDate endDate);

  Collection<DocumentEntity> findAllByAccountIdAndFileNameAndReceivedDateAndIsDisabledFalse(
      Long accountId, String fileName, LocalDate receivedDate);

  Collection<DocumentEntity> findTop1ByFileNameAndIsDisabledFalse(String fileName);

  Collection<DocumentEntity> findAllByAccountIdInAndPeriodEndDateBetweenAndIsDisabledFalse(
      Collection<Long> accountIds, LocalDate periodStartDate, LocalDate periodEndDate);

  Collection<DocumentEntity> findAllByAccountIdInAndCashMvmtDateBetweenAndIsDisabledFalse(
      Collection<Long> accountIds, LocalDate cashMvmtStartDate, LocalDate cashMvmtEndDate);

  Collection<DocumentEntity> findAllByAccountIdInAndCashMvmtDateBetweenAndTypeInAndIsDisabledFalse(
      Collection<Long> accountIds,
      LocalDate cashMvmtStartDate,
      LocalDate cashMvmtEndDate,
      Collection<String> type);

  Collection<DocumentEntity> findAllByIdIn(Collection<Long> documentIds);

  Collection<DocumentEntity> findAllByDirectoryIdAndIsDisabledIsFalse(Long directoryId);

  Collection<DocumentEntity> findAllByAccountIdAndFileNameContainingIgnoreCaseAndIsDisabledIsFalse(
      Long accountId, String filename);

  Collection<DocumentEntity> findAllByAccountIdInAndIsDisabled(
      Collection<Long> accountIds, Boolean isDisabled);

  Collection<DocumentEntity> findAllByAccountIdAndCanoeId(Long accountIds, String canoeId);

  List<DocumentEntity> findByCanoeId(String canoeId);

  @Query(
      "SELECT d "
          + "FROM DocumentEntity d "
          + "WHERE d.canoeId = :canoeId "
          + "  AND d.accountId = :accountId "
          + "  AND d.securityId = :securityId ")
  Optional<DocumentEntity> findByCanoeIdAndAccountIdAndSecurityId(
      String canoeId, Long accountId, Long securityId);

  Collection<DocumentEntity> findAllByAccountIdAndDirectoryIdIsNullAndIsDisabledIsFalse(
      Long accountId);

  List<DocumentEntity> findAllByAccountIdInAndSecurityIdAndDocDateAndIsDisabledFalse(
      List<Long> accountIds, Long securityId, LocalDate docDate);

  List<DocumentEntity> findAllByAccountIdInAndSecurityIdAndDocDateAndType(
      List<Long> accountIds, Long securityId, LocalDate docDate, String type);

  List<DocumentEntity> findAllByCustodyTransactionIdAndIsDisabledFalse(Long custodyTransactionId);

  @Query(
      "select doc from DocumentEntity doc where doc.docDate>=CURRENT_DATE and doc.isDisabled = false")
  List<DocumentEntity> findAllActiveDocumentsForToday();

  @Query(
      "SELECT d.accountId, d.securityId, MAX(d.docDate) FROM DocumentEntity d "
          + "WHERE d.accountId IN (:accountIds) "
          + "AND d.type = 'Capital Account Statement' AND d.docDate <= :providedDate "
          + "AND d.dataSource != 'MANUAL' "
          + "GROUP BY d.accountId, d.securityId")
  List<Object[]> findLatestStatementDatesByAccountAndSecurity(
      @Param("accountIds") List<Long> accountIds, @Param("providedDate") LocalDate providedDate);

  List<DocumentEntity> findAllByCreatedOnAfter(LocalDateTime createdOn);

  List<DocumentEntity> findAllBySecurityIdIn(List<Long> securityIds);

  List<DocumentEntity> findFirst100ByCloudStorageIdIsNullOrderByIdAsc();

  @Query(
      value =
          "SELECT * FROM document WHERE cloud_storage_id IS NULL OR cloud_storage_id = '' ORDER BY id ASC LIMIT 100",
      nativeQuery = true)
  List<DocumentEntity> findFirst100ByCloudStorageIdIsNullOrEmptyOrderByIdAsc();

  Optional<DocumentEntity> findFirstByCanoeIdAndCloudStorageIdIsNotNullOrderByIdDesc(
      String canoeId);

  @Query(
      "SELECT d "
          + "FROM DocumentEntity d "
          + "WHERE d.accountId = :accountId "
          + "  AND d.securityId = :securityId "
          + "  AND d.canoeId = :canoeId "
          + "  AND d.isDisabled = false "
          + "  AND d.source IN :sources "
          + "ORDER BY d.modifiedOn DESC")
  Optional<DocumentEntity> findMostRecentDocumentByCriteria(
      Long accountId, Long securityId, String canoeId, Set<String> sources);

  @Query(
      "SELECT d FROM DocumentEntity d "
          + "WHERE d.frequency = :frequency "
          + "AND d.securityId = :securityId "
          + "AND d.type = :documentType "
          + "AND d.docDate > :docDate")
  List<DocumentEntity> findDocumentsBySecurityIdFrequencyTypeAndDate(
      Long securityId, String frequency, String documentType, LocalDate docDate);

  @Query(
      "SELECT d FROM DocumentEntity d "
          + "where d.frequency = :frequency  "
          + "AND d.securityId IN :securityIds "
          + "AND d.type = :documentType "
          + "AND d.docDate=:docDate  and date(d.createdOn) between :startDate AND :endDate")
  List<DocumentEntity> findDocumentsBySecurityIdsFrequencyTypeAndDocDateCreationDate(
      Set<Long> securityIds,
      String frequency,
      String documentType,
      LocalDate docDate,
      LocalDate startDate,
      LocalDate endDate);

  @Query(
      "SELECT d FROM DocumentEntity d WHERE d.accountId IN :accountIds "
          + "AND d.isDisabled = :isDisabled "
          + "AND (:startDate IS NULL OR d.createdOn >= :startDate) "
          + "AND (:endDate IS NULL OR d.createdOn <= :endDate)")
  List<DocumentEntity> findAllByAccountIdAndIsDisabledAndCreatedOnBetween(
      @Param("accountIds") Set<Long> accountIds,
      @Param("isDisabled") Boolean isDisabled,
      @Param("startDate") LocalDateTime startDate,
      @Param("endDate") LocalDateTime endDate);

  @Query(
      """
        SELECT d
        FROM DocumentEntity d
        WHERE d.id IN :docIds
          AND d.isDisabled IS FALSE
          AND d.canoeId IS NOT NULL
          AND d.accountId IS NOT NULL
          AND d.securityId IS NOT NULL
          AND d.rawDataCloudStorageId IS NOT NULL
      """)
  Collection<DocumentEntity> findAllActiveByIds(@Param("docIds") Collection<Long> docIds);
}
