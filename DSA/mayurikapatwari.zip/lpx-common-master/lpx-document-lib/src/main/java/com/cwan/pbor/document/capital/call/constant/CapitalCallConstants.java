package com.cwan.pbor.document.capital.call.constant;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.lpx.domain.CapitalCallUserAction;
import java.time.LocalDate;
import java.util.Map;
import lombok.experimental.UtilityClass;

/** Contains utility constants related to Capital Call operations. */
@UtilityClass
public class CapitalCallConstants {

  /** Constants representing default date boundaries for Capital Calls. */
  @UtilityClass
  public static class DateConstants {

    public static final LocalDate MIN_START_DATE = LocalDate.of(1900, 1, 1);
    public static final LocalDate MAX_END_DATE = LocalDate.of(2300, 12, 31);
  }

  /** Constants representing system users in the context of Capital Calls. */
  @UtilityClass
  public static class SystemUserConstants {

    public static final Integer ID = -1;
    public static final String FULL_NAME = "SYSTEM";
    public static final String EMAIL = "no-reply@clearwateranalytics.com";
  }

  /** Constants representing service-specific values for Capital Calls. */
  @UtilityClass
  public static class ServiceConstants {

    public static final String DOCUMENT_TYPE_CAPITAL_CALL_NOTICE = "Capital Call Notice";
  }

  /** Constants related to document transformation operations for Capital Calls. */
  @UtilityClass
  public static class DocumentTransformerConstants {

    public static final String NEW_DOCUMENT =
        "Capital Call created and awaiting system processing.";
    public static final CapitalCallUser CAPITAL_CALL_USER = CapitalCallUser.builder().build();
    public static final CapitalCallUserAction CAPITAL_CALL_USER_ACTION =
        CapitalCallUserAction.builder().user(CAPITAL_CALL_USER).build();
  }

  /** Constants defining valid status transitions for a CapitalCallDocument. */
  @UtilityClass
  public static class StatusTransitionUtilConstants {

    public static final Map<CapitalCallStatus, Map<CapitalCallAction, CapitalCallStatus>>
        VALID_STATUS_TRANSITIONS =
            Map.of(
                CapitalCallStatus.BLACKLISTED,
                Map.of(CapitalCallAction.REJECT, CapitalCallStatus.WIRE_CHECK),
                CapitalCallStatus.WIRE_CHECK,
                Map.of(
                    CapitalCallAction.REJECT,
                    CapitalCallStatus.WIRE_CHECK_REJECTED,
                    CapitalCallAction.APPROVE,
                    CapitalCallStatus.INITIAL_REVIEW),
                CapitalCallStatus.WIRE_CHECK_REJECTED,
                Map.of(CapitalCallAction.REJECT, CapitalCallStatus.WIRE_CHECK),
                CapitalCallStatus.INITIAL_REVIEW,
                Map.of(
                    CapitalCallAction.REJECT,
                    CapitalCallStatus.WIRE_CHECK,
                    CapitalCallAction.APPROVE,
                    CapitalCallStatus.FINAL_REVIEW),
                CapitalCallStatus.FINAL_REVIEW,
                Map.of(
                    CapitalCallAction.REJECT,
                    CapitalCallStatus.INITIAL_REVIEW,
                    CapitalCallAction.APPROVE,
                    CapitalCallStatus.COMPLETED),
                CapitalCallStatus.COMPLETED,
                Map.of(CapitalCallAction.REJECT, CapitalCallStatus.FINAL_REVIEW),
                CapitalCallStatus.NEW_CAPITAL_CALL,
                Map.of(
                    CapitalCallAction.REJECT,
                    CapitalCallStatus.BLACKLISTED,
                    CapitalCallAction.APPROVE,
                    CapitalCallStatus.WIRE_CHECK));
  }
}
