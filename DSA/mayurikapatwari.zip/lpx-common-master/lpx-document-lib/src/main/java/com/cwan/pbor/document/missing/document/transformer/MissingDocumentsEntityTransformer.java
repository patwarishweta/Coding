package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentsEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class MissingDocumentsEntityTransformer
    implements Function<MissingDocuments, MissingDocumentsEntity> {

  @Override
  public MissingDocumentsEntity apply(MissingDocuments missingDocuments) {
    return MissingDocumentsEntity.builder()
        .id(missingDocuments.getId())
        .accountId(missingDocuments.getAccountId())
        .securityId(missingDocuments.getSecurityId())
        .fundName(missingDocuments.getFundName())
        .clientId(missingDocuments.getClientId())
        .clientName(missingDocuments.getClientName())
        .documentMissingCategory(missingDocuments.getDocumentMissingCategory())
        .documentType(missingDocuments.getDocumentType())
        .docDate(missingDocuments.getDocDate())
        .createdOn(missingDocuments.getCreatedOn())
        .flagCanoeUploaded(missingDocuments.getFlagCanoeUploaded())
        .flag(missingDocuments.getFlag())
        .flagBeginDate(missingDocuments.getFlagBeginDate())
        .flagEndDate(missingDocuments.getFlagEndDate())
        .flagComment(missingDocuments.getFlagComment())
        .flagLastModifiedBy(missingDocuments.getFlagLastModifiedBy())
        .flagLastModifiedOn(missingDocuments.getFlagLastModifiedOn())
        .build();
  }
}
