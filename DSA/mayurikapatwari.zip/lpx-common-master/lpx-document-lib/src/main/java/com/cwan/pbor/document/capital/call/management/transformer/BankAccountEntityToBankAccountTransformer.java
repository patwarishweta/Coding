package com.cwan.pbor.document.capital.call.management.transformer;

import com.cwan.lpx.domain.BankAccount;
import com.cwan.pbor.document.capital.call.management.entity.BankAccountEntity;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankAccountEntityToBankAccountTransformer
    implements Function<BankAccountEntity, BankAccount> {

  private final BankEntityToBankTransformer bankEntityToBankTransformer;

  public BankAccountEntityToBankAccountTransformer(
      BankEntityToBankTransformer bankEntityToBankTransformer) {
    this.bankEntityToBankTransformer = bankEntityToBankTransformer;
  }

  @Override
  public BankAccount apply(BankAccountEntity bankAccountEntity) {
    return Optional.ofNullable(bankAccountEntity)
        .map(
            entity ->
                BankAccount.builder()
                    .bankAccountUuid(entity.getBankAccountUuid())
                    .bank(bankEntityToBankTransformer.apply(entity.getBank()))
                    .accountId(entity.getAccountId())
                    .accountName(entity.getAccountName())
                    .accountNumber(entity.getAccountNumber())
                    .iban(entity.getIban())
                    .createdAt(entity.getCreatedAt())
                    .createdBy(entity.getCreatedBy())
                    .build())
        .orElse(null);
  }
}
