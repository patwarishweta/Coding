package com.cwan.pbor.document.constant;

public enum DocumentStatus {
  NEW,
  UPDATE,
  DUPLICATE,
  OLD_REJECTED
}
