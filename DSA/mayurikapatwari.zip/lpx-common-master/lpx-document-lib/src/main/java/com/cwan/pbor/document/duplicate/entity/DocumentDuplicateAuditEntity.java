package com.cwan.pbor.document.duplicate.entity;

import com.cwan.pbor.document.duplicate.constant.DuplicateStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Immutable;

@Entity
@Table(name = "document_duplicate_audit", catalog = "pabor")
@Immutable
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(builderClassName = "DocumentDuplicateAuditEntityBuilder", toBuilder = true)
public class DocumentDuplicateAuditEntity {

  @SuppressWarnings("unused")
  public static class DocumentDuplicateAuditEntityBuilder {

    public DocumentDuplicateAuditEntityBuilder action(String action) {
      this.action = StringUtils.trimToNull(action);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder assigneeEmail(String assigneeEmail) {
      this.assigneeEmail = StringUtils.trimToNull(assigneeEmail);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder assigneeFullName(String assigneeFullName) {
      this.assigneeFullName = StringUtils.trimToNull(assigneeFullName);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder clientName(String clientName) {
      this.clientName = StringUtils.trimToNull(clientName);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder comment(String comment) {
      this.comment = StringUtils.trimToNull(comment);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder entity(String entity) {
      this.entity = StringUtils.trimToNull(entity);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder investment(String investment) {
      this.investment = StringUtils.trimToNull(investment);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder modifierEmail(String modifierEmail) {
      this.modifierEmail = StringUtils.trimToNull(modifierEmail);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder modifierFullName(String modifierFullName) {
      this.modifierFullName = StringUtils.trimToNull(modifierFullName);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder note(String note) {
      this.note = StringUtils.trimToNull(note);
      return this;
    }

    public DocumentDuplicateAuditEntityBuilder ultimateParentName(String ultimateParentName) {
      this.ultimateParentName = StringUtils.trimToNull(ultimateParentName);
      return this;
    }
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "audit_id")
  private Long auditId;

  @Column(name = "document_duplicate_id", nullable = false)
  private Long documentDuplicateId;

  @Column(name = "version")
  private Integer version;

  @Column(name = "action", length = 10)
  private String action;

  @Column(
      name = "action_timestamp",
      nullable = false,
      columnDefinition = "DATETIME DEFAULT CURRENT_TIMESTAMP")
  private LocalDateTime actionTimestamp;

  @Column(name = "document_id")
  private Long documentId;

  @Column(name = "entity", length = 510)
  private String entity;

  @Column(name = "investment", length = 510)
  private String investment;

  @Column(name = "client_id")
  private Long clientId;

  @Column(name = "client_name", length = 510)
  private String clientName;

  @Column(name = "ultimate_parent_id")
  private Long ultimateParentId;

  @Column(name = "ultimate_parent_name", length = 510)
  private String ultimateParentName;

  @Column(name = "is_disabled")
  private Boolean isDisabled;

  @Column(name = "assignee_id")
  private Long assigneeId;

  @Column(name = "assignee_full_name", length = 510)
  private String assigneeFullName;

  @Column(name = "assignee_email", length = 510)
  private String assigneeEmail;

  @Column(name = "modifier_id")
  private Long modifierId;

  @Column(name = "modifier_full_name", length = 510)
  private String modifierFullName;

  @Column(name = "modifier_email", length = 510)
  private String modifierEmail;

  @Enumerated(EnumType.STRING)
  @Column(name = "duplicate_status", length = 170)
  private DuplicateStatus duplicateStatus;

  @Column(name = "comment", length = 510)
  private String comment;

  @Column(name = "note", length = 510)
  private String note;

  @Column(name = "ts_created")
  private LocalDateTime tsCreated;

  @Column(name = "ts_modified")
  private LocalDateTime tsModified;

  @Transient @Builder.Default private boolean isNew = true;
}
