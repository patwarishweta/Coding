package com.cwan.pbor.document.missing.document.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "missing_document_expectations_config", catalog = "pabor")
@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class MissingDocumentExpectationsConfigEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long securityId;
  private Long fundId;
  private String fundName;
  private String documentType;
  private String frequency;
  private Integer threshold;
  private Boolean isActive;
}
