package com.cwan.pbor.document.capital.call.management.service;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.pbor.document.capital.call.management.api.CapitalCallManagement;
import com.cwan.pbor.document.capital.call.management.repository.BankAccountRepository;
import com.cwan.pbor.document.capital.call.management.repository.BankBlacklistRepository;
import com.cwan.pbor.document.capital.call.management.repository.BankRepository;
import com.cwan.pbor.document.capital.call.management.transformer.BankAccountEntityToBankAccountTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankAccountToBankAccountEntityTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankBlacklistEntityToBankBlacklistTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankBlacklistToBankBlacklistEntityTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankEntityToBankTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankToBankEntityTransformer;
import com.cwan.pbor.document.capital.call.management.util.BankErrorMessage;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class CapitalCallManagementService implements CapitalCallManagement {

  @PersistenceContext private EntityManager entityManager;
  private final BankRepository bankRepository;
  private final BankAccountRepository bankAccountRepository;
  private final BankBlacklistRepository bankBlacklistRepository;
  private final BankToBankEntityTransformer bankToBankEntityTransformer;
  private final BankEntityToBankTransformer bankEntityToBankTransformer;
  private final BankAccountToBankAccountEntityTransformer bankAccountToBankAccountEntityTransformer;
  private final BankAccountEntityToBankAccountTransformer bankAccountEntityToBankAccountTransformer;
  private final BankBlacklistToBankBlacklistEntityTransformer
      bankBlacklistToBankBlacklistEntityTransformer;
  private final BankBlacklistEntityToBankBlacklistTransformer
      bankBlacklistEntityToBankBlacklistTransformer;

  public CapitalCallManagementService(
      EntityManager entityManager,
      BankRepository bankRepository,
      BankAccountRepository bankAccountRepository,
      BankBlacklistRepository bankBlacklistRepository,
      BankToBankEntityTransformer bankToBankEntityTransformer,
      BankEntityToBankTransformer bankEntityToBankTransformer,
      BankAccountToBankAccountEntityTransformer bankAccountToBankAccountEntityTransformer,
      BankAccountEntityToBankAccountTransformer bankAccountEntityToBankAccountTransformer,
      BankBlacklistToBankBlacklistEntityTransformer bankBlacklistToBankBlacklistEntityTransformer,
      BankBlacklistEntityToBankBlacklistTransformer bankBlacklistEntityToBankBlacklistTransformer) {
    this.entityManager = entityManager;
    this.bankRepository = bankRepository;
    this.bankAccountRepository = bankAccountRepository;
    this.bankBlacklistRepository = bankBlacklistRepository;
    this.bankToBankEntityTransformer = bankToBankEntityTransformer;
    this.bankEntityToBankTransformer = bankEntityToBankTransformer;
    this.bankAccountToBankAccountEntityTransformer = bankAccountToBankAccountEntityTransformer;
    this.bankAccountEntityToBankAccountTransformer = bankAccountEntityToBankAccountTransformer;
    this.bankBlacklistToBankBlacklistEntityTransformer =
        bankBlacklistToBankBlacklistEntityTransformer;
    this.bankBlacklistEntityToBankBlacklistTransformer =
        bankBlacklistEntityToBankBlacklistTransformer;
  }

  // ----------------- BANK ------------------
  @Override
  @Transactional
  public Bank createBank(Bank bank) {
    log.debug("Initiating bank creation process with parameters: {}", bank);
    Objects.requireNonNull(bank, BankErrorMessage.BANK_MUST_NOT_BE_NULL);
    var exists =
        bankRepository.existsByClientIdAndAbaRoutingNumberAndSwiftChipsCode(
            bank.clientId(), bank.abaRoutingNumber(), bank.swiftChipsCode());
    if (exists) {
      log.error("Attempted to create a bank with duplicate parameters: {}", bank);
      throw new DataIntegrityViolationException(
          BankErrorMessage.ENTRY_ALREADY_EXISTS_WITH_GIVEN_PARAMETERS);
    }
    var createdBank =
        persistAndTransform(
            bank, bankToBankEntityTransformer, bankRepository, bankEntityToBankTransformer);
    log.debug("Bank created successfully with UUID: {}", createdBank.bankUuid());
    return createdBank;
  }

  @Override
  public List<Bank> fetchBanksByClient(Long clientId) {
    log.debug("Initiating fetch process for banks associated with client ID: {}", clientId);
    Objects.requireNonNull(clientId, BankErrorMessage.CLIENT_ID_MUST_NOT_BE_NULL);
    return bankRepository.findByClientId(clientId).stream()
        .map(bankEntityToBankTransformer)
        .toList();
  }

  @Override
  public Optional<Bank> fetchBank(String bankUuid) {
    log.debug("Initiating fetch process for bank with UUID: {}", bankUuid);
    Objects.requireNonNull(bankUuid, BankErrorMessage.BANK_UUID_MUST_NOT_BE_NULL);
    Optional<Bank> fetchedBank =
        bankRepository.findByBankUuid(bankUuid).map(bankEntityToBankTransformer);
    if (fetchedBank.isEmpty()) {
      log.warn("No bank found with UUID: {}", bankUuid);
    }
    return fetchedBank;
  }

  @Override
  @Transactional
  public boolean deleteBank(String bankUuid, Long deletedBy) {
    log.debug("Initiating deletion process for bank with UUID: {}", bankUuid);
    Objects.requireNonNull(bankUuid, BankErrorMessage.BANK_UUID_MUST_NOT_BE_NULL);
    var bank =
        fetchBank(
                StringUtils.lowerCase(StringUtils.trimToNull(StringUtils.normalizeSpace(bankUuid))))
            .orElseThrow(
                () ->
                    new NoSuchElementException(
                        "Deletion failed. No bank found with UUID: " + bankUuid));
    fetchBankAccountsByClient(bank.clientId()).stream()
        .filter(
            bankAccount ->
                Objects.nonNull(bankAccount.bank())
                    && StringUtils.equalsIgnoreCase(bank.bankUuid(), bankAccount.bank().bankUuid()))
        .map(BankAccount::bankAccountUuid)
        .forEach(
            bankAccountUuid -> {
              deleteBankAccount(bankAccountUuid, deletedBy);
              log.info(
                  "Bank account soft-deleted for bank with UUID {}: {}", bankUuid, bankAccountUuid);
            });
    fetchBankBlacklistsByClient(bank.clientId()).stream()
        .filter(
            bankBlacklist ->
                Objects.nonNull(bankBlacklist.bank())
                    && StringUtils.equalsIgnoreCase(
                        bank.bankUuid(), bankBlacklist.bank().bankUuid()))
        .map(BankBlacklist::bankBlacklistUuid)
        .forEach(
            bankBlacklistUuid -> {
              deleteBankBlacklist(bankBlacklistUuid, deletedBy);
              log.info(
                  "Bank blacklist soft-deleted for bank with UUID {}: {}",
                  bankUuid,
                  bankBlacklistUuid);
            });
    var deleted = bankRepository.softDeleteByBankUuidAndSetDeletedBy(bankUuid, deletedBy) > 0;
    if (!deleted) {
      log.error("Failed to delete bank with UUID: {}", bankUuid);
      throw new IllegalStateException("Failed to delete bank with UUID: " + bankUuid);
    }
    log.debug("Bank with UUID: {} deleted successfully by user: {}", bankUuid, deletedBy);
    return true;
  }

  // ----------------- BANK ACCOUNT ------------------
  @Override
  public List<BankAccount> findAllBankAccounts() {
    log.debug("Initiating fetch process for all bank accounts.");
    return bankAccountRepository.findAll().stream()
        .map(bankAccountEntityToBankAccountTransformer)
        .toList();
  }

  @Override
  @Transactional
  public BankAccount createBankAccount(BankAccount bankAccount) {
    log.debug("Initiating bank account creation with parameters: {}", bankAccount);
    Objects.requireNonNull(bankAccount, BankErrorMessage.BANK_ACCOUNT_MUST_NOT_BE_NULL);
    var bankEntity =
        bankRepository
            .findByBankUuid(bankAccount.bank().bankUuid())
            .orElseThrow(
                () -> {
                  log.error(
                      "No bank found with the provided bankUuid: {}",
                      bankAccount.bank().bankUuid());
                  return new EntityNotFoundException(
                      BankErrorMessage.NO_BANK_FOUND_WITH_THE_PROVIDED_BANK_UUID);
                });
    var exists =
        bankAccountRepository.existsByBankIdAndAccountIdAndAccountNumberAndIban(
            bankEntity.getBankId(),
            bankAccount.accountId(),
            bankAccount.accountNumber(),
            bankAccount.iban());
    if (exists) {
      log.error("Attempted to create a bank account with duplicate parameters: {}", bankAccount);
      throw new DataIntegrityViolationException(
          BankErrorMessage.ENTRY_ALREADY_EXISTS_WITH_GIVEN_PARAMETERS);
    }
    var createdBankAccount =
        persistAndTransform(
            bankAccount,
            bankAccountToBankAccountEntityTransformer,
            bankAccountRepository,
            bankAccountEntityToBankAccountTransformer);
    log.debug(
        "Bank account created successfully with UUID: {}", createdBankAccount.bankAccountUuid());
    return createdBankAccount;
  }

  @Override
  public List<BankAccount> fetchBankAccountsByAccount(Long accountId) {
    log.debug(
        "Initiating fetch process for bank accounts associated with account ID: {}", accountId);
    Objects.requireNonNull(accountId, BankErrorMessage.ACCOUNT_ID_MUST_NOT_BE_NULL);
    return bankAccountRepository.findByAccountId(accountId).stream()
        .map(bankAccountEntityToBankAccountTransformer)
        .toList();
  }

  @Override
  public List<BankAccount> fetchBankAccountsByClient(Long clientId) {
    log.debug("Initiating fetch process for bank accounts associated with client ID: {}", clientId);
    Objects.requireNonNull(clientId, BankErrorMessage.CLIENT_ID_MUST_NOT_BE_NULL);
    return bankAccountRepository.findByClientId(clientId).stream()
        .map(bankAccountEntityToBankAccountTransformer)
        .toList();
  }

  @Override
  public Optional<BankAccount> fetchBankAccount(String bankAccountUuid) {
    log.debug("Initiating fetch process for bank account with UUID: {}", bankAccountUuid);
    Objects.requireNonNull(bankAccountUuid, BankErrorMessage.BANK_ACCOUNT_UUID_MUST_NOT_BE_NULL);
    Optional<BankAccount> fetchedBankAccount =
        bankAccountRepository
            .findByBankAccountUuid(bankAccountUuid)
            .map(bankAccountEntityToBankAccountTransformer);
    if (fetchedBankAccount.isEmpty()) {
      log.warn("No bank account found with UUID: {}", bankAccountUuid);
    }
    return fetchedBankAccount;
  }

  @Override
  @Transactional
  public boolean deleteBankAccount(String bankAccountUuid, Long deletedBy) {
    log.debug("Initiating deletion process for bank account with UUID: {}", bankAccountUuid);
    Objects.requireNonNull(bankAccountUuid, BankErrorMessage.BANK_ACCOUNT_UUID_MUST_NOT_BE_NULL);
    var deleted =
        bankAccountRepository.softDeleteByBankAccountUuidAndSetDeletedBy(bankAccountUuid, deletedBy)
            > 0;
    if (deleted) {
      log.debug(
          "Bank account with UUID: {} deleted successfully by user: {}",
          bankAccountUuid,
          deletedBy);
    } else {
      log.warn("Failed to delete bank account with UUID: {}", bankAccountUuid);
    }
    return deleted;
  }

  // ----------------- BANK BLACKLIST ------------------
  @Override
  @Transactional
  public BankBlacklist createBankBlacklist(BankBlacklist bankBlacklist) {
    log.debug("Initiating bank blacklist creation with parameters: {}", bankBlacklist);
    Objects.requireNonNull(bankBlacklist, BankErrorMessage.BANK_BLACKLIST_MUST_NOT_BE_NULL);
    var bankEntity =
        bankRepository
            .findByBankUuid(bankBlacklist.bank().bankUuid())
            .orElseThrow(
                () -> {
                  log.error(
                      "No bank found with the provided bankUuid: {}",
                      bankBlacklist.bank().bankUuid());
                  return new EntityNotFoundException(
                      BankErrorMessage.NO_BANK_FOUND_WITH_THE_PROVIDED_BANK_UUID);
                });
    var exists = bankBlacklistRepository.existsByBankId(bankEntity.getBankId());
    if (exists) {
      log.error(
          "Attempted to create a bank blacklist for bank with ID: {} which already exists.",
          bankEntity.getBankId());
      throw new DataIntegrityViolationException(
          BankErrorMessage.ENTRY_ALREADY_EXISTS_WITH_GIVEN_PARAMETERS);
    }
    var createdBankBlacklist =
        persistAndTransform(
            bankBlacklist,
            bankBlacklistToBankBlacklistEntityTransformer,
            bankBlacklistRepository,
            bankBlacklistEntityToBankBlacklistTransformer);
    log.debug(
        "Bank blacklist created successfully with UUID: {}",
        createdBankBlacklist.bankBlacklistUuid());
    return createdBankBlacklist;
  }

  @Override
  public List<BankBlacklist> fetchBankBlacklistsByClient(Long clientId) {
    log.debug(
        "Initiating fetch process for bank blacklists associated with client ID: {}", clientId);
    Objects.requireNonNull(clientId, BankErrorMessage.CLIENT_ID_MUST_NOT_BE_NULL);
    return bankBlacklistRepository.findByClientId(clientId).stream()
        .map(bankBlacklistEntityToBankBlacklistTransformer)
        .toList();
  }

  @Override
  public Optional<BankBlacklist> fetchBankBlacklist(String bankBlacklistUuid) {
    log.debug("Initiating fetch process for bank blacklist with UUID: {}", bankBlacklistUuid);
    Objects.requireNonNull(
        bankBlacklistUuid, BankErrorMessage.BANK_BLACKLIST_UUID_MUST_NOT_BE_NULL);
    Optional<BankBlacklist> fetchedBankBlacklist =
        bankBlacklistRepository
            .findByBankBlacklistUuid(bankBlacklistUuid)
            .map(bankBlacklistEntityToBankBlacklistTransformer);
    if (fetchedBankBlacklist.isEmpty()) {
      log.warn("No bank blacklist found with UUID: {}", bankBlacklistUuid);
    }
    return fetchedBankBlacklist;
  }

  @Override
  @Transactional
  public boolean deleteBankBlacklist(String bankBlacklistUuid, Long deletedBy) {
    log.debug("Initiating deletion process for bank blacklist with UUID: {}", bankBlacklistUuid);
    Objects.requireNonNull(
        bankBlacklistUuid, BankErrorMessage.BANK_BLACKLIST_UUID_MUST_NOT_BE_NULL);
    var deleted =
        bankBlacklistRepository.softDeleteByBankBlacklistUuidAndSetDeletedBy(
                bankBlacklistUuid, deletedBy)
            > 0;
    if (deleted) {
      log.debug(
          "Bank blacklist with UUID: {} deleted successfully by user: {}",
          bankBlacklistUuid,
          deletedBy);
    } else {
      log.warn("Failed to delete bank blacklist with UUID: {}", bankBlacklistUuid);
    }
    return deleted;
  }

  // ----------------- COMMON ------------------
  private <T, E> T persistAndTransform(
      T input,
      Function<T, E> transformToEntity,
      JpaRepository<E, ?> repo,
      Function<E, T> transformBack) {
    var entity = transformToEntity.apply(input);
    entity = repo.saveAndFlush(entity);
    entityManager.refresh(entity);
    return transformBack.apply(entity);
  }
}
