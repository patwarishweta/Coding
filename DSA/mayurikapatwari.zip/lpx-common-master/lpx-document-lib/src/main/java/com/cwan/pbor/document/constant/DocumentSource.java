package com.cwan.pbor.document.constant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@SuppressWarnings("unused")
@Getter
@RequiredArgsConstructor
public enum DocumentSource {
  NEXLA("Nexla"),
  OVERRIDE("Override"),
  SUSPENSE("Suspense"),
  DUPLICATE_OVERRIDE("Duplicate Override");

  private final String sourceName;
}
