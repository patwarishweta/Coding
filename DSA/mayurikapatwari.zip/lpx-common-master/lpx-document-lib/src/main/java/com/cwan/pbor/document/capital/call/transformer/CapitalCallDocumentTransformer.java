package com.cwan.pbor.document.capital.call.transformer;

import static com.cwan.lpx.domain.CapitalCallAction.APPROVE;
import static com.cwan.lpx.domain.CapitalCallAction.REJECT;
import static com.cwan.lpx.domain.CapitalCallStatus.FINAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.INITIAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.NOT_SPECIFIED;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK;
import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DocumentTransformerConstants.CAPITAL_CALL_USER;
import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DocumentTransformerConstants.CAPITAL_CALL_USER_ACTION;
import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DocumentTransformerConstants.NEW_DOCUMENT;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallBankDetail;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallPermissions;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUserAction;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.capital.call.entity.CapitalCallDocumentEntity;
import com.cwan.pbor.document.capital.call.util.CapitalCallStatusTransitionUtil;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.springframework.stereotype.Component;

@Component
public class CapitalCallDocumentTransformer {

  /**
   * Converts a CapitalCallDocumentEntity into a CapitalCallDocument. Also uses a
   * CapitalCallAuditLog for additional details.
   *
   * @param capitalCallEntity The capital call entity to transform.
   * @param auditLog The audit log associated with the capital call entity.
   * @return A transformed CapitalCallDocument.
   */
  public CapitalCallDocument apply(
      CapitalCallDocumentEntity capitalCallEntity, CapitalCallAuditLog auditLog) {
    // Creation of bank detail from capital call entity.
    var bankDetail = createBankDetailFromEntity(capitalCallEntity);
    // Begin building the CapitalCallDocument.
    var builder =
        CapitalCallDocument.builder()
            .documentId(capitalCallEntity.getDocumentId())
            .documentName(capitalCallEntity.getDocumentName())
            .paymentAmount(capitalCallEntity.getPaymentAmount())
            .netAmount(capitalCallEntity.getNetAmount())
            .daysAging(capitalCallEntity.getDaysAging())
            .bankDetail(bankDetail)
            .callReceivedDate(capitalCallEntity.getCallReceivedDate())
            .dueDate(capitalCallEntity.getDueDate())
            .security(createSecurityFromEntity(capitalCallEntity))
            .account(createAccountFromEntity(capitalCallEntity))
            .currency(capitalCallEntity.getCurrency())
            .audit(
                Objects.isNull(auditLog) || Objects.isNull(auditLog.audit())
                    ? Collections.emptyList()
                    : auditLog.audit());
    // Assigning status and comment based on the audit log.
    setPermissionsBasedOnStatus(determineStatusFromAudit(auditLog, builder), builder);
    // Creating and assigning user actions based on the audit log.
    assignUserActions(auditLog, builder);
    return builder.build();
  }

  private CapitalCallBankDetail createBankDetailFromEntity(
      CapitalCallDocumentEntity capitalCallEntity) {
    return CapitalCallBankDetail.builder()
        .bankName(capitalCallEntity.getBankName())
        .abaRoutingNumber(capitalCallEntity.getAbaRoutingNumber())
        .swiftOrChips(capitalCallEntity.getSwiftOrChips())
        .accountNumber(capitalCallEntity.getAccountNumber())
        .accountIban(capitalCallEntity.getAccountIban())
        .bankDetailId(capitalCallEntity.getBankDetailId())
        .build();
  }

  private Security createSecurityFromEntity(CapitalCallDocumentEntity capitalCallEntity) {
    return Optional.ofNullable(capitalCallEntity.getSecurityId())
        .map(id -> Security.builder().securityId(id).build())
        .orElse(null);
  }

  private Account createAccountFromEntity(CapitalCallDocumentEntity capitalCallEntity) {
    return Optional.ofNullable(capitalCallEntity.getAccountId())
        .map(id -> Account.builder().id(id).build())
        .orElse(null);
  }

  private CapitalCallStatus determineStatusFromAudit(
      CapitalCallAuditLog auditLog, CapitalCallDocument.CapitalCallDocumentBuilder builder) {
    if (isAuditLogValid(auditLog)) {
      var latestAudit = getLatestAuditFromLog(auditLog);
      setStatusAndCommentForBuilder(builder, latestAudit.nextStatus(), latestAudit.comment());
      return latestAudit.nextStatus();
    }
    setStatusAndCommentForBuilder(builder, NOT_SPECIFIED, NEW_DOCUMENT);
    return NOT_SPECIFIED;
  }

  private boolean isAuditLogValid(CapitalCallAuditLog auditLog) {
    return Objects.nonNull(auditLog)
        && Objects.nonNull(auditLog.audit())
        && !auditLog.audit().isEmpty();
  }

  private CapitalCallAudit getLatestAuditFromLog(CapitalCallAuditLog auditLog) {
    return auditLog.audit().stream()
        .max(Comparator.comparing(CapitalCallAudit::timestamp))
        .orElseThrow();
  }

  private void setStatusAndCommentForBuilder(
      CapitalCallDocument.CapitalCallDocumentBuilder builder,
      CapitalCallStatus status,
      String comment) {
    builder.status(status);
    builder.comment(comment);
  }

  private void setPermissionsBasedOnStatus(
      CapitalCallStatus currentStatus, CapitalCallDocument.CapitalCallDocumentBuilder builder) {
    builder.permissions(
        CapitalCallPermissions.builder()
            .approveActionAllowed(
                Objects.nonNull(
                    CapitalCallStatusTransitionUtil.getNewStatus(currentStatus, APPROVE)))
            .rejectActionAllowed(
                Objects.nonNull(
                    CapitalCallStatusTransitionUtil.getNewStatus(currentStatus, REJECT)))
            .build());
  }

  private void assignUserActions(
      CapitalCallAuditLog auditLog, CapitalCallDocument.CapitalCallDocumentBuilder builder) {
    if (Objects.nonNull(auditLog)
        && Objects.nonNull(auditLog.audit())
        && !auditLog.audit().isEmpty()) {
      var audits = auditLog.audit();
      EnumMap<CapitalCallStatus, CapitalCallUserAction> firstActionsByStatus =
          IntStream.iterate(audits.size() - 1, i -> i >= 0, i -> i - 1)
              .mapToObj(audits::get)
              .collect(
                  Collectors.toMap(
                      CapitalCallAudit::previousStatus,
                      audit ->
                          CapitalCallUserAction.builder()
                              .actionTimestamp(audit.timestamp())
                              .user(
                                  Objects.nonNull(audit.user()) ? audit.user() : CAPITAL_CALL_USER)
                              .build(),
                      (a, b) -> a,
                      () -> new EnumMap<>(CapitalCallStatus.class)));
      builder.wireCheckAction(
          firstActionsByStatus.getOrDefault(WIRE_CHECK, CAPITAL_CALL_USER_ACTION));
      builder.initialReviewAction(
          firstActionsByStatus.getOrDefault(INITIAL_REVIEW, CAPITAL_CALL_USER_ACTION));
      builder.finalReviewAction(
          firstActionsByStatus.getOrDefault(FINAL_REVIEW, CAPITAL_CALL_USER_ACTION));
    } else {
      builder.wireCheckAction(CAPITAL_CALL_USER_ACTION);
      builder.initialReviewAction(CAPITAL_CALL_USER_ACTION);
      builder.finalReviewAction(CAPITAL_CALL_USER_ACTION);
    }
  }
}
