package com.cwan.pbor.document.missing.document.api.impl;

import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.pbor.document.missing.document.api.MissingDocumentExpectationsConfigService;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationsConfigEntity;
import com.cwan.pbor.document.missing.document.repository.MissingDocumentExpectationsConfigRepository;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentExpectationsConfigEntityTransformer;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentExpectationsConfigTransformer;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class MissingDocumentExpectationsConfigServiceImpl
    implements MissingDocumentExpectationsConfigService {

  private MissingDocumentExpectationsConfigRepository missingDocumentExpectationsConfigRepository;
  private MissingDocumentExpectationsConfigTransformer missingDocumentExpectationsConfigTransformer;
  private MissingDocumentExpectationsConfigEntityTransformer
      missingDocumentExpectationsConfigEntityTransformer;

  @Override
  public List<MissingDocumentExpectationsConfig>
      getAllMissingDocumentExpectationsConfigBySecurityIds(List<Long> securityIds) {
    return missingDocumentExpectationsConfigRepository.findAllBySecurityIdIn(securityIds).stream()
        .map(missingDocumentExpectationsConfigTransformer)
        .toList();
  }

  @Override
  public Flux<MissingDocumentExpectationsConfig> addMissingDocumentExpectationsConfig(
      Set<MissingDocumentExpectationsConfig> missingDocumentExpectationsConfigs) {
    missingDocumentExpectationsConfigs.stream()
        .filter(doc -> doc.getId() != null)
        .forEach(
            doc ->
                log.warn(
                    "MissingDocumentExpectationsConfig with Id {} can't be added Id should be null.",
                    doc.getId()));
    return Flux.fromIterable(missingDocumentExpectationsConfigs)
        .filter(doc -> doc.getId() == null)
        .filter(Objects::nonNull)
        .map(missingDocumentExpectationsConfigEntityTransformer)
        .map(this::saveMissingDocumentExpectationsConfig)
        .map(missingDocumentExpectationsConfigTransformer);
  }

  private MissingDocumentExpectationsConfigEntity saveMissingDocumentExpectationsConfig(
      MissingDocumentExpectationsConfigEntity missingDocumentExpectationsConfigEntity) {
    return missingDocumentExpectationsConfigRepository.saveAndFlush(
        missingDocumentExpectationsConfigEntity);
  }
}
