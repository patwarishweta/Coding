package com.cwan.pbor.document.missing.document.repository;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentsEntity;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MissingDocumentsRepository extends JpaRepository<MissingDocumentsEntity, Long> {

  List<MissingDocumentsEntity> findAllByAccountIdInAndSecurityIdIn(
      List<Long> accountIds, List<Long> securityIds);

  List<MissingDocumentsEntity> findAllByAccountIdIn(List<Long> accountIds);

  @Query(
      "SELECT doc1 FROM MissingDocumentsEntity doc1 WHERE doc1.documentMissingCategory=:documentMissingCategory"
          + " AND NOT EXISTS (SELECT 1 FROM MissingDocumentsEntity doc2 "
          + "WHERE doc2.accountId=doc1.accountId and doc2.securityId=doc1.securityId"
          + " and doc2.documentType=doc1.documentType and doc2.docDate=doc1.docDate"
          + " and doc2.createdOn > doc1.createdOn)")
  List<MissingDocumentsEntity> retrieveAllMissingDocumentsByCategory(
      MissingDocumentStatus documentMissingCategory);

  @Query(
      "SELECT md FROM MissingDocumentsEntity md "
          + "WHERE md.accountId = :accountId "
          + "AND md.securityId = :securityId "
          + "AND md.docDate = :docDate "
          + "AND md.documentType = :documentType "
          + "AND md.documentMissingCategory IN :missingCategories")
  List<MissingDocumentsEntity>
      findByAccountIdAndSecurityIdAndDocDateAndDocumentTypeAndDocumentMissingCategory(
          Long accountId,
          Long securityId,
          LocalDate docDate,
          String documentType,
          List<MissingDocumentStatus> missingCategories);

  @Query(
      "SELECT md FROM MissingDocumentsEntity md "
          + "WHERE md.clientId = :clientId "
          + "AND md.securityId = :securityId "
          + "AND md.docDate = :docDate "
          + "AND md.documentType = :documentType "
          + "AND md.documentMissingCategory IN :missingCategories")
  List<MissingDocumentsEntity>
      findByClientIdAndSecurityIdAndDocDateAndDocumentTypeAndDocumentMissingCategory(
          Long clientId,
          Long securityId,
          LocalDate docDate,
          String documentType,
          List<MissingDocumentStatus> missingCategories);

  @Query(
      "SELECT md FROM MissingDocumentsEntity md "
          + "WHERE md.clientId = :clientId "
          + "AND md.securityId = :securityId "
          + "AND md.docDate = :docDate "
          + "AND md.documentType = :documentType "
          + "AND md.documentMissingCategory IN :missingCategories "
          + "AND NOT EXISTS ("
          + "  SELECT 1 FROM MissingDocumentsEntity submd "
          + "  WHERE submd.clientId = md.clientId "
          + "  AND submd.securityId = md.securityId "
          + "  AND submd.docDate = md.docDate "
          + "  AND submd.documentType = md.documentType "
          + "  AND submd.documentMissingCategory = 'RECEIVED'"
          + ")")
  List<MissingDocumentsEntity>
      findByClientIdAndSecurityIdAndDocDateAndDocumentTypeAndDocumentMissingCategoryNotReceieved(
          Long clientId,
          Long securityId,
          LocalDate docDate,
          String documentType,
          List<MissingDocumentStatus> missingCategories);

  @Query(
      "SELECT m FROM MissingDocumentsEntity m WHERE m.accountId IN :accountIds "
          + "AND (:startCreatedOn IS NULL OR m.createdOn >= :startCreatedOn) "
          + "AND (:endCreatedOn IS NULL OR m.createdOn <= :endCreatedOn)")
  List<MissingDocumentsEntity> findByAccountIdAndCreatedOnBetween(
      @Param("accountIds") List<Long> accountIds,
      @Param("startCreatedOn") LocalDateTime startCreatedOn,
      @Param("endCreatedOn") LocalDateTime endCreatedOn);
}
