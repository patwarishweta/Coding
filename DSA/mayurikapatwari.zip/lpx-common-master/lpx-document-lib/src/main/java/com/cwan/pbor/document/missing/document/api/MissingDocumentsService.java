package com.cwan.pbor.document.missing.document.api;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import java.util.List;
import java.util.Set;

public interface MissingDocumentsService {
  List<MissingDocuments> getAllMissingDocumentsUsingAccountIdInAndSecurityIdIn(
      List<Long> accountIds, List<Long> securityIds);

  List<MissingDocuments> getAllMissingDocumentsUsingAccountIdIn(List<Long> accountIds);

  List<MissingDocuments> getAllMissingDocumentsByCategory(
      MissingDocumentStatus documentMissingCategory);

  List<MissingDocuments> addMissingDocuments(Set<MissingDocuments> missingDocuments);
}
