package com.cwan.pbor.document.misc.document.repository;

import com.cwan.pbor.document.misc.document.entity.MiscDocumentEntity;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MiscDocumentRepository extends JpaRepository<MiscDocumentEntity, Long> {

  List<MiscDocumentEntity> findByDocumentId(Long documentId);

  @Query(
      "SELECT m FROM MiscDocumentEntity m WHERE m.ultimateParentId = :ultimateParentId "
          + "AND (:startReceivedDate IS NULL OR m.receivedDate >= :startReceivedDate) "
          + "AND (:endReceivedDate IS NULL OR m.receivedDate <= :endReceivedDate) "
          + "AND m.status = :status")
  List<MiscDocumentEntity> findByUltimateParentIdAndReceivedDateBetweenAndStatus(
      @Param("ultimateParentId") Long ultimateParentId,
      @Param("startReceivedDate") LocalDate startReceivedDate,
      @Param("endReceivedDate") LocalDate endReceivedDate,
      @Param("status") String status);

  @Query(
      "SELECT d FROM MiscDocumentEntity d WHERE d.accountId IN :accountIds "
          + "AND (:beginDate IS NULL OR d.receivedDate >= :beginDate) "
          + "AND (:endDate IS NULL OR d.receivedDate <= :endDate) "
          + "AND d.status = :status")
  List<MiscDocumentEntity> findByAccountIdInAndReceivedDateBetweenAndStatus(
      @Param("accountIds") Set<Long> accountIds,
      @Param("beginDate") LocalDate beginDate,
      @Param("endDate") LocalDate endDate,
      @Param("status") String status);
}
