package com.cwan.pbor.document.capital.call.util;

import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.StatusTransitionUtilConstants.VALID_STATUS_TRANSITIONS;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallStatus;
import java.util.Objects;
import lombok.experimental.UtilityClass;

/**
 * This utility class defines the valid transitions between different states of a Capital Call based
 * on the action taken. This class is designed to prevent invalid state transitions in
 * CapitalCallDocument operations. It uses a static map to define valid transitions from one state
 * to another. The class also provides utility methods for checking if a transition is valid or not.
 */
@UtilityClass
public class CapitalCallStatusTransitionUtil {

  /**
   * Returns the new status of a Capital Call based on the current status and the action taken.
   *
   * @param currentStatus The current status of the Capital Call.
   * @param action The action taken on the Capital Call.
   * @return the new status after performing the action on the Capital Call or null if the action is
   *     invalid.
   */
  public static CapitalCallStatus getNewStatus(
      CapitalCallStatus currentStatus, CapitalCallAction action) {
    var actionsMap = VALID_STATUS_TRANSITIONS.get(currentStatus);
    return Objects.nonNull(actionsMap) ? actionsMap.get(action) : null;
  }
}
