package com.cwan.pbor.document.duplicate.helper;

import com.cwan.lpx.domain.DocumentDuplicateGroupKey;
import com.cwan.lpx.domain.DuplicateCanoe;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateEntity;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateExtEntity;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

@Slf4j
public final class DocumentDuplicateServiceHelper {

  /**
   * Builds the final result map of DocumentDuplicateGroupKey -> SortedSet<DuplicateCanoe>. We only
   * add an entry if: - The associated Document is non-null. - The extension list is non-empty. -
   * There is exactly one (or at least one) extension that is "current". - There is at least one
   * "non-current" extension.
   */
  public static Map<DocumentDuplicateGroupKey, SortedSet<DuplicateCanoe>> buildResultMap(
      Collection<DocumentDuplicateEntity> docDuplicates,
      Map<Long, DocumentEntity> docMap,
      Map<Long, List<DocumentDuplicateExtEntity>> extByDupId) {
    var resultMap = new TreeMap<DocumentDuplicateGroupKey, SortedSet<DuplicateCanoe>>();
    docDuplicates.forEach(
        dd -> {
          var doc = docMap.get(dd.getDocumentId());
          if (Objects.isNull(doc)) {
            log.info("Skipping docDuplicate {} because document is null in docMap.", dd.getId());
            return;
          }
          var duplicateExtEntities = extByDupId.getOrDefault(dd.getId(), List.of());
          if (CollectionUtils.isEmpty(duplicateExtEntities)) {
            log.info("Skipping docDuplicate {} because extension list is empty.", dd.getId());
            return;
          }
          var currentExt =
              duplicateExtEntities.stream()
                  .filter(DocumentDuplicateExtEntity::isCurrent)
                  .findFirst()
                  .orElse(null);
          if (Objects.isNull(currentExt)) {
            log.info(
                "Skipping docDuplicate {} because no current extension was found.", dd.getId());
            return;
          }
          var nonCurrents = duplicateExtEntities.stream().filter(e -> !e.isCurrent()).toList();
          if (CollectionUtils.isEmpty(nonCurrents)) {
            log.info(
                "Skipping docDuplicate {} because there are no non-current extensions.",
                dd.getId());
            return;
          }
          // If we get here, we can build the group key and the set of DuplicateCanoe.
          var mapKey = buildGroupKey(doc, dd, currentExt);
          var canoeSet = new TreeSet<DuplicateCanoe>();
          nonCurrents.forEach(nc -> buildAndAddDuplicateCanoe(nc, canoeSet));
          resultMap.put(mapKey, canoeSet);
        });
    return resultMap;
  }

  private static void buildAndAddDuplicateCanoe(
      DocumentDuplicateExtEntity nc, TreeSet<DuplicateCanoe> canoeSet) {
    canoeSet.add(
        DuplicateCanoe.builder()
            .duplicateCanoeId(nc.getCanoeId())
            .duplicateReceivedOn(nc.getTsCreated())
            .build());
  }

  /**
   * Builds the DocumentDuplicateGroupKey from the Document, DocumentDuplicate, and the single
   * current extension.
   */
  private static DocumentDuplicateGroupKey buildGroupKey(
      DocumentEntity documentEntity,
      DocumentDuplicateEntity documentDuplicateEntity,
      DocumentDuplicateExtEntity documentDuplicateExtEntity) {
    return DocumentDuplicateGroupKey.builder()
        .documentDuplicateId(documentDuplicateEntity.getId())
        .documentDuplicateCreatedOn(documentDuplicateEntity.getTsCreated())
        .documentId(documentEntity.getId())
        .fileName(documentEntity.getFileName())
        .accountId(documentEntity.getAccountId())
        .securityId(documentEntity.getSecurityId())
        .documentType(documentEntity.getType())
        .documentReceivedDate(documentEntity.getReceivedDate())
        .documentDate(documentEntity.getDocDate())
        .entity(documentDuplicateEntity.getEntity())
        .investment(documentDuplicateEntity.getInvestment())
        .clientId(documentDuplicateEntity.getClientId())
        .clientName(documentDuplicateEntity.getClientName())
        .ultimateParentId(documentDuplicateEntity.getUltimateParentId())
        .ultimateParentName(documentDuplicateEntity.getUltimateParentName())
        .assignee(documentDuplicateEntity.getAssigneeFullName())
        .modifier(documentDuplicateEntity.getModifierFullName())
        .duplicateStatus(
            Objects.isNull(documentDuplicateEntity.getDuplicateStatus())
                ? null
                : documentDuplicateEntity.getDuplicateStatus().name())
        .comment(documentDuplicateEntity.getComment())
        .note(documentDuplicateEntity.getNote())
        .createdOn(documentDuplicateEntity.getTsCreated())
        .modifiedOn(documentDuplicateEntity.getTsModified())
        .currentCanoeId(documentDuplicateExtEntity.getCanoeId())
        .currentReceivedOn(documentDuplicateExtEntity.getTsCreated())
        .build();
  }

  private DocumentDuplicateServiceHelper() {
    // Private constructor to prevent instantiation
  }
}
