package com.cwan.pbor.document.capital.call.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Immutable;

@Entity
@Data
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Immutable
@Table(name = "capital_call_document", schema = "pabor")
public class CapitalCallDocumentEntity {

  @Id
  @Column(name = "document_id")
  private Long documentId;

  @Column(name = "document_name")
  private String documentName;

  @Column(name = "payment_amount")
  private BigDecimal paymentAmount;

  @Column(name = "net_amount")
  private BigDecimal netAmount;

  @Column(name = "days_aging")
  private Integer daysAging;

  @Column(name = "bank_name")
  private String bankName;

  @Column(name = "aba_routing_number")
  private String abaRoutingNumber;

  @Column(name = "swift_or_chips")
  private String swiftOrChips;

  @Column(name = "account_number")
  private String accountNumber;

  @Column(name = "account_iban ")
  private String accountIban;

  @Column(name = "call_received_date")
  private LocalDate callReceivedDate;

  @Column(name = "due_date")
  private LocalDate dueDate;

  @Column(name = "security_id")
  private Long securityId;

  @Column(name = "account_id")
  private Long accountId;

  @Column(name = "currency")
  private String currency;

  @Column(name = "bank_detail_id")
  private Long bankDetailId;
}
