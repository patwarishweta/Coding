package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentsEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class MissingDocumentsTransformer
    implements Function<MissingDocumentsEntity, MissingDocuments> {

  @Override
  public MissingDocuments apply(MissingDocumentsEntity missingDocumentsEntity) {
    return MissingDocuments.builder()
        .id(missingDocumentsEntity.getId())
        .accountId(missingDocumentsEntity.getAccountId())
        .securityId(missingDocumentsEntity.getSecurityId())
        .fundName(missingDocumentsEntity.getFundName())
        .clientId(missingDocumentsEntity.getClientId())
        .clientName(missingDocumentsEntity.getClientName())
        .documentMissingCategory(missingDocumentsEntity.getDocumentMissingCategory())
        .documentType(missingDocumentsEntity.getDocumentType())
        .docDate(missingDocumentsEntity.getDocDate())
        .createdOn(missingDocumentsEntity.getCreatedOn())
        .flagCanoeUploaded(missingDocumentsEntity.getFlagCanoeUploaded())
        .flag(missingDocumentsEntity.getFlag())
        .flagBeginDate(missingDocumentsEntity.getFlagBeginDate())
        .flagEndDate(missingDocumentsEntity.getFlagEndDate())
        .flagComment(missingDocumentsEntity.getFlagComment())
        .flagLastModifiedBy(missingDocumentsEntity.getFlagLastModifiedBy())
        .flagLastModifiedOn(missingDocumentsEntity.getFlagLastModifiedOn())
        .build();
  }
}
