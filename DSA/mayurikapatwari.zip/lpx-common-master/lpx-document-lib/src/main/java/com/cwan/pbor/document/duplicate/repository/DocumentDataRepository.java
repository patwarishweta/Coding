package com.cwan.pbor.document.duplicate.repository;

import com.cwan.pbor.document.constant.DocumentStatus;
import com.cwan.pbor.document.duplicate.entity.DocumentDataEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentDataRepository extends JpaRepository<DocumentDataEntity, Long> {

  @Query(
      "SELECT d FROM DocumentDataEntity d WHERE d.existingCanoeId = :existingCanoeId "
          + "AND d.accountId = :accountId "
          + "AND d.securityId = :securityId "
          + "AND d.status = :status "
          + "AND (d.updateBeneficiaryBankDetailId IS NOT NULL "
          + "OR d.updateCorrespondentBankDetailId IS NOT NULL "
          + "OR d.updateIntermediaryBankDetailId IS NOT NULL) "
          + "ORDER BY d.tsCreatedOn DESC")
  Optional<DocumentDataEntity> findLatestActiveWithBankUpdates(
      @Param("existingCanoeId") String existingCanoeId,
      @Param("accountId") Long accountId,
      @Param("securityId") Long securityId,
      @Param("status") DocumentStatus status);
}
