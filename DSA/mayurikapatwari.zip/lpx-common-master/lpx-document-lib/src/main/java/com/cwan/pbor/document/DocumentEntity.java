package com.cwan.pbor.document;

import com.cwan.lpx.domain.DataForgerStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Document", catalog = "pabor")
public class DocumentEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String cloudStorageId;
  private String fileName;
  private String originalFileName;
  private String dataSource;
  private String canoeId;
  private Long accountId;
  private Long securityId;
  private String type;
  private Boolean isAudited;
  private String source;
  private String auditor;
  private String accountingPrinciples;
  private LocalDate auditOpinionDate;
  private String auditOpinion;
  private LocalDate receivedDate;
  private LocalDate docDate;
  private LocalDate cashMvmtDate;
  private String frequency;
  private LocalDate periodStartDate;
  private LocalDate periodEndDate;
  private Boolean checked;
  private String errorStatus;

  @Enumerated(EnumType.STRING)
  private DataForgerStatus dataForgerStatus;

  private String dataForgerOutputPath;
  private Boolean isDisabled;
  private String description;
  private Long directoryId;
  private Long custodyTransactionId;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  private LocalDateTime createdOn;
  private String modifiedBy;
  private Boolean isModifiedByInternalUser;
  private LocalDateTime modifiedOn;
  private Boolean cwanGptUploaded;
  private String assigneeId;
  private String assigneeName;
  private String assigneeEmail;
  private String rawDataCloudStorageId;
  private LocalDateTime rawDataModifiedOn;

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (DocumentEntity) o;
    return (id != null) && Objects.equals(id, that.id);
  }
}
