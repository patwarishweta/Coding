package com.cwan.pbor.document.capital.call.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "bank_accounts")
@Getter
@Setter
@NoArgsConstructor
@Where(clause = "is_deleted = false")
public class BankAccountEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "bank_account_id")
  private Long bankAccountId;

  @Setter(lombok.AccessLevel.NONE)
  @Column(
      name = "bank_account_uuid",
      length = 36,
      unique = true,
      updatable = false,
      insertable = false)
  private String bankAccountUuid;

  @Column(name = "bank_id", nullable = false)
  private Long bankId;

  @Setter(lombok.AccessLevel.NONE)
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(
      name = "bank_id",
      referencedColumnName = "bank_id",
      insertable = false,
      updatable = false)
  private BankEntity bank;

  @Column(name = "account_id", nullable = false)
  private Long accountId;

  @Column(name = "account_name", nullable = false, length = 500)
  private String accountName;

  @Column(name = "account_number", length = 100)
  private String accountNumber;

  @Column(name = "iban", length = 150)
  private String iban;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "created_at", updatable = false, insertable = false)
  private LocalDateTime createdAt;

  @Column(name = "created_by", nullable = false)
  private Long createdBy;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "deleted_at", updatable = false, insertable = false)
  private LocalDateTime deletedAt;

  @Column(name = "deleted_by")
  private Long deletedBy;

  @Column(name = "is_deleted", columnDefinition = "boolean default false", insertable = false)
  private Boolean isDeleted;

  @Builder
  public BankAccountEntity(
      Long bankAccountId,
      Long bankId,
      BankEntity bank,
      Long accountId,
      String accountName,
      String accountNumber,
      String iban,
      Long createdBy,
      Long deletedBy,
      Boolean isDeleted) {
    this.bankAccountId = bankAccountId;
    this.bankId = bankId;
    this.bank = bank;
    this.accountId = accountId;
    this.accountName = accountName;
    this.accountNumber = accountNumber;
    this.iban = iban;
    this.createdBy = createdBy;
    this.deletedBy = deletedBy;
    this.isDeleted = isDeleted;
  }
}
