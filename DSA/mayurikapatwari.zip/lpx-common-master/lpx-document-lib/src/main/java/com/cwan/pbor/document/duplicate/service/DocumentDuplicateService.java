package com.cwan.pbor.document.duplicate.service;

import com.cwan.lpx.domain.DocumentDuplicateGroupKey;
import com.cwan.lpx.domain.DuplicateCanoe;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.DocumentRepository;
import com.cwan.pbor.document.duplicate.api.DocumentDuplicates;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateEntity;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateExtEntity;
import com.cwan.pbor.document.duplicate.helper.DocumentDuplicateServiceHelper;
import com.cwan.pbor.document.duplicate.repository.DocumentDuplicateExtRepository;
import com.cwan.pbor.document.duplicate.repository.DocumentDuplicateRepository;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedSet;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Slf4j
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Service
public class DocumentDuplicateService implements DocumentDuplicates {

  private final DocumentRepository documentRepository;
  private final DocumentDuplicateRepository documentDuplicateRepository;
  private final DocumentDuplicateExtRepository documentDuplicateExtRepository;

  /**
   * Retrieves grouped document duplicates for the provided documentIds. Steps: 1. Find non-disabled
   * DocumentDuplicate rows for the given documentIds. 2. Find their corresponding (non-disabled)
   * Documents. 3. Find all DocumentDuplicateExt rows (non-disabled) for those duplicates. 4.
   * Identify the single "current" row vs. the "non-current" rows. 5. Build the result map grouped
   * by DocumentDuplicateGroupKey, with non-current duplicates as a SortedSet of DuplicateCanoe.
   *
   * @param documentIds The collection of document IDs to process.
   * @return A map keyed by DocumentDuplicateGroupKey, with a SortedSet of DuplicateCanoe as values.
   */
  @Override
  @Transactional
  public Map<DocumentDuplicateGroupKey, SortedSet<DuplicateCanoe>> getGroupedDocumentDuplicates(
      Collection<Long> documentIds) {
    log.info("Entering getGroupedDocumentDuplicates with documentIds={}", documentIds);
    // (A) Handle empty input
    if (CollectionUtils.isEmpty(documentIds)) {
      log.info("No documentIds provided; returning empty result map.");
      return Collections.emptyMap();
    }
    // (B) Retrieve DocumentDuplicateEntities
    var docDuplicates = documentDuplicateRepository.findAllActiveByDocumentIds(documentIds);
    log.info("Found {} active DocumentDuplicateEntity records.", docDuplicates.size());
    if (CollectionUtils.isEmpty(docDuplicates)) {
      log.info("No DocumentDuplicate records found; returning empty result map.");
      return Collections.emptyMap();
    }
    // (C) Fetch the Documents
    var docMap = findActiveDocumentsMap(docDuplicates);
    if (CollectionUtils.isEmpty(docMap)) {
      log.info("No active Documents found matching the duplicates; returning empty result map.");
      return Collections.emptyMap();
    }
    // (D) Fetch the DocumentDuplicateExtEntities
    var extByDupId = findExtensionsGroupedByDuplicateId(docDuplicates);
    // (E) Ensure single current extension
    enforceSingleCurrentExtensionRow(docDuplicates, docMap, extByDupId);
    // (F) Build and return final map
    var resultMap =
        DocumentDuplicateServiceHelper.buildResultMap(docDuplicates, docMap, extByDupId);
    log.info("Exiting getGroupedDocumentDuplicates with result size={}", resultMap.size());
    return resultMap;
  }

  /**
   * Ensures only one current extension row per DocumentDuplicate (by matching the docCanoeId if
   * multiple are marked as current).
   */
  private void enforceSingleCurrentExtensionRow(
      Collection<DocumentDuplicateEntity> docDuplicates,
      Map<Long, DocumentEntity> docMap,
      Map<Long, List<DocumentDuplicateExtEntity>> extByDupId) {
    log.info("Ensuring a single current extension row per DocumentDuplicate...");
    // Build quick lookup for docDuplicates
    Map<Long, DocumentDuplicateEntity> documentDuplicateEntityMap =
        docDuplicates.stream()
            .collect(Collectors.toMap(DocumentDuplicateEntity::getId, Function.identity()));
    // For each group of extension rows, check if more than one is marked "current"
    extByDupId.forEach(
        (dupId, extList) -> {
          var documentDuplicateEntity = documentDuplicateEntityMap.get(dupId);
          if (Objects.isNull(documentDuplicateEntity)) {
            return;
          }
          var documentEntity = docMap.get(documentDuplicateEntity.getDocumentId());
          if (Objects.isNull(documentEntity)) {
            return;
          }
          var docCanoeId = documentEntity.getCanoeId();
          // If docCanoeId is null, skip the single-current-row logic
          if (Objects.nonNull(docCanoeId)) {
            ensureSingleCurrentRow(extList, docCanoeId);
          } else {
            log.info(
                "docCanoeId is null for documentId={}, skipping ensureSingleCurrentRow.",
                documentDuplicateEntity.getDocumentId());
          }
        });
  }

  /**
   * If more than one extension row is currently marked isCurrent = true, retain only the extension
   * whose canoeId matches the given docCanoeId, and un-mark all other "current" ones.
   */
  private void ensureSingleCurrentRow(
      Collection<DocumentDuplicateExtEntity> extList, String docCanoeId) {
    if (CollectionUtils.isEmpty(extList)) {
      return;
    }
    // Currently marked as "current"
    Collection<DocumentDuplicateExtEntity> currentlyMarked =
        extList.stream().filter(DocumentDuplicateExtEntity::isCurrent).toList();
    // If there's 0 or 1 "current", there's nothing to fix
    if (currentlyMarked.size() <= 1) {
      return;
    }
    // Only keep the one matching the docCanoeId
    var matchingOpt =
        currentlyMarked.stream()
            .filter(e -> Objects.equals(e.getCanoeId(), docCanoeId))
            .findFirst();
    // If we can't find any that match docCanoeId, do nothing for now
    if (matchingOpt.isEmpty()) {
      return;
    }
    // Turn off "current" for all but the "matching" one
    var keep = matchingOpt.get();
    var changed = new ArrayList<DocumentDuplicateExtEntity>();
    currentlyMarked.stream()
        .filter(ext -> !Objects.equals(ext.getId(), keep.getId()))
        .forEach(
            ext -> {
              ext.setCurrent(false);
              changed.add(ext);
            });
    if (!changed.isEmpty()) {
      log.info("Updating {} extension row(s) to isCurrent=false.", changed.size());
      documentDuplicateExtRepository.saveAllAndFlush(changed);
    }
  }

  /**
   * Builds a map of documentId -> DocumentEntity from the given list of DocumentDuplicateEntity.
   */
  private Map<Long, DocumentEntity> findActiveDocumentsMap(
      Collection<DocumentDuplicateEntity> docDuplicates) {
    log.info("Fetching corresponding Documents for DocumentDuplicateEntities...");
    var docIds =
        docDuplicates.stream()
            .map(DocumentDuplicateEntity::getDocumentId)
            .collect(Collectors.toSet());
    var documents = documentRepository.findAllActiveByIds(docIds);
    log.info("Found {} active DocumentEntity records.", documents.size());
    return documents.stream().collect(Collectors.toMap(DocumentEntity::getId, Function.identity()));
  }

  /** Builds a map of duplicateId -> list of DocumentDuplicateExtEntity (all active). */
  private Map<Long, List<DocumentDuplicateExtEntity>> findExtensionsGroupedByDuplicateId(
      Collection<DocumentDuplicateEntity> docDuplicates) {
    log.info("Fetching DocumentDuplicateExtEntity records for duplicates...");
    var docDupIds =
        docDuplicates.stream().map(DocumentDuplicateEntity::getId).collect(Collectors.toSet());
    var documentDuplicateExtEntities =
        documentDuplicateExtRepository.findAllActiveByDuplicateIds(docDupIds);
    log.info("Found {} DocumentDuplicateExtEntity records.", documentDuplicateExtEntities.size());
    return documentDuplicateExtEntities.stream()
        .collect(Collectors.groupingBy(DocumentDuplicateExtEntity::getDocumentDuplicateId));
  }
}
