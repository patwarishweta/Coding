package com.cwan.pbor.document.duplicate.constant;

public enum DuplicateStatus {
  OPEN,
  OVERRIDING,
  OVERRIDDEN,
  IGNORED,
  FAILED
}
