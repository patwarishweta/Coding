package com.cwan.pbor.document.duplicate.entity;

import com.cwan.lpx.domain.CanoeDuplicateCheckResponse;
import com.cwan.pbor.document.constant.DocumentStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "document_data", catalog = "pabor")
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(builderClassName = "DocumentDataBuilder")
public class DocumentDataEntity {

  public static class DocumentDataBuilder {

    public DocumentDataBuilder canoeId(String canoeId) {
      this.canoeId = StringUtils.trimToNull(canoeId);
      return this;
    }

    public DocumentDataBuilder customAllocationId(String customAllocationId) {
      this.customAllocationId = StringUtils.trimToNull(customAllocationId);
      return this;
    }

    public DocumentDataBuilder documentType(String documentType) {
      this.documentType = StringUtils.trimToNull(documentType);
      return this;
    }

    public DocumentDataBuilder entity(String entity) {
      this.entity = StringUtils.trimToNull(entity);
      return this;
    }

    public DocumentDataBuilder existingCanoeId(String existingCanoeId) {
      this.existingCanoeId = StringUtils.trimToNull(existingCanoeId);
      return this;
    }

    public DocumentDataBuilder existingFileName(String existingFileName) {
      this.existingFileName = StringUtils.trimToNull(existingFileName);
      return this;
    }

    public DocumentDataBuilder fileName(String fileName) {
      this.fileName = StringUtils.trimToNull(fileName);
      return this;
    }

    public DocumentDataBuilder investment(String investment) {
      this.investment = StringUtils.trimToNull(investment);
      return this;
    }

    public DocumentDataBuilder rawDataCloudStorageId(String rawDataCloudStorageId) {
      this.rawDataCloudStorageId = StringUtils.trimToNull(rawDataCloudStorageId);
      return this;
    }
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "canoe_id", nullable = false)
  private String canoeId;

  @Column(name = "file_name", nullable = false)
  private String fileName;

  @Column(name = "account_id", nullable = false)
  private Long accountId;

  @Column(name = "security_id", nullable = false)
  private Long securityId;

  @Column(name = "raw_data_cloud_storage_id", nullable = false)
  private String rawDataCloudStorageId;

  @Column(name = "raw_data_modified_on", nullable = false)
  private LocalDateTime rawDataModifiedOn;

  @Column(name = "document_type", nullable = false)
  private String documentType;

  @Column(name = "custom_allocation_id", nullable = false)
  private String customAllocationId;

  @Column(name = "entity")
  private String entity;

  @Column(name = "investment")
  private String investment;

  @Column(name = "data_date")
  private LocalDate dataDate;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "capital_call", columnDefinition = "json")
  private List<Double> capitalCall;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "capital_call_net_amount", columnDefinition = "json")
  private List<Double> capitalCallNetAmount;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "distribution", columnDefinition = "json")
  private List<Double> distribution;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "distribution_net_amount", columnDefinition = "json")
  private List<Double> distributionNetAmount;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "ending_balance", columnDefinition = "json")
  private List<Double> endingBalance;

  @Enumerated(EnumType.STRING)
  @Column(name = "status", nullable = false)
  private DocumentStatus status;

  @Column(name = "update_beneficiary_bank_detail_id")
  private Long updateBeneficiaryBankDetailId;

  @Column(name = "update_correspondent_bank_detail_id")
  private Long updateCorrespondentBankDetailId;

  @Column(name = "update_intermediary_bank_detail_id")
  private Long updateIntermediaryBankDetailId;

  @Column(name = "existing_document_id")
  private Long existingDocumentId;

  @Column(name = "existing_canoe_id")
  private String existingCanoeId;

  @Column(name = "existing_file_name")
  private String existingFileName;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "comparison_json", columnDefinition = "json")
  private Map<String, CanoeDuplicateCheckResponse> comparisonJson;

  @CreationTimestamp
  @Column(name = "ts_created_on", updatable = false, nullable = false)
  private LocalDateTime tsCreatedOn;
}
