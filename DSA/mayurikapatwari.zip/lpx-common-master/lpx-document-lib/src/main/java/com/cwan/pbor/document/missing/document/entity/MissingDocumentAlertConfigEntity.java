package com.cwan.pbor.document.missing.document.entity;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.pbor.document.missing.document.transformer.LongListConverter;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentStatusListConverter;
import com.cwan.pbor.document.missing.document.transformer.StringListConverter;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "missing_document_alert_config", catalog = "pabor")
@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class MissingDocumentAlertConfigEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long clientId;

  @Convert(converter = LongListConverter.class)
  @Column(columnDefinition = "json")
  private List<Long> accountIds;

  @Convert(converter = LongListConverter.class)
  @Column(columnDefinition = "json")
  private List<Long> securityIds;

  @Convert(converter = MissingDocumentStatusListConverter.class)
  @Column(columnDefinition = "json")
  private List<MissingDocumentStatus> documentMissingCategories;

  @Convert(converter = StringListConverter.class)
  @Column(columnDefinition = "json")
  private List<String> documentTypes;

  @Convert(converter = StringListConverter.class)
  @Column(columnDefinition = "json")
  private List<String> username;

  private LocalDate startDate;

  private LocalDate expiry;

  private Boolean isActive;
}
