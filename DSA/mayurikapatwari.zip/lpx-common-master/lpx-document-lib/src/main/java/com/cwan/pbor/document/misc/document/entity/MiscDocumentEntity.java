package com.cwan.pbor.document.misc.document.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "misc_documents", catalog = "pabor")
public class MiscDocumentEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long documentId;

  private Long accountId;

  private String accountName;

  private Long securityId;

  private String securityName;

  private Long ultimateParentId;

  private String ultimateParentName;

  private String documentType;

  private String tags;

  private LocalDate receivedDate;
  private LocalDate cashMovementDate;
  private LocalDate docDate;

  private String description;
  private String comment;
  private String status;

  @Column(name = "created_on", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
  private LocalDateTime createdOn;

  @Column(
      name = "modified_on",
      columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
  private LocalDateTime modifiedOn;

  private String createdBy;
  private String modifiedBy;
  private String classificationOutput;
  private String dataForgeStatus;
}
