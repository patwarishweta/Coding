package com.cwan.pbor.document.capital.call.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "bank_blacklists")
@Getter
@Setter
@NoArgsConstructor
@Where(clause = "is_deleted = false")
public class BankBlacklistEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "bank_blacklist_id")
  private Long bankBlacklistId;

  @Setter(lombok.AccessLevel.NONE)
  @Column(
      name = "bank_blacklist_uuid",
      length = 36,
      unique = true,
      updatable = false,
      insertable = false)
  private String bankBlacklistUuid;

  @Column(name = "bank_id", nullable = false)
  private Long bankId;

  @Setter(lombok.AccessLevel.NONE)
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(
      name = "bank_id",
      referencedColumnName = "bank_id",
      insertable = false,
      updatable = false)
  private BankEntity bank;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "created_at", updatable = false, insertable = false)
  private LocalDateTime createdAt;

  @Column(name = "created_by", nullable = false)
  private Long createdBy;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "created_at", updatable = false, insertable = false)
  private LocalDateTime deletedAt;

  @Column(name = "deleted_by")
  private Long deletedBy;

  @Column(name = "is_deleted", columnDefinition = "boolean default false", insertable = false)
  private Boolean isDeleted;

  @Builder
  public BankBlacklistEntity(
      Long bankBlacklistId,
      Long bankId,
      BankEntity bank,
      Long createdBy,
      Long deletedBy,
      Boolean isDeleted) {
    this.bankBlacklistId = bankBlacklistId;
    this.bankId = bankId;
    this.bank = bank;
    this.createdBy = createdBy;
    this.deletedBy = deletedBy;
    this.isDeleted = isDeleted;
  }
}
