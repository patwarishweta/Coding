package com.cwan.pbor.document.capital.call.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "banks")
@Getter
@Setter
@NoArgsConstructor
@Where(clause = "is_deleted = false")
public class BankEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "bank_id")
  private Long bankId;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "bank_uuid", length = 36, unique = true, updatable = false, insertable = false)
  private String bankUuid;

  @Column(name = "client_id", nullable = false)
  private Long clientId;

  @Column(name = "bank_name", nullable = false, length = 500)
  private String bankName;

  @Column(name = "aba_routing_number", length = 50)
  private String abaRoutingNumber;

  @Column(name = "swift_chips_code", length = 50)
  private String swiftChipsCode;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "created_at", updatable = false, insertable = false)
  private LocalDateTime createdAt;

  @Column(name = "created_by", nullable = false)
  private Long createdBy;

  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "deleted_at", updatable = false, insertable = false)
  private LocalDateTime deletedAt;

  @Column(name = "deleted_by")
  private Long deletedBy;

  @Column(name = "is_deleted", columnDefinition = "boolean default false", insertable = false)
  private Boolean isDeleted;

  @Builder
  public BankEntity(
      Long bankId,
      Long clientId,
      String bankName,
      String abaRoutingNumber,
      String swiftChipsCode,
      Long createdBy,
      Long deletedBy,
      Boolean isDeleted) {
    this.bankId = bankId;
    this.clientId = clientId;
    this.bankName = bankName;
    this.abaRoutingNumber = abaRoutingNumber;
    this.swiftChipsCode = swiftChipsCode;
    this.createdBy = createdBy;
    this.deletedBy = deletedBy;
    this.isDeleted = isDeleted;
  }
}
