package com.cwan.pbor.document.duplicate.repository;

import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateExtEntity;
import java.util.Collection;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentDuplicateExtRepository
    extends JpaRepository<DocumentDuplicateExtEntity, Long> {

  @Query(
      "SELECT dde FROM DocumentDuplicateExtEntity dde "
          + "WHERE dde.documentDuplicateId = :documentDuplicateId "
          + "AND dde.canoeId = :canoeId "
          + "AND dde.isDisabled IS FALSE")
  Optional<DocumentDuplicateExtEntity> findActiveByDuplicateIdAndCanoeId(
      @Param("documentDuplicateId") Long documentDuplicateId, @Param("canoeId") String canoeId);

  @Query(
      "SELECT dde FROM DocumentDuplicateExtEntity dde "
          + "WHERE dde.documentDuplicateId IN :dupIds "
          + "AND dde.isDisabled IS FALSE")
  Collection<DocumentDuplicateExtEntity> findAllActiveByDuplicateIds(
      @Param("dupIds") Collection<Long> dupIds);
}
