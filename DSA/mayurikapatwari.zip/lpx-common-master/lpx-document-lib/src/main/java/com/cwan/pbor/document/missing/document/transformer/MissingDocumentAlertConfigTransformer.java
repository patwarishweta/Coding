package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentAlertConfigEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class MissingDocumentAlertConfigTransformer
    implements Function<MissingDocumentAlertConfigEntity, MissingDocumentAlertConfig> {

  @Override
  public MissingDocumentAlertConfig apply(
      MissingDocumentAlertConfigEntity missingDocumentAlertConfigEntity) {
    return MissingDocumentAlertConfig.builder()
        .id(missingDocumentAlertConfigEntity.getId())
        .clientId(missingDocumentAlertConfigEntity.getClientId())
        .accountIds(missingDocumentAlertConfigEntity.getAccountIds())
        .securityIds(missingDocumentAlertConfigEntity.getSecurityIds())
        .documentMissingCategories(missingDocumentAlertConfigEntity.getDocumentMissingCategories())
        .documentTypes(missingDocumentAlertConfigEntity.getDocumentTypes())
        .startDate(missingDocumentAlertConfigEntity.getStartDate())
        .expiry(missingDocumentAlertConfigEntity.getExpiry())
        .username(missingDocumentAlertConfigEntity.getUsername())
        .isActive(missingDocumentAlertConfigEntity.getIsActive())
        .build();
  }
}
