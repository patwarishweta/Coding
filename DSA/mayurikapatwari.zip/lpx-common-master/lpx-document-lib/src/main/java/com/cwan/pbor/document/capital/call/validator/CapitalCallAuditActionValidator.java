package com.cwan.pbor.document.capital.call.validator;

import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Utility class that provides validation for the {@link CapitalCallAuditAction} object. Ensures
 * that the fields of the CapitalCallAuditAction are properly set according to predefined
 * conditions.
 */
@UtilityClass
@Slf4j
public class CapitalCallAuditActionValidator {

  /**
   * Validates the given {@link CapitalCallAuditAction} object. Checks for common validation
   * failures such as null fields or invalid values.
   *
   * @param capitalCallAuditAction The object to validate.
   * @return An Optional containing an error message if validation fails, or an empty Optional if
   *     validation succeeds.
   */
  public static Optional<String> validateCapitalCallAuditAction(
      CapitalCallAuditAction capitalCallAuditAction) {
    var reasons = new ArrayList<String>();
    if (Objects.isNull(capitalCallAuditAction)) {
      reasons.add("CapitalCallAuditAction is null");
    } else {
      reasons.addAll(validateUserFields(capitalCallAuditAction));
      reasons.addAll(validateDocumentId(capitalCallAuditAction));
    }
    if (!reasons.isEmpty()) {
      var errorMessage = MessageFormat.format("{0}.", String.join(", ", reasons));
      log.warn(errorMessage);
      return Optional.of(errorMessage);
    }
    return Optional.empty();
  }

  private static Collection<String> validateUserFields(
      CapitalCallAuditAction capitalCallAuditAction) {
    var reasons = new ArrayList<String>();
    if (Objects.isNull(capitalCallAuditAction.user())) {
      reasons.add("User is null");
      return reasons;
    }
    if (StringUtils.isBlank(capitalCallAuditAction.user().fullName())) {
      reasons.add("User full name is blank");
    }
    if (StringUtils.isBlank(capitalCallAuditAction.user().email())) {
      reasons.add("User email is blank");
    }
    reasons.addAll(validateUserId(capitalCallAuditAction));
    return reasons;
  }

  private static Collection<String> validateDocumentId(
      CapitalCallAuditAction capitalCallAuditAction) {
    var reasons = new ArrayList<String>();
    if (Objects.isNull(capitalCallAuditAction.documentId())) {
      reasons.add("Document ID is null");
    } else if (capitalCallAuditAction.documentId() <= 0) {
      reasons.add(
          "Document ID should be greater than 0. Provided value: "
              + capitalCallAuditAction.documentId());
    }
    return reasons;
  }

  private static Collection<String> validateUserId(CapitalCallAuditAction capitalCallAuditAction) {
    var reasons = new ArrayList<String>();
    var user = capitalCallAuditAction.user();
    var userId = user.id();
    if (Objects.isNull(userId)) {
      reasons.add("User ID is null");
    } else if ((userId <= 0)
        && (!StringUtils.equalsIgnoreCase(
                StringUtils.deleteWhitespace(user.fullName()), SystemUserConstants.FULL_NAME)
            && !StringUtils.equalsIgnoreCase(
                StringUtils.deleteWhitespace(user.email()), SystemUserConstants.EMAIL))) {
      reasons.add("User ID is invalid: " + userId);
    }
    return reasons;
  }
}
