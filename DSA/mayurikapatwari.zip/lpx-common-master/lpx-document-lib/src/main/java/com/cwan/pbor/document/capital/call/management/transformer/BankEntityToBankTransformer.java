package com.cwan.pbor.document.capital.call.management.transformer;

import com.cwan.lpx.domain.Bank;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BankEntityToBankTransformer implements Function<BankEntity, Bank> {

  @Override
  public Bank apply(BankEntity bankEntity) {
    return Optional.ofNullable(bankEntity)
        .map(
            entity ->
                Bank.builder()
                    .bankUuid(entity.getBankUuid())
                    .clientId(entity.getClientId())
                    .bankName(entity.getBankName())
                    .abaRoutingNumber(entity.getAbaRoutingNumber())
                    .swiftChipsCode(entity.getSwiftChipsCode())
                    .createdAt(entity.getCreatedAt())
                    .createdBy(entity.getCreatedBy())
                    .build())
        .orElse(null);
  }
}
