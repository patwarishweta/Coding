package com.cwan.pbor.document;

import com.cwan.lpx.domain.Document;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class DocumentEntityTransformer implements Function<Document, DocumentEntity> {

  @Override
  public DocumentEntity apply(Document document) {
    return DocumentEntity.builder()
        .id(document.getId())
        .cloudStorageId(document.getCloudStorageId())
        .canoeId(document.getCanoeId())
        .fileName(document.getFileName())
        .originalFileName(document.getOriginalFileName())
        .accountId(Objects.nonNull(document.getAccount()) ? document.getAccount().getId() : null)
        .securityId(
            Objects.nonNull(document.getSecurity()) ? document.getSecurity().getSecurityId() : null)
        .type(document.getType())
        .isAudited(document.getIsAudited())
        .source(document.getSource())
        .auditor(document.getAuditor())
        .accountingPrinciples(document.getAccountingPrinciples())
        .auditOpinionDate(document.getAuditOpinionDate())
        .auditOpinion(document.getAuditOpinion())
        .dataSource(document.getDataSource())
        .receivedDate(document.getReceivedDate())
        .docDate(document.getDocumentDate())
        .cashMvmtDate(document.getCashMovementDate())
        .frequency(document.getFrequency())
        .periodStartDate(document.getPeriodStartDate())
        .periodEndDate(document.getPeriodEndDate())
        .checked(document.getChecked())
        .errorStatus(document.getErrorStatus())
        .dataForgerStatus(document.getDataForgerStatus())
        .dataForgerOutputPath(document.getDataForgerOutputPath())
        .isDisabled((document.getIsDisabled() != null) && document.getIsDisabled())
        .directoryId(document.getDirectoryId())
        .description(document.getDescription())
        .createdBy(document.getCreatedBy())
        .isCreatedByInternalUser(document.getIsCreatedByInternalUser())
        .modifiedBy(document.getModifiedBy())
        .isModifiedByInternalUser(document.getIsModifiedByInternalUser())
        .createdOn(
            document.getCreatedOn() != null
                ? document.getCreatedOn()
                : LocalDateTime.now(ZoneOffset.UTC))
        .modifiedOn(
            document.getModifiedOn() != null
                ? document.getModifiedOn()
                : LocalDateTime.now(ZoneOffset.UTC))
        .cwanGptUploaded(document.getCwanGptUploaded())
        .assigneeId(document.getAssigneeId())
        .assigneeName(document.getAssigneeName())
        .assigneeEmail(document.getAssigneeEmail())
        .rawDataCloudStorageId(document.getRawDataCloudStorageId())
        .rawDataModifiedOn(document.getRawDataModifiedOn())
        .custodyTransactionId(document.getCustodyTransactionId())
        .build();
  }
}
