package com.cwan.pbor.document.api;

import com.cwan.lpx.domain.Document;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface Documents {

  Flux<Document> addDocuments(Set<Document> documents);

  Flux<Document> getDocumentsByAccountIdAndFileNameAndReceivedDate(
      Long accountId, String fileName, LocalDate receivedDate);

  Map<String, LocalDate> getLatestStatementDatesMapBeforeOrEqualProvidedDate(
      List<Long> accountIds, LocalDate providedDate);

  Flux<Document> getDocumentsByAccountId(Set<Long> accountId);

  Flux<Document> getDocumentByFileName(String fileName);

  Flux<Document> getDocumentsByAccountAndDate(Set<Long> accountIds, LocalDate documentDate);

  Mono<Document> getDocumentById(Long id);

  Flux<Document> updateDocumentInfo(Set<Document> documents);

  Flux<Document> getDocumentsByAccountsAndReceivedDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate);

  Flux<Document> getDocumentsByAccountsAndReceivedDateBetweenAndTypes(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate, List<String> types);

  Flux<Document> getDocumentsByAccountsAndDocumentDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate);

  @Transactional(readOnly = true)
  Flux<Document> getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
      Collection<Long> accountIds,
      Collection<Long> securityIds,
      LocalDate beginDate,
      LocalDate endDate,
      Collection<String> excludedSources);

  Flux<Document> getDocumentsByAccountsAndPeriodEndDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate);

  Flux<Document> getDocumentsByAccountsAndCashMvmtDateBetween(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate);

  Flux<Document> getDocumentsByAccountsAndCashMvmtDateBetweenAndTypes(
      Set<Long> accountIds, LocalDate beginDate, LocalDate endDate, List<String> types);

  Flux<Document> getDocumentsByIds(Set<Long> documentIds);

  Set<Document> getDocumentsByIdsNonReactive(Set<Long> documentIds);

  Flux<Document> getAllActiveDocumentsByDirectoryId(Long directoryId);

  Flux<Document> getAllActiveDocumentsByAccountIdAndFileName(Long accountId, String filename);

  Flux<Document> getAllDocumentsByAccountIdAndIsDisabled(Set<Long> accountIds, Boolean isDisabled);

  Flux<Document> getAllActiveDocumentsWithoutDirectoryByAccountId(Long accountId);

  @Transactional
  List<Document> getAllDocumentsByAccountIdsAndIsDisabledAndCreatedOnBetween(
      Set<Long> accountIds, Boolean isDisabled, LocalDate beginDate, LocalDate endDate);

  Flux<Document> getAllDocumentsByAccountIdAndCanoeId(Long accountId, String canoeId);

  List<Document> getDocumentsByCanoeId(String canoeId);

  Optional<Document> getDocumentByCanoeIdAndAccountIdAndSecurityId(
      String canoeId, Long accountId, Long securityId);

  Flux<Document> getAllActiveDocumentsByAccountIdInAndSecurityIdAndDocDate(
      List<Long> accountIds, Long securityId, LocalDate docDate);

  Flux<Document> getAllActiveDocumentsByCustodyTransactionId(Long custodyTransactionId);

  @Query(
      "select doc from DocumentEntity doc where doc.docDate>=CURRENT_DATE and doc.isDisabled = false")
  Flux<Document> getAllActiveDocumentsForToday();

  Flux<Document> getDocumentByCreatedOnAfter(LocalDateTime createdOn);

  Flux<Document> getDocumentsBySecurityIdsIn(List<Long> securityIds);

  Flux<Document> getByAccountIdInAndSecurityIdAndDocDateAndType(
      List<Long> accountIds, Long securityId, LocalDate docDate, String type);

  Document updateDocument(
      Long documentId,
      String rawDataCloudStorageId,
      LocalDateTime rawDataModifiedOn,
      String source);

  Optional<Document> getMostRecentDocumentByCriteria(
      Long accountId, Long securityId, String canoeId, Set<String> sources);
}
