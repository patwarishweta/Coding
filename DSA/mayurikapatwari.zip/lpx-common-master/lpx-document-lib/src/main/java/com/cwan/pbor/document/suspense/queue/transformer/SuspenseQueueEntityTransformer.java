package com.cwan.pbor.document.suspense.queue.transformer;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Client;
import com.cwan.lpx.domain.Security;
import com.cwan.lpx.domain.SuspenseQueue;
import com.cwan.pbor.document.suspense.queue.SuspenseQueueEntity;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@AllArgsConstructor
public class SuspenseQueueEntityTransformer
    implements Function<SuspenseQueueEntity, SuspenseQueue> {

  @Override
  public SuspenseQueue apply(SuspenseQueueEntity suspenseQueueEntity) {
    Integer daysAgeing =
        Math.toIntExact(
            ChronoUnit.DAYS.between(
                suspenseQueueEntity.getCreatedOn(), LocalDate.now().atStartOfDay()));
    return SuspenseQueue.builder()
        .id(suspenseQueueEntity.getId())
        .canoeId(suspenseQueueEntity.getCanoeId())
        .documentName(suspenseQueueEntity.getDocumentName())
        .clientId(suspenseQueueEntity.getClientId())
        .client(Client.builder().name(suspenseQueueEntity.getClientName()).build())
        .ultimateParentId(suspenseQueueEntity.getUltimateParentId())
        .ultimateParentName(suspenseQueueEntity.getUltimateParentName())
        .originalFileName(suspenseQueueEntity.getOriginalFileName())
        .dataForgeAccount(
            Account.builder()
                .id(suspenseQueueEntity.getDataForgeAccountId())
                .name(suspenseQueueEntity.getDataForgeAccountName())
                .build())
        .canoeAccount(
            Account.builder()
                .id(suspenseQueueEntity.getCanoeAccountId())
                .name(suspenseQueueEntity.getCanoeAccountName())
                .build())
        .dataForgeSecurity(
            Security.builder()
                .securityId(suspenseQueueEntity.getDataForgeSecurityId())
                .securityName(suspenseQueueEntity.getDataForgeSecurityName())
                .build())
        .canoeSecurity(
            Security.builder()
                .securityId(suspenseQueueEntity.getCanoeSecurityId())
                .securityName(suspenseQueueEntity.getCanoeSecurityName())
                .build())
        .documentId(suspenseQueueEntity.getDocumentId())
        .s3Path(suspenseQueueEntity.getS3Path())
        .dataForgeClassification(suspenseQueueEntity.getDataForgeClassification())
        .canoeClassification(suspenseQueueEntity.getCanoeClassification())
        .finalValueSource(suspenseQueueEntity.getFinalValueSource())
        .assignedTo(suspenseQueueEntity.getAssignedTo())
        .receivedDate(suspenseQueueEntity.getReceivedDate())
        .dataDate(suspenseQueueEntity.getDataDate())
        .daysAgeing(daysAgeing)
        .notes(suspenseQueueEntity.getNotes())
        .version(suspenseQueueEntity.getVersion())
        .isCurrent(suspenseQueueEntity.getIsCurrent())
        .isDisabled(suspenseQueueEntity.getIsDisabled())
        .modifiedOn(suspenseQueueEntity.getModifiedOn())
        .modifiedBy(suspenseQueueEntity.getModifiedBy())
        .createdOn(suspenseQueueEntity.getCreatedOn())
        .createdBy(suspenseQueueEntity.getCreatedBy())
        .clientCurrentState(suspenseQueueEntity.getClientCurrentState())
        .build();
  }
}
