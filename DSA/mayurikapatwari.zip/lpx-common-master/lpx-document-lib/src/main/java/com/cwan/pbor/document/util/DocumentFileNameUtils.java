package com.cwan.pbor.document.util;

import com.cwan.lpx.domain.FileNameData;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@SuppressWarnings("unused")
@Slf4j
public final class DocumentFileNameUtils {

  private static final Pattern NON_ALPHA_NUMERIC_PATTERN = Pattern.compile("[^a-zA-Z0-9]");
  private static final Pattern LEADING_TRAILING_HYPHEN_PATTERN = Pattern.compile("^-+|-+$");
  private static final Pattern CONSECUTIVE_HYPHEN_PATTERN = Pattern.compile("-+");
  private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("MM-dd-yyyy");
  private static final String UNDERSCORE = "_";
  private static final String HYPHEN = "-";
  private static final String BLANK = "";

  public static <T extends FileNameData> String getFileName(T obj) {
    var dataDate = getDataDateOrDefault(obj);
    var account = getEntityOrDefault(obj);
    return generateFileName(
        obj.getFileType(),
        obj.getInvestment(),
        account,
        obj.getDocumentType(),
        dataDate.format(FORMATTER));
  }

  public static <T extends FileNameData> String getOldFileName(T obj) {
    var dataDate = getDataDateOrDefault(obj);
    return generateOldFileName(
        obj.getFileType(),
        obj.getInvestment(),
        obj.getAccount(),
        obj.getDocumentType(),
        dataDate.format(FORMATTER));
  }

  /**
   * Generates a sanitized file name by processing the provided components and file extension.
   * Steps: - Normalize, trim, and replace non-alphanumeric characters in components with hyphens. -
   * Remove consecutive hyphens and leading/trailing hyphens. - Join components with underscores. -
   * Sanitize the file extension, defaulting to "pdf" if blank or null. - Remove all whitespace from
   * the final file name.
   */
  private static String generateFileName(String fileExtension, String... components) {
    // Normalize, trim, and replace non-alphanumeric characters in each component
    var cleanedFileName =
        Arrays.stream(components)
            .map(StringUtils::normalizeSpace)
            .map(StringUtils::trimToNull)
            .filter(StringUtils::isNotBlank)
            .map(component -> NON_ALPHA_NUMERIC_PATTERN.matcher(component).replaceAll(HYPHEN))
            .map(component -> LEADING_TRAILING_HYPHEN_PATTERN.matcher(component).replaceAll(BLANK))
            .map(component -> CONSECUTIVE_HYPHEN_PATTERN.matcher(component).replaceAll(HYPHEN))
            .map(StringUtils::trimToNull)
            .filter(StringUtils::isNotBlank)
            .filter(component -> !StringUtils.equalsIgnoreCase(component, HYPHEN))
            .collect(Collectors.joining(UNDERSCORE));
    // Clean file extension, default to "pdf" if none provided
    var cleanedFileExtension =
        Optional.ofNullable(fileExtension)
            .map(ext -> NON_ALPHA_NUMERIC_PATTERN.matcher(ext).replaceAll(BLANK))
            .filter(StringUtils::isNotBlank)
            .orElse("pdf");
    // Combine file name and extension, remove all whitespace
    var finalFileName = StringUtils.deleteWhitespace(cleanedFileName + "." + cleanedFileExtension);
    log.info("Generated file name: {}", finalFileName);
    return finalFileName;
  }

  private static String generateOldFileName(
      String fileType, String investment, String account, String documentType, String dataDate) {
    // Just concatenates with underscores
    return (investment
            + UNDERSCORE
            + account
            + UNDERSCORE
            + documentType
            + UNDERSCORE
            + dataDate
            + fileType)
        .replace(" ", UNDERSCORE);
  }

  private static <T extends FileNameData> LocalDate getDataDateOrDefault(T obj) {
    return Objects.isNull(obj.getDataDate()) ? LocalDate.now() : obj.getDataDate();
  }

  private static <T extends FileNameData> String getEntityOrDefault(T obj) {
    var cleanedEntity = StringUtils.trimToNull(StringUtils.normalizeSpace(obj.getEntity()));
    var cleanedAccount = StringUtils.trimToNull(StringUtils.normalizeSpace(obj.getAccount()));
    return StringUtils.isNotBlank(cleanedEntity) ? cleanedEntity : cleanedAccount;
  }

  private DocumentFileNameUtils() {
    // Private constructor to prevent instantiation
  }
}
