package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationsConfigEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class MissingDocumentExpectationsConfigTransformer
    implements Function<
        MissingDocumentExpectationsConfigEntity, MissingDocumentExpectationsConfig> {

  @Override
  public MissingDocumentExpectationsConfig apply(
      MissingDocumentExpectationsConfigEntity missingDocumentExpectationsConfigEntity) {
    return MissingDocumentExpectationsConfig.builder()
        .id(missingDocumentExpectationsConfigEntity.getId())
        .securityId(missingDocumentExpectationsConfigEntity.getSecurityId())
        .fundId(missingDocumentExpectationsConfigEntity.getFundId())
        .fundName(missingDocumentExpectationsConfigEntity.getFundName())
        .documentType(missingDocumentExpectationsConfigEntity.getDocumentType())
        .frequency(missingDocumentExpectationsConfigEntity.getFrequency())
        .threshold(missingDocumentExpectationsConfigEntity.getThreshold())
        .isActive(missingDocumentExpectationsConfigEntity.getIsActive())
        .build();
  }
}
