package com.cwan.pbor.document.missing.document.repository;

import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationGroupedConfig;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationsConfigEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MissingDocumentExpectationsConfigRepository
    extends JpaRepository<MissingDocumentExpectationsConfigEntity, Long> {
  List<MissingDocumentExpectationsConfigEntity> findAllBySecurityIdIn(List<Long> securityIds);

  @Query(
      "SELECT DISTINCT e.documentType as documentType,"
          + "e.frequency as frequency,"
          + "e.threshold as threshold, "
          + "e.fundName as fundName, e.fundId as fundId, "
          + "e.isActive as isActive "
          + "FROM MissingDocumentExpectationsConfigEntity e")
  List<MissingDocumentExpectationGroupedConfig> findAllWithDistinctFundId();
}
