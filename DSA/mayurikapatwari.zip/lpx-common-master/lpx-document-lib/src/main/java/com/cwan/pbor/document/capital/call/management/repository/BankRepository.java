package com.cwan.pbor.document.capital.call.management.repository;

import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface BankRepository extends JpaRepository<BankEntity, Long> {

  List<BankEntity> findByClientId(Long clientId);

  Optional<BankEntity> findByBankUuid(String bankUuid);

  @Transactional
  @Modifying
  @Query(
      "UPDATE BankEntity b SET b.isDeleted = true, b.deletedBy = :deletedBy WHERE b.bankUuid = :bankUuid")
  int softDeleteByBankUuidAndSetDeletedBy(String bankUuid, Long deletedBy);

  boolean existsByClientIdAndAbaRoutingNumberAndSwiftChipsCode(
      Long clientId, String abaRoutingNumber, String swiftChipsCode);
}
