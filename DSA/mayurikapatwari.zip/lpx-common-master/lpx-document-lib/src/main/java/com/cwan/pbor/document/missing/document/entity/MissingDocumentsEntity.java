package com.cwan.pbor.document.missing.document.entity;

import com.cwan.lpx.domain.MissingDocumentStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "missing_documents", catalog = "pabor")
@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class MissingDocumentsEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long accountId;
  private Long securityId;
  private String fundName;
  private Long clientId;
  private String clientName;

  @Enumerated(EnumType.STRING)
  private MissingDocumentStatus documentMissingCategory;

  private String documentType;
  private LocalDate docDate;
  @CreationTimestamp private LocalDateTime createdOn;

  private Boolean flagCanoeUploaded;
  private Boolean flag;
  private LocalDate flagBeginDate;
  private LocalDate flagEndDate;
  private String flagComment;
  private String flagLastModifiedBy;
  private ZonedDateTime flagLastModifiedOn;
}
