package com.cwan.pbor.document.duplicate.repository;

import com.cwan.pbor.document.duplicate.constant.DuplicateStatus;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentDuplicateRepository extends JpaRepository<DocumentDuplicateEntity, Long> {

  @Query(
      "SELECT dd FROM DocumentDuplicateEntity dd "
          + "WHERE dd.documentId = :documentId "
          + "AND dd.isDisabled IS FALSE")
  Optional<DocumentDuplicateEntity> findActiveByDocumentId(@Param("documentId") Long documentId);

  @Query(
      "SELECT dd FROM DocumentDuplicateEntity dd "
          + "WHERE dd.documentId IN :docIds AND dd.isDisabled IS FALSE")
  Collection<DocumentDuplicateEntity> findAllActiveByDocumentIds(
      @Param("docIds") Collection<Long> docIds);

  @Query(
      "SELECT dd FROM DocumentDuplicateEntity dd "
          + "WHERE dd.documentId = :documentId "
          + "AND dd.duplicateStatus IN :statuses "
          + "AND dd.isDisabled IS FALSE "
          + "ORDER BY dd.tsModified DESC")
  Optional<DocumentDuplicateEntity> findLatestActiveByDocumentIdAndStatusIn(
      @Param("documentId") Long documentId, @Param("statuses") List<DuplicateStatus> statuses);
}
