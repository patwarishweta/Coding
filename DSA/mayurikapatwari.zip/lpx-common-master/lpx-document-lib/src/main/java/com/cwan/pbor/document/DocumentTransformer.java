package com.cwan.pbor.document;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class DocumentTransformer implements Function<DocumentEntity, Document> {

  @Override
  public Document apply(DocumentEntity documentEntity) {
    return Document.builder()
        .id(documentEntity.getId())
        .cloudStorageId(documentEntity.getCloudStorageId())
        .canoeId(documentEntity.getCanoeId())
        .fileName(documentEntity.getFileName())
        .originalFileName(documentEntity.getOriginalFileName())
        .account(Account.builder().id(documentEntity.getAccountId()).build())
        .security(Security.builder().securityId(documentEntity.getSecurityId()).build())
        .type(documentEntity.getType())
        .isAudited(documentEntity.getIsAudited())
        .source(documentEntity.getSource())
        .auditor(documentEntity.getAuditor())
        .accountingPrinciples(documentEntity.getAccountingPrinciples())
        .auditOpinionDate(documentEntity.getAuditOpinionDate())
        .auditOpinion(documentEntity.getAuditOpinion())
        .dataSource(documentEntity.getDataSource())
        .receivedDate(documentEntity.getReceivedDate())
        .documentDate(documentEntity.getDocDate())
        .cashMovementDate(documentEntity.getCashMvmtDate())
        .frequency(documentEntity.getFrequency())
        .periodStartDate(documentEntity.getPeriodStartDate())
        .periodEndDate(documentEntity.getPeriodEndDate())
        .checked(documentEntity.getChecked())
        .errorStatus(documentEntity.getErrorStatus())
        .dataForgerStatus(documentEntity.getDataForgerStatus())
        .dataForgerOutputPath(documentEntity.getDataForgerOutputPath())
        .directoryId(documentEntity.getDirectoryId())
        .isDisabled(documentEntity.getIsDisabled())
        .description(documentEntity.getDescription())
        .createdBy(documentEntity.getCreatedBy())
        .isCreatedByInternalUser(documentEntity.getIsCreatedByInternalUser())
        .createdOn(documentEntity.getCreatedOn())
        .modifiedBy(documentEntity.getModifiedBy())
        .isModifiedByInternalUser(documentEntity.getIsModifiedByInternalUser())
        .modifiedOn(documentEntity.getModifiedOn())
        .cwanGptUploaded(documentEntity.getCwanGptUploaded())
        .custodyTransactionId(documentEntity.getCustodyTransactionId())
        .assigneeId(documentEntity.getAssigneeId())
        .assigneeName(documentEntity.getAssigneeName())
        .assigneeEmail(documentEntity.getAssigneeEmail())
        .rawDataCloudStorageId(documentEntity.getRawDataCloudStorageId())
        .rawDataModifiedOn(documentEntity.getRawDataModifiedOn())
        .build();
  }
}
