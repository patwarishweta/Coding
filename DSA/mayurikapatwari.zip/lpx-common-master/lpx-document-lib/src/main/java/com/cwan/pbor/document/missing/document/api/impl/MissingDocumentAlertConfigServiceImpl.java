package com.cwan.pbor.document.missing.document.api.impl;

import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.pbor.document.missing.document.api.MissingDocumentAlertConfigService;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentAlertConfigEntity;
import com.cwan.pbor.document.missing.document.repository.MissingDocumentAlertConfigRepository;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentAlertConfigEntityTransformer;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentAlertConfigTransformer;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class MissingDocumentAlertConfigServiceImpl implements MissingDocumentAlertConfigService {

  private MissingDocumentAlertConfigRepository missingDocumentAlertConfigRepository;
  private MissingDocumentAlertConfigTransformer missingDocumentAlertConfigTransformer;
  private MissingDocumentAlertConfigEntityTransformer missingDocumentAlertConfigEntityTransformer;

  @Override
  public List<MissingDocumentAlertConfig> getAllMissingDocumentAlertConfigByClientIdIn(
      List<Long> clientIds) {
    return missingDocumentAlertConfigRepository.findAllByClientIdIn(clientIds).stream()
        .map(missingDocumentAlertConfigTransformer)
        .toList();
  }

  @Override
  public Flux<MissingDocumentAlertConfig> addMissingDocumentAlertConfig(
      Set<MissingDocumentAlertConfig> missingDocumentAlertConfigs) {
    missingDocumentAlertConfigs.stream()
        .filter(doc -> doc.getId() != null)
        .forEach(
            doc ->
                log.warn(
                    "MissingDocumentAlertConfig with Id {} can't be added Id should be null.",
                    doc.getId()));
    return Flux.fromIterable(missingDocumentAlertConfigs)
        .filter(doc -> doc.getId() == null)
        .filter(Objects::nonNull)
        .map(missingDocumentAlertConfigEntityTransformer)
        .map(this::saveMissingDocumentAlertConfig)
        .map(missingDocumentAlertConfigTransformer);
  }

  private MissingDocumentAlertConfigEntity saveMissingDocumentAlertConfig(
      MissingDocumentAlertConfigEntity missingDocumentAlertConfigEntity) {
    return missingDocumentAlertConfigRepository.saveAndFlush(missingDocumentAlertConfigEntity);
  }
}
