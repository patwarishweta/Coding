package com.cwan.pbor.document.suspense.queue;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Table(name = "suspense_queue", catalog = "pabor")
@Data
@Builder
@Entity
public class SuspenseQueueEntity implements Serializable {

  @Serial private static final long serialVersionUID = 5977403601863539989L;

  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private Long id;

  private String canoeId;

  private Integer version;
  private String documentName;
  private Long clientId;
  private String clientName;
  private String originalFileName;
  private Long ultimateParentId;
  private String ultimateParentName;
  private Long canoeAccountId;
  private String canoeAccountName;
  private Long dataForgeAccountId;
  private String dataForgeAccountName;
  private Long canoeSecurityId;
  private String canoeSecurityName;
  private Long dataForgeSecurityId;
  private String dataForgeSecurityName;
  private Long documentId;

  @Column(name = "s3_path")
  private String s3Path;

  private String canoeClassification;
  private String dataForgeClassification;
  private String finalValueSource;

  private String assignedTo;
  private LocalDate receivedDate;
  private LocalDate dataDate;
  private String createdBy;
  private LocalDateTime createdOn;
  private String modifiedBy;
  private LocalDateTime modifiedOn;
  private Boolean isCurrent;
  private Boolean isDisabled;
  private String notes;
  private String clientCurrentState;
}
