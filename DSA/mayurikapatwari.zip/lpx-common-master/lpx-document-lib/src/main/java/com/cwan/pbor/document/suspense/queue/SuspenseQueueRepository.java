package com.cwan.pbor.document.suspense.queue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface SuspenseQueueRepository extends JpaRepository<SuspenseQueueEntity, Long> {

  @Query(
      "SELECT sq FROM SuspenseQueueEntity sq WHERE sq.createdOn BETWEEN :startDate AND :endDate "
          + "AND (sq.dataForgeClassification IN :documentTypes OR sq.dataForgeClassification IS NULL "
          + "OR sq.canoeClassification IN :documentTypes) "
          + "AND (sq.isCurrent IS TRUE AND sq.isDisabled is false)")
  List<SuspenseQueueEntity> findByCreatedOnBetweenAndDocumentTypeInOrDocumentTypeIsNull(
      @Param("startDate") LocalDateTime startDate,
      @Param("endDate") LocalDateTime endDate,
      @Param("documentTypes") List<String> documentTypes);

  @Query(
      "SELECT sq FROM SuspenseQueueEntity sq WHERE sq.createdOn BETWEEN :startDate AND :endDate "
          + "AND (sq.dataForgeClassification not in :documentTypes)"
          + "AND (sq.canoeClassification not in :documentTypes)"
          + "AND (sq.isCurrent is true AND sq.isDisabled is false)")
  List<SuspenseQueueEntity> findByCreatedOnBetweenAndDocumentTypeNotIn(
      LocalDateTime startDate, LocalDateTime endDate, List<String> documentTypes);

  SuspenseQueueEntity findByDocumentIdAndIsCurrent(Long id, Boolean isCurrent);

  @Query(
      "SELECT sq from SuspenseQueueEntity sq where sq.documentId IN :ids AND sq.isCurrent IS TRUE")
  List<SuspenseQueueEntity> findAllByDocumentIdInAndIsCurrent(Set<Long> ids);

  @Modifying
  @Query(
      "UPDATE SuspenseQueueEntity sq "
          + "SET sq.isCurrent = false, sq.modifiedBy = :modifiedBy, sq.modifiedOn = :modifiedOn "
          + "WHERE sq.documentId IN :ids AND sq.isCurrent = true")
  @Transactional
  void updateSuspenseQueueEntities(
      @Param("ids") List<Long> ids,
      @Param("modifiedBy") String modifiedBy,
      @Param("modifiedOn") LocalDateTime modifiedOn);

  @Query(
      "SELECT sq FROM SuspenseQueueEntity sq WHERE sq.createdOn BETWEEN :startDate AND :endDate "
          + "AND (:ultimateParentIds IS NULL OR sq.ultimateParentId IN (:ultimateParentIds))")
  List<SuspenseQueueEntity> findAllByCreatedOnBetweenAndUltimateParentIdsIn(
      LocalDateTime startDate, LocalDateTime endDate, List<Long> ultimateParentIds);
}
