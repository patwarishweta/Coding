package com.cwan.pbor.document.duplicate.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@DynamicInsert
@DynamicUpdate
@Table(
    name = "document_duplicate_ext",
    catalog = "pabor",
    uniqueConstraints = {
      @UniqueConstraint(
          name = "unique_duplicate",
          columnNames = {"document_duplicate_id", "canoe_id"})
    })
@SQLDelete(sql = "UPDATE pabor.document_duplicate_ext SET is_disabled = true WHERE id = ?")
@SQLRestriction("is_disabled = false")
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(builderClassName = "DocumentDuplicateExtEntityBuilder", toBuilder = true)
public class DocumentDuplicateExtEntity {

  @SuppressWarnings("unused")
  public static class DocumentDuplicateExtEntityBuilder {

    public DocumentDuplicateExtEntityBuilder canoeId(String canoeId) {
      this.canoeId = StringUtils.trimToNull(canoeId);
      return this;
    }

    public DocumentDuplicateExtEntityBuilder cloudStorageId(String cloudStorageId) {
      this.cloudStorageId = StringUtils.trimToNull(cloudStorageId);
      return this;
    }

    public DocumentDuplicateExtEntityBuilder rawDataCloudStorageId(String rawDataCloudStorageId) {
      this.rawDataCloudStorageId = StringUtils.trimToNull(rawDataCloudStorageId);
      return this;
    }
  }

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "document_duplicate_id", nullable = false)
  private Long documentDuplicateId;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(
      name = "document_duplicate_id",
      referencedColumnName = "id",
      insertable = false,
      updatable = false)
  private DocumentDuplicateEntity documentDuplicateEntity;

  @Column(name = "canoe_id", length = 170, nullable = false)
  private String canoeId;

  @Column(name = "cloud_storage_id", length = 510, nullable = false)
  private String cloudStorageId;

  @Column(name = "raw_data_cloud_storage_id", length = 510, nullable = false)
  private String rawDataCloudStorageId;

  @Column(name = "raw_data_modified_on", nullable = false)
  private LocalDateTime rawDataModifiedOn;

  @Column(name = "is_current", nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
  @Builder.Default
  private boolean isCurrent = false;

  @Column(name = "is_disabled", nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
  @Builder.Default
  private boolean isDisabled = false;

  @Column(name = "ts_created", nullable = false, updatable = false)
  private LocalDateTime tsCreated;

  @UpdateTimestamp
  @Column(name = "ts_modified", nullable = false)
  private LocalDateTime tsModified;
}
