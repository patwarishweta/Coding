package com.cwan.pbor.document.capital.call.transformer;

import static com.cwan.lpx.domain.CapitalCallStatus.NOT_SPECIFIED;

import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.pbor.document.capital.call.entity.CapitalCallAuditEntity;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.springframework.stereotype.Component;

@Component
public class CapitalCallAuditTransformer {

  public CapitalCallAuditLog apply(Long documentId, List<CapitalCallAuditEntity> entities) {
    var filteredEntities =
        entities.stream()
            .filter(entity -> Objects.equals(documentId, entity.getDocumentId()))
            .sorted(
                Comparator.comparing(
                    CapitalCallAuditEntity::getTimestamp,
                    Comparator.nullsFirst(Comparator.naturalOrder())))
            .toList();
    return CapitalCallAuditLog.builder()
        .documentId(documentId)
        .audit(
            IntStream.range(0, filteredEntities.size())
                .mapToObj(i -> buildAudit(filteredEntities, i))
                .collect(
                    Collectors.collectingAndThen(
                        Collectors.toList(), Collections::unmodifiableList)))
        .build();
  }

  private CapitalCallAudit buildAudit(List<CapitalCallAuditEntity> entities, int index) {
    var currentEntity = entities.get(index);
    CapitalCallStatus previousStatus =
        index == 0 ? NOT_SPECIFIED : entities.get(index - 1).getStatus();
    return CapitalCallAudit.builder()
        .previousStatus(previousStatus)
        .action(currentEntity.getAction())
        .nextStatus(currentEntity.getStatus())
        .timestamp(currentEntity.getTimestamp())
        .comment(currentEntity.getComment())
        .user(
            CapitalCallUser.builder()
                .id(currentEntity.getUserId())
                .fullName(currentEntity.getUserFullName())
                .email(currentEntity.getUserEmail())
                .build())
        .build();
  }
}
