package com.cwan.pbor.document.missing.document.transformer;

import com.cwan.pbor.document.missing.document.MissingDocumentException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Converter
@Component
@AllArgsConstructor
public class StringListConverter implements AttributeConverter<List<String>, String> {
  private ObjectMapper objectMapper;

  @Override
  public String convertToDatabaseColumn(List<String> attribute) {
    try {
      return objectMapper.writeValueAsString(attribute);
    } catch (Exception e) {
      throw new MissingDocumentException(
          HttpStatus.BAD_REQUEST,
          "Error converting List<String> to JSON string: " + e.getMessage());
    }
  }

  @Override
  public List<String> convertToEntityAttribute(String dbData) {
    try {
      return objectMapper.readValue(dbData, new TypeReference<List<String>>() {});
    } catch (Exception e) {
      throw new MissingDocumentException(
          HttpStatus.INTERNAL_SERVER_ERROR,
          "Error converting JSON string to List<String>: " + e.getMessage());
    }
  }
}
