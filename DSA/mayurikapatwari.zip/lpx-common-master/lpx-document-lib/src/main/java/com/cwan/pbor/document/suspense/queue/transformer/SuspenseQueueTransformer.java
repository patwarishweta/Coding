package com.cwan.pbor.document.suspense.queue.transformer;

import com.cwan.lpx.domain.SuspenseQueue;
import com.cwan.pbor.document.suspense.queue.SuspenseQueueEntity;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@AllArgsConstructor
public class SuspenseQueueTransformer implements Function<SuspenseQueue, SuspenseQueueEntity> {

  @Override
  public SuspenseQueueEntity apply(SuspenseQueue suspenseQueue) {
    return SuspenseQueueEntity.builder()
        .id(suspenseQueue.getId())
        .canoeId(suspenseQueue.getCanoeId())
        .version(suspenseQueue.getVersion())
        .documentName(suspenseQueue.getDocumentName())
        .originalFileName(suspenseQueue.getOriginalFileName())
        .clientId(suspenseQueue.getClientId())
        .clientName(suspenseQueue.getClient().getName())
        .ultimateParentId(suspenseQueue.getUltimateParentId())
        .ultimateParentName(suspenseQueue.getUltimateParentName())
        .dataForgeAccountId(suspenseQueue.getDataForgeAccount().getId())
        .dataForgeAccountName(suspenseQueue.getDataForgeAccount().getName())
        .canoeAccountId(suspenseQueue.getCanoeAccount().getId())
        .canoeAccountName(suspenseQueue.getCanoeAccount().getName())
        .dataForgeSecurityId(suspenseQueue.getDataForgeSecurity().getSecurityId())
        .dataForgeSecurityName(suspenseQueue.getDataForgeSecurity().getSecurityName())
        .canoeSecurityId(suspenseQueue.getCanoeSecurity().getSecurityId())
        .canoeSecurityName(suspenseQueue.getCanoeSecurity().getSecurityName())
        .documentId(suspenseQueue.getDocumentId())
        .s3Path(suspenseQueue.getS3Path())
        .dataForgeClassification(suspenseQueue.getDataForgeClassification())
        .canoeClassification(suspenseQueue.getCanoeClassification())
        .finalValueSource(suspenseQueue.getFinalValueSource())
        .assignedTo(suspenseQueue.getAssignedTo())
        .receivedDate(suspenseQueue.getReceivedDate())
        .dataDate(suspenseQueue.getDataDate())
        .notes(suspenseQueue.getNotes())
        .isCurrent(suspenseQueue.getIsCurrent())
        .isDisabled(suspenseQueue.getIsDisabled())
        .modifiedOn(suspenseQueue.getModifiedOn())
        .modifiedBy(suspenseQueue.getModifiedBy())
        .createdOn(suspenseQueue.getCreatedOn())
        .createdBy(suspenseQueue.getCreatedBy())
        .clientCurrentState(suspenseQueue.getClientCurrentState())
        .build();
  }
}
