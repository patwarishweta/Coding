package com.cwan.pbor.document.capital.call.service;

import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.ServiceConstants.DOCUMENT_TYPE_CAPITAL_CALL_NOTICE;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.capital.call.api.CapitalCalls;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import com.cwan.pbor.document.capital.call.entity.CapitalCallAuditEntity;
import com.cwan.pbor.document.capital.call.entity.CapitalCallDocumentEntity;
import com.cwan.pbor.document.capital.call.repository.CapitalCallAuditRepository;
import com.cwan.pbor.document.capital.call.repository.CapitalCallDocumentRepository;
import com.cwan.pbor.document.capital.call.transformer.CapitalCallAuditTransformer;
import com.cwan.pbor.document.capital.call.transformer.CapitalCallDocumentTransformer;
import com.cwan.pbor.document.capital.call.util.CapitalCallStatusTransitionUtil;
import com.cwan.pbor.document.capital.call.validator.CapitalCallAuditActionValidator;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/**
 * Service class for Capital Call related operations. This class uses {@link
 * CapitalCallAuditRepository} for database operations and {@link CapitalCallDocumentTransformer} to
 * convert database objects to {@link CapitalCallDocument} instances.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CapitalCallService implements CapitalCalls {

  private final CapitalCallAuditRepository capitalCallAuditRepository;
  private final CapitalCallDocumentRepository capitalCallDocumentRepository;
  private final CapitalCallDocumentTransformer capitalCallDocumentTransformer;
  private final CapitalCallAuditTransformer capitalCallAuditTransformer;

  /**
   * Fetches capital calls related to the given set of account IDs and within the specified date
   * range, then filters them based on the given set of statuses. The date range filtering is
   * applied based on the provided date filter type, either on the call received date or the due
   * date. If the provided set of statuses is empty, the method returns capital calls for the
   * specified accounts regardless of their status.
   *
   * @param dateFilterType The type of date filter to apply, either call received date or due date.
   * @param startDate The starting date for filtering capital calls.
   * @param endDate The ending date for filtering capital calls.
   * @param accountIds The set of account IDs for which to fetch capital calls.
   * @param statuses The set of capital call statuses to filter the results by. If empty, results
   *     will not be filtered by status.
   * @return A Flux of {@link CapitalCallDocument} instances.
   */
  @Override
  public Flux<CapitalCallDocument> getCapitalCallsByAccounts(
      CapitalCallDateFilterType dateFilterType,
      LocalDate startDate,
      LocalDate endDate,
      Set<Long> accountIds,
      Set<CapitalCallStatus> statuses) {
    if (Objects.isNull(accountIds) || accountIds.isEmpty()) {
      log.warn("Account IDs are null or empty. No capital calls will be fetched.");
      return Flux.empty();
    }
    log.info(
        "Initiating fetch for capital calls with accountIds: {} and statuses: {}.",
        accountIds,
        statuses);
    var capitalCallDocumentEntities =
        switch (dateFilterType) {
          case RECEIVED_DATE ->
              capitalCallDocumentRepository.findByCallReceivedDateBetweenAndAccountIdIn(
                  startDate, endDate, accountIds);
          case DUE_DATE ->
              capitalCallDocumentRepository.findByDueDateBetweenAndAccountIdIn(
                  startDate, endDate, accountIds);
        };
    return processCapitalCallEntities(capitalCallDocumentEntities, statuses);
  }

  /**
   * Fetches all capital calls from the database that match the given statuses. If no statuses are
   * provided, it will fetch all capital calls without any status filtering.
   *
   * @param statuses A set of {@link CapitalCallStatus} instances representing desired capital call
   *     statuses.
   * @return Flux of {@link CapitalCallDocument} instances matching the given statuses or all
   *     capital calls if no statuses are provided.
   */
  @Override
  public Flux<CapitalCallDocument> getCapitalCallsByStatuses(Set<CapitalCallStatus> statuses) {
    log.info("Initiating fetch for capital calls with statuses: {}.", statuses);
    return processCapitalCallEntities(capitalCallDocumentRepository.findAll(), statuses);
  }

  /**
   * Creates a capital call if the document entity is not null, has a non-null id, and its type is
   * "Capital Call Notice". The new capital call has status "NEW_CAPITAL_CALL" and userId -1. The
   * method is transactional, meaning that it won't affect the database if there's an error during
   * the operation.
   *
   * @param documentEntity The document entity from which to create the capital call.
   */
  @Transactional
  public void createCapitalCall(DocumentEntity documentEntity, boolean isNewDocument) {
    if (isNewDocument
        && Objects.nonNull(documentEntity)
        && Objects.nonNull(documentEntity.getId())
        && StringUtils.equalsIgnoreCase(
            DOCUMENT_TYPE_CAPITAL_CALL_NOTICE, documentEntity.getType())) {
      var info = "Capital Call record for Document ID: " + documentEntity.getId() + " created.";
      var capitalCallEntity =
          CapitalCallAuditEntity.builder()
              .documentId(documentEntity.getId())
              .action(CapitalCallAction.APPROVE)
              .status(CapitalCallStatus.NEW_CAPITAL_CALL)
              .comment(info)
              .userId(SystemUserConstants.ID)
              .userFullName(SystemUserConstants.FULL_NAME)
              .userEmail(SystemUserConstants.EMAIL)
              .build();
      capitalCallAuditRepository.saveAndFlush(capitalCallEntity);
      log.info(info);
    }
  }

  /**
   * This method updates the status of a Capital Call in the database. It first checks if the
   * requested action can be performed based on the current status of the Capital Call, and if so,
   * it creates a new status, saves the updated Capital Call in the database, and returns the
   * updated object.
   *
   * @return A Mono of {@link CapitalCallDocument} instances.
   */
  @Override
  @Modifying
  @Transactional
  public Mono<CapitalCallDocument> updateCapitalCallStatus(
      CapitalCallAuditAction capitalCallAuditAction, CapitalCallAction capitalCallAction) {
    log.info(
        "Starting process to update CapitalCall status for document ID: {}",
        capitalCallAuditAction.documentId());
    return CapitalCallAuditActionValidator.validateCapitalCallAuditAction(capitalCallAuditAction)
        .map(
            validationError ->
                Mono.<CapitalCallDocument>error(new IllegalArgumentException(validationError)))
        .orElseGet(
            () ->
                Mono.fromCallable(
                        () -> getCapitalCallAuditEntity(capitalCallAuditAction.documentId()))
                    .flatMap(
                        currentCapitalCall ->
                            processCurrentCapitalCall(
                                currentCapitalCall, capitalCallAuditAction, capitalCallAction)));
  }

  /**
   * Fetches the CapitalCallAudit by document ID and wraps the results in a Mono.
   *
   * @param documentId the ID of the document for which the audit is to be retrieved.
   * @return Mono of CapitalCallAuditLog containing the audit history of the provided document.
   */
  @Override
  public Mono<CapitalCallAuditLog> getCapitalCallAuditByDocument(Long documentId) {
    if (Objects.isNull(documentId)) {
      return Mono.error(new IllegalArgumentException("Document ID cannot be null."));
    }
    return Mono.fromCallable(
            () ->
                capitalCallAuditRepository.findByDocumentIdInOrderByTimestamp(List.of(documentId)))
        .flatMapIterable(Function.identity())
        .collectList()
        .map(
            capitalCallAuditEntities ->
                capitalCallAuditTransformer.apply(documentId, capitalCallAuditEntities))
        .onErrorResume(
            e -> {
              log.error("Error processing document with ID {}", documentId, e);
              return Mono.error(
                  new RuntimeException(
                      String.format(
                          "Error getting capital call audit for document having ID %s", documentId),
                      e));
            });
  }

  /**
   * Inserts any missed capital call records into the database. This method is exclusively invoked
   * by a scheduler to ensure data consistency and completeness. Note: This is a preventive and
   * corrective method to ensure no capital call records are unintentionally skipped or missed due
   * to transient system errors or disruptions.
   */
  @Override
  public Mono<Integer> insertMissedCapitalCalls() {
    try {
      log.info("Initiating insert for any missed capital calls.");
      var rowsInserted = capitalCallAuditRepository.insertMissedCapitalCalls();
      if (rowsInserted > 0) {
        log.info("Successfully inserted {} missed capital calls.", rowsInserted);
      } else {
        log.info("No missed capital calls found to be inserted.");
      }
      return Mono.just(rowsInserted);
    } catch (Exception e) {
      log.error("Error during insert of missed capital calls.", e);
      return Mono.error(e);
    }
  }

  /**
   * Fetches capital calls related to the given document ID.
   *
   * @param documentId Document ID for which to fetch capital call.
   * @return Mono of {@link CapitalCallDocument} instances.
   */
  @Override
  public Mono<CapitalCallDocument> getCapitalCallByDocument(Long documentId) {
    if (Objects.isNull(documentId)) {
      return Mono.error(new IllegalArgumentException("Document ID cannot be null."));
    }
    return Mono.fromCallable(() -> capitalCallDocumentRepository.findById(documentId))
        .publishOn(Schedulers.boundedElastic())
        .flatMap(entity -> entity.map(Mono::just).orElseGet(Mono::empty))
        .flatMap(
            entity ->
                getCapitalCallAuditByDocument(entity.getDocumentId())
                    .map(auditLog -> capitalCallDocumentTransformer.apply(entity, auditLog)));
  }

  Flux<CapitalCallDocument> processCapitalCallEntities(
      List<CapitalCallDocumentEntity> capitalCallEntities, Set<CapitalCallStatus> statuses) {
    Set<CapitalCallStatus> effectiveStatuses =
        Objects.isNull(statuses) ? Collections.emptySet() : statuses;
    if (capitalCallEntities.isEmpty()) {
      log.warn("No capital calls were fetched for statuses: {}.", effectiveStatuses);
      return Flux.empty();
    }
    log.debug(
        "Fetched {} capital call entities for statuses: {}",
        capitalCallEntities.size(),
        effectiveStatuses);
    return fetchAuditsForDocumentIds(
            capitalCallEntities.stream()
                .map(CapitalCallDocumentEntity::getDocumentId)
                .collect(Collectors.toSet()))
        .flatMapMany(
            auditsMap ->
                transformEntitiesToDocuments(capitalCallEntities, auditsMap, effectiveStatuses))
        .doOnTerminate(
            () ->
                log.info("Completed fetch for capital calls with statuses: {}.", effectiveStatuses))
        .doOnError(
            error ->
                log.error(
                    "Error fetching capital calls for statuses: {}", effectiveStatuses, error));
  }

  Mono<Map<Long, CapitalCallAuditLog>> fetchAuditsForDocumentIds(Set<Long> documentIds) {
    if (Objects.isNull(documentIds) || documentIds.isEmpty()) {
      return Mono.error(new IllegalArgumentException("Document IDs cannot be null or empty."));
    }
    return Flux.fromIterable(documentIds)
        .buffer(500)
        .flatMap(
            ids ->
                Flux.fromIterable(
                    capitalCallAuditRepository.findByDocumentIdInOrderByTimestamp(ids)))
        .collectList()
        .map(
            entities ->
                entities.stream()
                    .collect(Collectors.groupingBy(CapitalCallAuditEntity::getDocumentId))
                    .entrySet()
                    .stream()
                    .collect(
                        Collectors.toMap(
                            Entry::getKey,
                            entry ->
                                capitalCallAuditTransformer.apply(entry.getKey(), entry.getValue()),
                            (a, b) -> b)))
        .onErrorResume(
            e -> {
              var errorMessage =
                  String.format(
                      "Error getting capital call audits for documents having IDs %s", documentIds);
              log.error(errorMessage, e);
              return Mono.error(new RuntimeException(errorMessage, e));
            });
  }

  Flux<CapitalCallDocument> transformEntitiesToDocuments(
      List<CapitalCallDocumentEntity> entities,
      Map<Long, CapitalCallAuditLog> auditsMap,
      Set<CapitalCallStatus> statuses) {
    return Flux.fromIterable(entities)
        .flatMap(
            entity ->
                Mono.justOrEmpty(
                    capitalCallDocumentTransformer.apply(
                        entity, auditsMap.get(entity.getDocumentId()))))
        .filter(
            document -> Objects.nonNull(document.status()) && statuses.contains(document.status()))
        .sort(Comparator.comparing(CapitalCallDocument::documentId).reversed());
  }

  private CapitalCallAuditEntity getCapitalCallAuditEntity(Long documentId) {
    log.debug("Fetching latest CapitalCallAuditEntity for document ID: {}", documentId);
    return capitalCallAuditRepository
        .findFirstByDocumentIdOrderByTimestampDesc(documentId)
        .orElseThrow(
            () -> {
              log.error("Document ID not found: {}", documentId);
              return new RuntimeException("Document id not found");
            });
  }

  private Mono<CapitalCallDocument> processCurrentCapitalCall(
      CapitalCallAuditEntity currentCapitalCall,
      CapitalCallAuditAction capitalCallAuditAction,
      CapitalCallAction capitalCallAction) {
    if (capitalCallAuditAction.currentStatus() != currentCapitalCall.getStatus()) {
      log.error(
          "The status you are viewing is outdated. The current status is: {}",
          currentCapitalCall.getStatus());
      return Mono.error(
          new IllegalStateException(
              "The status you are viewing is outdated. Please refresh to see the updated status."));
    }
    var newStatus =
        CapitalCallStatusTransitionUtil.getNewStatus(
            currentCapitalCall.getStatus(), capitalCallAction);
    if (Objects.isNull(newStatus)) {
      log.error(
          "No valid transition found for status: {} and action: {}",
          currentCapitalCall.getStatus(),
          capitalCallAction);
      return Mono.error(
          new IllegalStateException("No actions can be performed on the current status"));
    }
    log.debug("Processing CapitalCallAuditEntity with status: {}", currentCapitalCall.getStatus());
    var newCapitalCall =
        createNewCapitalCallAuditEntity(capitalCallAuditAction, capitalCallAction, newStatus);
    log.info(
        "Action performed: {}, Old status: {}, Saving new CapitalCallAuditEntity with new status: {}",
        capitalCallAction,
        currentCapitalCall.getStatus(),
        newStatus);
    capitalCallAuditRepository.saveAndFlush(newCapitalCall);
    var documentId = capitalCallAuditAction.documentId();
    log.debug("Fetching CapitalCallDocument for document ID: {}", documentId);
    return findCapitalCallDocument(documentId);
  }

  private Mono<CapitalCallDocument> findCapitalCallDocument(Long documentId) {
    return Mono.fromCallable(() -> capitalCallDocumentRepository.findById(documentId))
        .publishOn(Schedulers.boundedElastic())
        .flatMap(entity -> entity.map(Mono::just).orElseGet(Mono::empty))
        .flatMap(
            entity ->
                getCapitalCallAuditByDocument(entity.getDocumentId())
                    .map(auditLog -> capitalCallDocumentTransformer.apply(entity, auditLog)));
  }

  private CapitalCallAuditEntity createNewCapitalCallAuditEntity(
      CapitalCallAuditAction capitalCallAuditAction,
      CapitalCallAction action,
      CapitalCallStatus newStatus) {
    log.debug("Creating new CapitalCallAuditEntity with status: {}", newStatus);
    return CapitalCallAuditEntity.builder()
        .documentId(capitalCallAuditAction.documentId())
        .action(action)
        .status(newStatus)
        .comment(capitalCallAuditAction.comment())
        .userId(capitalCallAuditAction.user().id())
        .userFullName(capitalCallAuditAction.user().fullName())
        .userEmail(capitalCallAuditAction.user().email())
        .build();
  }
}
