package com.cwan.pbor.document.capital.call.management.repository;

import com.cwan.pbor.document.capital.call.management.entity.BankBlacklistEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface BankBlacklistRepository extends JpaRepository<BankBlacklistEntity, Long> {

  @Query("SELECT bb FROM BankBlacklistEntity bb JOIN bb.bank b WHERE b.clientId = :clientId")
  List<BankBlacklistEntity> findByClientId(Long clientId);

  Optional<BankBlacklistEntity> findByBankBlacklistUuid(String bankBlacklistUuid);

  @Transactional
  @Modifying
  @Query(
      "UPDATE BankBlacklistEntity bb SET bb.isDeleted = true, bb.deletedBy = :deletedBy WHERE bb.bankBlacklistUuid = :bankBlacklistUuid")
  int softDeleteByBankBlacklistUuidAndSetDeletedBy(String bankBlacklistUuid, Long deletedBy);

  boolean existsByBankId(Long bankId);
}
