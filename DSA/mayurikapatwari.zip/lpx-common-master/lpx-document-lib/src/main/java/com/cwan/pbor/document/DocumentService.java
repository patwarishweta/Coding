package com.cwan.pbor.document;

import static java.util.stream.Collectors.toMap;

import com.cwan.lpx.domain.Document;
import com.cwan.pbor.document.api.Documents;
import com.cwan.pbor.document.capital.call.service.CapitalCallService;
import jakarta.persistence.EntityNotFoundException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Service
@Slf4j
public class DocumentService implements Documents {

  private DocumentRepository documentRepository;
  private DocumentEntityTransformer documentEntityTransformer;
  private DocumentTransformer documentTransformer;
  private CapitalCallService capitalCallService;

  public DocumentService() {}

  @Autowired
  DocumentService(
      final DocumentRepository documentRepository,
      final DocumentEntityTransformer documentEntityTransformer,
      final DocumentTransformer documentTransformer,
      final CapitalCallService capitalCallService) {
    this.documentRepository = documentRepository;
    this.documentEntityTransformer = documentEntityTransformer;
    this.documentTransformer = documentTransformer;
    this.capitalCallService = capitalCallService;
  }

  @Override
  public Flux<Document> addDocuments(final Set<Document> documents) {
    documents.stream()
        .filter(doc -> doc.getId() != null)
        .forEach(
            doc -> log.warn("document with Id {} can't be added Id should be null.", doc.getId()));
    return Flux.fromIterable(documents)
        .filter(doc -> doc.getId() == null)
        .filter(Objects::nonNull)
        .map(documentEntityTransformer)
        .map(this::saveDocument)
        .map(
            documentEntity -> {
              log.info("Document saved in pabor db with id {}", documentEntity.getId());
              return documentTransformer.apply(documentEntity);
            });
  }

  @Override
  @Transactional
  public Flux<Document> getDocumentsByAccountAndDate(
      final Set<Long> accountIds, LocalDate documentDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndDocDateEqualsAndIsDisabledFalse(
                accountIds, documentDate))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsByAccountId(final Set<Long> accountIds) {
    return Flux.fromIterable(documentRepository.findAllByAccountIdIn(accountIds))
        .map(documentTransformer);
  }

  @Override
  public Mono<Document> getDocumentById(Long id) {
    return Mono.just(
        documentTransformer.apply(
            documentRepository
                .findById(id)
                .orElseThrow(
                    () ->
                        new DocumentException(
                            HttpStatus.NOT_FOUND, "No document found with id " + id))));
  }

  @Override
  public Flux<Document> getDocumentsByAccountIdAndFileNameAndReceivedDate(
      Long accountId, String fileName, LocalDate receivedDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdAndFileNameAndReceivedDateAndIsDisabledFalse(
                accountId, fileName, receivedDate))
        .map(documentTransformer);
  }

  @Override
  public Map<String, LocalDate> getLatestStatementDatesMapBeforeOrEqualProvidedDate(
      List<Long> accountIds, LocalDate providedDate) {
    List<Object[]> results =
        documentRepository.findLatestStatementDatesByAccountAndSecurity(accountIds, providedDate);
    Map<String, LocalDate> latestStatementDatesMap = new HashMap<>();
    results.forEach(
        result -> {
          Number accountIdNumber = (Number) result[0];
          Number securityIdNumber = (Number) result[1];
          LocalDate statementDate = (LocalDate) result[2];
          if ((accountIdNumber == null) || (securityIdNumber == null)) {
            log.error(
                "Skipping entry due to null accountId or securityId: accountId={}, securityId={}",
                accountIdNumber,
                securityIdNumber);
            return;
          }
          long accountId = accountIdNumber.longValue();
          long securityId = securityIdNumber.longValue();
          if ((accountId == 0L) || (securityId == 0L)) {
            log.error(
                "Skipping entry due to zero value in accountId or securityId: accountId={}, securityId={}",
                accountId,
                securityId);
            return;
          }
          String key = accountId + "-" + securityId;
          latestStatementDatesMap.put(key, statementDate);
        });
    return latestStatementDatesMap;
  }

  @Override
  public Flux<Document> getDocumentByFileName(final String fileName) {
    return Flux.fromIterable(documentRepository.findTop1ByFileNameAndIsDisabledFalse(fileName))
        .map(documentTransformer);
  }

  @Override
  @Transactional
  public Flux<Document> updateDocumentInfo(final Set<Document> documents) {
    var idToDocumentMap =
        documents.stream().collect(toMap(Document::getId, documentEntityTransformer));
    var requestedDocumentIds = new HashSet<>(idToDocumentMap.keySet());
    return findAllByIds(requestedDocumentIds)
        .log("updateDocumentInfo")
        .filter(document -> requestedDocumentIds.remove(document.getId()))
        .mapNotNull(
            document -> {
              var documentEntity = idToDocumentMap.get(document.getId());
              documentEntity.setRawDataCloudStorageId(document.getRawDataCloudStorageId());
              documentEntity.setRawDataModifiedOn(document.getRawDataModifiedOn());
              documentEntity.setSource(document.getSource());
              return documentEntity;
            })
        .mapNotNull(this::saveDocument)
        .mapNotNull(documentTransformer)
        .doOnComplete(
            () ->
                requestedDocumentIds.forEach(
                    documentId ->
                        log.info(
                            "Could not update document id: {} because it does not exist.",
                            documentId)));
  }

  @Override
  public Flux<Document> getDocumentsByAccountsAndReceivedDateBetween(
      final Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndReceivedDateIsBetweenAndIsDisabledFalse(
                accountIds, beginDate, endDate))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsByAccountsAndReceivedDateBetweenAndTypes(
      final Set<Long> accountIds, LocalDate beginDate, LocalDate endDate, List<String> types) {
    return Flux.fromIterable(
            documentRepository
                .findAllByAccountIdInAndReceivedDateIsBetweenAndTypeInAndIsDisabledFalse(
                    accountIds, beginDate, endDate, types))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsByAccountsAndDocumentDateBetween(
      final Set<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndDocDateIsBetweenAndIsDisabledFalse(
                accountIds, beginDate, endDate))
        .map(documentTransformer);
  }

  @Transactional(readOnly = true)
  @Override
  public Flux<Document> getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
      Collection<Long> accountIds,
      Collection<Long> securityIds,
      LocalDate beginDate,
      LocalDate endDate,
      Collection<String> excludedSources) {
    if (!areActiveDocumentSearchParamsValid(accountIds, beginDate, endDate)) {
      log.warn(
          "Invalid input: accountIds={}, dateRange={} to {}",
          CollectionUtils.isEmpty(accountIds) ? "none" : accountIds,
          beginDate,
          endDate);
      return Flux.empty();
    }
    Flux<List<Long>> accountIdsChunks =
        Mono.justOrEmpty(accountIds)
            .map(DocumentService::validateActiveDocumentSearchCollection)
            .flatMapMany(Flux::fromIterable)
            .buffer(500);
    Set<Long> validSecurityIds = validateActiveDocumentSearchCollection(securityIds);
    Set<String> validExcludedSources = validateActiveDocumentSearchStrings(excludedSources);
    log.info(
        "Processing accounts={} with securities={} and excluded sources={}",
        accountIds,
        CollectionUtils.isEmpty(validSecurityIds) ? "none" : validSecurityIds,
        CollectionUtils.isEmpty(validExcludedSources) ? "none" : validExcludedSources);
    return accountIdsChunks
        .parallel()
        .runOn(Schedulers.parallel())
        .map(
            accountIdsChunk ->
                retrieveAndFilterDocuments(
                    accountIdsChunk, validSecurityIds, validExcludedSources, beginDate, endDate))
        .sequential()
        .flatMap(Flux::fromIterable)
        .collectList()
        .map(DocumentService::sortDocumentsByDate)
        .flatMapMany(Flux::fromIterable)
        .doOnComplete(
            () ->
                log.info(
                    "Completed processing documents for accounts={} with securities={}",
                    accountIds,
                    CollectionUtils.isEmpty(validSecurityIds) ? "none" : validSecurityIds));
  }

  private List<Document> retrieveAndFilterDocuments(
      Collection<Long> accountIds,
      Collection<Long> validSecurityIds,
      Collection<String> validExcludedSources,
      LocalDate beginDate,
      LocalDate endDate) {
    log.info("Processing chunk of {} accounts: {}", accountIds.size(), accountIds);
    return documentRepository
        .findActiveDocumentsByAccountsAndDateRange(accountIds, beginDate, endDate)
        .stream()
        .filter(
            doc ->
                CollectionUtils.isEmpty(validSecurityIds)
                    || (Objects.nonNull(doc.getSecurityId())
                        && validSecurityIds.contains(doc.getSecurityId())))
        .filter(
            doc ->
                CollectionUtils.isEmpty(validExcludedSources)
                    || !validExcludedSources.contains(
                        StringUtils.lowerCase(StringUtils.defaultString(doc.getSource()))))
        .map(documentTransformer)
        .toList();
  }

  private static List<Document> sortDocumentsByDate(List<Document> documents) {
    documents.sort(
        Comparator.comparing(
            Document::getDocumentDate, Comparator.nullsLast(Comparator.reverseOrder())));
    return documents;
  }

  private static <T> Set<T> validateActiveDocumentSearchCollection(Collection<T> searchParams) {
    return Optional.ofNullable(searchParams)
        .map(params -> params.stream().filter(Objects::nonNull).collect(Collectors.toSet()))
        .orElse(Collections.emptySet());
  }

  private static Set<String> validateActiveDocumentSearchStrings(Collection<String> searchParams) {
    return Optional.ofNullable(searchParams)
        .map(
            params ->
                params.stream()
                    .filter(StringUtils::isNotBlank)
                    .map(StringUtils::lowerCase)
                    .collect(Collectors.toSet()))
        .orElse(Collections.emptySet());
  }

  private static boolean areActiveDocumentSearchParamsValid(
      Collection<Long> accountIds, LocalDate beginDate, LocalDate endDate) {
    if (Objects.isNull(accountIds) || Objects.isNull(beginDate) || Objects.isNull(endDate)) {
      log.warn(
          "Received null parameters: accountIds={}, beginDate={}, endDate={}",
          accountIds,
          beginDate,
          endDate);
      return false;
    }
    if (CollectionUtils.isEmpty(accountIds)) {
      log.warn("Received empty account IDs");
      return false;
    }
    if (beginDate.isAfter(endDate)) {
      log.warn("Invalid date range: beginDate {} is after endDate {}", beginDate, endDate);
      return false;
    }
    return true;
  }

  private Flux<DocumentEntity> findAllByIds(Set<Long> documentIds) {
    return Flux.fromIterable(documentRepository.findAllById(documentIds));
  }

  public void deleteByIds(Set<Long> documentIds) {
    documentRepository.deleteAllById(documentIds);
  }

  private DocumentEntity saveDocument(DocumentEntity doc) {
    Long id = doc.getId();
    DocumentEntity documentEntity = documentRepository.saveAndFlush(doc);
    CompletableFuture.runAsync(
            () -> capitalCallService.createCapitalCall(documentEntity, Objects.isNull(id)))
        .exceptionally(
            error -> {
              log.error("Error while creating Capital Call", error);
              return null;
            });
    return documentEntity;
  }

  @Override
  public Flux<Document> getDocumentsByAccountsAndPeriodEndDateBetween(
      final Set<Long> accountIds, LocalDate periodStartDate, LocalDate periodEndDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndPeriodEndDateBetweenAndIsDisabledFalse(
                accountIds, periodStartDate, periodEndDate))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsByAccountsAndCashMvmtDateBetween(
      final Set<Long> accountIds, LocalDate cashMvmtStartDate, LocalDate cashMvmtEndDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndCashMvmtDateBetweenAndIsDisabledFalse(
                accountIds, cashMvmtStartDate, cashMvmtEndDate))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsByAccountsAndCashMvmtDateBetweenAndTypes(
      final Set<Long> accountIds,
      LocalDate cashMvmtStartDate,
      LocalDate cashMvmtEndDate,
      List<String> types) {
    return Flux.fromIterable(
            documentRepository
                .findAllByAccountIdInAndCashMvmtDateBetweenAndTypeInAndIsDisabledFalse(
                    accountIds, cashMvmtStartDate, cashMvmtEndDate, types))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsByIds(Set<Long> documentIds) {
    return Flux.fromIterable(documentRepository.findAllByIdIn(documentIds))
        .map(documentTransformer);
  }

  @Override
  public Set<Document> getDocumentsByIdsNonReactive(Set<Long> documentIds) {
    return documentRepository.findAllByIdIn(documentIds).stream()
        .map(documentEntity -> documentTransformer.apply(documentEntity))
        .collect(Collectors.toSet());
  }

  @Override
  @Transactional
  public Flux<Document> getAllActiveDocumentsByAccountIdAndFileName(
      final Long accountId, final String filename) {
    return Flux.fromIterable(
            documentRepository
                .findAllByAccountIdAndFileNameContainingIgnoreCaseAndIsDisabledIsFalse(
                    accountId, filename))
        .map(documentTransformer);
  }

  @Override
  @Transactional
  public Flux<Document> getAllActiveDocumentsByDirectoryId(Long directoryId) {
    return Flux.fromIterable(
            documentRepository.findAllByDirectoryIdAndIsDisabledIsFalse(directoryId))
        .map(documentTransformer);
  }

  @Override
  @Transactional
  public Flux<Document> getAllDocumentsByAccountIdAndIsDisabled(
      final Set<Long> accountIds, final Boolean isDisabled) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndIsDisabled(accountIds, isDisabled))
        .map(documentTransformer);
  }

  @Override
  public List<Document> getAllDocumentsByAccountIdsAndIsDisabledAndCreatedOnBetween(
      final Set<Long> accountIds,
      final Boolean isDisabled,
      final LocalDate beginDate,
      final LocalDate endDate) {
    List<Document> response = new ArrayList<>();
    Collection<DocumentEntity> documents =
        documentRepository.findAllByAccountIdAndIsDisabledAndCreatedOnBetween(
            accountIds, isDisabled, beginDate.atStartOfDay(), endDate.atStartOfDay());
    documents.forEach(document -> response.add(documentTransformer.apply(document)));
    return response;
  }

  @Override
  @Transactional
  public Flux<Document> getAllDocumentsByAccountIdAndCanoeId(Long accountId, String canoeId) {
    return Flux.fromIterable(documentRepository.findAllByAccountIdAndCanoeId(accountId, canoeId))
        .map(documentTransformer);
  }

  @Override
  @Transactional
  public Flux<Document> getAllActiveDocumentsWithoutDirectoryByAccountId(final Long accountId) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdAndDirectoryIdIsNullAndIsDisabledIsFalse(
                accountId))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getAllActiveDocumentsByAccountIdInAndSecurityIdAndDocDate(
      List<Long> accountIds, Long securityId, LocalDate docDate) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndSecurityIdAndDocDateAndIsDisabledFalse(
                accountIds, securityId, docDate))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getAllActiveDocumentsByCustodyTransactionId(Long custodyTransactionId) {
    return Flux.fromIterable(
            documentRepository.findAllByCustodyTransactionIdAndIsDisabledFalse(
                custodyTransactionId))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getAllActiveDocumentsForToday() {
    return Flux.fromIterable(documentRepository.findAllActiveDocumentsForToday())
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentByCreatedOnAfter(LocalDateTime createdOn) {
    return Flux.fromIterable(documentRepository.findAllByCreatedOnAfter(createdOn))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getDocumentsBySecurityIdsIn(List<Long> securityIds) {
    return Flux.fromIterable(documentRepository.findAllBySecurityIdIn(securityIds))
        .map(documentTransformer);
  }

  @Override
  public Flux<Document> getByAccountIdInAndSecurityIdAndDocDateAndType(
      List<Long> accountIds, Long securityId, LocalDate docDate, String type) {
    return Flux.fromIterable(
            documentRepository.findAllByAccountIdInAndSecurityIdAndDocDateAndType(
                accountIds, securityId, docDate, type))
        .map(documentTransformer);
  }

  @Override
  @Transactional
  public List<Document> getDocumentsByCanoeId(String canoeId) {
    return documentRepository.findByCanoeId(canoeId).stream()
        .map(documentEntity -> documentTransformer.apply(documentEntity))
        .toList();
  }

  @Override
  @Transactional
  public Optional<Document> getDocumentByCanoeIdAndAccountIdAndSecurityId(
      String canoeId, Long accountId, Long securityId) {
    return documentRepository
        .findByCanoeIdAndAccountIdAndSecurityId(canoeId, accountId, securityId)
        .map(documentEntity -> documentTransformer.apply(documentEntity));
  }

  @Override
  @Transactional
  public Document updateDocument(
      Long documentId,
      String rawDataCloudStorageId,
      LocalDateTime rawDataModifiedOn,
      String source) {
    var documentEntity =
        documentRepository
            .findById(documentId)
            .orElseThrow(
                () -> new EntityNotFoundException("Document not found with id: " + documentId));
    documentEntity.setRawDataCloudStorageId(rawDataCloudStorageId);
    documentEntity.setRawDataModifiedOn(rawDataModifiedOn);
    documentEntity.setSource(source);
    var updatedDocumentEntity = documentRepository.save(documentEntity);
    return documentTransformer.apply(updatedDocumentEntity);
  }

  @Override
  public Optional<Document> getMostRecentDocumentByCriteria(
      Long accountId, Long securityId, String canoeId, Set<String> sources) {
    return documentRepository
        .findMostRecentDocumentByCriteria(accountId, securityId, canoeId, sources)
        .map(documentEntity -> documentTransformer.apply(documentEntity));
  }
}
