package com.cwan.pbor.document.capital.call.repository;

import com.cwan.pbor.document.capital.call.entity.CapitalCallDocumentEntity;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

public interface CapitalCallDocumentRepository
    extends JpaRepository<CapitalCallDocumentEntity, Long> {

  List<CapitalCallDocumentEntity> findByCallReceivedDateBetweenAndAccountIdIn(
      LocalDate startDate, LocalDate endDate, Set<Long> accountIds);

  List<CapitalCallDocumentEntity> findByDueDateBetweenAndAccountIdIn(
      LocalDate startDate, LocalDate endDate, Set<Long> accountIds);

  @Transactional
  void deleteByDocumentId(Long documentId);

  Optional<CapitalCallDocumentEntity> getByDocumentId(Long documentId);
}
