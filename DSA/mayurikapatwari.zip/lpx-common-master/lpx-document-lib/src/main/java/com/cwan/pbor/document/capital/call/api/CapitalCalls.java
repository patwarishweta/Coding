package com.cwan.pbor.document.capital.call.api;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallStatus;
import java.time.LocalDate;
import java.util.Set;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** Interface for defining operations related to Capital Calls. */
public interface CapitalCalls {

  /**
   * Fetches capital calls related to the given set of account IDs and within the specified date
   * range, then filters them based on the given set of statuses. The date range filtering is
   * applied based on the provided date filter type, either on the call received date or the due
   * date. If the provided set of statuses is empty, the method returns capital calls for the
   * specified accounts regardless of their status.
   *
   * @param dateFilterType The type of date filter to apply, either call received date or due date.
   * @param startDate The starting date for filtering capital calls.
   * @param endDate The ending date for filtering capital calls.
   * @param accountIds The set of account IDs for which to fetch capital calls.
   * @param statuses The set of capital call statuses to filter the results by. If empty, results
   *     will not be filtered by status.
   * @return A Flux of {@link CapitalCallDocument} instances.
   */
  Flux<CapitalCallDocument> getCapitalCallsByAccounts(
      CapitalCallDateFilterType dateFilterType,
      LocalDate startDate,
      LocalDate endDate,
      Set<Long> accountIds,
      Set<CapitalCallStatus> statuses);

  /**
   * Fetches capital calls related to the given document ID.
   *
   * @param documentId the ID of the document for which the capital call is to be retrieved.
   * @return Mono of {@link CapitalCallDocument} instance.
   */
  Mono<CapitalCallDocument> getCapitalCallByDocument(Long documentId);

  /**
   * Method to update the status of a Capital Call.
   *
   * @param capitalCallAuditAction the request object containing all necessary information to update
   *     a Capital Call's status
   * @param capitalCallAction the action to be performed on a Capital Call
   * @return a Mono of the updated {@link CapitalCallDocument}
   */
  Mono<CapitalCallDocument> updateCapitalCallStatus(
      CapitalCallAuditAction capitalCallAuditAction, CapitalCallAction capitalCallAction);

  /**
   * Fetches the CapitalCallAudit by document ID and wraps the results in a Mono.
   *
   * @param documentId the ID of the document for which the audit is to be retrieved.
   * @return Mono of CapitalCallAuditLog containing the audit history of the provided document.
   */
  Mono<CapitalCallAuditLog> getCapitalCallAuditByDocument(Long documentId);

  /**
   * Fetches all capital calls from the database that match the given statuses. If no statuses are
   * provided, it will fetch all capital calls without any status filtering.
   *
   * @param statuses A set of {@link CapitalCallStatus} instances representing desired capital call
   *     statuses.
   * @return Flux of {@link CapitalCallDocument} instances matching the given statuses or all
   *     capital calls if no statuses are provided.
   */
  Flux<CapitalCallDocument> getCapitalCallsByStatuses(Set<CapitalCallStatus> statuses);

  /**
   * Inserts any missed capital call records into the database. This method is exclusively invoked
   * by a scheduler to ensure data consistency and completeness. Note: This is a preventive and
   * corrective method to ensure no capital call records are unintentionally skipped or missed due
   * to transient system errors or disruptions.
   */
  Mono<Integer> insertMissedCapitalCalls();
}
