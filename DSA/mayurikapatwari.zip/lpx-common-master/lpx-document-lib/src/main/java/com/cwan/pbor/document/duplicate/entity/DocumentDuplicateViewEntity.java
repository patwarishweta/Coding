package com.cwan.pbor.document.duplicate.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Immutable;

@Entity
@Table(name = "document_duplicate_view", catalog = "pabor")
@Immutable
@IdClass(DocumentDuplicateViewEntityPK.class)
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(builderClassName = "DocumentDuplicateViewEntityBuilder", toBuilder = true)
public class DocumentDuplicateViewEntity {

  @SuppressWarnings("unused")
  public static class DocumentDuplicateViewEntityBuilder {

    public DocumentDuplicateViewEntityBuilder assignee(String assignee) {
      this.assignee = StringUtils.trimToNull(assignee);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder clientName(String clientName) {
      this.clientName = StringUtils.trimToNull(clientName);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder comment(String comment) {
      this.comment = StringUtils.trimToNull(comment);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder currentCanoeId(String currentCanoeId) {
      this.currentCanoeId = StringUtils.trimToNull(currentCanoeId);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder documentType(String documentType) {
      this.documentType = StringUtils.trimToNull(documentType);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder duplicateCanoeId(String duplicateCanoeId) {
      this.duplicateCanoeId = StringUtils.trimToNull(duplicateCanoeId);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder duplicateStatus(String duplicateStatus) {
      this.duplicateStatus = StringUtils.trimToNull(duplicateStatus);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder entity(String entity) {
      this.entity = StringUtils.trimToNull(entity);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder fileName(String fileName) {
      this.fileName = StringUtils.trimToNull(fileName);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder investment(String investment) {
      this.investment = StringUtils.trimToNull(investment);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder modifier(String modifier) {
      this.modifier = StringUtils.trimToNull(modifier);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder note(String note) {
      this.note = StringUtils.trimToNull(note);
      return this;
    }

    public DocumentDuplicateViewEntityBuilder ultimateParentName(String ultimateParentName) {
      this.ultimateParentName = StringUtils.trimToNull(ultimateParentName);
      return this;
    }
  }

  @Id
  @Column(name = "document_id", updatable = false, insertable = false)
  private Long documentId;

  @Id
  @Column(name = "duplicate_canoe_id", updatable = false, insertable = false)
  private String duplicateCanoeId;

  @Column(name = "file_name", updatable = false, insertable = false)
  private String fileName;

  @Column(name = "account_id", updatable = false, insertable = false)
  private Long accountId;

  @Column(name = "security_id", updatable = false, insertable = false)
  private Long securityId;

  @Column(name = "document_type", updatable = false, insertable = false)
  private String documentType;

  @Column(name = "document_received_date", updatable = false, insertable = false)
  private LocalDate documentReceivedDate;

  @Column(name = "document_date", updatable = false, insertable = false)
  private LocalDate documentDate;

  @Column(name = "duplicate_received_on", updatable = false, insertable = false)
  private LocalDateTime duplicateReceivedOn;

  @Column(name = "current_canoe_id", updatable = false, insertable = false)
  private String currentCanoeId;

  @Column(name = "current_received_on", updatable = false, insertable = false)
  private LocalDateTime currentReceivedOn;

  @Column(name = "entity", updatable = false, insertable = false)
  private String entity;

  @Column(name = "investment", updatable = false, insertable = false)
  private String investment;

  @Column(name = "client_id", updatable = false, insertable = false)
  private Long clientId;

  @Column(name = "client_name", updatable = false, insertable = false)
  private String clientName;

  @Column(name = "ultimate_parent_id", updatable = false, insertable = false)
  private Long ultimateParentId;

  @Column(name = "ultimate_parent_name", updatable = false, insertable = false)
  private String ultimateParentName;

  @Column(name = "assignee", updatable = false, insertable = false)
  private String assignee;

  @Column(name = "modifier", updatable = false, insertable = false)
  private String modifier;

  @Column(name = "duplicate_status", updatable = false, insertable = false)
  private String duplicateStatus;

  @Column(name = "comment", updatable = false, insertable = false)
  private String comment;

  @Column(name = "note", updatable = false, insertable = false)
  private String note;

  @Column(name = "created_on", updatable = false, insertable = false)
  private LocalDateTime createdOn;

  @Column(name = "modified_on", updatable = false, insertable = false)
  private LocalDateTime modifiedOn;
}
