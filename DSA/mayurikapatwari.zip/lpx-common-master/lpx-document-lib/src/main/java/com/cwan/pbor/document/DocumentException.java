package com.cwan.pbor.document;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class DocumentException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = -3285493479844458072L;

  public DocumentException(HttpStatus status, String msg, Throwable e) {
    super(status, msg, e);
  }

  public DocumentException(HttpStatus status, String msg) {
    super(status, msg);
  }
}
