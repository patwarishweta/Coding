package com.cwan.pbor.document.capital.call.management.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BankErrorMessage {

  public static final String BANK_MUST_NOT_BE_NULL = "Bank must not be null";
  public static final String ENTRY_ALREADY_EXISTS_WITH_GIVEN_PARAMETERS =
      "Entry already exists with given parameters";
  public static final String CLIENT_ID_MUST_NOT_BE_NULL = "Client ID must not be null";
  public static final String BANK_UUID_MUST_NOT_BE_NULL = "Bank UUID must not be null";
  public static final String BANK_ACCOUNT_MUST_NOT_BE_NULL = "Bank Account must not be null";
  public static final String NO_BANK_FOUND_WITH_THE_PROVIDED_BANK_UUID =
      "No bank found with the provided bankUuid";
  public static final String ACCOUNT_ID_MUST_NOT_BE_NULL = "Account ID must not be null";
  public static final String BANK_ACCOUNT_UUID_MUST_NOT_BE_NULL =
      "Bank Account UUID must not be null";
  public static final String BANK_BLACKLIST_MUST_NOT_BE_NULL = "Bank Blacklist must not be null";
  public static final String BANK_BLACKLIST_UUID_MUST_NOT_BE_NULL =
      "Bank Blacklist UUID must not be null";
}
