package com.cwan.pbor.document.missing.document.api;

import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import java.util.List;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface MissingDocumentAlertConfigService {
  List<MissingDocumentAlertConfig> getAllMissingDocumentAlertConfigByClientIdIn(
      List<Long> clientIds);

  Flux<MissingDocumentAlertConfig> addMissingDocumentAlertConfig(
      Set<MissingDocumentAlertConfig> missingDocumentAlertConfigs);
}
