package com.cwan.pbor.document.capital.call.management.repository;

import com.cwan.pbor.document.capital.call.management.entity.BankAccountEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface BankAccountRepository extends JpaRepository<BankAccountEntity, Long> {

  List<BankAccountEntity> findByAccountId(Long accountId);

  @Query("SELECT ba FROM BankAccountEntity ba JOIN ba.bank b WHERE b.clientId = :clientId")
  List<BankAccountEntity> findByClientId(Long clientId);

  Optional<BankAccountEntity> findByBankAccountUuid(String bankAccountUuid);

  @Transactional
  @Modifying
  @Query(
      "UPDATE BankAccountEntity ba SET ba.isDeleted = true, ba.deletedBy = :deletedBy WHERE ba.bankAccountUuid = :bankAccountUuid")
  int softDeleteByBankAccountUuidAndSetDeletedBy(String bankAccountUuid, Long deletedBy);

  boolean existsByBankIdAndAccountIdAndAccountNumberAndIban(
      Long bankId, Long accountId, String accountNumber, String iban);
}
