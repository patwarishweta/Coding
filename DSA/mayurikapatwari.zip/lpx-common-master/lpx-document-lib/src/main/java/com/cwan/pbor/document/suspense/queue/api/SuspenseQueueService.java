package com.cwan.pbor.document.suspense.queue.api;

import com.cwan.lpx.domain.SuspenseQueue;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

public interface SuspenseQueueService {

  List<SuspenseQueue> getAllSuspenseQueueDocumentCreatedOnInBetweenAndDocumentTypesIn(
      LocalDateTime beginDate, LocalDateTime endDate, List<String> documentTypes);

  List<SuspenseQueue> getAllSuspenseQueueDocumentCreatedOnInBetweenAndDocumentTypesNotIn(
      LocalDateTime beginDate, LocalDateTime endDate, List<String> documentTypes);

  List<SuspenseQueue> getAllSuspenseQueueDocumentsByCreatedOnInBetweenAndUltimateParentIdsIn(
      LocalDateTime beginDate, LocalDateTime endDate, List<Long> ultimateParentIds);

  SuspenseQueue getSuspenseQueueDocumentByIdAndIsCurrent(Long id, Boolean isCurrent);

  List<SuspenseQueue> getAllSuspenseQueueDocumentByIdsAndIsCurrent(Set<Long> ids);

  void updateSuspenseQueueDocuments(List<Long> ids, String modifiedBy, LocalDateTime modifiedOn);

  void insertSuspenseQueueDocuments(List<SuspenseQueue> documents);
}
