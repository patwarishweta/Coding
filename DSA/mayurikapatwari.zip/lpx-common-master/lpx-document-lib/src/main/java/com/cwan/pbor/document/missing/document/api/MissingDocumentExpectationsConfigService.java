package com.cwan.pbor.document.missing.document.api;

import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import java.util.List;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface MissingDocumentExpectationsConfigService {
  List<MissingDocumentExpectationsConfig> getAllMissingDocumentExpectationsConfigBySecurityIds(
      List<Long> securityIds);

  Flux<MissingDocumentExpectationsConfig> addMissingDocumentExpectationsConfig(
      Set<MissingDocumentExpectationsConfig> missingDocumentExpectationsConfigs);
}
