package com.cwan.pbor.document.capital.call.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallStatus;
import org.junit.jupiter.api.Test;

class CapitalCallStatusTransitionUtilTest {

  @Test
  void testGetNewStatus() {
    // Test for WIRE_CHECK status
    assertEquals(
        CapitalCallStatus.WIRE_CHECK_REJECTED,
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.WIRE_CHECK, CapitalCallAction.REJECT));
    assertEquals(
        CapitalCallStatus.INITIAL_REVIEW,
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.WIRE_CHECK, CapitalCallAction.APPROVE));
    // Test for INITIAL_REVIEW status
    assertEquals(
        CapitalCallStatus.WIRE_CHECK,
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.INITIAL_REVIEW, CapitalCallAction.REJECT));
    assertEquals(
        CapitalCallStatus.FINAL_REVIEW,
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.INITIAL_REVIEW, CapitalCallAction.APPROVE));
    // Test for FINAL_REVIEW status
    assertEquals(
        CapitalCallStatus.INITIAL_REVIEW,
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.FINAL_REVIEW, CapitalCallAction.REJECT));
    assertEquals(
        CapitalCallStatus.COMPLETED,
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.FINAL_REVIEW, CapitalCallAction.APPROVE));
    // Test for a status that doesn't exist in the VALID_STATUS_TRANSITIONS map
    assertNull(
        CapitalCallStatusTransitionUtil.getNewStatus(
            CapitalCallStatus.COMPLETED, CapitalCallAction.APPROVE));
  }
}
