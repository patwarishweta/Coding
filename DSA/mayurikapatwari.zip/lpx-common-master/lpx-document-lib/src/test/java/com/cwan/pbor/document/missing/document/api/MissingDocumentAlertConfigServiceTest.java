package com.cwan.pbor.document.missing.document.api;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.pbor.document.missing.document.TestUtil;
import com.cwan.pbor.document.missing.document.api.impl.MissingDocumentAlertConfigServiceImpl;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentAlertConfigEntity;
import com.cwan.pbor.document.missing.document.repository.MissingDocumentAlertConfigRepository;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentAlertConfigEntityTransformer;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentAlertConfigTransformer;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
public class MissingDocumentAlertConfigServiceTest {
  @Mock private MissingDocumentAlertConfigRepository missingDocumentAlertConfigRepository;
  private MissingDocumentAlertConfigService missingDocumentAlertConfigService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    missingDocumentAlertConfigService =
        new MissingDocumentAlertConfigServiceImpl(
            missingDocumentAlertConfigRepository,
            new MissingDocumentAlertConfigTransformer(),
            new MissingDocumentAlertConfigEntityTransformer());
  }

  @Test
  void test_getAllMissingDocumentAlertConfigByClientId() {
    when(missingDocumentAlertConfigRepository.findAllByClientIdIn(List.of(1234L)))
        .thenReturn(List.of(TestUtil.getMissingDocumentAlertConfigEntity()));
    List<MissingDocumentAlertConfig> missingDocumentAlertConfigs =
        missingDocumentAlertConfigService.getAllMissingDocumentAlertConfigByClientIdIn(
            List.of(1234L));
    Assertions.assertEquals(
        List.of(TestUtil.getMissingDocumentAlertConfig()), missingDocumentAlertConfigs);
  }

  @Test
  void test_addMissingDocumentAlertConfig() {
    when(missingDocumentAlertConfigRepository.saveAndFlush(
            any(MissingDocumentAlertConfigEntity.class)))
        .thenReturn(TestUtil.getMissingDocumentAlertConfigEntity());
    MissingDocumentAlertConfig missingDocumentAlertConfig =
        TestUtil.getMissingDocumentAlertConfig();
    missingDocumentAlertConfig.setId(null);
    Assertions.assertEquals(
        List.of(TestUtil.getMissingDocumentAlertConfig()),
        missingDocumentAlertConfigService
            .addMissingDocumentAlertConfig(Set.of(missingDocumentAlertConfig))
            .collectList()
            .block());
  }
}
