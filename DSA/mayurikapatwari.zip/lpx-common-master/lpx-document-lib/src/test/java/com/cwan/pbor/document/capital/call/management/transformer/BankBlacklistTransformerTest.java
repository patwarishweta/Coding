package com.cwan.pbor.document.capital.call.management.transformer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.pbor.document.capital.call.management.entity.BankBlacklistEntity;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import com.cwan.pbor.document.capital.call.management.repository.BankRepository;
import java.time.LocalDateTime;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BankBlacklistTransformerTest {

  @InjectMocks
  private BankBlacklistEntityToBankBlacklistTransformer
      bankBlacklistEntityToBankBlacklistTransformer;

  @InjectMocks
  private BankBlacklistToBankBlacklistEntityTransformer
      bankBlacklistToBankBlacklistEntityTransformer;

  @Mock private BankEntityToBankTransformer bankEntityToBankTransformer;
  @Mock private BankRepository bankRepository;

  @Test
  public void testBankBlacklistEntityToBankBlacklistTransformer() {
    var bankBlacklistEntity = mock(BankBlacklistEntity.class);
    var bank = Bank.builder().bankUuid(String.valueOf(UUID.randomUUID())).build();
    when(bankBlacklistEntity.getBankBlacklistUuid()).thenReturn(String.valueOf(UUID.randomUUID()));
    when(bankBlacklistEntity.getCreatedAt()).thenReturn(LocalDateTime.now());
    when(bankBlacklistEntity.getCreatedBy()).thenReturn(123L);
    when(bankEntityToBankTransformer.apply(any())).thenReturn(bank);
    var result = bankBlacklistEntityToBankBlacklistTransformer.apply(bankBlacklistEntity);
    assertNotNull(result);
    assertEquals(bankBlacklistEntity.getBankBlacklistUuid(), result.bankBlacklistUuid());
  }

  @Test
  public void testBankBlacklistToBankBlacklistEntityTransformer() {
    var bank = Bank.builder().bankUuid(String.valueOf(UUID.randomUUID())).build();
    var bankBlacklist = BankBlacklist.builder().bank(bank).createdBy(123L).build();
    var bankEntity = mock(BankEntity.class);
    when(bankEntity.getBankId()).thenReturn(123L);
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.of(bankEntity));
    var result = bankBlacklistToBankBlacklistEntityTransformer.apply(bankBlacklist);
    assertNotNull(result);
    assertEquals(bankEntity.getBankId(), result.getBankId());
    assertEquals(bankBlacklist.createdBy(), result.getCreatedBy());
  }

  @Test
  public void testBankBlacklistToBankBlacklistEntityTransformer_NoBankFound() {
    var bank = Bank.builder().bankUuid(String.valueOf(UUID.randomUUID())).build();
    var bankBlacklist = BankBlacklist.builder().bank(bank).createdBy(123L).build();
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.empty());
    assertThrows(
        NoSuchElementException.class,
        () -> bankBlacklistToBankBlacklistEntityTransformer.apply(bankBlacklist));
  }
}
