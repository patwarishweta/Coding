package com.cwan.pbor.document.capital.call.transformer;

import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DocumentTransformerConstants.CAPITAL_CALL_USER_ACTION;
import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DocumentTransformerConstants.NEW_DOCUMENT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.pbor.document.capital.call.entity.CapitalCallDocumentEntity;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CapitalCallDocumentTransformerTest {

  private CapitalCallDocumentTransformer transformer;

  @BeforeEach
  void setUp() {
    transformer = new CapitalCallDocumentTransformer();
  }

  @Test
  void apply_ShouldTransformCapitalCallDocumentEntityToCapitalCall() {
    var now = LocalDate.now();
    var nowTime = LocalDateTime.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(now)
            .dueDate(now.plusDays(5))
            .securityId(1L)
            .accountId(1L)
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var audits = new ArrayList<CapitalCallAudit>();
    audits.add(
        CapitalCallAudit.builder()
            .timestamp(nowTime)
            .previousStatus(CapitalCallStatus.INITIAL_REVIEW)
            .nextStatus(CapitalCallStatus.FINAL_REVIEW)
            .user(CapitalCallUser.builder().email("test2@test.com").id(1).build())
            .comment("Some comment")
            .build());
    var auditLog = CapitalCallAuditLog.builder().audit(audits).build();
    var capitalCall = transformer.apply(entity, auditLog);
    assertEquals(entity.getNetAmount(), capitalCall.netAmount());
    assertEquals(entity.getDaysAging(), capitalCall.daysAging());
    var bankDetail = capitalCall.bankDetail();
    assertEquals(entity.getBankName(), bankDetail.bankName());
    assertEquals(entity.getAbaRoutingNumber(), bankDetail.abaRoutingNumber());
    assertEquals(entity.getSwiftOrChips(), bankDetail.swiftOrChips());
    assertEquals(entity.getAccountNumber(), bankDetail.accountNumber());
    assertEquals(entity.getBankDetailId(), bankDetail.bankDetailId());
    assertEquals(entity.getCallReceivedDate(), capitalCall.callReceivedDate());
    assertEquals(entity.getDueDate(), capitalCall.dueDate());
    assertEquals(entity.getSecurityId(), capitalCall.security().getSecurityId());
    assertEquals(entity.getAccountId(), capitalCall.account().getId());
    assertEquals(entity.getCurrency(), capitalCall.currency());
  }

  @Test
  void
      apply_ShouldTransformCapitalCallDocumentEntityToCapitalCall_WhenSecurityIdAndAccountIdAndStatusAreNull() {
    var now = LocalDate.now();
    var nowTime = LocalDateTime.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(now)
            .dueDate(now.plusDays(5))
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var audits = new ArrayList<CapitalCallAudit>();
    audits.add(
        CapitalCallAudit.builder()
            .timestamp(nowTime)
            .previousStatus(CapitalCallStatus.INITIAL_REVIEW)
            .nextStatus(CapitalCallStatus.FINAL_REVIEW)
            .user(CapitalCallUser.builder().email("test2@test.com").id(1).build())
            .comment("Some comment")
            .build());
    var auditLog = CapitalCallAuditLog.builder().audit(audits).build();
    var capitalCall = transformer.apply(entity, auditLog);
    assertEquals(entity.getNetAmount(), capitalCall.netAmount());
    assertEquals(entity.getDaysAging(), capitalCall.daysAging());
    var bankDetail = capitalCall.bankDetail();
    assertEquals(entity.getBankName(), bankDetail.bankName());
    assertEquals(entity.getAbaRoutingNumber(), bankDetail.abaRoutingNumber());
    assertEquals(entity.getSwiftOrChips(), bankDetail.swiftOrChips());
    assertEquals(entity.getAccountNumber(), bankDetail.accountNumber());
    assertEquals(entity.getBankDetailId(), bankDetail.bankDetailId());
    assertEquals(entity.getCallReceivedDate(), capitalCall.callReceivedDate());
    assertEquals(entity.getDueDate(), capitalCall.dueDate());
    assertNull(capitalCall.security());
    assertNull(capitalCall.account());
    assertEquals(entity.getCurrency(), capitalCall.currency());
  }

  @Test
  void apply_ShouldAssignDefaultStatusAndComment_WhenAuditLogIsEmpty() {
    var now = LocalDate.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(now)
            .dueDate(now.plusDays(5))
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var auditLog = CapitalCallAuditLog.builder().audit(new ArrayList<>()).build();
    var capitalCall = transformer.apply(entity, auditLog);
    assertEquals(CapitalCallStatus.NOT_SPECIFIED, capitalCall.status());
    assertEquals(NEW_DOCUMENT, capitalCall.comment());
  }

  @Test
  void apply_ShouldAssignUserActionsBasedOnPreviousStatus_WhenAuditLogIsNotEmpty() {
    var nowTime = LocalDateTime.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(LocalDate.now())
            .dueDate(LocalDate.now().plusDays(5))
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var audits = new ArrayList<CapitalCallAudit>();
    var user = CapitalCallUser.builder().email("test2@test.com").id(1).build();
    audits.add(
        CapitalCallAudit.builder()
            .timestamp(nowTime)
            .previousStatus(CapitalCallStatus.WIRE_CHECK)
            .nextStatus(CapitalCallStatus.FINAL_REVIEW)
            .user(user)
            .comment("Wire check comment")
            .build());
    audits.add(
        CapitalCallAudit.builder()
            .timestamp(nowTime.plusDays(1))
            .previousStatus(CapitalCallStatus.INITIAL_REVIEW)
            .nextStatus(CapitalCallStatus.WIRE_CHECK)
            .user(user)
            .comment("Initial review comment")
            .build());
    audits.add(
        CapitalCallAudit.builder()
            .timestamp(nowTime.plusDays(1))
            .previousStatus(CapitalCallStatus.FINAL_REVIEW)
            .nextStatus(CapitalCallStatus.WIRE_CHECK)
            .user(user)
            .comment("Initial review comment")
            .build());
    var auditLog = CapitalCallAuditLog.builder().audit(audits).build();
    var capitalCall = transformer.apply(entity, auditLog);
    assertEquals(user, capitalCall.wireCheckAction().user());
    assertEquals(user, capitalCall.initialReviewAction().user());
  }

  @Test
  void apply_ShouldAssignDefaultStatusAndComment_WhenAuditLogIsNull() {
    var now = LocalDate.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(now)
            .dueDate(now.plusDays(5))
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var capitalCall = transformer.apply(entity, null);
    assertEquals(CapitalCallStatus.NOT_SPECIFIED, capitalCall.status());
    assertEquals(NEW_DOCUMENT, capitalCall.comment());
  }

  @Test
  void apply_ShouldAssignDefaultUserActions_WhenAuditListIsNull() {
    var now = LocalDate.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(now)
            .dueDate(now.plusDays(5))
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var auditLog = CapitalCallAuditLog.builder().audit(null).build();
    var capitalCall = transformer.apply(entity, auditLog);
    assertEquals(CAPITAL_CALL_USER_ACTION, capitalCall.wireCheckAction());
    assertEquals(CAPITAL_CALL_USER_ACTION, capitalCall.initialReviewAction());
    assertEquals(CAPITAL_CALL_USER_ACTION, capitalCall.finalReviewAction());
  }

  @Test
  void apply_ShouldAssignDefaultUserActions_WhenAuditListIsEmpty() {
    var now = LocalDate.now();
    var entity =
        CapitalCallDocumentEntity.builder()
            .documentId(1L)
            .paymentAmount(new BigDecimal("100.0"))
            .netAmount(new BigDecimal("200.0"))
            .daysAging(3)
            .bankName("Test Bank")
            .abaRoutingNumber("123456789")
            .swiftOrChips("Swift")
            .accountNumber("1234567890")
            .callReceivedDate(now)
            .dueDate(now.plusDays(5))
            .currency("USD")
            .bankDetailId(1L)
            .build();
    var auditLog = CapitalCallAuditLog.builder().audit(new ArrayList<>()).build();
    var capitalCall = transformer.apply(entity, auditLog);
    assertEquals(CAPITAL_CALL_USER_ACTION, capitalCall.wireCheckAction());
    assertEquals(CAPITAL_CALL_USER_ACTION, capitalCall.initialReviewAction());
    assertEquals(CAPITAL_CALL_USER_ACTION, capitalCall.finalReviewAction());
  }
}
