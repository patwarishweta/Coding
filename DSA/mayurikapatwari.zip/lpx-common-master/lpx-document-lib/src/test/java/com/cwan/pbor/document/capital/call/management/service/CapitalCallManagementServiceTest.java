package com.cwan.pbor.document.capital.call.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.lpx.domain.BankBlacklist;
import com.cwan.pbor.document.capital.call.management.entity.BankAccountEntity;
import com.cwan.pbor.document.capital.call.management.entity.BankBlacklistEntity;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import com.cwan.pbor.document.capital.call.management.repository.BankAccountRepository;
import com.cwan.pbor.document.capital.call.management.repository.BankBlacklistRepository;
import com.cwan.pbor.document.capital.call.management.repository.BankRepository;
import com.cwan.pbor.document.capital.call.management.transformer.BankAccountEntityToBankAccountTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankAccountToBankAccountEntityTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankBlacklistEntityToBankBlacklistTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankBlacklistToBankBlacklistEntityTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankEntityToBankTransformer;
import com.cwan.pbor.document.capital.call.management.transformer.BankToBankEntityTransformer;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

@ExtendWith(MockitoExtension.class)
public class CapitalCallManagementServiceTest {

  @Mock private EntityManager entityManager;
  @Mock private BankRepository bankRepository;
  @Mock private BankAccountRepository bankAccountRepository;
  @Mock private BankBlacklistRepository bankBlacklistRepository;
  @Mock private BankToBankEntityTransformer bankToBankEntityTransformer;
  @Mock private BankEntityToBankTransformer bankEntityToBankTransformer;
  @Mock private BankAccountToBankAccountEntityTransformer bankAccountToBankAccountEntityTransformer;
  @Mock private BankAccountEntityToBankAccountTransformer bankAccountEntityToBankAccountTransformer;

  @Mock
  private BankBlacklistToBankBlacklistEntityTransformer
      bankBlacklistToBankBlacklistEntityTransformer;

  @Mock
  private BankBlacklistEntityToBankBlacklistTransformer
      bankBlacklistEntityToBankBlacklistTransformer;

  @InjectMocks @Spy private CapitalCallManagementService service;

  @BeforeEach
  void setUp() {
    lenient().doNothing().when(entityManager).refresh(any());
    lenient()
        .when(bankToBankEntityTransformer.apply(any(Bank.class)))
        .thenReturn(BankEntity.builder().build());
    lenient()
        .when(bankEntityToBankTransformer.apply(any(BankEntity.class)))
        .thenReturn(Bank.builder().clientId(1L).build());
    lenient()
        .when(bankAccountToBankAccountEntityTransformer.apply(any(BankAccount.class)))
        .thenReturn(BankAccountEntity.builder().build());
    lenient()
        .when(bankAccountEntityToBankAccountTransformer.apply(any(BankAccountEntity.class)))
        .thenReturn(BankAccount.builder().build());
    lenient()
        .when(bankBlacklistToBankBlacklistEntityTransformer.apply(any(BankBlacklist.class)))
        .thenReturn(BankBlacklistEntity.builder().build());
    lenient()
        .when(bankBlacklistEntityToBankBlacklistTransformer.apply(any(BankBlacklistEntity.class)))
        .thenReturn(BankBlacklist.builder().build());
  }

  @Test
  void testCreateBank() {
    var bank = Bank.builder().build();
    when(bankRepository.saveAndFlush(any())).thenReturn(BankEntity.builder().build());
    service.createBank(bank);
    verify(bankRepository).saveAndFlush(any());
  }

  @Test
  void testFetchBanksByClient() {
    when(bankRepository.findByClientId(any())).thenReturn(List.of(BankEntity.builder().build()));
    var banks = service.fetchBanksByClient(1L);
    assertNotNull(banks);
    assertEquals(1, banks.size());
  }

  @Test
  void testFetchBank() {
    when(bankRepository.findByBankUuid(any()))
        .thenReturn(Optional.of(BankEntity.builder().build()));
    var bank = service.fetchBank("uuid");
    assertTrue(bank.isPresent());
  }

  @Test
  void testDeleteBank() {
    when(bankRepository.softDeleteByBankUuidAndSetDeletedBy(any(), any())).thenReturn(1);
    var bankEntity = BankEntity.builder().build();
    bankEntity.setClientId(1L);
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.of(bankEntity));
    var result = service.deleteBank("uuid", 1L);
    assertTrue(result);
    verify(bankRepository).softDeleteByBankUuidAndSetDeletedBy("uuid", 1L);
  }

  @Test
  void testDeleteBankFailure() {
    when(bankRepository.softDeleteByBankUuidAndSetDeletedBy(any(), any())).thenReturn(0);
    var bankEntity = BankEntity.builder().build();
    bankEntity.setClientId(1L);
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.of(bankEntity));
    var exception = assertThrows(IllegalStateException.class, () -> service.deleteBank("uuid", 1L));
    assertEquals("Failed to delete bank with UUID: uuid", exception.getMessage());
    verify(bankRepository).softDeleteByBankUuidAndSetDeletedBy("uuid", 1L);
  }

  @Test
  void testFetchBankAccounts() {
    when(bankAccountRepository.findAll()).thenReturn(List.of(BankAccountEntity.builder().build()));
    var bankAccounts = service.findAllBankAccounts();
    assertNotNull(bankAccounts);
    assertEquals(1, bankAccounts.size());
  }

  @Test
  void testCreateBankAccount() {
    var bank = Bank.builder().bankUuid("test-uuid").build();
    var bankAccount = BankAccount.builder().bank(bank).build();
    when(bankAccountRepository.saveAndFlush(any())).thenReturn(BankAccountEntity.builder().build());
    when(bankRepository.findByBankUuid(any()))
        .thenReturn(Optional.of(BankEntity.builder().build()));
    service.createBankAccount(bankAccount);
    verify(bankAccountRepository).saveAndFlush(any());
  }

  @Test
  void testFetchBankAccountsByAccount() {
    when(bankAccountRepository.findByAccountId(any()))
        .thenReturn(List.of(BankAccountEntity.builder().build()));
    var bankAccounts = service.fetchBankAccountsByAccount(1L);
    assertNotNull(bankAccounts);
    assertEquals(1, bankAccounts.size());
  }

  @Test
  void testFetchBankAccountsByClient() {
    when(bankAccountRepository.findByClientId(any()))
        .thenReturn(List.of(BankAccountEntity.builder().build()));
    var bankAccounts = service.fetchBankAccountsByClient(1L);
    assertNotNull(bankAccounts);
    assertEquals(1, bankAccounts.size());
  }

  @Test
  void testFetchBankAccount() {
    when(bankAccountRepository.findByBankAccountUuid(any()))
        .thenReturn(Optional.of(BankAccountEntity.builder().build()));
    var bankAccount = service.fetchBankAccount("uuid");
    assertTrue(bankAccount.isPresent());
  }

  @Test
  void testDeleteBankAccount() {
    when(bankAccountRepository.softDeleteByBankAccountUuidAndSetDeletedBy(any(), any()))
        .thenReturn(1);
    var result = service.deleteBankAccount("uuid", 1L);
    assertTrue(result);
    verify(bankAccountRepository).softDeleteByBankAccountUuidAndSetDeletedBy("uuid", 1L);
  }

  @Test
  void testCreateBankBlacklist() {
    var bank = Bank.builder().bankUuid("test-uuid").build();
    var bankBlacklist = BankBlacklist.builder().bank(bank).build();
    when(bankBlacklistRepository.saveAndFlush(any()))
        .thenReturn(BankBlacklistEntity.builder().build());
    when(bankRepository.findByBankUuid(any()))
        .thenReturn(Optional.of(BankEntity.builder().build()));
    service.createBankBlacklist(bankBlacklist);
    verify(bankBlacklistRepository).saveAndFlush(any());
  }

  @Test
  void testFetchBankBlacklistsByClient() {
    when(bankBlacklistRepository.findByClientId(any()))
        .thenReturn(List.of(BankBlacklistEntity.builder().build()));
    var bankBlacklists = service.fetchBankBlacklistsByClient(1L);
    assertNotNull(bankBlacklists);
    assertEquals(1, bankBlacklists.size());
  }

  @Test
  void testFetchBankBlacklist() {
    when(bankBlacklistRepository.findByBankBlacklistUuid(any()))
        .thenReturn(Optional.of(BankBlacklistEntity.builder().build()));
    var bankBlacklist = service.fetchBankBlacklist("uuid");
    assertTrue(bankBlacklist.isPresent());
  }

  @Test
  void testDeleteBankBlacklist() {
    when(bankBlacklistRepository.softDeleteByBankBlacklistUuidAndSetDeletedBy(any(), any()))
        .thenReturn(1);
    var result = service.deleteBankBlacklist("uuid", 1L);
    assertTrue(result);
    verify(bankBlacklistRepository).softDeleteByBankBlacklistUuidAndSetDeletedBy("uuid", 1L);
  }

  @Test
  void testCreateBankThrowsExceptionForDuplicateParameters() {
    var bank = Bank.builder().build();
    when(bankRepository.existsByClientIdAndAbaRoutingNumberAndSwiftChipsCode(any(), any(), any()))
        .thenReturn(true);
    assertThrows(DataIntegrityViolationException.class, () -> service.createBank(bank));
  }

  @Test
  void testCreateBankThrowsExceptionForNullBank() {
    assertThrows(NullPointerException.class, () -> service.createBank(null));
  }

  @Test
  void testFetchBanksByClientThrowsExceptionForNullClientId() {
    assertThrows(NullPointerException.class, () -> service.fetchBanksByClient(null));
  }

  @Test
  void testFetchBankThrowsExceptionForNullBankUuid() {
    assertThrows(NullPointerException.class, () -> service.fetchBank(null));
  }

  @Test
  void testDeleteBankThrowsExceptionForNullBankUuid() {
    assertThrows(NullPointerException.class, () -> service.deleteBank(null, 1L));
  }

  @Test
  void testDeleteBankReturnsFalseForNonExistentBank() {
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.empty());
    assertThrows(NoSuchElementException.class, () -> service.deleteBank("uuid", 1L));
  }

  @Test
  void testDeleteBankWithBankAccounts() {
    when(bankRepository.softDeleteByBankUuidAndSetDeletedBy(any(), any())).thenReturn(1);
    var bankEntity = BankEntity.builder().build();
    bankEntity.setClientId(1L);
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.of(bankEntity));
    doReturn(
            List.of(
                BankAccount.builder().bankAccountUuid("uuid").bank(Bank.builder().build()).build()))
        .when(service)
        .fetchBankAccountsByClient(anyLong());
    doReturn(true).when(service).deleteBankAccount(anyString(), anyLong());
    assertTrue(service.deleteBank("uuid", 1L));
    verify(bankRepository).softDeleteByBankUuidAndSetDeletedBy("uuid", 1L);
  }

  @Test
  void testDeleteBankWithBankBlacklists() {
    when(bankRepository.softDeleteByBankUuidAndSetDeletedBy(any(), any())).thenReturn(1);
    var bankEntity = BankEntity.builder().build();
    bankEntity.setClientId(1L);
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.of(bankEntity));
    doReturn(
            List.of(
                BankBlacklist.builder()
                    .bankBlacklistUuid("uuid")
                    .bank(Bank.builder().build())
                    .build()))
        .when(service)
        .fetchBankBlacklistsByClient(anyLong());
    doReturn(true).when(service).deleteBankBlacklist(anyString(), anyLong());
    assertTrue(service.deleteBank("uuid", 1L));
    verify(bankRepository).softDeleteByBankUuidAndSetDeletedBy("uuid", 1L);
  }

  @Test
  void testCreateBankAccountThrowsExceptionForDuplicateParameters() {
    var bankAccount =
        BankAccount.builder().bank(Bank.builder().bankUuid("test-uuid").build()).build();
    when(bankRepository.findByBankUuid(any()))
        .thenReturn(Optional.of(BankEntity.builder().build()));
    when(bankAccountRepository.existsByBankIdAndAccountIdAndAccountNumberAndIban(
            any(), any(), any(), any()))
        .thenReturn(true);
    assertThrows(
        DataIntegrityViolationException.class, () -> service.createBankAccount(bankAccount));
  }

  @Test
  void testCreateBankAccountThrowsExceptionForNonExistentBank() {
    var bankAccount =
        BankAccount.builder().bank(Bank.builder().bankUuid("non-existent-uuid").build()).build();
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.empty());
    assertThrows(EntityNotFoundException.class, () -> service.createBankAccount(bankAccount));
  }

  @Test
  void testFetchBankAccountsByAccountThrowsExceptionForNullAccountId() {
    assertThrows(NullPointerException.class, () -> service.fetchBankAccountsByAccount(null));
  }

  @Test
  void testFetchBankAccountsByClientThrowsExceptionForNullClientId() {
    assertThrows(NullPointerException.class, () -> service.fetchBankAccountsByClient(null));
  }

  @Test
  void testFetchBankAccountThrowsExceptionForNullUuid() {
    assertThrows(NullPointerException.class, () -> service.fetchBankAccount(null));
  }

  @Test
  void testDeleteBankAccountReturnsFalseForFailedDeletion() {
    when(bankAccountRepository.softDeleteByBankAccountUuidAndSetDeletedBy(any(), any()))
        .thenReturn(0);
    assertFalse(service.deleteBankAccount("uuid", 1L));
  }

  @Test
  void testCreateBankBlacklistThrowsExceptionForDuplicateParameters() {
    var bankBlacklist =
        BankBlacklist.builder().bank(Bank.builder().bankUuid("test-uuid").build()).build();
    when(bankRepository.findByBankUuid(any()))
        .thenReturn(Optional.of(BankEntity.builder().build()));
    when(bankBlacklistRepository.existsByBankId(any())).thenReturn(true);
    assertThrows(
        DataIntegrityViolationException.class, () -> service.createBankBlacklist(bankBlacklist));
  }

  @Test
  void testFetchBankBlacklistsByClientThrowsExceptionForNullClientId() {
    assertThrows(NullPointerException.class, () -> service.fetchBankBlacklistsByClient(null));
  }

  @Test
  void testFetchBankBlacklistThrowsExceptionForNullUuid() {
    assertThrows(NullPointerException.class, () -> service.fetchBankBlacklist(null));
  }

  @Test
  void testDeleteBankBlacklistReturnsFalseForFailedDeletion() {
    when(bankBlacklistRepository.softDeleteByBankBlacklistUuidAndSetDeletedBy(any(), any()))
        .thenReturn(0);
    assertFalse(service.deleteBankBlacklist("uuid", 1L));
  }
}
