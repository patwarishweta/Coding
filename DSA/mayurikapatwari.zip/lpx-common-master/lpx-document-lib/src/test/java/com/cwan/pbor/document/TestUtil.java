package com.cwan.pbor.document;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import java.time.LocalDate;

public class TestUtil {

  public static Document getDocument(Long id) {
    return Document.builder()
        .id(id)
        .cloudStorageId("409d529e-fd25-4b23-b672-26ad762b5e62")
        .fileName("File Name")
        .account(Account.builder().id(2L).build())
        .security(Security.builder().securityId(3L).build())
        .type("Capital Account")
        .isAudited(true)
        .source("canoe")
        .auditor("auditor")
        .accountingPrinciples("Accounting Principles")
        .auditOpinionDate(LocalDate.of(2022, 1, 4))
        .auditOpinion("Audit Opinion")
        .receivedDate(LocalDate.of(2022, 1, 2))
        .documentDate(LocalDate.of(2021, 12, 31))
        .cashMovementDate(LocalDate.of(2022, 1, 4))
        .frequency("monthly")
        .periodStartDate(LocalDate.of(2021, 12, 1))
        .periodEndDate(LocalDate.of(2021, 12, 31))
        .checked(false)
        .directoryId(2L)
        .errorStatus("status")
        .description("test description")
        .createdBy("user1")
        .isCreatedByInternalUser(true)
        .modifiedBy("user2")
        .isModifiedByInternalUser(false)
        .custodyTransactionId(123L)
        .assigneeId("ae994834-3b58-11ec-ae29-c53a5392f8a7")
        .assigneeName("Test User")
        .assigneeEmail("test@clearwateranalytics.com")
        .build();
  }

  public static DocumentEntity getDocumentEntity(Long id) {
    return DocumentEntity.builder()
        .id(id)
        .cloudStorageId("409d529e-fd25-4b23-b672-26ad762b5e62")
        .fileName("File Name")
        .accountId(2L)
        .type("Capital Account")
        .isAudited(true)
        .source("canoe")
        .auditor("auditor")
        .accountingPrinciples("Accounting Principles")
        .auditOpinionDate(LocalDate.of(2022, 1, 4))
        .auditOpinion("Audit Opinion")
        .receivedDate(LocalDate.of(2022, 1, 2))
        .frequency("monthly")
        .periodStartDate(LocalDate.of(2021, 12, 1))
        .periodEndDate(LocalDate.of(2021, 12, 31))
        .checked(false)
        .directoryId(2L)
        .errorStatus("status")
        .description("test description")
        .createdBy("user1")
        .isCreatedByInternalUser(true)
        .modifiedBy("user2")
        .isModifiedByInternalUser(false)
        .docDate(LocalDate.of(2021, 12, 31))
        .cashMvmtDate(LocalDate.of(2022, 1, 4))
        .docDate(LocalDate.of(2021, 12, 31))
        .securityId(3L)
        .custodyTransactionId(123L)
        .assigneeId("ae994834-3b58-11ec-ae29-c53a5392f8a7")
        .assigneeName("Test User")
        .assigneeEmail("test@clearwateranalytics.com")
        .build();
  }
}
