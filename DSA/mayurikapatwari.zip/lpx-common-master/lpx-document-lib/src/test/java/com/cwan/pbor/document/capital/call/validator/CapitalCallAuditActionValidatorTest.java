package com.cwan.pbor.document.capital.call.validator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.SystemUserConstants;
import org.junit.jupiter.api.Test;

class CapitalCallAuditActionValidatorTest {

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenCapitalCallAuditActionIsNull() {
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(null);
    assertTrue(result.isPresent());
    assertEquals("CapitalCallAuditAction is null.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenUserIsNull() {
    var action = CapitalCallAuditAction.builder().documentId(1L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertTrue(result.isPresent());
    assertEquals("User is null.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenDocumentIdIsNull() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    var action = CapitalCallAuditAction.builder().user(user).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertTrue(result.isPresent());
    assertEquals("Document ID is null.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenUserIdIsNull() {
    var user =
        CapitalCallUser.builder().fullName("Test User").email("test.user@example.com").build();
    var action = CapitalCallAuditAction.builder().user(user).documentId(1L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertTrue(result.isPresent());
    assertEquals("User ID is null.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenDocumentIdIsZeroOrLess() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    var action = CapitalCallAuditAction.builder().user(user).documentId(0L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertTrue(result.isPresent());
    assertEquals("Document ID should be greater than 0. Provided value: 0.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenUserIdIsZeroOrLess() {
    var user =
        CapitalCallUser.builder()
            .id(0)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    var action = CapitalCallAuditAction.builder().user(user).documentId(1L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertTrue(result.isPresent());
    assertEquals("User ID is invalid: 0.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenSystemUser() {
    var user =
        CapitalCallUser.builder()
            .id(SystemUserConstants.ID)
            .fullName(SystemUserConstants.FULL_NAME)
            .email(SystemUserConstants.EMAIL)
            .build();
    var action = CapitalCallAuditAction.builder().user(user).documentId(1L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertFalse(result.isPresent());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnError_WhenUserNameOrUserEmailIsNull() {
    var user = CapitalCallUser.builder().id(1).build();
    var action = CapitalCallAuditAction.builder().user(user).documentId(1L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertTrue(result.isPresent());
    assertEquals("User full name is blank, User email is blank.", result.get());
  }

  @Test
  void validateCapitalCallAuditAction_ShouldReturnEmpty_WhenAllFieldsAreValid() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    var action = CapitalCallAuditAction.builder().user(user).documentId(1L).build();
    var result = CapitalCallAuditActionValidator.validateCapitalCallAuditAction(action);
    assertFalse(result.isPresent());
  }
}
