package com.cwan.pbor.document.capital.call.management.transformer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Bank;
import com.cwan.lpx.domain.BankAccount;
import com.cwan.pbor.document.capital.call.management.entity.BankAccountEntity;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import com.cwan.pbor.document.capital.call.management.repository.BankRepository;
import java.time.LocalDateTime;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BankAccountTransformerTest {

  @InjectMocks
  private BankAccountEntityToBankAccountTransformer bankAccountEntityToBankAccountTransformer;

  @InjectMocks
  private BankAccountToBankAccountEntityTransformer bankAccountToBankAccountEntityTransformer;

  @Mock private BankEntityToBankTransformer bankEntityToBankTransformer;
  @Mock private BankRepository bankRepository;

  @Test
  public void testBankAccountEntityToBankAccountTransformer() {
    var bankAccountEntity = mock(BankAccountEntity.class);
    var bankEntity = Bank.builder().bankUuid(String.valueOf(UUID.randomUUID())).build();
    when(bankAccountEntity.getBankAccountUuid()).thenReturn(String.valueOf(UUID.randomUUID()));
    when(bankAccountEntity.getAccountId()).thenReturn(123L);
    when(bankAccountEntity.getAccountName()).thenReturn("accountName");
    when(bankAccountEntity.getAccountNumber()).thenReturn("accountNumber");
    when(bankAccountEntity.getIban()).thenReturn("iban");
    when(bankAccountEntity.getCreatedAt()).thenReturn(LocalDateTime.now());
    when(bankAccountEntity.getCreatedBy()).thenReturn(123L);
    when(bankEntityToBankTransformer.apply(any())).thenReturn(bankEntity);
    var result = bankAccountEntityToBankAccountTransformer.apply(bankAccountEntity);
    assertNotNull(result);
    assertEquals(bankAccountEntity.getAccountId(), result.accountId());
  }

  @Test
  public void testBankAccountToBankAccountEntityTransformer() {
    var bank = Bank.builder().bankUuid(String.valueOf(UUID.randomUUID())).build();
    var bankAccount = BankAccount.builder().bank(bank).build();
    var bankEntity = mock(BankEntity.class);
    when(bankEntity.getBankId()).thenReturn(123L);
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.of(bankEntity));
    var result = bankAccountToBankAccountEntityTransformer.apply(bankAccount);
    assertNotNull(result);
    assertEquals(bankEntity.getBankId(), result.getBankId());
  }

  @Test
  public void testBankAccountToBankAccountEntityTransformer_NoBankFound() {
    var bank = Bank.builder().bankUuid(String.valueOf(UUID.randomUUID())).build();
    var bankAccount = BankAccount.builder().bank(bank).build();
    when(bankRepository.findByBankUuid(any())).thenReturn(Optional.empty());
    assertThrows(
        NoSuchElementException.class,
        () -> bankAccountToBankAccountEntityTransformer.apply(bankAccount));
  }
}
