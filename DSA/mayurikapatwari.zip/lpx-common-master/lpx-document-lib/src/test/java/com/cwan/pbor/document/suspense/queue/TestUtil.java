package com.cwan.pbor.document.suspense.queue;

import com.cwan.lpx.domain.SuspenseQueue;
import com.cwan.pbor.document.suspense.queue.transformer.SuspenseQueueEntityTransformer;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class TestUtil {

  public static SuspenseQueueEntity getSuspenseQueueDocumentEntity() {
    return SuspenseQueueEntity.builder()
        .id(12L)
        .version(1)
        .clientId(1L)
        .clientName("test client")
        .dataForgeAccountId(1L)
        .originalFileName("test file")
        .dataForgeAccountName("test account")
        .dataForgeSecurityId(1L)
        .dataForgeSecurityName("test security")
        .dataForgeClassification("dummy type")
        .documentName("dummy name")
        .assignedTo("dummy assignee")
        .notes("random notes")
        .isCurrent(true)
        .createdOn(LocalDateTime.of(2024, 12, 12, 00, 00, 00))
        .receivedDate(LocalDate.of(2024, 05, 06))
        .build();
  }

  public static SuspenseQueue getSuspenseQueueDocument() {
    return new SuspenseQueueEntityTransformer().apply(getSuspenseQueueDocumentEntity());
  }
}
