package com.cwan.pbor.document.duplicate.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.DocumentRepository;
import com.cwan.pbor.document.duplicate.constant.DuplicateStatus;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateEntity;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateExtEntity;
import com.cwan.pbor.document.duplicate.repository.DocumentDuplicateExtRepository;
import com.cwan.pbor.document.duplicate.repository.DocumentDuplicateRepository;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DocumentDuplicateServiceTest {

  private static DocumentDuplicateEntity createDocDuplicateEntity(Long dupId, Long docId) {
    return DocumentDuplicateEntity.builder()
        .id(dupId)
        .documentId(docId)
        .duplicateStatus(DuplicateStatus.OPEN)
        .build();
  }

  private static DocumentDuplicateExtEntity createDocDuplicateExtEntity(
      Long extId, Long dupId, String canoeId, boolean isCurrent) {
    return DocumentDuplicateExtEntity.builder()
        .id(extId)
        .documentDuplicateId(dupId)
        .canoeId(canoeId)
        .isCurrent(isCurrent)
        .build();
  }

  private static DocumentEntity createDocEntity(Long docId, String canoeId) {
    return DocumentEntity.builder().id(docId).canoeId(canoeId).build();
  }

  @Mock private DocumentRepository documentRepository;
  @Mock private DocumentDuplicateRepository documentDuplicateRepository;
  @Mock private DocumentDuplicateExtRepository documentDuplicateExtRepository;
  @InjectMocks private DocumentDuplicateService documentDuplicateService;

  @Test
  @DisplayName("Returns empty map if documentIds is empty")
  void testGetGroupedDocumentDuplicates_EmptyDocumentIds() {
    var result = documentDuplicateService.getGroupedDocumentDuplicates(Collections.emptyList());
    assertTrue(result.isEmpty(), "Expected an empty result for empty documentIds");
    verifyNoInteractions(
        documentDuplicateRepository, documentRepository, documentDuplicateExtRepository);
  }

  @Test
  @DisplayName("Multiple current ext rows get unmarked except the matching docCanoeId")
  void testGetGroupedDocumentDuplicates_MultipleCurrentExtensions() {
    List<Long> documentIds = List.of(111L);
    List<DocumentDuplicateEntity> duplicates = List.of(createDocDuplicateEntity(1001L, 111L));
    List<DocumentEntity> docs = List.of(createDocEntity(111L, "myCanoe"));
    var ext1 = createDocDuplicateExtEntity(1L, 1001L, "myCanoe", true);
    var ext2 = createDocDuplicateExtEntity(2L, 1001L, "myCanoe", true);
    var ext3 = createDocDuplicateExtEntity(3L, 1001L, "otherCanoe", true);
    var ext4 = createDocDuplicateExtEntity(4L, 1001L, "myCanoe", false);
    when(documentDuplicateRepository.findAllActiveByDocumentIds(documentIds))
        .thenReturn(duplicates);
    when(documentRepository.findAllActiveByIds(anyCollection())).thenReturn(docs);
    when(documentDuplicateExtRepository.findAllActiveByDuplicateIds(anySet()))
        .thenReturn(List.of(ext1, ext2, ext3, ext4));
    var result = documentDuplicateService.getGroupedDocumentDuplicates(documentIds);
    assertFalse(result.isEmpty());
    // We expect repository.saveAllAndFlush(...) to be called with the updated ext
    // rows (the ones turned off).
    ArgumentCaptor<List<DocumentDuplicateExtEntity>> captor = ArgumentCaptor.forClass(List.class);
    verify(documentDuplicateExtRepository, times(1)).saveAllAndFlush(captor.capture());
    var documentDuplicateExtEntities = captor.getValue();
    assertEquals(2, documentDuplicateExtEntities.size(), "Should unmark exactly 2 extension rows");
    assertTrue(documentDuplicateExtEntities.contains(ext2), "ext2 should have been unmarked");
    assertTrue(documentDuplicateExtEntities.contains(ext3), "ext3 should have been unmarked");
    assertFalse(ext2.isCurrent(), "ext2 is no longer current");
    assertFalse(ext3.isCurrent(), "ext3 is no longer current");
    // Check that ext1 is still current
    assertTrue(ext1.isCurrent());
  }

  @Test
  @DisplayName("Multiple current ext rows exist but no match => do nothing and produce empty map")
  void testGetGroupedDocumentDuplicates_MultipleCurrentExtensionsNoMatch() {
    List<Long> documentIds = List.of(222L);
    List<DocumentDuplicateEntity> duplicates = List.of(createDocDuplicateEntity(2001L, 222L));
    List<DocumentEntity> docs = List.of(createDocEntity(222L, "theCanoe"));
    // extA and extB are current, but their canoeId doesn't match "theCanoe"
    var extA = createDocDuplicateExtEntity(10L, 2001L, "foo", true);
    var extB = createDocDuplicateExtEntity(11L, 2001L, "bar", true);
    when(documentDuplicateRepository.findAllActiveByDocumentIds(documentIds))
        .thenReturn(duplicates);
    when(documentRepository.findAllActiveByIds(anyCollection())).thenReturn(docs);
    when(documentDuplicateExtRepository.findAllActiveByDuplicateIds(anySet()))
        .thenReturn(List.of(extA, extB));
    var result = documentDuplicateService.getGroupedDocumentDuplicates(documentIds);
    // Because no extension matches "theCanoe", the service won't unmark anything
    verify(documentDuplicateExtRepository, never()).saveAllAndFlush(anyList());
    // And because none matched, the final result is empty
    assertTrue(
        result.isEmpty(), "Expected an empty map because no ext row matches docCanoeId='theCanoe'");
  }

  @Test
  @DisplayName("Returns empty map if no DocumentDuplicateEntity found")
  void testGetGroupedDocumentDuplicates_NoDocDuplicatesFound() {
    List<Long> documentIds = List.of(10L, 20L);
    when(documentDuplicateRepository.findAllActiveByDocumentIds(documentIds))
        .thenReturn(Collections.emptyList());
    var result = documentDuplicateService.getGroupedDocumentDuplicates(documentIds);
    assertTrue(result.isEmpty());
    verify(documentDuplicateRepository).findAllActiveByDocumentIds(documentIds);
    verify(documentRepository, never()).findAllActiveByIds(anyCollection());
    verify(documentDuplicateExtRepository, never()).findAllActiveByDuplicateIds(anySet());
  }

  @Test
  @DisplayName("Returns empty map if no Documents found matching the duplicates")
  void testGetGroupedDocumentDuplicates_NoDocsFound() {
    List<Long> documentIds = List.of(100L, 200L);
    List<DocumentDuplicateEntity> duplicates =
        List.of(createDocDuplicateEntity(1L, 100L), createDocDuplicateEntity(2L, 200L));
    when(documentDuplicateRepository.findAllActiveByDocumentIds(documentIds))
        .thenReturn(duplicates);
    when(documentRepository.findAllActiveByIds(anyCollection()))
        .thenReturn(Collections.emptyList());
    var result = documentDuplicateService.getGroupedDocumentDuplicates(documentIds);
    assertTrue(result.isEmpty());
    verify(documentDuplicateRepository).findAllActiveByDocumentIds(documentIds);
    verify(documentRepository).findAllActiveByIds(anyCollection());
    verify(documentDuplicateExtRepository, never()).findAllActiveByDuplicateIds(anySet());
  }

  @Test
  @DisplayName("Returns empty map if no ext records are found (duplicates are excluded)")
  void testGetGroupedDocumentDuplicates_NoExtensionRecords() {
    List<Long> documentIds = List.of(101L);
    List<DocumentDuplicateEntity> duplicates = List.of(createDocDuplicateEntity(5L, 101L));
    List<DocumentEntity> docs = List.of(createDocEntity(101L, "canoeA"));
    when(documentDuplicateRepository.findAllActiveByDocumentIds(documentIds))
        .thenReturn(duplicates);
    when(documentRepository.findAllActiveByIds(anyCollection())).thenReturn(docs);
    when(documentDuplicateExtRepository.findAllActiveByDuplicateIds(anySet()))
        .thenReturn(Collections.emptyList());
    var result = documentDuplicateService.getGroupedDocumentDuplicates(documentIds);
    assertTrue(result.isEmpty(), "Result should be empty because there are no extension records");
    verify(documentDuplicateRepository).findAllActiveByDocumentIds(documentIds);
    verify(documentRepository).findAllActiveByIds(anyCollection());
    verify(documentDuplicateExtRepository).findAllActiveByDuplicateIds(anySet());
  }

  @Test
  @DisplayName("docCanoeId is null => skip ensureSingleCurrentRow logic => result is empty")
  void testGetGroupedDocumentDuplicates_NullDocCanoeIdSkipsSingleRowLogic() {
    List<Long> documentIds = List.of(333L);
    List<DocumentDuplicateEntity> duplicates = List.of(createDocDuplicateEntity(3001L, 333L));
    // docCanoeId is null
    List<DocumentEntity> docs = List.of(createDocEntity(333L, null));
    // extX is currently marked
    var extX = createDocDuplicateExtEntity(100L, 3001L, "someCanoe", true);
    when(documentDuplicateRepository.findAllActiveByDocumentIds(documentIds))
        .thenReturn(duplicates);
    when(documentRepository.findAllActiveByIds(anyCollection())).thenReturn(docs);
    when(documentDuplicateExtRepository.findAllActiveByDuplicateIds(anySet()))
        .thenReturn(List.of(extX));
    var result = documentDuplicateService.getGroupedDocumentDuplicates(documentIds);
    // Because docCanoeId is null, the service "skips" ensureSingleCurrentRow
    verify(documentDuplicateExtRepository, never()).saveAllAndFlush(anyList());
    assertTrue(
        result.isEmpty(),
        "Result should be empty because docCanoeId is null and there's no match for extensions.");
    assertTrue(extX.isCurrent(), "extX should remain current because we skipped unmark logic");
  }
}
