package com.cwan.pbor.document.capital.call.management.transformer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.Bank;
import com.cwan.pbor.document.capital.call.management.entity.BankEntity;
import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BankTransformerTest {

  @InjectMocks private BankEntityToBankTransformer bankEntityToBankTransformer;
  @InjectMocks private BankToBankEntityTransformer bankToBankEntityTransformer;

  @Test
  public void testBankEntityToBankTransformer() {
    var bankEntity = mock(BankEntity.class);
    when(bankEntity.getBankUuid()).thenReturn(String.valueOf(UUID.randomUUID()));
    when(bankEntity.getClientId()).thenReturn(123L);
    when(bankEntity.getBankName()).thenReturn("TestBank");
    when(bankEntity.getAbaRoutingNumber()).thenReturn("123456789");
    when(bankEntity.getSwiftChipsCode()).thenReturn("SWIFT123");
    when(bankEntity.getCreatedAt()).thenReturn(LocalDateTime.now());
    when(bankEntity.getCreatedBy()).thenReturn(123L);
    var result = bankEntityToBankTransformer.apply(bankEntity);
    assertNotNull(result);
    assertEquals(bankEntity.getBankUuid(), result.bankUuid());
    assertEquals(bankEntity.getClientId(), result.clientId());
    assertEquals(bankEntity.getBankName(), result.bankName());
    assertEquals(bankEntity.getAbaRoutingNumber(), result.abaRoutingNumber());
    assertEquals(bankEntity.getSwiftChipsCode(), result.swiftChipsCode());
    assertEquals(bankEntity.getCreatedBy(), result.createdBy());
  }

  @Test
  public void testBankToBankEntityTransformer() {
    var bank =
        Bank.builder()
            .bankUuid(String.valueOf(UUID.randomUUID()))
            .clientId(123L)
            .bankName("TestBank")
            .abaRoutingNumber("123456789")
            .swiftChipsCode("SWIFT123")
            .createdBy(123L)
            .build();
    var result = bankToBankEntityTransformer.apply(bank);
    assertNotNull(result);
    assertEquals(bank.clientId(), result.getClientId());
    assertEquals(bank.bankName(), result.getBankName());
    assertEquals(bank.abaRoutingNumber(), result.getAbaRoutingNumber());
    assertEquals(bank.swiftChipsCode(), result.getSwiftChipsCode());
    assertEquals(bank.createdBy(), result.getCreatedBy());
  }
}
