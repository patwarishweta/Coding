package com.cwan.pbor.document.capital.call.transformer;

import static com.cwan.lpx.domain.CapitalCallAction.APPROVE;
import static com.cwan.lpx.domain.CapitalCallAction.REJECT;
import static com.cwan.lpx.domain.CapitalCallStatus.COMPLETED;
import static com.cwan.lpx.domain.CapitalCallStatus.FINAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.INITIAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.NOT_SPECIFIED;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.CapitalCallAction;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallStatus;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.pbor.document.capital.call.entity.CapitalCallAuditEntity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CapitalCallAuditTransformerTest {

  private CapitalCallAuditTransformer capitalCallAuditTransformer;

  @BeforeEach
  void setUp() {
    capitalCallAuditTransformer = new CapitalCallAuditTransformer();
  }

  @Test
  void apply_shouldTransformIndexedEntitiesToCapitalCallAuditLog() {
    // Arrange
    var entities =
        Arrays.asList(
            createEntity(APPROVE, WIRE_CHECK, "New document"),
            createEntity(APPROVE, INITIAL_REVIEW, "Wire check approved"),
            createEntity(APPROVE, FINAL_REVIEW, "Initial review approved 1"),
            createEntity(REJECT, INITIAL_REVIEW, "Final review rejected"),
            createEntity(APPROVE, FINAL_REVIEW, "Initial review approved 2"),
            createEntity(APPROVE, COMPLETED, "Final review approved"));
    var expectedAudits = createExpectedAudits();
    var result = capitalCallAuditTransformer.apply(1L, new ArrayList<>(entities));
    // Assert
    assertThat(result).isNotNull();
    assertThat(result.documentId()).isEqualTo(1L);
    assertThat(result.audit()).containsExactlyElementsOf(expectedAudits);
  }

  private CapitalCallAuditEntity createEntity(
      CapitalCallAction action, CapitalCallStatus status, String comment) {
    return CapitalCallAuditEntity.builder()
        .documentId(1L)
        .action(action)
        .status(status)
        .comment(comment)
        .userId(123)
        .userFullName("Capital Call")
        .userEmail("capital.call@example.com")
        .build();
  }

  private List<CapitalCallAudit> createExpectedAudits() {
    return Arrays.asList(
        createAudit(NOT_SPECIFIED, APPROVE, WIRE_CHECK, "New document"),
        createAudit(WIRE_CHECK, APPROVE, INITIAL_REVIEW, "Wire check approved"),
        createAudit(INITIAL_REVIEW, APPROVE, FINAL_REVIEW, "Initial review approved 1"),
        createAudit(FINAL_REVIEW, REJECT, INITIAL_REVIEW, "Final review rejected"),
        createAudit(INITIAL_REVIEW, APPROVE, FINAL_REVIEW, "Initial review approved 2"),
        createAudit(FINAL_REVIEW, APPROVE, COMPLETED, "Final review approved"));
  }

  private CapitalCallAudit createAudit(
      CapitalCallStatus previousStatus,
      CapitalCallAction action,
      CapitalCallStatus nextStatus,
      String comment) {
    return CapitalCallAudit.builder()
        .previousStatus(previousStatus)
        .action(action)
        .nextStatus(nextStatus)
        .comment(comment)
        .user(
            CapitalCallUser.builder()
                .id(123)
                .fullName("Capital Call")
                .email("capital.call@example.com")
                .build())
        .build();
  }

  @Test
  void apply_shouldHandleEmptyList() {
    var result = capitalCallAuditTransformer.apply(1L, Collections.emptyList());
    // Assert
    assertThat(result).isNotNull();
    assertEquals(1L, result.documentId());
    assertThat(result.audit()).isEmpty();
  }

  @Test
  void apply_shouldHandleSingleEntity() {
    // Arrange
    var entity = createEntity(APPROVE, WIRE_CHECK, "New document");
    var result = capitalCallAuditTransformer.apply(1L, Collections.singletonList(entity));
    // Assert
    assertThat(result).isNotNull();
    assertThat(result.documentId()).isEqualTo(1L);
    assertThat(result.audit().size()).isEqualTo(1);
  }
}
