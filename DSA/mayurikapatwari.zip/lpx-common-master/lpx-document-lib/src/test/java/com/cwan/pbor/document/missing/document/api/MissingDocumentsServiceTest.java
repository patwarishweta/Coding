package com.cwan.pbor.document.missing.document.api;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.missing.document.TestUtil;
import com.cwan.pbor.document.missing.document.api.impl.MissingDocumentsServiceImpl;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentsEntity;
import com.cwan.pbor.document.missing.document.repository.MissingDocumentsRepository;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentsEntityTransformer;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentsTransformer;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
public class MissingDocumentsServiceTest {
  @Mock private MissingDocumentsRepository missingDocumentsRepository;
  private MissingDocumentsService missingDocumentsService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    missingDocumentsService =
        new MissingDocumentsServiceImpl(
            missingDocumentsRepository,
            new MissingDocumentsTransformer(),
            new MissingDocumentsEntityTransformer());
  }

  @Test
  void test_getAllMissingDocumentsUsingAccountIdAndSecurityId() {
    when(missingDocumentsRepository.findAllByAccountIdInAndSecurityIdIn(
            List.of(1234L), List.of(1235L)))
        .thenReturn(List.of(TestUtil.getMissingDocumentsEntity()));
    List<MissingDocuments> actualMissingDocuments =
        missingDocumentsService.getAllMissingDocumentsUsingAccountIdInAndSecurityIdIn(
            List.of(1234L), List.of(1235L));
    Assertions.assertEquals(List.of(TestUtil.getMissingDocuments()), actualMissingDocuments);
  }

  @Test
  void test_getAllMissingDocumentsUsingAccountId() {
    when(missingDocumentsRepository.findAllByAccountIdIn(List.of(1234L)))
        .thenReturn(List.of(TestUtil.getMissingDocumentsEntity()));
    List<MissingDocuments> actualMissingDocuments =
        missingDocumentsService.getAllMissingDocumentsUsingAccountIdIn(List.of(1234L));
    Assertions.assertEquals(List.of(TestUtil.getMissingDocuments()), actualMissingDocuments);
  }

  @Test
  void test_getAllMissingDocumentsByCategory() {
    when(missingDocumentsRepository.retrieveAllMissingDocumentsByCategory(
            MissingDocumentStatus.MISSING))
        .thenReturn(List.of(TestUtil.getMissingDocumentsEntity()));
    List<MissingDocuments> actualMissingDocuments =
        missingDocumentsService.getAllMissingDocumentsByCategory(MissingDocumentStatus.MISSING);
    Assertions.assertEquals(List.of(TestUtil.getMissingDocuments()), actualMissingDocuments);
  }

  @Test
  void test_addMissingDocuments() {
    when(missingDocumentsRepository.saveAndFlush(any(MissingDocumentsEntity.class)))
        .thenReturn(TestUtil.getMissingDocumentsEntity());
    MissingDocuments missingDocuments = TestUtil.getMissingDocuments();
    missingDocuments.setId(null);
    Assertions.assertEquals(
        List.of(TestUtil.getMissingDocuments()),
        missingDocumentsService.addMissingDocuments(Set.of(missingDocuments)));
  }
}
