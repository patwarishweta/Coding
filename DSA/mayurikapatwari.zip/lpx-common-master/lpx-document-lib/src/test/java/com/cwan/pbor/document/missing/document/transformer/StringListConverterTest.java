package com.cwan.pbor.document.missing.document.transformer;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

import com.cwan.pbor.document.missing.document.MissingDocumentException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

class StringListConverterTest {

  private ObjectMapper objectMapper;
  private StringListConverter stringListConverter;

  @BeforeEach
  void setup() {
    MockitoAnnotations.openMocks(this);
    objectMapper = new ObjectMapper();
    stringListConverter = new StringListConverter(objectMapper);
  }

  @Test
  void testConvertToDatabaseColumn() {
    List<String> stringList = Arrays.asList("test1", "test2", "test3");
    String expectedString = "[\"test1\",\"test2\",\"test3\"]";

    String actualString = stringListConverter.convertToDatabaseColumn(stringList);

    Assertions.assertEquals(expectedString, actualString);
  }

  @Test
  void testConvertToEntityAttribute() {
    String string = "[\"test1\",\"test2\",\"test3\"]";
    List<String> expectedStringList = Arrays.asList("test1", "test2", "test3");

    List<String> actualStringList = stringListConverter.convertToEntityAttribute(string);

    Assertions.assertEquals(expectedStringList, actualStringList);
  }

  @Test
  void testConvertToDatabaseColumnWithException() throws JsonProcessingException {
    List<String> stringList = Arrays.asList("test1", "test2", "test3");
    objectMapper = mock(ObjectMapper.class);
    stringListConverter = new StringListConverter(objectMapper);
    doThrow(new JsonProcessingException("") {}).when(objectMapper).writeValueAsString(stringList);
    assertThrows(
        MissingDocumentException.class,
        () -> stringListConverter.convertToDatabaseColumn(stringList));
  }

  @Test
  void testConvertToEntityAttributeWithException() throws JsonProcessingException {
    String string = "[\"test1\",\"test2\",\"test3\"]";
    objectMapper = mock(ObjectMapper.class);
    stringListConverter = new StringListConverter(objectMapper);
    doThrow(new JsonProcessingException("") {})
        .when(objectMapper)
        .readValue(any(String.class), any(TypeReference.class));
    assertThrows(
        MissingDocumentException.class, () -> stringListConverter.convertToEntityAttribute(string));
  }
}
