package com.cwan.pbor.document;

import static com.cwan.pbor.document.TestUtil.getDocument;
import static com.cwan.pbor.document.TestUtil.getDocumentEntity;
import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import com.cwan.pbor.document.capital.call.service.CapitalCallService;
import jakarta.persistence.EntityNotFoundException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class DocumentServiceTest {

  private static final DocumentRepository mockDocumentRepository =
      Mockito.mock(DocumentRepository.class);
  private static final CapitalCallService mockCapitalCallService =
      Mockito.mock(CapitalCallService.class);
  private final DocumentEntityTransformer documentEntityTransformer =
      Mockito.mock(DocumentEntityTransformer.class);
  private final DocumentTransformer documentTransformer = Mockito.mock(DocumentTransformer.class);
  private DocumentService documentService;
  private static final Long DOCUMENT_ID = 1L;
  private static final Set<Long> ACCOUNT_IDS = Set.of(1L, 2L);
  private static final Set<Long> ACCOUNTS = Set.of(1L, 2L);
  private static final DocumentEntity DOCUMENT_ENTITY = getDocumentEntity(DOCUMENT_ID);
  private static final List<DocumentEntity> DOCUMENT_ENTITY_LIST = List.of(DOCUMENT_ENTITY);
  private static final Document DOCUMENT = getDocument(DOCUMENT_ID);
  private static final Long ACCOUNT_ID = 134L;
  private static final String CANOE_ID = "134L";
  private static final Long SECURITY_ID = 456L;
  private static final LocalDate DOC_DATE = LocalDate.now();
  private static final Long CUSTODY_TRANSACTION_ID = 1L;
  private static final String NAME = "testFile";
  private static final String RAW_DATA_CLOUD_STORAGE_ID = "newRawDataCloudStorageId";
  private static final LocalDateTime RAW_DATA_MODIFIED_ON = LocalDateTime.now();
  private static final String SOURCE = "Nexla";

  @BeforeEach
  void before_each() {
    when(documentTransformer.apply(eq(DOCUMENT_ENTITY))).thenReturn(DOCUMENT);
    when(documentEntityTransformer.apply(eq(DOCUMENT))).thenReturn(DOCUMENT_ENTITY);
    documentService =
        new DocumentService(
            mockDocumentRepository,
            documentEntityTransformer,
            documentTransformer,
            mockCapitalCallService);
  }

  @Test
  void should_add_document_successfully() {
    when(mockDocumentRepository.saveAndFlush(any(DocumentEntity.class)))
        .thenReturn(DOCUMENT_ENTITY);
    documentService.addDocuments(Set.of(getDocument(null))).subscribe(this::assertSuccessResponse);
  }

  @Test
  void should_update_Document_with_updated_document_passed_in_updateDocumentInfo() {
    when(documentTransformer.apply(eq(DOCUMENT_ENTITY))).thenReturn(DOCUMENT);
    when(documentEntityTransformer.apply(eq(DOCUMENT))).thenReturn(DOCUMENT_ENTITY);
    when(mockDocumentRepository.saveAndFlush(any(DocumentEntity.class)))
        .thenReturn(DOCUMENT_ENTITY);
    when(mockDocumentRepository.findAllById(eq(Set.of(DOCUMENT_ID))))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    Set<Document> expected = Set.of(DOCUMENT);
    var actualResponse =
        documentService.updateDocumentInfo(expected).collect(Collectors.toSet()).block();
    assertEquals(expected, actualResponse);
  }

  @Test
  void should_not_add_document_if_id_is_given() {
    documentService.addDocuments(Set.of(getDocument(1L))).subscribe(Assertions::assertNull);
  }

  @Test
  void should_successfully_get_document_by_account_and_date() {
    var date = LocalDate.of(2022, 1, 1);
    when(mockDocumentRepository.findAllByAccountIdInAndDocDateEqualsAndIsDisabledFalse(
            ACCOUNT_IDS, date))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService.getDocumentsByAccountAndDate(ACCOUNT_IDS, date).blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_account() {
    when(mockDocumentRepository.findAllByAccountIdIn(ACCOUNT_IDS))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse = documentService.getDocumentsByAccountId(ACCOUNT_IDS).blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_id() {
    when(mockDocumentRepository.findById(DOCUMENT_ID)).thenReturn(Optional.of(DOCUMENT_ENTITY));
    var actualResponse = documentService.getDocumentById(DOCUMENT_ID).block();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_received_begin_and_end_date() {
    var beginDate = LocalDate.of(2022, 1, 1);
    var endDate = LocalDate.of(2022, 10, 10);
    when(mockDocumentRepository.findAllByAccountIdInAndReceivedDateIsBetweenAndIsDisabledFalse(
            ACCOUNT_IDS, beginDate, endDate))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountsAndReceivedDateBetween(ACCOUNT_IDS, beginDate, endDate)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_received_begin_and_end_date_and_types() {
    var beginDate = LocalDate.of(2022, 1, 1);
    var endDate = LocalDate.of(2022, 10, 10);
    var types = Arrays.asList("Capital Call Notice", "Capital Account Statement");
    when(mockDocumentRepository
            .findAllByAccountIdInAndReceivedDateIsBetweenAndTypeInAndIsDisabledFalse(
                ACCOUNT_IDS, beginDate, endDate, types))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountsAndReceivedDateBetweenAndTypes(
                ACCOUNT_IDS, beginDate, endDate, types)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_document_begin_and_end_date() {
    var beginDate = LocalDate.of(2022, 1, 1);
    var endDate = LocalDate.of(2022, 10, 10);
    when(mockDocumentRepository.findAllByAccountIdInAndDocDateIsBetweenAndIsDisabledFalse(
            ACCOUNT_IDS, beginDate, endDate))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountsAndDocumentDateBetween(ACCOUNT_IDS, beginDate, endDate)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_account_id_and_file_name_received_date() {
    var receivedDate = LocalDate.of(2022, 10, 10);
    when(mockDocumentRepository.findAllByAccountIdAndFileNameAndReceivedDateAndIsDisabledFalse(
            1L, "fileName", receivedDate))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountIdAndFileNameAndReceivedDate(1L, "fileName", receivedDate)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_file_name() {
    when(mockDocumentRepository.findTop1ByFileNameAndIsDisabledFalse("fileName"))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse = documentService.getDocumentByFileName("fileName").blockFirst();
    assertSuccessResponse(actualResponse);
  }

  private void assertSuccessResponse(final Document actualResponse) {
    assertNotNull(actualResponse);
    assertEquals(DocumentServiceTest.DOCUMENT, actualResponse);
  }

  @Test
  void should_successfully_get_document_by_period_end_date() {
    var periodStartDate = LocalDate.of(2022, 1, 1);
    var periodEndDate = LocalDate.of(2022, 10, 10);
    when(mockDocumentRepository.findAllByAccountIdInAndPeriodEndDateBetweenAndIsDisabledFalse(
            ACCOUNT_IDS, periodStartDate, periodEndDate))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountsAndPeriodEndDateBetween(
                ACCOUNT_IDS, periodStartDate, periodEndDate)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_cash_movement_date() {
    var cashMvmtStartDate = LocalDate.of(2022, 1, 1);
    var cashMvmtEndDate = LocalDate.of(2022, 10, 10);
    when(mockDocumentRepository.findAllByAccountIdInAndCashMvmtDateBetweenAndIsDisabledFalse(
            ACCOUNT_IDS, cashMvmtStartDate, cashMvmtEndDate))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountsAndCashMvmtDateBetween(
                ACCOUNT_IDS, cashMvmtStartDate, cashMvmtEndDate)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_successfully_get_document_by_cash_movement_date_and_types() {
    var cashMvmtStartDate = LocalDate.of(2022, 1, 1);
    var cashMvmtEndDate = LocalDate.of(2022, 10, 10);
    var types = Arrays.asList("Capital Call Notice", "Capital Account Statement");
    when(mockDocumentRepository
            .findAllByAccountIdInAndCashMvmtDateBetweenAndTypeInAndIsDisabledFalse(
                ACCOUNT_IDS, cashMvmtStartDate, cashMvmtEndDate, types))
        .thenReturn(Set.of(DOCUMENT_ENTITY));
    var actualResponse =
        documentService
            .getDocumentsByAccountsAndCashMvmtDateBetweenAndTypes(
                ACCOUNT_IDS, cashMvmtStartDate, cashMvmtEndDate, types)
            .blockFirst();
    assertSuccessResponse(actualResponse);
  }

  @Test
  void should_get_documents_by_ids() {
    var documentIds = Set.of(DOCUMENT_ID);
    when(mockDocumentRepository.findAllByIdIn(eq(documentIds))).thenReturn(DOCUMENT_ENTITY_LIST);
    var actual = documentService.getDocumentsByIds(documentIds).collectList().block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_documents_by_ids_non_reactive() {
    var documentIds = Set.of(DOCUMENT_ID);
    when(mockDocumentRepository.findAllByIdIn(eq(documentIds))).thenReturn(DOCUMENT_ENTITY_LIST);
    var actual = documentService.getDocumentsByIdsNonReactive(documentIds);
    assertEquals(Set.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_active_documents_by_accountId_and_FileName() {
    when(mockDocumentRepository
            .findAllByAccountIdAndFileNameContainingIgnoreCaseAndIsDisabledIsFalse(
                eq(DOCUMENT_ID), eq(NAME)))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllActiveDocumentsByAccountIdAndFileName(DOCUMENT_ID, NAME)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_active_documents_by_directoryId() {
    var directoryId = DOCUMENT_ID;
    when(mockDocumentRepository.findAllByDirectoryIdAndIsDisabledIsFalse(eq(directoryId)))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService.getAllActiveDocumentsByDirectoryId(directoryId).collectList().block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_documents_by_accountId_and_is_disabled() {
    when(mockDocumentRepository.findAllByAccountIdInAndIsDisabled(ACCOUNT_IDS, false))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllDocumentsByAccountIdAndIsDisabled(ACCOUNT_IDS, false)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_documents_by_accountId_and_is_disabled_and_between() {
    when(mockDocumentRepository.findAllByAccountIdAndIsDisabledAndCreatedOnBetween(
            ACCOUNTS, false, DOC_DATE.atStartOfDay(), DOC_DATE.atStartOfDay()))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllDocumentsByAccountIdsAndIsDisabledAndCreatedOnBetween(
                ACCOUNTS, false, DOC_DATE, DOC_DATE)
            .stream()
            .toList();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_active_documents_without_directory_by_accountId() {
    when(mockDocumentRepository.findAllByAccountIdAndDirectoryIdIsNullAndIsDisabledIsFalse(
            ACCOUNT_ID))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllActiveDocumentsWithoutDirectoryByAccountId(ACCOUNT_ID)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_active_documents_by_accountId_and_canoeId() {
    when(mockDocumentRepository.findAllByAccountIdAndCanoeId(ACCOUNT_ID, CANOE_ID))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllDocumentsByAccountIdAndCanoeId(ACCOUNT_ID, CANOE_ID)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_documents_by_canoeId() {
    when(mockDocumentRepository.findByCanoeId(CANOE_ID)).thenReturn(DOCUMENT_ENTITY_LIST);
    var actual = documentService.getDocumentsByCanoeId(CANOE_ID);
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void testCapitalCallServiceFails() {
    // Create and start a ListAppender
    ListAppender<ILoggingEvent> listAppender = new ListAppender<>();
    listAppender.start();
    // Get the Logger and add the appender to it.
    Logger logger = (Logger) LoggerFactory.getLogger(DocumentService.class);
    logger.addAppender(listAppender);
    DocumentEntity documentEntity = new DocumentEntity();
    when(mockDocumentRepository.saveAndFlush(any())).thenReturn(documentEntity);
    when(documentEntityTransformer.apply(any())).thenReturn(documentEntity);
    when(documentTransformer.apply(any())).thenReturn(new Document());
    doThrow(new RuntimeException("Error while creating Capital Call"))
        .when(mockCapitalCallService)
        .createCapitalCall(any(), anyBoolean());
    Document document = Document.builder().build();
    StepVerifier.create(documentService.addDocuments(Set.of(document)))
        .expectNext(document)
        .verifyComplete();
    // Using Awaitility to wait for the error log message
    await()
        .atMost(5, TimeUnit.SECONDS)
        .until(
            () ->
                listAppender.list.stream()
                    .anyMatch(
                        e ->
                            e.getMessage().contains("Error while creating Capital Call")
                                && (e.getLevel() == Level.ERROR)));
    // Assert that createCapitalCall was called once
    verify(mockCapitalCallService, times(1)).createCapitalCall(documentEntity, true);
  }

  @Test
  void should_get_all_active_documents_by_accountIdIn_and_securityId_and_docdate() {
    when(mockDocumentRepository.findAllByAccountIdInAndSecurityIdAndDocDateAndIsDisabledFalse(
            List.of(ACCOUNT_ID), SECURITY_ID, DOC_DATE))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllActiveDocumentsByAccountIdInAndSecurityIdAndDocDate(
                List.of(ACCOUNT_ID), SECURITY_ID, DOC_DATE)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_active_documents_by_custodyTransactionId() {
    when(mockDocumentRepository.findAllByCustodyTransactionIdAndIsDisabledFalse(
            CUSTODY_TRANSACTION_ID))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getAllActiveDocumentsByCustodyTransactionId(CUSTODY_TRANSACTION_ID)
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void should_get_all_active_documents_for_today() {
    when(mockDocumentRepository.findAllActiveDocumentsForToday()).thenReturn(DOCUMENT_ENTITY_LIST);
    var actual = documentService.getAllActiveDocumentsForToday().collectList().block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void test_getDocumentByCreatedOnAfter() {
    when(mockDocumentRepository.findAllByCreatedOnAfter(any())).thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService.getDocumentByCreatedOnAfter(LocalDateTime.now()).collectList().block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void test_getDocumentsBySecurityIdsIn() {
    when(mockDocumentRepository.findAllBySecurityIdIn(any())).thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService.getDocumentsBySecurityIdsIn(List.of(SECURITY_ID)).collectList().block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void test_getByAccountIdInAndSecurityIdAndDocDateAndType() {
    when(mockDocumentRepository.findAllByAccountIdInAndSecurityIdAndDocDateAndType(
            any(), any(), any(), any()))
        .thenReturn(DOCUMENT_ENTITY_LIST);
    var actual =
        documentService
            .getByAccountIdInAndSecurityIdAndDocDateAndType(
                List.of(ACCOUNT_ID), SECURITY_ID, DOC_DATE, "Capital Call")
            .collectList()
            .block();
    assertEquals(List.of(DOCUMENT), actual);
  }

  @Test
  void updateDocument_Success() {
    var existingDocumentEntity = new DocumentEntity();
    existingDocumentEntity.setId(DOCUMENT_ID);
    var updatedDocumentEntity = new DocumentEntity();
    updatedDocumentEntity.setId(DOCUMENT_ID);
    updatedDocumentEntity.setRawDataCloudStorageId(RAW_DATA_CLOUD_STORAGE_ID);
    updatedDocumentEntity.setRawDataModifiedOn(RAW_DATA_MODIFIED_ON);
    updatedDocumentEntity.setSource(SOURCE);
    var expectedDocument =
        Document.builder()
            .id(DOCUMENT_ID)
            .rawDataCloudStorageId(RAW_DATA_CLOUD_STORAGE_ID)
            .rawDataModifiedOn(RAW_DATA_MODIFIED_ON)
            .source(SOURCE)
            .build();
    when(mockDocumentRepository.findById(DOCUMENT_ID))
        .thenReturn(Optional.of(existingDocumentEntity));
    when(mockDocumentRepository.save(any(DocumentEntity.class))).thenReturn(updatedDocumentEntity);
    when(documentTransformer.apply(updatedDocumentEntity)).thenReturn(expectedDocument);
    var result =
        documentService.updateDocument(
            DOCUMENT_ID, RAW_DATA_CLOUD_STORAGE_ID, RAW_DATA_MODIFIED_ON, SOURCE);
    assertEquals(expectedDocument.getId(), result.getId());
    assertEquals(expectedDocument.getRawDataCloudStorageId(), result.getRawDataCloudStorageId());
    assertEquals(expectedDocument.getRawDataModifiedOn(), result.getRawDataModifiedOn());
    assertEquals(expectedDocument.getSource(), result.getSource());
    verify(mockDocumentRepository).save(any(DocumentEntity.class));
    verify(documentTransformer).apply(updatedDocumentEntity);
  }

  @Test
  void updateDocument_EntityNotFoundException() {
    when(mockDocumentRepository.findById(DOCUMENT_ID)).thenReturn(Optional.empty());
    assertThrows(
        EntityNotFoundException.class,
        () ->
            documentService.updateDocument(
                DOCUMENT_ID, RAW_DATA_CLOUD_STORAGE_ID, RAW_DATA_MODIFIED_ON, SOURCE));
    verify(mockDocumentRepository).findById(DOCUMENT_ID);
  }

  @Test
  void getMostRecentDocumentByCriteria_DocumentFound() {
    var accountId = 1L;
    var securityId = 2L;
    var canoeId = "testCanoeId";
    var sources = new HashSet<>(Arrays.asList("Prometheus", "Nexla"));
    var documentEntity = new DocumentEntity();
    documentEntity.setId(1L);
    var expectedDocument = new Document();
    expectedDocument.setId(1L);
    when(mockDocumentRepository.findMostRecentDocumentByCriteria(
            accountId, securityId, canoeId, sources))
        .thenReturn(Optional.of(documentEntity));
    when(documentTransformer.apply(documentEntity)).thenReturn(expectedDocument);
    var result =
        documentService.getMostRecentDocumentByCriteria(accountId, securityId, canoeId, sources);
    assertTrue(result.isPresent(), "Expected document was not found");
    assertEquals(
        expectedDocument.getId(),
        result.get().getId(),
        "Document ID does not match expected value");
    verify(mockDocumentRepository)
        .findMostRecentDocumentByCriteria(accountId, securityId, canoeId, sources);
    verify(documentTransformer).apply(documentEntity);
  }

  @Test
  void getMostRecentDocumentByCriteria_NoDocumentFound() {
    var accountId = 1L;
    var securityId = 2L;
    var canoeId = "testCanoeId";
    var sources = new HashSet<>(Arrays.asList("Prometheus", "Nexla"));
    when(mockDocumentRepository.findMostRecentDocumentByCriteria(
            accountId, securityId, canoeId, sources))
        .thenReturn(Optional.empty());
    var result =
        documentService.getMostRecentDocumentByCriteria(accountId, securityId, canoeId, sources);
    assertFalse(result.isPresent(), "Expected no document to be found");
    verify(documentTransformer, never()).apply(any());
  }

  @Test
  void getLatestStatementDatesMap_ShouldReturnCorrectDates() {
    List<Long> accountIds = List.of(1L, 2L);
    Object[] result1 = {1L, 100L, LocalDate.of(2024, 1, 15)};
    Object[] result2 = {2L, 101L, LocalDate.of(2024, 1, 20)};
    List<Object[]> results = List.of(result1, result2);
    Map<String, LocalDate> expectedMap = new HashMap<>();
    expectedMap.put("1-100", LocalDate.of(2024, 1, 15));
    expectedMap.put("2-101", LocalDate.of(2024, 1, 20));
    when(mockDocumentRepository.findLatestStatementDatesByAccountAndSecurity(
            accountIds, LocalDate.now()))
        .thenReturn(results);
    Map<String, LocalDate> latestStatementDatesMap =
        documentService.getLatestStatementDatesMapBeforeOrEqualProvidedDate(
            accountIds, LocalDate.now());
    assertEquals(expectedMap, latestStatementDatesMap);
  }

  @Test
  void getLatestStatementDatesMap_ShouldSkipNullIds() {
    List<Long> accountIds = List.of(1L);
    LocalDate queryDate = LocalDate.now();
    Object[] result1 = {null, 100L, LocalDate.of(2024, 1, 15)};
    Object[] result2 = {1L, null, LocalDate.of(2024, 1, 20)};
    List<Object[]> results = List.of(result1, result2);
    when(mockDocumentRepository.findLatestStatementDatesByAccountAndSecurity(accountIds, queryDate))
        .thenReturn(results);
    Map<String, LocalDate> latestStatementDatesMap =
        documentService.getLatestStatementDatesMapBeforeOrEqualProvidedDate(accountIds, queryDate);
    assertTrue(latestStatementDatesMap.isEmpty());
  }

  @Test
  void getLatestStatementDatesMap_ShouldSkipZeroValues() {
    List<Long> accountIds = List.of(1L);
    LocalDate queryDate = LocalDate.now();
    Object[] result1 = {0L, 100L, LocalDate.of(2024, 1, 15)};
    Object[] result2 = {1L, 0L, LocalDate.of(2024, 1, 20)};
    List<Object[]> results = List.of(result1, result2);
    when(mockDocumentRepository.findLatestStatementDatesByAccountAndSecurity(accountIds, queryDate))
        .thenReturn(results);
    Map<String, LocalDate> latestStatementDatesMap =
        documentService.getLatestStatementDatesMapBeforeOrEqualProvidedDate(accountIds, queryDate);
    assertTrue(latestStatementDatesMap.isEmpty());
  }

  @Test
  void deleteByIds() {
    documentService.deleteByIds(Set.of(1L, 2L));
    verify(mockDocumentRepository, atLeastOnce()).deleteAllById(any());
  }

  @Test
  void should_return_empty_flux_when_accountIds_is_null() {
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                null,
                Collections.singleton(1L),
                LocalDate.now(),
                LocalDate.now().plusDays(1),
                Collections.emptyList())
            .collectList()
            .block();
    assertTrue(CollectionUtils.isEmpty(result));
  }

  @Test
  void should_return_empty_flux_when_begin_date_is_null() {
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(1L),
                Collections.singleton(1L),
                null,
                LocalDate.now().plusDays(1),
                Collections.emptyList())
            .collectList()
            .block();
    assertTrue(CollectionUtils.isEmpty(result));
  }

  @Test
  void should_return_empty_flux_when_end_date_is_null() {
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(1L),
                Collections.singleton(1L),
                LocalDate.now(),
                null,
                Collections.emptyList())
            .collectList()
            .block();
    assertTrue(CollectionUtils.isEmpty(result));
  }

  @Test
  void should_return_empty_flux_when_accountIds_is_empty() {
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.emptyList(),
                Collections.singleton(1L),
                LocalDate.now(),
                LocalDate.now().plusDays(1),
                Collections.emptyList())
            .collectList()
            .block();
    assertTrue(CollectionUtils.isEmpty(result));
  }

  @Test
  void should_return_empty_flux_when_begin_date_is_after_end_date() {
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(1L),
                Collections.singleton(1L),
                LocalDate.now().plusDays(1),
                LocalDate.now(),
                Collections.emptyList())
            .collectList()
            .block();
    assertTrue(CollectionUtils.isEmpty(result));
  }

  @Test
  void should_filter_documents_by_security_ids() {
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(1);
    Long accountId = 1L;
    Long validSecurityId = 100L;
    Long invalidSecurityId = 200L;
    DocumentEntity doc1 = new DocumentEntity();
    doc1.setSecurityId(validSecurityId);
    DocumentEntity doc2 = new DocumentEntity();
    doc2.setSecurityId(invalidSecurityId);
    Document transformedDoc1 = new Document();
    transformedDoc1.setSecurity(Security.builder().securityId(validSecurityId).build());
    transformedDoc1.setDocumentDate(LocalDate.now());
    when(documentTransformer.apply(doc1)).thenReturn(transformedDoc1);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Arrays.asList(doc1, doc2));
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(accountId),
                Collections.singleton(validSecurityId),
                beginDate,
                endDate,
                Collections.emptyList())
            .collectList()
            .block();
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(validSecurityId, result.get(0).getSecurity().getSecurityId());
  }

  @Test
  void should_filter_documents_by_excluded_sources() {
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(1);
    Long accountId = 1L;
    DocumentEntity doc1 = new DocumentEntity();
    doc1.setSource("SOURCE1");
    DocumentEntity doc2 = new DocumentEntity();
    doc2.setSource("SOURCE2");
    Document transformedDoc2 = new Document();
    transformedDoc2.setSource("SOURCE2");
    transformedDoc2.setDocumentDate(LocalDate.now());
    when(documentTransformer.apply(doc2)).thenReturn(transformedDoc2);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Arrays.asList(doc1, doc2));
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(accountId),
                Collections.emptyList(),
                beginDate,
                endDate,
                Collections.singleton("source1"))
            .collectList()
            .block();
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("SOURCE2", result.get(0).getSource());
  }

  @Test
  void should_handle_null_security_id_in_document() {
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(1);
    Long accountId = 1L;
    Long validSecurityId = 100L;
    DocumentEntity doc1 = new DocumentEntity();
    doc1.setSecurityId(null);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Collections.singletonList(doc1));
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(accountId),
                Collections.singleton(validSecurityId),
                beginDate,
                endDate,
                Collections.emptyList())
            .collectList()
            .block();
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void should_handle_null_source_in_document() {
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(1);
    Long accountId = 1L;
    DocumentEntity doc1 = new DocumentEntity();
    doc1.setSource(null);
    Document transformedDoc1 = new Document();
    transformedDoc1.setSource(null);
    transformedDoc1.setDocumentDate(LocalDate.now());
    when(documentTransformer.apply(doc1)).thenReturn(transformedDoc1);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Collections.singletonList(doc1));
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(accountId),
                Collections.emptyList(),
                beginDate,
                endDate,
                Collections.singleton("source1"))
            .collectList()
            .block();
    assertNotNull(result);
    assertEquals(1, result.size());
    assertNull(result.get(0).getSource());
  }

  @Test
  void should_sort_documents_by_date() {
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(2);
    Long accountId = 1L;
    DocumentEntity doc1 = new DocumentEntity();
    DocumentEntity doc2 = new DocumentEntity();
    Document transformedDoc1 = new Document();
    transformedDoc1.setDocumentDate(LocalDate.now());
    Document transformedDoc2 = new Document();
    transformedDoc2.setDocumentDate(LocalDate.now().plusDays(1));
    when(documentTransformer.apply(doc1)).thenReturn(transformedDoc1);
    when(documentTransformer.apply(doc2)).thenReturn(transformedDoc2);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Arrays.asList(doc1, doc2));
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(accountId),
                Collections.emptyList(),
                beginDate,
                endDate,
                Collections.emptyList())
            .collectList()
            .block();
    assertNotNull(result);
    assertEquals(2, result.size());
    assertTrue(result.get(0).getDocumentDate().isAfter(result.get(1).getDocumentDate()));
  }

  @Test
  void should_handle_null_document_dates_in_sorting() {
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(2);
    Long accountId = 1L;
    DocumentEntity doc1 = new DocumentEntity();
    DocumentEntity doc2 = new DocumentEntity();
    DocumentEntity doc3 = new DocumentEntity();
    Document transformedDoc1 = new Document();
    transformedDoc1.setDocumentDate(null);
    Document transformedDoc2 = new Document();
    transformedDoc2.setDocumentDate(LocalDate.now());
    Document transformedDoc3 = new Document();
    transformedDoc3.setDocumentDate(LocalDate.now().plusDays(1));
    when(documentTransformer.apply(doc1)).thenReturn(transformedDoc1);
    when(documentTransformer.apply(doc2)).thenReturn(transformedDoc2);
    when(documentTransformer.apply(doc3)).thenReturn(transformedDoc3);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Arrays.asList(doc1, doc2, doc3));
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                Collections.singleton(accountId),
                Collections.emptyList(),
                beginDate,
                endDate,
                Collections.emptyList())
            .collectList()
            .block();
    assertNotNull(result);
    assertEquals(3, result.size());
    assertNull(result.get(2).getDocumentDate());
    assertNotNull(result.get(0).getDocumentDate());
    assertNotNull(result.get(1).getDocumentDate());
    assertTrue(result.get(0).getDocumentDate().isAfter(result.get(1).getDocumentDate()));
  }

  @Test
  void should_handle_large_account_ids_list() {
    List<Long> accountIds = IntStream.rangeClosed(1, 1000).mapToObj(Long::valueOf).toList();
    LocalDate beginDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(1);
    when(mockDocumentRepository.findActiveDocumentsByAccountsAndDateRange(
            any(), eq(beginDate), eq(endDate)))
        .thenReturn(Collections.emptyList());
    var result =
        documentService
            .getActiveDocumentsByAccountsSecuritiesAndDateRangeExcludingSources(
                accountIds, Collections.emptyList(), beginDate, endDate, Collections.emptyList())
            .collectList()
            .block();
    assertNotNull(result);
    verify(mockDocumentRepository, atLeast(2))
        .findActiveDocumentsByAccountsAndDateRange(any(), eq(beginDate), eq(endDate));
  }
}
