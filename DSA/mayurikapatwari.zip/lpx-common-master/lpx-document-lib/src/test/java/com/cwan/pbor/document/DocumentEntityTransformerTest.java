package com.cwan.pbor.document;

import static com.cwan.pbor.document.TestUtil.getDocument;
import static com.cwan.pbor.document.TestUtil.getDocumentEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DocumentEntityTransformerTest {

  public static final Long DOCUMENT_ID = 1L;

  @Test
  void should_convert_document_to_document_entity() {
    var expected = getDocumentEntity(DOCUMENT_ID);
    var actual = new DocumentEntityTransformer().apply(getDocument(DOCUMENT_ID));
    assertEquals(expected, actual);
  }
}
