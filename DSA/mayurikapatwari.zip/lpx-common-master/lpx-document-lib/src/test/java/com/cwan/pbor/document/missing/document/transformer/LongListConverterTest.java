package com.cwan.pbor.document.missing.document.transformer;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

import com.cwan.pbor.document.missing.document.MissingDocumentException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

class LongListConverterTest {
  private ObjectMapper objectMapper;
  private LongListConverter longListConverter;

  @BeforeEach
  void setup() {
    MockitoAnnotations.openMocks(this);
    objectMapper = new ObjectMapper();
    longListConverter = new LongListConverter(objectMapper);
  }

  @Test
  void testConvertToDatabaseColumn() {
    List<Long> longList = Arrays.asList(123L, 456L);
    String expectedString = "[123,456]";

    String actualString = longListConverter.convertToDatabaseColumn(longList);

    Assertions.assertEquals(expectedString, actualString);
  }

  @Test
  void testConvertToEntityAttribute() {
    String string = "[123,456]";
    List<Long> expectedLongList = Arrays.asList(123L, 456L);

    List<Long> actualLongList = longListConverter.convertToEntityAttribute(string);

    Assertions.assertEquals(expectedLongList, actualLongList);
  }

  @Test
  void testConvertToDatabaseColumnWithException() throws JsonProcessingException {
    List<Long> longList = Arrays.asList(123L, 456L);
    objectMapper = mock(ObjectMapper.class);
    longListConverter = new LongListConverter(objectMapper);
    doThrow(new JsonProcessingException("") {}).when(objectMapper).writeValueAsString(longList);
    assertThrows(
        MissingDocumentException.class, () -> longListConverter.convertToDatabaseColumn(longList));
  }

  @Test
  void testConvertToEntityAttributeWithException() throws JsonProcessingException {
    String string = "[123,456]";
    objectMapper = mock(ObjectMapper.class);
    longListConverter = new LongListConverter(objectMapper);
    doThrow(new JsonProcessingException("") {})
        .when(objectMapper)
        .readValue(any(String.class), any(TypeReference.class));
    assertThrows(
        MissingDocumentException.class, () -> longListConverter.convertToEntityAttribute(string));
  }
}
