package com.cwan.pbor.document.duplicate.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateEntity;
import com.cwan.pbor.document.duplicate.entity.DocumentDuplicateExtEntity;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class DocumentDuplicateServiceHelperTest {

  private static DocumentDuplicateEntity createDocDuplicateEntity(Long id, Long docId) {
    return DocumentDuplicateEntity.builder()
        .id(id)
        .documentId(docId)
        .tsCreated(LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault()))
        .build();
  }

  private static DocumentEntity createDocEntity(Long docId) {
    return DocumentEntity.builder().id(docId).build();
  }

  private static DocumentDuplicateExtEntity createExt(Long id, Long dupId, boolean isCurrent) {
    return DocumentDuplicateExtEntity.builder()
        .id(id)
        .documentDuplicateId(dupId)
        .isCurrent(isCurrent)
        .canoeId(isCurrent ? "Canoe_Current_" + id : "Canoe_NonCur_" + id)
        .tsCreated(LocalDateTime.ofInstant(Instant.now(), ZoneId.systemDefault()))
        .build();
  }

  @Test
  @DisplayName("Skip if doc is null in docMap")
  void testBuildResultMap_docIsNull() {
    var dd = createDocDuplicateEntity(1L, 101L);
    var docDuplicates = List.of(dd);
    // docMap has no entry for 101 => doc is null
    var docMap = Map.<Long, DocumentEntity>of();
    // extByDupId with some data
    var extA = createExt(10L, 1L, true);
    var extB = createExt(11L, 1L, false);
    var extByDupId = Map.of(1L, List.of(extA, extB));
    var result = DocumentDuplicateServiceHelper.buildResultMap(docDuplicates, docMap, extByDupId);
    // We skip because doc == null => result is empty
    assertTrue(result.isEmpty(), "Should be empty because doc is null");
  }

  @Test
  @DisplayName("Skip if extension list is empty for a duplicate")
  void testBuildResultMap_extIsEmpty() {
    var dd = createDocDuplicateEntity(2L, 202L);
    var docDuplicates = List.of(dd);
    // docMap with a valid doc
    var doc = createDocEntity(202L);
    var docMap = Map.of(202L, doc);
    // extByDupId => returns empty list
    var extByDupId = Map.of(2L, Collections.<DocumentDuplicateExtEntity>emptyList());
    var result = DocumentDuplicateServiceHelper.buildResultMap(docDuplicates, docMap, extByDupId);
    // We skip because extension list is empty
    assertTrue(result.isEmpty(), "Should be empty because extension list is empty");
  }

  @Test
  @DisplayName(
      "Happy path: doc is not null, at least one current extension, and at least one non-current => produce entry")
  void testBuildResultMap_happyPath() {
    var dd = createDocDuplicateEntity(5L, 505L);
    var docDuplicates = List.of(dd);
    var doc = createDocEntity(505L);
    var docMap = Map.of(505L, doc);
    // One current, one non-current
    var extCur = createExt(50L, 5L, true);
    var extNonCur = createExt(51L, 5L, false);
    var extByDupId = Map.of(5L, List.of(extCur, extNonCur));
    var result = DocumentDuplicateServiceHelper.buildResultMap(docDuplicates, docMap, extByDupId);
    // We expect exactly 1 entry in the map
    assertFalse(result.isEmpty(), "Should NOT be empty because we meet all conditions");
    assertEquals(1, result.size(), "Should only have one DocumentDuplicateGroupKey in the result");
    var entry = result.entrySet().iterator().next();
    var key = entry.getKey();
    var canoes = entry.getValue();
    // The key is built from doc, dd, extCur
    assertEquals(dd.getId(), key.getDocumentDuplicateId());
    assertEquals(doc.getId(), key.getDocumentId());
    // The current canoe ID should match the current ext
    assertEquals(extCur.getCanoeId(), key.getCurrentCanoeId());
    // The set should contain the non-current canoes
    assertEquals(1, canoes.size(), "We should have 1 non-current canoe in the set");
    var nonCurrentCanoe = canoes.first();
    assertEquals(extNonCur.getCanoeId(), nonCurrentCanoe.getDuplicateCanoeId());
  }

  @Test
  @DisplayName("Skip if there is no current extension")
  void testBuildResultMap_noCurrentExtension() {
    var dd = createDocDuplicateEntity(3L, 303L);
    var docDuplicates = List.of(dd);
    // docMap with a valid doc
    var doc = createDocEntity(303L);
    var docMap = Map.of(303L, doc);
    // extByDupId => all are non-current
    var extA = createExt(30L, 3L, false);
    var extB = createExt(31L, 3L, false);
    var extByDupId = Map.of(3L, List.of(extA, extB));
    var result = DocumentDuplicateServiceHelper.buildResultMap(docDuplicates, docMap, extByDupId);
    // We skip because currentExt is null
    assertTrue(result.isEmpty(), "Should be empty because no extension is current");
  }

  @Test
  @DisplayName("Skip if all extensions are current or there's no non-current extension")
  void testBuildResultMap_noNonCurrentExtensions() {
    var dd = createDocDuplicateEntity(4L, 404L);
    var docDuplicates = List.of(dd);
    var doc = createDocEntity(404L);
    var docMap = Map.of(404L, doc);
    // extA & extB are both current => nonCurrents is empty
    var extA = createExt(40L, 4L, true);
    var extB = createExt(41L, 4L, true);
    var extByDupId = Map.of(4L, List.of(extA, extB));
    var result = DocumentDuplicateServiceHelper.buildResultMap(docDuplicates, docMap, extByDupId);
    // We skip because nonCurrents is empty
    assertTrue(result.isEmpty(), "Should be empty because there's no non-current extension");
  }
}
