package com.cwan.pbor.document.util;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cwan.lpx.domain.FileNameData;
import java.time.LocalDate;
import lombok.Data;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class DocumentFileNameUtilsTest {

  @Data
  static class FakeFileNameData implements FileNameData {

    private final String fileType;
    private final String investment;
    private final String entity;
    private final String documentType;
    private final LocalDate dataDate;
    private String account;
  }

  @Test
  @DisplayName("Blank or only special chars in extension => default to pdf")
  void testGetFileName_BlankOrSpecialExtension() {
    var data = new FakeFileNameData("   !!! ", "Invest@!", "Ent##", "", LocalDate.of(2022, 12, 31));
    var fileName = DocumentFileNameUtils.getFileName(data);
    // The sanitized extension is blank => default "pdf"
    assertTrue(fileName.endsWith(".pdf"));
  }

  @Test
  @DisplayName("If dataDate is null => fallback to LocalDate.now() in getFileName()")
  void testGetFileName_DataDateNullUsesNow() {
    var data = new FakeFileNameData("xlsx", "In-vest", "EntityOfSorts", "Doc", null);
    // The date part will be "today" so we can't predict the exact string, but we
    // can check some portion
    var fileName = DocumentFileNameUtils.getFileName(data);
    assertTrue(
        fileName.startsWith("In-vest_EntityOfSorts_Doc_"), "Should contain these components");
    // definitely ends with .xlsx
    assertTrue(fileName.endsWith(".xlsx"), "Should end with .xlsx");
  }

  @Test
  @DisplayName("If entity is blank => fallback to account in getFileName()")
  void testGetFileName_EntityBlankFallBackToAccount() {
    var data =
        new FakeFileNameData("txt", "INVESTMENT", "   ", "Document", LocalDate.of(2022, 10, 10));
    data.setAccount("TheAccount");
    var fileName = DocumentFileNameUtils.getFileName(data);
    // Because entity is blank, we used "TheAccount"
    assertTrue(fileName.contains("TheAccount"), "Should fallback to account");
    assertTrue(fileName.endsWith(".txt"));
  }

  @Test
  @DisplayName("Normal usage of getFileName() => happy path")
  void testGetFileName_HappyPath() {
    var data =
        new FakeFileNameData(
            "pdf", "MyInvestment", "  MyEntity   ", "DocumentType", LocalDate.of(2023, 3, 15));
    data.setAccount(" MyAccount ");
    var fileName = DocumentFileNameUtils.getFileName(data);
    // The final file name is built with the extension (pdf) and sanitized
    // E.g. MyInvestment_MyEntity_DocumentType_03-15-2023.pdf (with potential
    // hyphens if there's punctuation).
    // Because we do not have punctuation in the components, it might just become:
    // "MyInvestment_MyEntity_DocumentType_03-15-2023.pdf"
    assertTrue(fileName.contains("MyInvestment"), "Should contain 'MyInvestment'");
    assertTrue(fileName.endsWith(".pdf"), "Should end with .pdf");
  }

  @Test
  @DisplayName("If fileExtension is null => default to pdf")
  void testGetFileName_NullExtensionDefaultsToPdf() {
    var data =
        new FakeFileNameData(
            null, "Invest^ment", "   Ent!ty   ", "Doc Type", LocalDate.of(2021, 1, 1));
    data.setAccount("Account**");
    var fileName = DocumentFileNameUtils.getFileName(data);
    // Because extension is null => "pdf"
    assertTrue(fileName.endsWith(".pdf"), "Should end with .pdf");
    // Also check that non-alphanumeric replaced with hyphens -> underscores
    // e.g. "Invest-ment_Ent-ty_Doc-Type_01-01-2021.pdf"
    assertTrue(fileName.contains("Invest-ment"), "Should have replaced ^ with -");
    assertTrue(fileName.contains("Ent-ty"), "Should have replaced ! with -");
    assertTrue(fileName.contains("Doc-Type"), "Should have replaced space with - then cleaned up");
  }

  @Test
  @DisplayName("generateOldFileName() test => uses underscores, doesn't sanitize much")
  void testGetOldFileName() {
    var data =
        new FakeFileNameData(".doc", "Invest**", "Entity**", "Doc Type", LocalDate.of(2020, 5, 5));
    data.setAccount("MyAccount");
    // getOldFileName => (investment + "_" + account + "_" + docType + "_" + date +
    // fileType)
    var oldName = DocumentFileNameUtils.getOldFileName(data);
    // e.g. "Invest**_MyAccount_Doc Type_05-05-2020.doc"
    // then .replace(" ", "_")
    // => "Invest**_MyAccount_Doc_Type_05-05-2020.doc"
    assertTrue(oldName.contains("Invest**"));
    assertTrue(oldName.contains("MyAccount"));
    assertTrue(oldName.contains("Doc_Type"));
    assertTrue(oldName.endsWith(".doc"));
  }

  @Test
  @DisplayName("Private constructor coverage via reflection")
  void testPrivateConstructor() throws Exception {
    var constructor = DocumentFileNameUtils.class.getDeclaredConstructor();
    assertFalse(constructor.canAccess(null), "Constructor should be inaccessible normally");
    constructor.setAccessible(true);
    var instance = constructor.newInstance();
    assertNotNull(instance, "We could instantiate it via reflection");
  }
}
