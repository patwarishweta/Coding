package com.cwan.pbor.document.missing.document.api;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.pbor.document.missing.document.TestUtil;
import com.cwan.pbor.document.missing.document.api.impl.MissingDocumentExpectationsConfigServiceImpl;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationsConfigEntity;
import com.cwan.pbor.document.missing.document.repository.MissingDocumentExpectationsConfigRepository;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentExpectationsConfigEntityTransformer;
import com.cwan.pbor.document.missing.document.transformer.MissingDocumentExpectationsConfigTransformer;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
public class MissingDocumentExpectationsConfigServiceTest {
  @Mock
  private MissingDocumentExpectationsConfigRepository missingDocumentExpectationsConfigRepository;

  private MissingDocumentExpectationsConfigService missingDocumentExpectationsConfigService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    missingDocumentExpectationsConfigService =
        new MissingDocumentExpectationsConfigServiceImpl(
            missingDocumentExpectationsConfigRepository,
            new MissingDocumentExpectationsConfigTransformer(),
            new MissingDocumentExpectationsConfigEntityTransformer());
  }

  @Test
  void test_getAllMissingDocumentExpectationsConfigBySecurityIds() {
    when(missingDocumentExpectationsConfigRepository.findAllBySecurityIdIn(List.of(123L, 124L)))
        .thenReturn(List.of(TestUtil.getMissingDocumentExpectationsConfigEntity()));
    List<MissingDocumentExpectationsConfig> missingDocumentExpectationsConfigs =
        missingDocumentExpectationsConfigService
            .getAllMissingDocumentExpectationsConfigBySecurityIds(List.of(123L, 124L));
    Assertions.assertEquals(
        List.of(TestUtil.getMissingDocumentExpectationsConfig()),
        missingDocumentExpectationsConfigs);
  }

  @Test
  void test_addMissingDocumentExpectationsConfig() {
    when(missingDocumentExpectationsConfigRepository.saveAndFlush(
            any(MissingDocumentExpectationsConfigEntity.class)))
        .thenReturn(TestUtil.getMissingDocumentExpectationsConfigEntity());
    MissingDocumentExpectationsConfig missingDocumentExpectationsConfig =
        TestUtil.getMissingDocumentExpectationsConfig();
    missingDocumentExpectationsConfig.setId(null);
    Assertions.assertEquals(
        List.of(TestUtil.getMissingDocumentExpectationsConfig()),
        missingDocumentExpectationsConfigService
            .addMissingDocumentExpectationsConfig(Set.of(missingDocumentExpectationsConfig))
            .collectList()
            .block());
  }
}
