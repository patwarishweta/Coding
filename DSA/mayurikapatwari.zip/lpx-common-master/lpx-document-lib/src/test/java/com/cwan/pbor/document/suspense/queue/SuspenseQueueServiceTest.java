package com.cwan.pbor.document.suspense.queue;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cwan.lpx.domain.SuspenseQueue;
import com.cwan.pbor.document.suspense.queue.api.SuspenseQueueService;
import com.cwan.pbor.document.suspense.queue.api.impl.SuspenseQueueServiceImpl;
import com.cwan.pbor.document.suspense.queue.transformer.SuspenseQueueEntityTransformer;
import com.cwan.pbor.document.suspense.queue.transformer.SuspenseQueueTransformer;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
public class SuspenseQueueServiceTest {

  @Mock private SuspenseQueueRepository suspenseQueueRepository;

  private SuspenseQueueService suspenseQueueService;

  @BeforeEach
  void before_each() {
    MockitoAnnotations.openMocks(this);
    suspenseQueueService =
        new SuspenseQueueServiceImpl(
            suspenseQueueRepository,
            new SuspenseQueueEntityTransformer(),
            new SuspenseQueueTransformer());
  }

  @Test
  void test_getAllSuspenseQueueDocumentReceivedDateInBetweenAndDocumentTypesIn() {

    SuspenseQueueEntity testData = TestUtil.getSuspenseQueueDocumentEntity();

    when(suspenseQueueRepository.findByCreatedOnBetweenAndDocumentTypeInOrDocumentTypeIsNull(
            any(LocalDateTime.class), any(LocalDateTime.class), anyList()))
        .thenReturn(List.of(testData));

    List<SuspenseQueue> result =
        suspenseQueueService.getAllSuspenseQueueDocumentCreatedOnInBetweenAndDocumentTypesIn(
            LocalDateTime.of(2023, 11, 11, 0, 0, 0),
            LocalDateTime.of(2024, 11, 11, 0, 0, 0),
            List.of("Capital Call Distribution", "Capital Account Statement"));

    assertEquals(List.of(TestUtil.getSuspenseQueueDocument()), result);
  }

  @Test
  void test_getAllSuspenseQueueDocumentReceivedDateInBetweenAndDocumentTypesNotIn() {

    SuspenseQueueEntity testData = TestUtil.getSuspenseQueueDocumentEntity();

    when(suspenseQueueRepository.findByCreatedOnBetweenAndDocumentTypeNotIn(
            any(LocalDateTime.class), any(LocalDateTime.class), anyList()))
        .thenReturn(List.of(testData));

    List<SuspenseQueue> result =
        suspenseQueueService.getAllSuspenseQueueDocumentCreatedOnInBetweenAndDocumentTypesNotIn(
            LocalDateTime.of(2023, 11, 11, 0, 0, 0),
            LocalDateTime.of(2024, 11, 11, 0, 0, 0),
            List.of("K1 Statement"));

    assertEquals(List.of(TestUtil.getSuspenseQueueDocument()), result);
  }

  @Test
  void test_getAllSuspenseQueueDocumentReceivedDateInBetweenAndAccountIdstIn() {

    SuspenseQueueEntity testData = TestUtil.getSuspenseQueueDocumentEntity();

    when(suspenseQueueRepository.findAllByCreatedOnBetweenAndUltimateParentIdsIn(
            any(LocalDateTime.class), any(LocalDateTime.class), any()))
        .thenReturn(List.of(testData));

    List<SuspenseQueue> result =
        suspenseQueueService.getAllSuspenseQueueDocumentsByCreatedOnInBetweenAndUltimateParentIdsIn(
            LocalDateTime.of(2023, 11, 11, 0, 0, 0), LocalDateTime.of(2024, 11, 11, 0, 0, 0), null);

    assertEquals(List.of(TestUtil.getSuspenseQueueDocument()), result);
  }

  @Test
  void test_getSuspenseQueueDocumentByIdAndIsCurrent() {

    SuspenseQueueEntity testData = TestUtil.getSuspenseQueueDocumentEntity();

    when(suspenseQueueRepository.findByDocumentIdAndIsCurrent(anyLong(), anyBoolean()))
        .thenReturn(testData);

    SuspenseQueue result = suspenseQueueService.getSuspenseQueueDocumentByIdAndIsCurrent(1L, true);

    assertEquals(TestUtil.getSuspenseQueueDocument(), result);
  }

  @Test
  void test_updateSuspenseQueueDocuments() {
    doNothing()
        .when(suspenseQueueRepository)
        .updateSuspenseQueueEntities(anyList(), anyString(), any(LocalDateTime.class));
    suspenseQueueService.updateSuspenseQueueDocuments(
        List.of(1L), "testUser", LocalDateTime.of(2024, 5, 20, 20, 50, 50));
    verify(suspenseQueueRepository, atLeastOnce())
        .updateSuspenseQueueEntities(
            List.of(1L), "testUser", LocalDateTime.of(2024, 5, 20, 20, 50, 50));
  }

  @Test
  void test_insertSuspenseQueueDocuments() {
    List<SuspenseQueue> suspenseQueueDocuments = List.of(TestUtil.getSuspenseQueueDocument());
    List<SuspenseQueueEntity> suspenseQueueEntityDocuments =
        List.of(TestUtil.getSuspenseQueueDocumentEntity());
    suspenseQueueService.insertSuspenseQueueDocuments(suspenseQueueDocuments);
    verify(suspenseQueueRepository, atLeastOnce()).saveAllAndFlush(suspenseQueueEntityDocuments);
  }
}
