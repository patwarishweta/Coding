package com.cwan.pbor.document.missing.document;

import com.cwan.lpx.domain.MissingDocumentAlertConfig;
import com.cwan.lpx.domain.MissingDocumentExpectationsConfig;
import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.lpx.domain.MissingDocuments;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentAlertConfigEntity;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentExpectationsConfigEntity;
import com.cwan.pbor.document.missing.document.entity.MissingDocumentsEntity;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class TestUtil {
  public static MissingDocuments getMissingDocuments() {
    return MissingDocuments.builder()
        .id(1234L)
        .accountId(1235L)
        .securityId(1236L)
        .clientId(1237L)
        .documentMissingCategory(MissingDocumentStatus.MISSING)
        .documentType("Capital Account")
        .docDate(LocalDate.of(2024, 1, 2))
        .createdOn(LocalDateTime.of(2024, 1, 1, 12, 30, 30))
        .build();
  }

  public static MissingDocumentsEntity getMissingDocumentsEntity() {
    return MissingDocumentsEntity.builder()
        .id(1234L)
        .accountId(1235L)
        .securityId(1236L)
        .clientId(1237L)
        .documentMissingCategory(MissingDocumentStatus.MISSING)
        .documentType("Capital Account")
        .docDate(LocalDate.of(2024, 1, 2))
        .createdOn(LocalDateTime.of(2024, 1, 1, 12, 30, 30))
        .build();
  }

  public static MissingDocumentAlertConfig getMissingDocumentAlertConfig() {
    return MissingDocumentAlertConfig.builder()
        .id(1234L)
        .clientId(1235L)
        .accountIds(List.of(22346L, 22347L))
        .securityIds(List.of(12346L, 12347L))
        .documentMissingCategories(List.of(MissingDocumentStatus.MISSING))
        .documentTypes(List.of("Capital Account"))
        .startDate(LocalDate.of(2023, 1, 2))
        .expiry(LocalDate.of(2024, 1, 2))
        .username(List.of("testuser"))
        .isActive(true)
        .build();
  }

  public static MissingDocumentAlertConfigEntity getMissingDocumentAlertConfigEntity() {
    return MissingDocumentAlertConfigEntity.builder()
        .id(1234L)
        .clientId(1235L)
        .accountIds(List.of(22346L, 22347L))
        .securityIds(List.of(12346L, 12347L))
        .documentMissingCategories(List.of(MissingDocumentStatus.MISSING))
        .documentTypes(List.of("Capital Account"))
        .startDate(LocalDate.of(2023, 1, 2))
        .expiry(LocalDate.of(2024, 1, 2))
        .username(List.of("testuser"))
        .isActive(true)
        .build();
  }

  public static MissingDocumentExpectationsConfig getMissingDocumentExpectationsConfig() {
    return MissingDocumentExpectationsConfig.builder()
        .id(1234L)
        .securityId(1235L)
        .fundId(111L)
        .fundName("test fund")
        .documentType("Capital Accoun")
        .frequency("monthly")
        .threshold(10)
        .isActive(true)
        .build();
  }

  public static MissingDocumentExpectationsConfigEntity
      getMissingDocumentExpectationsConfigEntity() {
    return MissingDocumentExpectationsConfigEntity.builder()
        .id(1234L)
        .securityId(1235L)
        .fundId(111L)
        .fundName("test fund")
        .documentType("Capital Accoun")
        .frequency("monthly")
        .threshold(10)
        .isActive(true)
        .build();
  }
}
