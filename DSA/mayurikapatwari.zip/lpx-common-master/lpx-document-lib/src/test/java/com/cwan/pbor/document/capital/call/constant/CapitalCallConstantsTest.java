package com.cwan.pbor.document.capital.call.constant;

import static com.cwan.lpx.domain.CapitalCallAction.REJECT;
import static com.cwan.lpx.domain.CapitalCallStatus.BLACKLISTED;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

class CapitalCallConstantsTest {

  @Test
  void systemUserConstants_ShouldHaveCorrectValues() {
    assertEquals(CapitalCallConstants.SystemUserConstants.ID, -1);
    assertEquals("SYSTEM", CapitalCallConstants.SystemUserConstants.FULL_NAME);
    assertEquals(
        "no-reply@clearwateranalytics.com", CapitalCallConstants.SystemUserConstants.EMAIL);
  }

  @Test
  void serviceConstants_ShouldHaveCorrectValues() {
    assertEquals(
        "Capital Call Notice",
        CapitalCallConstants.ServiceConstants.DOCUMENT_TYPE_CAPITAL_CALL_NOTICE);
  }

  @Test
  void documentTransformerConstants_ShouldHaveCorrectValues() {
    assertEquals(
        "Capital Call created and awaiting system processing.",
        CapitalCallConstants.DocumentTransformerConstants.NEW_DOCUMENT);
    assertNotNull(CapitalCallConstants.DocumentTransformerConstants.CAPITAL_CALL_USER);
    assertNotNull(CapitalCallConstants.DocumentTransformerConstants.CAPITAL_CALL_USER_ACTION);
  }

  @Test
  void statusTransitionUtilConstants_ShouldHaveCorrectValues() {
    assertNotNull(CapitalCallConstants.StatusTransitionUtilConstants.VALID_STATUS_TRANSITIONS);
    assertEquals(
        WIRE_CHECK,
        CapitalCallConstants.StatusTransitionUtilConstants.VALID_STATUS_TRANSITIONS
            .get(BLACKLISTED)
            .get(REJECT));
  }
}
