package com.cwan.pbor.document.missing.document.transformer;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

import com.cwan.lpx.domain.MissingDocumentStatus;
import com.cwan.pbor.document.missing.document.MissingDocumentException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

class MissingDocumentStatusListConverterTest {
  private ObjectMapper objectMapper;
  private MissingDocumentStatusListConverter missingDocumentStatusListConverter;

  @BeforeEach
  void setup() {
    MockitoAnnotations.openMocks(this);
    objectMapper = new ObjectMapper();
    missingDocumentStatusListConverter = new MissingDocumentStatusListConverter(objectMapper);
  }

  @Test
  void testConvertToDatabaseColumn() {
    List<MissingDocumentStatus> missingDocumentStatusList =
        Arrays.asList(MissingDocumentStatus.MISSING, MissingDocumentStatus.RECEIVED);
    String expectedString = "[\"MISSING\",\"RECEIVED\"]";

    String actualString =
        missingDocumentStatusListConverter.convertToDatabaseColumn(missingDocumentStatusList);

    Assertions.assertEquals(expectedString, actualString);
  }

  @Test
  void testConvertToEntityAttribute() {
    String string = "[\"MISSING\",\"RECEIVED\"]";
    List<MissingDocumentStatus> expectedMissingDocumentStatusList =
        Arrays.asList(MissingDocumentStatus.MISSING, MissingDocumentStatus.RECEIVED);

    List<MissingDocumentStatus> actualMissingDocumentStatusList =
        missingDocumentStatusListConverter.convertToEntityAttribute(string);

    Assertions.assertEquals(expectedMissingDocumentStatusList, actualMissingDocumentStatusList);
  }

  @Test
  void testConvertToDatabaseColumnWithException() throws JsonProcessingException {
    List<MissingDocumentStatus> missingDocumentStatusList =
        Arrays.asList(MissingDocumentStatus.MISSING, MissingDocumentStatus.RECEIVED);
    objectMapper = mock(ObjectMapper.class);
    missingDocumentStatusListConverter = new MissingDocumentStatusListConverter(objectMapper);
    doThrow(new JsonProcessingException("") {})
        .when(objectMapper)
        .writeValueAsString(missingDocumentStatusList);
    assertThrows(
        MissingDocumentException.class,
        () ->
            missingDocumentStatusListConverter.convertToDatabaseColumn(missingDocumentStatusList));
  }

  @Test
  void testConvertToEntityAttributeWithException() throws JsonProcessingException {
    String string = "[\"MISSING\",\"RECEIVED\"]";
    objectMapper = mock(ObjectMapper.class);
    missingDocumentStatusListConverter = new MissingDocumentStatusListConverter(objectMapper);
    doThrow(new JsonProcessingException("") {})
        .when(objectMapper)
        .readValue(any(String.class), any(TypeReference.class));
    assertThrows(
        MissingDocumentException.class,
        () -> missingDocumentStatusListConverter.convertToEntityAttribute(string));
  }
}
