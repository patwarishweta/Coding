package com.cwan.pbor.document;

import static com.cwan.pbor.document.TestUtil.getDocument;
import static com.cwan.pbor.document.TestUtil.getDocumentEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DocumentTransformerTest {

  private static final Long DOCUMENT_ID = 1L;

  @Test
  public void should_convert_document_entity_to_document() {
    var expected = getDocument(DOCUMENT_ID);
    var actual = new DocumentTransformer().apply(getDocumentEntity(DOCUMENT_ID));
    assertEquals(expected, actual);
  }
}
