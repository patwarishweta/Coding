package com.cwan.pbor.document.capital.call.service;

import static com.cwan.lpx.domain.CapitalCallAction.APPROVE;
import static com.cwan.lpx.domain.CapitalCallAction.REJECT;
import static com.cwan.lpx.domain.CapitalCallStatus.BLACKLISTED;
import static com.cwan.lpx.domain.CapitalCallStatus.FINAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.INITIAL_REVIEW;
import static com.cwan.lpx.domain.CapitalCallStatus.NEW_CAPITAL_CALL;
import static com.cwan.lpx.domain.CapitalCallStatus.WIRE_CHECK;
import static com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.ServiceConstants.DOCUMENT_TYPE_CAPITAL_CALL_NOTICE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.cwan.lpx.domain.CapitalCallAudit;
import com.cwan.lpx.domain.CapitalCallAuditAction;
import com.cwan.lpx.domain.CapitalCallAuditLog;
import com.cwan.lpx.domain.CapitalCallDateFilterType;
import com.cwan.lpx.domain.CapitalCallDocument;
import com.cwan.lpx.domain.CapitalCallUser;
import com.cwan.pbor.document.DocumentEntity;
import com.cwan.pbor.document.capital.call.constant.CapitalCallConstants.DateConstants;
import com.cwan.pbor.document.capital.call.entity.CapitalCallAuditEntity;
import com.cwan.pbor.document.capital.call.entity.CapitalCallDocumentEntity;
import com.cwan.pbor.document.capital.call.repository.CapitalCallAuditRepository;
import com.cwan.pbor.document.capital.call.repository.CapitalCallDocumentRepository;
import com.cwan.pbor.document.capital.call.transformer.CapitalCallAuditTransformer;
import com.cwan.pbor.document.capital.call.transformer.CapitalCallDocumentTransformer;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class CapitalCallServiceTest {

  @Mock private CapitalCallAuditRepository capitalCallAuditRepository;
  @Mock private CapitalCallDocumentRepository capitalCallDocumentRepository;
  @Mock private CapitalCallAuditTransformer capitalCallAuditTransformer;
  @Mock private CapitalCallDocumentTransformer capitalCallDocumentTransformer;
  @InjectMocks private CapitalCallService capitalCallService;
  private DocumentEntity documentEntity;
  private CapitalCallAuditAction updateStatusRequest;

  @BeforeEach
  void setUp() {
    documentEntity =
        DocumentEntity.builder().id(1L).type(DOCUMENT_TYPE_CAPITAL_CALL_NOTICE).build();
    updateStatusRequest = CapitalCallAuditAction.builder().documentId(1L).build();
  }

  @Test
  void createCapitalCall_ShouldCreateCapitalCall_WhenConditionMet() {
    capitalCallService.createCapitalCall(documentEntity, true);
    verify(capitalCallAuditRepository, times(1)).saveAndFlush(any(CapitalCallAuditEntity.class));
  }

  @Test
  void createCapitalCall_ShouldNotCreateCapitalCall_WhenConditionNotMet() {
    documentEntity = DocumentEntity.builder().id(1L).type("Not a Capital Call Notice").build();
    capitalCallService.createCapitalCall(documentEntity, true);
    verify(capitalCallAuditRepository, times(0)).saveAndFlush(any(CapitalCallAuditEntity.class));
  }

  @Test
  void updateCapitalCallStatus_ShouldReturnError_WhenNoActionsCanBePerformedOnCurrentStatus() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    updateStatusRequest = updateStatusRequest.toBuilder().user(user).build();
    when(capitalCallAuditRepository.findFirstByDocumentIdOrderByTimestampDesc(1L))
        .thenReturn(Optional.of(CapitalCallAuditEntity.builder().status(BLACKLISTED).build()));
    var result = capitalCallService.updateCapitalCallStatus(updateStatusRequest, APPROVE);
    StepVerifier.create(result).verifyError(IllegalStateException.class);
    verify(capitalCallAuditRepository, times(1)).findFirstByDocumentIdOrderByTimestampDesc(1L);
    verify(capitalCallAuditRepository, times(0)).saveAndFlush(any(CapitalCallAuditEntity.class));
    verify(capitalCallDocumentRepository, times(0)).findById(1L);
  }

  @Test
  void getCapitalCallsByAccountsTest_SuccessfulFlow() {
    var ids = Set.of(1L, 2L);
    var capitalCallDocumentEntity1 = new CapitalCallDocumentEntity();
    capitalCallDocumentEntity1.setDocumentId(1L);
    var capitalCallDocumentEntity2 = new CapitalCallDocumentEntity();
    capitalCallDocumentEntity2.setDocumentId(2L);
    var entities = Arrays.asList(capitalCallDocumentEntity1, capitalCallDocumentEntity2);
    when(capitalCallDocumentRepository.findByCallReceivedDateBetweenAndAccountIdIn(
            DateConstants.MIN_START_DATE, DateConstants.MAX_END_DATE, ids))
        .thenReturn(entities);
    var auditEntity1 = CapitalCallAuditEntity.builder().documentId(1L).status(WIRE_CHECK).build();
    var auditEntity2 = CapitalCallAuditEntity.builder().documentId(2L).status(WIRE_CHECK).build();
    when(capitalCallAuditRepository.findByDocumentIdInOrderByTimestamp(List.of(1L, 2L)))
        .thenReturn(List.of(auditEntity1, auditEntity2));
    entities.forEach(
        entity -> {
          when(capitalCallDocumentTransformer.apply(eq(entity), any()))
              .thenReturn(
                  CapitalCallDocument.builder()
                      .documentId(entity.getDocumentId())
                      .status(WIRE_CHECK)
                      .build());
          when(capitalCallAuditTransformer.apply(eq(entity.getDocumentId()), any()))
              .thenReturn(
                  CapitalCallAuditLog.builder()
                      .documentId(entity.getDocumentId())
                      .audit(
                          List.of(
                              CapitalCallAudit.builder()
                                  .previousStatus(NEW_CAPITAL_CALL)
                                  .nextStatus(WIRE_CHECK)
                                  .build()))
                      .build());
        });
    StepVerifier.create(
            capitalCallService.getCapitalCallsByAccounts(
                CapitalCallDateFilterType.RECEIVED_DATE,
                DateConstants.MIN_START_DATE,
                DateConstants.MAX_END_DATE,
                ids,
                Set.of(WIRE_CHECK)))
        .expectNextCount(2)
        .verifyComplete();
  }

  @Test
  void updateCapitalCallStatus_ShouldUpdateStatus_WhenCanPerformActionAndDocumentNotFound() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    updateStatusRequest =
        updateStatusRequest.toBuilder().currentStatus(WIRE_CHECK).user(user).build();
    when(capitalCallAuditRepository.findFirstByDocumentIdOrderByTimestampDesc(1L))
        .thenReturn(Optional.of(CapitalCallAuditEntity.builder().status(WIRE_CHECK).build()));
    when(capitalCallDocumentRepository.findById(1L)).thenReturn(Optional.empty());
    var result = capitalCallService.updateCapitalCallStatus(updateStatusRequest, APPROVE);
    StepVerifier.create(result).verifyComplete();
  }

  @Test
  void createCapitalCall_ShouldNotCreateCapitalCall_WhenDocumentEntityIsNull() {
    capitalCallService.createCapitalCall(null, true);
    verify(capitalCallAuditRepository, times(0)).saveAndFlush(any(CapitalCallAuditEntity.class));
  }

  @Test
  void createCapitalCall_ShouldNotCreateCapitalCall_WhenIsNotNewDocument() {
    capitalCallService.createCapitalCall(documentEntity, false);
    verify(capitalCallAuditRepository, times(0)).saveAndFlush(any(CapitalCallAuditEntity.class));
  }

  @Test
  void createCapitalCall_ShouldNotCreateCapitalCall_WhenDocumentIdIsNull() {
    documentEntity = DocumentEntity.builder().type(DOCUMENT_TYPE_CAPITAL_CALL_NOTICE).build();
    capitalCallService.createCapitalCall(documentEntity, true);
    verify(capitalCallAuditRepository, times(0)).saveAndFlush(any(CapitalCallAuditEntity.class));
  }

  @Test
  void updateCapitalCallStatus_ShouldThrowIllegalArgumentException_WhenAuditActionIsInvalid() {
    updateStatusRequest =
        CapitalCallAuditAction.builder().build(); // Invalid, no userId or documentId
    var result = capitalCallService.updateCapitalCallStatus(updateStatusRequest, APPROVE);
    StepVerifier.create(result).verifyError(IllegalArgumentException.class);
  }

  @Test
  void updateCapitalCallStatus_ShouldThrowIllegalArgumentException_WhenAuditActionUserIsInvalid() {
    var invalidUser =
        CapitalCallUser.builder()
            .id(-1)
            .build(); // Invalid, negative userId and missing userName and userEmail
    updateStatusRequest = updateStatusRequest.toBuilder().user(invalidUser).build();
    var result = capitalCallService.updateCapitalCallStatus(updateStatusRequest, APPROVE);
    StepVerifier.create(result).verifyError(IllegalArgumentException.class);
  }

  @Test
  void updateCapitalCallStatus_ShouldReturnEmptyMono_WhenDocumentNotFound() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    updateStatusRequest =
        updateStatusRequest.toBuilder().currentStatus(WIRE_CHECK).user(user).build();
    when(capitalCallAuditRepository.findFirstByDocumentIdOrderByTimestampDesc(1L))
        .thenReturn(Optional.of(CapitalCallAuditEntity.builder().status(WIRE_CHECK).build()));
    when(capitalCallDocumentRepository.findById(1L)).thenReturn(Optional.empty());
    var result = capitalCallService.updateCapitalCallStatus(updateStatusRequest, APPROVE);
    StepVerifier.create(result).verifyComplete();
  }

  @Test
  void updateCapitalCallStatus_ShouldThrowRuntimeException_WhenDocumentIdNotFound() {
    var user =
        CapitalCallUser.builder()
            .id(1)
            .fullName("Test User")
            .email("test.user@example.com")
            .build();
    updateStatusRequest = updateStatusRequest.toBuilder().user(user).build();
    // Mock the repository to return empty
    when(capitalCallAuditRepository.findFirstByDocumentIdOrderByTimestampDesc(1L))
        .thenReturn(Optional.empty());
    // Call the method and capture the exception
    RuntimeException thrownException = null;
    try {
      capitalCallService.updateCapitalCallStatus(updateStatusRequest, APPROVE).block();
    } catch (RuntimeException e) {
      thrownException = e;
    }
    // Assert that an exception was indeed thrown
    assertNotNull(thrownException, "Expected RuntimeException to be thrown, but it was not");
    assertEquals("Document id not found", thrownException.getMessage());
    // Verify the interaction with the repository
    verify(capitalCallAuditRepository, times(1)).findFirstByDocumentIdOrderByTimestampDesc(1L);
    // Verify that the saveAndFlush() method was not called
    verify(capitalCallAuditRepository, times(0)).saveAndFlush(any(CapitalCallAuditEntity.class));
    // Verify that the findById() method was not called
    verify(capitalCallDocumentRepository, times(0)).findById(1L);
  }

  @Test
  void getCapitalCallAuditByDocument_ShouldReturnAuditLog_WhenDocumentExists() {
    // Arrange
    Long documentId = 1L;
    // Create a SYSTEM audit entity for the start
    var systemAuditEntity =
        CapitalCallAuditEntity.create(
            documentId,
            APPROVE,
            WIRE_CHECK,
            "New document",
            -1,
            "SYSTEM",
            "no-reply@clearwateranlytics.com");
    // Build the rest of the entities with proper values
    var auditEntity1 =
        CapitalCallAuditEntity.create(
            documentId,
            APPROVE,
            INITIAL_REVIEW,
            "Audit entity 1",
            91298,
            "Test User",
            "tuser@clearwateranlytics.com");
    var auditEntity2 =
        CapitalCallAuditEntity.create(
            documentId,
            REJECT,
            FINAL_REVIEW,
            "Audit entity 2",
            91298,
            "Test User",
            "tuser@clearwateranlytics.com");
    List<CapitalCallAuditEntity> auditEntities =
        Arrays.asList(systemAuditEntity, auditEntity1, auditEntity2);
    // Mock the repository behavior
    when(capitalCallAuditRepository.findByDocumentIdInOrderByTimestamp(List.of(documentId)))
        .thenReturn(auditEntities);
    // Mock transformer behavior
    List<CapitalCallAudit> auditLogs =
        auditEntities.stream()
            .map(
                entity ->
                    CapitalCallAudit.builder()
                        .previousStatus(entity.getStatus())
                        .action(entity.getAction())
                        .nextStatus(entity.getStatus())
                        .timestamp(entity.getTimestamp())
                        .comment(entity.getComment())
                        .user(
                            CapitalCallUser.builder()
                                .id(entity.getUserId())
                                .fullName(entity.getUserFullName())
                                .email(entity.getUserEmail())
                                .build())
                        .build())
            .toList();
    when(capitalCallAuditTransformer.apply(anyLong(), any()))
        .thenReturn(CapitalCallAuditLog.builder().documentId(documentId).audit(auditLogs).build());
    // Act
    StepVerifier.create(capitalCallService.getCapitalCallAuditByDocument(documentId))
        .assertNext(
            capitalCallAuditLog -> {
              assertEquals(documentId, capitalCallAuditLog.documentId());
              assertEquals(3, capitalCallAuditLog.audit().size());
            })
        .verifyComplete();
    // Assert
    verify(capitalCallAuditRepository, times(1))
        .findByDocumentIdInOrderByTimestamp(List.of(documentId));
  }

  @Test
  void getCapitalCallAuditByDocument_ShouldThrowRuntimeException_WhenErrorOccursInRepository() {
    // Arrange
    Long documentId = 1L;
    when(capitalCallAuditRepository.findByDocumentIdInOrderByTimestamp(List.of(documentId)))
        .thenThrow(new RuntimeException("Test exception"));
    // Act and Assert
    StepVerifier.create(capitalCallService.getCapitalCallAuditByDocument(documentId))
        .verifyErrorMatches(
            e ->
                (e instanceof RuntimeException)
                    && e.getMessage()
                        .contains(
                            "Error getting capital call audit for document having ID "
                                + documentId));
  }

  @Test
  void getCapitalCallsByDocument_ShouldReturnEmpty_WhenDocumentDoesNotExist() {
    when(capitalCallDocumentRepository.findById(1L)).thenReturn(Optional.empty());
    var result = capitalCallService.getCapitalCallByDocument(1L);
    StepVerifier.create(result).expectComplete().verify();
  }

  @Test
  void getCapitalCallsByDocument_ShouldThrowException_WhenDocumentIdIsNull() {
    var result = capitalCallService.getCapitalCallByDocument(null);
    StepVerifier.create(result)
        .expectErrorMatches(throwable -> throwable instanceof IllegalArgumentException)
        .verify();
  }

  @Test
  void getCapitalCallAuditByDocument_ShouldThrowException_WhenDocumentIdIsNull() {
    var result = capitalCallService.getCapitalCallAuditByDocument(null);
    StepVerifier.create(result)
        .expectErrorMatches(throwable -> throwable instanceof IllegalArgumentException)
        .verify();
  }

  @Test
  void getOpenCapitalCalls_shouldReturnOpenCapitalCallsForValidStatuses() {
    var documentId1 = 1L;
    var documentId2 = 2L;
    var documentId3 = 3L;
    var entity1 = new CapitalCallDocumentEntity();
    entity1.setDocumentId(documentId1);
    var entity2 = new CapitalCallDocumentEntity();
    entity2.setDocumentId(documentId2);
    var entity3 = new CapitalCallDocumentEntity();
    entity3.setDocumentId(documentId3);
    var entities = Arrays.asList(entity1, entity2, entity3);
    when(capitalCallDocumentRepository.findAll()).thenReturn(entities);
    var auditLog1 = CapitalCallAuditLog.builder().documentId(documentId1).build();
    var auditLog2 = CapitalCallAuditLog.builder().documentId(documentId2).build();
    var auditLog3 = CapitalCallAuditLog.builder().documentId(documentId3).build();
    when(capitalCallAuditTransformer.apply(anyLong(), any()))
        .thenReturn(auditLog1, auditLog2, auditLog3);
    var auditEntity1 = CapitalCallAuditEntity.builder().documentId(documentId1).build();
    var auditEntity2 = CapitalCallAuditEntity.builder().documentId(documentId2).build();
    var auditEntity3 = CapitalCallAuditEntity.builder().documentId(documentId3).build();
    when(capitalCallAuditRepository.findByDocumentIdInOrderByTimestamp(anyList()))
        .thenReturn(List.of(auditEntity1, auditEntity2, auditEntity3));
    var document1 =
        CapitalCallDocument.builder().documentId(documentId1).status(INITIAL_REVIEW).build();
    var document2 =
        CapitalCallDocument.builder().documentId(documentId2).status(FINAL_REVIEW).build();
    var document3 =
        CapitalCallDocument.builder().documentId(documentId3).status(WIRE_CHECK).build();
    when(capitalCallDocumentTransformer.apply(any(), any()))
        .thenReturn(document1, document2, document3);
    StepVerifier.create(
            capitalCallService.getCapitalCallsByStatuses(
                Set.of(INITIAL_REVIEW, FINAL_REVIEW, WIRE_CHECK)))
        .expectNextMatches(doc -> doc.status() == WIRE_CHECK)
        .expectNextMatches(doc -> doc.status() == FINAL_REVIEW)
        .expectNextMatches(doc -> doc.status() == INITIAL_REVIEW)
        .verifyComplete();
    verify(capitalCallDocumentRepository).findAll();
    verify(capitalCallAuditTransformer, times(3)).apply(anyLong(), any());
    verify(capitalCallDocumentTransformer, times(3)).apply(any(), any());
  }

  @Test
  void insertMissedCapitalCalls_ShouldLogAndCallRepository() {
    when(capitalCallAuditRepository.insertMissedCapitalCalls())
        .thenReturn(0); // mock a scenario where 0 records are inserted
    var logger = (Logger) LoggerFactory.getLogger(CapitalCallService.class);
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    logger.addAppender(listAppender);
    StepVerifier.create(capitalCallService.insertMissedCapitalCalls())
        .expectNext(0)
        .expectComplete()
        .verify();
    var logsList = listAppender.list;
    assertEquals(2, logsList.size());
    assertEquals(Level.INFO, logsList.get(0).getLevel());
    assertTrue(
        logsList
            .get(0)
            .getFormattedMessage()
            .contains("Initiating insert for any missed capital calls."));
    assertEquals(Level.INFO, logsList.get(1).getLevel());
    assertTrue(
        logsList
            .get(1)
            .getFormattedMessage()
            .contains("No missed capital calls found to be inserted."));
    verify(capitalCallAuditRepository, times(1)).insertMissedCapitalCalls();
    logger.detachAppender(listAppender);
  }

  @Test
  void insertMissedCapitalCalls_ShouldLogErrorWhenRepositoryThrowsException() {
    doThrow(new RuntimeException("Test Error"))
        .when(capitalCallAuditRepository)
        .insertMissedCapitalCalls();
    var logger = (Logger) LoggerFactory.getLogger(CapitalCallService.class);
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    logger.addAppender(listAppender);
    StepVerifier.create(capitalCallService.insertMissedCapitalCalls())
        .expectError(RuntimeException.class)
        .verify();
    var logsList = listAppender.list;
    assertEquals(Level.INFO, logsList.get(0).getLevel());
    assertTrue(
        logsList
            .get(0)
            .getFormattedMessage()
            .contains("Initiating insert for any missed capital calls."));
    assertEquals(Level.ERROR, logsList.get(1).getLevel());
    assertTrue(
        logsList
            .get(1)
            .getFormattedMessage()
            .contains("Error during insert of missed capital calls."));
    verify(capitalCallAuditRepository, times(1)).insertMissedCapitalCalls();
    logger.detachAppender(listAppender);
  }

  @Test
  void getCapitalCallsByAccounts_ShouldLogWarning_WhenAccountIdsAreNullOrEmpty() {
    var logger = (Logger) LoggerFactory.getLogger(CapitalCallService.class);
    var listAppender = new ListAppender<ILoggingEvent>();
    listAppender.start();
    logger.addAppender(listAppender);
    StepVerifier.create(
            capitalCallService.getCapitalCallsByAccounts(
                CapitalCallDateFilterType.RECEIVED_DATE,
                DateConstants.MIN_START_DATE,
                DateConstants.MAX_END_DATE,
                null,
                Set.of(WIRE_CHECK)))
        .verifyComplete();
    var logsList = listAppender.list;
    assertEquals(Level.WARN, logsList.get(0).getLevel());
    assertTrue(
        logsList
            .get(0)
            .getFormattedMessage()
            .contains("Account IDs are null or empty. No capital calls will be fetched."));
    logger.detachAppender(listAppender);
  }

  @Test
  void processCapitalCallEntities_ShouldReturnEmpty_WhenEntitiesListIsEmpty() {
    var result =
        capitalCallService.processCapitalCallEntities(Collections.emptyList(), Set.of(WIRE_CHECK));
    assert result != null;
    StepVerifier.create(result).expectComplete().verify();
  }

  @Test
  void fetchAuditsForDocumentIds_ShouldReturnError_WhenDocumentIdsAreNullOrEmpty() {
    var result = capitalCallService.fetchAuditsForDocumentIds(Collections.emptySet());
    assert result != null;
    StepVerifier.create(result)
        .expectErrorMatches(throwable -> throwable instanceof IllegalArgumentException)
        .verify();
    result = capitalCallService.fetchAuditsForDocumentIds(null);
    assert result != null;
    StepVerifier.create(result)
        .expectErrorMatches(throwable -> throwable instanceof IllegalArgumentException)
        .verify();
  }

  @Test
  void processCapitalCallEntities_ShouldHandleError_WhenErrorOccurs() {
    var result =
        capitalCallService.processCapitalCallEntities(
            List.of(new CapitalCallDocumentEntity()), Set.of(WIRE_CHECK));
    assert result != null;
    StepVerifier.create(result).expectError(RuntimeException.class).verify();
  }
}
