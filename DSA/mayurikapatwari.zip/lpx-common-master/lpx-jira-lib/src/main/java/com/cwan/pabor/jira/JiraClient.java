package com.cwan.pabor.jira;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Slf4j
public class JiraClient {

  private final String jiraApiToken;
  private final String email;
  private final WebClient webClient;

  public JiraClient(WebClient webClient, String jiraApiToken, String email) {
    log.info(
        "JiraClient webClient : {}, jiraApiToken : {}, email : {}", webClient, jiraApiToken, email);
    this.webClient = webClient;
    this.jiraApiToken = jiraApiToken;
    this.email = email;
  }

  public Flux<JiraCreateIssueResponse> createIssue(Jira jira) {
    var authentication = email + ":" + jiraApiToken;
    var bas64EncodedAuthentication =
        Base64.getEncoder().encodeToString(authentication.getBytes(StandardCharsets.UTF_8));
    return webClient
        .post()
        .uri(uriBuilder -> uriBuilder.path("rest/api/3/issue").build())
        .headers(httpHeaders -> httpHeaders.setBasicAuth(bas64EncodedAuthentication))
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromValue(jira))
        .retrieve()
        .onStatus(
            HttpStatusCode::isError,
            clientResponse ->
                clientResponse
                    .bodyToMono(Object.class)
                    .handle(
                        (error, sink) ->
                            sink.error(
                                new Throwable("Error Response from Jira :" + error.toString()))))
        .bodyToFlux(JiraCreateIssueResponse.class);
  }

  public Flux<JiraSearch> getIssueBySummary(String summary) {
    var authentication = email + ":" + jiraApiToken;
    var bas64EncodedAuthentication =
        Base64.getEncoder().encodeToString(authentication.getBytes(StandardCharsets.UTF_8));
    return webClient
        .get()
        .uri(
            uriBuilder ->
                uriBuilder.path("rest/api/2/search?jql=summary~" + "\"" + summary + "\"").build())
        .headers(httpHeaders -> httpHeaders.setBasicAuth(bas64EncodedAuthentication))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            HttpStatusCode::isError,
            clientResponse ->
                clientResponse
                    .bodyToMono(Object.class)
                    .handle(
                        (error, sink) ->
                            sink.error(
                                new Throwable("Error Response from Jira :" + error.toString()))))
        .bodyToFlux(JiraSearch.class);
  }
}
