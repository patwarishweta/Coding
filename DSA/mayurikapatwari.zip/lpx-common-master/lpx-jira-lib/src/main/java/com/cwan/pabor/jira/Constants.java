package com.cwan.pabor.jira;

public class Constants {

  public static final String ID = "id";
  public static final String FIELDS = "fields";
  public static final String PROJECT = "project";
  public static final String PROJECT_PLATDESK_ID = "23302";
  public static final String ISSUETYPE = "issuetype";
  public static final String SUPPORT_REQUEST_ISSUETYPE_ID = "28";
  public static final String REQUEST_TYPE = "customfield_21640";
  public static final String LPX_MANAGEMENT_CONSOLE_REQUEST_TYPE_ID = "807";
  public static final String SUPPORT_REQUEST_TYPE = "customfield_22840";
  public static final String CLIENT_LIFECYCLE = "customfield_22839";
  public static final String CLIENT_LIFECYCLE_ID = "25354";
  public static final String NOT_WORKING_AS_EXPECTED_SUPPORT_REQUEST_TYPE_ID = "25357";
  public static final String SUMMARY = "summary";
  public static final String LABELS = "labels";
  public static final String SKYLAB_LABEL = "skylab";
  public static final String DESCRIPTION = "description";
  public static final String CONTENT = "content";
  public static final String TYPE = "type";
  public static final String PARAGRAPH_TYPE = "paragraph";
  public static final String TEXT_TYPE = "text";
  public static final String DOC_TYPE = "doc";
  public static final String VERSION = "version";
  public static final Integer VERSION_ONE = 1;
}
