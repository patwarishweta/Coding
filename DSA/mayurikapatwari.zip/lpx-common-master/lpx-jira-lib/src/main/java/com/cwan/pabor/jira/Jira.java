package com.cwan.pabor.jira;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class Jira {

  private Field fields;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class Field {

  private Map<String, String> project;

  @JsonProperty("issuetype")
  private Map<String, String> issueType;

  @JsonProperty("customfield_21640")
  private String requestType;

  @JsonProperty("customfield_22840")
  private Map<String, String> supportRequestType;

  private String summary;
  private Map<String, Object> description;

  @JsonProperty("customfield_22839")
  private Map<String, String> clientLifeCycle;
}
