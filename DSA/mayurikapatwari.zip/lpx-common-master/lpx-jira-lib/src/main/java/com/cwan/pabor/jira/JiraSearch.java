package com.cwan.pabor.jira;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
public class JiraSearch {

  private List<Issue> issues;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class Issue {

  private String key;
  private Response fields;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class Response {

  private Status status;
  private String summary;

  @JsonProperty("customfield_21640")
  private CustomField customField1;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class Status {

  private String name;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class CustomField {

  private RequestType requestType;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
class RequestType {

  private String name;
}
