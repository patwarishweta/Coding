package com.cwan.pabor.jira;

import static com.cwan.pabor.jira.Constants.CLIENT_LIFECYCLE_ID;
import static com.cwan.pabor.jira.Constants.CONTENT;
import static com.cwan.pabor.jira.Constants.DOC_TYPE;
import static com.cwan.pabor.jira.Constants.ID;
import static com.cwan.pabor.jira.Constants.LPX_MANAGEMENT_CONSOLE_REQUEST_TYPE_ID;
import static com.cwan.pabor.jira.Constants.NOT_WORKING_AS_EXPECTED_SUPPORT_REQUEST_TYPE_ID;
import static com.cwan.pabor.jira.Constants.PARAGRAPH_TYPE;
import static com.cwan.pabor.jira.Constants.PROJECT_PLATDESK_ID;
import static com.cwan.pabor.jira.Constants.SUPPORT_REQUEST_ISSUETYPE_ID;
import static com.cwan.pabor.jira.Constants.TEXT_TYPE;
import static com.cwan.pabor.jira.Constants.TYPE;
import static com.cwan.pabor.jira.Constants.VERSION;
import static com.cwan.pabor.jira.Constants.VERSION_ONE;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class JiraService {

  private final JiraClient jiraClient;

  public JiraService(JiraClient jiraClient) {
    this.jiraClient = jiraClient;
  }

  public void createIssue(String issueTitle, String issueDescription) {
    val fields = createFields(issueTitle, issueDescription);
    getIssueBySummary(issueTitle)
        .subscribe(
            issues -> {
              if (Objects.nonNull(issues) && !issues.isEmpty()) {
                log.info(
                    "More than one platdesk already exist for this summary, already raised platdesks {} "
                        + issues);
              } else {
                jiraClient
                    .createIssue(fields)
                    .subscribe(
                        response ->
                            log.info("Raised ticket in Jira, jira response : {}", response));
              }
            });
  }

  private Mono<List<Issue>> getIssueBySummary(String summary) {
    return jiraClient
        .getIssueBySummary(summary)
        .flatMap(jiraSearch -> getIssues(jiraSearch.getIssues(), summary))
        .collect(Collectors.toList());
  }

  private Flux<Issue> getIssues(List<Issue> issues, String summary) {
    return Flux.fromStream(
        issues.stream()
            .filter(issue -> issue.getKey().contains("PLATDESK"))
            .filter(issue -> issue.getFields().getSummary().equals(summary))
            .filter(
                issue -> {
                  val status = issue.getFields().getStatus().getName();
                  return !"Closed".equals(status);
                })
            .filter(
                issue ->
                    "LPx Management Console"
                        .equalsIgnoreCase(
                            issue.getFields().getCustomField1().getRequestType().getName())));
  }

  private Jira createFields(String issueTitle, String issueDescription) {
    Map<String, Object> contentMap =
        Map.of(
            TYPE,
            PARAGRAPH_TYPE,
            CONTENT,
            List.of(Map.of(TYPE, TEXT_TYPE, TEXT_TYPE, issueDescription)));
    return Jira.builder()
        .fields(
            Field.builder()
                .summary(issueTitle)
                .issueType(Map.of(ID, SUPPORT_REQUEST_ISSUETYPE_ID))
                .project(Map.of(ID, PROJECT_PLATDESK_ID))
                .description(
                    Map.of(TYPE, DOC_TYPE, VERSION, VERSION_ONE, CONTENT, List.of(contentMap)))
                .requestType(LPX_MANAGEMENT_CONSOLE_REQUEST_TYPE_ID)
                .supportRequestType(Map.of(ID, NOT_WORKING_AS_EXPECTED_SUPPORT_REQUEST_TYPE_ID))
                .clientLifeCycle(Map.of(ID, CLIENT_LIFECYCLE_ID))
                .build())
        .build();
  }
}
