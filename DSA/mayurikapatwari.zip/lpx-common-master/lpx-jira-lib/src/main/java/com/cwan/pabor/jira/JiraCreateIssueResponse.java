package com.cwan.pabor.jira;

import lombok.Data;

@Data
public class JiraCreateIssueResponse {

  private String id;
  private String key;
}
