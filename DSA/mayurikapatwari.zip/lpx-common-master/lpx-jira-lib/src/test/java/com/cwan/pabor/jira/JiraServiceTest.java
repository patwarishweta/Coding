package com.cwan.pabor.jira;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.core.publisher.Flux;

@Slf4j
public class JiraServiceTest {

  private JiraClient jiraClient;
  private JiraService jiraService;

  @BeforeEach
  public void setUp() {
    jiraClient = Mockito.mock(JiraClient.class);
    jiraService = new JiraService(jiraClient);
  }

  @Test
  public void createIssue_ShouldCallCreateIssueOnJiraClient_WhenInvoked()
      throws JsonProcessingException {
    var response = new JiraCreateIssueResponse();
    response.setId("JIRA-123");
    when(jiraClient.createIssue(any())).thenReturn(Flux.just(response));
    when(jiraClient.getIssueBySummary(any()))
        .thenReturn(
            Flux.just(
                JiraSearch.builder()
                    .issues(
                        List.of(
                            Issue.builder()
                                .key("PLATDESK-533")
                                .fields(Response.builder().summary("test").build())
                                .build()))
                    .build()));
    jiraService.createIssue("Test Issue Title", "Test Issue Description");
    verify(jiraClient, atLeastOnce()).createIssue(any());
  }

  @Test
  public void should_not_create_issue() {
    when(jiraClient.getIssueBySummary(any()))
        .thenReturn(
            Flux.just(
                JiraSearch.builder()
                    .issues(
                        List.of(
                            Issue.builder()
                                .key("PLATDESK-533")
                                .fields(
                                    Response.builder()
                                        .status(Status.builder().name("Open").build())
                                        .customField1(
                                            CustomField.builder()
                                                .requestType(
                                                    RequestType.builder()
                                                        .name("LPx Management Console")
                                                        .build())
                                                .build())
                                        .summary("Test Issue Title")
                                        .build())
                                .build()))
                    .build()));
    Assertions.assertDoesNotThrow(
        () -> jiraService.createIssue("Test Issue Title", "Test Issue Description"));
  }
}
