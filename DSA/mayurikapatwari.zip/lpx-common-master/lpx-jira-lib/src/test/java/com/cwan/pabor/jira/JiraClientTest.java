package com.cwan.pabor.jira;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.val;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.test.StepVerifier;

public class JiraClientTest {

  private MockWebServer mockWebServer;
  private JiraClient jiraClient;
  private ObjectMapper objectMapper;

  @BeforeEach
  public void setup() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();
    var webClient = WebClient.builder().baseUrl(mockWebServer.url("/").toString()).build();
    jiraClient = new JiraClient(webClient, "jiraApiToken", "email");
    objectMapper = new ObjectMapper();
  }

  @AfterEach
  public void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  public void testCreateIssue_success() throws Exception {
    val payload = TestUtil.getJira();
    var expectedResponse = new JiraCreateIssueResponse();
    var responseBody = objectMapper.writeValueAsString(expectedResponse);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.CREATED.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(responseBody));
    var response = jiraClient.createIssue(TestUtil.getJira());
    var actualResponse = response.blockFirst();
    var recordedRequest = mockWebServer.takeRequest();
    assertEquals(expectedResponse.getKey(), Objects.requireNonNull(actualResponse).getKey());
    assertEquals("POST", recordedRequest.getMethod());
    assertEquals("/rest/api/3/issue", recordedRequest.getPath());
    assertEquals(
        "Basic " + java.util.Base64.getEncoder().encodeToString("email:jiraApiToken".getBytes()),
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION));
    assertEquals(objectMapper.writeValueAsString(payload), recordedRequest.getBody().readUtf8());
  }

  @Test
  void createIssueWithError() throws JsonProcessingException {
    Map<String, Object> payload = new HashMap<>();
    payload.put("key", "value");
    var errorResponseBody = "{\"error\":\"Invalid payload\"}";
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.BAD_REQUEST.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(errorResponseBody));
    var result = jiraClient.createIssue(TestUtil.getJira());
    StepVerifier.create(result)
        .expectErrorSatisfies(
            error -> {
              var errorMessage = error.getMessage();
              assertTrue(errorMessage.contains("Error Response from Jira"));
              assertTrue(errorMessage.contains("Invalid payload"));
            })
        .verify();
  }

  @Test
  public void test_jira_search_when_throwing_error() {
    var errorResponseBody = "{\"error\":\"Invalid payload\"}";
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.BAD_REQUEST.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(errorResponseBody));
    var response = jiraClient.getIssueBySummary("test");
    StepVerifier.create(response)
        .expectErrorSatisfies(
            error -> {
              var errorMessage = error.getMessage();
              assertTrue(errorMessage.contains("Error Response from Jira"));
              assertTrue(errorMessage.contains("Invalid payload"));
            })
        .verify();
  }
}
