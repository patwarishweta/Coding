package com.cwan.pabor.jira;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.nio.file.Files;
import java.nio.file.Path;
import lombok.SneakyThrows;

public class TestUtil {

  @SneakyThrows
  public static Jira getJira() {
    return getObjectMapper()
        .readValue(Files.readString(Path.of("src/test/resources/jira.json")), Jira.class);
  }

  public static ObjectMapper getObjectMapper() {
    return new ObjectMapper()
        .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
        .setSerializationInclusion(JsonInclude.Include.NON_NULL);
  }
}
