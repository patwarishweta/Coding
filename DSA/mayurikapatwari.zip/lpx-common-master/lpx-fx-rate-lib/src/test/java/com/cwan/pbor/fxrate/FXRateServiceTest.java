package com.cwan.pbor.fxrate;

import static com.cwan.pbor.fxrate.TestUtil.getFXRate;
import static com.cwan.pbor.fxrate.TestUtil.getFXRateEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.FXRate;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class FXRateServiceTest {
  private static final FXRateRepository mockFXRateRepository = Mockito.mock(FXRateRepository.class);
  private FXRateService fXRateService;

  private static final FXRateEntity FX_RATE_ENTITY = getFXRateEntity();
  private static final List<FXRateEntity> FX_RATE_ENTITIES = List.of(FX_RATE_ENTITY);
  private static final FXRate FX_RATE = getFXRate();
  private static final Set<FXRate> FX_RATES = Set.of(FX_RATE);

  @BeforeEach
  void before_each() {
    openMocks(this);
    fXRateService =
        new FXRateService(
            mockFXRateRepository, new FXRateEntityTransformer(), new FXRateTransformer());
  }

  @Test
  void get_FX_Rate_for_base_currency_id() {
    var baseCurrency = 2L;
    when(mockFXRateRepository.findAllByBaseCurrencyId(baseCurrency)).thenReturn(FX_RATE_ENTITIES);
    assertEquals(FX_RATES, fXRateService.getFxRatesForBaseCurrency(baseCurrency));
  }

  @Test
  void get_FX_Rate_for_base_currency_id_and_source_id() {
    var baseCurrency = 2L;
    var sourceId = 3L;
    when(mockFXRateRepository.findAllByBaseCurrencyIdAndFxRateSourceIdIn(
            baseCurrency, Set.of(sourceId)))
        .thenReturn(FX_RATE_ENTITIES);
    assertEquals(
        FX_RATES,
        fXRateService.getFxRatesForBaseCurrencyAndSourceId(baseCurrency, Set.of(sourceId)));
  }

  @Test
  void addFXRates() {
    when(mockFXRateRepository.saveAndFlush(any(FXRateEntity.class)))
        .thenAnswer(invocation -> invocation.getArgument(0));

    Set<FXRate> result = fXRateService.addFXRates(Set.of(FX_RATE));

    assertEquals(1, result.size());
    verify(mockFXRateRepository, times(1)).saveAndFlush(any(FXRateEntity.class));
  }
}
