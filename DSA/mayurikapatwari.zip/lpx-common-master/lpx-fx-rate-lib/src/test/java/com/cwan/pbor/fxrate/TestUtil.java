package com.cwan.pbor.fxrate;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import java.time.LocalDate;

public class TestUtil {
  public static FXRate getFXRate() {
    return FXRate.builder()
        .baseCurrencyId(2L)
        .localCurrencyId(3L)
        .reportingFrequency(ReportingFrequency.QUARTERLY)
        .date(LocalDate.of(2022, 1, 1))
        .fxRateSourceId(4L)
        .fxRate(5.0)
        .averageFxRate(6.0)
        .createdBy("user1")
        .isCreatedByInternalUser(true)
        .modifiedBy("user2")
        .isModifiedByInternalUser(false)
        .build();
  }

  public static FXRateEntity getFXRateEntity() {
    return FXRateEntity.builder()
        .baseCurrencyId(2L)
        .localCurrencyId(3L)
        .reportingFrequency(ReportingFrequency.QUARTERLY.getValue())
        .date(LocalDate.of(2022, 1, 1))
        .fxRateSourceId(4L)
        .fxRate(5.0)
        .averageFxRate(6.0)
        .createdBy("user1")
        .isCreatedByInternalUser(true)
        .modifiedBy("user2")
        .isModifiedByInternalUser(false)
        .build();
  }
}
