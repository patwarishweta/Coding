package com.cwan.pbor.fxrate;

import com.cwan.lpx.domain.FXRate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class FXRateEntityTransformer implements Function<FXRate, FXRateEntity> {
  @Override
  public FXRateEntity apply(FXRate fxRate) {
    return FXRateEntity.builder()
        .baseCurrencyId(fxRate.getBaseCurrencyId())
        .localCurrencyId(fxRate.getLocalCurrencyId())
        .reportingFrequency(fxRate.getReportingFrequency().getValue())
        .date(fxRate.getDate())
        .fxRateSourceId(fxRate.getFxRateSourceId())
        .fxRate(fxRate.getFxRate())
        .averageFxRate(fxRate.getAverageFxRate())
        .createdBy(fxRate.getCreatedBy())
        .isCreatedByInternalUser(fxRate.getIsCreatedByInternalUser())
        .modifiedBy(fxRate.getModifiedBy())
        .isModifiedByInternalUser(fxRate.getIsModifiedByInternalUser())
        .createdOn(
            fxRate.getCreatedOn() != null
                ? fxRate.getCreatedOn()
                : LocalDateTime.now(ZoneOffset.UTC))
        .modifiedOn(
            fxRate.getModifiedOn() != null
                ? fxRate.getModifiedOn()
                : LocalDateTime.now(ZoneOffset.UTC))
        .build();
  }
}
