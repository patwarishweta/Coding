package com.cwan.pbor.fxrate;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@EqualsAndHashCode
public class FXRateKey implements Serializable {

  @Serial private static final long serialVersionUID = 7351223847506724113L;

  private Long baseCurrencyId;
  private Long localCurrencyId;
  private Integer reportingFrequency;
  private LocalDate date;
  private Long fxRateSourceId;
}
