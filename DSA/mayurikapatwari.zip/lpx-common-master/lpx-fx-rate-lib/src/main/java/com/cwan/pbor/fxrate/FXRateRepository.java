package com.cwan.pbor.fxrate;

import java.util.Collection;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FXRateRepository extends JpaRepository<FXRateEntity, FXRateKey> {
  Collection<FXRateEntity> findAllByBaseCurrencyId(Long baseCurrencyId);

  Collection<FXRateEntity> findAllByBaseCurrencyIdAndFxRateSourceIdIn(
      Long baseCurrencyId, Set<Long> sourceIds);
}
