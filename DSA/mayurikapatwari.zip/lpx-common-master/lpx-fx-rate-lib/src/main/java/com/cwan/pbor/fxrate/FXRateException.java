package com.cwan.pbor.fxrate;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class FXRateException extends ResponseStatusException {
  @Serial private static final long serialVersionUID = -3285493479844458072L;

  public FXRateException(HttpStatus status, String msg, Throwable e) {
    super(status, msg, e);
  }

  public FXRateException(HttpStatus status, String msg) {
    super(status, msg);
  }
}
