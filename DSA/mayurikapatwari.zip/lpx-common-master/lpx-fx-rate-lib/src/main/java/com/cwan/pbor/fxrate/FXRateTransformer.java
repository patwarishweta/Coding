package com.cwan.pbor.fxrate;

import com.cwan.lpx.domain.FXRate;
import com.cwan.lpx.domain.ReportingFrequency;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class FXRateTransformer implements Function<FXRateEntity, FXRate> {
  @Override
  public FXRate apply(FXRateEntity fxRateEntity) {
    return FXRate.builder()
        .baseCurrencyId(fxRateEntity.getBaseCurrencyId())
        .localCurrencyId(fxRateEntity.getLocalCurrencyId())
        .reportingFrequency(ReportingFrequency.getByValue(fxRateEntity.getReportingFrequency()))
        .date(fxRateEntity.getDate())
        .fxRateSourceId(fxRateEntity.getFxRateSourceId())
        .fxRate(fxRateEntity.getFxRate())
        .averageFxRate(fxRateEntity.getAverageFxRate())
        .createdBy(fxRateEntity.getCreatedBy())
        .isCreatedByInternalUser(fxRateEntity.getIsCreatedByInternalUser())
        .createdOn(fxRateEntity.getCreatedOn())
        .modifiedBy(fxRateEntity.getModifiedBy())
        .isModifiedByInternalUser(fxRateEntity.getIsModifiedByInternalUser())
        .modifiedOn(fxRateEntity.getModifiedOn())
        .build();
  }
}
