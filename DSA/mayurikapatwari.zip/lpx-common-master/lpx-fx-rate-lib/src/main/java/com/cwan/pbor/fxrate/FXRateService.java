package com.cwan.pbor.fxrate;

import com.cwan.lpx.domain.FXRate;
import com.cwan.pbor.fxrate.api.FXRates;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class FXRateService implements FXRates {
  private FXRateRepository fxRateRepository;
  private FXRateEntityTransformer fxRateEntityTransformer;
  private FXRateTransformer fxRateTransformer;

  public FXRateService() {}

  @Autowired
  public FXRateService(
      final FXRateRepository fxRateRepository,
      final FXRateEntityTransformer fxRateEntityTransformer,
      final FXRateTransformer fxRateTransformer) {
    this.fxRateRepository = fxRateRepository;
    this.fxRateEntityTransformer = fxRateEntityTransformer;
    this.fxRateTransformer = fxRateTransformer;
  }

  @Override
  public Set<FXRate> getFxRatesForBaseCurrency(Long baseCurrencyId) {
    return fxRateRepository.findAllByBaseCurrencyId(baseCurrencyId).stream()
        .map(fxRateTransformer)
        .collect(Collectors.toSet());
  }

  @Override
  public Set<FXRate> getFxRatesForBaseCurrencyAndSourceId(
      Long baseCurrencyId, Set<Long> sourceIds) {
    return fxRateRepository
        .findAllByBaseCurrencyIdAndFxRateSourceIdIn(baseCurrencyId, sourceIds)
        .stream()
        .map(fxRateTransformer)
        .collect(Collectors.toSet());
  }

  @Override
  public Set<FXRate> addFXRates(final Set<FXRate> fxRates) {
    return fxRates.stream()
        .map(fxRateEntityTransformer)
        .map(fxRateEntity -> fxRateRepository.saveAndFlush(fxRateEntity))
        .map(
            fxRateEntity -> {
              log.info(
                  "fxRateEntity saved in pabor db for baseCurrency:{}, localCurrency:{}, reportingFrequency:{}, date:{}",
                  fxRateEntity.getBaseCurrencyId(),
                  fxRateEntity.getLocalCurrencyId(),
                  fxRateEntity.getReportingFrequency(),
                  fxRateEntity.getDate());
              return fxRateTransformer.apply(fxRateEntity);
            })
        .collect(Collectors.toSet());
  }
}
