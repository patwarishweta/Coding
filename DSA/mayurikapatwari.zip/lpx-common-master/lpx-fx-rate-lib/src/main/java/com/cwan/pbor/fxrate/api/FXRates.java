package com.cwan.pbor.fxrate.api;

import com.cwan.lpx.domain.FXRate;
import java.util.Set;

public interface FXRates {
  Set<FXRate> getFxRatesForBaseCurrency(Long baseCurrencyId);

  Set<FXRate> getFxRatesForBaseCurrencyAndSourceId(Long baseCurrencyId, Set<Long> sourceIds);

  Set<FXRate> addFXRates(Set<FXRate> fxRates);
}
