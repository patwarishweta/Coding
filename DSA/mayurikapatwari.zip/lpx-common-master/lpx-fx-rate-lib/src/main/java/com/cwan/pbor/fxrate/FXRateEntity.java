package com.cwan.pbor.fxrate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
@IdClass(FXRateKey.class)
@Table(name = "fx_rates", catalog = "pabor")
public class FXRateEntity implements Serializable {
  @Id private Long baseCurrencyId;
  @Id private Long localCurrencyId;
  @Id private Integer reportingFrequency;
  @Id private LocalDate date;
  @Id private Long fxRateSourceId;
  private Double fxRate;
  private Double averageFxRate;

  private String createdBy;
  private Boolean isCreatedByInternalUser;
  private LocalDateTime createdOn;
  private String modifiedBy;
  private Boolean isModifiedByInternalUser;
  private LocalDateTime modifiedOn;
}
