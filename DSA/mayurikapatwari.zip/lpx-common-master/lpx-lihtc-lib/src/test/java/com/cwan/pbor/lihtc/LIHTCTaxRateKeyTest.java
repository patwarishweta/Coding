package com.cwan.pbor.lihtc;

import static org.junit.jupiter.api.Assertions.*;

import com.cwan.lpx.domain.TaxType;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class LIHTCTaxRateKeyTest {
  @Test
  void testEquals() {
    LIHTCTaxRateKey lihtcTaxRateKey =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCTaxRateKey lihtcTaxRateKey2 =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    assertEquals(lihtcTaxRateKey, lihtcTaxRateKey2);
  }

  @Test
  void testNotEquals_differentAccount() {
    LIHTCTaxRateKey lihtcTaxRateKey =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCTaxRateKey lihtcTaxRateKey2 =
        LIHTCTaxRateKey.builder()
            .accountId(9999L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcTaxRateKey, lihtcTaxRateKey2);
  }

  @Test
  void testNotEquals_differentSecurity() {
    LIHTCTaxRateKey lihtcTaxRateKey =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCTaxRateKey lihtcTaxRateKey2 =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(99999L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcTaxRateKey, lihtcTaxRateKey2);
  }

  @Test
  void testNotEquals_differentTaxType() {
    LIHTCTaxRateKey lihtcTaxRateKey =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(99999L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCTaxRateKey lihtcTaxRateKey2 =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(99999L)
            .taxType(TaxType.STATE)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcTaxRateKey, lihtcTaxRateKey2);
  }

  @Test
  void testNotEquals_differentRateStartDate() {
    LIHTCTaxRateKey lihtcTaxRateKey =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(99999L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCTaxRateKey lihtcTaxRateKey2 =
        LIHTCTaxRateKey.builder()
            .accountId(1234L)
            .securityId(99999L)
            .taxType(TaxType.FEDERAL)
            .taxRateStartDate(LocalDate.of(1900, 1, 1))
            .build();

    assertNotEquals(lihtcTaxRateKey, lihtcTaxRateKey2);
  }
}
