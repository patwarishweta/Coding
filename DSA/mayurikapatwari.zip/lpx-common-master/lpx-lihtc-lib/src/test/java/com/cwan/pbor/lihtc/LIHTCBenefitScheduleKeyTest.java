package com.cwan.pbor.lihtc;

import static org.junit.jupiter.api.Assertions.*;

import com.cwan.lpx.domain.TaxType;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class LIHTCBenefitScheduleKeyTest {
  @Test
  void testEquals() {
    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey2 =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    assertEquals(lihtcBenefitScheduleKey, lihtcBenefitScheduleKey2);
  }

  @Test
  void testNotEquals_differentAccount() {
    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey2 =
        LIHTCBenefitScheduleKey.builder()
            .accountId(999L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcBenefitScheduleKey, lihtcBenefitScheduleKey2);
  }

  @Test
  void testNotEquals_differentSecurity() {
    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey2 =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(99999L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcBenefitScheduleKey, lihtcBenefitScheduleKey2);
  }

  @Test
  void testNotEquals_differentTaxType() {
    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey2 =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.STATE)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcBenefitScheduleKey, lihtcBenefitScheduleKey2);
  }

  @Test
  void testNotEquals_differentReportingDate() {
    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey2 =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(1900, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    assertNotEquals(lihtcBenefitScheduleKey, lihtcBenefitScheduleKey2);
  }

  @Test
  void testNotEquals_differentScheduleDate() {
    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(2022, 1, 1))
            .build();

    LIHTCBenefitScheduleKey lihtcBenefitScheduleKey2 =
        LIHTCBenefitScheduleKey.builder()
            .accountId(1234L)
            .securityId(4567L)
            .taxType(TaxType.FEDERAL)
            .reportingDate(LocalDate.of(2022, 1, 1))
            .scheduleDate(LocalDate.of(1900, 1, 1))
            .build();

    assertNotEquals(lihtcBenefitScheduleKey, lihtcBenefitScheduleKey2);
  }
}
