package com.cwan.pbor.lihtc;

import static org.junit.jupiter.api.Assertions.*;

import com.cwan.lpx.domain.ManualAmortSegment;
import org.junit.jupiter.api.Test;

class ManualAmortSegmentTransformerTest {

  @Test
  void transform_test() {
    ManualAmortSegment originalSegment =
        ManualAmortSegment.builder().basisId(1).bookValue(1.0).accountId(1L).securityId(1L).build();
    ManualAmortSegmentEntity segmentEntity =
        ManualAmortSegmentTransformer.toSegmentEntity(originalSegment);
    ManualAmortSegment transformedSegment = ManualAmortSegmentTransformer.toSegment(segmentEntity);

    assertEquals(transformedSegment, originalSegment);
  }
}
