package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.TaxType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.SneakyThrows;

public class TestUtil {

  @SneakyThrows
  public static LIHTCBenefitSchedule getLIHTCBenefitSchedule() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/lihtc-benefit-schedule.json")),
            LIHTCBenefitSchedule.class);
  }

  @SneakyThrows
  public static LIHTCBenefitScheduleEntity getLIHTCBenefitScheduleEntity() {
    return LIHTCBenefitScheduleEntity.builder()
        .accountId(123L)
        .securityId(456L)
        .reportingDate(LocalDate.of(2023, 1, 1))
        .scheduleDate(LocalDate.of(2023, 2, 1))
        .contributions(1000.10)
        .distributions(2000.20)
        .federalCredits(3000.30)
        .stateCredits(4000.40)
        .otherCredits(5000.50)
        .taxDeductions(6000.60)
        .sale(7000.70)
        .comments("comments")
        .additionalNotes("additionalNotes")
        .action("action")
        .createdBy("createdBy")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2023, 4, 1, 0, 0, 0, 0))
        .modifiedBy("modifiedBy")
        .isModifiedByInternalUser(false)
        .modifiedOn(LocalDateTime.of(2023, 5, 1, 0, 0, 0, 0))
        .build();
  }

  @SneakyThrows
  public static LIHTCTaxRate getLIHTCTaxRate() {
    return getObjectMapper()
        .readValue(
            Files.readString(Path.of("src/test/resources/lihtc-tax-rate.json")),
            LIHTCTaxRate.class);
  }

  @SneakyThrows
  public static LIHTCTaxRateEntity getLIHTCTaxRateEntity() {
    return LIHTCTaxRateEntity.builder()
        .accountId(123L)
        .securityId(456L)
        .taxType(TaxType.FEDERAL)
        .taxRate(1.05)
        .taxRateStartDate(LocalDate.of(2023, 1, 1))
        .additionalNotes("additionalNotes")
        .action("action")
        .createdBy("createdBy")
        .isCreatedByInternalUser(true)
        .createdOn(LocalDateTime.of(2023, 1, 1, 0, 0, 0, 0))
        .modifiedBy("modifiedBy")
        .isModifiedByInternalUser(false)
        .modifiedOn(LocalDateTime.of(2023, 5, 1, 0, 0, 0, 0))
        .build();
  }

  private static ObjectMapper getObjectMapper() {
    return new ObjectMapper().registerModule(new JavaTimeModule());
  }
}
