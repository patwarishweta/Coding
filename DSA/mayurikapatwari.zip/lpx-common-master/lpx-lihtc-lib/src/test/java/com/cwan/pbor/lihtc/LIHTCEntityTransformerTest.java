package com.cwan.pbor.lihtc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import org.junit.jupiter.api.Test;

class LIHTCEntityTransformerTest {
  LIHTCEntityTransformer transformer = new LIHTCEntityTransformer();

  @Test
  void taxRateEntity2TaxRate() {
    LIHTCTaxRateEntity expected = TestUtil.getLIHTCTaxRateEntity();
    LIHTCTaxRate actual = transformer.toTaxRate(expected);

    assertEquals(expected.getAccountId(), actual.account().getId());
    assertEquals(expected.getSecurityId(), actual.security().getSecurityId());
    assertEquals(expected.getTaxType(), actual.taxType());
    assertEquals(expected.getTaxRate(), actual.taxRate());
    assertEquals(expected.getTaxRateStartDate(), actual.taxRateStartDate());
    assertEquals(expected.getAdditionalNotes(), actual.additionalNotes());
    assertEquals(expected.getAction(), actual.action());
    assertEquals(expected.getCreatedBy(), actual.createdBy());
    assertEquals(expected.getIsCreatedByInternalUser(), actual.isCreatedByInternalUser());
    assertEquals(expected.getCreatedOn(), actual.createdOn());
    assertEquals(expected.getModifiedBy(), actual.modifiedBy());
    assertEquals(expected.getIsModifiedByInternalUser(), actual.isModifiedByInternalUser());
    assertEquals(expected.getModifiedOn(), actual.modifiedOn());
  }

  @Test
  void taxRate2TaxRateEntity() {
    LIHTCTaxRate expected = TestUtil.getLIHTCTaxRate();
    LIHTCTaxRateEntity actual = transformer.toTaxRateEntity(expected);

    assertEquals(expected.account().getId(), actual.getAccountId());
    assertEquals(expected.security().getSecurityId(), actual.getSecurityId());
    assertEquals(expected.taxType(), actual.getTaxType());
    assertEquals(expected.taxRate(), actual.getTaxRate());
    assertEquals(expected.taxRateStartDate(), actual.getTaxRateStartDate());
    assertEquals(expected.additionalNotes(), actual.getAdditionalNotes());
    assertEquals(expected.action(), actual.getAction());
    assertEquals(expected.createdBy(), actual.getCreatedBy());
    assertEquals(expected.isCreatedByInternalUser(), actual.getIsCreatedByInternalUser());
    assertEquals(expected.createdOn(), actual.getCreatedOn());
    assertEquals(expected.modifiedBy(), actual.getModifiedBy());
    assertEquals(expected.isModifiedByInternalUser(), actual.getIsModifiedByInternalUser());
    assertEquals(expected.modifiedOn(), actual.getModifiedOn());
  }

  @Test
  void benefitScheduleEntity2BenefitSchedule() {
    LIHTCBenefitScheduleEntity expected = TestUtil.getLIHTCBenefitScheduleEntity();
    LIHTCBenefitSchedule actual = transformer.toBenefitSchedule(expected);

    assertEquals(expected.getAccountId(), actual.account().getId());
    assertEquals(expected.getSecurityId(), actual.security().getSecurityId());
    assertEquals(expected.getTaxType(), actual.taxType());
    assertEquals(expected.getReportingDate(), actual.reportingDate());
    assertEquals(expected.getScheduleDate(), actual.scheduleDate());
    assertEquals(expected.getContributions(), actual.contributions());
    assertEquals(expected.getDistributions(), actual.distributions());
    assertEquals(expected.getFederalCredits(), actual.federalCredits());
    assertEquals(expected.getStateCredits(), actual.stateCredits());
    assertEquals(expected.getOtherCredits(), actual.otherCredits());
    assertEquals(expected.getTaxDeductions(), actual.taxDeductions());
    assertEquals(expected.getSale(), actual.sale());
    assertEquals(expected.getComments(), actual.comments());
    assertEquals(expected.getAdditionalNotes(), actual.additionalNotes());
    assertEquals(expected.getAction(), actual.action());
    assertEquals(expected.getCreatedBy(), actual.createdBy());
    assertEquals(expected.getIsCreatedByInternalUser(), actual.isCreatedByInternalUser());
    assertEquals(expected.getCreatedOn(), actual.createdOn());
    assertEquals(expected.getModifiedBy(), actual.modifiedBy());
    assertEquals(expected.getIsModifiedByInternalUser(), actual.isModifiedByInternalUser());
    assertEquals(expected.getModifiedOn(), actual.modifiedOn());
  }

  @Test
  void benefitSchedule2BenefitScheduleEntity() {
    LIHTCBenefitSchedule expected = TestUtil.getLIHTCBenefitSchedule();
    LIHTCBenefitScheduleEntity actual = transformer.toBenefitScheduleEntity(expected);

    assertEquals(expected.account().getId(), actual.getAccountId());
    assertEquals(expected.security().getSecurityId(), actual.getSecurityId());
    assertEquals(expected.taxType(), actual.getTaxType());
    assertEquals(expected.reportingDate(), actual.getReportingDate());
    assertEquals(expected.scheduleDate(), actual.getScheduleDate());
    assertEquals(expected.contributions(), actual.getContributions());
    assertEquals(expected.distributions(), actual.getDistributions());
    assertEquals(expected.federalCredits(), actual.getFederalCredits());
    assertEquals(expected.stateCredits(), actual.getStateCredits());
    assertEquals(expected.otherCredits(), actual.getOtherCredits());
    assertEquals(expected.taxDeductions(), actual.getTaxDeductions());
    assertEquals(expected.sale(), actual.getSale());
    assertEquals(expected.comments(), actual.getComments());
    assertEquals(expected.additionalNotes(), actual.getAdditionalNotes());
    assertEquals(expected.action(), actual.getAction());
    assertEquals(expected.createdBy(), actual.getCreatedBy());
    assertEquals(expected.isCreatedByInternalUser(), actual.getIsCreatedByInternalUser());
    assertEquals(expected.createdOn(), actual.getCreatedOn());
    assertEquals(expected.modifiedBy(), actual.getModifiedBy());
    assertEquals(expected.isModifiedByInternalUser(), actual.getIsModifiedByInternalUser());
    assertEquals(expected.modifiedOn(), actual.getModifiedOn());
  }
}
