package com.cwan.pbor.lihtc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.TaxType;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.test.StepVerifier;

class LIHTCServiceImplTest {

  @Mock private LIHTCBenefitScheduleRepository mockLIHTCBenefitScheduleRepository;
  @Mock private LIHTCTaxRateRepository mockLIHTCTaxRateRepository;
  @Mock private ManualAmortSegmentRepository manualAmortSegmentRepository;
  private final LIHTCEntityTransformer lihtcEntityTransformer = new LIHTCEntityTransformer();
  private LIHTCServiceImpl lihtcServiceImpl;

  @BeforeEach
  void setUp() {
    openMocks(this);
    lihtcServiceImpl =
        new LIHTCServiceImpl(
            lihtcEntityTransformer,
            mockLIHTCBenefitScheduleRepository,
            mockLIHTCTaxRateRepository,
            manualAmortSegmentRepository);
  }

  @Test
  void addBenefitSchedules() {
    when(mockLIHTCBenefitScheduleRepository.saveAndFlush(any(LIHTCBenefitScheduleEntity.class)))
        .thenReturn(TestUtil.getLIHTCBenefitScheduleEntity());
    StepVerifier.create(
            lihtcServiceImpl.addBenefitSchedules(List.of(TestUtil.getLIHTCBenefitSchedule())))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void addBenefitSchedulesErrorSaving() {
    when(mockLIHTCBenefitScheduleRepository.saveAndFlush(any(LIHTCBenefitScheduleEntity.class)))
        .thenThrow(LIHTCException.class);
    StepVerifier.create(
            lihtcServiceImpl.addBenefitSchedules(List.of(TestUtil.getLIHTCBenefitSchedule())))
        .expectError(LIHTCException.class)
        .verify();
  }

  @Test
  void getBenefitSchedulesForAccountSecurityPair() {
    when(mockLIHTCBenefitScheduleRepository.findAllByAccountIdAndSecurityId(any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCBenefitScheduleEntity()));
    StepVerifier.create(lihtcServiceImpl.getBenefitSchedulesForAccountSecurityPair(1L, 1L))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void getBenefitSchedulesForAccountSecurityForReportingDate() {
    when(mockLIHTCBenefitScheduleRepository.findAllByAccountIdAndSecurityIdAndReportingDate(
            any(), any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCBenefitScheduleEntity()));
    StepVerifier.create(
            lihtcServiceImpl.getBenefitSchedulesForAccountSecurityForReportingDate(
                1L, 1L, LocalDate.now()))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType() {
    when(mockLIHTCBenefitScheduleRepository
            .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
                any(), any(), any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCBenefitScheduleEntity()));
    StepVerifier.create(
            lihtcServiceImpl
                .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
                    1L, 1L, LocalDate.now(), TaxType.FEDERAL))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate() {
    when(mockLIHTCBenefitScheduleRepository
            .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
                any(), any(), any(), any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCBenefitScheduleEntity()));
    StepVerifier.create(
            lihtcServiceImpl
                .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
                    1L, 1L, LocalDate.now(), TaxType.FEDERAL, LocalDate.now()))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void addTaxRates() {
    when(mockLIHTCTaxRateRepository.saveAndFlush(any(LIHTCTaxRateEntity.class)))
        .thenReturn(TestUtil.getLIHTCTaxRateEntity());
    StepVerifier.create(lihtcServiceImpl.addTaxRates(List.of(TestUtil.getLIHTCTaxRate())))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void addTaxRatesErrorSaving() {
    when(mockLIHTCTaxRateRepository.saveAndFlush(any(LIHTCTaxRateEntity.class)))
        .thenThrow(LIHTCException.class);
    StepVerifier.create(lihtcServiceImpl.addTaxRates(List.of(TestUtil.getLIHTCTaxRate())))
        .expectError(LIHTCException.class)
        .verify();
  }

  @Test
  void getTaxRatesForAccountSecurityPair() {
    when(mockLIHTCTaxRateRepository.findAllByAccountIdAndSecurityId(any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCTaxRateEntity()));
    StepVerifier.create(lihtcServiceImpl.getTaxRatesForAccountSecurityPair(1L, 1L))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void getTaxRatesForAccountSecurityForTaxType() {
    when(mockLIHTCTaxRateRepository.findAllByAccountIdAndSecurityIdAndTaxType(any(), any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCTaxRateEntity()));
    StepVerifier.create(
            lihtcServiceImpl.getTaxRatesForAccountSecurityForTaxType(1L, 1L, TaxType.FEDERAL))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId() {
    when(mockLIHTCTaxRateRepository.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(
            any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCTaxRateEntity()));
    StepVerifier.create(lihtcServiceImpl.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(1L, 1L))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType() {
    when(mockLIHTCTaxRateRepository.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
            any(), any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCTaxRateEntity()));
    StepVerifier.create(
            lihtcServiceImpl.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
                1L, 1L, TaxType.FEDERAL))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate() {
    when(mockLIHTCTaxRateRepository
            .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
                any(), any(), any(), any()))
        .thenReturn(List.of(TestUtil.getLIHTCTaxRateEntity()));
    StepVerifier.create(
            lihtcServiceImpl
                .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
                    1L, 1L, TaxType.FEDERAL, LocalDate.now()))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void testSaveManualAmortSegments() {
    // Given
    Set<ManualAmortSegment> manualAmortSegments = new HashSet<>();
    manualAmortSegments.add(ManualAmortSegment.builder().accountId(1L).build());
    manualAmortSegments.add(ManualAmortSegment.builder().accountId(2L).build());
    // When
    lihtcServiceImpl.saveManualAmortSegments(manualAmortSegments);
    // Then
    Set<ManualAmortSegmentEntity> expectedEntities =
        manualAmortSegments.stream()
            .map(ManualAmortSegmentTransformer::toSegmentEntity)
            .collect(Collectors.toSet());
    verify(manualAmortSegmentRepository, times(1)).saveAll(expectedEntities);
  }

  @Test
  void testGetSegmentMap() {
    // Given
    Long accountId = 1L;
    Long securityId = 1L;
    int basisId = 1;
    ManualAmortSegment segment1 =
        ManualAmortSegment.builder().effectiveDate(LocalDate.of(2023, 1, 1)).build();
    ManualAmortSegment segment2 =
        ManualAmortSegment.builder().effectiveDate(LocalDate.of(2023, 2, 1)).build();
    Set<ManualAmortSegment> segments = new HashSet<>(Arrays.asList(segment1, segment2));
    when(manualAmortSegmentRepository.findAllByAccountIdAndSecurityIdAndBasisIdAndIsActiveIsTrue(
            accountId, securityId, basisId))
        .thenReturn(
            segments.stream()
                .map(ManualAmortSegmentTransformer::toSegmentEntity)
                .collect(Collectors.toSet()));
    // When
    TreeMap<LocalDate, ManualAmortSegment> result =
        lihtcServiceImpl.getSegmentMap(accountId, securityId, basisId);
    // Then
    assertEquals(2, result.size());
    assertTrue(result.containsKey(LocalDate.of(2023, 1, 1)));
    assertTrue(result.containsKey(LocalDate.of(2023, 2, 1)));
    assertEquals(segment1, result.get(LocalDate.of(2023, 1, 1)));
    assertEquals(segment2, result.get(LocalDate.of(2023, 2, 1)));
  }

  @Test
  void testGetSegments() {
    // Given
    Long accountId = 1L;
    Long securityId = 1L;
    int basisId = 1;
    ManualAmortSegmentEntity entity = ManualAmortSegmentEntity.builder().id(1L).build();
    Set<ManualAmortSegmentEntity> entities = new HashSet<>(Collections.singletonList(entity));
    when(manualAmortSegmentRepository.findAllByAccountIdAndSecurityIdAndBasisIdAndIsActiveIsTrue(
            accountId, securityId, basisId))
        .thenReturn(entities);
    // When
    Set<ManualAmortSegment> result = lihtcServiceImpl.getSegments(accountId, securityId, basisId);
    // Then
    assertEquals(1, result.size());
    assertTrue(result.contains(ManualAmortSegmentTransformer.toSegment(entity)));
  }
}
