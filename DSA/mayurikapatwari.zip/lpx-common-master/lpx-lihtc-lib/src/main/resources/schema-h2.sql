create schema if not exists pabor;

-- FROM: pbor-db-aws/src/master/src/main/resources/sql/pabor.lihtc_benefit_schedule.sql
create table if not exists pabor.lihtc_benefit_schedule
(
  account_id                   BIGINT       NOT NULL,
  security_id                  BIGINT       NOT NULL,
  tax_type                     VARCHAR(32)  NULL,
  reporting_date               DATE         NULL,
  schedule_date                DATE         NULL,
  contributions                DOUBLE       NULL,
  distributions                DOUBLE       NULL,
  federal_credits              DOUBLE       NULL,
  state_credits                DOUBLE       NULL,
  other_credits                DOUBLE       NULL,
  tax_deductions               DOUBLE       NULL,
  sale                         DOUBLE       NULL,
  comments                     VARCHAR(256) NULL,
  additional_notes             VARCHAR(256) NULL,
  action                       VARCHAR(50)  NULL,
  created_by                   VARCHAR(256) NULL,
  is_created_by_internal_user  BIT          NULL,
  created_on                   TIMESTAMP    NULL,
  modified_by                  VARCHAR(256) NULL,
  is_modified_by_internal_user BIT          NULL,
  modified_on                  TIMESTAMP    NULL
);

-- FROM: pbor-db-aws/src/master/src/main/resources/sql/pabor.lihtc_tax_rate.sql
create table if not exists pabor.lihtc_tax_rate
(
  account_id                   BIGINT       NOT NULL,
  security_id                  BIGINT       NOT NULL,
  tax_type                     VARCHAR(25)  NOT NULL,
  tax_rate                     DOUBLE       NOT NULL,
  tax_rate_start_date          DATE         NOT NULL,
  additional_notes             VARCHAR(256) NOT NULL,
  action                       VARCHAR(50)  NULL,
  created_by                   VARCHAR(256) NULL,
  is_created_by_internal_user  BIT          NULL,
  created_on                   TIMESTAMP    NULL,
  modified_by                  VARCHAR(256) NULL,
  is_modified_by_internal_user BIT          NULL,
  modified_on                  TIMESTAMP    NULL
);
