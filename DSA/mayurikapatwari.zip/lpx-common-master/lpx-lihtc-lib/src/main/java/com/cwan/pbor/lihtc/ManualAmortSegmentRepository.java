package com.cwan.pbor.lihtc;

import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManualAmortSegmentRepository
    extends JpaRepository<ManualAmortSegmentEntity, Long> {
  Collection<ManualAmortSegmentEntity> findAllByAccountIdAndSecurityIdAndBasisIdAndIsActiveIsTrue(
      Long accountId, Long securityId, int basisId);
}
