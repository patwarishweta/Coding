package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.TaxType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Data
@IdClass(LIHTCBenefitScheduleKey.class)
@AllArgsConstructor
@NoArgsConstructor(force = true)
@Builder
@Table(name = "lihtc_benefit_schedule", catalog = "pabor")
public class LIHTCBenefitScheduleEntity {

  @Id private Long accountId;

  @Id private Long securityId;

  @Enumerated(EnumType.STRING)
  private TaxType taxType;

  private LocalDate reportingDate;
  private LocalDate scheduleDate;
  private Double contributions;
  private Double distributions;
  private Double federalCredits;
  private Double stateCredits;
  private Double otherCredits;
  private Double taxDeductions;
  private Double sale;
  private String comments;
  private String additionalNotes;
  private String action;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  @CreationTimestamp private LocalDateTime createdOn;
  private String modifiedBy;
  private Boolean isModifiedByInternalUser;
  @UpdateTimestamp private LocalDateTime modifiedOn;

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (LIHTCBenefitScheduleEntity) o;
    return (this.accountId != null)
        && Objects.equals(accountId, that.accountId)
        && (this.securityId != null)
        && Objects.equals(securityId, that.securityId)
        && (taxType != null)
        && Objects.equals(taxType, that.taxType)
        && (reportingDate != null)
        && Objects.equals(reportingDate, that.reportingDate)
        && (scheduleDate != null)
        && Objects.equals(scheduleDate, that.scheduleDate);
  }
}
