package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.TaxType;
import java.time.LocalDate;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

public interface LIHTCTaxRateRepository extends JpaRepository<LIHTCTaxRateEntity, LIHTCTaxRateKey> {
  Collection<LIHTCTaxRateEntity> findAllByAccountIdAndSecurityId(Long accountId, Long securityId);

  Collection<LIHTCTaxRateEntity> findAllByAccountIdAndSecurityIdAndTaxType(
      Long accountId, Long securityId, TaxType taxType);

  @Transactional
  Collection<LIHTCTaxRateEntity> deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(
      Long accountId, Long securityId);

  @Transactional
  Collection<LIHTCTaxRateEntity> deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
      Long accountId, Long securityId, TaxType taxType);

  @Transactional
  Collection<LIHTCTaxRateEntity>
      deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
          Long accountId, Long securityId, TaxType taxType, LocalDate taxRateStartDate);
}
