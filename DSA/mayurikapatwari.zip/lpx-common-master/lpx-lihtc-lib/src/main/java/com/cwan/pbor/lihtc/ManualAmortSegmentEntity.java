package com.cwan.pbor.lihtc;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor(force = true)
@Builder
@Table(name = "manual_amort_segment", catalog = "pabor")
public class ManualAmortSegmentEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  long accountId;
  long securityId;
  int basisId;
  double bookValue;
  LocalDate effectiveDate;
  boolean isActive;
  String createdBy;
  Boolean isCreatedByInternalUser;
  LocalDateTime createdOn;
  String modifiedBy;
  Boolean isModifiedByInternalUser;
  LocalDateTime modifiedOn;
}
