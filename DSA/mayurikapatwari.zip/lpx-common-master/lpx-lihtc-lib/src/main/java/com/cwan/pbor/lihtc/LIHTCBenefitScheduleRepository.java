package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.TaxType;
import java.time.LocalDate;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

public interface LIHTCBenefitScheduleRepository
    extends JpaRepository<LIHTCBenefitScheduleEntity, LIHTCBenefitScheduleKey> {
  Collection<LIHTCBenefitScheduleEntity> findAllByAccountIdAndSecurityId(
      Long accountId, Long securityId);

  Collection<LIHTCBenefitScheduleEntity> findAllByAccountIdAndSecurityIdAndReportingDate(
      Long accountId, Long securityId, LocalDate reportingDate);

  @Transactional
  Collection<LIHTCBenefitScheduleEntity>
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
          Long accoundId, Long securityId, LocalDate reportingDate, TaxType taxType);

  @Transactional
  Collection<LIHTCBenefitScheduleEntity>
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
          Long accoundId,
          Long securityId,
          LocalDate reportingDate,
          TaxType taxType,
          LocalDate scheduleDate);
}
