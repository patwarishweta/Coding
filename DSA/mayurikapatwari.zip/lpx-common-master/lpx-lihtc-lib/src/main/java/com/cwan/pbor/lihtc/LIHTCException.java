package com.cwan.pbor.lihtc;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class LIHTCException extends ResponseStatusException {

  public LIHTCException(String msg, Throwable e) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, msg, e);
  }

  public LIHTCException(String msg) {
    super(HttpStatus.BAD_REQUEST, msg);
  }
}
