package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.ManualAmortSegment;
import org.springframework.stereotype.Component;

@Component
public class ManualAmortSegmentTransformer {
  private ManualAmortSegmentTransformer() {}

  public static ManualAmortSegment toSegment(ManualAmortSegmentEntity segmentEntity) {
    return ManualAmortSegment.builder()
        .id(segmentEntity.getId())
        .accountId(segmentEntity.getAccountId())
        .securityId(segmentEntity.getSecurityId())
        .basisId(segmentEntity.getBasisId())
        .bookValue(segmentEntity.getBookValue())
        .effectiveDate(segmentEntity.getEffectiveDate())
        .isActive(segmentEntity.isActive())
        .createdBy(segmentEntity.getCreatedBy())
        .isCreatedByInternalUser(segmentEntity.getIsCreatedByInternalUser())
        .createdOn(segmentEntity.getCreatedOn())
        .modifiedBy(segmentEntity.getModifiedBy())
        .isModifiedByInternalUser(segmentEntity.getIsModifiedByInternalUser())
        .modifiedOn(segmentEntity.getModifiedOn())
        .build();
  }

  public static ManualAmortSegmentEntity toSegmentEntity(ManualAmortSegment segment) {
    return ManualAmortSegmentEntity.builder()
        .id(segment.id())
        .accountId(segment.accountId())
        .securityId(segment.securityId())
        .basisId(segment.basisId())
        .bookValue(segment.bookValue())
        .effectiveDate(segment.effectiveDate())
        .isActive(segment.isActive())
        .createdBy(segment.createdBy())
        .isCreatedByInternalUser(segment.isCreatedByInternalUser())
        .createdOn(segment.createdOn())
        .modifiedBy(segment.modifiedBy())
        .isModifiedByInternalUser(segment.isModifiedByInternalUser())
        .modifiedOn(segment.modifiedOn())
        .build();
  }
}
