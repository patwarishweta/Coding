package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.Security;
import org.springframework.stereotype.Component;

@Component
public class LIHTCEntityTransformer {
  public LIHTCBenefitScheduleEntity toBenefitScheduleEntity(
      LIHTCBenefitSchedule lihtcBenefitSchedule) {
    return LIHTCBenefitScheduleEntity.builder()
        .accountId(lihtcBenefitSchedule.account().getId())
        .securityId(lihtcBenefitSchedule.security().getSecurityId())
        .taxType(lihtcBenefitSchedule.taxType())
        .reportingDate(lihtcBenefitSchedule.reportingDate())
        .scheduleDate(lihtcBenefitSchedule.scheduleDate())
        .contributions(lihtcBenefitSchedule.contributions())
        .distributions(lihtcBenefitSchedule.distributions())
        .federalCredits(lihtcBenefitSchedule.federalCredits())
        .stateCredits(lihtcBenefitSchedule.stateCredits())
        .otherCredits(lihtcBenefitSchedule.otherCredits())
        .taxDeductions(lihtcBenefitSchedule.taxDeductions())
        .sale(lihtcBenefitSchedule.sale())
        .comments(lihtcBenefitSchedule.comments())
        .additionalNotes(lihtcBenefitSchedule.additionalNotes())
        .action(lihtcBenefitSchedule.action())
        .createdBy(lihtcBenefitSchedule.createdBy())
        .isCreatedByInternalUser(lihtcBenefitSchedule.isCreatedByInternalUser())
        .createdOn(lihtcBenefitSchedule.createdOn())
        .modifiedBy(lihtcBenefitSchedule.modifiedBy())
        .isModifiedByInternalUser(lihtcBenefitSchedule.isModifiedByInternalUser())
        .modifiedOn(lihtcBenefitSchedule.modifiedOn())
        .build();
  }

  public LIHTCBenefitSchedule toBenefitSchedule(
      LIHTCBenefitScheduleEntity lihtcBenefitScheduleEntity) {
    return LIHTCBenefitSchedule.builder()
        .account(Account.builder().id(lihtcBenefitScheduleEntity.getAccountId()).build())
        .security(Security.builder().securityId(lihtcBenefitScheduleEntity.getSecurityId()).build())
        .taxType(lihtcBenefitScheduleEntity.getTaxType())
        .reportingDate(lihtcBenefitScheduleEntity.getReportingDate())
        .scheduleDate(lihtcBenefitScheduleEntity.getScheduleDate())
        .contributions(lihtcBenefitScheduleEntity.getContributions())
        .distributions(lihtcBenefitScheduleEntity.getDistributions())
        .federalCredits(lihtcBenefitScheduleEntity.getFederalCredits())
        .stateCredits(lihtcBenefitScheduleEntity.getStateCredits())
        .otherCredits(lihtcBenefitScheduleEntity.getOtherCredits())
        .taxDeductions(lihtcBenefitScheduleEntity.getTaxDeductions())
        .sale(lihtcBenefitScheduleEntity.getSale())
        .comments(lihtcBenefitScheduleEntity.getComments())
        .additionalNotes(lihtcBenefitScheduleEntity.getAdditionalNotes())
        .action(lihtcBenefitScheduleEntity.getAction())
        .createdBy(lihtcBenefitScheduleEntity.getCreatedBy())
        .isCreatedByInternalUser(lihtcBenefitScheduleEntity.getIsCreatedByInternalUser())
        .createdOn(lihtcBenefitScheduleEntity.getCreatedOn())
        .modifiedBy(lihtcBenefitScheduleEntity.getModifiedBy())
        .isModifiedByInternalUser(lihtcBenefitScheduleEntity.getIsModifiedByInternalUser())
        .modifiedOn(lihtcBenefitScheduleEntity.getModifiedOn())
        .build();
  }

  public LIHTCTaxRateEntity toTaxRateEntity(LIHTCTaxRate lihtcTaxRate) {
    return LIHTCTaxRateEntity.builder()
        .accountId(lihtcTaxRate.account().getId())
        .securityId(lihtcTaxRate.security().getSecurityId())
        .taxType(lihtcTaxRate.taxType())
        .taxRate(lihtcTaxRate.taxRate())
        .taxRateStartDate(lihtcTaxRate.taxRateStartDate())
        .additionalNotes(lihtcTaxRate.additionalNotes())
        .action(lihtcTaxRate.action())
        .createdBy(lihtcTaxRate.createdBy())
        .isCreatedByInternalUser(lihtcTaxRate.isCreatedByInternalUser())
        .createdOn(lihtcTaxRate.createdOn())
        .modifiedBy(lihtcTaxRate.modifiedBy())
        .isModifiedByInternalUser(lihtcTaxRate.isModifiedByInternalUser())
        .modifiedOn(lihtcTaxRate.modifiedOn())
        .build();
  }

  public LIHTCTaxRate toTaxRate(LIHTCTaxRateEntity lihtcTaxRateEntity) {
    return LIHTCTaxRate.builder()
        .account(Account.builder().id(lihtcTaxRateEntity.getAccountId()).build())
        .security(Security.builder().securityId(lihtcTaxRateEntity.getSecurityId()).build())
        .taxType(lihtcTaxRateEntity.getTaxType())
        .taxRate(lihtcTaxRateEntity.getTaxRate())
        .taxRateStartDate(lihtcTaxRateEntity.getTaxRateStartDate())
        .additionalNotes(lihtcTaxRateEntity.getAdditionalNotes())
        .action(lihtcTaxRateEntity.getAction())
        .createdBy(lihtcTaxRateEntity.getCreatedBy())
        .isCreatedByInternalUser(lihtcTaxRateEntity.getIsCreatedByInternalUser())
        .createdOn(lihtcTaxRateEntity.getCreatedOn())
        .modifiedBy(lihtcTaxRateEntity.getModifiedBy())
        .isModifiedByInternalUser(lihtcTaxRateEntity.getIsModifiedByInternalUser())
        .modifiedOn(lihtcTaxRateEntity.getModifiedOn())
        .build();
  }
}
