package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.TaxType;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.Hibernate;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
public class LIHTCBenefitScheduleKey implements Serializable {
  private Long accountId;
  private Long securityId;
  private TaxType taxType;
  private LocalDate reportingDate;
  private LocalDate scheduleDate;

  @Override
  public int hashCode() {
    return Objects.hash(accountId, securityId, taxType, reportingDate, scheduleDate);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (LIHTCBenefitScheduleKey) o;
    return (accountId != null)
        && Objects.equals(accountId, that.accountId)
        && (securityId != null)
        && Objects.equals(securityId, that.securityId)
        && (taxType != null)
        && Objects.equals(taxType, that.taxType)
        && (reportingDate != null)
        && Objects.equals(reportingDate, that.reportingDate)
        && (scheduleDate != null)
        && Objects.equals(scheduleDate, that.scheduleDate);
  }
}
