package com.cwan.pbor.lihtc.api;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.TaxType;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Set;
import java.util.TreeMap;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

public interface LIHTCService {

  @Transactional
  Flux<LIHTCBenefitSchedule> addBenefitSchedules(
      Collection<LIHTCBenefitSchedule> lihtcBenefitSchedules);

  Flux<LIHTCBenefitSchedule> getBenefitSchedulesForAccountSecurityPair(
      Long accountId, Long securityId);

  Flux<LIHTCBenefitSchedule> getBenefitSchedulesForAccountSecurityForReportingDate(
      Long accountId, Long securityId, LocalDate reportingDate);

  @Transactional
  Flux<LIHTCBenefitSchedule>
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
          Long accountId, Long securityId, LocalDate reportingDate, TaxType taxType);

  @Transactional
  Flux<LIHTCBenefitSchedule>
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
          Long accountId,
          Long securityId,
          LocalDate reportingDate,
          TaxType taxType,
          LocalDate scheduleDate);

  @Transactional
  Flux<LIHTCTaxRate> addTaxRates(Collection<LIHTCTaxRate> lihtcTaxRates);

  Flux<LIHTCTaxRate> getTaxRatesForAccountSecurityPair(Long accountId, Long securityId);

  Flux<LIHTCTaxRate> getTaxRatesForAccountSecurityForTaxType(
      Long accountId, Long securityId, TaxType taxType);

  @Transactional
  Flux<LIHTCTaxRate> deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(
      Long accountId, Long securityId);

  @Transactional
  Flux<LIHTCTaxRate> deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
      Long accountId, Long securityId, TaxType taxType);

  @Transactional
  Flux<LIHTCTaxRate>
      deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
          Long accountId, Long securityId, TaxType taxType, LocalDate taxRateStartDate);

  TreeMap<LocalDate, ManualAmortSegment> getSegmentMap(
      Long accountId, Long securityId, int basisId);

  @Transactional
  Set<ManualAmortSegment> getSegments(Long accountId, Long securityId, int basisId);

  void saveManualAmortSegments(Set<ManualAmortSegment> manualAmortSegments);
}
