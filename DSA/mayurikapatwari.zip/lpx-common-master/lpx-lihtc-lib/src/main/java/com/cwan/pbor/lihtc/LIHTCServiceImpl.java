package com.cwan.pbor.lihtc;

import com.cwan.lpx.domain.LIHTCBenefitSchedule;
import com.cwan.lpx.domain.LIHTCTaxRate;
import com.cwan.lpx.domain.ManualAmortSegment;
import com.cwan.lpx.domain.TaxType;
import com.cwan.pbor.lihtc.api.LIHTCService;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

@Service
@Slf4j
@NoArgsConstructor
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class LIHTCServiceImpl implements LIHTCService {

  private LIHTCEntityTransformer lihtcEntityTransformer;
  private LIHTCBenefitScheduleRepository lihtcBenefitScheduleRepository;
  private LIHTCTaxRateRepository lihtcTaxRateRepository;
  private ManualAmortSegmentRepository manualAmortSegmentRepository;

  @Override
  @Transactional
  public Flux<LIHTCBenefitSchedule> addBenefitSchedules(
      final Collection<LIHTCBenefitSchedule> lihtcBenefitSchedules) {
    Collection<LIHTCBenefitScheduleEntity> lihtcBenefitScheduleEntities =
        lihtcBenefitSchedules.stream()
            .map(lihtcEntityTransformer::toBenefitScheduleEntity)
            .collect(Collectors.toList());
    try {
      return createBenefitSchedules(Flux.fromIterable(lihtcBenefitScheduleEntities));
    } catch (Exception e) {
      throw new LIHTCException("Error saving LIHTC Benefit Schedules.", e);
    }
  }

  @Override
  public Flux<LIHTCBenefitSchedule> getBenefitSchedulesForAccountSecurityPair(
      final Long accountId, final Long securityId) {
    return Flux.fromIterable(
            lihtcBenefitScheduleRepository.findAllByAccountIdAndSecurityId(accountId, securityId))
        .log("findByAccountIdAndSecurityId")
        .map(lihtcEntityTransformer::toBenefitSchedule);
  }

  @Override
  public Flux<LIHTCBenefitSchedule> getBenefitSchedulesForAccountSecurityForReportingDate(
      final Long accountId, final Long securityId, final LocalDate reportingDate) {
    return Flux.fromIterable(
            lihtcBenefitScheduleRepository.findAllByAccountIdAndSecurityIdAndReportingDate(
                accountId, securityId, reportingDate))
        .log("findByAccountIdAndSecurityIdAndReportingDate")
        .map(lihtcEntityTransformer::toBenefitSchedule);
  }

  @Override
  @Transactional
  public Flux<LIHTCBenefitSchedule>
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
          final Long accountId,
          final Long securityId,
          final LocalDate reportingDate,
          final TaxType taxType) {
    return Flux.fromIterable(
            lihtcBenefitScheduleRepository
                .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType(
                    accountId, securityId, reportingDate, taxType))
        .log("deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxType")
        .map(lihtcEntityTransformer::toBenefitSchedule);
  }

  @Override
  @Transactional
  public Flux<LIHTCBenefitSchedule>
      deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
          final Long accountId,
          final Long securityId,
          final LocalDate reportingDate,
          final TaxType taxType,
          final LocalDate scheduleDate) {
    return Flux.fromIterable(
            lihtcBenefitScheduleRepository
                .deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate(
                    accountId, securityId, reportingDate, taxType, scheduleDate))
        .log(
            "deleteLIHTCBenefitScheduleEntitiesByAccountIdAndSecurityIdAndReportingDateAndTaxTypeAndScheduleDate")
        .map(lihtcEntityTransformer::toBenefitSchedule);
  }

  @Override
  @Transactional
  public Flux<LIHTCTaxRate> addTaxRates(final Collection<LIHTCTaxRate> lihtcTaxRates) {
    Collection<LIHTCTaxRateEntity> lihtcTaxRateEntities =
        lihtcTaxRates.stream()
            .map(lihtcEntityTransformer::toTaxRateEntity)
            .collect(Collectors.toList());
    try {
      return createTaxRate(Flux.fromIterable(lihtcTaxRateEntities));
    } catch (Exception e) {
      throw new LIHTCException("Error saving LIHTC Tax Rate.", e);
    }
  }

  @Override
  public Flux<LIHTCTaxRate> getTaxRatesForAccountSecurityPair(
      final Long accountId, final Long securityId) {
    return Flux.fromIterable(
            lihtcTaxRateRepository.findAllByAccountIdAndSecurityId(accountId, securityId))
        .log("findByAccountIdAndSecurityId")
        .map(lihtcEntityTransformer::toTaxRate);
  }

  @Override
  public Flux<LIHTCTaxRate> getTaxRatesForAccountSecurityForTaxType(
      final Long accountId, final Long securityId, final TaxType taxType) {
    return Flux.fromIterable(
            lihtcTaxRateRepository.findAllByAccountIdAndSecurityIdAndTaxType(
                accountId, securityId, taxType))
        .log("findByAccountIdAndSecurityIdAndTaxType")
        .map(lihtcEntityTransformer::toTaxRate);
  }

  @Override
  @Transactional
  public Flux<LIHTCTaxRate> deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(
      final Long accountId, final Long securityId) {
    return Flux.fromIterable(
            lihtcTaxRateRepository.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId(
                accountId, securityId))
        .log("deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityId")
        .map(lihtcEntityTransformer::toTaxRate);
  }

  @Override
  @Transactional
  public Flux<LIHTCTaxRate> deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
      final Long accountId, final Long securityId, final TaxType taxType) {
    return Flux.fromIterable(
            lihtcTaxRateRepository.deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType(
                accountId, securityId, taxType))
        .log("deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxType")
        .map(lihtcEntityTransformer::toTaxRate);
  }

  @Override
  @Transactional
  public Flux<LIHTCTaxRate>
      deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
          final Long accountId,
          final Long securityId,
          final TaxType taxType,
          final LocalDate taxRateStartDate) {
    return Flux.fromIterable(
            lihtcTaxRateRepository
                .deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate(
                    accountId, securityId, taxType, taxRateStartDate))
        .log("deleteLIHTCTaxRateEntitiesByAccountIdAndSecurityIdAndTaxTypeAndTaxRateStartDate")
        .map(lihtcEntityTransformer::toTaxRate);
  }

  private Flux<LIHTCBenefitSchedule> createBenefitSchedules(
      final Flux<LIHTCBenefitScheduleEntity> lihtcBenefitScheduleEntities) {
    return lihtcBenefitScheduleEntities
        .map(lihtcBenefitScheduleRepository::saveAndFlush)
        .log("Saved LIHTC Benefit Schedule.")
        .map(lihtcEntityTransformer::toBenefitSchedule);
  }

  private Flux<LIHTCTaxRate> createTaxRate(final Flux<LIHTCTaxRateEntity> lihtcTaxRateEntities) {
    return lihtcTaxRateEntities
        .map(lihtcTaxRateRepository::saveAndFlush)
        .log("Saved LIHTC Tax Rates.")
        .map(lihtcEntityTransformer::toTaxRate);
  }

  @Override
  public void saveManualAmortSegments(Set<ManualAmortSegment> manualAmortSegments) {
    Set<ManualAmortSegmentEntity> collect =
        manualAmortSegments.stream()
            .map(ManualAmortSegmentTransformer::toSegmentEntity)
            .collect(Collectors.toSet());

    manualAmortSegmentRepository.saveAll(collect);
  }

  @Override
  public TreeMap<LocalDate, ManualAmortSegment> getSegmentMap(
      Long accountId, Long securityId, int basisId) {
    return getSegments(accountId, securityId, basisId).stream()
        .collect(
            Collectors.toMap(
                ManualAmortSegment::effectiveDate, Function.identity(), (a, b) -> b, TreeMap::new));
  }

  @Override
  public Set<ManualAmortSegment> getSegments(Long accountId, Long securityId, int basisId) {
    return manualAmortSegmentRepository
        .findAllByAccountIdAndSecurityIdAndBasisIdAndIsActiveIsTrue(accountId, securityId, basisId)
        .stream()
        .map(ManualAmortSegmentTransformer::toSegment)
        .collect(Collectors.toSet());
  }
}
