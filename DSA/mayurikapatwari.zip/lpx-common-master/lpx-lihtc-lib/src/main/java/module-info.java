import com.cwan.pbor.lihtc.LIHTCServiceImpl;
import com.cwan.pbor.lihtc.api.LIHTCService;

module pbor.lihtc.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;
  requires spring.boot;

  exports com.cwan.pbor.lihtc.api;
  exports com.cwan.pbor.lihtc;

  provides LIHTCService with
      LIHTCServiceImpl;
}
