import com.cwan.pbor.aum.AumService;
import com.cwan.pbor.aum.api.Aums;

module lpx.aum.lib {
  requires lombok;
  requires jakarta.persistence;
  requires cwan.lpx.domain;
  requires reactor.core;
  requires org.hibernate.orm.core;
  requires spring.context;
  requires spring.web;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.slf4j;

  exports com.cwan.pbor.aum.api;
  exports com.cwan.pbor.aum;

  provides Aums with
      AumService;
}
