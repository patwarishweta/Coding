package com.cwan.pbor.aum;

import com.cwan.lpx.domain.Aum;
import com.cwan.pbor.aum.api.Aums;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AumService implements Aums {

  private AumRepository aumRepository;
  private AumEntityTransformer aumEntityTransformer;
  private AumTransformer aumTransformer;

  public AumService() {}

  @Autowired
  AumService(
      final AumRepository aumRepository,
      AumEntityTransformer aumEntityTransformer,
      AumTransformer aumTransformer) {
    this.aumRepository = aumRepository;
    this.aumEntityTransformer = aumEntityTransformer;
    this.aumTransformer = aumTransformer;
  }

  @Override
  public Set<Aum> addAums(Set<Aum> aums) {
    Set<AumEntity> aumEntities =
        aums.stream().map(aumEntityTransformer).collect(Collectors.toSet());
    return aumRepository.saveAll(aumEntities).stream()
        .map(aumTransformer)
        .collect(Collectors.toSet());
  }

  public Aum saveEntity(AumEntity aums) {
    return aumTransformer.apply(aumRepository.saveAndFlush(aums));
  }

  @Override
  public Set<Aum> updateAll(Set<Aum> aums) {
    Set<AumEntity> aumsToUpdate =
        aums.stream().map(aumEntityTransformer).collect(Collectors.toSet());
    return aumsToUpdate.stream()
        .filter(this::isSavedAum)
        .map(this::saveEntity)
        .collect(Collectors.toSet());
  }

  protected boolean isSavedAum(AumEntity aumEntity) {
    if (aumEntity == null) {
      return false;
    }
    return aumRepository
        .findAllByAccountIdAndSecurityIdAndCalculatedOn(
            aumEntity.getAccountId(), aumEntity.getSecurityId(), aumEntity.getCalculatedOn())
        .isPresent();
  }

  @Override
  public Set<Aum> findByAccountIdAndSecurityIdAndCalculatedOn(
      Long accountId, Long securityId, LocalDate calculatedOn) {
    AumEntity aumEntity =
        aumRepository.findByAccountIdAndSecurityIdAndCalculatedOn(
            accountId, securityId, calculatedOn);
    return Set.of(aumTransformer.apply(aumEntity));
  }

  @Override
  public Set<Aum> deleteAll(Set<Aum> aums) {
    Set<AumEntity> aumsToDelete =
        aums.stream()
            .map(aumEntityTransformer)
            .filter(this::isSavedAum)
            .collect(Collectors.toSet());
    aumRepository.deleteAll(aumsToDelete);
    return aumsToDelete.stream().map(aumTransformer).collect(Collectors.toSet());
  }

  @Override
  public Aum upsertByAccountIdAndSecurityIdAndCalculatedOn(
      Long accountId, Long securityId, LocalDate calculatedOn, Aum aum) {
    AumEntity aumEntitiesToUpsert = aumEntityTransformer.apply(aum);
    Optional<AumEntity> idAndCalculatedOn =
        aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            accountId, securityId, calculatedOn);
    if (idAndCalculatedOn.isPresent()) {
      Long id = idAndCalculatedOn.get().getId();
      aumEntitiesToUpsert = aumEntitiesToUpsert.toBuilder().id(id).build();
    }
    AumEntity aumEntity = aumRepository.saveAndFlush(aumEntitiesToUpsert);
    return aumTransformer.apply(aumEntity);
  }

  @Override
  public List<Aum> findAllByClientIdAndCalculatedOn(Long accountId, LocalDate calculatedOn) {
    return aumRepository
        .findAumEntitiesByUltimateParentIdAndCalculatedOnEquals(accountId, calculatedOn)
        .stream()
        .map(aumTransformer)
        .toList();
  }
}
