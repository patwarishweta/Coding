package com.cwan.pbor.aum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.Hibernate;

@Data
@Builder(toBuilder = true)
@Entity
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name = "lp_aum_detail", catalog = "pabor")
public class AumEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Long accountId;
  private Long securityId;

  private Long ultimateParentId;

  private Long clientId;

  @Column(name = "nav")
  private Double aum;

  private LocalDate calculatedOn;

  private Boolean isActive;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (AumEntity) o;
    return (id != null) && Objects.equals(id, that.id);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
