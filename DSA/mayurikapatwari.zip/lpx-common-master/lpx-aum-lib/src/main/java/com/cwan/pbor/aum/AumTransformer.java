package com.cwan.pbor.aum;

import com.cwan.lpx.domain.Aum;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class AumTransformer implements Function<AumEntity, Aum> {

  @Override
  public Aum apply(AumEntity aumEntity) {
    return Aum.builder()
        .accountId(aumEntity.getAccountId())
        .securityId(aumEntity.getSecurityId())
        .ultimateParentId(aumEntity.getUltimateParentId())
        .clientId(aumEntity.getClientId())
        .aum(aumEntity.getAum())
        .calculatedOn(aumEntity.getCalculatedOn())
        .isActive(aumEntity.getIsActive())
        .id(aumEntity.getId())
        .build();
  }
}
