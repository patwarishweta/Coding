package com.cwan.pbor.aum;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AumRepository extends JpaRepository<AumEntity, Long> {

  Optional<AumEntity> findAllByAccountIdAndSecurityIdAndCalculatedOn(
      Long accountId, Long securityId, LocalDate calculatedOn);

  AumEntity findByAccountIdAndSecurityIdAndCalculatedOn(
      Long accountId, Long securityId, LocalDate calculatedOn);

  List<AumEntity> findAumEntitiesByUltimateParentIdAndCalculatedOnEquals(
      Long ultimateParentId, LocalDate calculatedOn);
}
