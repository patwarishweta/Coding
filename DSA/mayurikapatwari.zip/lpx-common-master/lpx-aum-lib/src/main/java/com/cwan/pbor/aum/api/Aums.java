package com.cwan.pbor.aum.api;

import com.cwan.lpx.domain.Aum;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface Aums {
  Set<Aum> addAums(Set<Aum> aums);

  Set<Aum> findByAccountIdAndSecurityIdAndCalculatedOn(
      Long accountId, Long securityId, LocalDate calculatedOn);

  Set<Aum> updateAll(Set<Aum> aums);

  Set<Aum> deleteAll(Set<Aum> aums);

  Aum upsertByAccountIdAndSecurityIdAndCalculatedOn(
      Long accountId, Long securityId, LocalDate calculatedOn, Aum aum);

  List<Aum> findAllByClientIdAndCalculatedOn(Long accountId, LocalDate calculatedOn);
}
