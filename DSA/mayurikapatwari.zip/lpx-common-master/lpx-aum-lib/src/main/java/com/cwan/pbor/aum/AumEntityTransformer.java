package com.cwan.pbor.aum;

import com.cwan.lpx.domain.Aum;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class AumEntityTransformer implements Function<Aum, AumEntity> {

  @Override
  public AumEntity apply(Aum aum) {
    return AumEntity.builder()
        .accountId(aum.getAccountId())
        .securityId(aum.getSecurityId())
        .ultimateParentId((aum.getUltimateParentId()))
        .clientId(aum.getClientId())
        .aum(aum.getAum())
        .calculatedOn(aum.getCalculatedOn())
        .isActive(aum.getIsActive())
        .id(aum.getId())
        .build();
  }
}
