package com.cwan.pbor.aum;

import com.cwan.lpx.domain.Aum;
import java.time.LocalDate;

class TestUtil {

  public static Aum getAum(Long accountId, Long id) {
    return Aum.builder()
        .id(id)
        .accountId(accountId)
        .securityId(4L)
        .ultimateParentId(5L)
        .clientId(6L)
        .aum(7.0)
        .calculatedOn(LocalDate.of(2022, 1, 1))
        .isActive(true)
        .build();
  }

  public static AumEntity getAumEntity(Long accountId, Long id) {
    return AumEntity.builder()
        .id(id)
        .accountId(accountId)
        .securityId(4L)
        .ultimateParentId(5L)
        .clientId(6L)
        .aum(7.0)
        .calculatedOn(LocalDate.of(2022, 1, 1))
        .isActive(true)
        .build();
  }
}
