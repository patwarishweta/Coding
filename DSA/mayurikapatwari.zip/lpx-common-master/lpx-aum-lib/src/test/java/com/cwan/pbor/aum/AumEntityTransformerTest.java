package com.cwan.pbor.aum;

import static com.cwan.pbor.aum.TestUtil.getAumEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cwan.lpx.domain.Aum;
import org.junit.jupiter.api.Test;

class AumEntityTransformerTest {

  private static final Long ACCOUNT_ID = 9L;
  private static final Long ID = 1L;

  @Test
  void should_convert_aum_to_aum_entity() {
    Aum aum = TestUtil.getAum(ACCOUNT_ID, ID);
    AumEntityTransformer transformer = new AumEntityTransformer();
    AumEntity expected = getAumEntity(ACCOUNT_ID, ID);
    AumEntity actual = transformer.apply(aum);
    assertEquals(expected, actual);
  }
}
