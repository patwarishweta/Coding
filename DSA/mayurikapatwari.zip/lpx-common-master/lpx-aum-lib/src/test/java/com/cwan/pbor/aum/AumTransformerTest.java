package com.cwan.pbor.aum;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AumTransformerTest {
  private static final Long ACCOUNT_ID = 9L;
  private static final Long ID = 1L;

  @Test
  void shoult_convert_aum_entity_to_aum() {
    var aumEntity = TestUtil.getAumEntity(ACCOUNT_ID, ID);
    var transformer = new AumTransformer();
    var expected = TestUtil.getAum(ACCOUNT_ID, ID);
    var actual = transformer.apply(aumEntity);

    assertEquals(expected.getAum(), actual.getAum());
    assertEquals(expected.getSecurityId(), actual.getSecurityId());
    assertEquals(expected.getCalculatedOn(), actual.getCalculatedOn());
    assertEquals(expected.getIsActive(), actual.getIsActive());
    assertEquals(expected.getId(), actual.getId());
    assertEquals(expected.getUltimateParentId(), actual.getUltimateParentId());
    assertEquals(expected.getClientId(), actual.getClientId());
  }
}
