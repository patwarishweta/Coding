package com.cwan.pbor.aum;

import static com.cwan.pbor.aum.TestUtil.getAum;
import static com.cwan.pbor.aum.TestUtil.getAumEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Aum;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class AumServiceTest {

  @Mock private AumRepository aumRepository;
  @Mock private AumEntityTransformer aumEntityTransformer;
  @Mock private AumTransformer aumTransformer;
  @Mock private AumService aumService;
  private static final Long ACCOUNT_ID = 9L;
  private static final Long SECURITY_ID = 4L;
  private static final Long ID = 1L;
  private static final Aum AUM = getAum(ACCOUNT_ID, ID);
  private static final AumEntity AUM_ENTITY = getAumEntity(ACCOUNT_ID, ID);
  private static final Set<Aum> AUMS = Set.of(AUM);
  private static final Set<AumEntity> AUMS_ENTITY_SET = Set.of(AUM_ENTITY);
  private static final List<AumEntity> AUMS_ENTITY_LIST = List.of(AUM_ENTITY);
  private static final LocalDate CALCULATED_ON = LocalDate.of(2022, 1, 1);

  @BeforeEach
  void setup() {
    openMocks(this);
    aumService = new AumService(aumRepository, aumEntityTransformer, aumTransformer);
  }

  @Test
  void should_add_aum_successfully() {
    when(aumRepository.saveAll(AUMS_ENTITY_SET)).thenReturn(AUMS_ENTITY_LIST);
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    var actual = aumService.addAums(AUMS);
    assertEquals(AUMS, actual);
  }

  @Test
  void should_update_aum_successfully() {
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    when(aumService.saveEntity(AUM_ENTITY)).thenReturn(AUM);
    when(aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            eq(ACCOUNT_ID), eq(SECURITY_ID), eq(CALCULATED_ON)))
        .thenReturn(Optional.of(AUM_ENTITY));
    var actual = aumService.updateAll(AUMS);
    assertEquals(AUMS, actual);
  }

  @Test
  void testDeleteAll() {
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    when(aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            eq(ACCOUNT_ID), eq(SECURITY_ID), eq(CALCULATED_ON)))
        .thenReturn(Optional.of(AUM_ENTITY));
    Set<Aum> result = aumService.deleteAll(Set.of(AUM));
    assertEquals(1, result.size());
    assertTrue(result.contains(AUM));
  }

  @Test
  void testFindByAccountIdAndSecurityIdAndCalculatedOn() {
    when(aumRepository.findByAccountIdAndSecurityIdAndCalculatedOn(
            eq(ACCOUNT_ID), eq(SECURITY_ID), any(LocalDate.class)))
        .thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    Set<Aum> result =
        aumService.findByAccountIdAndSecurityIdAndCalculatedOn(
            ACCOUNT_ID, SECURITY_ID, CALCULATED_ON);
    assertEquals(1, result.size());
    assertTrue(result.contains(AUM));
  }

  @Test
  void testNullUpdateAll() {
    var aum = Aum.builder().build();
    var aumEntity = AumEntity.builder().build();
    when(aumEntityTransformer.apply(aum)).thenReturn(aumEntity);
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(aumEntity)).thenReturn(aum);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    when(aumService.saveEntity(aumEntity)).thenReturn(aum);
    when(aumService.saveEntity(AUM_ENTITY)).thenReturn(AUM);
    when(aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            eq(ACCOUNT_ID), eq(SECURITY_ID), eq(CALCULATED_ON)))
        .thenReturn(Optional.of(AUM_ENTITY));
    var received = aumService.updateAll(Set.of(aum, AUM));
    assertEquals(Set.of(AUM), received);
  }

  @Test
  void testNullDeleteAll() {
    var aum = Aum.builder().build();
    var aumEntity = AumEntity.builder().build();
    when(aumEntityTransformer.apply(aum)).thenReturn(aumEntity);
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(aumEntity)).thenReturn(aum);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    when(aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            ACCOUNT_ID, SECURITY_ID, CALCULATED_ON))
        .thenReturn(Optional.of(AUM_ENTITY));
    Set<Aum> result = aumService.deleteAll(Set.of(aum, AUM)); // Deleting a null num and an AUM
    assertEquals(1, result.size());
    assertTrue(result.contains(AUM));
  }

  @Test
  void testUpsertByAccountIdAndSecurityIdAndCalculatedOnWithIdPresent() {
    when(aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            ACCOUNT_ID, SECURITY_ID, CALCULATED_ON))
        .thenReturn(Optional.of(AUM_ENTITY));
    when(aumRepository.saveAndFlush(AUM_ENTITY)).thenReturn(AUM_ENTITY);
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    var actual =
        aumService.upsertByAccountIdAndSecurityIdAndCalculatedOn(
            ACCOUNT_ID, SECURITY_ID, CALCULATED_ON, AUM);
    assertEquals(AUM, actual);
  }

  @Test
  void testUpsertByAccountIdAndSecurityIdAndCalculatedOnWithIdNotPresent() {
    when(aumRepository.findAllByAccountIdAndSecurityIdAndCalculatedOn(
            ACCOUNT_ID, SECURITY_ID, CALCULATED_ON))
        .thenReturn(Optional.empty());
    when(aumRepository.saveAndFlush(AUM_ENTITY)).thenReturn(AUM_ENTITY);
    when(aumEntityTransformer.apply(AUM)).thenReturn(AUM_ENTITY);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    var actual =
        aumService.upsertByAccountIdAndSecurityIdAndCalculatedOn(
            ACCOUNT_ID, SECURITY_ID, CALCULATED_ON, AUM);
    assertEquals(AUM, actual);
  }

  @Test
  void testFindAllByAccountIdAndCalculatedOnBetween() {
    when(aumRepository.findAumEntitiesByUltimateParentIdAndCalculatedOnEquals(
            ACCOUNT_ID, CALCULATED_ON))
        .thenReturn(AUMS_ENTITY_LIST);
    when(aumTransformer.apply(AUM_ENTITY)).thenReturn(AUM);
    var actual = aumService.findAllByClientIdAndCalculatedOn(ACCOUNT_ID, CALCULATED_ON);
    assertEquals(List.of(AUM), actual);
  }
}
