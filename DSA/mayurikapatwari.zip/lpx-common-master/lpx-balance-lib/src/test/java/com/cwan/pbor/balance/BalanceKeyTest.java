package com.cwan.pbor.balance;

import org.hibernate.Hibernate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class BalanceKeyTest {

  @Test
  void testHashCode() {
    var balanceKey1 = BalanceKey.builder().id(1L).version(1).build();
    var balanceKey2 = BalanceKey.builder().id(1L).version(1).build();
    Assertions.assertEquals(balanceKey1.hashCode(), balanceKey2.hashCode());
  }

  @Test
  void testEqualsSameInstance() {
    var balanceKey = BalanceKey.builder().id(1L).version(1).build();
    Assertions.assertEquals(balanceKey, balanceKey);
  }

  @Test
  void testEqualsWithNull() {
    var balanceKey = BalanceKey.builder().id(1L).version(1).build();
    Assertions.assertNotEquals(null, balanceKey);
  }

  @Test
  void testEqualsWithDifferentBalanceKey() {
    var balanceKey1 = BalanceKey.builder().id(1L).version(1).build();
    var balanceKey2 = BalanceKey.builder().id(2L).version(2).build();
    Assertions.assertNotEquals(balanceKey2, balanceKey1);
  }

  @Test
  void testEqualsWithProxiedInstance() {
    var balanceKey = BalanceKey.builder().id(1L).version(1).build();
    var balanceKeyProxied = Hibernate.unproxy(balanceKey);
    Assertions.assertEquals(balanceKey, balanceKeyProxied);
  }

  @Test
  void testEqualsWithDifferentVersion() {
    var balanceKey1 = BalanceKey.builder().id(1L).version(1).build();
    var balanceKey2 = BalanceKey.builder().id(1L).version(2).build();
    Assertions.assertNotEquals(balanceKey1, balanceKey2);
  }

  @Test
  void testEqualsWithDifferentId() {
    var balanceKey1 = BalanceKey.builder().id(1L).version(1).build();
    var balanceKey2 = BalanceKey.builder().id(2L).version(1).build();
    Assertions.assertNotEquals(balanceKey1, balanceKey2);
  }

  @Test
  void testEqualsWithSameVersionAndId() {
    var balanceKey1 = BalanceKey.builder().id(1L).version(1).build();
    var balanceKey2 = BalanceKey.builder().id(1L).version(1).build();
    Assertions.assertEquals(balanceKey1, balanceKey2);
  }
}
