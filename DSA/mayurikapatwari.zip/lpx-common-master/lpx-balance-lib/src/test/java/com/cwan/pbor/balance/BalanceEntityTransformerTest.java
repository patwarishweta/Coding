package com.cwan.pbor.balance;

import static com.cwan.pbor.balance.TestUtil.getBalanceEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BalanceEntityTransformerTest {

  private static final Long ACCOUNT_ID = 9L;

  @Test
  void should_convert_balance_to_balance_entity() {
    var balance = TestUtil.getBalance(ACCOUNT_ID, 1L);
    var transformer = new BalanceEntityTransformer();
    var expected = getBalanceEntity(ACCOUNT_ID, 1L);
    var actual = transformer.apply(balance);
    assertEquals(expected, actual);
  }
}
