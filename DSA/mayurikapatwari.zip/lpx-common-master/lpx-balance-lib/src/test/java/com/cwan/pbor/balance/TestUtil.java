package com.cwan.pbor.balance;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;

public class TestUtil {

  public static Balance getBalance(Long accountId) {
    return getBalance(accountId, null);
  }

  public static BalanceEntity getBalanceEntity(Long accountId) {
    return getBalanceEntity(accountId, null);
  }

  public static Balance getBalance(Long accountId, Long id) {
    return Balance.builder()
        .id(id)
        .account(Account.builder().id(accountId).build())
        .security(Security.builder().securityId(4L).build())
        .document(Document.builder().id(5L).fileName("Document name").build())
        .source("source")
        .entryDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .balanceDate(LocalDate.of(2022, 1, 1))
        .knowledgeStartDate(LocalDateTime.of(2022, Month.JULY, 1, 1, 1, 48))
        .knowledgeEndDate(LocalDateTime.of(2022, Month.JULY, 2, 2, 2, 48))
        .type("TOTAL_COMMITMENT")
        .currency("USD")
        .fxCurrency("INR")
        .amount(1.0)
        .isCurrent(true)
        .version(1)
        .amountMTD(2.0)
        .amountQTD(3.0)
        .amountYTD(4.0)
        .amountITD(5.0)
        .action("create")
        .createdBy("pbor-balance-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("pbor-balance-lib")
        .isModifiedByInternalUser(true)
        .build();
  }

  public static BalanceEntity getBalanceEntity(Long accountId, Long id) {
    return BalanceEntity.builder()
        .id(id)
        .accountId(accountId)
        .version(1)
        .securityId(4L)
        .documentId(5L)
        .documentName("Document name")
        .source("source")
        .entryDate(
            LocalDate.of(Integer.parseInt("2022"), Integer.parseInt("1"), Integer.parseInt("1")))
        .balanceDate(LocalDate.of(2022, 1, 1))
        .knowledgeStartDate(LocalDateTime.of(2022, Month.JULY, 1, 1, 1, 48))
        .knowledgeEndDate(LocalDateTime.of(2022, Month.JULY, 2, 2, 2, 48))
        .type("TOTAL_COMMITMENT")
        .currency("USD")
        .fxCurrency("INR")
        .amount(1.0)
        .isCurrent(true)
        .amountMTD(2.0)
        .amountQTD(3.0)
        .amountYTD(4.0)
        .amountITD(5.0)
        .action("create")
        .createdBy("pbor-balance-lib")
        .isCreatedByInternalUser(true)
        .modifiedBy("pbor-balance-lib")
        .isModifiedByInternalUser(true)
        .build();
  }
}
