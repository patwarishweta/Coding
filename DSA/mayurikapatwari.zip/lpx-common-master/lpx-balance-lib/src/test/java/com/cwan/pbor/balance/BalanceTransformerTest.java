package com.cwan.pbor.balance;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class BalanceTransformerTest {

  private static final Long ACCOUNT_ID = 9L;

  @Test
  void shoult_convert_balance_entity_to_balance() {
    var balanceEntity = TestUtil.getBalanceEntity(ACCOUNT_ID);
    var transformer = new BalanceTransformer();
    var expected = TestUtil.getBalance(ACCOUNT_ID);
    var actual = transformer.apply(balanceEntity);
    assertEquals(expected, actual);
  }
}
