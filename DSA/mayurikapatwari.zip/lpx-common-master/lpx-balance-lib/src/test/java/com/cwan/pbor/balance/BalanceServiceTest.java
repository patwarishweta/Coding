package com.cwan.pbor.balance;

import static com.cwan.pbor.balance.Constants.CANCEL;
import static com.cwan.pbor.balance.Constants.IS_CURRENT;
import static com.cwan.pbor.balance.TestUtil.getBalance;
import static com.cwan.pbor.balance.TestUtil.getBalanceEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Balance;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class BalanceServiceTest {

  @Mock private BalanceRepository balanceRepository;
  @Mock private BalanceEntityTransformer balanceEntityTransformer;
  @Mock private BalanceTransformer balanceTransformer;
  private BalanceService balanceService;
  private static final Long ACCOUNT_ID = 9L;
  private static final Long BALANCE_ID = 1L;
  private static final Set<Long> BALANCE_IDS = Set.of(BALANCE_ID);
  private static final Balance BALANCE = getBalance(ACCOUNT_ID);
  private static final List<Balance> BALANCES = List.of(BALANCE);
  private static final BalanceEntity BALANCE_ENTITY = getBalanceEntity(ACCOUNT_ID);
  private static final List<BalanceEntity> BALANCE_ENTITIES = List.of(BALANCE_ENTITY);

  @BeforeEach
  void before_each() {
    openMocks(this);
    when(balanceTransformer.apply(eq(BALANCE_ENTITY))).thenReturn(BALANCE);
    when(balanceEntityTransformer.apply(eq(BALANCE))).thenReturn(BALANCE_ENTITY);
    balanceService =
        new BalanceService(balanceRepository, balanceEntityTransformer, balanceTransformer);
  }

  @Test
  void should_add_balance_successfully() {
    var balanceEntity = getBalanceEntity(ACCOUNT_ID);
    balanceEntity.setId(BALANCE_ID);
    var updatedBalance = getBalance(ACCOUNT_ID);
    updatedBalance.setId(BALANCE_ID);
    when(balanceRepository.saveAndFlush(eq(BALANCE_ENTITY))).thenReturn(balanceEntity);
    when(balanceEntityTransformer.apply(eq(updatedBalance))).thenReturn(balanceEntity);
    when(balanceTransformer.apply(eq(balanceEntity))).thenReturn(updatedBalance);
    when(balanceRepository.insertBalance(
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(),
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(),
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
        .thenReturn(1);
    when(balanceRepository.findByIdAndIsCurrentTrue(any())).thenReturn(balanceEntity);
    var expected = List.of(updatedBalance);
    var actual = balanceService.addBalance(Set.of(BALANCE)).collectList().block();
    assertEquals(expected, actual);
  }

  @Test
  void should_throw_Error_in_fetching_balances() {
    when(balanceRepository.findAllByIdInAndIsCurrentTrue(eq(BALANCE_IDS)))
        .thenReturn(Collections.emptyList());
    StepVerifier.create(balanceService.getBalancesByIds(BALANCE_IDS))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof BalanceException)
                    && Objects.requireNonNull(throwable.getMessage())
                        .contains(String.format("Error while fetching Balances: %s", BALANCE_IDS)))
        .verify();
  }

  @Test
  void should_successfully_get_balanceVO_by_balance_ids() {
    when(balanceRepository.findAllByIdInAndIsCurrentTrue(eq(BALANCE_IDS)))
        .thenReturn(BALANCE_ENTITIES);
    var actual = balanceService.getBalancesByIds(BALANCE_IDS).collectList().block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void should_delete_balance_using_balanceId() {
    when(balanceRepository.findAllByIdInAndIsCurrentTrue(eq(BALANCE_IDS)))
        .thenReturn(BALANCE_ENTITIES);
    when(balanceRepository.saveAndFlush(eq(BALANCE_ENTITY))).thenReturn(BALANCE_ENTITY);
    var actual = balanceService.deleteBalanceById(BALANCE_IDS).collectList().block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void should_throw_BalanceException_while_executing_deleteBalanceById() {
    when(balanceRepository.findAllByIdInAndIsCurrentTrue(eq(BALANCE_IDS)))
        .thenReturn(Collections.emptyList());
    StepVerifier.create(balanceService.deleteBalanceById(BALANCE_IDS))
        .expectErrorMatches(
            throwable ->
                (throwable instanceof BalanceException)
                    && Objects.requireNonNull(throwable.getMessage())
                        .contains(String.format("Error while deleting Balance: %s", BALANCE_IDS)))
        .verify();
  }

  @Test
  void should_update_Balance_with_updated_balanceVO_passed_in_updateBalanceInfo() {
    var balanceEntity = getBalanceEntity(ACCOUNT_ID);
    balanceEntity.setId(BALANCE_ID);
    var updatedBalance = getBalance(ACCOUNT_ID);
    updatedBalance.setId(BALANCE_ID);
    when(balanceRepository.saveAndFlush(eq(balanceEntity))).thenReturn(balanceEntity);
    when(balanceRepository.findAllByIdInAndIsCurrentTrue(BALANCE_IDS))
        .thenReturn(List.of(balanceEntity));
    when(balanceEntityTransformer.apply(eq(updatedBalance))).thenReturn(balanceEntity);
    when(balanceTransformer.apply(eq(balanceEntity))).thenReturn(updatedBalance);
    var expected = List.of(updatedBalance);
    var actual = balanceService.updateBalanceInfo(Set.of(updatedBalance)).collectList().block();
    assertEquals(expected, actual);
  }

  @Test
  void should_successfully_get_balanceVO_by_account_and_date() {
    var accountIds = Set.of(1L, 2L);
    var asOfDate = LocalDate.of(2022, 1, 1);
    when(balanceRepository.findAllByAccountIdInAndBalanceDateIsBeforeAndIsCurrentTrue(
            accountIds, asOfDate))
        .thenReturn(BALANCE_ENTITIES);
    var actual =
        balanceService.getBalancesByAccountAndDate(accountIds, asOfDate).collectList().block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void get_balances_by_account_inclusive() {
    var accountIds = Set.of(1L, 2L);
    var asOfDate = LocalDate.of(2022, 1, 1);
    when(balanceRepository.findAllByAccountIdInAndBalanceDateIsAndIsCurrentTrue(
            accountIds, asOfDate))
        .thenReturn(BALANCE_ENTITIES);
    var actual = balanceService.getBalancesByAccountAndDateInclusive(accountIds, asOfDate);
    assertEquals(BALANCES.get(0), actual.stream().findAny().get());
  }

  @Test
  void should_successfully_get_balanceVO_by_documentId() {
    var documentIds = Set.of(1L, 2L);
    when(balanceRepository.findAllByDocumentIdInAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
            eq(documentIds), any(LocalDateTime.class)))
        .thenReturn(BALANCE_ENTITIES);
    var actual = balanceService.getBalancesByDocumentIds(documentIds).collectList().block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void should_succesfully_getBalance_based_on_acc_id_secid_and_type() {
    var accountId = 1L;
    var securityId = 4L;
    when(balanceRepository.findByAccountIdAndSecurityIdAndTypeAndIsCurrentTrue(
            eq(accountId), eq(securityId), anyString()))
        .thenReturn(BALANCE_ENTITIES);
    var actual =
        balanceService
            .getBalanceByAccountAndSecurityIdAndType(accountId, securityId, "TOTAL_COMMITMENT")
            .collectList()
            .block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void should_get_balances_by_account_entry_date_knowledge_date() {
    var entryDate = LocalDate.of(2022, 9, 1);
    var knowledgeDate = entryDate.atStartOfDay();
    when(balanceRepository
            .findAllByAccountIdAndBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                eq(ACCOUNT_ID), eq(entryDate), eq(knowledgeDate), any(LocalDateTime.class)))
        .thenReturn(BALANCE_ENTITIES);
    var actual =
        balanceService
            .getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
                ACCOUNT_ID, entryDate, knowledgeDate)
            .collectList()
            .block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void getBalancesOnBalanceDateForAccounts_test() {
    var entryDate = LocalDate.of(2022, 9, 1);
    var knowledgeDate = entryDate.atStartOfDay();
    when(balanceRepository
            .findAllByAccountIdInAndBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                eq(Set.of(ACCOUNT_ID)), eq(entryDate), eq(knowledgeDate), any(LocalDateTime.class)))
        .thenReturn(BALANCE_ENTITIES);
    var actual =
        balanceService
            .getBalancesOnBalanceDateForAccounts(Set.of(ACCOUNT_ID), entryDate, knowledgeDate)
            .collectList()
            .block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void getBalancesOnBalanceDate_test() {
    var entryDate = LocalDate.of(2022, 9, 1);
    var knowledgeDate = entryDate.atStartOfDay();
    when(balanceRepository
            .findAllByBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                eq(entryDate), eq(knowledgeDate), any(LocalDateTime.class)))
        .thenReturn(BALANCE_ENTITIES);
    var actual =
        balanceService.getBalancesOnBalanceDate(entryDate, knowledgeDate).collectList().block();
    assertEquals(BALANCES, actual);
  }

  @Test
  void getBalancesByDocumentId_shouldReturnBalances() {
    Long documentId = 1L;
    List<BalanceEntity> balances =
        Arrays.asList(BalanceEntity.builder().build(), BalanceEntity.builder().build());
    when(balanceRepository.findAllByDocumentIdAndIsCurrentAndActionNot(
            eq(documentId), eq(IS_CURRENT), eq(CANCEL)))
        .thenReturn(balances);
    when(balanceTransformer.apply(any(BalanceEntity.class))).thenReturn(new Balance());
    Flux<Balance> result = balanceService.getBalancesByDocumentId(documentId);
    StepVerifier.create(result).expectNextCount(2).verifyComplete();
  }
}
