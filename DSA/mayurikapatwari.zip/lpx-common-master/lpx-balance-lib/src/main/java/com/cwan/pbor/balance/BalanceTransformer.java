package com.cwan.pbor.balance;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Balance;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.Security;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BalanceTransformer implements Function<BalanceEntity, Balance> {

  @Override
  public Balance apply(BalanceEntity balanceEntity) {
    return Balance.builder()
        .account(Account.builder().id(balanceEntity.getAccountId()).build())
        .version(balanceEntity.getVersion())
        .security(Security.builder().securityId(balanceEntity.getSecurityId()).build())
        .document(getDocument(balanceEntity))
        .source(balanceEntity.getSource())
        .dataSource(balanceEntity.getDataSource())
        .entryDate(balanceEntity.getEntryDate())
        .balanceDate(balanceEntity.getBalanceDate())
        .currency(balanceEntity.getCurrency())
        .fxCurrency(balanceEntity.getFxCurrency())
        .fxRate(balanceEntity.getFxRate())
        .type(balanceEntity.getType())
        .amount(balanceEntity.getAmount())
        .isCurrent(balanceEntity.getIsCurrent())
        .amountITD(balanceEntity.getAmountITD())
        .amountMTD(balanceEntity.getAmountMTD())
        .amountQTD(balanceEntity.getAmountQTD())
        .amountYTD(balanceEntity.getAmountYTD())
        .unitsITD(balanceEntity.getUnitsITD())
        .unitsMTD(balanceEntity.getUnitsMTD())
        .unitsQTD(balanceEntity.getUnitsQTD())
        .unitsYTD(balanceEntity.getUnitsYTD())
        .units(balanceEntity.getUnits())
        .action(balanceEntity.getAction())
        .relatesTo(balanceEntity.getRelatesTo())
        .knowledgeStartDate(balanceEntity.getKnowledgeStartDate())
        .knowledgeEndDate(balanceEntity.getKnowledgeEndDate())
        .isCreatedByInternalUser(balanceEntity.getIsCreatedByInternalUser())
        .isModifiedByInternalUser(balanceEntity.getIsModifiedByInternalUser())
        .createdOn(balanceEntity.getCreatedOn())
        .modifiedOn(balanceEntity.getModifiedOn())
        .createdBy(balanceEntity.getCreatedBy())
        .modifiedBy(balanceEntity.getModifiedBy())
        .id(balanceEntity.getId())
        .build();
  }

  private Document getDocument(BalanceEntity entity) {
    return Document.builder().id(entity.getDocumentId()).fileName(entity.getDocumentName()).build();
  }
}
