package com.cwan.pbor.balance;

public class Constants {

  private Constants() {}

  public static final boolean IS_CURRENT = true;
  public static final String CANCEL = "Cancel";
}
