package com.cwan.pbor.balance;

import static com.cwan.pbor.balance.Constants.CANCEL;
import static com.cwan.pbor.balance.Constants.IS_CURRENT;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Collectors.toSet;

import com.cwan.lpx.domain.Balance;
import com.cwan.pbor.balance.api.Balances;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Service
@Slf4j
public class BalanceService implements Balances {

  private BalanceRepository balanceRepository;
  private BalanceEntityTransformer balanceEntityTransformer;
  private BalanceTransformer balanceTransformer;

  public BalanceService() {}

  @Autowired
  BalanceService(
      final BalanceRepository balanceRepository,
      final BalanceEntityTransformer balanceEntityTransformer,
      final BalanceTransformer balanceTransformer) {
    this.balanceRepository = balanceRepository;
    this.balanceEntityTransformer = balanceEntityTransformer;
    this.balanceTransformer = balanceTransformer;
  }

  @Override
  public Flux<Balance> addBalance(final Set<Balance> balances) {
    return Flux.fromIterable(balances)
        .flatMap(
            balance ->
                Mono.fromCallable(
                        () ->
                            balanceRepository.findByIdAndVersion(
                                balance.getId(), balance.getVersion()))
                    .subscribeOn(Schedulers.boundedElastic())
                    .flatMap(
                        optionalBalance -> {
                          if (optionalBalance.isPresent()) {
                            log.info(
                                "Balances with Id {} version {} can't be added.",
                                balance.getId(),
                                balance.getVersion());
                            return Mono.empty();
                          }
                          return Mono.just(balanceEntityTransformer.apply(balance));
                        }))
        .collectList()
        .flatMapMany(
            newBalances -> {
              if (newBalances.isEmpty()) {
                return Mono.error(
                    new BalanceException(
                        "Balance Id for given values already exists. Please try updating existing Balances if required"));
              }
              return createBalances(Flux.fromIterable(newBalances))
                  .onErrorMap(
                      e ->
                          new BalanceException(
                              "Error saving Balances:"
                                  + balances.stream().map(Balance::getId).collect(toSet()),
                              e));
            });
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesByIds(final Set<Long> balanceIds) {
    return Mono.fromCallable(() -> balanceRepository.findAllByIdInAndIsCurrentTrue(balanceIds))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .switchIfEmpty(
            Flux.error(
                new BalanceException(String.format("No balances found for ids: %s", balanceIds))))
        .mapNotNull(balanceTransformer)
        .onErrorResume(
            BalanceException.class,
            e ->
                Mono.error(
                    new BalanceException(
                        String.format("Error while fetching Balances: %s", balanceIds), e)));
  }

  @Override
  @Transactional
  public Flux<Balance> deleteBalanceById(final Set<Long> balanceIds) {
    return findAllByIds(balanceIds)
        .mapNotNull(
            balance -> {
              balance.setIsCurrent(false);
              balance.setKnowledgeEndDate(LocalDateTime.now());
              return balance;
            })
        .switchIfEmpty(
            Flux.error(
                new BalanceException(String.format("No balances found for ids: %s", balanceIds))))
        .flatMap(this::saveBalance)
        .mapNotNull(balanceTransformer)
        .onErrorResume(
            BalanceException.class,
            e ->
                Mono.error(
                    new BalanceException(
                        String.format("Error while deleting Balance: %s", balanceIds), e)));
  }

  @Override
  @Transactional
  public Flux<Balance> updateBalanceInfo(final Set<Balance> balances) {
    var idToBalanceMap = balances.stream().collect(toMap(Balance::getId, balanceEntityTransformer));
    var requestedBalanceIds = new HashSet<>(idToBalanceMap.keySet());
    return findAllByIds(requestedBalanceIds)
        .filter(balance -> requestedBalanceIds.remove(balance.getId()))
        .mapNotNull(balance -> idToBalanceMap.get(balance.getId()))
        .flatMap(this::saveBalance)
        .mapNotNull(balanceTransformer)
        .doOnComplete(
            () ->
                requestedBalanceIds.forEach(
                    balanceId ->
                        log.info(
                            "Could not update balance id: {} because it does not exist.",
                            balanceId)));
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesByAccountAndDate(final Set<Long> accountIds, LocalDate asOfDate) {
    return Mono.fromCallable(
            () ->
                balanceRepository.findAllByAccountIdInAndBalanceDateIsBeforeAndIsCurrentTrue(
                    accountIds, asOfDate))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  @Override
  @Transactional
  public Set<Balance> getBalancesByAccountAndDateInclusive(
      final Set<Long> accountIds, LocalDate asOfDate) {
    return balanceRepository
        .findAllByAccountIdInAndBalanceDateIsAndIsCurrentTrue(accountIds, asOfDate)
        .stream()
        .map(balanceTransformer)
        .collect(toSet());
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesByDocumentIds(final Set<Long> documentIds) {
    return Mono.fromCallable(
            () ->
                balanceRepository.findAllByDocumentIdInAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                    documentIds, LocalDateTime.now()))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  @Override
  @Transactional
  public Flux<Balance> getBalanceByAccountAndSecurityIdAndType(
      Long accountId, Long securityId, String type) {
    return Mono.fromCallable(
            () ->
                balanceRepository.findByAccountIdAndSecurityIdAndTypeAndIsCurrentTrue(
                    accountId, securityId, type))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
      Long accountId, LocalDate balanceDate, LocalDateTime knowledgeStartDate) {
    return Mono.fromCallable(
            () ->
                balanceRepository
                    .findAllByAccountIdAndBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                        accountId, balanceDate, knowledgeStartDate, LocalDateTime.now()))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesOnBalanceDateForAccounts(
      Set<Long> accountIds, LocalDate balanceDate, LocalDateTime knowledgeStartDate) {
    return Mono.fromCallable(
            () ->
                balanceRepository
                    .findAllByAccountIdInAndBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                        accountIds, balanceDate, knowledgeStartDate, LocalDateTime.now()))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesOnBalanceDate(
      LocalDate balanceDate, LocalDateTime knowledgeStartDate) {
    return Mono.fromCallable(
            () ->
                balanceRepository
                    .findAllByBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
                        balanceDate, knowledgeStartDate, LocalDateTime.now()))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  @Override
  @Transactional
  public Flux<Balance>
      getBalancesByKnowledgeStartDateGreaterThanEqualAndKnowledgeStartDateLessThanAndKnowledgeEndDateAfter(
          LocalDateTime knowledgeStartDateGreaterThan,
          LocalDateTime knowledgeStartDateLessThan,
          LocalDateTime knowledgeEndDateGreaterThan) {
    return Mono.fromCallable(
            () ->
                balanceRepository
                    .findAllByKnowledgeStartDateGreaterThanEqualAndKnowledgeStartDateLessThanAndKnowledgeEndDateAfterAndIsCurrentTrue(
                        knowledgeStartDateGreaterThan,
                        knowledgeStartDateLessThan,
                        knowledgeEndDateGreaterThan))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }

  private Mono<BalanceEntity> saveBalance(BalanceEntity bal) {
    return Mono.fromCallable(() -> balanceRepository.saveAndFlush(bal))
        .subscribeOn(Schedulers.boundedElastic());
  }

  private Flux<BalanceEntity> findAllByIds(Set<Long> balanceIds) {
    return Mono.fromCallable(() -> balanceRepository.findAllByIdInAndIsCurrentTrue(balanceIds))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable);
  }

  private Flux<Balance> createBalances(Flux<BalanceEntity> balanceEntityFlux) {
    AtomicReference<Long> id = new AtomicReference<>();
    return balanceEntityFlux
        .log("Create Balance")
        .flatMapSequential(
            balance -> {
              id.set(balance.getId());
              log.info(
                  "Create Balance {}_{} for accountId: {} securityId {}",
                  balance.getId(),
                  balance.getVersion(),
                  balance.getAccountId(),
                  balance.getSecurityId());
              balanceRepository.insertBalance(
                  balance.getId(),
                  balance.getVersion(),
                  balance.getAccountId(),
                  balance.getSecurityId(),
                  balance.getDocumentId(),
                  balance.getSource(),
                  balance.getDataSource(),
                  balance.getEntryDate(),
                  balance.getBalanceDate(),
                  balance.getKnowledgeStartDate(),
                  balance.getKnowledgeEndDate(),
                  balance.getIsCurrent(),
                  balance.getType(),
                  balance.getCurrency(),
                  balance.getFxCurrency(),
                  balance.getFxRate(),
                  balance.getAmount(),
                  balance.getAmountMTD(),
                  balance.getAmountQTD(),
                  balance.getAmountYTD(),
                  balance.getAmountITD(),
                  balance.getUnitsMTD(),
                  balance.getUnitsQTD(),
                  balance.getUnitsYTD(),
                  balance.getUnitsITD(),
                  balance.getUnits(),
                  balance.getAction(),
                  balance.getRelatesTo(),
                  balance.getCreatedBy(),
                  balance.getIsCreatedByInternalUser(),
                  (Objects.nonNull(balance.getCreatedOn())) && (balance.getVersion() == 1)
                      ? balance.getCreatedOn()
                      : LocalDateTime.now(ZoneOffset.UTC),
                  balance.getModifiedBy(),
                  balance.getIsModifiedByInternalUser(),
                  Objects.nonNull(balance.getModifiedOn())
                      ? balance.getModifiedOn()
                      : LocalDateTime.now(ZoneOffset.UTC),
                  balance.getDocumentName());
              Long balanceId = Objects.isNull(id.get()) ? balanceRepository.getId() : id.get();
              BalanceEntity retrievedBalanceEntity =
                  balanceRepository.findByIdAndIsCurrentTrue(balanceId);
              return Mono.just(balanceTransformer.apply(retrievedBalanceEntity));
            });
  }

  @Override
  @Transactional
  public Flux<Balance> getBalancesByDocumentId(Long documentId) {
    return Mono.fromCallable(
            () ->
                balanceRepository.findAllByDocumentIdAndIsCurrentAndActionNot(
                    documentId, IS_CURRENT, CANCEL))
        .subscribeOn(Schedulers.boundedElastic())
        .flatMapMany(Flux::fromIterable)
        .mapNotNull(balanceTransformer);
  }
}
