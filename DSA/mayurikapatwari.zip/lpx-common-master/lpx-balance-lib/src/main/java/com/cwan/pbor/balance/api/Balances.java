package com.cwan.pbor.balance.api;

import com.cwan.lpx.domain.Balance;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface Balances {

  Flux<Balance> addBalance(Set<Balance> balances);

  Flux<Balance> getBalancesByIds(Set<Long> balanceIds);

  Flux<Balance> deleteBalanceById(Set<Long> balanceIds);

  Flux<Balance> updateBalanceInfo(Set<Balance> balances);

  Flux<Balance> getBalancesByAccountAndDate(Set<Long> accountIds, LocalDate asOfDate);

  Set<Balance> getBalancesByAccountAndDateInclusive(Set<Long> accountIds, LocalDate asOfDate);

  Flux<Balance> getBalancesByDocumentIds(Set<Long> documentIds);

  Flux<Balance> getBalanceByAccountAndSecurityIdAndType(
      Long accountId, Long securityId, String type);

  Flux<Balance> getBalancesByAccountAndBalanceDateAndKnowledgeStartDate(
      Long accountId, LocalDate balanceDate, LocalDateTime knowledgeStartDate);

  Flux<Balance> getBalancesOnBalanceDateForAccounts(
      Set<Long> accountIds, LocalDate balanceDate, LocalDateTime knowledgeStartDate);

  Flux<Balance> getBalancesOnBalanceDate(LocalDate balanceDate, LocalDateTime knowledgeStartDate);

  Flux<Balance>
      getBalancesByKnowledgeStartDateGreaterThanEqualAndKnowledgeStartDateLessThanAndKnowledgeEndDateAfter(
          LocalDateTime knowledgeStartDateGreaterThan,
          LocalDateTime knowledgeStartDateLessThan,
          LocalDateTime knowledgeEndDateGreaterThan);

  Flux<Balance> getBalancesByDocumentId(Long documentId);
}
