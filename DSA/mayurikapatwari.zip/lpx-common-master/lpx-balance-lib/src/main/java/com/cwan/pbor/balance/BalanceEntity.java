package com.cwan.pbor.balance;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
@IdClass(BalanceKey.class)
@Table(name = "Balance", catalog = "pabor")
public class BalanceEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Id private Integer version;
  private Long accountId;
  private Long securityId;
  private Long documentId;
  private String documentName;
  private String source;
  private String dataSource;
  private LocalDate entryDate;
  private LocalDate balanceDate;
  private LocalDateTime knowledgeStartDate;
  private LocalDateTime knowledgeEndDate;
  private String type;
  private String currency;
  private String fxCurrency;
  private Double fxRate;
  private Double amount;
  private Boolean isCurrent;

  @Column(name = "amount_mtd")
  private Double amountMTD;

  @Column(name = "amount_qtd")
  private Double amountQTD;

  @Column(name = "amount_ytd")
  private Double amountYTD;

  @Column(name = "amount_itd")
  private Double amountITD;

  @Column(name = "units_mtd")
  private Double unitsMTD;

  @Column(name = "units_qtd")
  private Double unitsQTD;

  @Column(name = "units_ytd")
  private Double unitsYTD;

  @Column(name = "units_itd")
  private Double unitsITD;

  private Double units;
  private String action;
  private String relatesTo;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  private LocalDateTime createdOn;
  private String modifiedBy;
  private Boolean isModifiedByInternalUser;
  private LocalDateTime modifiedOn;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if ((o == null) || (Hibernate.getClass(this) != Hibernate.getClass(o))) {
      return false;
    }
    var that = (BalanceEntity) o;
    return (id != null) && Objects.equals(id, that.id);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
