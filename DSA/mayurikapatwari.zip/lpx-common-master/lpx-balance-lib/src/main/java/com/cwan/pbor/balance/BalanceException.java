package com.cwan.pbor.balance;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class BalanceException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = 8902166125971596523L;

  public BalanceException(String msg, Throwable e) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, msg, e);
  }

  public BalanceException(String msg) {
    super(HttpStatus.BAD_REQUEST, msg);
  }
}
