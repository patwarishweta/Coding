package com.cwan.pbor.balance;

import com.cwan.lpx.domain.Balance;
import java.util.Objects;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class BalanceEntityTransformer implements Function<Balance, BalanceEntity> {

  @Override
  public BalanceEntity apply(Balance balance) {
    return BalanceEntity.builder()
        .accountId(balance.getAccount().getId())
        .version(balance.getVersion())
        .securityId(
            Objects.nonNull(balance.getSecurity()) ? balance.getSecurity().getSecurityId() : null)
        .documentId(Objects.nonNull(balance.getDocument()) ? balance.getDocument().getId() : null)
        .documentName(
            Objects.nonNull(balance.getDocument()) ? balance.getDocument().getFileName() : null)
        .source(balance.getSource())
        .dataSource(balance.getDataSource())
        .entryDate(balance.getEntryDate())
        .balanceDate(balance.getBalanceDate())
        .currency(balance.getCurrency())
        .fxCurrency(balance.getFxCurrency())
        .fxRate(balance.getFxRate())
        .type(balance.getType())
        .amount(balance.getAmount())
        .isCurrent(balance.getIsCurrent())
        .amountITD(balance.getAmountITD())
        .amountMTD(balance.getAmountMTD())
        .amountQTD(balance.getAmountQTD())
        .amountYTD(balance.getAmountYTD())
        .unitsITD(balance.getUnitsITD())
        .unitsMTD(balance.getUnitsMTD())
        .unitsQTD(balance.getUnitsQTD())
        .unitsYTD(balance.getUnitsYTD())
        .units(balance.getUnits())
        .action(balance.getAction())
        .knowledgeStartDate(balance.getKnowledgeStartDate())
        .knowledgeEndDate(balance.getKnowledgeEndDate())
        .relatesTo(balance.getRelatesTo())
        .isCreatedByInternalUser(balance.getIsCreatedByInternalUser())
        .isModifiedByInternalUser(balance.getIsModifiedByInternalUser())
        .createdBy(balance.getCreatedBy())
        .modifiedBy(balance.getModifiedBy())
        .createdOn(balance.getCreatedOn())
        .modifiedOn(balance.getModifiedOn())
        .id(balance.getId())
        .build();
  }
}
