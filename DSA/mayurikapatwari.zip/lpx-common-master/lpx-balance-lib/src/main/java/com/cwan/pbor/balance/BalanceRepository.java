package com.cwan.pbor.balance;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface BalanceRepository extends JpaRepository<BalanceEntity, BalanceKey> {

  Optional<BalanceEntity> findByIdAndVersion(Long id, Integer version);

  Collection<BalanceEntity> findAllByIdInAndIsCurrentTrue(Set<Long> balanceIds);

  Collection<BalanceEntity> findAllByAccountIdInAndBalanceDateIsBeforeAndIsCurrentTrue(
      Collection<Long> accountIds, LocalDate asOfDate);

  Collection<BalanceEntity> findAllByAccountIdInAndBalanceDateIsAndIsCurrentTrue(
      Collection<Long> accountIds, LocalDate asOfDate);

  Collection<BalanceEntity> findAllByDocumentIdInAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
      Collection<Long> documentIds, LocalDateTime asOfDate);

  Collection<BalanceEntity> findByAccountIdAndSecurityIdAndTypeAndIsCurrentTrue(
      Long accountId, Long securityId, String type);

  Collection<BalanceEntity>
      findAllByAccountIdAndBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
          Long accountId,
          LocalDate entryDate,
          LocalDateTime knowledgeStartDate,
          LocalDateTime knowledgeEndDate);

  Collection<BalanceEntity>
      findAllByAccountIdInAndBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
          Set<Long> accountId,
          LocalDate entryDate,
          LocalDateTime knowledgeStartDate,
          LocalDateTime knowledgeEndDate);

  Collection<BalanceEntity>
      findAllByBalanceDateAndKnowledgeStartDateIsBeforeAndKnowledgeEndDateIsAfterAndIsCurrentTrue(
          LocalDate entryDate, LocalDateTime knowledgeStartDate, LocalDateTime knowledgeEndDate);

  Collection<BalanceEntity>
      findAllByKnowledgeStartDateGreaterThanEqualAndKnowledgeStartDateLessThanAndKnowledgeEndDateAfterAndIsCurrentTrue(
          LocalDateTime knowledgeStartDateGreaterThan,
          LocalDateTime knowledgeStartDateLessThan,
          LocalDateTime endDate);

  @Transactional
  void deleteByDocumentId(Long documentId);

  Optional<BalanceEntity> getByDocumentId(Long documentId);

  BalanceEntity findByIdAndIsCurrentTrue(Long id);

  @Modifying
  @Query(
      value =
          "insert into pabor.balance (id, version, account_id, security_id, document_id, source,"
              + "data_source, entry_date, balance_date, knowledge_start_date, knowledge_end_date,"
              + "is_current, type, currency, fx_currency, fx_rate, amount, amount_mtd,"
              + "amount_qtd, amount_ytd, amount_itd, "
              + "units_mtd, units_qtd, units_ytd, units_itd, units, "
              + "action, relates_to, created_by, is_created_by_internal_user, "
              + "created_on, modified_by, is_modified_by_internal_user, modified_on, document_name ) "
              + "select :id, :version, :accountId, :securityId, :documentId, "
              + ":source, :dataSource, :entryDate, :balanceDate, :knowledgeStartDate, :knowledgeEndDate, "
              + ":isCurrent, :type, :currency, :fxCurrency, :fxRate, :amount, :amountMtd, "
              + ":amountQtd, :amountYtd, :amountItd,"
              + ":unitsMtd, :unitsQtd, :unitsYtd, :unitsItd, :units, "
              + ":action, :relatesTo, :createdBy, :isCreatedByInternalUser, "
              + ":createdOn, :modifiedBy, :isModifiedByInternalUser, :modifiedOn, :documentName from"
              + " dual",
      nativeQuery = true)
  @Transactional
  Integer insertBalance(
      Long id,
      Integer version,
      Long accountId,
      Long securityId,
      Long documentId,
      String source,
      String dataSource,
      LocalDate entryDate,
      LocalDate balanceDate,
      LocalDateTime knowledgeStartDate,
      LocalDateTime knowledgeEndDate,
      Boolean isCurrent,
      String type,
      String currency,
      String fxCurrency,
      Double fxRate,
      Double amount,
      Double amountMtd,
      Double amountQtd,
      Double amountYtd,
      Double amountItd,
      Double unitsMtd,
      Double unitsQtd,
      Double unitsYtd,
      Double unitsItd,
      Double units,
      String action,
      String relatesTo,
      String createdBy,
      Boolean isCreatedByInternalUser,
      LocalDateTime createdOn,
      String modifiedBy,
      Boolean isModifiedByInternalUser,
      LocalDateTime modifiedOn,
      String documentName);

  @Query(value = "select last_insert_id() ", nativeQuery = true)
  Long getId();

  Collection<BalanceEntity> findAllByDocumentIdAndIsCurrentAndActionNot(
      Long documentId, boolean isCurrent, String action);
}
