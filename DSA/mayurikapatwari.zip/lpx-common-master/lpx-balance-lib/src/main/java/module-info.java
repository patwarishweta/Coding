import com.cwan.pbor.balance.BalanceService;
import com.cwan.pbor.balance.api.Balances;

module pbor.balance.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;

  exports com.cwan.pbor.balance.api;

  provides Balances with
      BalanceService;
}
