create schema if not exists pabor;
create table if not exists pabor.balance
(
  id                           bigint       not null auto_increment primary key,
  version                      int          null,
  account_id                   bigint       not null,
  security_id                  bigint       not null,
  document_id                  bigint       null,
  entry_date                   date         null,
  source                       varchar(30)  null,
  knowledge_start_date         datetime     null,
  knowledge_end_date           datetime     null,
  type                         varchar(50)  not null,
  currency                     char(3)      not null,
  amount                       float(53)    not null,
  is_current                   bit          null,
  amount_mtd                   float(53)    null,
  amount_qtd                   float(53)    null,
  amount_ytd                   float(53)    null,
  amount_itd                   float(53)    null,
  action                       varchar(256) null,
  created_by                   varchar(256) null,
  is_created_by_internal_user  bit          null,
  created_on                   datetime     null,
  modified_by                  varchar(256) null,
  is_modified_by_internal_user bit          null,
  modified_on                  datetime     null
);
