package com.cwan.pbor.fs;

import static com.cwan.pbor.fs.TestUtil.getObjectMapper;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.cwan.lpx.domain.FinancialStatement;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import java.nio.file.Files;
import java.nio.file.Path;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

public class FinancialStatementTest {
  @Test
  @SneakyThrows
  void financial_statement_deserialization() {
    FinancialStatement financialStatement = null;
    try {
      financialStatement =
          getObjectMapper()
              .readValue(
                  Files.readString(Path.of("src/test/resources/nos-pabor-ffs-message.json")),
                  FinancialStatement.class);
    } catch (MismatchedInputException e) {
      System.out.println(e.getMessage());
    }
    assertNotNull(financialStatement);
    assertEquals(1, financialStatement.getAccount().getId());
  }
}
