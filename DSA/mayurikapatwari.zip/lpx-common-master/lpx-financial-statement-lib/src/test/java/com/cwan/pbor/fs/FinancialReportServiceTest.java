package com.cwan.pbor.fs;

import static com.cwan.pbor.fs.TestUtil.getNosPaborFfsMessageFinancialStatement;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.FinancialStatement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
class FinancialReportServiceTest {

  private static final Long FINANCIAL_STATEMENT_ID = 1L;
  private static final Set<Long> FINANCIAL_STATEMENT_IDS = Set.of(FINANCIAL_STATEMENT_ID);
  private static final FinancialReportEntity FINANCIAL_REPORT_ENTITY =
      TestUtil.getNosPaborFfsMessageFinancialReportEntity(FINANCIAL_STATEMENT_ID);
  private static final List<FinancialReportEntity> FINANCIAL_REPORT_ENTITIES =
      List.of(FINANCIAL_REPORT_ENTITY);
  private static final FinancialStatement FINANCIAL_STATEMENT =
      getNosPaborFfsMessageFinancialStatement(FINANCIAL_STATEMENT_ID);
  private static final List<FinancialStatement> FINANCIAL_STATEMENTS = List.of(FINANCIAL_STATEMENT);
  private static final Set<Long> ACCOUNT_IDS = Set.of(1L, 2L);
  private static final LocalDate BEGIN_DATE = LocalDate.of(2022, 1, 1);
  private static final LocalDate END_DATE = LocalDate.of(2022, 2, 1);
  @Mock private FinancialReportRepository mockFinancialReportRepository;
  private final FinancialReportEntityTransformer financialReportEntityTransformer =
      new FinancialReportEntityTransformer();
  private final FinancialReportTransformer mockFinancialReportTransformer =
      new FinancialReportTransformer();
  private FinancialReportService financialReportService;

  @BeforeEach
  void before_each() {
    openMocks(this);
    financialReportService =
        new FinancialReportService(
            mockFinancialReportRepository,
            financialReportEntityTransformer,
            mockFinancialReportTransformer);
  }

  @Test
  void should_add_financial_report_successfully() {
    when(mockFinancialReportRepository.saveAndFlush(any(FinancialReportEntity.class)))
        .thenReturn(FINANCIAL_REPORT_ENTITY);
    StepVerifier.create(
            financialReportService.addReports(
                Set.of(getNosPaborFfsMessageFinancialStatement(null))))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void should_throw_FinancialStatementException_in_addFinancialStatement() {
    when(mockFinancialReportRepository.saveAndFlush(any(FinancialReportEntity.class)))
        .thenThrow(FinancialReportException.class);
    StepVerifier.create(financialReportService.addReports(Set.of(FINANCIAL_STATEMENT)))
        .expectError(FinancialReportException.class)
        .verify();
  }

  @Test
  void should_successfully_get_financial_report_by_financial_statement_ids() {
    when(mockFinancialReportRepository.findAllById(any())).thenReturn(FINANCIAL_REPORT_ENTITIES);
    StepVerifier.create(financialReportService.getReportsByIds(FINANCIAL_STATEMENT_IDS))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void
      should_update_FinancialStatement_with_updated_accountId_passed_in_updateFinancialStatementInfo() {
    var modifiedFinancialStatement =
        getNosPaborFfsMessageFinancialStatement(FINANCIAL_STATEMENT_ID);
    var modifiedFinancialStatementEntity =
        TestUtil.getNosPaborFfsMessageFinancialReportEntity(FINANCIAL_STATEMENT_ID);
    var accountId = 42L;
    modifiedFinancialStatement.getAccount().setId(accountId);
    modifiedFinancialStatementEntity.setAccountId(accountId);
    when(mockFinancialReportRepository.saveAndFlush(modifiedFinancialStatementEntity))
        .thenReturn(modifiedFinancialStatementEntity);
    StepVerifier.create(
            financialReportService.updateFinancialStatementInfo(
                FINANCIAL_STATEMENT_IDS, Set.of(modifiedFinancialStatement)))
        .expectNextCount(1L)
        .verifyComplete();
  }

  @Test
  void should_successfully_get_all_financial_statements_by_document_id() {
    var documentId = 9L;
    when(mockFinancialReportRepository.findAllByDocumentId(documentId))
        .thenReturn(FINANCIAL_REPORT_ENTITIES);
    StepVerifier.create(financialReportService.getAllFinancialStatementsByDocumentId(documentId))
        .expectNextCount(1)
        .verifyComplete();
  }

  @Test
  void
      addReports_WhenExceptionThrownInSaveFinancialStatements_ShouldThrowFinancialReportException() {
    // Arrange
    Set<FinancialStatement> financialStatements = new HashSet<>();

    // Create a Document instance using the Lombok builder
    Document document =
        Document.builder()
            .originalFileName(
                "testFile.pdf") // Ensure your Document class has a builder and this field
            .build();

    // Create a FinancialStatement instance with the document
    FinancialStatement statement =
        FinancialStatement.builder()
            .document(document)
            .account(Account.builder().id(1L).build())
            .build();

    financialStatements.add(statement);

    // Simulate exception during the repository save
    when(mockFinancialReportRepository.saveAndFlush(any()))
        .thenThrow(new RuntimeException("Database error"));

    // Act & Assert
    FinancialReportException exception =
        assertThrows(
            FinancialReportException.class,
            () -> financialReportService.addReports(financialStatements).collectList().block());

    // Assert
    assertEquals("400 BAD_REQUEST \"Error creating FinancialStatement\"", exception.getMessage());
    verify(mockFinancialReportRepository, times(1)).saveAndFlush(any(FinancialReportEntity.class));
  }

  @Test
  void getAllFinancialStatementsByAccountId_ShouldReturnTransformedFinancialStatements() {
    // Arrange
    Set<Long> accountIds = new HashSet<>(List.of(1L, 2L, 3L));
    LocalDateTime asOfDate = LocalDateTime.now();

    // Create sample FinancialReportEntity objects
    FinancialReportEntity entity1 = new FinancialReportEntity();
    FinancialReportEntity entity2 = new FinancialReportEntity();

    // Define mock behavior for the repository
    when(mockFinancialReportRepository.findAllByAccountIdInAndKnowledgeEndDateAfter(
            accountIds, asOfDate))
        .thenReturn(List.of(entity1, entity2));

    // Mock the transformation behavior
    FinancialStatement transformedStatement1 = new FinancialStatement(); // Set properties as needed
    FinancialStatement transformedStatement2 = new FinancialStatement(); // Set properties as needed
    // Act
    Flux<FinancialStatement> result =
        financialReportService.getAllFinancialStatementsByAccountId(accountIds, asOfDate);

    // Collect results
    List<FinancialStatement> statements = result.collectList().block();

    // Assert
    assertEquals(2, statements.size());
    assertNotNull(statements.get(0));
    assertNotNull(statements.get(1));
    verify(mockFinancialReportRepository)
        .findAllByAccountIdInAndKnowledgeEndDateAfter(accountIds, asOfDate);
  }
}
