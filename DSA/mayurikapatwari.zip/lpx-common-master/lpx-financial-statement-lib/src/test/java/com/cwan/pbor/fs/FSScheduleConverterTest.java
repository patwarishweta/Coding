package com.cwan.pbor.fs;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.cwan.lpx.domain.FSSchedules;
import org.junit.jupiter.api.Test;

public class FSScheduleConverterTest {
  @Test
  void convertToDatabaseColumn_validJson() {
    FSScheduleConverter fsScheduleConverter = new FSScheduleConverter(TestUtil.getObjectMapper());
    FSSchedules fsSchedule = TestUtil.getNosPaborFfsMessageFinancialStatement(1L).getFsSchedules();

    String dbColumn = fsScheduleConverter.convertToDatabaseColumn(fsSchedule);

    assertNotNull(dbColumn);
    assertTrue(dbColumn.contains("fsIncomeStatement"));
    assertTrue(dbColumn.contains("fsBalanceSheet"));
    assertTrue(dbColumn.contains("fsStatementOfCashflow"));
  }

  @Test
  void convertToEntityAttribute_validJson() {
    FSScheduleConverter fsScheduleConverter = new FSScheduleConverter(TestUtil.getObjectMapper());

    String json = "{\"fsIncomeStatement\":{},\"fsBalanceSheet\":{},\"fsStatementOfCashflow\":{}}";
    FSSchedules fsSchedules = fsScheduleConverter.convertToEntityAttribute(json);

    assertNotNull(fsSchedules);
    assertNotNull(fsSchedules.getFsIncomeStatement());
    assertNotNull(fsSchedules.getFsBalanceSheet());
    assertNotNull(fsSchedules.getFsStatementOfCashflow());
  }

  @Test
  void convertToEntityAttribute_invalidJson() {
    FSScheduleConverter fsScheduleConverter = new FSScheduleConverter(TestUtil.getObjectMapper());

    String json =
        "{\"bad_fsIncomeStatement\": 123,\"bad_fsBalanceSheet\":{},\"bad_fsStatementOfCashflow\":{}}";
    FSSchedules fsSchedules = fsScheduleConverter.convertToEntityAttribute(json);

    assertNull(fsSchedules);
  }
}
