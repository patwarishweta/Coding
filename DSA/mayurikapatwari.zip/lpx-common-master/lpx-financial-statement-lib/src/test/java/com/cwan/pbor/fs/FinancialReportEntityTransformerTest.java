package com.cwan.pbor.fs;

import static com.cwan.pbor.fs.TestUtil.getNosPaborFfsMessageFinancialStatement;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FinancialReportEntityTransformerTest {

  public static final Long FINANCIAL_STATEMENT_ID = 1L;

  @Test
  void should_convert_financial_statement_to_financial_report_entity() {
    var expected = getNosPaborFfsMessageFinancialStatement(FINANCIAL_STATEMENT_ID);
    var actual =
        new FinancialReportEntityTransformer()
            .apply(getNosPaborFfsMessageFinancialStatement(FINANCIAL_STATEMENT_ID));
    assertEquals(expected.getId(), actual.getId());
    assertEquals(expected.getAccount().getId(), actual.getAccountId());
    assertEquals(expected.getSecurity().getSecurityId(), actual.getSecurityId());
    assertEquals(expected.getDocument().getId(), actual.getDocumentId());
    assertEquals(expected.getReportDate(), actual.getReportDate());
    assertEquals(expected.getSource(), actual.getSource());
    assertEquals(expected.getDataSource(), actual.getDataSource());
    // financialReportJson
    assertEquals(expected.getKnowledgeStartDate(), actual.getKnowledgeStartDate());
    assertEquals(expected.getKnowledgeEndDate(), actual.getKnowledgeEndDate());
    assertEquals(expected.getCreatedBy(), actual.getCreatedBy());
    assertEquals(expected.getIsCreatedByInternalUser(), actual.getIsCreatedByInternalUser());
    assertEquals(expected.getCreatedOn(), actual.getCreatedOn());
    assertEquals(expected.getModifiedBy(), actual.getModifiedBy());
    assertEquals(expected.getIsModifiedByInternalUser(), actual.getIsModifiedByInternalUser());
    assertEquals(expected.getModifiedOn(), actual.getModifiedOn());
  }
}
