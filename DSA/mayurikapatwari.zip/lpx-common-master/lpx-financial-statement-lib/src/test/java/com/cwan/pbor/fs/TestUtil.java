package com.cwan.pbor.fs;

import com.cwan.lpx.domain.FinancialStatement;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.nio.file.Files;
import java.nio.file.Path;
import lombok.SneakyThrows;

public class TestUtil {

  @SneakyThrows
  public static FinancialStatement getNosPaborFfsMessageFinancialStatement(Long id) {
    var ffs =
        getObjectMapper()
            .readValue(
                Files.readString(Path.of("src/test/resources/nos-pabor-ffs-message.json")),
                FinancialStatement.class);
    ffs.setId(id);
    return ffs;
  }

  @SneakyThrows
  public static FinancialReportEntity getNosPaborFfsMessageFinancialReportEntity(Long id) {
    var ffs =
        getObjectMapper()
            .readValue(
                Files.readString(Path.of("src/test/resources/nos-pabor-ffs-entity-message.json")),
                FinancialReportEntity.class);
    ffs.setId(id);
    return ffs;
  }

  public static ObjectMapper getObjectMapper() {
    return new ObjectMapper().registerModule(new JavaTimeModule());
  }
}
