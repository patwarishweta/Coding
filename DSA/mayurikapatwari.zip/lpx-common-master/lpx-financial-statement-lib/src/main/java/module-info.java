import com.cwan.pbor.fs.FinancialReportService;
import com.cwan.pbor.fs.api.FinancialReports;

module pbor.fs.reader {
  requires reactor.core;
  requires lombok;
  requires jakarta.persistence;
  requires org.hibernate.orm.core;
  requires spring.web;
  requires spring.context;
  requires spring.tx;
  requires spring.core;
  requires spring.data.commons;
  requires spring.data.jpa;
  requires spring.boot.starter.data.jpa;
  requires spring.beans;
  requires org.reactivestreams;
  requires org.slf4j;
  requires cwan.lpx.domain;
  requires spring.boot;
  requires com.fasterxml.jackson.databind;
  requires com.fasterxml.jackson.datatype.jsr310;

  exports com.cwan.pbor.fs.api;
  exports com.cwan.pbor.fs;

  provides FinancialReports with
      FinancialReportService;
}
