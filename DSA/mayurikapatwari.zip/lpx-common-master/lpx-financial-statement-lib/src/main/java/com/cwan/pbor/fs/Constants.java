package com.cwan.pbor.fs;

public class Constants {

  public static final boolean IS_CURRENT = true;
  public static final String CANCEL = "Cancel";

  private Constants() {}
}
