package com.cwan.pbor.fs;

import java.io.Serial;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class FinancialReportException extends ResponseStatusException {

  @Serial private static final long serialVersionUID = 6130403690884111968L;

  public FinancialReportException(String msg, Throwable e) {
    super(HttpStatus.INTERNAL_SERVER_ERROR, msg, e);
  }

  public FinancialReportException(String msg) {
    super(HttpStatus.BAD_REQUEST, msg);
  }
}
