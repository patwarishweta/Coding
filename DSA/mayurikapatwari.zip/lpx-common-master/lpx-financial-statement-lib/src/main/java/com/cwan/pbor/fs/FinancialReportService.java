package com.cwan.pbor.fs;

import static java.util.stream.Collectors.toSet;

import com.cwan.lpx.domain.FinancialStatement;
import com.cwan.pbor.fs.api.FinancialReports;
import java.time.LocalDateTime;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

@Service
@Slf4j
public class FinancialReportService implements FinancialReports {

  public FinancialReportService() {}

  private FinancialReportRepository financialReportRepository;
  private FinancialReportEntityTransformer financialReportEntityTransformer;
  private FinancialReportTransformer financialReportTransformer;

  @Autowired
  FinancialReportService(
      final FinancialReportRepository financialReportRepository,
      final FinancialReportEntityTransformer financialReportEntityTransformer,
      final FinancialReportTransformer financialReportTransformer) {
    this.financialReportRepository = financialReportRepository;
    this.financialReportEntityTransformer = financialReportEntityTransformer;
    this.financialReportTransformer = financialReportTransformer;
  }

  public Flux<FinancialStatement> addReports(final Set<FinancialStatement> financialStatements) {
    Set<FinancialReportEntity> financialReportEntities =
        financialStatements.stream().map(financialReportEntityTransformer).collect(toSet());
    return saveFinancialStatements(Flux.fromIterable(financialReportEntities));
  }

  @Override
  public Flux<FinancialStatement> getReportsByIds(Set<Long> ids) {
    return Flux.fromIterable(financialReportRepository.findAllById(ids))
        .log("findByFinancialStatementId")
        .map(financialReportTransformer);
  }

  @Transactional
  public Flux<FinancialStatement> updateFinancialStatementInfo(
      Set<Long> ids, final Set<FinancialStatement> transactions) {
    return saveFinancialStatements(
        Flux.fromStream(transactions.stream().map(financialReportEntityTransformer)));
  }

  @Transactional
  public Flux<FinancialStatement> getAllFinancialStatementsByDocumentId(Long documentId) {
    return Flux.fromIterable(financialReportRepository.findAllByDocumentId(documentId))
        .map(financialReportTransformer);
  }

  @Transactional
  public Flux<FinancialStatement> getAllFinancialStatementsByAccountId(
      Set<Long> accountId, LocalDateTime asOfDate) {
    return Flux.fromIterable(
            financialReportRepository.findAllByAccountIdInAndKnowledgeEndDateAfter(
                accountId, asOfDate))
        .map(financialReportTransformer);
  }

  private Flux<FinancialStatement> saveFinancialStatements(
      Flux<FinancialReportEntity> financialReportEntityFlux) {
    return financialReportEntityFlux
        .publishOn(Schedulers.boundedElastic())
        .map(fs -> financialReportRepository.saveAndFlush(fs))
        .onErrorResume(
            e -> {
              log.error("Error creating FinancialStatement", e);
              return Flux.error(new FinancialReportException("Error creating FinancialStatement"));
            })
        .log("Created FinancialStatement")
        .map(financialReportTransformer);
  }
}
