package com.cwan.pbor.fs.api;

import com.cwan.lpx.domain.FinancialStatement;
import java.util.Set;
import reactor.core.publisher.Flux;

public interface FinancialReports {

  Flux<FinancialStatement> addReports(Set<FinancialStatement> financialReports);

  Flux<FinancialStatement> getReportsByIds(Set<Long> ids);

  Flux<FinancialStatement> getAllFinancialStatementsByDocumentId(Long documentId);
}
