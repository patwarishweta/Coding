package com.cwan.pbor.fs;

import com.cwan.lpx.domain.FinancialStatement;
import java.util.Objects;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class FinancialReportEntityTransformer
    implements Function<FinancialStatement, FinancialReportEntity> {

  @Override
  public FinancialReportEntity apply(FinancialStatement financialStatement) {
    return FinancialReportEntity.builder()
        .id(financialStatement.getId())
        .accountId(financialStatement.getAccount().getId())
        .securityId(
            Objects.nonNull(financialStatement.getSecurity())
                ? financialStatement.getSecurity().getSecurityId()
                : null)
        .documentId(
            Objects.nonNull(financialStatement.getDocument())
                ? financialStatement.getDocument().getId()
                : null)
        .source(financialStatement.getSource())
        .dataSource(financialStatement.getDataSource())
        .reportDate(financialStatement.getReportDate())
        .currency(financialStatement.getCurrency())
        .periodType(financialStatement.getPeriodType())
        .type(financialStatement.getType())
        .date(financialStatement.getDate())
        .fundNav(financialStatement.getFundNav())
        .vehicleName(financialStatement.getVehicleName())
        .fundId(financialStatement.getFundId())
        .financialReportJson(financialStatement.getFsSchedules())
        .knowledgeStartDate(financialStatement.getKnowledgeStartDate())
        .knowledgeEndDate(financialStatement.getKnowledgeEndDate())
        .createdBy(financialStatement.getCreatedBy())
        .isCreatedByInternalUser(financialStatement.getIsCreatedByInternalUser())
        .createdOn(financialStatement.getCreatedOn())
        .modifiedBy(financialStatement.getModifiedBy())
        .isModifiedByInternalUser(financialStatement.getIsModifiedByInternalUser())
        .modifiedOn(financialStatement.getModifiedOn())
        .build();
  }
}
