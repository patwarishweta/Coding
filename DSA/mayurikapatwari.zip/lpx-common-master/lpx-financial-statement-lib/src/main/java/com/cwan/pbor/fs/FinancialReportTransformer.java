package com.cwan.pbor.fs;

import com.cwan.lpx.domain.Account;
import com.cwan.lpx.domain.Document;
import com.cwan.lpx.domain.FinancialStatement;
import com.cwan.lpx.domain.Security;
import java.util.function.Function;
import org.springframework.stereotype.Component;

@Component
public class FinancialReportTransformer
    implements Function<FinancialReportEntity, FinancialStatement> {

  @Override
  public FinancialStatement apply(FinancialReportEntity financialReportEntity) {
    return FinancialStatement.builder()
        .id(financialReportEntity.getId())
        .account(Account.builder().id(financialReportEntity.getAccountId()).build())
        .security(Security.builder().securityId(financialReportEntity.getSecurityId()).build())
        .document(Document.builder().id(financialReportEntity.getDocumentId()).build())
        .source(financialReportEntity.getSource())
        .dataSource(financialReportEntity.getDataSource())
        .fsSchedules(financialReportEntity.getFinancialReportJson())
        .knowledgeStartDate(financialReportEntity.getKnowledgeStartDate())
        .knowledgeEndDate(financialReportEntity.getKnowledgeEndDate())
        .createdBy(financialReportEntity.getCreatedBy())
        .isCreatedByInternalUser(financialReportEntity.getIsCreatedByInternalUser())
        .createdOn(financialReportEntity.getCreatedOn())
        .modifiedBy(financialReportEntity.getModifiedBy())
        .isModifiedByInternalUser(financialReportEntity.getIsModifiedByInternalUser())
        .modifiedOn(financialReportEntity.getModifiedOn())
        .build();
  }
}
