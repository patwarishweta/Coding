package com.cwan.pbor.fs;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinancialReportRepository extends JpaRepository<FinancialReportEntity, Long> {

  Collection<FinancialReportEntity> findAllByAccountIdInAndKnowledgeEndDateAfter(
      Collection<Long> accountIds, LocalDateTime asOfDate);

  Collection<FinancialReportEntity> findAllByDocumentId(Long documentId);
}
