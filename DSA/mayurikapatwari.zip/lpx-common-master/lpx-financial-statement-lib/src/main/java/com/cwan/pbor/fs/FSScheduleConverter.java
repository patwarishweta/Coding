package com.cwan.pbor.fs;

import com.cwan.lpx.domain.FSSchedules;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FSScheduleConverter implements AttributeConverter<FSSchedules, String> {
  private final ObjectMapper objectMapper;

  public FSScheduleConverter(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  @Override
  public String convertToDatabaseColumn(FSSchedules fsSchedules) {

    String json = null;
    try {
      json = this.objectMapper.writeValueAsString(fsSchedules);
    } catch (final JsonProcessingException e) {
      log.error("JSON writing error - cannot convert FSSchedule to JSON", e);
    }

    return json;
  }

  @Override
  public FSSchedules convertToEntityAttribute(String fsScheduleJson) {

    FSSchedules fsSchedules = null;
    try {
      fsSchedules = this.objectMapper.readValue(fsScheduleJson, new TypeReference<>() {});
    } catch (final IOException e) {
      log.error("JSON reading error - cannot convert JSON to FSSchedule", e);
    }

    return fsSchedules;
  }
}
