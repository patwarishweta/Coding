create schema if not exists pabor;
-- FROM: pbor-db-aws/src/master/src/main/resources/sql/pabor.financial_statement.sql
create table if not exists pabor.financial_statement
(
  id                           bigint       not null auto_increment primary key,
  account_id                   bigint       not null,
  security_id                  bigint       not null,
  document_id                  bigint       not null,
  source                       varchar(30)  null,
  data_source                  varchar(30)  null,
  report_date                  timestamp    not null,
  financial_report_json        json         null,
  knowledge_start_date         date         null,
  knowledge_end_date           date         null,
  created_by                   varchar(256) null,
  is_created_by_internal_user  bit          null,
  created_on                   timestamp    null,
  modified_by                  varchar(256) null,
  is_modified_by_internal_user bit          null,
  modified_on                  timestamp    null
);
