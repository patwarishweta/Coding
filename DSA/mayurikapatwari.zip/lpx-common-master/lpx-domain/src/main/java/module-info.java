module cwan.lpx.domain {
  requires lombok;
  requires java.desktop;
  requires com.fasterxml.jackson.annotation;
  requires org.apache.commons.lang3;

  exports com.cwan.lpx.domain;
}
