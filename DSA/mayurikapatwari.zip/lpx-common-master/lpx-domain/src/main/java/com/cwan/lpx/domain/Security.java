package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class Security implements Serializable {

  @Serial private static final long serialVersionUID = -2584234936232687509L;
  private Long securityId;
  private String securityName;
  private String cusip;
  private Currency currency;
  private SecurityDetail securityDetail;
  private FundDetail fundDetail;
  private SecurityTypeDataDetail securityTypeDataDetail;
  private SecurityInvestmentDetail securityInvestmentDetail;
  private SecurityPerformance securityPerformance;
}
