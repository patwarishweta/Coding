package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Asset {

  private String name;
  private Investment investment;
  private Operating operating;
  private AssetDetails assetDetails;
  private AssetInvestmentDetails assetInvestmentDetails;
  private AssetPerformance assetPerformance;
}
