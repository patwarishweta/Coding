package com.cwan.lpx.domain;

public enum ReconciliationStatus {
  MISMATCH,
  MATCHED,
  MISSING_CUSTODY,
  MISSING_DOCUMENT,
  FORCEDMATCH
}
