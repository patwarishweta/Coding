package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class FSBalanceSheet implements Serializable {

  @Serial private static final long serialVersionUID = 9153805491290889621L;
  private TotalAssets totalAssets;
  private TotalLiabilitiesAndPartnersCapital totalLiabilitiesAndPartnersCapital;
}
