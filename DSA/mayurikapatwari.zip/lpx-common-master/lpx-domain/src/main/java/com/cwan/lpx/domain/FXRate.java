package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class FXRate implements Serializable {
  private Long baseCurrencyId;
  private Long localCurrencyId;
  private ReportingFrequency reportingFrequency;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate date;

  private Long fxRateSourceId;
  private Double fxRate;
  private Double averageFxRate;

  private String createdBy;
  private Boolean isCreatedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;
}
