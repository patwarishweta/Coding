package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class SuspenseQueue implements Serializable {

  @Serial private static final long serialVersionUID = 5977403601863539989L;

  private Long id;
  private String canoeId;
  private String documentName;
  private Long clientId;
  private Long ultimateParentId;
  private String ultimateParentName;
  private String originalFileName;

  @JsonIncludeProperties({"name"})
  private Client client;

  @JsonIncludeProperties({"id", "name"})
  private Account dataForgeAccount;

  @JsonIncludeProperties({"id", "name"})
  private Account canoeAccount;

  @JsonIncludeProperties({"securityId", "securityName"})
  private Security dataForgeSecurity;

  @JsonIncludeProperties({"securityId", "securityName"})
  private Security canoeSecurity;

  private Long documentId;
  private String s3Path;

  private String canoeClassification;
  private String dataForgeClassification;
  private String finalValueSource;
  private String assignedTo;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate receivedDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate dataDate;

  private Integer daysAgeing;

  private String createdBy;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;

  private Integer version;
  private Boolean isCurrent;
  private Boolean isDisabled;

  private String notes;
  private String clientCurrentState;
}
