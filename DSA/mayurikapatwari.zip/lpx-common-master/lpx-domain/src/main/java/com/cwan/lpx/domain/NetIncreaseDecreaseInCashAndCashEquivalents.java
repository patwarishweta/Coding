package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class NetIncreaseDecreaseInCashAndCashEquivalents implements Serializable {

  @Serial private static final long serialVersionUID = -5901323889658568075L;
  private String netIncreaseDecreaseInCashAndCashEquivalentsValue;
  private CashFlowFromOperatingActivities cashFlowFromOperatingActivities;
  private CashFlowFromFinancingActivities cashFlowFromFinancingActivities;
}
