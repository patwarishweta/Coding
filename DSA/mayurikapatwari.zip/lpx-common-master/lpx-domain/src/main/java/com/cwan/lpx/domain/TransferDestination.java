package com.cwan.lpx.domain;

public record TransferDestination(
    Long accountId,
    Double marketValue,
    Double unfundedCommitment,
    Double fundedCommitment,
    Double recallableDist,
    Double units) {}
