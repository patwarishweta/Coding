package com.cwan.lpx.domain;

import java.io.Serializable;
import lombok.Builder;

@Builder(toBuilder = true)
public record CapitalCallPermissions(boolean approveActionAllowed, boolean rejectActionAllowed)
    implements Serializable {}
