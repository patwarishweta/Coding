package com.cwan.lpx.domain;

import java.io.Serializable;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record CapitalCallBankDetail(
    String bankName,
    String abaRoutingNumber,
    String swiftOrChips,
    String accountNumber,
    String accountIban,
    Long bankDetailId,
    Boolean newAccount)
    implements Serializable {

  public static class CapitalCallBankDetailBuilder {

    public CapitalCallBankDetailBuilder bankName(String bankName) {
      this.bankName = StringUtils.trimToNull(StringUtils.normalizeSpace(bankName));
      return this;
    }

    public CapitalCallBankDetailBuilder abaRoutingNumber(String abaRoutingNumber) {
      this.abaRoutingNumber = StringUtils.trimToNull(StringUtils.normalizeSpace(abaRoutingNumber));
      return this;
    }

    public CapitalCallBankDetailBuilder swiftOrChips(String swiftOrChips) {
      this.swiftOrChips = StringUtils.trimToNull(StringUtils.normalizeSpace(swiftOrChips));
      return this;
    }

    public CapitalCallBankDetailBuilder accountNumber(String accountNumber) {
      this.accountNumber = StringUtils.trimToNull(StringUtils.normalizeSpace(accountNumber));
      return this;
    }
  }
}
