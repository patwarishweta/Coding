package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class TransactionSubType implements Serializable {

  @Serial private static final long serialVersionUID = -7188599289392132854L;
  private String code;
  private String name;
  private String description;
  private TransactionType transactionType;
  private Integer bookImpactMultiplier;
  private Integer cashImpactMultiplier;
  private Integer navImpactMultiplier;
  private Integer unfundedCommitmentMultiplier;
  private Integer recallImpactMultiplier;
  private Integer unitImpactMultiplier;
  private String createdBy;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;

  private Boolean isCreatedByInternalUser;
  private Boolean isModifiedByInternalUser;
}
