package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TotalIncome implements Serializable {

  @Serial private static final long serialVersionUID = 410862144200255769L;
  private String totalIncomeValue;
  private String portfolioInterestIncome;
  private String portfolioDividendIncome;
  private String otherInterestEarned;
  private String investmentIncome;
  private String otherIncome;
  private String reimbursementFromAffiliate;
}
