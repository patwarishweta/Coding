package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class Currency implements Serializable {

  @Serial private static final long serialVersionUID = -1833982748371991460L;
  private Long currencyId;
  private String code;
}
