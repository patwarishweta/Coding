package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Balance implements Serializable {

  @Serial private static final long serialVersionUID = -568155604698456903L;
  private Long id;
  private Integer version;
  private Account account;
  private Security security;
  private Document document;
  private String source;
  private String dataSource;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate entryDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate balanceDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime knowledgeStartDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime knowledgeEndDate;

  private String type;
  private String currency;
  private String fxCurrency;
  private Double fxRate;
  private Double amount;
  private Boolean isCurrent;
  private Double amountMTD;
  private Double amountQTD;
  private Double amountYTD;
  private Double amountITD;
  private Double unitsMTD;
  private Double unitsQTD;
  private Double unitsYTD;
  private Double unitsITD;
  private Double units;
  private String action;
  private String relatesTo;
  private String createdBy;
  private Boolean isCreatedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;
}
