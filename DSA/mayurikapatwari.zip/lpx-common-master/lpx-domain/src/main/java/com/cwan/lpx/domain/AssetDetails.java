package com.cwan.lpx.domain;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class AssetDetails {

  private String clientSecurityName;
  private String couponType;
  private Long currentRate;
  private String debtSeniority;
  private Double fixedRate;
  private Double floor;
  private Long investmentRound;
  private LocalDate maturityDate;
  private String pikSpread;
  private Long quotedSpread;
  private Double referenceRate;
  private Double referenceRateFloor;
  private Boolean secured;
  private Double securityCCY;
  private String securityClass;
  private String securityDescription;
  private String securityType;
  private String terminationOption;
  private String dealType;
  private String gicsIndustry;
  private Boolean isPublic;
  private String pcCurrency;
  private String propertyArea;
  private String propertyType;
  private String sector;
  private String stockTicker;
}
