package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class DuplicateCanoe implements Comparable<DuplicateCanoe>, Serializable {

  @Serial private static final long serialVersionUID = -2677110739805775711L;
  private String duplicateCanoeId;
  private LocalDateTime duplicateReceivedOn;

  /**
   * Compare by `duplicateReceivedOn` **descending** (nulls go last, meaning they're treated as
   * "smaller").
   */
  @Override
  public int compareTo(@NonNull DuplicateCanoe other) {
    if (Objects.isNull(this.duplicateReceivedOn) && Objects.isNull(other.duplicateReceivedOn)) {
      return 0;
    }
    if (Objects.isNull(this.duplicateReceivedOn)) {
      return 1;
    }
    if (Objects.isNull(other.duplicateReceivedOn)) {
      return -1;
    }
    return other.duplicateReceivedOn.compareTo(this.duplicateReceivedOn);
  }
}
