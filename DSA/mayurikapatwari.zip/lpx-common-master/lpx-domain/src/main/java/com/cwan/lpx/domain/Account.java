package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class Account implements Serializable {

  @Serial private static final long serialVersionUID = 8898116725088501357L;
  private Long id;
  private String name;
  private Boolean multiCurrency;
  private Boolean aggregate;
  private Boolean displayed;
  private Long functionalCurrencyId;
  private String functionalCurrencyCode;
  private Long currencyFxRateSourceId;
  private Long clientId;
  private Client client;
  private String sourceAccount;
  private String sourceAccountName;
  private Boolean stat;
  private Boolean simpleWeight;
  private Integer numRatingsRequired;
  private Boolean active;
  private Boolean demo;
  private Boolean naic;
  private Boolean tax;
  private Boolean premiumUseWalForEffectiveMaturity;
  private Boolean discountUseWalForEffectiveMaturity;
  private Boolean tradingReconciled;
  private List<Long> simpleAccountIds;
  private Client ultimateParentClient;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate stableDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate subscriptionStartDate;

  private Boolean reconciled;
  private Boolean mmfundInterestAccrued;
  private Map<String, String> attributes;
}
