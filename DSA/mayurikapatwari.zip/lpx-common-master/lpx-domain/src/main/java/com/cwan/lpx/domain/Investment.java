package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Investment {

  // Asset LTV (Private Debt/Real Estate)
  private String assetLtv;
  private String capitalDistributed;
  private String dealStatus;
  private String entryDate;
  private String exitDate;
  private String fundOwnershipPercentage;
  private String irrGross;
  // Multiple on invested capital (MOIC)
  private String moic;
  private String remainingCapitalInvested;
  private String residualValue;
  private String totalCapitalInvested;
}
