package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TotalLiabilitiesAndPartnersCapital implements Serializable {

  @Serial private static final long serialVersionUID = 5184428530205473536L;
  private String totalLiabilitiesAndPartnersCapitalValue;
  private TotalLiabilities totalLiabilities;
  private String totalPartnerCapital;
}
