package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class CashFlowFromOperatingActivities implements Serializable {

  @Serial private static final long serialVersionUID = -4661621657138929046L;
  private String cashFlowFromOperatingActivitiesValue;
  private String totalIncomeFromOperations;
  private String realisedGainLoss;
  private String unrealisedGainLoss;
  private ChangeInOperatingAssetsAndLiabilities changeInOperatingAssetsAndLiabilities;
}
