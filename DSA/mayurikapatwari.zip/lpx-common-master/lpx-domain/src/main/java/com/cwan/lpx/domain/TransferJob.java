package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TransferJob implements Serializable {
  private Long id;
  private Long sourceAccountId;
  private Long destAccountId;
  private String cusip;
  private Long securityId;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate entryDate;

  private List<Integer> basisIds;
  private Double units;
  private Double marketValue;
  private Double unfundedCommitment;
  private Double fundedCommitment;
  private Double recallable;
  private String currency;
  private Long userId;
  @Builder.Default private Optional<TransferDocumentInfo> document = Optional.empty();

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;
}
