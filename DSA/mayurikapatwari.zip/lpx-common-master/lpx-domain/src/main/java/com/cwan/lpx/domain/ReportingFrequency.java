package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum ReportingFrequency {
  MONTHLY(0),
  QUARTERLY(1),
  YEARLY(2);

  private int value;

  private static final Map<Integer, ReportingFrequency> FREQUENCIES =
      Arrays.asList(ReportingFrequency.values()).stream()
          .collect(Collectors.toMap(frequency -> frequency.value, Function.identity()));

  ReportingFrequency(int value) {
    this.value = value;
  }

  @JsonCreator
  public static ReportingFrequency getByValue(int id) {
    return FREQUENCIES.get(id);
  }

  public int getValue() {
    return value;
  }
}
