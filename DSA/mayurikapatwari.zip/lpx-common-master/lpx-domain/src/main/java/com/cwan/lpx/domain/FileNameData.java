package com.cwan.lpx.domain;

import java.time.LocalDate;

public interface FileNameData {

  LocalDate getDataDate();

  String getFileType();

  String getInvestment();

  String getAccount();

  String getEntity();

  String getDocumentType();
}
