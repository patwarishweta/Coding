package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ReconciliationType {
  CONTRIBUTION("Capital Call Notice", "CAPC", "CW"),
  DISTRIBUTION("Capital Distribution Notice", "CAPD", "CD");
  private final String docType;
  private final String transactionCode;
  private final String custodyTransactionCode;

  public static ReconciliationType fromTransactionCode(String transactionCode) {
    if (CONTRIBUTION.transactionCode.equalsIgnoreCase(transactionCode)) {
      return CONTRIBUTION;
    } else if (DISTRIBUTION.transactionCode.equalsIgnoreCase(transactionCode)) {
      return DISTRIBUTION;
    }
    return null;
  }
}
