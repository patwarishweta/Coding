package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TransferLink {

  private Long id;
  private TransferJob transferJob;
  private Transaction transactionIn;
  private Transaction transactionOut;
}
