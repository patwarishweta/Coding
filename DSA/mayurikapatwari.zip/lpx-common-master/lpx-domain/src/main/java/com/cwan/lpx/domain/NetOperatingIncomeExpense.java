package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class NetOperatingIncomeExpense implements Serializable {

  @Serial private static final long serialVersionUID = -398814959804264745L;
  private TotalIncome totalIncome;
  private TotalExpense totalExpense;
  private String netOperatingIncomeExpenseValue;
}
