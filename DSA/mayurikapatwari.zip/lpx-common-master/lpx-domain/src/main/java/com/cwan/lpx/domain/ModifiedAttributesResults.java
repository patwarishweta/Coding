package com.cwan.lpx.domain;

import java.util.List;
import lombok.Data;

@Data
public class ModifiedAttributesResults {

  private List<ModifiedAttributes> modifiedAttributes;
}
