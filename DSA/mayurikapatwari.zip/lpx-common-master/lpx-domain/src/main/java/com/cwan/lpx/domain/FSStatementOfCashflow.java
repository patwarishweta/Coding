package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class FSStatementOfCashflow implements Serializable {

  @Serial private static final long serialVersionUID = -3694470494659279822L;
  private String openingCashAndCashEquivalents;
  private NetIncreaseDecreaseInCashAndCashEquivalents netIncreaseDecreaseInCashAndCashEquivalents;
  private String closingCashAndCashEquivalents;
  private String cashPaidForInterest;
}
