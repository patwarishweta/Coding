package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class TransactionIdentifier implements Serializable {

  @Serial private static final long serialVersionUID = -7828627705081440682L;
  private Long id;
  private Long transactionId;
  private Integer transVersion;
  private String attributeName;
  private Long attributeValue;
  private String createdBy;
  private String modifiedBy;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;

  private Boolean isCreatedByInternalUser;
  private Boolean isModifiedByInternalUser;
}
