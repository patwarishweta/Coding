package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class CustodyTransaction {

  private Long id;
  private Double amountInReportingCurrency;
  private Double amountInLocalCurrency;
  private String transactionDescription;
  private ReconciliationType reconciliationType;
  private Long fileId;
  private String comment;
  private String localCurrencyCode;
  private String reportingCurrencyCode;
  private Long custodyAccountId;
  private String cashAccountNumber;
  private Long securityId;
  private ReconciliationStatus reconciliationStatus;
  private String dataSource;
  private String transactionType;
  private String transactionSubType;
  private Boolean isCreatedByInternalUser;
  private Boolean isModifiedByInternalUser;
  private String createdBy;
  private String modifiedBy;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate transactionDate;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
  private LocalDate reconcileDate;

  private String reason;
  private String uploadedDocCanoeId;
  private String docUploadedBy;
}
