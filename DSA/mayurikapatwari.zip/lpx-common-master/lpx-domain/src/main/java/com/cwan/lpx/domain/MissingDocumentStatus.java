package com.cwan.lpx.domain;

public enum MissingDocumentStatus {
  RECEIVED,
  MISSING,
  POTENTIALLY_MISSING
}
