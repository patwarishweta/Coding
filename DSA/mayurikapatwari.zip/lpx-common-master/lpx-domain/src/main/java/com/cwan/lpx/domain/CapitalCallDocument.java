package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record CapitalCallDocument(
    Long documentId,
    String documentName,
    BigDecimal paymentAmount,
    BigDecimal netAmount,
    Integer daysAging,
    CapitalCallBankDetail bankDetail,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate callReceivedDate,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate dueDate,
    Security security,
    Account account,
    String currency,
    CapitalCallStatus status,
    CapitalCallPermissions permissions,
    String comment,
    CapitalCallUserAction wireCheckAction,
    CapitalCallUserAction initialReviewAction,
    CapitalCallUserAction finalReviewAction,
    List<CapitalCallAudit> audit)
    implements Serializable {

  public static class CapitalCallDocumentBuilder {

    public CapitalCallDocumentBuilder documentName(String documentName) {
      this.documentName = StringUtils.trimToNull(StringUtils.normalizeSpace(documentName));
      return this;
    }

    public CapitalCallDocumentBuilder currency(String currency) {
      this.currency = StringUtils.trimToNull(StringUtils.normalizeSpace(currency));
      return this;
    }

    public CapitalCallDocumentBuilder comment(String comment) {
      this.comment = StringUtils.trimToNull(StringUtils.normalizeSpace(comment));
      return this;
    }
  }
}
