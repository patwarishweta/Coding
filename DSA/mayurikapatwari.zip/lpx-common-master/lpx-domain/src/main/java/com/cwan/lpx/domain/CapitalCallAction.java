package com.cwan.lpx.domain;

/** This enum represents the possible actions that can be taken on a Capital Call. */
public enum CapitalCallAction {
  REJECT,
  APPROVE
}
