package com.cwan.lpx.domain;

import lombok.Builder;

@Builder
public record DocumentTransferRequest(String canoeId, String fileName) {}
