package com.cwan.lpx.domain;

import lombok.Data;

@Data
public class ModifiedAttributes {

  private String fieldName;
  private String fromValue;
  private String toValue;
}
