package com.cwan.lpx.domain;

public interface SecurityFundResponseProjection {
  Long getSecurityId();

  Long getFundId();

  String getName();
}
