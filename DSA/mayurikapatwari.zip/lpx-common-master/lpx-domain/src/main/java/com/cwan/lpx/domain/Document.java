package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Document implements Serializable {

  @Serial private static final long serialVersionUID = 5977403601863539989L;
  private Long id;
  private String cloudStorageId;
  private String canoeId;
  private Account account;
  private Security security;
  private String fileName;
  private String originalFileName;
  private String type;
  private Boolean isAudited;
  private String source;
  private String auditor;
  private String accountingPrinciples;
  private LocalDate auditOpinionDate;
  private String auditOpinion;
  private String dataSource;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate receivedDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate documentDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate cashMovementDate;

  private String frequency;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate periodStartDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate periodEndDate;

  private Boolean checked;
  private String errorStatus;
  private DataForgerStatus dataForgerStatus;
  private String dataForgerOutputPath;
  private Long directoryId;
  private Boolean isDisabled;
  private String description;
  private String createdBy;
  private Boolean isCreatedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;

  private Boolean cwanGptUploaded;
  private Long custodyTransactionId;
  private String assigneeId;
  private String assigneeName;
  private String assigneeEmail;
  private String rawDataCloudStorageId;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime rawDataModifiedOn;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime validationDate;
}
