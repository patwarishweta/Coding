package com.cwan.lpx.domain;

import lombok.Builder;

@Builder
public record DocumentUploadResult(String canoeId, String storageId) {}
