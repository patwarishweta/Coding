package com.cwan.lpx.domain;

public class BalanceType {

  public static final String TOTAL_COMMITMENT = "Total Commitment";
  public static final String ENDING_NAV = "Ending NAV";
  public static final String ENDING_ECONOMIC_NAV = "Ending Economic NAV";
  public static final String RECALLABLE_DISTRIBUTION = "Recallable Distribution";
  public static final String BEGINNING_NAV = "Beginning NAV";
  public static final String BEGINNING_ECONOMIC_NAV = "Beginning Economic NAV";
  public static final String PRE_CUM_CONTRIBUTION = "Pre Cum Contribution";
  public static final String CUM_CONTRIBUTION = "Cum Contribution";
  public static final String PRE_CUM_DISTRIBUTION = "Pre Cum Distribution";
  public static final String CUM_DISTRIBUTION = "Cum Distribution";
  public static final String CARRIED_INTEREST_ENDING_BALANCE = "Carried Interest Ending Balance";
  public static final String CARRIED_INTEREST_PAID = "Carried Interest Paid";
  public static final String CARRIED_INTEREST_STARTING_BALANCE =
      "Carried Interest Starting Balance";
  public static final String CHANGE_IN_CARRIED_INTEREST_ACCRUED =
      "Change in Carried interest accrued";
  public static final String CHANGE_IN_UNREALISED_GAIN_LOSS = "Change in Unrealized Gain / Loss";
  public static final String CONTRIBUTION_CASH_NON_CASH = "Contribution Cash & Non Cash";
  public static final String DIVIDEND_INCOME = "Dividend Income";
  public static final String DISTRIBUTION_CASH_NON_CASH = "Distribution Cash & Non Cash";
  public static final String EXPIRED_RELEASED_COMMITMENTS = "Expired / Released Commitments";
  public static final String FEE_WAIVER = "Fee Waiver";
  public static final String INTEREST_EXPENSE = "Interest Expense";
  public static final String INTEREST_INCOME = "Interest Income";
  public static final String MANAGEMENT_FEE_GROSS = "Management Fee Gross";
  public static final String MANAGEMENT_FEE_NET = "Management Fee Net";
  public static final String MANAGEMENT_FEE_REBATE = "Management Fee Rebates";
  public static final String NET_OPERATING_INCOME_EXPENSE = "Net (Operating) Income / Expense";
  public static final String NET_MANAGEMENT_FEE_EXPENSE = "Net Management Fees & Expenses";
  public static final String OTHER_INCOME_EXPENSE = "Other Income / Expense";
  public static final String OTHER_UNFUNDED_ADJUSTMENT = "Other unfunded adjustment";
  public static final String PARTNERSHIP_FEE = "Partnership Fees";
  public static final String PLACEMENT_FEE = "Placement Fees";
  public static final String REALISED_GAIN_LOSS = "Realized Gain / Loss";
  public static final String TOTAL_OFFSET_FEE_EXPENSE = "Total Offsets to Fees and Expenses";
  public static final String TOTAL_CASH_NON_CASH_FLOWS = "Total Cash NonCash Flows";
  public static final String BEGINNING_UNFUNDED_COMMITMENT = "Beginning Unfunded Commitment";
  public static final String ENDING_UNFUNDED_COMMITMENT = "Ending UnFunded Commitment";
  public static final String PRE_FUNDED_COMMITMENT = "Pre Funded Commitment";
  public static final String FUNDED_COMMITMENT = "Funded Commitment";
  public static final String WATCHLIST_BEGINNING_NAV = "Watchlist Beginning NAV";
  public static final String WATCHLIST_ENDING_NAV = "Watchlist End NAV";
  public static final String WATCHLIST_ENDING_NAV_WITH_ADJUSTMENT =
      "Watchlist NAV with Adjustments";

  private BalanceType() {}
}
