package com.cwan.lpx.domain;

/**
 * This enum represents the possible statuses for a given document while running in data-forger
 * pipeline.
 */
public enum DataForgerStatus {
  CLASSIFIED,
  CLASSIFY_FAILED,
  UPLOAD_FAILED,
  EXTRACTED,
  EXTRACTION_FAILED,
  VALIDATION_FAILED,
  COMPLETE,
  SUSPENSE
}
