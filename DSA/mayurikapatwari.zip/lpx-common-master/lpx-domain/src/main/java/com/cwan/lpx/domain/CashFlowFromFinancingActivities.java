package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class CashFlowFromFinancingActivities implements Serializable {

  @Serial private static final long serialVersionUID = 7960048750578450092L;
  private String cashFlowFromFinancingActivitiesValue;
  private String capitalContributions;
  private String capitalDistributions;
  private String proceedsFromLoans;
  private String repaymentOfLoans;
}
