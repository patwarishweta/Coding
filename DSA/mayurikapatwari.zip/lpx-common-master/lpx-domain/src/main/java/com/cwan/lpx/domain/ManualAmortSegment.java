package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;

@Builder(toBuilder = true)
public record ManualAmortSegment(
    Long id,
    long accountId,
    long securityId,
    int basisId,
    double bookValue,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate effectiveDate,
    boolean isActive,
    String createdBy,
    Boolean isCreatedByInternalUser,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdOn,
    String modifiedBy,
    Boolean isModifiedByInternalUser,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime modifiedOn)
    implements Serializable {}
