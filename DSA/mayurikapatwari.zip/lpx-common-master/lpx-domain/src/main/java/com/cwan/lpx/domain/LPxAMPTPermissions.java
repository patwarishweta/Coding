package com.cwan.lpx.domain;

public class LPxAMPTPermissions {

  private LPxAMPTPermissions() {}

  public static final String LPX_MANAGEMENT_CONSOLE = "130";
  public static final String LPX_MANAGEMENT_CONSOLE_DOCUMENT_VIEW_ACCESS = "134";
  public static final String LPX_MANAGEMENT_CONSOLE_DOCUMENT_EDIT_ACCESS = "135";
  public static final String LPX_MANAGEMENT_CONSOLE_DASHBOARD_VIEW = "143";
  public static final String LPX_MANAGEMENT_CONSOLE_DASHBOARD_EDIT = "144";
  public static final String LPX_MANAGEMENT_CONSOLE_DOCUMENT_MANAGER_VIEW = "145";
  public static final String LPX_MANAGEMENT_CONSOLE_DOCUMENT_MANAGER_EDIT = "146";
  public static final String LPX_MANAGEMENT_CONSOLE_ACCOUNT_VIEW = "147";
  public static final String LPX_MANAGEMENT_CONSOLE_ACCOUNT_EDIT = "148";
  public static final String LPX_MANAGEMENT_CONSOLE_AUDIT_VIEW = "149";
  public static final String LPX_CLARITY = "153";
  public static final String LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_READ = "157";
  public static final String LPX_MANAGEMENT_CONSOLE_CAPITAL_CALL_WRITE = "158";
  public static final String LPX_MANAGEMENT_CONSOLE_ONBOARDING_READ = "159";
  public static final String LPX_MANAGEMENT_CONSOLE_ONBOARDING_WRITE = "160";
  public static final String LPX_JCURVE_READ = "161";
  public static final String LPX_JCURVE_WRITE = "162";
  public static final String LPX_MANAGEMENT_CONSOLE_COPILOT = "165";
  public static final String LPX_MANAGEMENT_CONSOLE_RECONCILIATION_READ = "166";
  public static final String LPX_MANAGEMENT_CONSOLE_RECONCILIATION_WRITE = "167";
  public static final String LPX_MANAGEMENT_CONSOLE_WATCHLIST_READ = "170";
  public static final String LPX_MANAGEMENT_CONSOLE_WATCHLIST_WRITE = "171";
  public static final String LPX_MANAGEMENT_CONSOLE_K1_READ = "172";
  public static final String LPX_MANAGEMENT_CONSOLE_K1_WRITE = "173";
  public static final String LPX_MANAGEMENT_CONSOLE_GO_LIVE_DATE_READ = "177";
  public static final String LPX_MANAGEMENT_CONSOLE_GO_LIVE_DATE_WRITE = "178";
  public static final String LPX_MANAGEMENT_CONSOLE_GO_LIVE_DATE_WRITE_WITH_FORCE = "179";
  public static final String LPX_MANAGEMENT_CONSOLE_DASHBOARD_MANAGER = "184";
}
