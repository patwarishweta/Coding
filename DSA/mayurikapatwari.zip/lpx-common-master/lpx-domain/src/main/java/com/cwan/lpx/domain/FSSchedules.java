package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class FSSchedules implements Serializable {

  @Serial private static final long serialVersionUID = -4903227760230975120L;
  private FSIncomeStatement fsIncomeStatement;
  private FSBalanceSheet fsBalanceSheet;
  private FSStatementOfCashflow fsStatementOfCashflow;
}
