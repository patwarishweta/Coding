package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Operating {

  private String ebit;
  private String ebitda;
  private String evEbitda;
  private String freeCashflow;
  private String netDebt;
  private String netDebtEbitda;
  private String netIncome;
  // Net Operating Income (Real Estate)
  private String netOperatingIncome;
  private String netRevenues;
  private String netSeniorDebt;
  private String numberOfEmployees;
  // Occupancy rate (Real Estate)
  private String occupancyRate;
  private String operatingCashflow;
  // Rental Income (Real Estate)
  private String rentalIncome;
  private String totalEnterpriseValue;
  // WALT (Real Estate)
  private String walt;
}
