package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityInvestmentDetail {

  private String commitment;
  private String entryDate;
  private String numberOfShares;
  private String principal;
}
