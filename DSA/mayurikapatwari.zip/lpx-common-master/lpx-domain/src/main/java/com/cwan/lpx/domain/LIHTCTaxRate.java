package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;

@Builder(toBuilder = true)
public record LIHTCTaxRate(
    Account account,
    Security security,
    TaxType taxType,
    Double taxRate,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate taxRateStartDate,
    String additionalNotes,
    String action,
    String createdBy,
    Boolean isCreatedByInternalUser,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdOn,
    String modifiedBy,
    Boolean isModifiedByInternalUser,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime modifiedOn)
    implements Serializable {}
