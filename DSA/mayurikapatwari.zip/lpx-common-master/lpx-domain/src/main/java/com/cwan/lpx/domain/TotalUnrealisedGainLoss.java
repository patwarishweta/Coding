package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TotalUnrealisedGainLoss implements Serializable {

  @Serial private static final long serialVersionUID = 847701083143171511L;
  private String totalUnrealisedGainLossValue;
  private String unrealisedGainLossOnInvestments;
  private String unrealisedFXGainLoss;
}
