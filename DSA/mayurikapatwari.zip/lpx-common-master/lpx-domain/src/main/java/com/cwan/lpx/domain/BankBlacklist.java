package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankBlacklist(
    String bankBlacklistUuid,
    Bank bank,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdAt,
    Long createdBy)
    implements Serializable {

  public static class BankBlacklistBuilder {

    public BankBlacklist.BankBlacklistBuilder bankBlacklistUuid(String bankBlacklistUuid) {
      this.bankBlacklistUuid =
          StringUtils.lowerCase(
              StringUtils.trimToNull(StringUtils.normalizeSpace(bankBlacklistUuid)));
      return this;
    }
  }
}
