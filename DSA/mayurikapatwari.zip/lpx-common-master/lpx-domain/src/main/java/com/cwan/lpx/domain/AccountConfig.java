package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class AccountConfig implements Serializable {

  @Serial private static final long serialVersionUID = 8898116725088501357L;

  private Long id;
  private Account account;
  private Service service;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate subscriptionStartDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate subscriptionEndDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime tsCreatedOn;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime tsModifiedOn;

  private String createdBy;
  private String modifiedBy;
  private Boolean isCreatedByInternalUser;
  private Boolean isModifiedByInternalUser;
  private Long ultimateParentId;
  private String ultimateParentName;
  private Long clientId;
  private String clientName;
  private Map<String, String> attributes;
  private String clientCurrentState;
}
