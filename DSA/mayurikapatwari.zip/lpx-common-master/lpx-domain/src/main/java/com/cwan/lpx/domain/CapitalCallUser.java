package com.cwan.lpx.domain;

import java.io.Serializable;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record CapitalCallUser(Integer id, String fullName, String email) implements Serializable {

  public static class CapitalCallUserBuilder {

    public CapitalCallUserBuilder fullName(String fullName) {
      this.fullName = StringUtils.trimToNull(StringUtils.normalizeSpace(fullName));
      return this;
    }

    public CapitalCallUserBuilder email(String email) {
      this.email = StringUtils.trimToNull(StringUtils.normalizeSpace(email));
      return this;
    }
  }
}
