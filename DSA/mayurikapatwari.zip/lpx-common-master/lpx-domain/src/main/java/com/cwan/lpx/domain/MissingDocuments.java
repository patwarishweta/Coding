package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class MissingDocuments {
  private Long id;
  private Long accountId;
  private Long securityId;
  private String fundName;
  private Long clientId;
  private String clientName;
  private String documentType;
  private MissingDocumentStatus documentMissingCategory;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate docDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private Boolean flagCanoeUploaded;
  private Boolean flag;
  private LocalDate flagBeginDate;
  private LocalDate flagEndDate;
  private String flagComment;
  private String flagLastModifiedBy;

  @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
  private ZonedDateTime flagLastModifiedOn;
}
