package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Static {

  private String country;
  private String dealType;
  private String gicsIndustry;
  private String isPublic;
  private String pcCurrency;
  // Property area (Real Estate)
  private String propertyArea;
  // Property type (Real Estate)
  private String propertyType;
  // Sector (as stated)
  private String sector;
  private String stockTicker;
}
