package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record BankAccount(
    String bankAccountUuid,
    Bank bank,
    Long accountId,
    String accountName,
    String accountNumber,
    String iban,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdAt,
    Long createdBy)
    implements Serializable {

  public static class BankAccountBuilder {

    public BankAccount.BankAccountBuilder bankAccountUuid(String bankAccountUuid) {
      this.bankAccountUuid =
          StringUtils.lowerCase(
              StringUtils.trimToNull(StringUtils.normalizeSpace(bankAccountUuid)));
      return this;
    }

    public BankAccount.BankAccountBuilder accountName(String accountName) {
      this.accountName = StringUtils.trimToNull(StringUtils.normalizeSpace(accountName));
      return this;
    }

    public BankAccount.BankAccountBuilder accountNumber(String accountNumber) {
      this.accountNumber =
          StringUtils.upperCase(StringUtils.trimToNull(StringUtils.normalizeSpace(accountNumber)));
      return this;
    }

    public BankAccount.BankAccountBuilder iban(String iban) {
      this.iban = StringUtils.upperCase(StringUtils.trimToNull(StringUtils.normalizeSpace(iban)));
      return this;
    }
  }
}
