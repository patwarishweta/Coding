package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Optional;

public record TransferRequest(
    Long sourceAccountId,
    Long securityId,
    String cusip,
    Integer userId,
    LocalDate entryDate,
    String currency,
    Collection<Integer> basisIds,
    @JsonInclude(JsonInclude.Include.NON_ABSENT) Optional<TransferDocumentInfo> document,
    Collection<TransferDestination> destinations) {
  public TransferRequest(
      Long sourceAccountId,
      Long securityId,
      String cusip,
      Integer userId,
      LocalDate entryDate,
      String currency,
      Collection<Integer> basisIds,
      Collection<TransferDestination> destinations) {
    this(
        sourceAccountId,
        securityId,
        cusip,
        userId,
        entryDate,
        currency,
        basisIds,
        Optional.empty(),
        destinations);
  }
}
