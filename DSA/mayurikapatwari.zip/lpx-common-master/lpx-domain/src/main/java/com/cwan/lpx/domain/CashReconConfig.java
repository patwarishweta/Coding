package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class CashReconConfig {

  private Long id;
  private Long accountId;
  private Long securityId;
  private String currency;
  private String createdBy;
  private String modifiedBy;
  private CustodyFeedConfig contributionCustodyFeedConfig;
  private CustodyFeedConfig distributionCustodyFeedConfig;
}
