package com.cwan.lpx.domain;

/**
 * Enum representing the types of date filters that can be applied to CapitalCallDocument queries.
 */
public enum CapitalCallDateFilterType {
  /** Represents filtering by the date the call was received. */
  RECEIVED_DATE,
  /** Represents filtering by the due date of the call. */
  DUE_DATE
}
