package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TotalRealisedGainLoss implements Serializable {

  @Serial private static final long serialVersionUID = 9210227391908572504L;
  private String totalRealisedGainLossValue;
  private String realisedGainLossOnInvestments;
  private String realisedFXGainLoss;
}
