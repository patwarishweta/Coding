package com.cwan.lpx.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
@Builder(builderClassName = "CanoeDuplicateCheckResponseBuilder")
@EqualsAndHashCode
public class CanoeDuplicateCheckResponse {

  private final String customAllocationId;
  private final String dataDate;
  private final List<Double> capitalCall;
  private final List<Double> capitalCallNetAmount;
  private final List<Double> distribution;
  private final List<Double> distributionNetAmount;
  private final List<Double> endingBalance;

  public static class CanoeDuplicateCheckResponseBuilder {

    public CanoeDuplicateCheckResponseBuilder customAllocationId(String customAllocationId) {
      this.customAllocationId = StringUtils.trimToNull(customAllocationId);
      return this;
    }

    public CanoeDuplicateCheckResponseBuilder dataDate(String dataDate) {
      this.dataDate = StringUtils.trimToNull(dataDate);
      return this;
    }

    public CanoeDuplicateCheckResponseBuilder capitalCall(Object capitalCall) {
      this.capitalCall = convertToList(capitalCall);
      return this;
    }

    public CanoeDuplicateCheckResponseBuilder capitalCallNetAmount(Object capitalCallNetAmount) {
      this.capitalCallNetAmount = convertToList(capitalCallNetAmount);
      return this;
    }

    public CanoeDuplicateCheckResponseBuilder distribution(Object distribution) {
      this.distribution = convertToList(distribution);
      return this;
    }

    public CanoeDuplicateCheckResponseBuilder distributionNetAmount(Object distributionNetAmount) {
      this.distributionNetAmount = convertToList(distributionNetAmount);
      return this;
    }

    public CanoeDuplicateCheckResponseBuilder endingBalance(Object endingBalance) {
      this.endingBalance = convertToList(endingBalance);
      return this;
    }

    public CanoeDuplicateCheckResponse build() {
      if (Objects.isNull(this.capitalCall)) {
        this.capitalCall = Collections.emptyList();
      }
      if (Objects.isNull(this.capitalCallNetAmount)) {
        this.capitalCallNetAmount = Collections.emptyList();
      }
      if (Objects.isNull(this.distribution)) {
        this.distribution = Collections.emptyList();
      }
      if (Objects.isNull(this.distributionNetAmount)) {
        this.distributionNetAmount = Collections.emptyList();
      }
      if (Objects.isNull(this.endingBalance)) {
        this.endingBalance = Collections.emptyList();
      }
      return new CanoeDuplicateCheckResponse(
          customAllocationId,
          dataDate,
          capitalCall,
          capitalCallNetAmount,
          distribution,
          distributionNetAmount,
          endingBalance);
    }

    private static List<Double> convertToList(Object value) {
      List<Double> result = new ArrayList<>();
      if (value instanceof List) {
        result =
            ((List<?>) value)
                .stream()
                    .filter(Objects::nonNull)
                    .filter(v -> (v instanceof String) || (v instanceof Double))
                    .map(CanoeDuplicateCheckResponseBuilder::convertToDouble)
                    .filter(Objects::nonNull)
                    .map(Math::abs)
                    .collect(Collectors.toList());
      } else if (value instanceof String) {
        var convertedValue = convertToDouble(value);
        if (Objects.nonNull(convertedValue)) {
          result.add(Math.abs(convertedValue));
        }
      } else if (value instanceof Double) {
        result.add(Math.abs((Double) value));
      }
      result = result.stream().filter(v -> v != 0.0).sorted().collect(Collectors.toList());
      return Collections.unmodifiableList(result);
    }

    private static Double convertToDouble(Object value) {
      Double result = null;
      if (value instanceof Double) {
        result = (Double) value;
      } else if (value instanceof String) {
        var trimmedValue = StringUtils.trimToNull((String) value);
        if (Objects.nonNull(trimmedValue)) {
          try {
            result = Double.valueOf(trimmedValue);
          } catch (NumberFormatException e) {
            // ignore
          }
        }
      }
      return result;
    }
  }
}
