package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class ClientSpecificData {
  private Long id;
  private Long accountId;
  private Long securityId;
  private String fundName;
  private Boolean isCanoeConnected;
  private Integer vintageYear;
  private Double capitalCommitment;
  private String sector1;
  private String sector2;
  private String sector3;
  private String countryOfRisk;
  private String stateOfRisk;
  private String regionOfInvestment;
  private Boolean affiliateTransferRight;
  private String mostFavourableNationClause;
  private Double issueConcentrationRestriction;
  private Double ownershipPercentage;
  private String naicTypeAndStrategy;
  private String naicCategory;
  private String secondaryMarket;
  private LocalDate amortStartDate;
  private boolean forceIrrCalc;
}
