package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TotalAssets implements Serializable {

  @Serial private static final long serialVersionUID = 6789221127028801314L;
  private String dividendsReceivable;
  private String tradeAndOtherReceivables;
  private String otherAssets;
  private InvestmentsAtFairValue investmentsAtFairValue;
  private String totalAssetsValue;
  private String cashAndCashEquivalents;
  private String interestReceivable;
}
