package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class Performance implements Serializable {

  @Serial private static final long serialVersionUID = 8528943352170824745L;
  private Long id;
  private Long accountId;
  private Long securityId;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime calculationDate;

  private String frequency;
  private Double residualValue;
  private Double totalCommitment;
  private Double fundedCommitment;
  private Double recallableDistribution;
  private Double unfundedCommitment;
  private Double rvpi;
  private Double dpi;
  private Double tvpi;
  private Double pic;
  private Double dc;
  private Double grossMoic;
  private Double grossXirr;
  private Double netXirr;
  private Double customXirr;
  private Double modifiedXirr;
  private Double xirrMgmtFees;
  private Double xirrPartnershipExpenses;
  private Double xirrFeesAndExpenses;
  private Double pme;
  private Double pmeReferenceIndex;
  private String pmeReferenceIndexName;
  private Double navImpact;
  private Double totalContributions;
  private Double totalContributionsLastMonth;
  private Double totalDistributions;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  private Double previousQtrIrr;
  private Integer vintageYear;
  private String irrCalcStatus;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;
}
