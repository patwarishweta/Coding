package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

@Data
@AllArgsConstructor
@Builder
public class MissingDocumentAlertConfig {
  private Long id;
  @NonNull private Long clientId;
  private List<Long> accountIds;
  private List<Long> securityIds;
  private List<MissingDocumentStatus> documentMissingCategories;
  private List<String> documentTypes;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate startDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate expiry;

  @NonNull private List<String> username;
  @NonNull private Boolean isActive;
}
