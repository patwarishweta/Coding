package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class BankDetail implements Serializable {

  @Serial private static final long serialVersionUID = 2669981357841280800L;
  private Long id;
  private String name;
  private String address;
  private String abaRoutingNumber;
  private String swiftOrChip;
  private String accountIBAN;
  private String accountName;
  private String accountNumber;
  private String accountAddress;
  private String reference;
  private String createdBy;
  private Boolean isCreatedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;
}
