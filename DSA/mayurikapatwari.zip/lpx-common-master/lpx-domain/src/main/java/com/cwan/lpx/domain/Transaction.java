package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Transaction implements Serializable {

  private static final long serialVersionUID = 8173127539474034749L;
  private Long id;
  private Account account;
  private Security security;
  private Document document;
  private String source;
  private String dataSource;
  private CoreData coreData;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate tradeDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate entryDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate settleDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate amortStartDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate acquiredDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime knowledgeStartDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime knowledgeEndDate;

  private String type;
  private String subType;
  private String currency;
  private Double unit;
  private Double price;
  private Boolean isCurrent;
  private Integer version;
  private Double fxRate;
  private String fxCurrency;
  private Double grossAmount;
  private Double netAmount;
  private Double cashImpact;
  private Double navImpact;
  private Double unfundedCommitmentImpact;
  private Double fundedCommitmentImpact;
  private Double totalCommitmentImpact;
  private Double recallableImpact;
  private String investmentCompany;
  private String custodianName;
  private String additionalNotes;
  private String reasonCode;
  private String comments;
  private Boolean isHistoric;
  private String action;
  private Long parentId;
  private String createdBy;
  private Boolean isCreatedByInternalUser;
  @Builder.Default private String basisAffect = "ALL";

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;

  private ModifiedAttributesResults modifiedAttributesResults;
  private Set<TransactionIdentifier> transactionIdentifiers;
  private Set<LoadTransactionDetail> loadTransactionDetails;
}
