package com.cwan.lpx.domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record CapitalCallAudit(
    CapitalCallStatus previousStatus,
    CapitalCallAction action,
    CapitalCallStatus nextStatus,
    LocalDateTime timestamp,
    String comment,
    CapitalCallUser user)
    implements Serializable {

  public static class CapitalCallAuditBuilder {

    public CapitalCallAuditBuilder comment(String comment) {
      this.comment = StringUtils.trimToNull(StringUtils.normalizeSpace(comment));
      return this;
    }
  }
}
