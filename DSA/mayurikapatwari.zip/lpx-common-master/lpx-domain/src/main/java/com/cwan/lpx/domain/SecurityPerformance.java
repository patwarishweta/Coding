package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityPerformance {

  private String fmvShare;
  private String remainingCapitalInvested;
  private String residualValue;
  private String totalCapitalInvested;
}
