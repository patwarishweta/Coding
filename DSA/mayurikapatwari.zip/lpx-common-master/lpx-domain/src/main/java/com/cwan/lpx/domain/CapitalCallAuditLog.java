package com.cwan.lpx.domain;

import java.util.List;
import lombok.Builder;

@Builder(toBuilder = true)
public record CapitalCallAuditLog(Long documentId, List<CapitalCallAudit> audit) {}
