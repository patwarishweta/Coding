package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

@Data
@AllArgsConstructor
@Builder
public class MissingDocumentExpectationsConfig {
  private Long id;
  private Long securityId;
  @NonNull private Long fundId;
  private String fundName;
  @NonNull private String documentType;
  @NonNull private String frequency;
  @NonNull private Integer threshold;
  @NonNull private Boolean isActive;
}
