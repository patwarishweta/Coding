package com.cwan.lpx.domain;

/**
 * Enum representing the various statuses a capital call can have. It can be used for both tracking
 * the status and display purposes.
 */
public enum CapitalCallStatus {
  /** Status indicating a capital call has been blacklisted. */
  BLACKLISTED,
  /** Status indicating a capital call is undergoing a wire check. */
  WIRE_CHECK,
  /** Status indicating a capital call's wire check has been rejected. */
  WIRE_CHECK_REJECTED,
  /** Status indicating a capital call is undergoing an initial review. */
  INITIAL_REVIEW,
  /** Status indicating a capital call is undergoing a final review. */
  FINAL_REVIEW,
  /** Status indicating a capital call has been completed. */
  COMPLETED,
  /** Status indicating a capital call is new and not yet processed. */
  NEW_CAPITAL_CALL,
  /** Status indicating a capital call's status is not specified or unknown. */
  NOT_SPECIFIED
}
