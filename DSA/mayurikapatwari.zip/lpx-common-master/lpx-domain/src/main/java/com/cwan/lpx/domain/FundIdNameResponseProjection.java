package com.cwan.lpx.domain;

public interface FundIdNameResponseProjection {

  Long getId();

  String getName();
}
