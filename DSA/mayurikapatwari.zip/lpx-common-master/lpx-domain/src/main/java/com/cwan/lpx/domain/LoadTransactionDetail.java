package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class LoadTransactionDetail implements Serializable {

  private Long id;
  private Long transactionId;
  private Integer transVersion;
  private String accountingMethod;
  private Double bookValue;
  private Double fxBookValue;
  private Double originalCost;
  private Double fxOriginalCost;
  private Double impairment;
  private Double fxImpairment;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;
}
