package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class CustodyFeedConfig {

  private Long id;
  private String name;
  private Long custodyAccountId;
  private String cashAccountNumber;
  private String createdBy;
  private String modifiedBy;
}
