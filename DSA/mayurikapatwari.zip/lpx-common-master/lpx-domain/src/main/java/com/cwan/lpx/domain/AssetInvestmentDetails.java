package com.cwan.lpx.domain;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class AssetInvestmentDetails {

  private String commitment;
  private LocalDate entryDate;
  private Long numberOfShares;
  private Double principal;
}
