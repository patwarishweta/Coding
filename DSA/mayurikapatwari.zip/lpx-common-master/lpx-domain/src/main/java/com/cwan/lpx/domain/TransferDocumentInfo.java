package com.cwan.lpx.domain;

public record TransferDocumentInfo(Long documentId, String fileName) {

  public Document toDocument() {
    return Document.builder().id(documentId()).fileName(fileName()).build();
  }
}
