package com.cwan.lpx.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class LoaInfo {

  private Long id;
  private Long clientId;
  private String gpName;
  private String gpPortalAddress;
  private String gpEmail;
  private Boolean canoeAccess;
  private List<String> fundNames;
  private Document document;
  private String canoeStatus;
  private String cwStatus;
  private String salesforceId;
  private String comment;
  private LocalDate loaMailSentDate;
  private boolean loaMailSent;

  private String createdBy;
  private LocalDateTime createdOn;
  private String modifiedBy;
  private LocalDateTime modifiedOn;
}
