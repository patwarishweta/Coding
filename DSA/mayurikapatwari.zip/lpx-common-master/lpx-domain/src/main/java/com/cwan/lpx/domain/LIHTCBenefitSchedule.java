package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;

@Builder(toBuilder = true)
public record LIHTCBenefitSchedule(
    Account account,
    Security security,
    TaxType taxType,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate reportingDate,
    @JsonFormat(pattern = "yyyy-MM-dd") LocalDate scheduleDate,
    Double contributions,
    Double distributions,
    Double federalCredits,
    Double stateCredits,
    Double otherCredits,
    Double taxDeductions,
    Double sale,
    String comments,
    String additionalNotes,
    String action,
    String createdBy,
    Boolean isCreatedByInternalUser,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime createdOn,
    String modifiedBy,
    Boolean isModifiedByInternalUser,
    @EqualsAndHashCode.Exclude @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
        LocalDateTime modifiedOn)
    implements Serializable {}
