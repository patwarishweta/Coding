package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityDetail {

  private String couponType;
  private String currentRate;
  private String debtSeniority;
  private String fixedRate;
  private String floor;
  private String investmentRound;
  private String maturityDate;
  private String pikSpread;
  private String quotedSpread;
  private String referenceRate;
  private String referenceRateFloor;
  private String secured;
  private String securityCurrency;
  private String securityClass;
  private String securityDescription;
  private String securityName;
  private String securityType;
  private String terminationOption;
}
