package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@RequiredArgsConstructor
public class Aum implements Serializable {

  @Serial private static final long serialVersionUID = 8767546441091546528L;
  private Long id;
  private Long accountId;
  private Long securityId;
  private Long ultimateParentId;
  private Long clientId;
  private Double aum;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private LocalDate calculatedOn;

  private Boolean isActive;
}
