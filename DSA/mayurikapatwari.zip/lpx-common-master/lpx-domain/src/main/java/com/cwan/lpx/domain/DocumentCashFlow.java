package com.cwan.lpx.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class DocumentCashFlow implements Serializable {

  @Serial private static final long serialVersionUID = 2385431601465819899L;
  private Long id;
  private Document document;
  private String limitedPartnerId;
  private Double limitedPartnerPercentOfFund;
  private Double limitedPartnerPercentOfNAV;
  private Double netAmount;
  private Double totalContribution;
  private Double totalRecallableDistribution;
  private Double totalNonRecallableDistribution;
  private Double recallableDistributionITD;
  private Double returnOfCapitalDistributionITD;
  private String currency;
  private String fxCurrency;
  private Double fxRate;
  private String ffcName;
  private String ffcNumber;
  private String source;
  private Boolean isCurrent;
  private Integer version;
  private BankDetail beneficiaryBankDetail;
  private BankDetail correspondentBankDetail;
  private BankDetail intermediaryBankDetail;
  private String action;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime knowledgeStartDate;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime knowledgeEndDate;

  private String createdBy;
  private Boolean isCreatedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime createdOn;

  private String modifiedBy;
  private Boolean isModifiedByInternalUser;

  @EqualsAndHashCode.Exclude
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss[.SSS]")
  private LocalDateTime modifiedOn;
}
