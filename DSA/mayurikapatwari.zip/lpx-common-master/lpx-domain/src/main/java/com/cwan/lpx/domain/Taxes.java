package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class Taxes implements Serializable {

  @Serial private static final long serialVersionUID = 4229552066122723865L;
  private String capitalTax;
  private String incomeTax;
  private String taxesValue;
}
