package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class DocumentDuplicateGroupKey
    implements Comparable<DocumentDuplicateGroupKey>, Serializable {

  @Serial private static final long serialVersionUID = -4475592286877931541L;
  private Long documentId;
  private String fileName;
  private Long accountId;
  private Long securityId;
  private String documentType;
  private LocalDate documentReceivedDate;
  private LocalDate documentDate;
  private String entity;
  private String investment;
  private Long clientId;
  private String clientName;
  private Long ultimateParentId;
  private String ultimateParentName;
  private String assignee;
  private String modifier;
  private String duplicateStatus;
  private String comment;
  private String note;
  private LocalDateTime createdOn;
  private LocalDateTime modifiedOn;
  private String currentCanoeId;
  private LocalDateTime currentReceivedOn;
  private Long documentDuplicateId;
  private LocalDateTime documentDuplicateCreatedOn;

  /**
   * Compare by `documentDuplicateCreatedOn` **descending** (nulls go last, meaning they're treated
   * as "smaller").
   */
  @Override
  public int compareTo(@NonNull DocumentDuplicateGroupKey other) {
    if (Objects.isNull(this.documentDuplicateCreatedOn)
        && Objects.isNull(other.documentDuplicateCreatedOn)) {
      return 0;
    }
    if (Objects.isNull(this.documentDuplicateCreatedOn)) {
      return 1;
    }
    if (Objects.isNull(other.documentDuplicateCreatedOn)) {
      return -1;
    }
    return other.documentDuplicateCreatedOn.compareTo(this.documentDuplicateCreatedOn);
  }
}
