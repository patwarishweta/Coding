package com.cwan.lpx.domain;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class CoreData {
  private UUID coreTransactionId;
  private Long coreLegacyTransactionId;
  private Long coreOriginalTransactionId;
  private String coreStatus;
}
