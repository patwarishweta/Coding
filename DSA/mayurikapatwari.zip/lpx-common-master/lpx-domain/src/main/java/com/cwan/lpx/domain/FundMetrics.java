package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class FundMetrics implements Serializable {

  @Serial private static final long serialVersionUID = -6691767987840660256L;
  private String capitalContributions;
  private String capitalDistributions;
  private String capitalUndrawn;
  private String dpi;
  private String fundCurrency;
  private String fundName;
  private String grossIrr;
  // LTV (Private Debt/Real Estate)
  private String ltv;
  private String netIrr;
  private String periodAndDate;
  private String nav;
  private String residualValue;
  private String rvpi;
  private String tvpi;
  private String totalAssets;
  private String totalLiabilities;
  private String portfolioFMV;
}
