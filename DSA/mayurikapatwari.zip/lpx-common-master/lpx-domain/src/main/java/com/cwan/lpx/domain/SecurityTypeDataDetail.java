package com.cwan.lpx.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class SecurityTypeDataDetail {
  private boolean isLIHTC;
  private boolean isAmortizingLP;
  private boolean isLimitedPartnership;
}
