package com.cwan.lpx.domain;

public enum ConfigAttributes {
  TREAT_KNOWLEDGE_DATE_AS_SETTLE_DATE,
  DOC_VALIDATION_REQUIRED,
  USE_LMC_ENTRY_DATE_AS_OF,
}
