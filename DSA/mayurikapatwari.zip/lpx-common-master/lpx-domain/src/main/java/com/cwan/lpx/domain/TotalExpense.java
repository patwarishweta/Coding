package com.cwan.lpx.domain;

import java.io.Serial;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder(toBuilder = true)
@RequiredArgsConstructor
@AllArgsConstructor
public class TotalExpense implements Serializable {

  @Serial private static final long serialVersionUID = 159155844168715255L;
  private String totalExpenseValue;
  private String netManagementFees;
  private String brokenDealFees;
  private String interestExpense;
  private String professionalFees;
  private String bankFees;
  private String advisoryDirectorsFees;
  private String insuranceExpense;
  private String otherExpenses;
  private String investmentExpenses;
  private String auditFees;
  private String dealCosts;
  private String administrationFees;
  private String partnershipExpenses;
}
