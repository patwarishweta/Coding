package com.cwan.lpx.domain;

import lombok.Builder;
import org.apache.commons.lang3.StringUtils;

@Builder(toBuilder = true)
public record CapitalCallAuditAction(
    Long documentId, String comment, CapitalCallStatus currentStatus, CapitalCallUser user) {

  public static class CapitalCallAuditActionBuilder {

    public CapitalCallAuditActionBuilder comment(String comment) {
      this.comment = StringUtils.trimToNull(StringUtils.normalizeSpace(comment));
      return this;
    }
  }
}
