package com.cwan.lpx.domain;

// Names have limit of 25 chars in the DB
public enum TaxType {
  STATE,
  FEDERAL,
  LOCAL
}
